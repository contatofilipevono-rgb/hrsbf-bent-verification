import H12CloudChart1Data192

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans48893_48894 : H12AffineEnvironment.transform 10 0 env48893 = env48894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48893 == env48894) = true)

def leafEnv48894 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,0,1,3,17,1,21,0,1,1,17,3,20,8,1,16,0,17,17,1,21,0,5,1,5,2,0,513,1,1,0]

def active48894 : List Nat := [0,1,2,3,8]

def tree48894 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48894 : H12WitnessSearch.Good tree48894 := H12GlobalWitnessIndex.good

theorem leafIdentity48894 : H12AffineFastState.composeSystem env48894 rootObs = leafEnv48894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48894 rootObs == leafEnv48894) = true)

theorem terminalChecked48894 : H12PackedTerminal.terminalCheckFast leafEnv48894 active48894 tree48894 = true := by decide +kernel

def env48895 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,1,1,3,16,2049,20,0,1,1,17,3,8,16,2048,16,17,2049,20,0,5,1,1,513]

theorem envBound48895 : H12AffineFastState.Bounded env48895 := by
  intro p hp
  have h : env48895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48892_48895 : H12AffineEnvironment.transform 9 21 env48892 = env48895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48892 == env48895) = true)

theorem identity48895 : scanCanonicalize (H12AffineFastState.compose env48895 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound48895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48896 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,17,9,1,1,3,16,522,20,0,1,1,17,3,8,16,523,16,17,522,20,0,5,1,1,513]

theorem envBound48896 : H12AffineFastState.Bounded env48896 := by
  intro p hp
  have h : env48896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48895_48896 : H12AffineEnvironment.transform 10 523 env48895 = env48896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env48895 == env48896) = true)

def leafEnv48896 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,17,9,1,1,3,16,522,20,0,1,1,17,3,21,8,1,16,523,16,17,522,20,0,5,1,5,2,1,513,1,1,0]

def active48896 : List Nat := [0,1,2,3,8]

def tree48896 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48896 : H12WitnessSearch.Good tree48896 := H12GlobalWitnessIndex.good

theorem leafIdentity48896 : H12AffineFastState.composeSystem env48896 rootObs = leafEnv48896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48896 rootObs == leafEnv48896) = true)

theorem terminalChecked48896 : H12PackedTerminal.terminalCheckFast leafEnv48896 active48896 tree48896 = true := by decide +kernel

def env48897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,97,41431,8328,65,158013,5392,17777,179648,1453,41341,257,21840,46324,625]

theorem envBound48897 : H12AffineFastState.Bounded env48897 := by
  intro p hp
  have h : env48897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48879_48897 : H12AffineEnvironment.transform 22 97 env48879 = env48897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 97 env48879 == env48897) = true)

theorem identity48897 : scanCanonicalize (H12AffineFastState.compose env48897 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13493) := by decide +kernel

theorem selectedBound48897 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13493,32160,1025,32769,4161,21792,97,41431,8328,65,23944,5392,17777,35189,1453,41341,257,21840,46324,625]

theorem envBound48898 : H12AffineFastState.Bounded env48898 := by
  intro p hp
  have h : env48898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48897_48898 : H12AffineEnvironment.transform 16 13493 env48897 = env48898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13493 env48897 == env48898) = true)

theorem identity48898 : scanCanonicalize (H12AffineFastState.compose env48898 (packedSelected [1,11,12,15,16,17,18,19,20,23,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound48898 : packedSelected [1,11,12,15,16,17,18,19,20,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env48899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8493,8202,13493,32160,1025,8492,4161,21792,97,250,8328,65,23944,5392,17777,10328,1453,80,257,21840,5593,625]

theorem envBound48899 : H12AffineFastState.Bounded env48899 := by
  intro p hp
  have h : env48899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48898_48899 : H12AffineEnvironment.transform 14 8493 env48898 = env48899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env48898 == env48899) = true)

theorem identity48899 : scanCanonicalize (H12AffineFastState.compose env48899 (packedSelected [1,2,3,4,5,12,14,15,17,19,20,22,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48899 : packedSelected [1,2,3,4,5,12,14,15,17,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env48900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8493,8202,13493,10401,1025,8492,4161,33,97,250,8328,65,2185,5392,4208,10328,1453,80,257,81,5593,625]

theorem envBound48900 : H12AffineFastState.Bounded env48900 := by
  intro p hp
  have h : env48900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48899_48900 : H12AffineEnvironment.transform 13 5377 env48899 = env48900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48899 == env48900) = true)

theorem identity48900 : scanCanonicalize (H12AffineFastState.compose env48900 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48900 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48901 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,8192,5377,8493,8202,13493,10401,1025,8492,4145,33,17,138,8328,49,2185,5392,4096,10280,1453,32,257,33,5545,513]

theorem envBound48901 : H12AffineFastState.Bounded env48901 := by
  intro p hp
  have h : env48901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48900_48901 : H12AffineEnvironment.transform 5 48 env48900 = env48901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48900 == env48901) = true)

theorem identity48901 : scanCanonicalize (H12AffineFastState.compose env48901 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48901 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48902 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,5377,8460,8202,13460,10368,1025,8461,4112,0,17,138,8328,16,2185,5392,4096,10249,1420,1,257,0,5512,513]

theorem envBound48902 : H12AffineFastState.Bounded env48902 := by
  intro p hp
  have h : env48902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48901_48902 : H12AffineEnvironment.transform 4 1 env48901 = env48902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48901 == env48902) = true)

theorem identity48902 : scanCanonicalize (H12AffineFastState.compose env48902 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound48902 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env48903 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,388,5377,136,398,5392,2308,1025,137,4112,0,17,138,268,16,2185,5392,4096,2445,1420,1,257,0,5512,513]

theorem envBound48903 : H12AffineFastState.Bounded env48903 := by
  intro p hp
  have h : env48903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48902_48903 : H12AffineEnvironment.transform 12 388 env48902 = env48903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env48902 == env48903) = true)

theorem identity48903 : scanCanonicalize (H12AffineFastState.compose env48903 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48903 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48904 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,1,263,5392,2308,1025,0,4112,0,17,3,268,16,2048,5392,4096,2308,1285,1,257,0,5377,513]

theorem envBound48904 : H12AffineFastState.Bounded env48904 := by
  intro p hp
  have h : env48904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48903_48904 : H12AffineEnvironment.transform 6 9 env48903 = env48904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48903 == env48904) = true)

theorem identity48904 : scanCanonicalize (H12AffineFastState.compose env48904 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48904 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48905 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,1,2,5141,2049,1025,0,4112,0,17,3,9,16,2048,5141,4096,2049,1024,1,4,0,5124,513]

theorem envBound48905 : H12AffineFastState.Bounded env48905 := by
  intro p hp
  have h : env48905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48904_48905 : H12AffineEnvironment.transform 7 5 env48904 = env48905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48904 == env48905) = true)

def env48906 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,1,2,1029,2049,1025,0,0,0,17,3,9,16,2048,1029,16,2049,1024,1,4,0,1044,513]

theorem envBound48906 : H12AffineFastState.Bounded env48906 := by
  intro p hp
  have h : env48906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48905_48906 : H12AffineEnvironment.transform 11 16 env48905 = env48906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48905 == env48906) = true)

def env48907 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,1,2,1028,2049,1025,0,1,0,17,3,9,16,2048,1028,17,2049,1024,1,4,0,1045,513]

theorem envBound48907 : H12AffineFastState.Bounded env48907 := by
  intro p hp
  have h : env48907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48905_48907 : H12AffineEnvironment.transform 11 17 env48905 = env48907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48905 == env48907) = true)

theorem identity48907 : scanCanonicalize (H12AffineFastState.compose env48907 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48907 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48908 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,1,1,2,16,2049,21,0,1,0,17,3,9,16,2048,16,17,2049,20,1,4,0,1,513]

theorem envBound48908 : H12AffineFastState.Bounded env48908 := by
  intro p hp
  have h : env48908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48907_48908 : H12AffineEnvironment.transform 9 20 env48907 = env48908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48907 == env48908) = true)

theorem identity48908 : scanCanonicalize (H12AffineFastState.compose env48908 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound48908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48909 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,17,8,1,1,2,16,523,21,0,1,0,17,3,9,16,522,16,17,523,20,1,4,0,1,513]

theorem envBound48909 : H12AffineFastState.Bounded env48909 := by
  intro p hp
  have h : env48909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48908_48909 : H12AffineEnvironment.transform 10 522 env48908 = env48909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env48908 == env48909) = true)

def leafEnv48909 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,17,8,1,1,2,16,523,21,0,1,0,17,3,21,9,1,16,522,16,17,523,20,1,4,0,5,3,1,513,1,1,0]

def active48909 : List Nat := [0,1,2,3,8]

def tree48909 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48909 : H12WitnessSearch.Good tree48909 := H12GlobalWitnessIndex.good

theorem leafIdentity48909 : H12AffineFastState.composeSystem env48909 rootObs = leafEnv48909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48909 rootObs == leafEnv48909) = true)

theorem terminalChecked48909 : H12PackedTerminal.terminalCheckFast leafEnv48909 active48909 tree48909 = true := by decide +kernel

def env48910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98781,8328,65,8546653,79130,8480026,8568225,8390092,98678,257,8484155,8492191,8462874]

theorem envBound48910 : H12AffineFastState.Bounded env48910 := by
  intro p hp
  have h : env48910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48877_48910 : H12AffineEnvironment.transform 21 21793 env48877 = env48910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env48877 == env48910) = true)

theorem identity48910 : scanCanonicalize (H12AffineFastState.compose env48910 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound48910 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,73755,98781,8328,65,215366,79130,17665,236986,75223,98678,257,21792,46212,513]

theorem envBound48911 : H12AffineFastState.Bounded env48911 := by
  intro p hp
  have h : env48911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48910_48911 : H12AffineEnvironment.transform 22 73755 env48910 = env48911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env48910 == env48911) = true)

def env48912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,73755,98645,8192,65,215366,79130,17665,236850,75103,98678,257,21792,46092,513]

theorem envBound48912 : H12AffineFastState.Bounded env48912 := by
  intro p hp
  have h : env48912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48911_48912 : H12AffineEnvironment.transform 6 8 env48911 = env48912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48911 == env48912) = true)

theorem identity48912 : scanCanonicalize (H12AffineFastState.compose env48912 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound48912 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,17664,32040,1025,32769,77899,21793,73755,98645,8192,65,68678,79130,17665,120882,75103,98678,257,21792,46092,513]

theorem envBound48913 : H12AffineFastState.Bounded env48913 := by
  intro p hp
  have h : env48913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48912_48913 : H12AffineEnvironment.transform 16 17664 env48912 = env48913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env48912 == env48913) = true)

theorem identity48913 : scanCanonicalize (H12AffineFastState.compose env48913 (packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound48913 : packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env48914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,9499,17664,32040,1025,32769,5456,21793,1280,42062,8192,65,10589,4097,17665,64809,68,42093,257,21792,46092,513]

theorem envBound48914 : H12AffineFastState.Bounded env48914 := by
  intro p hp
  have h : env48914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48913_48914 : H12AffineEnvironment.transform 15 9499 env48913 = env48914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env48913 == env48914) = true)

theorem identity48914 : scanCanonicalize (H12AffineFastState.compose env48914 (packedSelected [3,5,10,12,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48914 : packedSelected [3,5,10,12,38] rootPS < 2^1333 := by decide +kernel

def env48915 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,9326,17525,31837,1025,32769,5157,21588,1141,42062,8192,65,10280,4097,17524,64604,68,42093,116,21589,46092,513]

theorem envBound48915 : H12AffineFastState.Bounded env48915 := by
  intro p hp
  have h : env48915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48914_48915 : H12AffineEnvironment.transform 7 117 env48914 = env48915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48914 == env48915) = true)

theorem identity48915 : scanCanonicalize (H12AffineFastState.compose env48915 (packedSelected [3,4,5,7,9,10,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound48915 : packedSelected [3,4,5,7,9,10,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env48916 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,1077,9326,17525,31837,1025,1076,5157,21588,1141,8315,8192,65,10280,4097,17524,30825,68,8280,116,21589,12345,513]

theorem envBound48916 : H12AffineFastState.Bounded env48916 := by
  intro p hp
  have h : env48916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48915_48916 : H12AffineEnvironment.transform 14 1077 env48915 = env48916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env48915 == env48916) = true)

theorem identity48916 : scanCanonicalize (H12AffineFastState.compose env48916 (packedSelected [2,6,11,12,15,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound48916 : packedSelected [2,6,11,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env48917 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,1077,9326,4097,10281,1025,1076,5157,32,1141,8315,8192,65,10280,4097,4096,11293,68,8280,116,33,12345,513]

theorem envBound48917 : H12AffineFastState.Bounded env48917 := by
  intro p hp
  have h : env48917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48916_48917 : H12AffineEnvironment.transform 13 5236 env48916 = env48917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env48916 == env48917) = true)

theorem identity48917 : scanCanonicalize (H12AffineFastState.compose env48917 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48917 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env48918 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,4112,81,8202,4097,10281,101,80,4161,32,17,8315,8192,65,10280,4097,4096,10361,68,8280,116,33,12345,513]

theorem envBound48918 : H12AffineFastState.Bounded env48918 := by
  intro p hp
  have h : env48918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48917_48918 : H12AffineEnvironment.transform 9 100 env48917 = env48918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48917 == env48918) = true)

theorem identity48918 : scanCanonicalize (H12AffineFastState.compose env48918 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound48918 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48919 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8,4112,81,2,4097,2081,101,80,4161,32,17,115,8,65,2080,4097,4096,2161,68,80,116,33,4145,513]

theorem envBound48919 : H12AffineFastState.Bounded env48919 := by
  intro p hp
  have h : env48919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48918_48919 : H12AffineEnvironment.transform 12 8 env48918 = env48919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env48918 == env48919) = true)

theorem identity48919 : scanCanonicalize (H12AffineFastState.compose env48919 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound48919 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48920 : List Nat := [2,4,8,16,32,64,8,117,512,100,608,4096,8,4112,81,2,4097,577,101,80,4161,32,17,115,8,65,576,4097,4096,529,68,80,116,33,4145,513]

theorem envBound48920 : H12AffineFastState.Bounded env48920 := by
  intro p hp
  have h : env48920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48919_48920 : H12AffineEnvironment.transform 10 608 env48919 = env48920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env48919 == env48920) = true)

theorem identity48920 : scanCanonicalize (H12AffineFastState.compose env48920 (packedSelected [5,6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48920 : packedSelected [5,6] rootPS < 2^1333 := by decide +kernel

def env48921 : List Nat := [2,4,8,16,10,64,8,95,512,78,586,4096,8,4112,81,2,4097,577,79,80,4161,10,17,89,8,65,576,4097,4096,529,68,80,94,11,4123,513]

theorem envBound48921 : H12AffineFastState.Bounded env48921 := by
  intro p hp
  have h : env48921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48920_48921 : H12AffineEnvironment.transform 4 10 env48920 = env48921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48920 == env48921) = true)

theorem identity48921 : scanCanonicalize (H12AffineFastState.compose env48921 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48921 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48922 : List Nat := [2,4,8,16,10,17,8,14,512,31,539,4096,8,4112,0,2,4097,528,30,1,4112,10,17,8,8,16,529,4097,4096,529,21,1,15,11,4123,513]

theorem envBound48922 : H12AffineFastState.Bounded env48922 := by
  intro p hp
  have h : env48922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48921_48922 : H12AffineEnvironment.transform 5 17 env48921 = env48922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48921 == env48922) = true)

theorem identity48922 : scanCanonicalize (H12AffineFastState.compose env48922 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound48922 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48923 : List Nat := [2,4,8,16,10,17,8,14,27,31,0,4096,8,4112,0,2,4097,11,30,1,4112,10,17,8,8,16,10,4097,4096,10,21,1,15,11,4123,26]

theorem envBound48923 : H12AffineFastState.Bounded env48923 := by
  intro p hp
  have h : env48923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48922_48923 : H12AffineEnvironment.transform 8 27 env48922 = env48923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env48922 == env48923) = true)

theorem identity48923 : scanCanonicalize (H12AffineFastState.compose env48923 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48924 : List Nat := [2,4,8,0,10,1,8,14,11,15,0,4096,8,4096,0,2,4097,11,14,1,4096,10,1,8,8,0,10,4097,4096,10,5,1,15,11,4107,10]

theorem envBound48924 : H12AffineFastState.Bounded env48924 := by
  intro p hp
  have h : env48924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48923_48924 : H12AffineEnvironment.transform 3 0 env48923 = env48924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48923 == env48924) = true)

theorem identity48924 : scanCanonicalize (H12AffineFastState.compose env48924 (packedSelected [3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48924 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env48925 : List Nat := [2,4,3,0,1,1,3,5,0,4,0,4096,3,4096,0,2,4097,0,5,1,4096,1,1,3,3,0,1,4097,4096,1,5,1,4,0,4096,1]

theorem envBound48925 : H12AffineFastState.Bounded env48925 := by
  intro p hp
  have h : env48925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48924_48925 : H12AffineEnvironment.transform 2 3 env48924 = env48925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48924 == env48925) = true)

def env48926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77899,21793,73755,98644,8193,65,215366,79130,17665,236851,75102,98678,257,21792,46093,513]

theorem envBound48926 : H12AffineFastState.Bounded env48926 := by
  intro p hp
  have h : env48926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48911_48926 : H12AffineEnvironment.transform 6 9 env48911 = env48926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48911 == env48926) = true)

theorem identity48926 : scanCanonicalize (H12AffineFastState.compose env48926 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48926 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1025,29789,77899,21793,73755,95496,8193,65,215366,79130,17665,223599,75102,95530,257,21792,16465,513]

theorem envBound48927 : H12AffineFastState.Bounded env48927 := by
  intro p hp
  have h : env48927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48926_48927 : H12AffineEnvironment.transform 14 29788 env48926 = env48927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48926 == env48927) = true)

theorem identity48927 : scanCanonicalize (H12AffineFastState.compose env48927 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound48927 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env48928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,131072,32041,1025,29789,17728,21793,21776,3,8193,65,146509,16401,17665,138340,20565,33,257,21792,16465,513]

theorem envBound48928 : H12AffineFastState.Bounded env48928 := by
  intro p hp
  have h : env48928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48927_48928 : H12AffineEnvironment.transform 15 29963 env48927 = env48928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env48927 == env48928) = true)

theorem identity48928 : scanCanonicalize (H12AffineFastState.compose env48928 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound48928 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,8283,131072,10361,1025,8461,4112,113,64,3,8193,65,146509,5441,4177,138340,1285,33,257,112,5377,513]

theorem envBound48929 : H12AffineFastState.Bounded env48929 := by
  intro p hp
  have h : env48929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48928_48929 : H12AffineEnvironment.transform 13 5456 env48928 = env48929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env48928 == env48929) = true)

theorem identity48929 : scanCanonicalize (H12AffineFastState.compose env48929 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48930 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10280,1025,8461,4112,32,17,3,8193,16,146460,5392,4096,138293,1285,33,257,33,5377,513]

theorem envBound48930 : H12AffineFastState.Bounded env48930 := by
  intro p hp
  have h : env48930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48929_48930 : H12AffineEnvironment.transform 5 17 env48929 = env48930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48929 == env48930) = true)

theorem identity48930 : scanCanonicalize (H12AffineFastState.compose env48930 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound48930 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48931 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,261,3,131072,2081,1025,260,4112,32,17,3,8,16,138261,5392,4096,138293,1285,33,257,33,5377,513]

theorem envBound48931 : H12AffineFastState.Bounded env48931 := by
  intro p hp
  have h : env48931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48930_48931 : H12AffineEnvironment.transform 12 9 env48930 = env48931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env48930 == env48931) = true)

theorem identity48931 : scanCanonicalize (H12AffineFastState.compose env48931 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound48931 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48932 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,261,3,5140,2081,1025,260,4112,32,17,3,8,16,2049,5392,4096,2081,1285,33,257,33,5377,513]

theorem envBound48932 : H12AffineFastState.Bounded env48932 := by
  intro p hp
  have h : env48932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48931_48932 : H12AffineEnvironment.transform 16 5140 env48931 = env48932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env48931 == env48932) = true)

theorem identity48932 : scanCanonicalize (H12AffineFastState.compose env48932 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound48932 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48933 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,4096,9,5377,261,3,5140,261,1025,260,4112,32,17,3,8,16,293,5392,4096,261,1285,33,257,33,5377,513]

theorem envBound48933 : H12AffineFastState.Bounded env48933 := by
  intro p hp
  have h : env48933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48932_48933 : H12AffineEnvironment.transform 10 292 env48932 = env48933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env48932 == env48933) = true)

theorem identity48933 : scanCanonicalize (H12AffineFastState.compose env48933 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound48933 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48934 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,276,9,1045,261,3,1280,261,1025,260,260,32,17,3,8,16,293,1028,276,261,1285,33,257,33,1045,513]

theorem envBound48934 : H12AffineFastState.Bounded env48934 := by
  intro p hp
  have h : env48934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48933_48934 : H12AffineEnvironment.transform 11 276 env48933 = env48934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env48933 == env48934) = true)

theorem identity48934 : scanCanonicalize (H12AffineFastState.compose env48934 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48934 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48935 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,16,9,1045,1,3,1028,1,1025,0,0,32,17,3,8,16,33,1028,16,1,1025,33,5,33,1045,513]

theorem envBound48935 : H12AffineFastState.Bounded env48935 := by
  intro p hp
  have h : env48935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48934_48935 : H12AffineEnvironment.transform 7 4 env48934 = env48935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48934 == env48935) = true)

theorem identity48935 : scanCanonicalize (H12AffineFastState.compose env48935 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48936 : List Nat := [2,4,8,16,0,17,9,4,512,1024,0,16,9,1045,1,3,1028,1,1025,0,0,0,17,3,8,16,1,1028,16,1,1025,1,5,1,1045,513]

theorem envBound48936 : H12AffineFastState.Bounded env48936 := by
  intro p hp
  have h : env48936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48935_48936 : H12AffineEnvironment.transform 4 0 env48935 = env48936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48935 == env48936) = true)

theorem identity48936 : scanCanonicalize (H12AffineFastState.compose env48936 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound48936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48937 : List Nat := [2,4,8,16,0,17,9,4,512,532,0,16,9,513,1,3,528,1,533,0,0,0,17,3,8,16,1,528,16,1,533,1,5,1,513,513]

theorem envBound48937 : H12AffineFastState.Bounded env48937 := by
  intro p hp
  have h : env48937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48936_48937 : H12AffineEnvironment.transform 9 532 env48936 = env48937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env48936 == env48937) = true)

theorem identity48937 : scanCanonicalize (H12AffineFastState.compose env48937 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48937 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48938 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,16,9,0,1,3,17,1,20,0,0,0,17,3,8,16,1,17,16,1,20,1,5,1,0,0]

theorem envBound48938 : H12AffineFastState.Bounded env48938 := by
  intro p hp
  have h : env48938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48937_48938 : H12AffineEnvironment.transform 8 1 env48937 = env48938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48937 == env48938) = true)

theorem identity48938 : scanCanonicalize (H12AffineFastState.compose env48938 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48939 : List Nat := [2,4,3,16,0,17,2,4,1,21,0,16,2,0,1,3,17,1,20,0,0,0,17,3,3,16,1,17,16,1,20,1,5,1,0,0]

theorem envBound48939 : H12AffineFastState.Bounded env48939 := by
  intro p hp
  have h : env48939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48938_48939 : H12AffineEnvironment.transform 2 3 env48938 = env48939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48938 == env48939) = true)

theorem identity48939 : scanCanonicalize (H12AffineFastState.compose env48939 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48939 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48940 : List Nat := [2,4,3,0,0,1,2,4,1,5,0,0,2,0,1,3,1,1,4,0,0,0,1,3,3,0,1,1,0,1,4,1,5,1,0,0]

theorem envBound48940 : H12AffineFastState.Bounded env48940 := by
  intro p hp
  have h : env48940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48939_48940 : H12AffineEnvironment.transform 3 0 env48939 = env48940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48939 == env48940) = true)

def env48941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98780,8328,65,12729468,79130,8480027,8568224,8390093,4314199,257,8484155,8492191,8462875]

theorem envBound48941 : H12AffineFastState.Bounded env48941 := by
  intro p hp
  have h : env48941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48876_48941 : H12AffineEnvironment.transform 17 32161 env48876 = env48941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env48876 == env48941) = true)

def env48942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98780,8328,65,8546652,79130,8480027,8568224,8390093,98679,257,8484155,8492191,8462875]

theorem envBound48942 : H12AffineFastState.Bounded env48942 := by
  intro p hp
  have h : env48942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48941_48942 : H12AffineEnvironment.transform 21 21792 env48941 = env48942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env48941 == env48942) = true)

theorem identity48942 : scanCanonicalize (H12AffineFastState.compose env48942 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound48942 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,120014,98780,8328,65,245138,79130,45525,223598,119043,98679,257,41461,16465,63189]

theorem envBound48943 : H12AffineFastState.Bounded env48943 := by
  intro p hp
  have h : env48943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48942_48943 : H12AffineEnvironment.transform 22 120014 env48942 = env48943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env48942 == env48943) = true)

def env48944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1025,32769,77898,32,98766,98780,8328,65,245138,79130,45525,212078,99331,98679,257,41461,5457,41941]

theorem envBound48944 : H12AffineFastState.Bounded env48944 := by
  intro p hp
  have h : env48944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48943_48944 : H12AffineEnvironment.transform 13 5376 env48943 = env48944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48943 == env48944) = true)

theorem identity48944 : scanCanonicalize (H12AffineFastState.compose env48944 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48944 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,77898,32,98631,98645,8193,65,245019,79130,45404,212078,99331,98679,257,41340,5457,41820]

theorem envBound48945 : H12AffineFastState.Bounded env48945 := by
  intro p hp
  have h : env48945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48944_48945 : H12AffineEnvironment.transform 6 9 env48944 = env48945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48944 == env48945) = true)

theorem identity48945 : scanCanonicalize (H12AffineFastState.compose env48945 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48945 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env48946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10280,1025,32769,4160,32,41293,41311,8193,65,171281,5392,45404,138340,41993,41341,257,41340,5457,41820]

theorem envBound48946 : H12AffineFastState.Bounded env48946 := by
  intro p hp
  have h : env48946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48945_48946 : H12AffineEnvironment.transform 15 8202 env48945 = env48946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48945 == env48946) = true)

theorem identity48946 : scanCanonicalize (H12AffineFastState.compose env48946 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound48946 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5425,10280,1025,32769,4160,32,41293,41311,8193,65,34848,5392,45404,2389,41993,41341,257,41340,5457,41820]

theorem envBound48947 : H12AffineFastState.Bounded env48947 := by
  intro p hp
  have h : env48947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48946_48947 : H12AffineEnvironment.transform 16 5425 env48946 = env48947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env48946 == env48947) = true)

theorem identity48947 : scanCanonicalize (H12AffineFastState.compose env48947 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8573) := by decide +kernel

theorem selectedBound48947 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8573,8202,5425,10280,1025,8572,4160,32,48,34,8193,65,10589,5392,4129,2389,1396,0,257,1,5457,545]

theorem envBound48948 : H12AffineFastState.Bounded env48948 := by
  intro p hp
  have h : env48948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48947_48948 : H12AffineEnvironment.transform 14 8573 env48947 = env48948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8573 env48947 == env48948) = true)

theorem identity48948 : scanCanonicalize (H12AffineFastState.compose env48948 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48948 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48949 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5392,10249,1025,8541,4160,1,17,3,8193,65,10589,5392,4096,2389,1365,0,257,1,5457,512]

theorem envBound48949 : H12AffineFastState.Bounded env48949 := by
  intro p hp
  have h : env48949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48948_48949 : H12AffineEnvironment.transform 4 1 env48948 = env48949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48948 == env48949) = true)

theorem identity48949 : scanCanonicalize (H12AffineFastState.compose env48949 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48949 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48950 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,5392,10249,1025,8461,4112,1,17,3,8193,17,10509,5392,4096,2309,1285,0,257,1,5377,512]

theorem envBound48950 : H12AffineFastState.Bounded env48950 := by
  intro p hp
  have h : env48950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48949_48950 : H12AffineEnvironment.transform 5 16 env48949 = env48950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48949 == env48950) = true)

theorem identity48950 : scanCanonicalize (H12AffineFastState.compose env48950 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48951 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5376,1,263,5392,2308,1025,0,4112,1,17,3,268,17,2048,5392,4096,2309,1285,0,257,1,5377,512]

theorem envBound48951 : H12AffineFastState.Bounded env48951 := by
  intro p hp
  have h : env48951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48950_48951 : H12AffineEnvironment.transform 12 269 env48950 = env48951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48950 == env48951) = true)

theorem identity48951 : scanCanonicalize (H12AffineFastState.compose env48951 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound48951 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48952 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1028,269,260,1,263,276,2308,1025,0,1044,1,17,3,268,17,2048,276,1028,2309,1285,0,257,1,261,512]

theorem envBound48952 : H12AffineFastState.Bounded env48952 := by
  intro p hp
  have h : env48952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48951_48952 : H12AffineEnvironment.transform 11 1028 env48951 = env48952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env48951 == env48952) = true)

theorem identity48952 : scanCanonicalize (H12AffineFastState.compose env48952 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound48952 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48953 : List Nat := [2,4,8,16,1,16,9,256,260,1024,2048,1028,269,260,1,263,276,2308,1025,0,1044,1,17,3,268,17,2048,276,1028,2309,1285,0,257,1,261,260]

theorem envBound48953 : H12AffineFastState.Bounded env48953 := by
  intro p hp
  have h : env48953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48952_48953 : H12AffineEnvironment.transform 8 260 env48952 = env48953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env48952 == env48953) = true)

theorem identity48953 : scanCanonicalize (H12AffineFastState.compose env48953 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound48953 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48954 : List Nat := [2,4,8,16,1,16,9,256,260,1024,1029,1028,269,260,1,263,276,1281,1025,0,1044,1,17,3,268,17,1029,276,1028,1280,1285,0,257,1,261,260]

theorem envBound48954 : H12AffineFastState.Bounded env48954 := by
  intro p hp
  have h : env48954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48953_48954 : H12AffineEnvironment.transform 10 1029 env48953 = env48954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env48953 == env48954) = true)

theorem identity48954 : scanCanonicalize (H12AffineFastState.compose env48954 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48954 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48955 : List Nat := [2,4,8,1,1,1,9,256,260,1024,1029,1028,269,260,1,263,261,1281,1025,0,1029,1,0,3,268,0,1029,261,1028,1280,1285,0,257,1,261,260]

theorem envBound48955 : H12AffineFastState.Bounded env48955 := by
  intro p hp
  have h : env48955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48954_48955 : H12AffineEnvironment.transform 3 1 env48954 = env48955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48954 == env48955) = true)

theorem identity48955 : scanCanonicalize (H12AffineFastState.compose env48955 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound48955 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48956 : List Nat := [2,4,8,1,1,1,9,256,260,257,260,261,269,260,1,263,261,0,256,0,260,1,0,3,268,0,260,261,261,1,4,0,257,1,261,260]

theorem envBound48956 : H12AffineFastState.Bounded env48956 := by
  intro p hp
  have h : env48956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48955_48956 : H12AffineEnvironment.transform 9 257 env48955 = env48956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env48955 == env48956) = true)

theorem identity48956 : scanCanonicalize (H12AffineFastState.compose env48956 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48956 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48957 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,1,9,0,1,3,1,0,4,0,0,1,0,3,8,0,0,1,1,1,4,0,5,1,1,0]

theorem envBound48957 : H12AffineFastState.Bounded env48957 := by
  intro p hp
  have h : env48957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48956_48957 : H12AffineEnvironment.transform 7 4 env48956 = env48957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48956 == env48957) = true)

theorem identity48957 : scanCanonicalize (H12AffineFastState.compose env48957 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48958 : List Nat := [2,0,8,1,1,1,9,0,0,1,0,1,9,0,1,3,1,0,0,0,0,1,0,3,8,0,0,1,1,1,0,0,1,1,1,0]

theorem envBound48958 : H12AffineFastState.Bounded env48958 := by
  intro p hp
  have h : env48958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48957_48958 : H12AffineEnvironment.transform 1 0 env48957 = env48958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48957 == env48958) = true)

def env48959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1025,32769,77898,33,98767,98780,8328,65,245138,79130,45525,212079,99330,98679,257,41461,5456,41940]

theorem envBound48959 : H12AffineFastState.Bounded env48959 := by
  intro p hp
  have h : env48959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48943_48959 : H12AffineEnvironment.transform 13 5377 env48943 = env48959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48943 == env48959) = true)

theorem identity48959 : scanCanonicalize (H12AffineFastState.compose env48959 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound48959 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,46276,10400,1025,32769,77898,33,98767,98780,8328,65,67926,79130,45525,100523,99330,98679,257,41461,5456,41940]

theorem envBound48960 : H12AffineFastState.Bounded env48960 := by
  intro p hp
  have h : env48960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48959_48960 : H12AffineEnvironment.transform 16 46276 env48959 = env48960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env48959 == env48960) = true)

theorem identity48960 : scanCanonicalize (H12AffineFastState.compose env48960 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48960 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env48961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,46276,10400,1025,32769,4161,33,41412,41431,8328,65,10589,5393,45525,43168,41993,41340,257,41461,5456,41940]

theorem envBound48961 : H12AffineFastState.Bounded env48961 := by
  intro p hp
  have h : env48961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48960_48961 : H12AffineEnvironment.transform 15 8203 env48960 = env48961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48960 == env48961) = true)

theorem identity48961 : scanCanonicalize (H12AffineFastState.compose env48961 (packedSelected [0,6,17,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48961 : packedSelected [0,6,17,27] rootPS < 2^1333 := by decide +kernel

def env48962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,5529,10400,1025,8540,4161,33,153,138,8328,65,10589,5393,4232,2557,1364,33,257,168,5456,649]

theorem envBound48962 : H12AffineFastState.Bounded env48962 := by
  intro p hp
  have h : env48962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48961_48962 : H12AffineEnvironment.transform 14 8541 env48961 = env48962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48961 == env48962) = true)

theorem identity48962 : scanCanonicalize (H12AffineFastState.compose env48962 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound48962 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,136,478,5529,2421,1025,137,4161,33,153,138,349,65,2184,5393,4232,2557,1364,33,257,168,5456,649]

theorem envBound48963 : H12AffineFastState.Bounded env48963 := by
  intro p hp
  have h : env48963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48962_48963 : H12AffineEnvironment.transform 12 469 env48962 = env48963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env48962 == env48963) = true)

theorem identity48963 : scanCanonicalize (H12AffineFastState.compose env48963 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48963 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env48964 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,469,4453,136,478,4605,2421,101,137,4161,33,153,138,349,65,2184,4469,4232,2557,304,33,257,168,4404,649]

theorem envBound48964 : H12AffineFastState.Bounded env48964 := by
  intro p hp
  have h : env48964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48963_48964 : H12AffineEnvironment.transform 9 100 env48963 = env48964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48963 == env48964) = true)

theorem identity48964 : scanCanonicalize (H12AffineFastState.compose env48964 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound48964 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env48965 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2248,469,2477,136,478,2357,2421,101,137,2185,33,153,138,349,65,2184,2493,2112,2557,304,33,257,168,2556,649]

theorem envBound48965 : H12AffineFastState.Bounded env48965 := by
  intro p hp
  have h : env48965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48964_48965 : H12AffineEnvironment.transform 11 2248 env48964 = env48965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env48964 == env48965) = true)

theorem identity48965 : scanCanonicalize (H12AffineFastState.compose env48965 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound48965 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env48966 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,2248,121,2049,136,114,2201,2265,101,137,2185,33,153,138,241,65,2184,2065,2112,2129,156,33,173,168,2128,649]

theorem envBound48966 : H12AffineFastState.Bounded env48966 := by
  intro p hp
  have h : env48966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48965_48966 : H12AffineEnvironment.transform 7 172 env48965 = env48966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48965 == env48966) = true)

theorem identity48966 : scanCanonicalize (H12AffineFastState.compose env48966 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound48966 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env48967 : List Nat := [2,4,8,16,32,64,128,172,512,100,137,65,121,136,136,114,16,80,101,137,0,33,153,138,241,65,1,152,201,216,156,33,173,168,217,649]

theorem envBound48967 : H12AffineFastState.Bounded env48967 := by
  intro p hp
  have h : env48967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48966_48967 : H12AffineEnvironment.transform 10 137 env48966 = env48967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env48966 == env48967) = true)

theorem identity48967 : scanCanonicalize (H12AffineFastState.compose env48967 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48967 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48968 : List Nat := [2,4,8,16,32,16,128,172,512,52,137,17,41,136,136,34,16,0,53,137,0,33,153,138,161,17,1,152,153,136,156,33,173,168,137,649]

theorem envBound48968 : H12AffineFastState.Bounded env48968 := by
  intro p hp
  have h : env48968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48967_48968 : H12AffineEnvironment.transform 5 16 env48967 = env48968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48967 == env48968) = true)

theorem identity48968 : scanCanonicalize (H12AffineFastState.compose env48968 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48968 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env48969 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,0,0,34,16,0,53,1,0,33,17,2,41,17,1,16,17,0,20,33,37,32,1,513]

theorem envBound48969 : H12AffineFastState.Bounded env48969 := by
  intro p hp
  have h : env48969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48968_48969 : H12AffineEnvironment.transform 6 8 env48968 = env48969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48968 == env48969) = true)

theorem identity48969 : scanCanonicalize (H12AffineFastState.compose env48969 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound48969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48970 : List Nat := [2,4,8,16,32,16,8,36,17,52,1,17,41,0,0,34,16,0,53,1,0,33,17,2,41,17,1,16,17,0,20,33,37,32,1,16]

theorem envBound48970 : H12AffineFastState.Bounded env48970 := by
  intro p hp
  have h : env48970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48969_48970 : H12AffineEnvironment.transform 8 17 env48969 = env48970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env48969 == env48970) = true)

theorem identity48970 : scanCanonicalize (H12AffineFastState.compose env48970 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48971 : List Nat := [2,4,8,16,11,16,8,15,17,31,1,17,2,0,0,9,16,0,30,1,0,10,17,2,2,17,1,16,17,0,20,10,14,11,1,16]

theorem envBound48971 : H12AffineFastState.Bounded env48971 := by
  intro p hp
  have h : env48971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48970_48971 : H12AffineEnvironment.transform 4 11 env48970 = env48971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48970 == env48971) = true)

theorem identity48971 : scanCanonicalize (H12AffineFastState.compose env48971 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48971 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48972 : List Nat := [2,4,8,1,11,1,8,15,0,14,1,0,2,0,0,9,1,0,15,1,0,10,0,2,2,0,1,1,0,0,5,10,14,11,1,1]

theorem envBound48972 : H12AffineFastState.Bounded env48972 := by
  intro p hp
  have h : env48972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48971_48972 : H12AffineEnvironment.transform 3 1 env48971 = env48972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48971 == env48972) = true)

def env48973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98780,8328,65,8546653,79130,8480027,8568224,8390093,98678,257,8484155,8492191,8462875]

theorem envBound48973 : H12AffineFastState.Bounded env48973 := by
  intro p hp
  have h : env48973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48941_48973 : H12AffineEnvironment.transform 21 21793 env48941 = env48973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env48941 == env48973) = true)

theorem identity48973 : scanCanonicalize (H12AffineFastState.compose env48973 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound48973 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32161,1025,32769,58517,21793,8388608,21763,8328,65,8546653,57797,8434116,8568224,8390093,21929,257,8430052,8405056,8451780]

theorem envBound48974 : H12AffineFastState.Bounded env48974 := by
  intro p hp
  have h : env48974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48973_48974 : H12AffineEnvironment.transform 15 54495 env48973 = env48974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env48973 == env48974) = true)

def env48975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58397,21793,8388608,21763,8192,65,8546653,57677,8433996,8568104,8389957,21793,257,8429932,8405056,8451660]

theorem envBound48975 : H12AffineFastState.Bounded env48975 := by
  intro p hp
  have h : env48975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48974_48975 : H12AffineEnvironment.transform 6 8 env48974 = env48975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48974 == env48975) = true)

theorem identity48975 : scanCanonicalize (H12AffineFastState.compose env48975 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 147457) := by decide +kernel

theorem selectedBound48975 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58397,21793,147457,21763,8192,65,10588,57677,192845,64809,148804,21793,257,188781,131137,177741]

theorem envBound48976 : H12AffineFastState.Bounded env48976 := by
  intro p hp
  have h : env48976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48975_48976 : H12AffineEnvironment.transform 22 147457 env48975 = env48976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env48975 == env48976) = true)

theorem identity48976 : scanCanonicalize (H12AffineFastState.compose env48976 (packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48976 : packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env48977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,32041,1025,8541,17729,21793,147457,21763,8192,65,10588,16401,151569,23669,148804,21793,257,147505,131137,136977]

theorem envBound48977 : H12AffineFastState.Bounded env48977 := by
  intro p hp
  have h : env48977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48976_48977 : H12AffineEnvironment.transform 14 8540 env48976 = env48977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48976 == env48977) = true)

theorem identity48977 : scanCanonicalize (H12AffineFastState.compose env48977 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48977 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,5392,32041,1025,8541,17729,21793,21777,21763,8192,65,10588,16401,17665,23669,20564,21793,257,21793,5457,513]

theorem envBound48978 : H12AffineFastState.Bounded env48978 := by
  intro p hp
  have h : env48978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48977_48978 : H12AffineEnvironment.transform 16 5392 env48977 = env48978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48977 == env48978) = true)

theorem identity48978 : scanCanonicalize (H12AffineFastState.compose env48978 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound48978 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1297,20806,5392,22884,1025,1296,17729,21793,21777,21763,1101,65,3345,16401,17665,23669,20564,21793,257,21793,5457,513]

theorem envBound48979 : H12AffineFastState.Bounded env48979 := by
  intro p hp
  have h : env48979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48978_48979 : H12AffineEnvironment.transform 12 1101 env48978 = env48979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env48978 == env48979) = true)

theorem identity48979 : scanCanonicalize (H12AffineFastState.compose env48979 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48979 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1297,1094,5392,3172,1025,1296,4161,33,17,3,1101,65,3345,5393,4097,2421,1364,33,257,33,5457,513]

theorem envBound48980 : H12AffineFastState.Bounded env48980 := by
  intro p hp
  have h : env48980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48979_48980 : H12AffineEnvironment.transform 13 5376 env48979 = env48980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48979 == env48980) = true)

theorem identity48980 : scanCanonicalize (H12AffineFastState.compose env48980 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound48980 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48981 : List Nat := [2,4,8,16,32,64,8,256,512,801,2048,4096,876,4641,560,871,4657,2885,800,561,4161,33,17,3,876,65,2608,4656,4097,2421,629,33,257,33,4720,513]

theorem envBound48981 : H12AffineFastState.Bounded env48981 := by
  intro p hp
  have h : env48981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48980_48981 : H12AffineEnvironment.transform 9 801 env48980 = env48981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env48980 == env48981) = true)

theorem identity48981 : scanCanonicalize (H12AffineFastState.compose env48981 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48981 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48982 : List Nat := [2,4,8,16,32,64,8,256,49,272,2048,4096,349,4112,1,342,4096,2420,273,0,4161,33,17,3,349,65,2049,4097,4097,2421,68,33,257,33,4161,48]

theorem envBound48982 : H12AffineFastState.Bounded env48982 := by
  intro p hp
  have h : env48982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48981_48982 : H12AffineEnvironment.transform 8 49 env48981 = env48982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48981 == env48982) = true)

theorem identity48982 : scanCanonicalize (H12AffineFastState.compose env48982 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48982 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48983 : List Nat := [2,4,8,16,32,64,8,20,49,4,2048,4096,73,4112,1,66,4096,2144,5,0,4161,33,17,3,73,65,2049,4097,4097,2145,68,33,21,33,4161,48]

theorem envBound48983 : H12AffineFastState.Bounded env48983 := by
  intro p hp
  have h : env48983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48982_48983 : H12AffineEnvironment.transform 7 20 env48982 = env48983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48982 == env48983) = true)

theorem identity48983 : scanCanonicalize (H12AffineFastState.compose env48983 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound48983 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48984 : List Nat := [2,4,8,16,32,64,8,20,49,4,2048,1,73,17,1,66,1,2144,5,0,64,33,17,3,73,65,2049,0,0,2145,68,33,21,33,64,48]

theorem envBound48984 : H12AffineFastState.Bounded env48984 := by
  intro p hp
  have h : env48984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48983_48984 : H12AffineEnvironment.transform 11 1 env48983 = env48984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env48983 == env48984) = true)

theorem identity48984 : scanCanonicalize (H12AffineFastState.compose env48984 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48984 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env48985 : List Nat := [2,4,8,16,1,64,8,20,16,4,2048,1,73,17,1,66,1,2113,5,0,64,0,17,3,73,65,2049,0,0,2112,68,0,21,0,64,17]

theorem envBound48985 : H12AffineFastState.Bounded env48985 := by
  intro p hp
  have h : env48985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48984_48985 : H12AffineEnvironment.transform 4 1 env48984 = env48985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48984 == env48985) = true)

theorem identity48985 : scanCanonicalize (H12AffineFastState.compose env48985 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48985 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env48986 : List Nat := [2,4,8,16,1,16,8,20,16,4,2048,1,25,17,1,18,1,2065,5,0,16,0,17,3,25,17,2049,0,0,2064,20,0,21,0,16,17]

theorem envBound48986 : H12AffineFastState.Bounded env48986 := by
  intro p hp
  have h : env48986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48985_48986 : H12AffineEnvironment.transform 5 16 env48985 = env48986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48985 == env48986) = true)

theorem identity48986 : scanCanonicalize (H12AffineFastState.compose env48986 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48987 : List Nat := [2,4,8,16,1,16,8,20,16,4,0,1,25,17,1,18,1,17,5,0,16,0,17,3,25,17,1,0,0,16,20,0,21,0,16,17]

theorem envBound48987 : H12AffineFastState.Bounded env48987 := by
  intro p hp
  have h : env48987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48986_48987 : H12AffineEnvironment.transform 10 0 env48986 = env48987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48986 == env48987) = true)

def env48988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58396,21793,8388608,21763,8193,65,8546653,57676,8433997,8568105,8389956,21792,257,8429933,8405056,8451661]

theorem envBound48988 : H12AffineFastState.Bounded env48988 := by
  intro p hp
  have h : env48988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48974_48988 : H12AffineEnvironment.transform 6 9 env48974 = env48988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48974 == env48988) = true)

theorem identity48988 : scanCanonicalize (H12AffineFastState.compose env48988 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 62540) := by decide +kernel

theorem selectedBound48988 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58396,21793,62540,21763,8193,65,171281,57676,17665,149861,61704,21792,257,21793,46092,513]

theorem envBound48989 : H12AffineFastState.Bounded env48989 := by
  intro p hp
  have h : env48989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48988_48989 : H12AffineEnvironment.transform 22 62540 env48988 = env48989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env48988 == env48989) = true)

theorem identity48989 : scanCanonicalize (H12AffineFastState.compose env48989 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48989 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env48990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,5392,32040,1025,32769,58396,21793,62540,21763,8193,65,34817,57676,17665,23669,61704,21792,257,21793,46092,513]

theorem envBound48990 : H12AffineFastState.Bounded env48990 := by
  intro p hp
  have h : env48990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48989_48990 : H12AffineEnvironment.transform 16 5392 env48989 = env48990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48989 == env48990) = true)

theorem identity48990 : scanCanonicalize (H12AffineFastState.compose env48990 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound48990 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env48991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,5392,32040,1025,29788,4161,21793,17,21763,8193,65,31836,5393,17665,23669,1365,21792,257,21793,16465,513]

theorem envBound48991 : H12AffineFastState.Bounded env48991 := by
  intro p hp
  have h : env48991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48990_48991 : H12AffineEnvironment.transform 14 29789 env48990 = env48991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env48990 == env48991) = true)

theorem identity48991 : scanCanonicalize (H12AffineFastState.compose env48991 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48991 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1025,8541,4161,32,17,2,8193,65,10589,5393,4096,2420,1365,33,257,32,5456,513]

theorem envBound48992 : H12AffineFastState.Bounded env48992 := by
  intro p hp
  have h : env48992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48991_48992 : H12AffineEnvironment.transform 13 5377 env48991 = env48992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48991 == env48992) = true)

theorem identity48992 : scanCanonicalize (H12AffineFastState.compose env48992 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48992 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2420,1025,0,4161,32,17,2,348,65,2048,5393,4096,2420,1365,33,257,32,5456,513]

theorem envBound48993 : H12AffineFastState.Bounded env48993 := by
  intro p hp
  have h : env48993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48992_48993 : H12AffineEnvironment.transform 12 349 env48992 = env48993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48992 == env48993) = true)

theorem identity48993 : scanCanonicalize (H12AffineFastState.compose env48993 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound48993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1818,4096,349,5377,1,342,5392,1646,1025,0,4161,32,17,2,348,65,1818,5393,4096,1646,1365,33,257,32,5456,513]

theorem envBound48994 : H12AffineFastState.Bounded env48994 := by
  intro p hp
  have h : env48994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48993_48994 : H12AffineEnvironment.transform 10 1818 env48993 = env48994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env48993 == env48994) = true)

theorem identity48994 : scanCanonicalize (H12AffineFastState.compose env48994 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound48994 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48995 : List Nat := [2,4,8,16,32,64,9,256,512,101,895,4096,349,4452,1,342,4469,523,100,0,4161,32,17,2,348,65,895,4468,4096,523,304,33,257,32,4405,513]

theorem envBound48995 : H12AffineFastState.Bounded env48995 := by
  intro p hp
  have h : env48995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48994_48995 : H12AffineEnvironment.transform 9 101 env48994 = env48995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env48994 == env48995) = true)

theorem identity48995 : scanCanonicalize (H12AffineFastState.compose env48995 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 618) := by decide +kernel

theorem selectedBound48995 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env48996 : List Nat := [2,4,8,16,32,64,9,256,512,101,895,618,349,782,1,342,799,523,100,0,555,32,17,2,348,65,895,798,618,523,304,33,257,32,863,513]

theorem envBound48996 : H12AffineFastState.Bounded env48996 := by
  intro p hp
  have h : env48996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48995_48996 : H12AffineEnvironment.transform 11 618 env48995 = env48996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 618 env48995 == env48996) = true)

theorem identity48996 : scanCanonicalize (H12AffineFastState.compose env48996 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound48996 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48997 : List Nat := [2,4,8,16,32,64,9,84,512,101,555,618,9,602,1,2,587,523,100,0,555,32,17,2,8,65,555,586,618,523,100,33,85,32,523,513]

theorem envBound48997 : H12AffineFastState.Bounded env48997 := by
  intro p hp
  have h : env48997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48996_48997 : H12AffineEnvironment.transform 7 84 env48996 = env48997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env48996 == env48997) = true)

theorem identity48997 : scanCanonicalize (H12AffineFastState.compose env48997 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound48997 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48998 : List Nat := [2,4,8,16,32,42,9,62,512,15,555,512,9,560,1,2,545,523,14,0,555,32,17,2,8,43,555,544,512,523,14,33,63,32,523,513]

theorem envBound48998 : H12AffineFastState.Bounded env48998 := by
  intro p hp
  have h : env48998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48997_48998 : H12AffineEnvironment.transform 5 42 env48997 = env48998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env48997 == env48998) = true)

theorem identity48998 : scanCanonicalize (H12AffineFastState.compose env48998 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48998 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env48999 : List Nat := [2,4,8,7,32,42,9,41,512,15,555,512,9,551,1,2,545,523,14,0,555,32,6,2,8,43,555,544,512,523,14,33,40,32,523,513]

theorem envBound48999 : H12AffineFastState.Bounded env48999 := by
  intro p hp
  have h : env48999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48998_48999 : H12AffineEnvironment.transform 3 7 env48998 = env48999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48998 == env48999) = true)

theorem identity48999 : scanCanonicalize (H12AffineFastState.compose env48999 (packedSelected [1,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48999 : packedSelected [1,4,10] rootPS < 2^1333 := by decide +kernel

def env49000 : List Nat := [2,4,8,7,1,11,9,8,512,15,522,512,9,518,1,2,512,523,14,0,522,1,6,2,8,10,522,513,512,523,14,0,9,1,523,513]

theorem envBound49000 : H12AffineFastState.Bounded env49000 := by
  intro p hp
  have h : env49000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48999_49000 : H12AffineEnvironment.transform 4 1 env48999 = env49000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48999 == env49000) = true)

theorem identity49000 : scanCanonicalize (H12AffineFastState.compose env49000 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound49000 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49001 : List Nat := [2,4,8,7,1,11,9,8,6,15,12,6,9,0,1,2,6,13,14,0,12,1,6,2,8,10,12,7,6,13,14,0,9,1,13,7]

theorem envBound49001 : H12AffineFastState.Bounded env49001 := by
  intro p hp
  have h : env49001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49000_49001 : H12AffineEnvironment.transform 8 6 env49000 = env49001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env49000 == env49001) = true)

theorem identity49001 : scanCanonicalize (H12AffineFastState.compose env49001 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound49001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49002 : List Nat := [2,4,0,7,1,3,1,0,6,7,4,6,1,0,1,2,6,5,6,0,4,1,6,2,0,2,4,7,6,5,6,0,1,1,5,7]

theorem envBound49002 : H12AffineFastState.Bounded env49002 := by
  intro p hp
  have h : env49002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49001_49002 : H12AffineEnvironment.transform 2 0 env49001 = env49002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env49001 == env49002) = true)

theorem identity49002 : scanCanonicalize (H12AffineFastState.compose env49002 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49002 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49003 : List Nat := [0,4,0,5,1,1,1,0,4,5,4,4,1,0,1,0,4,5,4,0,4,1,4,0,0,0,4,5,4,5,4,0,1,1,5,5]

theorem envBound49003 : H12AffineFastState.Bounded env49003 := by
  intro p hp
  have h : env49003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49002_49003 : H12AffineEnvironment.transform 0 0 env49002 = env49003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49002 == env49003) = true)

def env49004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound49004 : H12AffineFastState.Bounded env49004 := by
  intro p hp
  have h : env49004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48554_49004 : H12AffineEnvironment.transform 26 30393345 env48554 = env49004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env48554 == env49004) = true)

def env49005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound49005 : H12AffineFastState.Bounded env49005 := by
  intro p hp
  have h : env49005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49004_49005 : H12AffineEnvironment.transform 18 1024 env49004 = env49005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49004 == env49005) = true)

theorem identity49005 : scanCanonicalize (H12AffineFastState.compose env49005 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 510123) := by decide +kernel

theorem selectedBound49005 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,510123,16777216,8328,65,20973738,18973837,2596346,67754,17190074,23160256,256,19270662,19328418,17263469]

theorem envBound49006 : H12AffineFastState.Bounded env49006 := by
  intro p hp
  have h : env49006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49005_49006 : H12AffineEnvironment.transform 22 510123 env49005 = env49006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 510123 env49005 == env49006) = true)

def env49007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,16777216,8328,65,16959642,18973837,2596346,67754,17190074,19113456,256,19270662,19328418,17263469]

theorem envBound49007 : H12AffineFastState.Bounded env49007 := by
  intro p hp
  have h : env49007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49006_49007 : H12AffineEnvironment.transform 21 180272 env49006 = env49007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env49006 == env49007) = true)

def env49008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,499128,8328,65,349474,2496821,2596346,67754,119042,2373704,256,2199998,2191386,63189]

theorem envBound49008 : H12AffineFastState.Bounded env49008 := by
  intro p hp
  have h : env49008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49007_49008 : H12AffineEnvironment.transform 23 499128 env49007 = env49008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env49007 == env49008) = true)

def env49009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510123,499128,8328,65,349474,395637,495034,67754,119042,272392,256,98814,90202,63189]

theorem envBound49009 : H12AffineFastState.Bounded env49009 := by
  intro p hp
  have h : env49009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49008_49009 : H12AffineEnvironment.transform 20 4160 env49008 = env49009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49008 == env49009) = true)

theorem identity49009 : scanCanonicalize (H12AffineFastState.compose env49009 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound49009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180272,120015,98780,8328,65,215366,5393,102878,67754,119042,144492,256,98814,90202,63189]

theorem envBound49010 : H12AffineFastState.Bounded env49010 := by
  intro p hp
  have h : env49010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49009_49010 : H12AffineEnvironment.transform 17 138340 env49009 = env49010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env49009 == env49010) = true)

def env49011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180272,119879,98644,8192,65,215366,5393,102742,67618,119042,144492,256,98678,90202,63069]

theorem envBound49011 : H12AffineFastState.Bounded env49011 := by
  intro p hp
  have h : env49011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49010_49011 : H12AffineEnvironment.transform 6 8 env49010 = env49011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49010 == env49011) = true)

theorem identity49011 : scanCanonicalize (H12AffineFastState.compose env49011 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound49011 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env49012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29822,131072,138340,1024,32769,4160,180272,41017,62762,8192,65,146744,5393,58664,31836,42364,144492,256,62728,5156,63069]

theorem envBound49012 : H12AffineFastState.Bounded env49012 := by
  intro p hp
  have h : env49012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49011_49012 : H12AffineEnvironment.transform 15 29822 env49011 = env49012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env49011 == env49012) = true)

theorem identity49012 : scanCanonicalize (H12AffineFastState.compose env49012 (packedSelected [1,2,4,5,6,8,14,19,20,22,23,24,26,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49012 : packedSelected [1,2,4,5,6,8,14,19,20,22,23,24,26,32,35] rootPS < 2^1333 := by decide +kernel

def env49013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,29822,131072,138340,1024,1,4160,147504,8249,29994,8192,65,146744,5393,25896,31836,9596,144492,256,29960,5156,30301]

theorem envBound49013 : H12AffineFastState.Bounded env49013 := by
  intro p hp
  have h : env49013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49012_49013 : H12AffineEnvironment.transform 14 0 env49012 = env49013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49012 == env49013) = true)

theorem identity49013 : scanCanonicalize (H12AffineFastState.compose env49013 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49013 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env49014 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,0,29822,131072,138340,1024,1,4160,147504,8249,29790,8192,65,146508,5221,25692,31836,9224,144492,116,29820,5156,30301]

theorem envBound49014 : H12AffineFastState.Bounded env49014 := by
  intro p hp
  have h : env49014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49013_49014 : H12AffineEnvironment.transform 7 116 env49013 = env49014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49013 == env49014) = true)

theorem identity49014 : scanCanonicalize (H12AffineFastState.compose env49014 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49014 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env49015 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,0,21590,131072,138340,1024,1,4160,147504,17,21622,40,65,138340,5221,17524,23668,1056,136260,116,21588,5156,22133]

theorem envBound49015 : H12AffineFastState.Bounded env49015 := by
  intro p hp
  have h : env49015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49014_49015 : H12AffineEnvironment.transform 12 40 env49014 = env49015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49014 == env49015) = true)

theorem identity49015 : scanCanonicalize (H12AffineFastState.compose env49015 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound49015 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49016 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,0,21590,16401,23669,1024,1,4160,33,17,21622,40,65,23669,5221,17524,23668,1056,21589,116,21588,5156,22133]

theorem envBound49016 : H12AffineFastState.Bounded env49016 := by
  intro p hp
  have h : env49016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49015_49016 : H12AffineEnvironment.transform 16 16401 env49015 = env49016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49015 == env49016) = true)

theorem identity49016 : scanCanonicalize (H12AffineFastState.compose env49016 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound49016 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49017 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,2048,0,7254,2065,5237,1024,1,4160,33,17,7286,40,65,5237,5221,3188,5236,1056,7253,116,7252,5156,7797]

theorem envBound49017 : H12AffineFastState.Bounded env49017 := by
  intro p hp
  have h : env49017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49016_49017 : H12AffineEnvironment.transform 13 2048 env49016 = env49017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env49016 == env49017) = true)

theorem identity49017 : scanCanonicalize (H12AffineFastState.compose env49017 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound49017 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49018 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,40,2048,0,35,2065,2048,1024,1,3125,33,17,3,40,65,2048,2064,3188,2049,1056,32,116,33,2129,512]

theorem envBound49018 : H12AffineFastState.Bounded env49018 := by
  intro p hp
  have h : env49018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49017_49018 : H12AffineEnvironment.transform 11 3189 env49017 = env49018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env49017 == env49018) = true)

theorem identity49018 : scanCanonicalize (H12AffineFastState.compose env49018 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 625) := by decide +kernel

theorem selectedBound49018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49019 : List Nat := [2,4,8,16,32,64,8,116,512,1024,625,1540,40,625,0,35,608,625,1024,1,1604,33,17,3,40,65,625,609,1541,624,1056,32,116,33,544,512]

theorem envBound49019 : H12AffineFastState.Bounded env49019 := by
  intro p hp
  have h : env49019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49018_49019 : H12AffineEnvironment.transform 10 625 env49018 = env49019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 625 env49018 == env49019) = true)

theorem identity49019 : scanCanonicalize (H12AffineFastState.compose env49019 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49019 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env49020 : List Nat := [2,4,8,16,32,48,8,4,512,1024,513,1540,40,513,0,35,528,513,1024,1,1588,33,17,3,40,49,513,529,1541,512,1056,32,4,33,544,512]

theorem envBound49020 : H12AffineFastState.Bounded env49020 := by
  intro p hp
  have h : env49020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49019_49020 : H12AffineEnvironment.transform 5 48 env49019 = env49020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49019 == env49020) = true)

def env49021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180272,119878,98645,8193,65,215366,5393,102743,67619,119042,144492,256,98679,90202,63068]

theorem envBound49021 : H12AffineFastState.Bounded env49021 := by
  intro p hp
  have h : env49021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49010_49021 : H12AffineEnvironment.transform 6 9 env49010 = env49021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49010 == env49021) = true)

theorem identity49021 : scanCanonicalize (H12AffineFastState.compose env49021 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49021 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env49022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138340,1024,32769,4160,169265,98631,98645,8193,65,203847,5393,102743,67619,99331,144492,256,98679,79195,41821]

theorem envBound49022 : H12AffineFastState.Bounded env49022 := by
  intro p hp
  have h : env49022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49021_49022 : H12AffineEnvironment.transform 13 5377 env49021 = env49022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49021 == env49022) = true)

theorem identity49022 : scanCanonicalize (H12AffineFastState.compose env49022 (packedSelected [0,1,3,7,8,9,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound49022 : packedSelected [0,1,3,7,8,9,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env49023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103495,100387,1024,32769,4160,65910,98631,98645,8193,65,34816,5393,102743,67619,99331,106539,256,98679,79195,41821]

theorem envBound49023 : H12AffineFastState.Bounded env49023 := by
  intro p hp
  have h : env49023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49022_49023 : H12AffineEnvironment.transform 16 103495 env49022 = env49023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env49022 == env49023) = true)

theorem identity49023 : scanCanonicalize (H12AffineFastState.compose env49023 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound49023 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env49024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5393,2421,1024,32769,4160,32800,17,3,8193,65,34816,5393,4097,35189,1365,8573,256,33,46093,41821]

theorem envBound49024 : H12AffineFastState.Bounded env49024 := by
  intro p hp
  have h : env49024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49023_49024 : H12AffineEnvironment.transform 15 33110 env49023 = env49024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env49023 == env49024) = true)

theorem identity49024 : scanCanonicalize (H12AffineFastState.compose env49024 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49024 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,33110,5393,2421,1024,32769,4160,32800,17,3,348,65,34816,5393,4097,35189,1365,32,256,33,38224,33280]

theorem envBound49025 : H12AffineFastState.Bounded env49025 := by
  intro p hp
  have h : env49025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49024_49025 : H12AffineEnvironment.transform 12 349 env49024 = env49025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49024 == env49025) = true)

theorem identity49025 : scanCanonicalize (H12AffineFastState.compose env49025 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49025 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5393,2421,1024,1,4160,32,17,3,348,65,2048,5393,4097,2421,1365,32,256,33,5456,512]

theorem envBound49026 : H12AffineFastState.Bounded env49026 := by
  intro p hp
  have h : env49026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49025_49026 : H12AffineEnvironment.transform 14 0 env49025 = env49026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49025 == env49026) = true)

theorem identity49026 : scanCanonicalize (H12AffineFastState.compose env49026 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1899) := by decide +kernel

theorem selectedBound49026 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1899,4096,349,5377,0,342,5393,1566,1024,1,4160,32,17,3,348,65,1899,5393,4097,1566,1365,32,256,33,5456,512]

theorem envBound49027 : H12AffineFastState.Bounded env49027 := by
  intro p hp
  have h : env49027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49026_49027 : H12AffineEnvironment.transform 10 1899 env49026 = env49027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1899 env49026 == env49027) = true)

theorem identity49027 : scanCanonicalize (H12AffineFastState.compose env49027 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49027 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49028 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1819,4096,301,5377,0,294,5393,1566,1024,1,4144,32,17,3,300,49,1819,5393,4097,1566,1317,32,256,33,5408,512]

theorem envBound49028 : H12AffineFastState.Bounded env49028 := by
  intro p hp
  have h : env49028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49027_49028 : H12AffineEnvironment.transform 5 48 env49027 = env49028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49027 == env49028) = true)

theorem identity49028 : scanCanonicalize (H12AffineFastState.compose env49028 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49028 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49029 : List Nat := [2,4,8,16,32,48,9,256,512,52,815,4096,301,4405,0,294,4389,554,52,1,4144,32,17,3,300,49,815,4389,4097,554,273,32,256,33,4372,512]

theorem envBound49029 : H12AffineFastState.Bounded env49029 := by
  intro p hp
  have h : env49029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49028_49029 : H12AffineEnvironment.transform 9 52 env49028 = env49029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49028 == env49029) = true)

theorem identity49029 : scanCanonicalize (H12AffineFastState.compose env49029 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound49029 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env49030 : List Nat := [2,4,8,16,32,48,9,256,512,52,815,538,301,815,0,294,831,554,52,1,554,32,17,3,300,49,815,831,539,554,273,32,256,33,782,512]

theorem envBound49030 : H12AffineFastState.Bounded env49030 := by
  intro p hp
  have h : env49030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49029_49030 : H12AffineEnvironment.transform 11 538 env49029 = env49030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env49029 == env49030) = true)

theorem identity49030 : scanCanonicalize (H12AffineFastState.compose env49030 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49030 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env49031 : List Nat := [2,4,8,16,32,48,9,256,43,52,260,49,301,260,0,294,276,1,52,1,1,32,17,3,300,49,260,276,48,1,273,32,256,33,293,43]

theorem envBound49031 : H12AffineFastState.Bounded env49031 := by
  intro p hp
  have h : env49031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49030_49031 : H12AffineEnvironment.transform 8 43 env49030 = env49031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49030 == env49031) = true)

theorem identity49031 : scanCanonicalize (H12AffineFastState.compose env49031 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49031 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49032 : List Nat := [2,4,8,16,32,48,9,4,43,52,0,49,41,0,0,34,16,1,52,1,1,32,17,3,40,49,0,16,48,1,21,32,4,33,33,43]

theorem envBound49032 : H12AffineFastState.Bounded env49032 := by
  intro p hp
  have h : env49032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49031_49032 : H12AffineEnvironment.transform 7 4 env49031 = env49032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49031 == env49032) = true)

theorem identity49032 : scanCanonicalize (H12AffineFastState.compose env49032 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound49032 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49033 : List Nat := [2,4,8,4,32,36,9,4,43,32,0,37,41,0,0,34,4,1,32,1,1,32,5,3,40,37,0,4,36,1,1,32,4,33,33,43]

theorem envBound49033 : H12AffineFastState.Bounded env49033 := by
  intro p hp
  have h : env49033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49032_49033 : H12AffineEnvironment.transform 3 4 env49032 = env49033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env49032 == env49033) = true)

theorem identity49033 : scanCanonicalize (H12AffineFastState.compose env49033 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49034 : List Nat := [0,4,8,4,32,36,9,4,41,32,0,37,41,0,0,32,4,1,32,1,1,32,5,1,40,37,0,4,36,1,1,32,4,33,33,41]

theorem envBound49034 : H12AffineFastState.Bounded env49034 := by
  intro p hp
  have h : env49034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49033_49034 : H12AffineEnvironment.transform 0 0 env49033 = env49034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49033 == env49034) = true)

theorem identity49034 : scanCanonicalize (H12AffineFastState.compose env49034 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49035 : List Nat := [0,4,8,4,1,5,9,4,8,1,0,4,8,0,0,1,4,1,1,1,1,1,5,1,9,4,0,4,5,1,1,1,4,0,0,8]

theorem envBound49035 : H12AffineFastState.Bounded env49035 := by
  intro p hp
  have h : env49035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49034_49035 : H12AffineEnvironment.transform 4 1 env49034 = env49035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49034 == env49035) = true)

def env49036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510123,499128,8328,65,349474,395636,495035,67754,119042,272393,256,98815,90203,63189]

theorem envBound49036 : H12AffineFastState.Bounded env49036 := by
  intro p hp
  have h : env49036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49008_49036 : H12AffineEnvironment.transform 20 4161 env49008 = env49036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49008 == env49036) = true)

theorem identity49036 : scanCanonicalize (H12AffineFastState.compose env49036 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,144612,474239,485740,8328,65,349474,395636,489839,67754,75222,272393,256,95531,90203,513]

theorem envBound49037 : H12AffineFastState.Bounded env49037 := by
  intro p hp
  have h : env49037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49036_49037 : H12AffineEnvironment.transform 14 29908 env49036 = env49037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49036 == env49037) = true)

def env49038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144492,474239,485740,8192,65,349474,395636,489839,67618,75102,272393,256,95531,90203,513]

theorem envBound49038 : H12AffineFastState.Bounded env49038 := by
  intro p hp
  have h : env49038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49037_49038 : H12AffineEnvironment.transform 6 8 env49037 = env49038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49037 == env49038) = true)

theorem identity49038 : scanCanonicalize (H12AffineFastState.compose env49038 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound49038 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,4161,87159,285796,264567,8192,65,349474,354671,268660,67618,75102,272393,256,95531,90203,513]

theorem envBound49039 : H12AffineFastState.Bounded env49039 := by
  intro p hp
  have h : env49039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49038_49039 : H12AffineEnvironment.transform 16 90139 env49038 = env49039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env49038 == env49039) = true)

theorem identity49039 : scanCanonicalize (H12AffineFastState.compose env49039 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 76910) := by decide +kernel

theorem selectedBound49039 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env49040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76910,1024,29789,4161,87159,94218,75033,8192,65,31052,17665,79130,67618,75102,66663,256,95531,90203,513]

theorem envBound49040 : H12AffineFastState.Bounded env49040 := by
  intro p hp
  have h : env49040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49039_49040 : H12AffineEnvironment.transform 17 76910 env49039 = env49040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76910 env49039 == env49040) = true)

theorem identity49040 : scanCanonicalize (H12AffineFastState.compose env49040 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound49040 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env49041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5393,22884,1024,29789,4161,8573,1280,20499,8192,65,31052,17665,16400,32040,20564,29037,256,33,5457,513]

theorem envBound49041 : H12AffineFastState.Bounded env49041 := by
  intro p hp
  have h : env49041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49040_49041 : H12AffineEnvironment.transform 15 29962 env49040 = env49041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env49040 == env49041) = true)

theorem identity49041 : scanCanonicalize (H12AffineFastState.compose env49041 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound49041 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,1297,1095,5393,10281,1024,1296,4161,8573,1280,8542,8192,65,2049,13388,12637,3173,8473,32,256,33,5457,513]

theorem envBound49042 : H12AffineFastState.Bounded env49042 := by
  intro p hp
  have h : env49042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49041_49042 : H12AffineEnvironment.transform 13 12621 env49041 = env49042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env49041 == env49042) = true)

theorem identity49042 : scanCanonicalize (H12AffineFastState.compose env49042 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound49042 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6429,2128,1297,1095,5393,4404,1024,1296,4161,6240,1280,6211,6429,65,2049,3409,2112,3173,6148,32,256,33,5457,513]

theorem envBound49043 : H12AffineFastState.Bounded env49043 := by
  intro p hp
  have h : env49043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49042_49043 : H12AffineEnvironment.transform 12 6429 env49042 = env49043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env49042 == env49043) = true)

theorem identity49043 : scanCanonicalize (H12AffineFastState.compose env49043 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49043 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env49044 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,6249,2128,1125,1095,5221,4160,1024,1124,4161,6240,1140,6211,6249,65,2049,3109,2112,3173,6148,32,116,33,5157,513]

theorem envBound49044 : H12AffineFastState.Bounded env49044 := by
  intro p hp
  have h : env49044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49043_49044 : H12AffineEnvironment.transform 7 116 env49043 = env49044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49043 == env49044) = true)

theorem identity49044 : scanCanonicalize (H12AffineFastState.compose env49044 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49044 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env49045 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,6201,2048,1077,1047,5173,4112,1024,1076,4113,6192,1060,6163,6201,17,2049,3109,2064,3125,6148,32,36,33,5157,513]

theorem envBound49045 : H12AffineFastState.Bounded env49045 := by
  intro p hp
  have h : env49045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49044_49045 : H12AffineEnvironment.transform 5 16 env49044 = env49045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49044 == env49045) = true)

theorem identity49045 : scanCanonicalize (H12AffineFastState.compose env49045 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound49045 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49046 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1053,2048,1077,1047,2065,3124,1024,1076,3125,1044,1060,1079,1053,17,2049,3109,2064,3125,1056,32,36,33,2049,513]

theorem envBound49046 : H12AffineFastState.Bounded env49046 := by
  intro p hp
  have h : env49046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49045_49046 : H12AffineEnvironment.transform 11 3108 env49045 = env49046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env49045 == env49046) = true)

theorem identity49046 : scanCanonicalize (H12AffineFastState.compose env49046 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound49046 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env49047 : List Nat := [2,4,8,16,32,16,8,36,512,1024,555,1551,1053,555,1077,1047,570,1567,1024,1076,1566,1044,1060,1079,1053,17,554,1550,571,1566,1056,32,36,33,554,513]

theorem envBound49047 : H12AffineFastState.Bounded env49047 := by
  intro p hp
  have h : env49047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49046_49047 : H12AffineEnvironment.transform 10 555 env49046 = env49047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env49046 == env49047) = true)

theorem identity49047 : scanCanonicalize (H12AffineFastState.compose env49047 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49047 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49048 : List Nat := [2,4,8,16,32,16,8,36,512,53,555,570,40,555,0,34,570,554,53,1,555,33,17,2,40,17,554,571,571,555,21,32,36,33,554,513]

theorem envBound49048 : H12AffineFastState.Bounded env49048 := by
  intro p hp
  have h : env49048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49047_49048 : H12AffineEnvironment.transform 9 53 env49047 = env49048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49047 == env49048) = true)

theorem identity49048 : scanCanonicalize (H12AffineFastState.compose env49048 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound49048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49049 : List Nat := [2,4,8,16,32,16,8,36,59,53,16,1,40,16,0,34,1,17,53,1,16,33,17,2,40,17,17,0,0,16,21,32,36,33,17,58]

theorem envBound49049 : H12AffineFastState.Bounded env49049 := by
  intro p hp
  have h : env49049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49048_49049 : H12AffineEnvironment.transform 8 59 env49048 = env49049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env49048 == env49049) = true)

def env49050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,474239,485740,8193,65,349474,395636,489839,67619,75103,272393,256,95531,90203,513]

theorem envBound49050 : H12AffineFastState.Bounded env49050 := by
  intro p hp
  have h : env49050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49037_49050 : H12AffineEnvironment.transform 6 9 env49037 = env49050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49037 == env49050) = true)

theorem identity49050 : scanCanonicalize (H12AffineFastState.compose env49050 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound49050 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env49051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1024,29788,4161,144493,213334,201797,8193,65,75787,160861,197702,67619,75103,21792,256,95531,90203,513]

theorem envBound49051 : H12AffineFastState.Bounded env49051 := by
  intro p hp
  have h : env49051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49050_49051 : H12AffineEnvironment.transform 17 32041 env49050 = env49051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env49050 == env49051) = true)

theorem identity49051 : scanCanonicalize (H12AffineFastState.compose env49051 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound49051 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env49052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,131072,32041,1024,29788,4161,144493,136448,147475,8193,65,31837,160861,151568,23669,28937,21792,256,8573,13325,513]

theorem envBound49052 : H12AffineFastState.Bounded env49052 := by
  intro p hp
  have h : env49052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49051_49052 : H12AffineEnvironment.transform 15 21590 env49051 = env49052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env49051 == env49052) = true)

theorem identity49052 : scanCanonicalize (H12AffineFastState.compose env49052 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49052 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,131072,23668,1024,21761,4161,136496,136448,147475,348,65,23808,152832,151568,23669,20564,21792,256,32,5456,513]

theorem envBound49053 : H12AffineFastState.Bounded env49053 := by
  intro p hp
  have h : env49053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49052_49053 : H12AffineEnvironment.transform 12 349 env49052 = env49053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49052 == env49053) = true)

theorem identity49053 : scanCanonicalize (H12AffineFastState.compose env49053 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound49053 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,5392,23668,1024,21761,4161,32,16,21763,348,65,23808,16400,17664,23669,20564,21792,256,32,5456,513]

theorem envBound49054 : H12AffineFastState.Bounded env49054 := by
  intro p hp
  have h : env49054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49053_49054 : H12AffineEnvironment.transform 16 5392 env49053 = env49054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env49053 == env49054) = true)

theorem identity49054 : scanCanonicalize (H12AffineFastState.compose env49054 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49054 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49055 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,16384,21760,21590,5392,23636,1024,21761,4161,0,16,21763,348,65,23808,16400,17664,23637,20564,21760,256,0,5456,513]

theorem envBound49055 : H12AffineFastState.Bounded env49055 := by
  intro p hp
  have h : env49055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49054_49055 : H12AffineEnvironment.transform 4 0 env49054 = env49055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49054 == env49055) = true)

theorem identity49055 : scanCanonicalize (H12AffineFastState.compose env49055 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49055 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49056 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5377,1,343,5392,2389,1024,0,4161,0,16,2,348,65,2049,5393,4097,2388,1365,1,256,0,5456,513]

theorem envBound49056 : H12AffineFastState.Bounded env49056 := by
  intro p hp
  have h : env49056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49055_49056 : H12AffineEnvironment.transform 13 5377 env49055 = env49056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49055 == env49056) = true)

theorem identity49056 : scanCanonicalize (H12AffineFastState.compose env49056 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound49056 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49057 : List Nat := [2,4,8,16,0,64,9,256,512,832,2048,4096,349,4673,1,343,4688,2389,832,0,4161,0,16,2,348,65,2049,4689,4097,2388,533,1,256,0,4624,513]

theorem envBound49057 : H12AffineFastState.Bounded env49057 := by
  intro p hp
  have h : env49057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49056_49057 : H12AffineEnvironment.transform 9 832 env49056 = env49057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env49056 == env49057) = true)

theorem identity49057 : scanCanonicalize (H12AffineFastState.compose env49057 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49057 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49058 : List Nat := [2,4,8,16,0,17,9,256,512,785,2048,4096,268,4624,1,262,4609,2308,785,0,4112,0,16,2,269,16,2049,4608,4097,2309,533,1,256,0,4624,513]

theorem envBound49058 : H12AffineFastState.Bounded env49058 := by
  intro p hp
  have h : env49058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49057_49058 : H12AffineEnvironment.transform 5 17 env49057 = env49058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49057 == env49058) = true)

theorem identity49058 : scanCanonicalize (H12AffineFastState.compose env49058 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound49058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49059 : List Nat := [2,4,8,16,0,17,9,256,512,785,2048,261,268,789,1,262,772,2308,785,0,277,0,16,2,269,16,2049,773,260,2309,533,1,256,0,789,513]

theorem envBound49059 : H12AffineFastState.Bounded env49059 := by
  intro p hp
  have h : env49059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49058_49059 : H12AffineEnvironment.transform 11 261 env49058 = env49059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env49058 == env49059) = true)

theorem identity49059 : scanCanonicalize (H12AffineFastState.compose env49059 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound49059 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49060 : List Nat := [2,4,8,16,0,17,9,256,512,785,261,261,268,789,1,262,772,1,785,0,277,0,16,2,269,16,260,773,260,0,533,1,256,0,789,513]

theorem envBound49060 : H12AffineFastState.Bounded env49060 := by
  intro p hp
  have h : env49060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49059_49060 : H12AffineEnvironment.transform 10 261 env49059 = env49060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env49059 == env49060) = true)

theorem identity49060 : scanCanonicalize (H12AffineFastState.compose env49060 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49060 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49061 : List Nat := [2,4,8,1,0,0,9,256,512,768,261,261,268,772,1,262,772,1,768,0,260,0,1,2,269,1,260,773,260,0,516,1,256,0,772,513]

theorem envBound49061 : H12AffineFastState.Bounded env49061 := by
  intro p hp
  have h : env49061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49060_49061 : H12AffineEnvironment.transform 3 1 env49060 = env49061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49060 == env49061) = true)

theorem identity49061 : scanCanonicalize (H12AffineFastState.compose env49061 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound49061 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49062 : List Nat := [2,4,8,1,0,0,9,256,260,4,261,261,268,0,1,262,0,1,4,0,260,0,1,2,269,1,260,1,260,0,256,1,256,0,0,261]

theorem envBound49062 : H12AffineFastState.Bounded env49062 := by
  intro p hp
  have h : env49062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49061_49062 : H12AffineEnvironment.transform 8 260 env49061 = env49062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env49061 == env49062) = true)

theorem identity49062 : scanCanonicalize (H12AffineFastState.compose env49062 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49062 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49063 : List Nat := [2,4,8,1,0,0,9,5,1,4,0,0,9,0,1,3,0,1,4,0,1,0,1,2,8,1,1,1,1,0,5,1,5,0,0,0]

theorem envBound49063 : H12AffineFastState.Bounded env49063 := by
  intro p hp
  have h : env49063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49062_49063 : H12AffineEnvironment.transform 7 5 env49062 = env49063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49062 == env49063) = true)

def env49064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510123,499129,8328,65,349475,2496820,2596346,67754,119043,2373705,256,2199999,2191387,63188]

theorem envBound49064 : H12AffineFastState.Bounded env49064 := by
  intro p hp
  have h : env49064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49007_49064 : H12AffineEnvironment.transform 23 499129 env49007 = env49064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env49007 == env49064) = true)

def env49065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510123,499129,8328,65,349475,395636,495034,67754,119043,272393,256,98815,90203,63188]

theorem envBound49065 : H12AffineFastState.Bounded env49065 := by
  intro p hp
  have h : env49065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49064_49065 : H12AffineEnvironment.transform 20 4160 env49064 = env49065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49064 == env49065) = true)

def env49066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,180272,253963,242969,8328,65,97667,139732,238874,67754,119043,169,256,98815,90203,63188]

theorem envBound49066 : H12AffineFastState.Bounded env49066 := by
  intro p hp
  have h : env49066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49065_49066 : H12AffineEnvironment.transform 17 10400 env49065 = env49066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49065 == env49066) = true)

def env49067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180272,253963,242969,8192,65,97547,139612,238874,67618,119043,33,256,98679,90203,63068]

theorem envBound49067 : H12AffineFastState.Bounded env49067 := by
  intro p hp
  have h : env49067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49066_49067 : H12AffineEnvironment.transform 6 8 env49066 = env49067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49066 == env49067) = true)

theorem identity49067 : scanCanonicalize (H12AffineFastState.compose env49067 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound49067 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,98678,41293,62559,8192,65,97547,90138,58460,67618,119043,33,256,98679,90203,63068]

theorem envBound49068 : H12AffineFastState.Bounded env49068 := by
  intro p hp
  have h : env49068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49067_49068 : H12AffineEnvironment.transform 16 82246 env49067 = env49068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env49067 == env49068) = true)

theorem identity49068 : scanCanonicalize (H12AffineFastState.compose env49068 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49068 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,2421,1024,32769,4160,98678,32784,54530,349,65,89174,82247,50433,67618,119043,33,256,98679,82182,55041]

theorem envBound49069 : H12AffineFastState.Bounded env49069 := by
  intro p hp
  have h : env49069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49068_49069 : H12AffineEnvironment.transform 12 349 env49068 = env49069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49068 == env49069) = true)

theorem identity49069 : scanCanonicalize (H12AffineFastState.compose env49069 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49069 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env49070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70727,2421,1024,32769,4160,98678,32784,32771,349,65,67927,70726,36864,67618,99330,33,256,98679,70663,33280]

theorem envBound49070 : H12AffineFastState.Bounded env49070 := by
  intro p hp
  have h : env49070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49069_49070 : H12AffineEnvironment.transform 13 5377 env49069 = env49070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49069 == env49070) = true)

theorem identity49070 : scanCanonicalize (H12AffineFastState.compose env49070 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound49070 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,65536,70727,2421,1024,1,4160,65910,16,3,349,65,67927,70726,4096,67618,66562,33,256,65911,70663,512]

theorem envBound49071 : H12AffineFastState.Bounded env49071 := by
  intro p hp
  have h : env49071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49070_49071 : H12AffineEnvironment.transform 14 0 env49070 = env49071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env49070 == env49071) = true)

theorem identity49071 : scanCanonicalize (H12AffineFastState.compose env49071 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49071 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env49072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,65536,70679,2341,1024,1,4112,65830,16,3,269,17,67847,70678,4096,67618,66562,33,256,65831,70663,512]

theorem envBound49072 : H12AffineFastState.Bounded env49072 := by
  intro p hp
  have h : env49072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49071_49072 : H12AffineEnvironment.transform 5 16 env49071 = env49072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49071 == env49072) = true)

theorem identity49072 : scanCanonicalize (H12AffineFastState.compose env49072 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49072 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49073 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,0,65536,70679,2309,1024,1,4112,65798,16,3,269,17,67847,70678,4096,67586,66562,1,256,65799,70663,512]

theorem envBound49073 : H12AffineFastState.Bounded env49073 := by
  intro p hp
  have h : env49073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49072_49073 : H12AffineEnvironment.transform 4 0 env49072 = env49073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49072 == env49073) = true)

theorem identity49073 : scanCanonicalize (H12AffineFastState.compose env49073 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49073 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env49074 : List Nat := [2,4,8,16,0,16,8,20,512,1024,2048,4096,25,5141,0,65536,70679,2065,1024,1,4112,65554,16,3,25,17,67603,70678,4096,67586,66562,1,20,65555,70663,512]

theorem envBound49074 : H12AffineFastState.Bounded env49074 := by
  intro p hp
  have h : env49074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49073_49074 : H12AffineEnvironment.transform 7 20 env49073 = env49074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49073 == env49074) = true)

def env49075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180272,253963,242969,8193,65,97546,139613,238874,67619,119043,32,256,98678,90203,63069]

theorem envBound49075 : H12AffineFastState.Bounded env49075 := by
  intro p hp
  have h : env49075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49066_49075 : H12AffineEnvironment.transform 6 9 env49066 = env49075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49066 == env49075) = true)

theorem identity49075 : scanCanonicalize (H12AffineFastState.compose env49075 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound49075 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4160,73770,17,21763,8193,65,97546,115015,17664,67619,119043,32,256,98678,90203,63069]

theorem envBound49076 : H12AffineFastState.Bounded env49076 := by
  intro p hp
  have h : env49076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49075_49076 : H12AffineEnvironment.transform 16 122906 env49075 = env49076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env49075 == env49076) = true)

theorem identity49076 : scanCanonicalize (H12AffineFastState.compose env49076 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49076 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,103495,10281,1024,32769,4160,73770,17,8542,8193,65,67927,111898,12637,67619,107870,32,256,98678,70662,33280]

theorem envBound49077 : H12AffineFastState.Bounded env49077 := by
  intro p hp
  have h : env49077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49076_49077 : H12AffineEnvironment.transform 13 13405 env49076 = env49077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49076 == env49077) = true)

theorem identity49077 : scanCanonicalize (H12AffineFastState.compose env49077 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound49077 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8282,46109,10281,1024,32769,4160,112,17,8542,8193,65,10509,38208,12637,10361,34052,32,256,41260,13404,33280]

theorem envBound49078 : H12AffineFastState.Bounded env49078 := by
  intro p hp
  have h : env49078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49077_49078 : H12AffineEnvironment.transform 15 8282 env49077 = env49078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env49077 == env49078) = true)

theorem identity49078 : scanCanonicalize (H12AffineFastState.compose env49078 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49078 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49079 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,32768,8282,46109,10281,1024,32769,4160,112,17,8315,8193,65,10280,37989,12408,10361,33825,32,37,40969,13404,33280]

theorem envBound49079 : H12AffineFastState.Bounded env49079 := by
  intro p hp
  have h : env49079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49078_49079 : H12AffineEnvironment.transform 7 37 env49078 = env49079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49078 == env49079) = true)

theorem identity49079 : scanCanonicalize (H12AffineFastState.compose env49079 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound49079 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49080 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13405,80,8282,13389,10281,1024,81,4160,112,17,8315,8193,65,10280,5173,12408,10361,1137,32,37,8281,13404,592]

theorem envBound49080 : H12AffineFastState.Bounded env49080 := by
  intro p hp
  have h : env49080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49079_49080 : H12AffineEnvironment.transform 14 80 env49079 = env49080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env49079 == env49080) = true)

theorem identity49080 : scanCanonicalize (H12AffineFastState.compose env49080 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound49080 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49081 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2112,8192,11293,80,8282,11277,10281,1024,81,2048,112,17,8315,8193,65,10280,3189,10296,10361,1137,32,37,8281,11292,592]

theorem envBound49081 : H12AffineFastState.Bounded env49081 := by
  intro p hp
  have h : env49081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49080_49081 : H12AffineEnvironment.transform 11 2112 env49080 = env49081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env49080 == env49081) = true)

theorem identity49081 : scanCanonicalize (H12AffineFastState.compose env49081 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49081 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49082 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2112,8192,10281,80,8282,10297,10281,52,81,2048,112,17,8315,8193,65,10280,2113,10296,10361,69,32,37,8281,10280,592]

theorem envBound49082 : H12AffineFastState.Bounded env49082 := by
  intro p hp
  have h : env49082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49081_49082 : H12AffineEnvironment.transform 9 52 env49081 = env49082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49081 == env49082) = true)

theorem identity49082 : scanCanonicalize (H12AffineFastState.compose env49082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49083 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,2112,40,2049,80,114,2065,2049,52,81,2048,112,17,83,41,65,2048,2113,2064,2129,69,32,37,113,2048,592]

theorem envBound49083 : H12AffineFastState.Bounded env49083 := by
  intro p hp
  have h : env49083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49082_49083 : H12AffineEnvironment.transform 12 40 env49082 = env49083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49082 == env49083) = true)

theorem identity49083 : scanCanonicalize (H12AffineFastState.compose env49083 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49083 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env49084 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,40,2049,0,34,2065,2049,52,1,2048,32,17,3,41,17,2048,2065,2064,2049,21,32,37,33,2048,512]

theorem envBound49084 : H12AffineFastState.Bounded env49084 := by
  intro p hp
  have h : env49084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49083_49084 : H12AffineEnvironment.transform 5 16 env49083 = env49084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49083 == env49084) = true)

theorem identity49084 : scanCanonicalize (H12AffineFastState.compose env49084 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49085 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2064,8,2049,0,2,2065,2049,20,1,2048,0,17,3,9,17,2048,2065,2064,2049,21,0,5,1,2048,512]

theorem envBound49085 : H12AffineFastState.Bounded env49085 := by
  intro p hp
  have h : env49085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49084_49085 : H12AffineEnvironment.transform 4 0 env49084 = env49085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49084 == env49085) = true)

theorem identity49085 : scanCanonicalize (H12AffineFastState.compose env49085 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound49085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49086 : List Nat := [2,4,8,16,0,16,9,5,512,20,4,20,8,5,0,2,21,5,20,1,4,0,17,3,9,17,4,21,20,5,21,0,5,1,4,512]

theorem envBound49086 : H12AffineFastState.Bounded env49086 := by
  intro p hp
  have h : env49086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49085_49086 : H12AffineEnvironment.transform 10 4 env49085 = env49086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env49085 == env49086) = true)

def env49087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,180272,253962,242968,8328,65,97666,139733,238875,67754,119043,168,256,98815,90203,63188]

theorem envBound49087 : H12AffineFastState.Bounded env49087 := by
  intro p hp
  have h : env49087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49065_49087 : H12AffineEnvironment.transform 17 10401 env49065 = env49087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49065 == env49087) = true)

def env49088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180272,253962,242968,8192,65,97546,139613,238875,67618,119043,32,256,98679,90203,63068]

theorem envBound49088 : H12AffineFastState.Bounded env49088 := by
  intro p hp
  have h : env49088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49087_49088 : H12AffineEnvironment.transform 6 8 env49087 = env49088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49087 == env49088) = true)

theorem identity49088 : scanCanonicalize (H12AffineFastState.compose env49088 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49088 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,4160,156012,213334,201796,8192,65,97546,139613,197703,67618,94303,32,256,73771,90203,22272]

theorem envBound49089 : H12AffineFastState.Bounded env49089 := by
  intro p hp
  have h : env49089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49088_49089 : H12AffineEnvironment.transform 14 8540 env49088 = env49089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49088 == env49089) = true)

theorem identity49089 : scanCanonicalize (H12AffineFastState.compose env49089 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound49089 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env49090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21591,131072,10281,1024,8541,4160,156012,136449,147475,8192,65,10589,139613,151568,23669,9224,32,256,29820,13324,22272]

theorem envBound49090 : H12AffineFastState.Bounded env49090 := by
  intro p hp
  have h : env49090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49089_49090 : H12AffineEnvironment.transform 15 21591 env49089 = env49090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env49089 == env49090) = true)

theorem identity49090 : scanCanonicalize (H12AffineFastState.compose env49090 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49090 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env49091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8282,131072,10281,1024,8541,4160,136545,136449,144414,8192,65,10589,139613,140317,10360,9224,32,256,113,13324,8973]

theorem envBound49091 : H12AffineFastState.Bounded env49091 := by
  intro p hp
  have h : env49091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49090_49091 : H12AffineEnvironment.transform 13 13325 env49090 = env49091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49090 == env49091) = true)

theorem identity49091 : scanCanonicalize (H12AffineFastState.compose env49091 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound49091 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8282,4469,10281,1024,8541,4160,1044,1140,9579,8192,65,10589,12328,13672,10360,9224,32,256,113,13324,8973]

theorem envBound49092 : H12AffineFastState.Bounded env49092 := by
  intro p hp
  have h : env49092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49091_49092 : H12AffineEnvironment.transform 16 4469 env49091 = env49092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env49091 == env49092) = true)

theorem identity49092 : scanCanonicalize (H12AffineFastState.compose env49092 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound49092 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4161,1296,1046,4469,3173,1024,1297,4160,1044,1140,295,1100,65,3345,5220,4388,3124,68,32,256,113,4160,1857]

theorem envBound49093 : H12AffineFastState.Bounded env49093 := by
  intro p hp
  have h : env49093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49092_49093 : H12AffineEnvironment.transform 12 1100 env49092 = env49093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env49092 == env49093) = true)

theorem identity49093 : scanCanonicalize (H12AffineFastState.compose env49093 (packedSelected [0,1,7,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound49093 : packedSelected [0,1,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env49094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,1100,2421,1296,1046,2113,3173,1024,1297,2420,1044,1140,295,1100,65,3345,3408,2064,3124,68,32,256,113,2420,1857]

theorem envBound49094 : H12AffineFastState.Bounded env49094 := by
  intro p hp
  have h : env49094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49093_49094 : H12AffineEnvironment.transform 11 2356 env49093 = env49094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env49093 == env49094) = true)

theorem identity49094 : scanCanonicalize (H12AffineFastState.compose env49094 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49094 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env49095 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2113,1100,2048,1125,1046,2113,3173,1024,1124,2049,1044,1140,82,1100,65,3172,3109,2064,3124,68,32,117,113,2049,1588]

theorem envBound49095 : H12AffineFastState.Bounded env49095 := by
  intro p hp
  have h : env49095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49094_49095 : H12AffineEnvironment.transform 7 117 env49094 = env49095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49094 == env49095) = true)

theorem identity49095 : scanCanonicalize (H12AffineFastState.compose env49095 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49095 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env49096 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,2113,41,2048,0,115,2113,2048,101,1,2049,113,17,82,41,65,2049,2112,2064,2129,68,32,117,113,2049,593]

theorem envBound49096 : H12AffineFastState.Bounded env49096 := by
  intro p hp
  have h : env49096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49095_49096 : H12AffineEnvironment.transform 9 101 env49095 = env49096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49095 == env49096) = true)

theorem identity49096 : scanCanonicalize (H12AffineFastState.compose env49096 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49096 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49097 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2064,41,2048,0,34,2064,2048,52,1,2049,32,17,3,41,16,2049,2065,2064,2048,21,32,36,32,2049,512]

theorem envBound49097 : H12AffineFastState.Bounded env49097 := by
  intro p hp
  have h : env49097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49096_49097 : H12AffineEnvironment.transform 5 17 env49096 = env49097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49096 == env49097) = true)

theorem identity49097 : scanCanonicalize (H12AffineFastState.compose env49097 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound49097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49098 : List Nat := [2,4,8,16,32,17,8,36,512,52,516,532,41,516,0,34,532,516,52,1,517,32,17,3,41,16,517,533,532,516,21,32,36,32,517,512]

theorem envBound49098 : H12AffineFastState.Bounded env49098 := by
  intro p hp
  have h : env49098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49097_49098 : H12AffineEnvironment.transform 10 516 env49097 = env49098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env49097 == env49098) = true)

theorem identity49098 : scanCanonicalize (H12AffineFastState.compose env49098 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound49098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49099 : List Nat := [2,4,8,16,2,17,8,6,512,22,516,532,11,516,0,0,532,516,22,1,517,2,17,3,11,16,517,533,532,516,21,2,6,2,517,512]

theorem envBound49099 : H12AffineFastState.Bounded env49099 := by
  intro p hp
  have h : env49099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49098_49099 : H12AffineEnvironment.transform 4 2 env49098 = env49099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env49098 == env49099) = true)

theorem identity49099 : scanCanonicalize (H12AffineFastState.compose env49099 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound49099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49100 : List Nat := [2,4,8,16,2,17,8,6,7,22,3,19,11,3,0,0,19,3,22,1,2,2,17,3,11,16,2,18,19,3,21,2,6,2,2,7]

theorem envBound49100 : H12AffineFastState.Bounded env49100 := by
  intro p hp
  have h : env49100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49099_49100 : H12AffineEnvironment.transform 8 7 env49099 = env49100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env49099 == env49100) = true)

theorem identity49100 : scanCanonicalize (H12AffineFastState.compose env49100 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound49100 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49101 : List Nat := [2,4,6,16,2,17,6,6,7,22,3,19,5,3,0,0,19,3,22,1,2,2,17,3,5,16,2,18,19,3,21,2,6,2,2,7]

theorem envBound49101 : H12AffineFastState.Bounded env49101 := by
  intro p hp
  have h : env49101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49100_49101 : H12AffineEnvironment.transform 2 6 env49100 = env49101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env49100 == env49101) = true)

theorem identity49101 : scanCanonicalize (H12AffineFastState.compose env49101 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49101 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49102 : List Nat := [0,4,4,16,0,17,4,4,5,20,1,17,5,1,0,0,17,1,20,1,0,0,17,1,5,16,0,16,17,1,21,0,4,0,0,5]

theorem envBound49102 : H12AffineFastState.Bounded env49102 := by
  intro p hp
  have h : env49102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49101_49102 : H12AffineEnvironment.transform 0 0 env49101 = env49102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49101 == env49102) = true)

def env49103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180272,253962,242968,8193,65,97547,139612,238875,67619,119043,33,256,98678,90203,63069]

theorem envBound49103 : H12AffineFastState.Bounded env49103 := by
  intro p hp
  have h : env49103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49087_49103 : H12AffineEnvironment.transform 6 9 env49087 = env49103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49087 == env49103) = true)

theorem identity49103 : scanCanonicalize (H12AffineFastState.compose env49103 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound49103 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,4160,144492,201814,213316,8193,65,97547,139612,217415,67619,75103,33,256,95530,90203,513]

theorem envBound49104 : H12AffineFastState.Bounded env49104 := by
  intro p hp
  have h : env49104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49103_49104 : H12AffineEnvironment.transform 14 29788 env49103 = env49104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env49103 == env49104) = true)

theorem identity49104 : scanCanonicalize (H12AffineFastState.compose env49104 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound49104 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env49105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82246,10280,1024,29789,4160,95530,21776,2,8193,65,97547,90138,4097,67619,75103,33,256,95530,90203,513]

theorem envBound49105 : H12AffineFastState.Bounded env49105 := by
  intro p hp
  have h : env49105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49104_49105 : H12AffineEnvironment.transform 16 82246 env49104 = env49105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env49104 == env49105) = true)

theorem identity49105 : scanCanonicalize (H12AffineFastState.compose env49105 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49105 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,262,16448,10280,1024,29789,4160,29740,21776,2,8193,65,31757,24860,4097,2341,9305,33,256,29740,24925,513]

theorem envBound49106 : H12AffineFastState.Bounded env49106 := by
  intro p hp
  have h : env49106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49105_49106 : H12AffineEnvironment.transform 15 262 env49105 = env49106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49105 == env49106) = true)

theorem identity49106 : scanCanonicalize (H12AffineFastState.compose env49106 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49106 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,262,5440,10280,1024,8541,4160,8492,16,2,8193,65,10509,13340,4097,2341,9305,33,256,8492,13405,513]

theorem envBound49107 : H12AffineFastState.Bounded env49107 := by
  intro p hp
  have h : env49107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49106_49107 : H12AffineEnvironment.transform 13 5376 env49106 = env49107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49106 == env49107) = true)

theorem identity49107 : scanCanonicalize (H12AffineFastState.compose env49107 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49107 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,262,5440,2421,1024,0,4160,113,16,2,348,65,2128,5441,4097,2341,1284,33,256,113,5376,513]

theorem envBound49108 : H12AffineFastState.Bounded env49108 := by
  intro p hp
  have h : env49108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49107_49108 : H12AffineEnvironment.transform 12 349 env49107 = env49108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49107 == env49108) = true)

theorem identity49108 : scanCanonicalize (H12AffineFastState.compose env49108 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound49108 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env49109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1588,4096,349,5376,1,262,5440,1857,1024,0,4160,113,16,2,348,65,1636,5441,4097,1809,1284,33,256,113,5376,513]

theorem envBound49109 : H12AffineFastState.Bounded env49109 := by
  intro p hp
  have h : env49109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49108_49109 : H12AffineEnvironment.transform 10 1588 env49108 = env49109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env49108 == env49109) = true)

theorem identity49109 : scanCanonicalize (H12AffineFastState.compose env49109 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound49109 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env49110 : List Nat := [2,4,8,16,32,64,9,256,277,1024,1313,4096,349,5376,1,262,5440,1108,1024,0,4160,113,16,2,348,65,1393,5441,4097,1028,1284,33,256,113,5376,276]

theorem envBound49110 : H12AffineFastState.Bounded env49110 := by
  intro p hp
  have h : env49110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49109_49110 : H12AffineEnvironment.transform 8 277 env49109 = env49110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env49109 == env49110) = true)

theorem identity49110 : scanCanonicalize (H12AffineFastState.compose env49110 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound49110 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env49111 : List Nat := [2,4,8,16,32,64,9,256,277,117,340,4096,349,4469,1,262,4405,33,117,0,4160,113,16,2,348,65,260,4404,4097,113,369,33,256,113,4469,276]

theorem envBound49111 : H12AffineFastState.Bounded env49111 := by
  intro p hp
  have h : env49111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49110_49111 : H12AffineEnvironment.transform 9 117 env49110 = env49111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env49110 == env49111) = true)

theorem identity49111 : scanCanonicalize (H12AffineFastState.compose env49111 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound49111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49112 : List Nat := [2,4,8,16,32,64,9,256,277,117,340,261,349,112,1,262,48,33,117,0,325,113,16,2,348,65,260,49,260,113,369,33,256,113,112,276]

theorem envBound49112 : H12AffineFastState.Bounded env49112 := by
  intro p hp
  have h : env49112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49111_49112 : H12AffineEnvironment.transform 11 261 env49111 = env49112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env49111 == env49112) = true)

theorem identity49112 : scanCanonicalize (H12AffineFastState.compose env49112 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49113 : List Nat := [2,4,8,16,32,64,9,5,16,117,81,0,88,112,1,3,48,33,117,0,64,113,16,2,89,65,1,49,1,113,116,33,5,113,112,17]

theorem envBound49113 : H12AffineFastState.Bounded env49113 := by
  intro p hp
  have h : env49113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49112_49113 : H12AffineEnvironment.transform 7 5 env49112 = env49113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49112 == env49113) = true)

theorem identity49113 : scanCanonicalize (H12AffineFastState.compose env49113 (packedSelected [3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49113 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env49114 : List Nat := [2,4,8,16,32,1,9,5,16,52,16,0,25,49,1,3,48,33,52,0,1,48,16,2,24,0,1,49,1,48,53,33,5,48,49,17]

theorem envBound49114 : H12AffineFastState.Bounded env49114 := by
  intro p hp
  have h : env49114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49113_49114 : H12AffineEnvironment.transform 5 1 env49113 = env49114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49113 == env49114) = true)

theorem identity49114 : scanCanonicalize (H12AffineFastState.compose env49114 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49114 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49115 : List Nat := [2,4,8,16,1,1,9,5,16,21,16,0,25,16,1,3,17,0,21,0,1,17,16,2,24,0,1,16,1,17,20,0,5,17,16,17]

theorem envBound49115 : H12AffineFastState.Bounded env49115 := by
  intro p hp
  have h : env49115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49114_49115 : H12AffineEnvironment.transform 4 1 env49114 = env49115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49114 == env49115) = true)

def env49116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510123,499129,8328,65,349475,395637,495035,67754,119043,272392,256,98814,90202,63188]

theorem envBound49116 : H12AffineFastState.Bounded env49116 := by
  intro p hp
  have h : env49116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49064_49116 : H12AffineEnvironment.transform 20 4161 env49064 = env49116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49064 == env49116) = true)

theorem identity49116 : scanCanonicalize (H12AffineFastState.compose env49116 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound49116 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180272,73755,95497,8328,65,245139,57797,91403,67754,119043,180408,256,98814,90202,63188]

theorem envBound49117 : H12AffineFastState.Bounded env49117 := by
  intro p hp
  have h : env49117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49116_49117 : H12AffineEnvironment.transform 17 190640 env49116 = env49117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env49116 == env49117) = true)

def env49118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1024,32769,4161,32,73755,95497,8328,65,97667,57797,91403,67754,119043,168,256,98814,90202,63188]

theorem envBound49118 : H12AffineFastState.Bounded env49118 := by
  intro p hp
  have h : env49118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49117_49118 : H12AffineEnvironment.transform 16 49168 env49117 = env49118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env49117 == env49118) = true)

theorem identity49118 : scanCanonicalize (H12AffineFastState.compose env49118 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound49118 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env49119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,65536,24632,10400,1024,8233,4161,32,73755,95497,8328,65,97667,16877,91403,67754,94507,168,256,74198,90202,22268]

theorem envBound49119 : H12AffineFastState.Bounded env49119 := by
  intro p hp
  have h : env49119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49118_49119 : H12AffineEnvironment.transform 14 8232 env49118 = env49119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env49118 == env49119) = true)

theorem identity49119 : scanCanonicalize (H12AffineFastState.compose env49119 (packedSelected [1,2,6,7,9,11,16,18,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound49119 : packedSelected [1,2,6,7,9,11,16,18,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,171,24632,10400,1024,8233,4161,32,8368,30114,8328,65,32040,16877,26016,2049,29056,168,256,8573,24817,22268]

theorem envBound49120 : H12AffineFastState.Bounded env49120 := by
  intro p hp
  have h : env49120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49119_49120 : H12AffineEnvironment.transform 15 171 env49119 = env49120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env49119 == env49120) = true)

theorem identity49120 : scanCanonicalize (H12AffineFastState.compose env49120 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound49120 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env49121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,8232,171,13389,10400,1024,8233,4161,32,8368,8663,8328,65,10589,5528,12757,2049,9717,168,256,8573,13444,649]

theorem envBound49121 : H12AffineFastState.Bounded env49121 := by
  intro p hp
  have h : env49121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49120_49121 : H12AffineEnvironment.transform 13 5237 env49120 = env49121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env49120 == env49121) = true)

theorem identity49121 : scanCanonicalize (H12AffineFastState.compose env49121 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound49121 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env49122 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,4248,8232,171,12448,10400,237,8233,4161,32,8368,8663,8328,65,10589,4469,12757,2049,8472,168,256,8573,12393,649]

theorem envBound49122 : H12AffineFastState.Bounded env49122 := by
  intro p hp
  have h : env49122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49121_49122 : H12AffineEnvironment.transform 9 237 env49121 = env49122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env49121 == env49122) = true)

theorem identity49122 : scanCanonicalize (H12AffineFastState.compose env49122 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound49122 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env49123 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,4096,8192,4248,8232,171,12448,10400,237,8233,4161,32,8368,8234,8328,65,10400,4232,12328,2049,8421,168,253,8320,12393,649]

theorem envBound49123 : H12AffineFastState.Bounded env49123 := by
  intro p hp
  have h : env49123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49122_49123 : H12AffineEnvironment.transform 7 253 env49122 = env49123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env49122 == env49123) = true)

theorem identity49123 : scanCanonicalize (H12AffineFastState.compose env49123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49124 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,4096,40,4248,0,171,4232,2184,237,1,4161,32,152,2,160,65,2184,4232,4096,2049,205,168,253,168,4161,649]

theorem envBound49124 : H12AffineFastState.Bounded env49124 := by
  intro p hp
  have h : env49124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49123_49124 : H12AffineEnvironment.transform 12 40 env49123 = env49124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49123 == env49124) = true)

theorem identity49124 : scanCanonicalize (H12AffineFastState.compose env49124 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound49124 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49125 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,152,40,0,0,171,16,2184,237,1,217,32,152,2,160,65,2184,16,152,2049,205,168,253,168,217,649]

theorem envBound49125 : H12AffineFastState.Bounded env49125 := by
  intro p hp
  have h : env49125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49124_49125 : H12AffineEnvironment.transform 11 152 env49124 = env49125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env49124 == env49125) = true)

theorem identity49125 : scanCanonicalize (H12AffineFastState.compose env49125 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49126 : List Nat := [2,4,8,16,32,48,128,141,512,157,2048,152,40,0,0,171,16,2184,157,1,169,32,152,2,160,49,2184,16,152,2049,189,168,141,168,169,649]

theorem envBound49126 : H12AffineFastState.Bounded env49126 := by
  intro p hp
  have h : env49126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49125_49126 : H12AffineEnvironment.transform 5 48 env49125 = env49126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49125 == env49126) = true)

theorem identity49126 : scanCanonicalize (H12AffineFastState.compose env49126 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49126 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env49127 : List Nat := [2,4,8,16,32,48,128,141,512,157,1,152,40,0,0,171,16,137,157,1,169,32,152,2,160,49,137,16,152,0,189,168,141,168,169,649]

theorem envBound49127 : H12AffineFastState.Bounded env49127 := by
  intro p hp
  have h : env49127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49126_49127 : H12AffineEnvironment.transform 10 1 env49126 = env49127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49126 == env49127) = true)

theorem identity49127 : scanCanonicalize (H12AffineFastState.compose env49127 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound49127 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env49128 : List Nat := [2,4,8,16,32,48,128,141,184,157,1,152,40,0,0,171,16,137,157,1,169,32,152,2,160,49,137,16,152,0,189,168,141,168,169,49]

theorem envBound49128 : H12AffineFastState.Bounded env49128 := by
  intro p hp
  have h : env49128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49127_49128 : H12AffineEnvironment.transform 8 184 env49127 = env49128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env49127 == env49128) = true)

theorem identity49128 : scanCanonicalize (H12AffineFastState.compose env49128 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49128 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env49129 : List Nat := [2,4,8,16,1,17,128,141,153,157,1,152,9,0,0,138,16,137,157,1,136,1,152,2,129,16,137,16,152,0,156,137,141,137,136,16]

theorem envBound49129 : H12AffineFastState.Bounded env49129 := by
  intro p hp
  have h : env49129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49128_49129 : H12AffineEnvironment.transform 4 1 env49128 = env49129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49128 == env49129) = true)

def env49130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1024,32769,4161,33,73755,95497,8328,65,97666,57797,91403,67754,119043,169,256,98814,90202,63188]

theorem envBound49130 : H12AffineFastState.Bounded env49130 := by
  intro p hp
  have h : env49130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49117_49130 : H12AffineEnvironment.transform 16 49169 env49117 = env49130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env49117 == env49130) = true)

theorem identity49130 : scanCanonicalize (H12AffineFastState.compose env49130 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound49130 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env49131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10401,1024,32769,4161,33,153,21899,8328,65,23808,57797,17801,10280,61825,169,256,41340,16600,63188]

theorem envBound49131 : H12AffineFastState.Bounded env49131 := by
  intro p hp
  have h : env49131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49130_49131 : H12AffineEnvironment.transform 15 8322 env49130 = env49131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env49130 == env49131) = true)

theorem identity49131 : scanCanonicalize (H12AffineFastState.compose env49131 (packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49131 : packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env49132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8322,13508,10401,1024,29908,4161,33,153,21899,8328,65,23808,5392,17801,10280,1364,169,256,21929,16600,513]

theorem envBound49132 : H12AffineFastState.Bounded env49132 := by
  intro p hp
  have h : env49132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49131_49132 : H12AffineEnvironment.transform 14 29909 env49131 = env49132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49131 == env49132) = true)

theorem identity49132 : scanCanonicalize (H12AffineFastState.compose env49132 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49132 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13508,10401,1024,8661,4161,33,153,138,8328,65,2049,5392,4232,10280,1364,169,256,168,5593,513]

theorem envBound49133 : H12AffineFastState.Bounded env49133 := by
  intro p hp
  have h : env49133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49132_49133 : H12AffineEnvironment.transform 13 5377 env49132 = env49133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49132 == env49133) = true)

theorem identity49133 : scanCanonicalize (H12AffineFastState.compose env49133 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound49133 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env49134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,342,5392,2421,1024,1,4161,33,153,138,348,65,2049,5392,4232,2556,1364,169,256,168,5593,513]

theorem envBound49134 : H12AffineFastState.Bounded env49134 := by
  intro p hp
  have h : env49134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49133_49134 : H12AffineEnvironment.transform 12 468 env49133 = env49134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env49133 == env49134) = true)

theorem identity49134 : scanCanonicalize (H12AffineFastState.compose env49134 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49134 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env49135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,0,263,5392,2340,1024,1,4112,33,153,138,269,16,2049,5392,4232,2477,1285,169,256,168,5512,513]

theorem envBound49135 : H12AffineFastState.Bounded env49135 := by
  intro p hp
  have h : env49135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49134_49135 : H12AffineEnvironment.transform 5 17 env49134 = env49135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49134 == env49135) = true)

theorem identity49135 : scanCanonicalize (H12AffineFastState.compose env49135 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound49135 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env49136 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3329,389,2048,0,263,2065,2340,1024,1,3345,33,153,138,269,16,2049,2065,3465,2477,1285,169,256,168,2185,513]

theorem envBound49136 : H12AffineFastState.Bounded env49136 := by
  intro p hp
  have h : env49136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49135_49136 : H12AffineEnvironment.transform 11 3329 env49135 = env49136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env49135 == env49136) = true)

theorem identity49136 : scanCanonicalize (H12AffineFastState.compose env49136 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49136 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49137 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2357,389,2048,0,263,2065,2340,52,1,2341,33,153,138,269,16,2049,2065,2493,2477,305,169,256,168,2185,513]

theorem envBound49137 : H12AffineFastState.Bounded env49137 := by
  intro p hp
  have h : env49137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49136_49137 : H12AffineEnvironment.transform 9 52 env49136 = env49137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49136 == env49137) = true)

theorem identity49137 : scanCanonicalize (H12AffineFastState.compose env49137 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound49137 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env49138 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,2201,41,2048,0,171,2065,2184,52,1,2185,33,153,138,161,16,2049,2065,2065,2049,157,169,172,168,2185,513]

theorem envBound49138 : H12AffineFastState.Bounded env49138 := by
  intro p hp
  have h : env49138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49137_49138 : H12AffineEnvironment.transform 7 172 env49137 = env49138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49137 == env49138) = true)

theorem identity49138 : scanCanonicalize (H12AffineFastState.compose env49138 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49138 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env49139 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2065,41,2048,0,35,2065,2048,52,1,2049,33,17,2,41,16,2049,2065,2065,2049,21,33,36,32,2049,513]

theorem envBound49139 : H12AffineFastState.Bounded env49139 := by
  intro p hp
  have h : env49139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49138_49139 : H12AffineEnvironment.transform 6 8 env49138 = env49139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49138 == env49139) = true)

theorem identity49139 : scanCanonicalize (H12AffineFastState.compose env49139 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound49139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49140 : List Nat := [2,4,8,16,32,17,8,36,1,52,2048,2065,41,2048,0,35,2065,2048,52,1,2049,33,17,2,41,16,2049,2065,2065,2049,21,33,36,32,2049,0]

theorem envBound49140 : H12AffineFastState.Bounded env49140 := by
  intro p hp
  have h : env49140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49139_49140 : H12AffineEnvironment.transform 8 1 env49139 = env49140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env49139 == env49140) = true)

theorem identity49140 : scanCanonicalize (H12AffineFastState.compose env49140 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound49140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49141 : List Nat := [2,4,8,16,32,17,8,36,1,52,10,27,41,10,0,35,27,10,52,1,11,33,17,2,41,16,11,27,27,11,21,33,36,32,11,0]

theorem envBound49141 : H12AffineFastState.Bounded env49141 := by
  intro p hp
  have h : env49141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49140_49141 : H12AffineEnvironment.transform 10 10 env49140 = env49141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env49140 == env49141) = true)

def env49142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,16777216,8328,65,16959643,18973837,2596346,67754,17190074,19113457,256,19270662,19328418,17263469]

theorem envBound49142 : H12AffineFastState.Bounded env49142 := by
  intro p hp
  have h : env49142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49006_49142 : H12AffineEnvironment.transform 21 180273 env49006 = env49142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env49006 == env49142) = true)

def env49143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,499128,8328,65,349475,2496821,2596346,67754,119042,2373705,256,2199998,2191386,63189]

theorem envBound49143 : H12AffineFastState.Bounded env49143 := by
  intro p hp
  have h : env49143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49142_49143 : H12AffineEnvironment.transform 23 499128 env49142 = env49143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env49142 == env49143) = true)

def env49144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510123,499128,8328,65,349475,395637,495034,67754,119042,272393,256,98814,90202,63189]

theorem envBound49144 : H12AffineFastState.Bounded env49144 := by
  intro p hp
  have h : env49144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49143_49144 : H12AffineEnvironment.transform 20 4160 env49143 = env49144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49143 == env49144) = true)

theorem identity49144 : scanCanonicalize (H12AffineFastState.compose env49144 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound49144 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,180273,400500,412007,8328,65,295420,395637,416101,56437,1501,272393,256,21793,46213,63189]

theorem envBound49145 : H12AffineFastState.Bounded env49145 := by
  intro p hp
  have h : env49145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49144_49145 : H12AffineEnvironment.transform 15 54495 env49144 = env49145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env49144 == env49145) = true)

def env49146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180273,400500,412007,8192,65,295284,395637,416101,56437,1365,272393,256,21793,46093,63069]

theorem envBound49146 : H12AffineFastState.Bounded env49146 := by
  intro p hp
  have h : env49146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1