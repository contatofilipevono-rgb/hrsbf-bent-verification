import H12CloudChart1Data054

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity13811 : scanCanonicalize (H12AffineFastState.compose env13811 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13811 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13812 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,17,40,0,1,35,17,1,53,0,0,33,17,3,40,16,0,16,16,1,21,33,37,33,1,513]

theorem envBound13812 : H12AffineFastState.Bounded env13812 := by
  intro p hp
  have h : env13812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13811_13812 : H12AffineEnvironment.transform 9 52 env13811 = env13812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13811 == env13812) = true)

theorem identity13812 : scanCanonicalize (H12AffineFastState.compose env13812 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13813 : List Nat := [2,4,8,16,32,17,8,36,32,52,1,17,40,0,1,35,17,1,53,0,0,33,17,3,40,16,0,16,16,1,21,33,37,33,1,33]

theorem envBound13813 : H12AffineFastState.Bounded env13813 := by
  intro p hp
  have h : env13813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13812_13813 : H12AffineEnvironment.transform 8 32 env13812 = env13813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13812 == env13813) = true)

theorem identity13813 : scanCanonicalize (H12AffineFastState.compose env13813 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13813 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13814 : List Nat := [2,4,8,16,1,17,8,5,1,21,1,17,9,0,1,2,17,1,20,0,0,0,17,3,9,16,0,16,16,1,21,0,4,0,1,0]

theorem envBound13814 : H12AffineFastState.Bounded env13814 := by
  intro p hp
  have h : env13814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13813_13814 : H12AffineEnvironment.transform 4 1 env13813 = env13814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13813 == env13814) = true)

def env13815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155533,2114883,8192,65,4409703,115014,45404,2231332,75103,4268042,257,2188651,2196550,513]

theorem envBound13815 : H12AffineFastState.Bounded env13815 := by
  intro p hp
  have h : env13815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13786_13815 : H12AffineEnvironment.transform 22 2155533 env13786 = env13815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env13786 == env13815) = true)

def env13816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114883,8192,65,215367,115014,45404,2231332,75103,73770,257,2188651,2196550,513]

theorem envBound13816 : H12AffineFastState.Bounded env13816 := by
  intro p hp
  have h : env13816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13815_13816 : H12AffineEnvironment.transform 21 32 env13815 = env13816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13815 == env13816) = true)

def env13817 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114835,8192,17,215319,114966,45324,2231332,75023,73770,257,2188603,2196502,513]

theorem envBound13817 : H12AffineFastState.Bounded env13817 := by
  intro p hp
  have h : env13817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13816_13817 : H12AffineEnvironment.transform 5 16 env13816 = env13817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13816 == env13817) = true)

theorem identity13817 : scanCanonicalize (H12AffineFastState.compose env13817 (packedSelected [14,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound13817 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env13818 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58396,32,17,41231,8192,17,215319,114966,45324,190520,75023,73770,257,98599,90122,513]

theorem envBound13818 : H12AffineFastState.Bounded env13818 := by
  intro p hp
  have h : env13818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13817_13818 : H12AffineEnvironment.transform 20 58396 env13817 = env13818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env13817 == env13818) = true)

theorem identity13818 : scanCanonicalize (H12AffineFastState.compose env13818 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound13818 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env13819 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10280,1025,32769,58396,32,17,41231,8192,17,190749,24860,45324,190520,34053,32800,257,8493,49152,513]

theorem envBound13819 : H12AffineFastState.Bounded env13819 := by
  intro p hp
  have h : env13819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13818_13819 : H12AffineEnvironment.transform 15 40970 env13818 = env13819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env13818 == env13819) = true)

theorem identity13819 : scanCanonicalize (H12AffineFastState.compose env13819 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13819 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13820 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1025,32769,58396,32,17,41231,8192,17,43276,24860,45324,43049,34053,32800,257,8493,49152,513]

theorem envBound13820 : H12AffineFastState.Bounded env13820 := by
  intro p hp
  have h : env13820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13819_13820 : H12AffineEnvironment.transform 16 16401 env13819 = env13820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13819 == env13820) = true)

theorem identity13820 : scanCanonicalize (H12AffineFastState.compose env13820 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound13820 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13821 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,262,16401,10280,1025,8461,17680,32,17,3,8192,17,2048,24860,4096,2341,9225,8492,257,8493,24844,513]

theorem envBound13821 : H12AffineFastState.Bounded env13821 := by
  intro p hp
  have h : env13821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13820_13821 : H12AffineEnvironment.transform 14 8460 env13820 = env13821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env13820 == env13821) = true)

theorem identity13821 : scanCanonicalize (H12AffineFastState.compose env13821 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13821 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13822 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1025,0,17680,32,17,3,269,17,2048,16401,4096,2341,1284,33,257,32,16385,513]

theorem envBound13822 : H12AffineFastState.Bounded env13822 := by
  intro p hp
  have h : env13822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13821_13822 : H12AffineEnvironment.transform 12 269 env13821 = env13822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13821 == env13822) = true)

theorem identity13822 : scanCanonicalize (H12AffineFastState.compose env13822 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13823 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,269,16384,1,262,16401,2341,20,0,16645,32,17,3,269,17,2048,16401,4096,2341,273,33,257,32,16385,513]

theorem envBound13823 : H12AffineFastState.Bounded env13823 := by
  intro p hp
  have h : env13823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13822_13823 : H12AffineEnvironment.transform 9 21 env13822 = env13823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13822 == env13823) = true)

theorem identity13823 : scanCanonicalize (H12AffineFastState.compose env13823 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound13823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13824 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,269,4372,1,262,4357,2341,20,0,4113,32,17,3,269,17,2048,4357,4096,2341,273,33,257,32,4373,513]

theorem envBound13824 : H12AffineFastState.Bounded env13824 := by
  intro p hp
  have h : env13824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13823_13824 : H12AffineEnvironment.transform 13 4372 env13823 = env13824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env13823 == env13824) = true)

theorem identity13824 : scanCanonicalize (H12AffineFastState.compose env13824 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound13824 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13825 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,560,269,804,1,262,821,2341,20,0,545,32,17,3,269,17,2048,821,560,2341,273,33,257,32,805,513]

theorem envBound13825 : H12AffineFastState.Bounded env13825 := by
  intro p hp
  have h : env13825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13824_13825 : H12AffineEnvironment.transform 11 560 env13824 = env13825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env13824 == env13825) = true)

theorem identity13825 : scanCanonicalize (H12AffineFastState.compose env13825 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound13825 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13826 : List Nat := [2,4,8,16,32,16,8,256,512,21,820,560,269,804,1,262,821,529,20,0,545,32,17,3,269,17,820,821,560,529,273,33,257,32,805,513]

theorem envBound13826 : H12AffineFastState.Bounded env13826 := by
  intro p hp
  have h : env13826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13825_13826 : H12AffineEnvironment.transform 10 820 env13825 = env13826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env13825 == env13826) = true)

theorem identity13826 : scanCanonicalize (H12AffineFastState.compose env13826 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13826 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13827 : List Nat := [2,4,8,16,32,16,8,37,512,21,529,560,40,513,1,35,528,529,20,0,545,32,17,3,40,17,529,528,560,529,52,33,36,32,512,513]

theorem envBound13827 : H12AffineFastState.Bounded env13827 := by
  intro p hp
  have h : env13827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13826_13827 : H12AffineEnvironment.transform 7 37 env13826 = env13827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13826 == env13827) = true)

theorem identity13827 : scanCanonicalize (H12AffineFastState.compose env13827 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13827 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13828 : List Nat := [2,4,8,16,0,16,8,5,512,21,529,528,8,513,1,3,528,529,20,0,513,0,17,3,8,17,529,528,528,529,20,1,4,0,512,513]

theorem envBound13828 : H12AffineFastState.Bounded env13828 := by
  intro p hp
  have h : env13828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13827_13828 : H12AffineEnvironment.transform 4 0 env13827 = env13828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13827 == env13828) = true)

theorem identity13828 : scanCanonicalize (H12AffineFastState.compose env13828 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13829 : List Nat := [2,4,8,0,0,0,8,5,512,5,513,512,8,513,1,3,512,513,4,0,513,0,1,3,8,1,513,512,512,513,4,1,4,0,512,513]

theorem envBound13829 : H12AffineFastState.Bounded env13829 := by
  intro p hp
  have h : env13829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13828_13829 : H12AffineEnvironment.transform 3 0 env13828 = env13829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13828 == env13829) = true)

def env13830 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114834,8192,16,215318,114967,45325,2231332,75022,73770,257,2188602,2196503,513]

theorem envBound13830 : H12AffineFastState.Bounded env13830 := by
  intro p hp
  have h : env13830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13816_13830 : H12AffineEnvironment.transform 5 17 env13816 = env13830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13816 == env13830) = true)

theorem identity13830 : scanCanonicalize (H12AffineFastState.compose env13830 (packedSelected [14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound13830 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env13831 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33031,131072,10280,1025,32769,2097152,32,2155533,2114834,8192,16,182289,16400,45325,2231332,41993,41261,257,2155581,2098448,513]

theorem envBound13831 : H12AffineFastState.Bounded env13831 := by
  intro p hp
  have h : env13831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13830_13831 : H12AffineEnvironment.transform 15 33031 env13830 = env13831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env13830 == env13831) = true)

theorem identity13831 : scanCanonicalize (H12AffineFastState.compose env13831 (packedSelected [11,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13831 : packedSelected [11,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13832 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33031,131072,2341,1025,32769,2097152,32,2147584,2114834,269,16,182289,16400,36864,2231332,34052,32800,257,2147632,2098448,513]

theorem envBound13832 : H12AffineFastState.Bounded env13832 := by
  intro p hp
  have h : env13832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13831_13832 : H12AffineEnvironment.transform 12 269 env13831 = env13832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13831 == env13832) = true)

theorem identity13832 : scanCanonicalize (H12AffineFastState.compose env13832 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13832 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env13833 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,131072,2341,1025,0,2097152,32,2114817,2114834,269,16,149520,16400,4097,2231332,1285,33,257,2114865,2098448,513]

theorem envBound13833 : H12AffineFastState.Bounded env13833 := by
  intro p hp
  have h : env13833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13832_13833 : H12AffineEnvironment.transform 14 1 env13832 = env13833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13832 == env13833) = true)

def env13834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155533,2114883,8192,65,215366,115014,45404,2231332,75103,73771,257,2188651,2196550,513]

theorem envBound13834 : H12AffineFastState.Bounded env13834 := by
  intro p hp
  have h : env13834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13815_13834 : H12AffineEnvironment.transform 21 33 env13815 = env13834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13815 == env13834) = true)

theorem identity13834 : scanCanonicalize (H12AffineFastState.compose env13834 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound13834 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58396,33,17,41311,8192,65,215366,115014,45404,190520,75103,73771,257,98679,90202,513]

theorem envBound13835 : H12AffineFastState.Bounded env13835 := by
  intro p hp
  have h : env13835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13834_13835 : H12AffineEnvironment.transform 20 58396 env13834 = env13835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env13834 == env13835) = true)

theorem identity13835 : scanCanonicalize (H12AffineFastState.compose env13835 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13835 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env13836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,33,17,41311,8192,65,67927,115014,45404,43049,75103,73771,257,98679,90202,513]

theorem envBound13836 : H12AffineFastState.Bounded env13836 := by
  intro p hp
  have h : env13836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13835_13836 : H12AffineEnvironment.transform 16 16401 env13835 = env13836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13835 == env13836) = true)

theorem identity13836 : scanCanonicalize (H12AffineFastState.compose env13836 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound13836 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env13837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8283,16401,10280,1025,32769,58396,33,17,41311,8192,65,10508,57629,45404,43049,1284,112,257,41260,16385,513]

theorem envBound13837 : H12AffineFastState.Bounded env13837 := by
  intro p hp
  have h : env13837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13836_13837 : H12AffineEnvironment.transform 15 8283 env13836 = env13837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env13836 == env13837) = true)

theorem identity13837 : scanCanonicalize (H12AffineFastState.compose env13837 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound13837 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env13838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8283,16401,10280,1025,81,25676,33,17,8463,8192,65,10508,24909,12556,10361,1284,112,257,8572,16385,513]

theorem envBound13838 : H12AffineFastState.Bounded env13838 := by
  intro p hp
  have h : env13838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13837_13838 : H12AffineEnvironment.transform 14 80 env13837 = env13838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env13837 == env13838) = true)

theorem identity13838 : scanCanonicalize (H12AffineFastState.compose env13838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,80,263,16401,2420,1025,81,17680,33,17,83,348,65,2128,16401,4176,2341,1284,112,257,32,16385,513]

theorem envBound13839 : H12AffineFastState.Bounded env13839 := by
  intro p hp
  have h : env13839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13838_13839 : H12AffineEnvironment.transform 12 348 env13838 = env13839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13838 == env13839) = true)

def env13840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616168,18973700,10507601,8579112,25265169,23160136,257,27378724,27337992,25207630]

theorem envBound13840 : H12AffineFastState.Bounded env13840 := by
  intro p hp
  have h : env13840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13784_13840 : H12AffineEnvironment.transform 6 9 env13784 = env13840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13784 == env13840) = true)

theorem identity13840 : scanCanonicalize (H12AffineFastState.compose env13840 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound13840 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,8388626,8193,65,4450362,10585110,10507601,8579112,99331,14771546,257,2212918,2172186,41820]

theorem envBound13841 : H12AffineFastState.Bounded env13841 := by
  intro p hp
  have h : env13841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13840_13841 : H12AffineEnvironment.transform 23 8388626 env13840 = env13841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env13840 == env13841) = true)

theorem identity13841 : scanCanonicalize (H12AffineFastState.compose env13841 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound13841 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env13842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,2097152,4194304,8388608,8388626,8193,65,4229152,10585110,10507601,8489010,99331,14771546,257,2212918,2172186,41820]

theorem envBound13842 : H12AffineFastState.Bounded env13842 := by
  intro p hp
  have h : env13842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13841_13842 : H12AffineEnvironment.transform 16 90138 env13841 = env13842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env13841 == env13842) = true)

theorem identity13842 : scanCanonicalize (H12AffineFastState.compose env13842 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound13842 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env13843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,2097152,4194304,4194352,4194338,8193,65,4229152,6390822,6313313,4294658,99331,2188650,257,2212918,2172186,41820]

theorem envBound13843 : H12AffineFastState.Bounded env13843 := by
  intro p hp
  have h : env13843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13842_13843 : H12AffineEnvironment.transform 22 4194352 env13842 = env13843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env13842 == env13843) = true)

theorem identity13843 : scanCanonicalize (H12AffineFastState.compose env13843 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13843 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1025,8540,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6313313,4270431,75102,2188650,257,2188651,2172186,513]

theorem envBound13844 : H12AffineFastState.Bounded env13844 := by
  intro p hp
  have h : env13844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13843_13844 : H12AffineEnvironment.transform 14 8541 env13843 = env13844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13843 == env13844) = true)

theorem identity13844 : scanCanonicalize (H12AffineFastState.compose env13844 (packedSelected [2,4,6,9,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 19525) := by decide +kernel

theorem selectedBound13844 : packedSelected [2,4,6,9,17,18] rootPS < 2^1333 := by decide +kernel

def env13845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1025,8540,2097152,19525,19573,19559,8193,65,25912,2189630,2103588,91418,75102,2188650,257,2188651,2172186,513]

theorem envBound13845 : H12AffineFastState.Bounded env13845 := by
  intro p hp
  have h : env13845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13844_13845 : H12AffineEnvironment.transform 21 19525 env13844 = env13845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 19525 env13844 == env13845) = true)

theorem identity13845 : scanCanonicalize (H12AffineFastState.compose env13845 (packedSelected [3,5,10,11,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound13845 : packedSelected [3,5,10,11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env13846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28699,4097,10281,1025,8540,2097152,19525,19573,19559,8193,65,25912,2103589,2103588,5377,21829,2102641,257,2102640,2118913,513]

theorem envBound13846 : H12AffineFastState.Bounded env13846 := by
  intro p hp
  have h : env13846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13845_13846 : H12AffineEnvironment.transform 15 28699 env13845 = env13846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env13845 == env13846) = true)

theorem identity13846 : scanCanonicalize (H12AffineFastState.compose env13846 (packedSelected [0,3,5,8,9,10,12,14,17,24] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound13846 : packedSelected [0,3,5,8,9,10,12,14,17,24] rootPS < 2^1333 := by decide +kernel

def env13847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28699,4097,10281,1025,8540,5456,19525,19573,19559,8193,65,25912,3189,3188,5377,21829,33,257,32,16465,513]

theorem envBound13847 : H12AffineFastState.Bounded env13847 := by
  intro p hp
  have h : env13847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13846_13847 : H12AffineEnvironment.transform 20 5456 env13846 = env13847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env13846 == env13847) = true)

theorem identity13847 : scanCanonicalize (H12AffineFastState.compose env13847 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound13847 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4097,10281,1025,8540,5456,7253,7269,7287,8193,65,13608,3189,3188,5377,1365,33,257,32,4161,513]

theorem envBound13848 : H12AffineFastState.Bounded env13848 := by
  intro p hp
  have h : env13848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13847_13848 : H12AffineEnvironment.transform 13 4112 env13847 = env13848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env13847 == env13848) = true)

theorem identity13848 : scanCanonicalize (H12AffineFastState.compose env13848 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13848 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,0,342,4097,2420,1025,1,5456,7253,7269,7287,348,65,5237,3189,3188,5377,1365,33,257,32,4161,513]

theorem envBound13849 : H12AffineFastState.Bounded env13849 := by
  intro p hp
  have h : env13849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13848_13849 : H12AffineEnvironment.transform 12 349 env13848 = env13849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13848 == env13849) = true)

theorem identity13849 : scanCanonicalize (H12AffineFastState.compose env13849 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound13849 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,349,2128,0,342,2113,2420,1025,1,3344,1045,1061,1079,348,65,3125,3189,3188,3393,1365,33,257,32,2049,513]

theorem envBound13850 : H12AffineFastState.Bounded env13850 := by
  intro p hp
  have h : env13850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13849_13850 : H12AffineEnvironment.transform 11 2112 env13849 = env13850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env13849 == env13850) = true)

theorem identity13850 : scanCanonicalize (H12AffineFastState.compose env13850 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13850 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13851 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,269,2048,0,262,2065,2340,1025,1,3344,1045,1061,1079,268,17,3125,3109,3108,3345,1285,33,257,32,2049,513]

theorem envBound13851 : H12AffineFastState.Bounded env13851 := by
  intro p hp
  have h : env13851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13850_13851 : H12AffineEnvironment.transform 5 16 env13850 = env13851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13850 == env13851) = true)

theorem identity13851 : scanCanonicalize (H12AffineFastState.compose env13851 (packedSelected [1,4,5,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13851 : packedSelected [1,4,5,7,15] rootPS < 2^1333 := by decide +kernel

def env13852 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,269,2048,0,262,2065,2340,53,1,2340,33,17,3,268,17,2049,2065,2064,2341,305,33,257,32,2049,513]

theorem envBound13852 : H12AffineFastState.Bounded env13852 := by
  intro p hp
  have h : env13852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13851_13852 : H12AffineEnvironment.transform 9 52 env13851 = env13852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13851 == env13852) = true)

theorem identity13852 : scanCanonicalize (H12AffineFastState.compose env13852 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound13852 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13853 : List Nat := [2,4,8,16,32,16,9,256,512,52,303,319,269,303,0,262,318,11,53,1,11,33,17,3,268,17,302,318,319,10,305,33,257,32,302,513]

theorem envBound13853 : H12AffineFastState.Bounded env13853 := by
  intro p hp
  have h : env13853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13852_13853 : H12AffineEnvironment.transform 10 303 env13852 = env13853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env13852 == env13853) = true)

def env13854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound13854 : H12AffineFastState.Bounded env13854 := by
  intro p hp
  have h : env13854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13592_13854 : H12AffineEnvironment.transform 26 30393345 env13592 = env13854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env13592 == env13854) = true)

def env13855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound13855 : H12AffineFastState.Bounded env13855 := by
  intro p hp
  have h : env13855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13854_13855 : H12AffineEnvironment.transform 18 1024 env13854 = env13855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13854 == env13855) = true)

theorem identity13855 : scanCanonicalize (H12AffineFastState.compose env13855 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534881) := by decide +kernel

theorem selectedBound13855 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,16777216,8328,65,23162336,18973836,456880,2125280,19343856,23160256,256,17262924,17271017,19271207]

theorem envBound13856 : H12AffineFastState.Bounded env13856 := by
  intro p hp
  have h : env13856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13855_13856 : H12AffineEnvironment.transform 22 2534881 env13855 = env13856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534881 env13855 == env13856) = true)

def env13857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,474220,8328,65,6705548,2537696,456880,2125280,2102684,6707628,256,21792,46213,2175563]

theorem envBound13857 : H12AffineFastState.Bounded env13857 := by
  intro p hp
  have h : env13857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13856_13857 : H12AffineEnvironment.transform 23 474220 env13856 = env13857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474220 env13856 == env13857) = true)

def env13858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101329,98780,8328,65,6351932,2098512,17664,2125280,2102684,6349852,256,21792,46213,2175563]

theorem envBound13858 : H12AffineFastState.Bounded env13858 := by
  intro p hp
  have h : env13858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13857_13858 : H12AffineEnvironment.transform 17 179632 env13857 = env13858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env13857 == env13858) = true)

def env13859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,17,98780,8328,65,4258940,5392,17664,32160,1500,4256860,256,21792,46213,74251]

theorem envBound13859 : H12AffineFastState.Bounded env13859 := by
  intro p hp
  have h : env13859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13858_13859 : H12AffineEnvironment.transform 20 4160 env13858 = env13859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13858 == env13859) = true)

theorem identity13859 : scanCanonicalize (H12AffineFastState.compose env13859 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound13859 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,213486,17,98780,8328,65,245138,5392,17664,32160,1500,243122,256,21792,46213,74251]

theorem envBound13860 : H12AffineFastState.Bounded env13860 := by
  intro p hp
  have h : env13860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13859_13860 : H12AffineEnvironment.transform 21 213486 env13859 = env13860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env13859 == env13860) = true)

def env13861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,213350,17,98644,8192,65,245018,5392,17664,32040,1364,243002,256,21792,46093,74251]

theorem envBound13861 : H12AffineFastState.Bounded env13861 := by
  intro p hp
  have h : env13861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13860_13861 : H12AffineEnvironment.transform 6 8 env13860 = env13861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13860 == env13861) = true)

theorem identity13861 : scanCanonicalize (H12AffineFastState.compose env13861 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13861 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4160,156012,17,41310,8192,65,171280,5392,17664,32040,1364,169264,256,21792,46093,513]

theorem envBound13862 : H12AffineFastState.Bounded env13862 := by
  intro p hp
  have h : env13862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13861_13862 : H12AffineEnvironment.transform 15 8202 env13861 = env13862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13861 == env13862) = true)

theorem identity13862 : scanCanonicalize (H12AffineFastState.compose env13862 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound13862 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64808,1024,32769,4160,8572,17,41310,8192,65,56576,5392,17664,32040,1364,54560,256,21792,46093,513]

theorem envBound13863 : H12AffineFastState.Bounded env13863 := by
  intro p hp
  have h : env13863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13862_13863 : H12AffineEnvironment.transform 16 16400 env13862 = env13863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env13862 == env13863) = true)

theorem identity13863 : scanCanonicalize (H12AffineFastState.compose env13863 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13863 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,23668,1024,8541,4160,8572,17,2,8192,65,31836,5392,17664,32040,1364,29820,256,21792,5457,513]

theorem envBound13864 : H12AffineFastState.Bounded env13864 := by
  intro p hp
  have h : env13864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13863_13864 : H12AffineEnvironment.transform 14 8540 env13863 = env13864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13863 == env13864) = true)

theorem identity13864 : scanCanonicalize (H12AffineFastState.compose env13864 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound13864 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8202,13341,10361,1024,8541,4160,8572,17,2,8192,65,2129,5392,12557,2341,1364,113,256,8493,5457,513]

theorem envBound13865 : H12AffineFastState.Bounded env13865 := by
  intro p hp
  have h : env13865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13864_13865 : H12AffineEnvironment.transform 13 13325 env13864 = env13865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env13864 == env13865) = true)

theorem identity13865 : scanCanonicalize (H12AffineFastState.compose env13865 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13865 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,262,5393,2421,1024,81,4160,112,17,2,268,65,2129,5392,4097,2341,1364,113,256,33,5457,513]

theorem envBound13866 : H12AffineFastState.Bounded env13866 := by
  intro p hp
  have h : env13866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13865_13866 : H12AffineEnvironment.transform 12 268 env13865 = env13866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13865 == env13866) = true)

theorem identity13866 : scanCanonicalize (H12AffineFastState.compose env13866 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1889) := by decide +kernel

theorem selectedBound13866 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1889,268,608,80,262,624,2421,1024,81,1825,112,17,2,268,65,2129,625,1888,2341,1364,113,256,33,560,513]

theorem envBound13867 : H12AffineFastState.Bounded env13867 := by
  intro p hp
  have h : env13867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13866_13867 : H12AffineEnvironment.transform 11 1889 env13866 = env13867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1889 env13866 == env13867) = true)

theorem identity13867 : scanCanonicalize (H12AffineFastState.compose env13867 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13868 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1841,268,560,0,262,544,2341,1024,1,1825,32,17,2,268,17,2049,545,1840,2341,1284,33,256,33,560,513]

theorem envBound13868 : H12AffineFastState.Bounded env13868 := by
  intro p hp
  have h : env13868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13867_13868 : H12AffineEnvironment.transform 5 16 env13867 = env13868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13867 == env13868) = true)

theorem identity13868 : scanCanonicalize (H12AffineFastState.compose env13868 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound13868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13869 : List Nat := [2,4,8,16,32,16,8,21,512,1024,2048,1572,25,560,0,19,544,2096,1024,1,1588,32,17,2,25,17,2049,545,1573,2096,1041,33,21,33,560,513]

theorem envBound13869 : H12AffineFastState.Bounded env13869 := by
  intro p hp
  have h : env13869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13868_13869 : H12AffineEnvironment.transform 7 21 env13868 = env13869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env13868 == env13869) = true)

theorem identity13869 : scanCanonicalize (H12AffineFastState.compose env13869 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13869 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13870 : List Nat := [2,4,8,16,32,16,8,21,49,1024,2048,1045,25,1,0,19,17,2096,1024,1,1029,32,17,2,25,17,2049,16,1044,2096,1041,33,21,33,1,48]

theorem envBound13870 : H12AffineFastState.Bounded env13870 := by
  intro p hp
  have h : env13870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13869_13870 : H12AffineEnvironment.transform 8 49 env13869 = env13870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13869 == env13870) = true)

theorem identity13870 : scanCanonicalize (H12AffineFastState.compose env13870 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound13870 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13871 : List Nat := [2,4,8,16,32,16,8,21,49,1024,17,1045,25,1,0,19,17,33,1024,1,1029,32,17,2,25,17,16,16,1044,33,1041,33,21,33,1,48]

theorem envBound13871 : H12AffineFastState.Bounded env13871 := by
  intro p hp
  have h : env13871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13870_13871 : H12AffineEnvironment.transform 10 17 env13870 = env13871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13870 == env13871) = true)

theorem identity13871 : scanCanonicalize (H12AffineFastState.compose env13871 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound13871 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13872 : List Nat := [2,4,8,16,32,16,8,21,49,21,17,0,25,1,0,19,17,33,21,1,16,32,17,2,25,17,16,16,1,33,4,33,21,33,1,48]

theorem envBound13872 : H12AffineFastState.Bounded env13872 := by
  intro p hp
  have h : env13872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13871_13872 : H12AffineEnvironment.transform 9 21 env13871 = env13872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13871 == env13872) = true)

theorem identity13872 : scanCanonicalize (H12AffineFastState.compose env13872 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13872 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env13873 : List Nat := [2,4,8,16,1,16,8,21,16,21,17,0,25,1,0,19,17,0,21,1,16,1,17,2,25,17,16,16,1,0,4,0,21,0,1,17]

theorem envBound13873 : H12AffineFastState.Bounded env13873 := by
  intro p hp
  have h : env13873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13872_13873 : H12AffineEnvironment.transform 4 1 env13872 = env13873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13872 == env13873) = true)

theorem identity13873 : scanCanonicalize (H12AffineFastState.compose env13873 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13873 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13874 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,0,8,1,0,2,0,0,4,1,1,1,0,2,8,0,1,1,1,0,4,0,4,0,1,0]

theorem envBound13874 : H12AffineFastState.Bounded env13874 := by
  intro p hp
  have h : env13874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13873_13874 : H12AffineEnvironment.transform 3 1 env13873 = env13874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13873 == env13874) = true)

theorem identity13874 : scanCanonicalize (H12AffineFastState.compose env13874 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13874 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13875 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,0,2,1,0,2,0,0,4,1,1,1,0,2,2,0,1,1,1,0,4,0,4,0,1,0]

theorem envBound13875 : H12AffineFastState.Bounded env13875 := by
  intro p hp
  have h : env13875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13874_13875 : H12AffineEnvironment.transform 2 2 env13874 = env13875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13874 == env13875) = true)

def env13876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,213351,17,98645,8193,65,245019,5392,17664,32041,1365,243003,256,21792,46092,74251]

theorem envBound13876 : H12AffineFastState.Bounded env13876 := by
  intro p hp
  have h : env13876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13860_13876 : H12AffineEnvironment.transform 6 9 env13860 = env13876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13860 == env13876) = true)

theorem identity13876 : scanCanonicalize (H12AffineFastState.compose env13876 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13876 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179513,1024,32769,4160,180273,17,3,8193,65,146509,5392,17664,32041,1365,144493,256,21792,46092,41821]

theorem envBound13877 : H12AffineFastState.Bounded env13877 := by
  intro p hp
  have h : env13877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13876_13877 : H12AffineEnvironment.transform 15 33110 env13876 = env13877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13876 == env13877) = true)

theorem identity13877 : scanCanonicalize (H12AffineFastState.compose env13877 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound13877 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16449,64888,1024,32769,4160,32880,17,3,8193,65,31756,5392,17664,32041,1365,29740,256,21792,46092,41821]

theorem envBound13878 : H12AffineFastState.Bounded env13878 := by
  intro p hp
  have h : env13878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13877_13878 : H12AffineEnvironment.transform 16 16449 env13877 = env13878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env13877 == env13878) = true)

theorem identity13878 : scanCanonicalize (H12AffineFastState.compose env13878 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound13878 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,293,115,16449,31837,1024,292,4160,341,17,3,8193,65,31756,5392,17664,32041,1365,29740,256,21792,13609,8824]

theorem envBound13879 : H12AffineFastState.Bounded env13879 := by
  intro p hp
  have h : env13879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13878_13879 : H12AffineEnvironment.transform 14 293 env13878 = env13879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env13878 == env13879) = true)

theorem identity13879 : scanCanonicalize (H12AffineFastState.compose env13879 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound13879 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env13880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,293,115,16449,23589,1024,292,4160,341,17,3,121,65,23668,5392,17664,23889,1365,21588,256,21792,5457,512]

theorem envBound13880 : H12AffineFastState.Bounded env13880 := by
  intro p hp
  have h : env13880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13879_13880 : H12AffineEnvironment.transform 12 120 env13879 = env13880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env13879 == env13880) = true)

theorem identity13880 : scanCanonicalize (H12AffineFastState.compose env13880 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13880 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,293,115,5172,2128,1024,292,4160,341,17,3,121,65,2049,5392,4469,2340,1365,33,256,341,5457,512]

theorem envBound13881 : H12AffineFastState.Bounded env13881 := by
  intro p hp
  have h : env13881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13880_13881 : H12AffineEnvironment.transform 13 5237 env13880 = env13881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13880 == env13881) = true)

theorem identity13881 : scanCanonicalize (H12AffineFastState.compose env13881 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound13881 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13882 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,9,5124,293,2,5172,2081,1024,292,4145,292,17,3,8,48,2049,5392,4356,2340,1316,33,256,292,5408,512]

theorem envBound13882 : H12AffineFastState.Bounded env13882 := by
  intro p hp
  have h : env13882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13881_13882 : H12AffineEnvironment.transform 5 49 env13881 = env13882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env13881 == env13882) = true)

theorem identity13882 : scanCanonicalize (H12AffineFastState.compose env13882 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13882 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13883 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,9,5124,1,2,5172,2081,1024,0,4145,0,17,3,8,48,2049,5172,4128,2048,1024,33,36,0,5124,512]

theorem envBound13883 : H12AffineFastState.Bounded env13883 := by
  intro p hp
  have h : env13883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13882_13883 : H12AffineEnvironment.transform 7 36 env13882 = env13883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13882 == env13883) = true)

theorem identity13883 : scanCanonicalize (H12AffineFastState.compose env13883 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13883 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13884 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,1,2,5140,2049,1024,0,4113,0,17,3,8,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound13884 : H12AffineFastState.Bounded env13884 := by
  intro p hp
  have h : env13884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13883_13884 : H12AffineEnvironment.transform 4 0 env13883 = env13884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13883 == env13884) = true)

def env13885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,16,98780,8328,65,4258941,5393,17664,32161,1501,4256861,256,21792,46213,74250]

theorem envBound13885 : H12AffineFastState.Bounded env13885 := by
  intro p hp
  have h : env13885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13858_13885 : H12AffineEnvironment.transform 20 4161 env13858 = env13885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13858 == env13885) = true)

theorem identity13885 : scanCanonicalize (H12AffineFastState.compose env13885 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound13885 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179632,1024,32769,4161,4194304,16,21762,8328,65,4258941,5393,17664,32161,1501,4256861,256,21792,46213,63188]

theorem envBound13886 : H12AffineFastState.Bounded env13886 := by
  intro p hp
  have h : env13886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13885_13886 : H12AffineEnvironment.transform 15 54494 env13885 = env13886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env13885 == env13886) = true)

def env13887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,4194304,16,21762,8192,65,4258941,5393,17664,32041,1365,4256861,256,21792,46093,63068]

theorem envBound13887 : H12AffineFastState.Bounded env13887 := by
  intro p hp
  have h : env13887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13886_13887 : H12AffineEnvironment.transform 6 8 env13886 = env13887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13886 == env13887) = true)

theorem identity13887 : scanCanonicalize (H12AffineFastState.compose env13887 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound13887 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,56437,1024,32769,4161,4194304,16,21762,8192,65,4258941,5393,17664,32041,1365,4256861,256,21792,46093,63068]

theorem envBound13888 : H12AffineFastState.Bounded env13888 := by
  intro p hp
  have h : env13888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13887_13888 : H12AffineEnvironment.transform 16 24909 env13887 = env13888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env13887 == env13888) = true)

theorem identity13888 : scanCanonicalize (H12AffineFastState.compose env13888 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound13888 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env13889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1024,29788,4161,4194304,16,21762,8192,65,4196384,5393,17664,32041,1365,4194304,256,21792,16464,513]

theorem envBound13889 : H12AffineFastState.Bounded env13889 := by
  intro p hp
  have h : env13889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13888_13889 : H12AffineEnvironment.transform 14 29789 env13888 = env13889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env13888 == env13889) = true)

theorem identity13889 : scanCanonicalize (H12AffineFastState.compose env13889 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound13889 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1024,29788,4161,8493,16,21762,8192,65,10509,5393,17664,32041,1365,8493,256,21792,16464,513]

theorem envBound13890 : H12AffineFastState.Bounded env13890 := by
  intro p hp
  have h : env13890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13889_13890 : H12AffineEnvironment.transform 21 8493 env13889 = env13890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env13889 == env13890) = true)

def env13891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,4194304,16,21762,8193,65,4258941,5393,17664,32040,1364,4256861,256,21792,46092,63069]

theorem envBound13891 : H12AffineFastState.Bounded env13891 := by
  intro p hp
  have h : env13891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13886_13891 : H12AffineEnvironment.transform 6 9 env13886 = env13891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13886 == env13891) = true)

theorem identity13891 : scanCanonicalize (H12AffineFastState.compose env13891 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound13891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32041,1024,32769,4161,4194304,16,21762,8193,65,4258941,5393,17664,32040,1364,4256861,256,21792,46092,63069]

theorem envBound13892 : H12AffineFastState.Bounded env13892 := by
  intro p hp
  have h : env13892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13891_13892 : H12AffineEnvironment.transform 16 49168 env13891 = env13892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env13891 == env13892) = true)

theorem identity13892 : scanCanonicalize (H12AffineFastState.compose env13892 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13892 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env13893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,49168,23668,1024,32769,4161,4194304,16,21762,348,65,4250912,5393,17664,23669,1364,4248832,256,21792,38225,55040]

theorem envBound13893 : H12AffineFastState.Bounded env13893 := by
  intro p hp
  have h : env13893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13892_13893 : H12AffineEnvironment.transform 12 349 env13892 = env13893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13892 == env13893) = true)

theorem identity13893 : scanCanonicalize (H12AffineFastState.compose env13893 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound13893 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,49168,23668,1024,32769,4161,33,16,21762,348,65,56577,5393,17664,23669,1364,54561,256,21792,38225,55040]

theorem envBound13894 : H12AffineFastState.Bounded env13894 := by
  intro p hp
  have h : env13894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13893_13894 : H12AffineEnvironment.transform 21 33 env13893 = env13894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13893 == env13894) = true)

theorem identity13894 : scanCanonicalize (H12AffineFastState.compose env13894 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13894 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33111,38160,2420,1024,32769,4161,33,16,2,348,65,34817,5393,4096,2421,1364,32801,256,32,38225,33280]

theorem envBound13895 : H12AffineFastState.Bounded env13895 := by
  intro p hp
  have h : env13895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13894_13895 : H12AffineEnvironment.transform 13 5376 env13894 = env13895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13894 == env13895) = true)

theorem identity13895 : scanCanonicalize (H12AffineFastState.compose env13895 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13895 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1296,1095,4096,2420,1024,1297,4161,33,16,2,348,65,3345,5393,4096,2421,1364,1329,256,32,4161,1808]

theorem envBound13896 : H12AffineFastState.Bounded env13896 := by
  intro p hp
  have h : env13896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13895_13896 : H12AffineEnvironment.transform 14 1296 env13895 = env13896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env13895 == env13896) = true)

theorem identity13896 : scanCanonicalize (H12AffineFastState.compose env13896 (packedSelected [4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound13896 : packedSelected [4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env13897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,357,4096,349,5376,1296,1095,4096,17,1024,1297,4161,33,16,2,348,65,1140,5393,4096,16,1364,1329,256,32,4161,1808]

theorem envBound13897 : H12AffineFastState.Bounded env13897 := by
  intro p hp
  have h : env13897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13896_13897 : H12AffineEnvironment.transform 10 357 env13896 = env13897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env13896 == env13897) = true)

theorem identity13897 : scanCanonicalize (H12AffineFastState.compose env13897 (packedSelected [0,1,3,5,6,7,8,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound13897 : packedSelected [0,1,3,5,6,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env13898 : List Nat := [2,4,8,16,32,64,9,256,512,256,357,4096,349,4096,16,327,4096,17,256,17,4161,33,16,2,348,65,372,4113,4096,16,84,49,256,32,4161,528]

theorem envBound13898 : H12AffineFastState.Bounded env13898 := by
  intro p hp
  have h : env13898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13897_13898 : H12AffineEnvironment.transform 9 256 env13897 = env13898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env13897 == env13898) = true)

theorem identity13898 : scanCanonicalize (H12AffineFastState.compose env13898 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound13898 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13899 : List Nat := [2,4,8,16,32,64,9,256,512,256,357,1,349,1,16,327,1,17,256,17,64,33,16,2,348,65,372,16,1,16,84,49,256,32,64,528]

theorem envBound13899 : H12AffineFastState.Bounded env13899 := by
  intro p hp
  have h : env13899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13898_13899 : H12AffineEnvironment.transform 11 1 env13898 = env13899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env13898 == env13899) = true)

theorem identity13899 : scanCanonicalize (H12AffineFastState.compose env13899 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound13899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13900 : List Nat := [2,4,8,16,32,64,9,52,512,52,81,1,105,1,16,115,1,17,52,17,64,33,16,2,104,65,64,16,1,16,84,49,52,32,64,528]

theorem envBound13900 : H12AffineFastState.Bounded env13900 := by
  intro p hp
  have h : env13900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13899_13900 : H12AffineEnvironment.transform 7 52 env13899 = env13900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env13899 == env13900) = true)

theorem identity13900 : scanCanonicalize (H12AffineFastState.compose env13900 (packedSelected [1,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound13900 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env13901 : List Nat := [2,4,8,16,32,0,9,52,512,52,17,1,41,1,16,51,1,17,52,17,0,33,16,2,40,1,0,16,1,16,20,49,52,32,0,528]

theorem envBound13901 : H12AffineFastState.Bounded env13901 := by
  intro p hp
  have h : env13901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13900_13901 : H12AffineEnvironment.transform 5 0 env13900 = env13901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env13900 == env13901) = true)

def env13902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101328,98781,8328,65,6351933,2098513,17665,2125280,2102684,6349853,256,21792,46213,2175563]

theorem envBound13902 : H12AffineFastState.Bounded env13902 := by
  intro p hp
  have h : env13902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13857_13902 : H12AffineEnvironment.transform 17 179633 env13857 = env13902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env13857 == env13902) = true)

def env13903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,16,98781,8328,65,4258941,5393,17665,32160,1500,4256861,256,21792,46213,74251]

theorem envBound13903 : H12AffineFastState.Bounded env13903 := by
  intro p hp
  have h : env13903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13902_13903 : H12AffineEnvironment.transform 20 4160 env13902 = env13903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13902 == env13903) = true)

theorem identity13903 : scanCanonicalize (H12AffineFastState.compose env13903 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13903 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4160,4194304,16,41431,8328,65,4258941,5393,17665,32160,1500,4256861,256,21792,46213,513]

theorem envBound13904 : H12AffineFastState.Bounded env13904 := by
  intro p hp
  have h : env13904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13903_13904 : H12AffineEnvironment.transform 15 8202 env13903 = env13904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13903 == env13904) = true)

theorem identity13904 : scanCanonicalize (H12AffineFastState.compose env13904 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound13904 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4160,169264,16,41431,8328,65,158029,5393,17665,32160,1500,156013,256,21792,46213,513]

theorem envBound13905 : H12AffineFastState.Bounded env13905 := by
  intro p hp
  have h : env13905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13904_13905 : H12AffineEnvironment.transform 21 169264 env13904 = env13905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env13904 == env13905) = true)

theorem identity13905 : scanCanonicalize (H12AffineFastState.compose env13905 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13905 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env13906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4160,169264,16,41311,8192,65,158029,5393,17665,32040,1364,156013,256,21792,46093,513]

theorem envBound13906 : H12AffineFastState.Bounded env13906 := by
  intro p hp
  have h : env13906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13905_13906 : H12AffineEnvironment.transform 6 8 env13905 = env13906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13905 == env13906) = true)

theorem identity13906 : scanCanonicalize (H12AffineFastState.compose env13906 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound13906 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10280,1024,32769,4160,33,16,41311,8192,65,64604,5393,17665,32040,1364,62588,256,21792,46093,513]

theorem envBound13907 : H12AffineFastState.Bounded env13907 := by
  intro p hp
  have h : env13907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13906_13907 : H12AffineEnvironment.transform 16 38161 env13906 = env13907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13906 == env13907) = true)

theorem identity13907 : scanCanonicalize (H12AffineFastState.compose env13907 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13907 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,5392,10280,1024,0,4160,33,16,8542,8192,65,31837,5393,17665,32040,1364,29821,256,21792,13324,513]

theorem envBound13908 : H12AffineFastState.Bounded env13908 := by
  intro p hp
  have h : env13908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13907_13908 : H12AffineEnvironment.transform 14 1 env13907 = env13908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13907 == env13908) = true)

theorem identity13908 : scanCanonicalize (H12AffineFastState.compose env13908 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound13908 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,5392,10280,1024,0,4160,33,16,8542,8192,65,2048,5393,12636,2421,1364,32,256,8573,13324,513]

theorem envBound13909 : H12AffineFastState.Bounded env13909 := by
  intro p hp
  have h : env13909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13908_13909 : H12AffineEnvironment.transform 13 13405 env13908 = env13909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env13908 == env13909) = true)

theorem identity13909 : scanCanonicalize (H12AffineFastState.compose env13909 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13909 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4160,33,16,3,349,65,2048,5393,4097,2421,1364,32,256,32,5457,513]

theorem envBound13910 : H12AffineFastState.Bounded env13910 := by
  intro p hp
  have h : env13910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13909_13910 : H12AffineEnvironment.transform 12 349 env13909 = env13910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13909 == env13910) = true)

theorem identity13910 : scanCanonicalize (H12AffineFastState.compose env13910 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13910 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13911 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4112,1,343,4096,2421,272,0,4160,33,16,3,349,65,2048,4097,4097,2421,68,32,256,32,4161,513]

theorem envBound13911 : H12AffineFastState.Bounded env13911 := by
  intro p hp
  have h : env13911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13910_13911 : H12AffineEnvironment.transform 9 272 env13910 = env13911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13910 == env13911) = true)

theorem identity13911 : scanCanonicalize (H12AffineFastState.compose env13911 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound13911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13912 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,49,349,33,1,343,49,2421,272,0,113,33,16,3,349,65,2048,48,48,2421,68,32,256,32,112,513]

theorem envBound13912 : H12AffineFastState.Bounded env13912 := by
  intro p hp
  have h : env13912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13911_13912 : H12AffineEnvironment.transform 11 49 env13911 = env13912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env13911 == env13912) = true)

theorem identity13912 : scanCanonicalize (H12AffineFastState.compose env13912 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13912 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13913 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,49,40,33,1,34,49,2048,101,0,113,33,16,3,40,65,2048,48,48,2048,68,32,117,32,112,513]

theorem envBound13913 : H12AffineFastState.Bounded env13913 := by
  intro p hp
  have h : env13913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13912_13913 : H12AffineEnvironment.transform 7 117 env13912 = env13913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13912 == env13913) = true)

theorem identity13913 : scanCanonicalize (H12AffineFastState.compose env13913 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound13913 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13914 : List Nat := [2,4,8,16,32,64,8,117,512,101,513,49,40,33,1,34,49,513,101,0,113,33,16,3,40,65,513,48,48,513,68,32,117,32,112,513]

theorem envBound13914 : H12AffineFastState.Bounded env13914 := by
  intro p hp
  have h : env13914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13913_13914 : H12AffineEnvironment.transform 10 513 env13913 = env13914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env13913 == env13914) = true)

def env13915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,17,98781,8328,65,4258940,5392,17665,32161,1501,4256860,256,21792,46213,74250]

theorem envBound13915 : H12AffineFastState.Bounded env13915 := by
  intro p hp
  have h : env13915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13902_13915 : H12AffineEnvironment.transform 20 4161 env13902 = env13915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13902 == env13915) = true)

theorem identity13915 : scanCanonicalize (H12AffineFastState.compose env13915 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound13915 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,243003,17,98781,8328,65,215367,5392,17665,32161,1501,213351,256,21792,46213,74250]

theorem envBound13916 : H12AffineFastState.Bounded env13916 := by
  intro p hp
  have h : env13916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13915_13916 : H12AffineEnvironment.transform 21 243003 env13915 = env13916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env13915 == env13916) = true)

def env13917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,243003,17,98645,8192,65,215367,5392,17665,32041,1365,213351,256,21792,46093,74250]

theorem envBound13917 : H12AffineFastState.Bounded env13917 := by
  intro p hp
  have h : env13917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13916_13917 : H12AffineEnvironment.transform 6 8 env13916 = env13917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13916 == env13917) = true)

theorem identity13917 : scanCanonicalize (H12AffineFastState.compose env13917 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13917 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169264,17,41310,8192,65,158028,5392,17665,32041,1365,156012,256,21792,46093,513]

theorem envBound13918 : H12AffineFastState.Bounded env13918 := by
  intro p hp
  have h : env13918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13917_13918 : H12AffineEnvironment.transform 15 8203 env13917 = env13918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13917 == env13918) = true)

theorem identity13918 : scanCanonicalize (H12AffineFastState.compose env13918 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13918 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64808,1024,32769,4161,54561,17,41310,8192,65,10589,5392,17665,32041,1365,8573,256,21792,46093,513]

theorem envBound13919 : H12AffineFastState.Bounded env13919 := by
  intro p hp
  have h : env13919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13918_13919 : H12AffineEnvironment.transform 16 16401 env13918 = env13919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13918 == env13919) = true)

theorem identity13919 : scanCanonicalize (H12AffineFastState.compose env13919 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13919 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,23669,1024,8540,4161,29820,17,3,8192,65,10589,5392,17665,32041,1365,8573,256,21792,5456,513]

theorem envBound13920 : H12AffineFastState.Bounded env13920 := by
  intro p hp
  have h : env13920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13919_13920 : H12AffineEnvironment.transform 14 8541 env13919 = env13920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13919 == env13920) = true)

theorem identity13920 : scanCanonicalize (H12AffineFastState.compose env13920 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound13920 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8541,8203,13673,10509,1024,8540,4161,260,17,3,8192,65,10589,5392,12409,2129,1365,8573,256,8280,5456,513]

theorem envBound13921 : H12AffineFastState.Bounded env13921 := by
  intro p hp
  have h : env13921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13920_13921 : H12AffineEnvironment.transform 13 13688 env13920 = env13921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env13920 == env13921) = true)

theorem identity13921 : scanCanonicalize (H12AffineFastState.compose env13921 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound13921 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13922 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12344,8541,8203,12329,10509,320,8540,4161,260,17,3,8192,65,10589,4176,12409,2129,21,8573,256,8280,4112,513]

theorem envBound13922 : H12AffineFastState.Bounded env13922 := by
  intro p hp
  have h : env13922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13921_13922 : H12AffineEnvironment.transform 9 320 env13921 = env13922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env13921 == env13922) = true)

theorem identity13922 : scanCanonicalize (H12AffineFastState.compose env13922 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound13922 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13923 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,4153,1,4452,4146,16,6452,320,4453,4161,260,17,3,4153,65,6500,4176,64,2129,21,4420,256,4193,4112,513]

theorem envBound13923 : H12AffineFastState.Bounded env13923 := by
  intro p hp
  have h : env13923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13922_13923 : H12AffineEnvironment.transform 12 4153 env13922 = env13923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env13922 == env13923) = true)

theorem identity13923 : scanCanonicalize (H12AffineFastState.compose env13923 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound13923 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env13924 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,4096,4153,1,4452,4146,16,4452,320,4453,4161,260,17,3,4153,65,4404,4176,64,1,21,4420,256,4193,4112,513]

theorem envBound13924 : H12AffineFastState.Bounded env13924 := by
  intro p hp
  have h : env13924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13923_13924 : H12AffineEnvironment.transform 10 80 env13923 = env13924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env13923 == env13924) = true)

theorem identity13924 : scanCanonicalize (H12AffineFastState.compose env13924 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13924 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13925 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,4096,4153,1,4160,4146,16,4160,100,4161,4161,32,17,3,4153,65,4112,4176,64,1,21,4192,36,4193,4112,513]

theorem envBound13925 : H12AffineFastState.Bounded env13925 := by
  intro p hp
  have h : env13925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13924_13925 : H12AffineEnvironment.transform 7 36 env13924 = env13925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13924 == env13925) = true)

theorem identity13925 : scanCanonicalize (H12AffineFastState.compose env13925 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound13925 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env13926 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,65,120,1,1,115,16,1,100,0,0,32,17,3,120,65,81,17,64,1,21,33,36,32,81,513]

theorem envBound13926 : H12AffineFastState.Bounded env13926 := by
  intro p hp
  have h : env13926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13925_13926 : H12AffineEnvironment.transform 11 65 env13925 = env13926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env13925 == env13926) = true)

theorem identity13926 : scanCanonicalize (H12AffineFastState.compose env13926 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13926 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13927 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,1,1,34,16,1,53,0,0,32,17,3,41,16,0,17,17,1,21,33,36,32,0,513]

theorem envBound13927 : H12AffineFastState.Bounded env13927 := by
  intro p hp
  have h : env13927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13926_13927 : H12AffineEnvironment.transform 5 17 env13926 = env13927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13926 == env13927) = true)

theorem identity13927 : scanCanonicalize (H12AffineFastState.compose env13927 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound13927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13928 : List Nat := [2,4,8,16,32,17,8,36,17,53,1,16,41,1,1,34,16,1,53,0,0,32,17,3,41,16,0,17,17,1,21,33,36,32,0,16]

theorem envBound13928 : H12AffineFastState.Bounded env13928 := by
  intro p hp
  have h : env13928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13927_13928 : H12AffineEnvironment.transform 8 17 env13927 = env13928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env13927 == env13928) = true)

theorem identity13928 : scanCanonicalize (H12AffineFastState.compose env13928 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13928 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13929 : List Nat := [2,4,3,16,32,17,3,36,17,53,1,16,34,1,1,34,16,1,53,0,0,32,17,3,34,16,0,17,17,1,21,33,36,32,0,16]

theorem envBound13929 : H12AffineFastState.Bounded env13929 := by
  intro p hp
  have h : env13929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13928_13929 : H12AffineEnvironment.transform 2 3 env13928 = env13929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13928 == env13929) = true)

def env13930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,243003,17,98644,8193,65,215367,5392,17665,32040,1364,213351,256,21792,46092,74250]

theorem envBound13930 : H12AffineFastState.Bounded env13930 := by
  intro p hp
  have h : env13930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13916_13930 : H12AffineEnvironment.transform 6 9 env13916 = env13930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13916 == env13930) = true)

theorem identity13930 : scanCanonicalize (H12AffineFastState.compose env13930 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound13930 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179512,1024,32769,4161,144492,17,3,8193,65,182288,5392,17665,32040,1364,180272,256,21792,46092,41821]

theorem envBound13931 : H12AffineFastState.Bounded env13931 := by
  intro p hp
  have h : env13931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13930_13931 : H12AffineEnvironment.transform 15 33111 env13930 = env13931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env13930 == env13931) = true)

theorem identity13931 : scanCanonicalize (H12AffineFastState.compose env13931 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound13931 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env13932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,5393,43049,1024,32769,4161,8573,17,3,8193,65,56577,5392,17665,32040,1364,54561,256,21792,46092,41821]

theorem envBound13932 : H12AffineFastState.Bounded env13932 := by
  intro p hp
  have h : env13932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13931_13932 : H12AffineEnvironment.transform 16 5393 env13931 = env13932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env13931 == env13932) = true)

theorem identity13932 : scanCanonicalize (H12AffineFastState.compose env13932 (packedSelected [0,1,3,5,6,8,10,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13932 : packedSelected [0,1,3,5,6,8,10,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env13933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,33111,5393,43049,1024,32769,4161,8573,17,3,8193,65,35188,5392,4468,10589,1364,33108,256,341,46092,41821]

theorem envBound13933 : H12AffineFastState.Bounded env13933 := by
  intro p hp
  have h : env13933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13932_13933 : H12AffineEnvironment.transform 13 5237 env13932 = env13933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13932 == env13933) = true)

theorem identity13933 : scanCanonicalize (H12AffineFastState.compose env13933 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13933 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env13934 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,32803,5221,43049,1024,32769,4161,8201,17,3,8193,65,34816,5220,4096,10281,1056,32800,116,33,46092,41513]

theorem envBound13934 : H12AffineFastState.Bounded env13934 := by
  intro p hp
  have h : env13934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13933_13934 : H12AffineEnvironment.transform 7 116 env13933 = env13934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13933 == env13934) = true)

theorem identity13934 : scanCanonicalize (H12AffineFastState.compose env13934 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13934 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env13935 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,1,34,5221,10280,1024,0,4161,8201,17,3,8193,65,2049,5220,4096,10281,1056,33,116,33,13325,8744]

theorem envBound13935 : H12AffineFastState.Bounded env13935 := by
  intro p hp
  have h : env13935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13934_13935 : H12AffineEnvironment.transform 14 1 env13934 = env13935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13934 == env13935) = true)

theorem identity13935 : scanCanonicalize (H12AffineFastState.compose env13935 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13935 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13936 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,1,34,5221,2049,1024,0,4161,32,17,3,40,65,2049,5220,4096,2048,1056,33,116,33,5156,513]

theorem envBound13936 : H12AffineFastState.Bounded env13936 := by
  intro p hp
  have h : env13936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13935_13936 : H12AffineEnvironment.transform 12 41 env13935 = env13936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13935 == env13936) = true)

theorem identity13936 : scanCanonicalize (H12AffineFastState.compose env13936 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound13936 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13937 : List Nat := [2,4,8,16,32,64,9,116,512,1024,90,4096,41,5237,1,34,5221,91,1024,0,4161,32,17,3,40,65,91,5220,4096,90,1056,33,116,33,5156,513]

theorem envBound13937 : H12AffineFastState.Bounded env13937 := by
  intro p hp
  have h : env13937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13936_13937 : H12AffineEnvironment.transform 10 90 env13936 = env13937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env13936 == env13937) = true)

def env13938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,474221,8328,65,6705549,2537697,456880,2125280,2102685,6707629,256,21793,46212,2175562]

theorem envBound13938 : H12AffineFastState.Bounded env13938 := by
  intro p hp
  have h : env13938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13856_13938 : H12AffineEnvironment.transform 23 474221 env13856 = env13938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474221 env13856 == env13938) = true)

def env13939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101329,98781,8328,65,6351933,2098513,17664,2125280,2102685,6349853,256,21793,46212,2175562]

theorem envBound13939 : H12AffineFastState.Bounded env13939 := by
  intro p hp
  have h : env13939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13938_13939 : H12AffineEnvironment.transform 17 179632 env13938 = env13939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env13938 == env13939) = true)

def env13940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,17,98781,8328,65,4258941,5393,17664,32160,1501,4256861,256,21793,46212,74250]

theorem envBound13940 : H12AffineFastState.Bounded env13940 := by
  intro p hp
  have h : env13940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13939_13940 : H12AffineEnvironment.transform 20 4160 env13939 = env13940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13939 == env13940) = true)

theorem identity13940 : scanCanonicalize (H12AffineFastState.compose env13940 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound13940 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,169265,17,98781,8328,65,158028,5393,17664,32160,1501,156012,256,21793,46212,74250]

theorem envBound13941 : H12AffineFastState.Bounded env13941 := by
  intro p hp
  have h : env13941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13940_13941 : H12AffineEnvironment.transform 21 169265 env13940 = env13941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env13940 == env13941) = true)

theorem identity13941 : scanCanonicalize (H12AffineFastState.compose env13941 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13941 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179632,1024,32769,4160,169265,17,41430,8328,65,158028,5393,17664,32160,1501,156012,256,21793,46212,513]

theorem envBound13942 : H12AffineFastState.Bounded env13942 := by
  intro p hp
  have h : env13942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13941_13942 : H12AffineEnvironment.transform 15 8203 env13941 = env13942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13941 == env13942) = true)

theorem identity13942 : scanCanonicalize (H12AffineFastState.compose env13942 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound13942 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64929,1024,32769,4160,54560,17,41430,8328,65,10589,5393,17664,32160,1501,8573,256,21793,46212,513]

theorem envBound13943 : H12AffineFastState.Bounded env13943 := by
  intro p hp
  have h : env13943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13942_13943 : H12AffineEnvironment.transform 16 16401 env13942 = env13943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env13942 == env13943) = true)

theorem identity13943 : scanCanonicalize (H12AffineFastState.compose env13943 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound13943 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env13944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16401,2477,1024,29709,4160,8492,17,21978,8328,65,10589,5393,17664,32160,1501,8573,256,21793,16520,513]

theorem envBound13944 : H12AffineFastState.Bounded env13944 := by
  intro p hp
  have h : env13944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13943_13944 : H12AffineEnvironment.transform 14 29708 env13943 = env13944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env13943 == env13944) = true)

def env13945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,20924,1467,16401,2477,1024,20925,4160,1180,17,21978,1336,65,3309,5393,17664,22544,1501,1229,256,21793,16520,513]

theorem envBound13945 : H12AffineFastState.Bounded env13945 := by
  intro p hp
  have h : env13945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13944_13945 : H12AffineEnvironment.transform 12 1456 env13944 = env13945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env13944 == env13945) = true)

theorem identity13945 : scanCanonicalize (H12AffineFastState.compose env13945 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound13945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13946 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,468,16384,20924,479,16401,2477,100,20925,4160,248,17,20926,348,65,2185,4469,16740,22544,441,169,256,20805,16520,513]

theorem envBound13946 : H12AffineFastState.Bounded env13946 := by
  intro p hp
  have h : env13946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13945_13946 : H12AffineEnvironment.transform 9 100 env13945 = env13946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env13945 == env13946) = true)

theorem identity13946 : scanCanonicalize (H12AffineFastState.compose env13946 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound13946 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env13947 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2200,468,16384,18724,479,16401,2477,100,18725,2264,248,17,18726,348,65,2185,2541,16740,16520,441,169,256,18909,16520,513]

theorem envBound13947 : H12AffineFastState.Bounded env13947 := by
  intro p hp
  have h : env13947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13946_13947 : H12AffineEnvironment.transform 11 2200 env13946 = env13947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env13946 == env13947) = true)

theorem identity13947 : scanCanonicalize (H12AffineFastState.compose env13947 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 428) := by decide +kernel

theorem selectedBound13947 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13948 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2200,468,428,2184,479,445,2477,100,2185,2264,248,17,2186,348,65,2185,2541,200,292,441,169,256,2161,292,513]

theorem envBound13948 : H12AffineFastState.Bounded env13948 := by
  intro p hp
  have h : env13948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13947_13948 : H12AffineEnvironment.transform 13 428 env13947 = env13948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 428 env13947 == env13948) = true)

theorem identity13948 : scanCanonicalize (H12AffineFastState.compose env13948 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13948 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13949 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,2200,121,1,2184,114,16,2048,100,2185,2264,248,17,2186,241,65,2185,2112,200,137,20,169,173,2161,137,513]

theorem envBound13949 : H12AffineFastState.Bounded env13949 := by
  intro p hp
  have h : env13949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13948_13949 : H12AffineEnvironment.transform 7 173 env13948 = env13949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13948 == env13949) = true)

theorem identity13949 : scanCanonicalize (H12AffineFastState.compose env13949 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13949 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env13950 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,2200,40,1,2184,35,16,2048,53,2185,2185,169,17,2186,160,16,2185,2065,153,137,20,169,173,2080,137,513]

theorem envBound13950 : H12AffineFastState.Bounded env13950 := by
  intro p hp
  have h : env13950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13949_13950 : H12AffineEnvironment.transform 5 17 env13949 = env13950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13949 == env13950) = true)

theorem identity13950 : scanCanonicalize (H12AffineFastState.compose env13950 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13950 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13951 : List Nat := [2,4,8,16,32,17,128,173,512,53,1,153,40,1,137,35,16,1,53,136,136,169,17,139,160,16,136,16,153,137,20,169,173,33,137,513]

theorem envBound13951 : H12AffineFastState.Bounded env13951 := by
  intro p hp
  have h : env13951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13950_13951 : H12AffineEnvironment.transform 10 1 env13950 = env13951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13950 == env13951) = true)

def env13952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,20925,1466,16401,2477,1024,20924,4160,1181,17,21978,1337,65,3308,5393,17664,22545,1501,1228,256,21793,16520,513]

theorem envBound13952 : H12AffineFastState.Bounded env13952 := by
  intro p hp
  have h : env13952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13944_13952 : H12AffineEnvironment.transform 12 1457 env13944 = env13952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env13944 == env13952) = true)

theorem identity13952 : scanCanonicalize (H12AffineFastState.compose env13952 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound13952 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,4540,1,1466,4525,2477,1024,0,4160,1181,17,1126,1337,65,3308,5393,5308,2477,1501,1228,256,1181,4404,513]

theorem envBound13953 : H12AffineFastState.Bounded env13953 := by
  intro p hp
  have h : env13953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13952_13953 : H12AffineEnvironment.transform 13 4540 env13952 = env13953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env13952 == env13953) = true)

theorem identity13953 : scanCanonicalize (H12AffineFastState.compose env13953 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound13953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13954 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,268,4540,1,263,4525,2477,189,0,4160,32,17,219,388,65,2129,4524,4097,2477,352,113,256,32,4404,513]

theorem envBound13954 : H12AffineFastState.Bounded env13954 := by
  intro p hp
  have h : env13954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13953_13954 : H12AffineEnvironment.transform 9 189 env13953 = env13954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env13953 == env13954) = true)

theorem identity13954 : scanCanonicalize (H12AffineFastState.compose env13954 (packedSelected [1,3,4,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound13954 : packedSelected [1,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env13955 : List Nat := [2,4,8,16,32,64,128,256,512,189,372,4096,268,4540,1,263,4525,217,189,0,4160,32,17,219,388,65,293,4524,4097,217,352,113,256,32,4404,513]

theorem envBound13955 : H12AffineFastState.Bounded env13955 := by
  intro p hp
  have h : env13955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13954_13955 : H12AffineEnvironment.transform 10 372 env13954 = env13955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env13954 == env13955) = true)

theorem identity13955 : scanCanonicalize (H12AffineFastState.compose env13955 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13955 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env13956 : List Nat := [2,4,8,16,32,64,128,117,512,189,1,4096,121,4297,1,114,4312,217,189,0,4160,32,17,219,241,65,80,4313,4097,217,21,113,117,32,4161,513]

theorem envBound13956 : H12AffineFastState.Bounded env13956 := by
  intro p hp
  have h : env13956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13955_13956 : H12AffineEnvironment.transform 7 117 env13955 = env13956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13955 == env13956) = true)

def env13957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,16,98781,8328,65,4258940,5392,17664,32161,1500,4256860,256,21793,46212,74251]

theorem envBound13957 : H12AffineFastState.Bounded env13957 := by
  intro p hp
  have h : env13957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13939_13957 : H12AffineEnvironment.transform 20 4161 env13939 = env13957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13939 == env13957) = true)

def env13958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98645,8192,65,4258940,5392,17664,32041,1364,4256860,256,21793,46092,74251]

theorem envBound13958 : H12AffineFastState.Bounded env13958 := by
  intro p hp
  have h : env13958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13958 : H12AffineEnvironment.transform 6 8 env13957 = env13958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13957 == env13958) = true)

theorem identity13958 : scanCanonicalize (H12AffineFastState.compose env13958 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound13958 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,67618,1024,32769,4161,4194304,16,98645,8192,65,4258940,5392,17664,32041,1364,4256860,256,21793,46092,74251]

theorem envBound13959 : H12AffineFastState.Bounded env13959 := by
  intro p hp
  have h : env13959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13958_13959 : H12AffineEnvironment.transform 16 111898 env13958 = env13959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env13958 == env13959) = true)

theorem identity13959 : scanCanonicalize (H12AffineFastState.compose env13959 (packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13959 : packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,46157,2421,1024,32769,4161,4194304,16,32770,8192,65,4258940,5392,17664,32041,1364,4256860,256,21793,46092,9052]

theorem envBound13960 : H12AffineFastState.Bounded env13960 := by
  intro p hp
  have h : env13960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13959_13960 : H12AffineEnvironment.transform 15 343 env13959 = env13960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13959 == env13960) = true)

theorem identity13960 : scanCanonicalize (H12AffineFastState.compose env13960 (packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound13960 : packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env13961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,46157,2421,1024,32769,4161,8572,16,32770,8192,65,56576,5392,17664,32041,1364,54560,256,21793,46092,9052]

theorem envBound13961 : H12AffineFastState.Bounded env13961 := by
  intro p hp
  have h : env13961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13960_13961 : H12AffineEnvironment.transform 21 8572 env13960 = env13961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env13960 == env13961) = true)

theorem identity13961 : scanCanonicalize (H12AffineFastState.compose env13961 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound13961 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env13962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,5393,2421,1024,8541,4161,8572,16,8542,8192,65,31836,5392,17664,32041,1364,29820,256,21793,5456,9052]

theorem envBound13962 : H12AffineFastState.Bounded env13962 := by
  intro p hp
  have h : env13962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13961_13962 : H12AffineEnvironment.transform 14 8540 env13961 = env13962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env13961 == env13962) = true)

theorem identity13962 : scanCanonicalize (H12AffineFastState.compose env13962 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound13962 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,16384,340,343,5393,2421,1024,341,4161,372,16,342,8,65,23636,5392,17664,23841,1364,21620,256,21793,5456,852]

theorem envBound13963 : H12AffineFastState.Bounded env13963 := by
  intro p hp
  have h : env13963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13962_13963 : H12AffineEnvironment.transform 12 8 env13962 = env13963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13962 == env13963) = true)

theorem identity13963 : scanCanonicalize (H12AffineFastState.compose env13963 (packedSelected [1,2,8,14,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound13963 : packedSelected [1,2,8,14,19] rootPS < 2^1333 := by decide +kernel

def env13964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5204,340,343,5393,2421,1024,341,4161,372,16,342,8,65,2048,5392,4436,2421,1364,32,256,373,5456,852]

theorem envBound13964 : H12AffineFastState.Bounded env13964 := by
  intro p hp
  have h : env13964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13963_13964 : H12AffineEnvironment.transform 13 5204 env13963 = env13964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env13963 == env13964) = true)

theorem identity13964 : scanCanonicalize (H12AffineFastState.compose env13964 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13964 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13965 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8,5204,33,34,5220,2048,1024,32,4161,1,16,35,8,65,2048,5221,4129,2048,1057,32,117,0,5157,545]

theorem envBound13965 : H12AffineFastState.Bounded env13965 := by
  intro p hp
  have h : env13965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13964_13965 : H12AffineEnvironment.transform 7 117 env13964 = env13965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13964 == env13965) = true)

theorem identity13965 : scanCanonicalize (H12AffineFastState.compose env13965 (packedSelected [3,5,10,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13965 : packedSelected [3,5,10,16] rootPS < 2^1333 := by decide +kernel

def env13966 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,4096,8,5204,1,2,5188,2048,1024,0,4161,1,16,3,8,65,2048,5189,4097,2048,1025,0,85,0,5125,513]

theorem envBound13966 : H12AffineFastState.Bounded env13966 := by
  intro p hp
  have h : env13966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13965_13966 : H12AffineEnvironment.transform 4 0 env13965 = env13966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13965 == env13966) = true)

theorem identity13966 : scanCanonicalize (H12AffineFastState.compose env13966 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound13966 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13967 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,4096,8,4113,1,2,4097,2048,69,0,4161,1,16,3,8,65,2048,4096,4097,2048,68,0,85,0,4160,513]

theorem envBound13967 : H12AffineFastState.Bounded env13967 := by
  intro p hp
  have h : env13967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13966_13967 : H12AffineEnvironment.transform 9 69 env13966 = env13967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env13966 == env13967) = true)

theorem identity13967 : scanCanonicalize (H12AffineFastState.compose env13967 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13968 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,17,8,0,1,2,16,2048,69,0,80,1,16,3,8,65,2048,17,16,2048,68,0,85,0,81,513]

theorem envBound13968 : H12AffineFastState.Bounded env13968 := by
  intro p hp
  have h : env13968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13967_13968 : H12AffineEnvironment.transform 11 17 env13967 = env13968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13967 == env13968) = true)

theorem identity13968 : scanCanonicalize (H12AffineFastState.compose env13968 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound13968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13969 : List Nat := [2,4,8,16,0,64,8,85,512,69,64,17,8,0,1,2,16,64,69,0,80,1,16,3,8,65,64,17,16,64,68,0,85,0,81,513]

theorem envBound13969 : H12AffineFastState.Bounded env13969 := by
  intro p hp
  have h : env13969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13968_13969 : H12AffineEnvironment.transform 10 64 env13968 = env13969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env13968 == env13969) = true)

theorem identity13969 : scanCanonicalize (H12AffineFastState.compose env13969 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound13969 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13970 : List Nat := [2,4,8,16,0,64,8,85,80,69,64,17,8,0,1,2,16,64,69,0,80,1,16,3,8,65,64,17,16,64,68,0,85,0,81,81]

theorem envBound13970 : H12AffineFastState.Bounded env13970 := by
  intro p hp
  have h : env13970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13969_13970 : H12AffineEnvironment.transform 8 80 env13969 = env13970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env13969 == env13970) = true)

theorem identity13970 : scanCanonicalize (H12AffineFastState.compose env13970 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound13970 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13971 : List Nat := [2,4,8,16,0,11,8,30,27,14,11,17,8,0,1,2,16,11,14,0,27,1,16,3,8,10,11,17,16,11,15,0,30,0,26,26]

theorem envBound13971 : H12AffineFastState.Bounded env13971 := by
  intro p hp
  have h : env13971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13970_13971 : H12AffineEnvironment.transform 5 11 env13970 = env13971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env13970 == env13971) = true)

theorem identity13971 : scanCanonicalize (H12AffineFastState.compose env13971 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13971 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env13972 : List Nat := [2,4,2,16,0,1,2,20,17,4,1,17,2,0,1,2,16,1,4,0,17,1,16,3,2,0,1,17,16,1,5,0,20,0,16,16]

theorem envBound13972 : H12AffineFastState.Bounded env13972 := by
  intro p hp
  have h : env13972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13971_13972 : H12AffineEnvironment.transform 2 2 env13971 = env13972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13971 == env13972) = true)

def env13973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98644,8193,65,4258940,5392,17664,32040,1365,4256860,256,21793,46093,74251]

theorem envBound13973 : H12AffineFastState.Bounded env13973 := by
  intro p hp
  have h : env13973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13957_13973 : H12AffineEnvironment.transform 6 9 env13957 = env13973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13957 == env13973) = true)

theorem identity13973 : scanCanonicalize (H12AffineFastState.compose env13973 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound13973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,108927,1024,32769,4161,4194304,16,98644,8193,65,4258940,5392,17664,32040,1365,4256860,256,21793,46093,74251]

theorem envBound13974 : H12AffineFastState.Bounded env13974 := by
  intro p hp
  have h : env13974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13973_13974 : H12AffineEnvironment.transform 16 70726 env13973 = env13974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env13973 == env13974) = true)

theorem identity13974 : scanCanonicalize (H12AffineFastState.compose env13974 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound13974 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env13975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,70726,108927,1024,32769,4161,4194304,16,98644,8193,65,4229152,5392,12636,2420,1365,4227072,256,8573,46093,74251]

theorem envBound13975 : H12AffineFastState.Bounded env13975 := by
  intro p hp
  have h : env13975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13974_13975 : H12AffineEnvironment.transform 13 13404 env13974 = env13975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env13974 == env13975) = true)

theorem identity13975 : scanCanonicalize (H12AffineFastState.compose env13975 (packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound13975 : packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS < 2^1333 := by decide +kernel

def env13976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,373,65536,70726,75786,1024,372,4161,4194304,16,65569,8193,65,4196693,5392,12636,2420,1365,4194677,256,8573,13688,74251]

theorem envBound13976 : H12AffineFastState.Bounded env13976 := by
  intro p hp
  have h : env13976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13975_13976 : H12AffineEnvironment.transform 14 373 env13975 = env13976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env13975 == env13976) = true)

theorem identity13976 : scanCanonicalize (H12AffineFastState.compose env13976 (packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound13976 : packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS < 2^1333 := by decide +kernel

def env13977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,373,65536,70726,75786,1024,372,4161,8201,16,65569,8193,65,10588,5392,12636,2420,1365,8572,256,8573,13688,74251]

theorem envBound13977 : H12AffineFastState.Bounded env13977 := by
  intro p hp
  have h : env13977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13976_13977 : H12AffineEnvironment.transform 21 8201 env13976 = env13977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env13976 == env13977) = true)

theorem identity13977 : scanCanonicalize (H12AffineFastState.compose env13977 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound13977 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,373,65536,70726,67619,1024,372,4161,32,16,65569,40,65,2421,5392,4469,2420,1365,341,256,340,5457,66082]

theorem envBound13978 : H12AffineFastState.Bounded env13978 := by
  intro p hp
  have h : env13978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13977_13978 : H12AffineEnvironment.transform 12 41 env13977 = env13978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env13977 == env13978) = true)

theorem identity13978 : scanCanonicalize (H12AffineFastState.compose env13978 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13978 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env13979 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,65536,70726,67619,1024,1,4161,32,16,65569,40,65,2048,5221,4096,2049,1056,32,117,33,5156,66082]

theorem envBound13979 : H12AffineFastState.Bounded env13979 := by
  intro p hp
  have h : env13979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13978_13979 : H12AffineEnvironment.transform 7 117 env13978 = env13979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13978 == env13979) = true)

theorem identity13979 : scanCanonicalize (H12AffineFastState.compose env13979 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound13979 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env13980 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,1094,4096,3173,1024,1,4161,32,16,1127,40,65,2048,5221,4096,2049,1056,32,117,33,5156,1636]

theorem envBound13980 : H12AffineFastState.Bounded env13980 := by
  intro p hp
  have h : env13980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13979_13980 : H12AffineEnvironment.transform 15 1094 env13979 = env13980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env13979 == env13980) = true)

def env13981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101328,98780,8328,65,6351932,2098512,17665,2125280,2102685,6349852,256,21793,46212,2175562]

theorem envBound13981 : H12AffineFastState.Bounded env13981 := by
  intro p hp
  have h : env13981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13938_13981 : H12AffineEnvironment.transform 17 179633 env13938 = env13981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env13938 == env13981) = true)

def env13982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,16,98780,8328,65,4258940,5392,17665,32160,1501,4256860,256,21793,46212,74250]

theorem envBound13982 : H12AffineFastState.Bounded env13982 := by
  intro p hp
  have h : env13982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13981_13982 : H12AffineEnvironment.transform 20 4160 env13981 = env13982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env13981 == env13982) = true)

theorem identity13982 : scanCanonicalize (H12AffineFastState.compose env13982 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13982 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149861,1024,29909,4160,4194304,16,95496,8328,65,4196520,5392,17665,32160,1501,4194440,256,21793,16464,74250]

theorem envBound13983 : H12AffineFastState.Bounded env13983 := by
  intro p hp
  have h : env13983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13982_13983 : H12AffineEnvironment.transform 14 29908 env13982 = env13983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13982 == env13983) = true)

def env13984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138341,1024,8661,4160,4194304,16,73736,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,74250]

theorem envBound13984 : H12AffineFastState.Bounded env13984 := by
  intro p hp
  have h : env13984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13983_13984 : H12AffineEnvironment.transform 13 5376 env13983 = env13984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13983 == env13984) = true)

theorem identity13984 : scanCanonicalize (H12AffineFastState.compose env13984 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound13984 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,67619,1024,8661,4160,4194304,16,73736,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,74250]

theorem envBound13985 : H12AffineFastState.Bounded env13985 := by
  intro p hp
  have h : env13985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13984_13985 : H12AffineEnvironment.transform 16 70726 env13984 = env13985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env13984 == env13985) = true)

theorem identity13985 : scanCanonicalize (H12AffineFastState.compose env13985 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound13985 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13389,10280,1024,8661,4160,4194304,16,3,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,513]

theorem envBound13986 : H12AffineFastState.Bounded env13986 := by
  intro p hp
  have h : env13986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13985_13986 : H12AffineEnvironment.transform 15 8203 env13985 = env13986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env13985 == env13986) = true)

theorem identity13986 : scanCanonicalize (H12AffineFastState.compose env13986 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound13986 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13389,10280,1024,8661,4160,8492,16,3,8328,65,10628,5392,4097,10400,1501,8612,256,33,5456,513]

theorem envBound13987 : H12AffineFastState.Bounded env13987 := by
  intro p hp
  have h : env13987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13986_13987 : H12AffineEnvironment.transform 21 8492 env13986 = env13987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env13986 == env13987) = true)

def env13988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138340,1024,8660,4160,4194304,16,73737,8328,65,4196520,5392,4096,10401,1501,4194440,256,32,5457,74250]

theorem envBound13988 : H12AffineFastState.Bounded env13988 := by
  intro p hp
  have h : env13988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13983_13988 : H12AffineEnvironment.transform 13 5377 env13983 = env13988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13983 == env13988) = true)

theorem identity13988 : scanCanonicalize (H12AffineFastState.compose env13988 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound13988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70863,67755,1024,8660,4160,4194304,16,73737,8328,65,4196520,5392,4096,10401,1501,4194440,256,32,5457,74250]

theorem envBound13989 : H12AffineFastState.Bounded env13989 := by
  intro p hp
  have h : env13989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13988_13989 : H12AffineEnvironment.transform 16 70863 env13988 = env13989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env13988 == env13989) = true)

theorem identity13989 : scanCanonicalize (H12AffineFastState.compose env13989 (packedSelected [0,2,3,4,5,6,9,10,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13989 : packedSelected [0,2,3,4,5,6,9,10,20,27] rootPS < 2^1333 := by decide +kernel

def env13990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70726,67618,1024,8541,4160,4194304,16,73737,8193,65,4196385,5392,4096,10280,1364,4194305,256,32,5457,74250]

theorem envBound13990 : H12AffineFastState.Bounded env13990 := by
  intro p hp
  have h : env13990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13989_13990 : H12AffineEnvironment.transform 6 9 env13989 = env13990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13989 == env13990) = true)

theorem identity13990 : scanCanonicalize (H12AffineFastState.compose env13990 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound13990 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,5392,2420,1024,8541,4160,4194304,16,8543,8193,65,4196385,5392,4096,10280,1364,4194305,256,32,5457,9052]

theorem envBound13991 : H12AffineFastState.Bounded env13991 := by
  intro p hp
  have h : env13991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13990_13991 : H12AffineEnvironment.transform 15 342 env13990 = env13991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env13990 == env13991) = true)

theorem identity13991 : scanCanonicalize (H12AffineFastState.compose env13991 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound13991 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env13992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,5392,2420,1024,8541,4160,8280,16,8543,8193,65,10361,5392,4096,10280,1364,8281,256,32,5457,9052]

theorem envBound13992 : H12AffineFastState.Bounded env13992 := by
  intro p hp
  have h : env13992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13991_13992 : H12AffineEnvironment.transform 21 8280 env13991 = env13992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env13991 == env13992) = true)

theorem identity13992 : scanCanonicalize (H12AffineFastState.compose env13992 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13992 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env13993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1024,1,4160,260,16,3,349,65,2341,5392,4096,2420,1364,261,256,32,5457,512]

theorem envBound13993 : H12AffineFastState.Bounded env13993 := by
  intro p hp
  have h : env13993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13992_13993 : H12AffineEnvironment.transform 12 348 env13992 = env13993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13992 == env13993) = true)

theorem identity13993 : scanCanonicalize (H12AffineFastState.compose env13993 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13994 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,88,5125,0,82,5140,2160,1024,1,4160,0,16,3,89,65,2081,5140,4096,2160,1104,1,4,32,5205,512]

theorem envBound13994 : H12AffineFastState.Bounded env13994 := by
  intro p hp
  have h : env13994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13993_13994 : H12AffineEnvironment.transform 7 4 env13993 = env13994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13993 == env13994) = true)

theorem identity13994 : scanCanonicalize (H12AffineFastState.compose env13994 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound13994 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env13995 : List Nat := [2,4,8,16,32,64,9,4,512,1024,1092,4096,88,5125,0,82,5140,1076,1024,1,4160,0,16,3,89,65,1125,5140,4096,1076,1104,1,4,32,5205,512]

theorem envBound13995 : H12AffineFastState.Bounded env13995 := by
  intro p hp
  have h : env13995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13994_13995 : H12AffineEnvironment.transform 10 1092 env13994 = env13995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env13994 == env13995) = true)

theorem identity13995 : scanCanonicalize (H12AffineFastState.compose env13995 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13995 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env13996 : List Nat := [2,4,8,16,0,64,9,4,512,1024,1092,4096,88,5125,0,82,5140,1044,1024,1,4160,0,16,3,89,65,1093,5140,4096,1044,1104,1,4,0,5205,512]

theorem envBound13996 : H12AffineFastState.Bounded env13996 := by
  intro p hp
  have h : env13996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13995_13996 : H12AffineEnvironment.transform 4 0 env13995 = env13996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13995 == env13996) = true)

theorem identity13996 : scanCanonicalize (H12AffineFastState.compose env13996 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13997 : List Nat := [2,4,8,16,0,64,9,4,512,1024,1092,17,88,1044,0,82,1029,1044,1024,1,81,0,16,3,89,65,1093,1029,17,1044,1104,1,4,0,1092,512]

theorem envBound13997 : H12AffineFastState.Bounded env13997 := by
  intro p hp
  have h : env13997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13996_13997 : H12AffineEnvironment.transform 11 17 env13996 = env13997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13996 == env13997) = true)

theorem identity13997 : scanCanonicalize (H12AffineFastState.compose env13997 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound13997 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13998 : List Nat := [2,4,8,16,0,64,9,4,81,1024,1092,17,88,1044,0,82,1029,1044,1024,1,81,0,16,3,89,65,1093,1029,17,1044,1104,1,4,0,1092,81]

theorem envBound13998 : H12AffineFastState.Bounded env13998 := by
  intro p hp
  have h : env13998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13997_13998 : H12AffineEnvironment.transform 8 81 env13997 = env13998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env13997 == env13998) = true)

theorem identity13998 : scanCanonicalize (H12AffineFastState.compose env13998 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound13998 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13999 : List Nat := [2,4,8,16,0,64,9,4,81,69,1,17,88,81,0,82,64,81,69,1,81,0,16,3,89,65,0,64,17,81,21,1,4,0,1,81]

theorem envBound13999 : H12AffineFastState.Bounded env13999 := by
  intro p hp
  have h : env13999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13998_13999 : H12AffineEnvironment.transform 9 69 env13998 = env13999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env13998 == env13999) = true)

theorem identity13999 : scanCanonicalize (H12AffineFastState.compose env13999 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound13999 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14000 : List Nat := [2,4,8,16,0,0,9,4,17,5,1,17,24,17,0,18,0,17,5,1,17,0,16,3,25,1,0,0,17,17,21,1,4,0,1,17]

theorem envBound14000 : H12AffineFastState.Bounded env14000 := by
  intro p hp
  have h : env14000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13999_14000 : H12AffineEnvironment.transform 5 0 env13999 = env14000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env13999 == env14000) = true)

def env14001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,17,98780,8328,65,4258941,5393,17665,32161,1500,4256861,256,21793,46212,74251]

theorem envBound14001 : H12AffineFastState.Bounded env14001 := by
  intro p hp
  have h : env14001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13981_14001 : H12AffineEnvironment.transform 20 4161 env13981 = env14001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env13981 == env14001) = true)

theorem identity14001 : scanCanonicalize (H12AffineFastState.compose env14001 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound14001 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,156132,17,98780,8328,65,171417,5393,17665,32161,1500,169401,256,21793,46212,74251]

theorem envBound14002 : H12AffineFastState.Bounded env14002 := by
  intro p hp
  have h : env14002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14001_14002 : H12AffineEnvironment.transform 21 156132 env14001 = env14002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env14001 == env14002) = true)

def env14003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,17,98644,8192,65,171281,5393,17665,32041,1364,169265,256,21793,46092,74251]

theorem envBound14003 : H12AffineFastState.Bounded env14003 := by
  intro p hp
  have h : env14003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14002_14003 : H12AffineEnvironment.transform 6 8 env14002 = env14003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14002 == env14003) = true)

theorem identity14003 : scanCanonicalize (H12AffineFastState.compose env14003 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14003 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4161,156012,17,41310,8192,65,171281,5393,17665,32041,1364,169265,256,21793,46092,513]

theorem envBound14004 : H12AffineFastState.Bounded env14004 := by
  intro p hp
  have h : env14004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14003_14004 : H12AffineEnvironment.transform 15 8202 env14003 = env14004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14003 == env14004) = true)

theorem identity14004 : scanCanonicalize (H12AffineFastState.compose env14004 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound14004 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64809,1024,32769,4161,8572,17,41310,8192,65,56577,5393,17665,32041,1364,54561,256,21793,46092,513]

theorem envBound14005 : H12AffineFastState.Bounded env14005 := by
  intro p hp
  have h : env14005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14004_14005 : H12AffineEnvironment.transform 16 16400 env14004 = env14005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14004 == env14005) = true)

theorem identity14005 : scanCanonicalize (H12AffineFastState.compose env14005 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14005 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,23669,1024,8541,4161,8572,17,2,8192,65,31837,5393,17665,32041,1364,29821,256,21793,5456,513]

theorem envBound14006 : H12AffineFastState.Bounded env14006 := by
  intro p hp
  have h : env14006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14005_14006 : H12AffineEnvironment.transform 14 8540 env14005 = env14006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14005 == env14006) = true)

theorem identity14006 : scanCanonicalize (H12AffineFastState.compose env14006 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14006 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,8202,13340,10361,1024,8541,4161,8572,17,2,8192,65,2129,5393,12557,2341,1364,113,256,8493,5456,513]

theorem envBound14007 : H12AffineFastState.Bounded env14007 := by
  intro p hp
  have h : env14007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14006_14007 : H12AffineEnvironment.transform 13 13324 env14006 = env14007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14006 == env14007) = true)

theorem identity14007 : scanCanonicalize (H12AffineFastState.compose env14007 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14007 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,1,343,5441,2340,1024,0,4161,33,17,2,349,65,2129,5393,4176,2341,1364,113,256,112,5456,513]

theorem envBound14008 : H12AffineFastState.Bounded env14008 := by
  intro p hp
  have h : env14008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14007_14008 : H12AffineEnvironment.transform 12 349 env14007 = env14008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14007 == env14008) = true)

theorem identity14008 : scanCanonicalize (H12AffineFastState.compose env14008 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14009 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4113,33,17,2,269,17,2049,5393,4096,2341,1284,33,256,32,5376,513]

theorem envBound14009 : H12AffineFastState.Bounded env14009 := by
  intro p hp
  have h : env14009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14008_14009 : H12AffineEnvironment.transform 5 16 env14008 = env14009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14008 == env14009) = true)

theorem identity14009 : scanCanonicalize (H12AffineFastState.compose env14009 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound14009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14010 : List Nat := [2,4,8,16,32,16,8,256,512,256,2048,4096,269,4097,1,263,4113,2340,256,0,4113,33,17,2,269,17,2049,4113,4096,2341,4,33,256,32,4096,513]

theorem envBound14010 : H12AffineFastState.Bounded env14010 := by
  intro p hp
  have h : env14010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14009_14010 : H12AffineEnvironment.transform 9 256 env14009 = env14010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env14009 == env14010) = true)

theorem identity14010 : scanCanonicalize (H12AffineFastState.compose env14010 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14010 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14011 : List Nat := [2,4,8,16,32,16,8,256,1,256,2048,4096,269,4097,1,263,4113,2340,256,0,4113,33,17,2,269,17,2049,4113,4096,2341,4,33,256,32,4096,0]

theorem envBound14011 : H12AffineFastState.Bounded env14011 := by
  intro p hp
  have h : env14011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14010_14011 : H12AffineEnvironment.transform 8 1 env14010 = env14011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14010 == env14011) = true)

theorem identity14011 : scanCanonicalize (H12AffineFastState.compose env14011 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound14011 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14012 : List Nat := [2,4,8,16,32,16,8,256,1,256,2048,2049,269,2048,1,263,2064,2340,256,0,2064,33,17,2,269,17,2049,2064,2049,2341,4,33,256,32,2049,0]

theorem envBound14012 : H12AffineFastState.Bounded env14012 := by
  intro p hp
  have h : env14012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14011_14012 : H12AffineEnvironment.transform 11 2049 env14011 = env14012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env14011 == env14012) = true)

theorem identity14012 : scanCanonicalize (H12AffineFastState.compose env14012 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound14012 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14013 : List Nat := [2,4,8,16,32,16,8,256,1,256,292,293,269,292,1,263,308,0,256,0,308,33,17,2,269,17,293,308,293,1,4,33,256,32,293,0]

theorem envBound14013 : H12AffineFastState.Bounded env14013 := by
  intro p hp
  have h : env14013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14012_14013 : H12AffineEnvironment.transform 10 292 env14012 = env14013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env14012 == env14013) = true)

theorem identity14013 : scanCanonicalize (H12AffineFastState.compose env14013 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound14013 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14014 : List Nat := [2,4,8,16,32,16,8,52,1,52,16,17,57,16,1,51,0,0,52,0,0,33,17,2,57,17,17,0,17,1,4,33,52,32,17,0]

theorem envBound14014 : H12AffineFastState.Bounded env14014 := by
  intro p hp
  have h : env14014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14013_14014 : H12AffineEnvironment.transform 7 52 env14013 = env14014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env14013 == env14014) = true)

theorem identity14014 : scanCanonicalize (H12AffineFastState.compose env14014 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14014 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14015 : List Nat := [2,4,8,1,32,1,8,37,1,37,1,0,40,1,1,34,0,0,37,0,0,33,0,2,40,0,0,0,0,1,4,33,37,32,0,0]

theorem envBound14015 : H12AffineFastState.Bounded env14015 := by
  intro p hp
  have h : env14015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14014_14015 : H12AffineEnvironment.transform 3 1 env14014 = env14015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14014 == env14015) = true)

theorem identity14015 : scanCanonicalize (H12AffineFastState.compose env14015 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14016 : List Nat := [2,4,2,1,32,1,2,37,1,37,1,0,34,1,1,34,0,0,37,0,0,33,0,2,34,0,0,0,0,1,4,33,37,32,0,0]

theorem envBound14016 : H12AffineFastState.Bounded env14016 := by
  intro p hp
  have h : env14016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14015_14016 : H12AffineEnvironment.transform 2 2 env14015 = env14016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14015 == env14016) = true)

def env14017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156013,17,98645,8193,65,171280,5393,17665,32040,1365,169264,256,21793,46093,74251]

theorem envBound14017 : H12AffineFastState.Bounded env14017 := by
  intro p hp
  have h : env14017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14002_14017 : H12AffineEnvironment.transform 6 9 env14002 = env14017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14002 == env14017) = true)

theorem identity14017 : scanCanonicalize (H12AffineFastState.compose env14017 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14017 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179512,1024,32769,4161,156013,17,3,8193,65,171280,5393,17665,32040,1365,169264,256,21793,46093,41821]

theorem envBound14018 : H12AffineFastState.Bounded env14018 := by
  intro p hp
  have h : env14018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14017_14018 : H12AffineEnvironment.transform 15 33110 env14017 = env14018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14017 == env14018) = true)

theorem identity14018 : scanCanonicalize (H12AffineFastState.compose env14018 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14018 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14019 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33031,131072,179512,1024,32769,4112,155964,17,3,8193,16,171280,5393,17665,32040,1284,169264,256,21793,46093,41740]

theorem envBound14019 : H12AffineFastState.Bounded env14019 := by
  intro p hp
  have h : env14019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14018_14019 : H12AffineEnvironment.transform 5 17 env14018 = env14019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14018 == env14019) = true)

theorem identity14019 : scanCanonicalize (H12AffineFastState.compose env14019 (packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound14019 : packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14020 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,32768,33031,131072,179512,1024,32769,4112,144665,17,3,8193,16,171280,5393,4388,10509,1284,169264,256,260,46093,41740]

theorem envBound14020 : H12AffineFastState.Bounded env14020 := by
  intro p hp
  have h : env14020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14019_14020 : H12AffineEnvironment.transform 13 5157 env14019 = env14020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env14019 == env14020) = true)

theorem identity14020 : scanCanonicalize (H12AffineFastState.compose env14020 (packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14020 : packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS < 2^1333 := by decide +kernel

def env14021 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,32768,33031,38160,10280,1024,32769,4112,40969,17,3,8193,16,2048,5393,4388,10509,1284,32,256,260,46093,41740]

theorem envBound14021 : H12AffineFastState.Bounded env14021 := by
  intro p hp
  have h : env14021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14020_14021 : H12AffineEnvironment.transform 16 38160 env14020 = env14021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14020 == env14021) = true)

theorem identity14021 : scanCanonicalize (H12AffineFastState.compose env14021 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound14021 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14022 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,293,34,5173,10280,1024,292,4112,8492,17,3,8193,16,2048,5393,4388,10509,1284,32,256,260,13608,8745]

theorem envBound14022 : H12AffineFastState.Bounded env14022 := by
  intro p hp
  have h : env14022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14021_14022 : H12AffineEnvironment.transform 14 293 env14021 = env14022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env14021 == env14022) = true)

theorem identity14022 : scanCanonicalize (H12AffineFastState.compose env14022 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14022 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14023 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,1,34,5173,10280,1024,0,4112,8200,17,3,8193,16,2048,5173,4096,10281,1056,32,36,32,13324,8745]

theorem envBound14023 : H12AffineFastState.Bounded env14023 := by
  intro p hp
  have h : env14023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14022_14023 : H12AffineEnvironment.transform 7 36 env14022 = env14023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14022 == env14023) = true)

theorem identity14023 : scanCanonicalize (H12AffineFastState.compose env14023 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound14023 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env14024 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,513,8192,1572,1,34,1588,10280,1024,0,529,8200,17,3,8193,16,2048,1588,513,10281,1056,32,36,32,9741,8745]

theorem envBound14024 : H12AffineFastState.Bounded env14024 := by
  intro p hp
  have h : env14024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14023_14024 : H12AffineEnvironment.transform 11 513 env14023 = env14024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env14023 == env14024) = true)

theorem identity14024 : scanCanonicalize (H12AffineFastState.compose env14024 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound14024 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env14025 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,513,8192,1572,1,34,1588,8760,1024,0,529,8200,17,3,8193,16,528,1588,513,8761,1056,32,36,32,9741,8745]

theorem envBound14025 : H12AffineFastState.Bounded env14025 := by
  intro p hp
  have h : env14025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14024_14025 : H12AffineEnvironment.transform 10 528 env14024 = env14025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env14024 == env14025) = true)

theorem identity14025 : scanCanonicalize (H12AffineFastState.compose env14025 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14025 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env14026 : List Nat := [2,4,8,16,32,17,9,36,0,1024,16,1,8192,1060,1,34,1076,8248,1024,0,17,8200,17,3,8193,16,16,1076,1,8249,1056,32,36,32,9229,8233]

theorem envBound14026 : H12AffineFastState.Bounded env14026 := by
  intro p hp
  have h : env14026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14025_14026 : H12AffineEnvironment.transform 8 0 env14025 = env14026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14025 == env14026) = true)

theorem identity14026 : scanCanonicalize (H12AffineFastState.compose env14026 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound14026 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14027 : List Nat := [2,4,8,16,32,17,9,36,0,1024,16,1,25,1060,1,34,1076,33,1024,0,17,17,17,3,24,16,16,1076,1,32,1056,32,36,32,1044,48]

theorem envBound14027 : H12AffineFastState.Bounded env14027 := by
  intro p hp
  have h : env14027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14026_14027 : H12AffineEnvironment.transform 12 25 env14026 = env14027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env14026 == env14027) = true)

theorem identity14027 : scanCanonicalize (H12AffineFastState.compose env14027 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound14027 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14028 : List Nat := [2,4,8,16,32,17,9,36,0,21,16,1,25,49,1,34,33,33,21,0,17,17,17,3,24,16,16,33,1,32,53,32,36,32,1,48]

theorem envBound14028 : H12AffineFastState.Bounded env14028 := by
  intro p hp
  have h : env14028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14027_14028 : H12AffineEnvironment.transform 9 21 env14027 = env14028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14027 == env14028) = true)

theorem identity14028 : scanCanonicalize (H12AffineFastState.compose env14028 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound14028 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14029 : List Nat := [2,4,8,16,16,17,9,20,0,21,16,1,25,1,1,18,17,17,21,0,17,17,17,3,24,16,16,17,1,16,5,16,20,16,1,0]

theorem envBound14029 : H12AffineFastState.Bounded env14029 := by
  intro p hp
  have h : env14029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14028_14029 : H12AffineEnvironment.transform 4 16 env14028 = env14029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env14028 == env14029) = true)

theorem identity14029 : scanCanonicalize (H12AffineFastState.compose env14029 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14029 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14030 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,9,1,1,2,1,1,5,0,1,1,1,3,8,0,0,1,1,0,5,0,4,0,1,0]

theorem envBound14030 : H12AffineFastState.Bounded env14030 := by
  intro p hp
  have h : env14030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14029_14030 : H12AffineEnvironment.transform 3 0 env14029 = env14030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14029 == env14030) = true)

theorem identity14030 : scanCanonicalize (H12AffineFastState.compose env14030 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound14030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14031 : List Nat := [2,4,7,0,0,1,6,4,0,5,0,1,6,1,1,2,1,1,5,0,1,1,1,3,7,0,0,1,1,0,5,0,4,0,1,0]

theorem envBound14031 : H12AffineFastState.Bounded env14031 := by
  intro p hp
  have h : env14031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14030_14031 : H12AffineEnvironment.transform 2 7 env14030 = env14031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env14030 == env14031) = true)

def env14032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound14032 : H12AffineFastState.Bounded env14032 := by
  intro p hp
  have h : env14032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13854_14032 : H12AffineEnvironment.transform 18 1025 env13854 = env14032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13854 == env14032) = true)

theorem identity14032 : scanCanonicalize (H12AffineFastState.compose env14032 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444640) := by decide +kernel

theorem selectedBound14032 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444640,8328,65,14847328,313837,10507601,8830976,10799473,4466848,257,8686028,8677480,10874535]

theorem envBound14033 : H12AffineFastState.Bounded env14033 := by
  intro p hp
  have h : env14033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14032_14033 : H12AffineEnvironment.transform 23 2444640 env14032 = env14033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444640 env14032 == env14033) = true)

def env14034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318700,2444640,8328,65,6705548,313837,2394557,138476,2102685,4466848,257,21792,46212,2175563]

theorem envBound14034 : H12AffineFastState.Bounded env14034 := by
  intro p hp
  have h : env14034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14033_14034 : H12AffineEnvironment.transform 22 318700 env14033 = env14034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318700 env14033 == env14034) = true)

def env14035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318700,466224,8328,65,4456924,313837,449005,138476,148941,4466848,257,21792,46212,221723]

theorem envBound14035 : H12AffineFastState.Bounded env14035 := by
  intro p hp
  have h : env14035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14034_14035 : H12AffineEnvironment.transform 20 151632 env14034 = env14035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env14034 == env14035) = true)

def env14036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,147640,318700,466224,8328,65,409956,313837,449005,138476,148941,419864,257,21792,46212,221723]

theorem envBound14036 : H12AffineFastState.Bounded env14036 := by
  intro p hp
  have h : env14036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14035_14036 : H12AffineEnvironment.transform 21 147640 env14035 = env14036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147640 env14035 == env14036) = true)

def env14037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318700,351520,8328,65,262516,313837,301565,23804,1501,272392,257,21792,46212,74251]

theorem envBound14037 : H12AffineFastState.Bounded env14037 := by
  intro p hp
  have h : env14037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14036_14037 : H12AffineEnvironment.transform 16 16400 env14036 = env14037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14036 == env14037) = true)

def env14038 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318700,351452,8328,65,262280,313361,301057,23804,1057,272392,253,21724,46212,74251]

theorem envBound14038 : H12AffineFastState.Bounded env14038 := by
  intro p hp
  have h : env14038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14038 : H12AffineEnvironment.transform 7 252 env14037 = env14038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env14037 == env14038) = true)

def env14039 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,112,318516,351236,8272,65,262224,313361,301057,23588,1057,272392,37,21508,46172,74251]

theorem envBound14039 : H12AffineFastState.Bounded env14039 := by
  intro p hp
  have h : env14039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14038_14039 : H12AffineEnvironment.transform 6 88 env14038 = env14039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14038 == env14039) = true)

theorem identity14039 : scanCanonicalize (H12AffineFastState.compose env14039 (packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 67698) := by decide +kernel

theorem selectedBound14039 : packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env14040 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,65536,16400,67698,1025,32769,4160,112,119878,21622,8272,65,67618,114787,102515,23588,1057,73850,37,21508,46172,74251]

theorem envBound14040 : H12AffineFastState.Bounded env14040 := by
  intro p hp
  have h : env14040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14039_14040 : H12AffineEnvironment.transform 17 67698 env14039 = env14040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67698 env14039 == env14040) = true)

theorem identity14040 : scanCanonicalize (H12AffineFastState.compose env14040 (packedSelected [0,2,3,4,6,7,9,10,12,14,15,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 61514) := by decide +kernel

theorem selectedBound14040 : packedSelected [0,2,3,4,6,7,9,10,12,14,15,17,19,24] rootPS < 2^1333 := by decide +kernel

def env14041 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,61514,16400,63544,1025,32769,4160,112,9228,21622,8272,65,63592,12329,24633,23588,1057,53296,37,21508,46172,53825]

theorem envBound14041 : H12AffineFastState.Bounded env14041 := by
  intro p hp
  have h : env14041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14040_14041 : H12AffineEnvironment.transform 15 61514 env14040 = env14041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61514 env14040 == env14041) = true)

theorem identity14041 : scanCanonicalize (H12AffineFastState.compose env14041 (packedSelected [0,7,9,11,14,17,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound14041 : packedSelected [0,7,9,11,14,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14042 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,1076,29822,16400,31756,1025,1077,4160,112,9228,21622,8272,65,31836,12329,24633,23588,1057,21508,37,21508,12392,22133]

theorem envBound14042 : H12AffineFastState.Bounded env14042 := by
  intro p hp
  have h : env14042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14041_14042 : H12AffineEnvironment.transform 14 1076 env14041 = env14042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env14041 == env14042) = true)

theorem identity14042 : scanCanonicalize (H12AffineFastState.compose env14042 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound14042 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env14043 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,8192,16384,1076,27759,16400,25629,1025,1077,2129,112,9228,19559,8272,65,25677,10296,24633,17461,1057,19477,37,19477,10361,20068]

theorem envBound14043 : H12AffineFastState.Bounded env14043 := by
  intro p hp
  have h : env14043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14042_14043 : H12AffineEnvironment.transform 11 2065 env14042 = env14043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env14042 == env14043) = true)

theorem identity14043 : scanCanonicalize (H12AffineFastState.compose env14043 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14043 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env14044 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,40,16384,1076,19527,16400,17461,1025,1077,2129,112,1060,19559,120,65,17509,2064,16401,17461,1057,19477,37,19477,2129,20068]

theorem envBound14044 : H12AffineFastState.Bounded env14044 := by
  intro p hp
  have h : env14044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14043_14044 : H12AffineEnvironment.transform 12 40 env14043 = env14044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14043 == env14044) = true)

theorem identity14044 : scanCanonicalize (H12AffineFastState.compose env14044 (packedSelected [2,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound14044 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env14045 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,40,81,1076,3094,65,1124,1025,1077,2129,112,1060,3126,120,65,1076,2064,64,1124,1057,3140,37,3140,2129,3637]

theorem envBound14045 : H12AffineFastState.Bounded env14045 := by
  intro p hp
  have h : env14045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14044_14045 : H12AffineEnvironment.transform 13 81 env14044 = env14045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env14044 == env14045) = true)

theorem identity14045 : scanCanonicalize (H12AffineFastState.compose env14045 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound14045 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env14046 : List Nat := [2,4,8,16,32,64,88,36,512,101,2048,2065,40,81,81,2163,65,1,100,80,2129,112,65,2131,120,65,81,2064,64,1,68,2081,37,2081,2129,2640]

theorem envBound14046 : H12AffineFastState.Bounded env14046 := by
  intro p hp
  have h : env14046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14045_14046 : H12AffineEnvironment.transform 9 101 env14045 = env14046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env14045 == env14046) = true)

theorem identity14046 : scanCanonicalize (H12AffineFastState.compose env14046 (packedSelected [0,2,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14046 : packedSelected [0,2,17] rootPS < 2^1333 := by decide +kernel

def env14047 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,1,1,2083,17,1,52,0,2049,32,17,2051,40,17,1,2064,16,1,20,2081,37,2081,2049,2560]

theorem envBound14047 : H12AffineFastState.Bounded env14047 := by
  intro p hp
  have h : env14047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14046_14047 : H12AffineEnvironment.transform 5 16 env14046 = env14047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14046 == env14047) = true)

theorem identity14047 : scanCanonicalize (H12AffineFastState.compose env14047 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14047 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14048 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,16,40,1,1,34,17,1,52,0,0,32,17,2,40,17,1,17,16,1,20,32,37,32,0,513]

theorem envBound14048 : H12AffineFastState.Bounded env14048 := by
  intro p hp
  have h : env14048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14047_14048 : H12AffineEnvironment.transform 10 1 env14047 = env14048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14047 == env14048) = true)

theorem identity14048 : scanCanonicalize (H12AffineFastState.compose env14048 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound14048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14049 : List Nat := [2,4,8,16,32,16,8,36,26,53,1,16,40,1,1,34,17,1,52,0,0,32,17,2,40,17,1,17,16,1,20,32,37,32,0,27]

theorem envBound14049 : H12AffineFastState.Bounded env14049 := by
  intro p hp
  have h : env14049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14048_14049 : H12AffineEnvironment.transform 8 26 env14048 = env14049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env14048 == env14049) = true)

def env14050 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,113,318517,351237,8273,65,262225,313361,301057,23589,1057,272392,36,21509,46173,74251]

theorem envBound14050 : H12AffineFastState.Bounded env14050 := by
  intro p hp
  have h : env14050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14038_14050 : H12AffineEnvironment.transform 6 89 env14038 = env14050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14038 == env14050) = true)

theorem identity14050 : scanCanonicalize (H12AffineFastState.compose env14050 (packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound14050 : packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env14051 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,65536,16400,2048,1025,32769,4160,113,54325,87045,8273,65,2129,49169,36865,23589,1057,8200,36,21509,46173,74251]

theorem envBound14051 : H12AffineFastState.Bounded env14051 := by
  intro p hp
  have h : env14051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14050_14051 : H12AffineEnvironment.transform 17 2048 env14050 = env14051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env14050 == env14051) = true)

theorem identity14051 : scanCanonicalize (H12AffineFastState.compose env14051 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,19,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14051 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env14052 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,8203,16400,2048,1025,32769,4160,113,54325,29710,8273,65,2129,49169,36865,23589,1057,8200,36,21509,46173,512]

theorem envBound14052 : H12AffineFastState.Bounded env14052 := by
  intro p hp
  have h : env14052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14051_14052 : H12AffineEnvironment.transform 15 8203 env14051 = env14052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14051 == env14052) = true)

theorem identity14052 : scanCanonicalize (H12AffineFastState.compose env14052 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound14052 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14053 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,5157,32768,8203,5173,2048,1025,32769,4160,113,32784,8235,8273,65,2129,37940,36865,2048,1057,8200,36,32,46173,512]

theorem envBound14053 : H12AffineFastState.Bounded env14053 := by
  intro p hp
  have h : env14053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14052_14053 : H12AffineEnvironment.transform 13 5157 env14052 = env14053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env14052 == env14053) = true)

theorem identity14053 : scanCanonicalize (H12AffineFastState.compose env14053 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14053 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14054 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,8192,5124,32768,8203,5140,2048,1025,32769,4160,80,32784,8202,8273,65,2129,37909,36865,2048,1024,8200,5,1,46173,512]

theorem envBound14054 : H12AffineFastState.Bounded env14054 := by
  intro p hp
  have h : env14054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14053_14054 : H12AffineEnvironment.transform 4 1 env14053 = env14054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14053 == env14054) = true)

theorem identity14054 : scanCanonicalize (H12AffineFastState.compose env14054 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14054 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env14055 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,8192,5124,1,8203,5140,2048,1025,0,4160,80,17,8202,8273,65,2129,5140,4096,2048,1024,8200,5,1,13404,512]

theorem envBound14055 : H12AffineFastState.Bounded env14055 := by
  intro p hp
  have h : env14055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14054_14055 : H12AffineEnvironment.transform 14 1 env14054 = env14055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14054 == env14055) = true)

theorem identity14055 : scanCanonicalize (H12AffineFastState.compose env14055 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound14055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14056 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,25,5124,1,18,5140,2048,1025,0,4160,80,17,19,72,65,2129,5140,4096,2048,1024,17,5,1,5189,512]

theorem envBound14056 : H12AffineFastState.Bounded env14056 := by
  intro p hp
  have h : env14056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14055_14056 : H12AffineEnvironment.transform 12 25 env14055 = env14056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env14055 == env14056) = true)

theorem identity14056 : scanCanonicalize (H12AffineFastState.compose env14056 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound14056 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env14057 : List Nat := [2,4,8,16,1,64,89,4,512,1024,592,4096,25,5124,1,18,5140,592,1025,0,4160,80,17,19,72,65,513,5140,4096,592,1024,17,5,1,5189,512]

theorem envBound14057 : H12AffineFastState.Bounded env14057 := by
  intro p hp
  have h : env14057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14056_14057 : H12AffineEnvironment.transform 10 592 env14056 = env14057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env14056 == env14057) = true)

theorem identity14057 : scanCanonicalize (H12AffineFastState.compose env14057 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound14057 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env14058 : List Nat := [2,4,8,16,1,64,89,4,512,1024,592,593,25,1621,1,18,1605,592,1025,0,529,80,17,19,72,65,513,1605,593,592,1024,17,5,1,1556,512]

theorem envBound14058 : H12AffineFastState.Bounded env14058 := by
  intro p hp
  have h : env14058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14057_14058 : H12AffineEnvironment.transform 11 593 env14057 = env14058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env14057 == env14058) = true)

theorem identity14058 : scanCanonicalize (H12AffineFastState.compose env14058 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound14058 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14059 : List Nat := [2,4,8,16,1,64,89,4,65,1024,17,16,25,1044,1,18,1028,17,1025,0,80,80,17,19,72,65,64,1028,16,17,1024,17,5,1,1109,65]

theorem envBound14059 : H12AffineFastState.Bounded env14059 := by
  intro p hp
  have h : env14059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14058_14059 : H12AffineEnvironment.transform 8 65 env14058 = env14059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env14058 == env14059) = true)

theorem identity14059 : scanCanonicalize (H12AffineFastState.compose env14059 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14059 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14060 : List Nat := [2,4,8,16,1,64,89,4,65,20,17,16,25,0,1,18,16,17,21,0,80,80,17,19,72,65,64,16,16,17,20,17,5,1,65,65]

theorem envBound14060 : H12AffineFastState.Bounded env14060 := by
  intro p hp
  have h : env14060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14059_14060 : H12AffineEnvironment.transform 9 20 env14059 = env14060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14059 == env14060) = true)

theorem identity14060 : scanCanonicalize (H12AffineFastState.compose env14060 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 21) := by decide +kernel

theorem selectedBound14060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14061 : List Nat := [2,4,8,16,1,21,12,4,20,20,17,16,25,0,1,18,16,17,21,0,5,5,17,19,29,20,21,16,16,17,20,17,5,1,20,20]

theorem envBound14061 : H12AffineFastState.Bounded env14061 := by
  intro p hp
  have h : env14061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14060_14061 : H12AffineEnvironment.transform 5 21 env14060 = env14061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env14060 == env14061) = true)

theorem identity14061 : scanCanonicalize (H12AffineFastState.compose env14061 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14061 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14062 : List Nat := [2,4,8,0,1,5,12,4,4,4,1,0,9,0,1,2,0,1,5,0,5,5,1,3,13,4,5,0,0,1,4,1,5,1,4,4]

theorem envBound14062 : H12AffineFastState.Bounded env14062 := by
  intro p hp
  have h : env14062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14061_14062 : H12AffineEnvironment.transform 3 0 env14061 = env14062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14061 == env14062) = true)

def env14063 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318700,351453,8328,65,262281,313360,301056,23804,1056,272392,252,21725,46212,74251]

theorem envBound14063 : H12AffineFastState.Bounded env14063 := by
  intro p hp
  have h : env14063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14037_14063 : H12AffineEnvironment.transform 7 253 env14037 = env14063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env14037 == env14063) = true)

theorem identity14063 : scanCanonicalize (H12AffineFastState.compose env14063 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14063 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14064 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,168,318700,294103,8328,65,262281,313360,301056,23804,1056,272392,252,21725,46212,513]

theorem envBound14064 : H12AffineFastState.Bounded env14064 := by
  intro p hp
  have h : env14064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14063_14064 : H12AffineEnvironment.transform 15 8202 env14063 = env14064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14063 == env14064) = true)

def env14065 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,32,318564,293983,8192,65,262145,313360,301056,23668,1056,272392,116,21589,46092,513]

theorem envBound14065 : H12AffineFastState.Bounded env14065 := by
  intro p hp
  have h : env14065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14064_14065 : H12AffineEnvironment.transform 6 8 env14064 = env14065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14064 == env14065) = true)

theorem identity14065 : scanCanonicalize (H12AffineFastState.compose env14065 (packedSelected [2,4,6,9,11,14,17,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 28776) := by decide +kernel

theorem selectedBound14065 : packedSelected [2,4,6,9,11,14,17,20,23] rootPS < 2^1333 := by decide +kernel

def env14066 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,28776,8202,16400,262144,1025,28777,4160,32,273420,293983,8192,65,262145,276600,288872,23668,1056,272392,116,21589,17508,513]

theorem envBound14066 : H12AffineFastState.Bounded env14066 := by
  intro p hp
  have h : env14066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14065_14066 : H12AffineEnvironment.transform 14 28776 env14065 = env14066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28776 env14065 == env14066) = true)

theorem identity14066 : scanCanonicalize (H12AffineFastState.compose env14066 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 30824) := by decide +kernel

theorem selectedBound14066 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env14067 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,28776,8202,16400,30824,1025,28777,4160,32,21604,1079,8192,65,30825,16400,4096,23668,1056,20576,116,21589,17508,513]

theorem envBound14067 : H12AffineFastState.Bounded env14067 := by
  intro p hp
  have h : env14067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14066_14067 : H12AffineEnvironment.transform 17 30824 env14066 = env14067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30824 env14066 == env14067) = true)

theorem identity14067 : scanCanonicalize (H12AffineFastState.compose env14067 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14067 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env14068 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13324,1124,8202,13340,3172,1025,1125,4160,32,8296,1079,8192,65,3173,13340,4096,10360,1056,9324,116,8281,12392,513]

theorem envBound14068 : H12AffineFastState.Bounded env14068 := by
  intro p hp
  have h : env14068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14067_14068 : H12AffineEnvironment.transform 13 13324 env14067 = env14068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14067 == env14068) = true)

theorem identity14068 : scanCanonicalize (H12AffineFastState.compose env14068 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14068 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14069 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,8192,12345,81,8202,12329,2129,52,80,4160,32,8296,2,8192,65,2128,12329,4096,10360,21,8281,116,8281,12392,513]

theorem envBound14069 : H12AffineFastState.Bounded env14069 := by
  intro p hp
  have h : env14069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14068_14069 : H12AffineEnvironment.transform 9 53 env14068 = env14069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14068 == env14069) = true)

theorem identity14069 : scanCanonicalize (H12AffineFastState.compose env14069 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound14069 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1