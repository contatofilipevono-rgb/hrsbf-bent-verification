import H12CloudChart1Data160

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans40829_40830 : H12AffineEnvironment.transform 4 20 env40829 = env40830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env40829 == env40830) = true)

theorem identity40830 : scanCanonicalize (H12AffineFastState.compose env40830 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40830 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40831 : List Nat := [2,4,8,12,8,12,9,3,13,3,15,3,15,9,1,15,4,10,2,0,14,9,13,8,14,13,4,15,9,11,5,3,2,2,3,7]

theorem envBound40831 : H12AffineFastState.Bounded env40831 := by
  intro p hp
  have h : env40831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40830_40831 : H12AffineEnvironment.transform 3 12 env40830 = env40831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40830 == env40831) = true)

theorem identity40831 : scanCanonicalize (H12AffineFastState.compose env40831 (packedSelected [1,10] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40831 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env40832 : List Nat := [2,4,1,5,1,5,0,3,4,3,6,3,6,0,1,6,4,3,2,0,7,0,4,1,7,4,4,6,0,2,5,3,2,2,3,7]

theorem envBound40832 : H12AffineFastState.Bounded env40832 := by
  intro p hp
  have h : env40832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40831_40832 : H12AffineEnvironment.transform 2 1 env40831 = env40832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40831 == env40832) = true)

theorem identity40832 : scanCanonicalize (H12AffineFastState.compose env40832 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40833 : List Nat := [1,4,1,5,1,5,0,0,4,0,5,0,5,0,1,5,4,0,1,0,4,0,4,1,4,4,4,5,0,1,5,0,1,1,0,4]

theorem envBound40833 : H12AffineFastState.Bounded env40833 := by
  intro p hp
  have h : env40833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40832_40833 : H12AffineEnvironment.transform 0 1 env40832 = env40833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40832 == env40833) = true)

theorem identity40833 : scanCanonicalize (H12AffineFastState.compose env40833 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40834 : List Nat := [1,1,1,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,1,1,1,1,0,0,1,0,0,1,1,0,1]

theorem envBound40834 : H12AffineFastState.Bounded env40834 := by
  intro p hp
  have h : env40834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40833_40834 : H12AffineEnvironment.transform 1 1 env40833 = env40834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40833 == env40834) = true)

def env40835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458737,8393984,10507600,8527101,2102684,12645453,257,21793,46213,2175562]

theorem envBound40835 : H12AffineFastState.Bounded env40835 := by
  intro p hp
  have h : env40835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40737_40835 : H12AffineEnvironment.transform 17 56573 env40737 = env40835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env40737 == env40835) = true)

def env40836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,8388608,8487373,8328,65,4365617,8393984,8406288,8527101,1500,12645453,257,21793,46213,74250]

theorem envBound40836 : H12AffineFastState.Bounded env40836 := by
  intro p hp
  have h : env40836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40835_40836 : H12AffineEnvironment.transform 20 4160 env40835 = env40836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40835 == env40836) = true)

def env40837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,16,98781,8328,65,4365617,5392,17664,138477,1500,4256861,257,21793,46213,74250]

theorem envBound40837 : H12AffineFastState.Bounded env40837 := by
  intro p hp
  have h : env40837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40836_40837 : H12AffineEnvironment.transform 22 16 env40836 = env40837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40836 == env40837) = true)

theorem identity40837 : scanCanonicalize (H12AffineFastState.compose env40837 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound40837 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,62589,16,98781,8328,65,158028,5392,17664,138477,1500,32,257,21793,46213,74250]

theorem envBound40838 : H12AffineFastState.Bounded env40838 := by
  intro p hp
  have h : env40838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40837_40838 : H12AffineEnvironment.transform 21 62589 env40837 = env40838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env40837 == env40838) = true)

theorem identity40838 : scanCanonicalize (H12AffineFastState.compose env40838 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40838 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56573,1025,32769,4160,62589,16,41430,8328,65,158028,5392,17664,138477,1500,32,257,21793,46213,513]

theorem envBound40839 : H12AffineFastState.Bounded env40839 := by
  intro p hp
  have h : env40839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40838_40839 : H12AffineEnvironment.transform 15 8203 env40838 = env40839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40838 == env40839) = true)

theorem identity40839 : scanCanonicalize (H12AffineFastState.compose env40839 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound40839 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56573,1025,32769,4160,62589,16,41430,8328,65,10588,5392,17664,23805,1500,32,257,21793,46213,513]

theorem envBound40840 : H12AffineFastState.Bounded env40840 := by
  intro p hp
  have h : env40840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40839_40840 : H12AffineEnvironment.transform 16 16400 env40839 = env40840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40839 == env40840) = true)

def env40841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,17,98780,8328,65,4365617,5393,17665,138476,1500,4256860,257,21793,46213,74250]

theorem envBound40841 : H12AffineFastState.Bounded env40841 := by
  intro p hp
  have h : env40841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40836_40841 : H12AffineEnvironment.transform 22 17 env40836 = env40841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40836 == env40841) = true)

theorem identity40841 : scanCanonicalize (H12AffineFastState.compose env40841 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40841 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10281,1025,29909,4160,4194304,17,95496,8328,65,4352485,5393,17665,138476,1500,4194440,257,21793,16465,74250]

theorem envBound40842 : H12AffineFastState.Bounded env40842 := by
  intro p hp
  have h : env40842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40841_40842 : H12AffineEnvironment.transform 14 29908 env40841 = env40842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40841 == env40842) = true)

def env40843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1025,8661,4160,4194304,17,73736,8328,65,4340965,5393,4097,138476,1500,4194440,257,33,5457,74250]

theorem envBound40843 : H12AffineFastState.Bounded env40843 := by
  intro p hp
  have h : env40843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40842_40843 : H12AffineEnvironment.transform 13 5376 env40842 = env40843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40842 == env40843) = true)

theorem identity40843 : scanCanonicalize (H12AffineFastState.compose env40843 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,4160,4194304,17,73736,8193,65,4340844,5393,4097,138341,1365,4194305,257,33,5457,74250]

theorem envBound40844 : H12AffineFastState.Bounded env40844 := by
  intro p hp
  have h : env40844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40843_40844 : H12AffineEnvironment.transform 6 9 env40843 = env40844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40843 == env40844) = true)

theorem identity40844 : scanCanonicalize (H12AffineFastState.compose env40844 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210235) := by decide +kernel

theorem selectedBound40844 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env40845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,4160,210235,17,73736,8193,65,67927,5393,4097,138341,1365,210234,257,33,5457,74250]

theorem envBound40845 : H12AffineFastState.Bounded env40845 := by
  intro p hp
  have h : env40845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40844_40845 : H12AffineEnvironment.transform 21 210235 env40844 = env40845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210235 env40844 == env40845) = true)

theorem identity40845 : scanCanonicalize (H12AffineFastState.compose env40845 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound40845 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env40846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10281,1025,8540,4160,32,17,73736,8193,65,67927,5393,4097,76158,1365,33,257,33,5457,74250]

theorem envBound40846 : H12AffineFastState.Bounded env40846 := by
  intro p hp
  have h : env40846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40845_40846 : H12AffineEnvironment.transform 16 79131 env40845 = env40846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env40845 == env40846) = true)

theorem identity40846 : scanCanonicalize (H12AffineFastState.compose env40846 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40846 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,372,65536,70962,2048,1025,373,4160,32,17,65569,40,65,67927,5393,4097,67927,1365,33,257,33,5457,66083]

theorem envBound40847 : H12AffineFastState.Bounded env40847 := by
  intro p hp
  have h : env40847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40846_40847 : H12AffineEnvironment.transform 12 41 env40846 = env40847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40846 == env40847) = true)

theorem identity40847 : scanCanonicalize (H12AffineFastState.compose env40847 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 4439) := by decide +kernel

theorem selectedBound40847 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,372,4439,1125,2048,1025,373,4160,32,17,4470,40,65,6144,5393,4097,6144,1365,33,257,33,5457,4980]

theorem envBound40848 : H12AffineFastState.Bounded env40848 := by
  intro p hp
  have h : env40848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40847_40848 : H12AffineEnvironment.transform 15 4439 env40847 = env40848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4439 env40847 == env40848) = true)

def env40849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1025,8660,4160,4194304,17,73737,8328,65,4340964,5393,4096,138476,1500,4194440,257,32,5456,74250]

theorem envBound40849 : H12AffineFastState.Bounded env40849 := by
  intro p hp
  have h : env40849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40842_40849 : H12AffineEnvironment.transform 13 5377 env40842 = env40849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40842 == env40849) = true)

theorem identity40849 : scanCanonicalize (H12AffineFastState.compose env40849 (packedSelected [0,2,5,6,7,8,10,11,12,14,16,18,19,24,28,35,41] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound40849 : packedSelected [0,2,5,6,7,8,10,11,12,14,16,18,19,24,28,35,41] rootPS < 2^1333 := by decide +kernel

def env40850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1025,8660,4160,168,17,73737,8328,65,146508,5393,4096,138476,1500,32,257,32,5456,74250]

theorem envBound40850 : H12AffineFastState.Bounded env40850 := by
  intro p hp
  have h : env40850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40849_40850 : H12AffineEnvironment.transform 21 168 env40849 = env40850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env40849 == env40850) = true)

theorem identity40850 : scanCanonicalize (H12AffineFastState.compose env40850 (packedSelected [2,5,6,7,8,9,10,11,16,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound40850 : packedSelected [2,5,6,7,8,9,10,11,16,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79250,10281,1025,8660,4160,168,17,73737,8328,65,68062,5393,4096,76158,1500,32,257,32,5456,74250]

theorem envBound40851 : H12AffineFastState.Bounded env40851 := by
  intro p hp
  have h : env40851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40850_40851 : H12AffineEnvironment.transform 16 79250 env40850 = env40851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env40850 == env40851) = true)

theorem identity40851 : scanCanonicalize (H12AffineFastState.compose env40851 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound40851 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env40852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,128,5377,341,65536,70930,2217,1025,340,4160,168,17,65673,8,65,68062,5393,4096,68094,1500,32,257,32,5456,66186]

theorem envBound40852 : H12AffineFastState.Bounded env40852 := by
  intro p hp
  have h : env40852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40851_40852 : H12AffineEnvironment.transform 12 128 env40851 = env40852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env40851 == env40852) = true)

theorem identity40852 : scanCanonicalize (H12AffineFastState.compose env40852 (packedSelected [0,3,4,5,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound40852 : packedSelected [0,3,4,5,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env40853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,128,5377,341,343,5189,2217,1025,340,4160,168,17,478,8,65,2185,5393,4096,2217,1500,32,257,32,5456,989]

theorem envBound40853 : H12AffineFastState.Bounded env40853 := by
  intro p hp
  have h : env40853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40852_40853 : H12AffineEnvironment.transform 15 343 env40852 = env40853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env40852 == env40853) = true)

theorem identity40853 : scanCanonicalize (H12AffineFastState.compose env40853 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound40853 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env40854 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,128,5341,137,139,5189,2217,1025,136,4160,168,17,2,8,65,2185,5325,4096,2217,1024,32,221,32,5260,513]

theorem envBound40854 : H12AffineFastState.Bounded env40854 := by
  intro p hp
  have h : env40854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40853_40854 : H12AffineEnvironment.transform 7 220 env40853 = env40854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env40853 == env40854) = true)

def env40855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,8388608,8487372,8328,65,4365616,8393984,8406289,8527101,1501,12645453,257,21793,46213,74251]

theorem envBound40855 : H12AffineFastState.Bounded env40855 := by
  intro p hp
  have h : env40855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40835_40855 : H12AffineEnvironment.transform 20 4161 env40835 = env40855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40835 == env40855) = true)

def env40856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,16,98780,8328,65,4365616,5392,17665,138477,1501,4256861,257,21793,46213,74251]

theorem envBound40856 : H12AffineFastState.Bounded env40856 := by
  intro p hp
  have h : env40856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40855_40856 : H12AffineEnvironment.transform 22 16 env40855 = env40856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40855 == env40856) = true)

theorem identity40856 : scanCanonicalize (H12AffineFastState.compose env40856 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound40856 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,169,16,98780,8328,65,171417,5392,17665,138477,1501,62708,257,21793,46213,74251]

theorem envBound40857 : H12AffineFastState.Bounded env40857 := by
  intro p hp
  have h : env40857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40856_40857 : H12AffineEnvironment.transform 21 169 env40856 = env40857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env40856 == env40857) = true)

def env40858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,16,98644,8192,65,171281,5392,17665,138341,1365,62588,257,21793,46093,74251]

theorem envBound40858 : H12AffineFastState.Bounded env40858 := by
  intro p hp
  have h : env40858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40857_40858 : H12AffineEnvironment.transform 6 8 env40857 = env40858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40857 == env40858) = true)

theorem identity40858 : scanCanonicalize (H12AffineFastState.compose env40858 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40858 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1025,32769,4161,33,16,98644,8192,65,171281,5392,4097,138341,1365,41340,257,33,46093,74251]

theorem envBound40859 : H12AffineFastState.Bounded env40859 := by
  intro p hp
  have h : env40859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40858_40859 : H12AffineEnvironment.transform 13 5376 env40858 = env40859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40858 == env40859) = true)

theorem identity40859 : scanCanonicalize (H12AffineFastState.compose env40859 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound40859 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,35189,1025,32769,4161,33,16,98644,8192,65,34817,5392,4097,2421,1365,41340,257,33,46093,74251]

theorem envBound40860 : H12AffineFastState.Bounded env40860 := by
  intro p hp
  have h : env40860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40859_40860 : H12AffineEnvironment.transform 16 5392 env40859 = env40860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env40859 == env40860) = true)

theorem identity40860 : scanCanonicalize (H12AffineFastState.compose env40860 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40860 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35189,1025,32769,4161,33,16,41311,8192,65,34817,5392,4097,2421,1365,41340,257,33,46093,512]

theorem envBound40861 : H12AffineFastState.Bounded env40861 := by
  intro p hp
  have h : env40861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40860_40861 : H12AffineEnvironment.transform 15 8203 env40860 = env40861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40860 == env40861) = true)

theorem identity40861 : scanCanonicalize (H12AffineFastState.compose env40861 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound40861 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8200,8203,5392,10621,1025,8201,4161,33,16,343,8192,65,10249,5392,4097,2421,1365,372,257,33,5125,512]

theorem envBound40862 : H12AffineFastState.Bounded env40862 := by
  intro p hp
  have h : env40862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40861_40862 : H12AffineEnvironment.transform 14 8200 env40861 = env40862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env40861 == env40862) = true)

theorem identity40862 : scanCanonicalize (H12AffineFastState.compose env40862 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40862 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env40863 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8200,8203,5221,10248,1025,8201,4161,33,16,34,8192,65,10249,5221,4097,2048,1056,1,116,33,5125,512]

theorem envBound40863 : H12AffineFastState.Bounded env40863 := by
  intro p hp
  have h : env40863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40862_40863 : H12AffineEnvironment.transform 7 117 env40862 = env40863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40862 == env40863) = true)

theorem identity40863 : scanCanonicalize (H12AffineFastState.compose env40863 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound40863 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40864 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2170,8192,3087,8200,8203,3103,10248,1025,8201,2107,33,16,34,8192,65,10249,3103,2171,2048,1056,1,116,33,3199,512]

theorem envBound40864 : H12AffineFastState.Bounded env40864 := by
  intro p hp
  have h : env40864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40863_40864 : H12AffineEnvironment.transform 11 2170 env40863 = env40864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env40863 == env40864) = true)

theorem identity40864 : scanCanonicalize (H12AffineFastState.compose env40864 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound40864 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40865 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2170,89,3087,81,82,3103,2129,1025,80,2107,33,16,34,89,65,2128,3103,2171,2048,1056,1,116,33,3199,512]

theorem envBound40865 : H12AffineFastState.Bounded env40865 := by
  intro p hp
  have h : env40865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40864_40865 : H12AffineEnvironment.transform 12 89 env40864 = env40865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env40864 == env40865) = true)

theorem identity40865 : scanCanonicalize (H12AffineFastState.compose env40865 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40865 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env40866 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2090,9,3087,1,2,3103,2049,1025,0,2107,33,16,34,9,17,2048,3103,2091,2048,1056,1,36,33,3119,512]

theorem envBound40866 : H12AffineFastState.Bounded env40866 := by
  intro p hp
  have h : env40866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40865_40866 : H12AffineEnvironment.transform 5 16 env40865 = env40866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40865 == env40866) = true)

theorem identity40866 : scanCanonicalize (H12AffineFastState.compose env40866 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound40866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40867 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,2090,9,2090,1,2,2106,2049,36,0,2107,33,16,34,9,17,2048,2106,2091,2048,5,1,36,33,2058,512]

theorem envBound40867 : H12AffineFastState.Bounded env40867 := by
  intro p hp
  have h : env40867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40866_40867 : H12AffineEnvironment.transform 9 37 env40866 = env40867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env40866 == env40867) = true)

theorem identity40867 : scanCanonicalize (H12AffineFastState.compose env40867 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40867 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env40868 : List Nat := [2,4,2,16,32,16,2,37,512,37,2048,2080,3,2080,1,2,2096,2049,36,0,2097,33,16,34,3,17,2048,2096,2081,2048,5,1,36,33,2048,512]

theorem envBound40868 : H12AffineFastState.Bounded env40868 := by
  intro p hp
  have h : env40868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40867_40868 : H12AffineEnvironment.transform 2 2 env40867 = env40868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40867 == env40868) = true)

theorem identity40868 : scanCanonicalize (H12AffineFastState.compose env40868 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40868 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40869 : List Nat := [2,4,2,1,32,1,2,37,512,37,2048,2080,3,2080,1,2,2081,2049,36,0,2080,33,1,34,3,0,2048,2081,2081,2048,5,1,36,33,2048,512]

theorem envBound40869 : H12AffineFastState.Bounded env40869 := by
  intro p hp
  have h : env40869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40868_40869 : H12AffineEnvironment.transform 3 1 env40868 = env40869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40868 == env40869) = true)

theorem identity40869 : scanCanonicalize (H12AffineFastState.compose env40869 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 548) := by decide +kernel

theorem selectedBound40869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40870 : List Nat := [2,4,2,1,32,1,2,37,512,37,548,516,3,516,1,2,517,549,36,0,516,33,1,34,3,0,548,517,517,548,5,1,36,33,548,512]

theorem envBound40870 : H12AffineFastState.Bounded env40870 := by
  intro p hp
  have h : env40870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40869_40870 : H12AffineEnvironment.transform 10 548 env40869 = env40870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 548 env40869 == env40870) = true)

theorem identity40870 : scanCanonicalize (H12AffineFastState.compose env40870 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40870 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40871 : List Nat := [2,4,2,1,0,1,2,5,512,5,516,516,3,516,1,2,517,517,4,0,516,1,1,2,3,0,516,517,517,516,5,1,4,1,516,512]

theorem envBound40871 : H12AffineFastState.Bounded env40871 := by
  intro p hp
  have h : env40871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40870_40871 : H12AffineEnvironment.transform 4 0 env40870 = env40871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40870 == env40871) = true)

theorem identity40871 : scanCanonicalize (H12AffineFastState.compose env40871 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40872 : List Nat := [2,3,2,1,0,1,2,2,512,2,515,515,3,515,1,2,514,514,3,0,515,1,1,2,3,0,515,514,514,515,2,1,3,1,515,512]

theorem envBound40872 : H12AffineFastState.Bounded env40872 := by
  intro p hp
  have h : env40872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40871_40872 : H12AffineEnvironment.transform 1 3 env40871 = env40872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40871 == env40872) = true)

theorem identity40872 : scanCanonicalize (H12AffineFastState.compose env40872 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40872 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40873 : List Nat := [0,1,0,1,0,1,0,0,512,0,513,513,1,513,1,0,512,512,1,0,513,1,1,0,1,0,513,512,512,513,0,1,1,1,513,512]

theorem envBound40873 : H12AffineFastState.Bounded env40873 := by
  intro p hp
  have h : env40873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40872_40873 : H12AffineEnvironment.transform 0 0 env40872 = env40873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40872 == env40873) = true)

theorem identity40873 : scanCanonicalize (H12AffineFastState.compose env40873 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40873 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env40874 : List Nat := [0,1,0,1,0,1,0,0,0,0,1,1,1,1,1,0,0,0,1,0,1,1,1,0,1,0,1,0,0,1,0,1,1,1,1,0]

theorem envBound40874 : H12AffineFastState.Bounded env40874 := by
  intro p hp
  have h : env40874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40873_40874 : H12AffineEnvironment.transform 8 0 env40873 = env40874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40873 == env40874) = true)

def env40875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,32,16,98645,8193,65,171280,5392,17665,138340,1364,62589,257,21793,46092,74251]

theorem envBound40875 : H12AffineFastState.Bounded env40875 := by
  intro p hp
  have h : env40875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40857_40875 : H12AffineEnvironment.transform 6 9 env40857 = env40875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40857 == env40875) = true)

theorem identity40875 : scanCanonicalize (H12AffineFastState.compose env40875 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound40875 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,4161,32,16,95496,8193,65,158029,5392,17665,138340,1364,32,257,21793,16465,74251]

theorem envBound40876 : H12AffineFastState.Bounded env40876 := by
  intro p hp
  have h : env40876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40875_40876 : H12AffineEnvironment.transform 14 29789 env40875 = env40876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env40875 == env40876) = true)

theorem identity40876 : scanCanonicalize (H12AffineFastState.compose env40876 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40876 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16401,10281,1025,29788,4161,32,16,95496,8193,65,10588,5392,17665,23669,1364,32,257,21793,16465,74251]

theorem envBound40877 : H12AffineFastState.Bounded env40877 := by
  intro p hp
  have h : env40877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40876_40877 : H12AffineEnvironment.transform 16 16401 env40876 = env40877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40876 == env40877) = true)

theorem identity40877 : scanCanonicalize (H12AffineFastState.compose env40877 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40877 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env40878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5392,10281,1025,8541,4161,32,16,73737,8193,65,10588,5392,4096,2420,1364,32,257,32,5456,74251]

theorem envBound40878 : H12AffineFastState.Bounded env40878 := by
  intro p hp
  have h : env40878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40877_40878 : H12AffineEnvironment.transform 13 5377 env40877 = env40878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40877 == env40878) = true)

theorem identity40878 : scanCanonicalize (H12AffineFastState.compose env40878 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound40878 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,82,5392,10281,1025,8541,4161,32,16,8283,8193,65,10588,5392,4096,2420,1364,32,257,32,5456,8793]

theorem envBound40879 : H12AffineFastState.Bounded env40879 := by
  intro p hp
  have h : env40879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40878_40879 : H12AffineEnvironment.transform 15 82 env40878 = env40879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env40878 == env40879) = true)

theorem identity40879 : scanCanonicalize (H12AffineFastState.compose env40879 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound40879 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5377,260,82,5392,2161,1025,261,4161,32,16,3,89,65,2308,5392,4096,2420,1364,32,257,32,5456,513]

theorem envBound40880 : H12AffineFastState.Bounded env40880 := by
  intro p hp
  have h : env40880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40879_40880 : H12AffineEnvironment.transform 12 88 env40879 = env40880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env40879 == env40880) = true)

theorem identity40880 : scanCanonicalize (H12AffineFastState.compose env40880 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40880 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40881 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5377,260,2,5392,2081,1025,261,4113,32,16,3,9,17,2308,5392,4096,2340,1284,32,257,32,5376,513]

theorem envBound40881 : H12AffineFastState.Bounded env40881 := by
  intro p hp
  have h : env40881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40880_40881 : H12AffineEnvironment.transform 5 16 env40880 = env40881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40880 == env40881) = true)

theorem identity40881 : scanCanonicalize (H12AffineFastState.compose env40881 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound40881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40882 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,8,1061,260,2,1076,2081,1025,261,309,32,16,3,9,17,2308,1076,292,2340,1284,32,257,32,1060,513]

theorem envBound40882 : H12AffineFastState.Bounded env40882 := by
  intro p hp
  have h : env40882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40881_40882 : H12AffineEnvironment.transform 11 292 env40881 = env40882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env40881 == env40882) = true)

theorem identity40882 : scanCanonicalize (H12AffineFastState.compose env40882 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40882 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40883 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,292,8,1061,260,2,1076,2081,1025,261,309,32,16,3,9,17,2308,1076,292,2340,1284,32,257,32,1060,1]

theorem envBound40883 : H12AffineFastState.Bounded env40883 := by
  intro p hp
  have h : env40883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40882_40883 : H12AffineEnvironment.transform 8 0 env40882 = env40883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40882 == env40883) = true)

def env40884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,17,98781,8328,65,4365616,5393,17664,138476,1501,4256860,257,21793,46213,74251]

theorem envBound40884 : H12AffineFastState.Bounded env40884 := by
  intro p hp
  have h : env40884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40855_40884 : H12AffineEnvironment.transform 22 17 env40855 = env40884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40855 == env40884) = true)

def env40885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,17,98645,8192,65,4365616,5393,17664,138340,1365,4256860,257,21793,46093,74251]

theorem envBound40885 : H12AffineFastState.Bounded env40885 := by
  intro p hp
  have h : env40885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40884_40885 : H12AffineEnvironment.transform 6 8 env40884 = env40885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40884 == env40885) = true)

theorem identity40885 : scanCanonicalize (H12AffineFastState.compose env40885 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40885 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32040,1025,8540,4161,4194304,17,73736,8192,65,4340845,5393,17664,138340,1365,4216065,257,21793,5456,74251]

theorem envBound40886 : H12AffineFastState.Bounded env40886 := by
  intro p hp
  have h : env40886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40885_40886 : H12AffineEnvironment.transform 14 8541 env40885 = env40886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40885 == env40886) = true)

theorem identity40886 : scanCanonicalize (H12AffineFastState.compose env40886 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40886 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,32040,1025,8540,4161,4194304,17,73736,8192,65,4283510,5393,17664,97407,1365,4216065,257,21793,5456,74251]

theorem envBound40887 : H12AffineFastState.Bounded env40887 := by
  intro p hp
  have h : env40887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40886_40887 : H12AffineEnvironment.transform 16 90139 env40886 = env40887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40886 == env40887) = true)

theorem identity40887 : scanCanonicalize (H12AffineFastState.compose env40887 (packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound40887 : packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS < 2^1333 := by decide +kernel

def env40888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8574,16741,32040,1025,8540,4161,4194304,17,374,8192,65,4226312,5393,17664,23809,1365,4216065,257,21793,5456,885]

theorem envBound40888 : H12AffineFastState.Bounded env40888 := by
  intro p hp
  have h : env40888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40887_40888 : H12AffineEnvironment.transform 15 8574 env40887 = env40888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env40887 == env40888) = true)

theorem identity40888 : scanCanonicalize (H12AffineFastState.compose env40888 (packedSelected [3,5,10,15,41] rootPS)) = affineNative (2^(21+1) ^^^ 21589) := by decide +kernel

theorem selectedBound40888 : packedSelected [3,5,10,15,41] rootPS < 2^1333 := by decide +kernel

def env40889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8574,16741,32040,1025,8540,4161,21589,17,374,8192,65,10589,5393,17664,23809,1365,340,257,21793,5456,885]

theorem envBound40889 : H12AffineFastState.Bounded env40889 := by
  intro p hp
  have h : env40889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40888_40889 : H12AffineEnvironment.transform 21 21589 env40888 = env40889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21589 env40888 == env40889) = true)

theorem identity40889 : scanCanonicalize (H12AffineFastState.compose env40889 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40889 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40890 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8233,8202,16401,31836,1025,8232,4161,21589,17,2,8192,65,10281,5221,17524,23669,1057,32,117,21589,5156,513]

theorem envBound40890 : H12AffineFastState.Bounded env40890 := by
  intro p hp
  have h : env40890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40889_40890 : H12AffineEnvironment.transform 7 116 env40889 = env40890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40889 == env40890) = true)

theorem identity40890 : scanCanonicalize (H12AffineFastState.compose env40890 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40890 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40891 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,8233,8202,5172,10361,1025,8232,4161,112,17,2,8192,65,10281,5221,4177,2128,1057,32,117,112,5156,513]

theorem envBound40891 : H12AffineFastState.Bounded env40891 := by
  intro p hp
  have h : env40891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40890_40891 : H12AffineEnvironment.transform 13 5157 env40890 = env40891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40890 == env40891) = true)

theorem identity40891 : scanCanonicalize (H12AffineFastState.compose env40891 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound40891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40892 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,8192,4160,8233,8202,4177,10361,100,8232,4161,112,17,2,8192,65,10281,4096,4177,2128,68,32,117,112,4161,513]

theorem envBound40892 : H12AffineFastState.Bounded env40892 := by
  intro p hp
  have h : env40892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40891_40892 : H12AffineEnvironment.transform 9 101 env40891 = env40892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env40891 == env40892) = true)

theorem identity40892 : scanCanonicalize (H12AffineFastState.compose env40892 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40892 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40893 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,41,4160,0,35,4177,2128,100,1,4161,112,17,2,41,65,2048,4096,4177,2128,68,32,117,112,4161,513]

theorem envBound40893 : H12AffineFastState.Bounded env40893 := by
  intro p hp
  have h : env40893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40892_40893 : H12AffineEnvironment.transform 12 41 env40892 = env40893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40892 == env40893) = true)

theorem identity40893 : scanCanonicalize (H12AffineFastState.compose env40893 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound40893 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40894 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,65,41,1,0,35,16,2128,100,1,0,112,17,2,41,65,2048,65,16,2128,68,32,117,112,0,513]

theorem envBound40894 : H12AffineFastState.Bounded env40894 := by
  intro p hp
  have h : env40894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40893_40894 : H12AffineEnvironment.transform 11 65 env40893 = env40894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env40893 == env40894) = true)

theorem identity40894 : scanCanonicalize (H12AffineFastState.compose env40894 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound40894 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40895 : List Nat := [2,4,8,16,32,64,8,116,512,101,81,65,41,1,0,35,16,1,100,1,0,112,17,2,41,65,81,65,16,1,68,32,117,112,0,513]

theorem envBound40895 : H12AffineFastState.Bounded env40895 := by
  intro p hp
  have h : env40895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40894_40895 : H12AffineEnvironment.transform 10 81 env40894 = env40895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env40894 == env40895) = true)

def env40896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,4194304,17,98644,8193,65,4365616,5393,17664,138341,1364,4256860,257,21793,46092,74251]

theorem envBound40896 : H12AffineFastState.Bounded env40896 := by
  intro p hp
  have h : env40896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40884_40896 : H12AffineEnvironment.transform 6 9 env40884 = env40896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40884 == env40896) = true)

theorem identity40896 : scanCanonicalize (H12AffineFastState.compose env40896 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40896 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4161,4194304,17,41310,8193,65,4365616,5393,17664,138341,1364,4256860,257,21793,46092,513]

theorem envBound40897 : H12AffineFastState.Bounded env40897 := by
  intro p hp
  have h : env40897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40896_40897 : H12AffineEnvironment.transform 15 8202 env40896 = env40897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40896 == env40897) = true)

theorem identity40897 : scanCanonicalize (H12AffineFastState.compose env40897 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound40897 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4161,112,17,41310,8193,65,171328,5393,17664,138341,1364,62508,257,21793,46092,513]

theorem envBound40898 : H12AffineFastState.Bounded env40898 := by
  intro p hp
  have h : env40898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40897_40898 : H12AffineEnvironment.transform 21 112 env40897 = env40898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env40897 == env40898) = true)

def env40899 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4113,32,17,41230,8193,17,171280,5393,17664,138293,1284,62508,257,21793,46092,513]

theorem envBound40899 : H12AffineFastState.Bounded env40899 := by
  intro p hp
  have h : env40899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40898_40899 : H12AffineEnvironment.transform 5 16 env40898 = env40899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40898 == env40899) = true)

theorem identity40899 : scanCanonicalize (H12AffineFastState.compose env40899 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound40899 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env40900 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,13341,56356,1025,32769,4113,32,17,41230,8193,17,43277,5393,17664,10280,1284,62508,257,21793,46092,513]

theorem envBound40900 : H12AffineFastState.Bounded env40900 := by
  intro p hp
  have h : env40900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40899_40900 : H12AffineEnvironment.transform 16 13341 env40899 = env40900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env40899 == env40900) = true)

theorem identity40900 : scanCanonicalize (H12AffineFastState.compose env40900 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40900 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40901 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,5392,56356,1025,32769,4113,32,17,32771,268,17,34816,5393,17664,2341,1284,54561,257,21793,38145,513]

theorem envBound40901 : H12AffineFastState.Bounded env40901 := by
  intro p hp
  have h : env40901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40900_40901 : H12AffineEnvironment.transform 12 269 env40900 = env40901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40900 == env40901) = true)

theorem identity40901 : scanCanonicalize (H12AffineFastState.compose env40901 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound40901 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40902 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,263,5392,2340,1025,21761,4113,32,17,21763,268,17,23808,5393,17664,2341,1284,33,257,21793,16385,513]

theorem envBound40902 : H12AffineFastState.Bounded env40902 := by
  intro p hp
  have h : env40902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40901_40902 : H12AffineEnvironment.transform 14 21760 env40901 = env40902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env40901 == env40902) = true)

theorem identity40902 : scanCanonicalize (H12AffineFastState.compose env40902 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40902 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40903 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5392,2340,1025,0,4113,32,17,2,268,17,2049,5393,4097,2341,1284,33,257,32,5376,513]

theorem envBound40903 : H12AffineFastState.Bounded env40903 := by
  intro p hp
  have h : env40903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40902_40903 : H12AffineEnvironment.transform 13 5377 env40902 = env40903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40902 == env40903) = true)

theorem identity40903 : scanCanonicalize (H12AffineFastState.compose env40903 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40904 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5125,1,3,5140,2080,1025,0,4113,32,17,2,8,17,2049,5141,4097,2081,1024,33,5,32,5124,513]

theorem envBound40904 : H12AffineFastState.Bounded env40904 := by
  intro p hp
  have h : env40904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40903_40904 : H12AffineEnvironment.transform 7 4 env40903 = env40904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40903 == env40904) = true)

theorem identity40904 : scanCanonicalize (H12AffineFastState.compose env40904 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40904 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40905 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,4096,9,4144,1,3,4129,2080,52,0,4113,32,17,2,8,17,2049,4128,4097,2081,53,33,5,32,4145,513]

theorem envBound40905 : H12AffineFastState.Bounded env40905 := by
  intro p hp
  have h : env40905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40904_40905 : H12AffineEnvironment.transform 9 53 env40904 = env40905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40904 == env40905) = true)

theorem identity40905 : scanCanonicalize (H12AffineFastState.compose env40905 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound40905 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40906 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,2609,9,2561,1,3,2576,2080,52,0,2592,32,17,2,8,17,2049,2577,2608,2081,53,33,5,32,2560,513]

theorem envBound40906 : H12AffineFastState.Bounded env40906 := by
  intro p hp
  have h : env40906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40905_40906 : H12AffineEnvironment.transform 11 2609 env40905 = env40906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env40905 == env40906) = true)

theorem identity40906 : scanCanonicalize (H12AffineFastState.compose env40906 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound40906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40907 : List Nat := [2,4,8,16,32,16,9,4,512,53,529,32,9,16,1,3,1,561,52,0,49,32,17,2,8,17,528,0,33,560,53,33,5,32,17,513]

theorem envBound40907 : H12AffineFastState.Bounded env40907 := by
  intro p hp
  have h : env40907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40906_40907 : H12AffineEnvironment.transform 10 529 env40906 = env40907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env40906 == env40907) = true)

theorem identity40907 : scanCanonicalize (H12AffineFastState.compose env40907 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound40907 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40908 : List Nat := [2,4,8,16,32,16,9,4,33,53,48,32,9,16,1,3,1,16,52,0,49,32,17,2,8,17,49,0,33,17,53,33,5,32,17,32]

theorem envBound40908 : H12AffineFastState.Bounded env40908 := by
  intro p hp
  have h : env40908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40907_40908 : H12AffineEnvironment.transform 8 33 env40907 = env40908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env40907 == env40908) = true)

theorem identity40908 : scanCanonicalize (H12AffineFastState.compose env40908 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40908 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40909 : List Nat := [2,4,8,16,1,16,9,4,0,20,17,1,9,16,1,3,1,16,21,0,16,1,17,2,8,17,16,0,0,17,20,0,5,1,17,1]

theorem envBound40909 : H12AffineFastState.Bounded env40909 := by
  intro p hp
  have h : env40909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40908_40909 : H12AffineEnvironment.transform 4 1 env40908 = env40909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40908 == env40909) = true)

theorem identity40909 : scanCanonicalize (H12AffineFastState.compose env40909 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40909 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40910 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,1,9,1,1,3,1,1,4,0,1,1,0,2,8,0,1,0,0,0,5,0,5,1,0,1]

theorem envBound40910 : H12AffineFastState.Bounded env40910 := by
  intro p hp
  have h : env40910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40909_40910 : H12AffineEnvironment.transform 3 1 env40909 = env40910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40909 == env40910) = true)

def env40911 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4112,33,17,41231,8193,16,171281,5393,17664,138292,1285,62508,257,21793,46092,513]

theorem envBound40911 : H12AffineFastState.Bounded env40911 := by
  intro p hp
  have h : env40911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40898_40911 : H12AffineEnvironment.transform 5 17 env40898 = env40911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40898 == env40911) = true)

theorem identity40911 : scanCanonicalize (H12AffineFastState.compose env40911 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40911 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env40912 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,8202,131072,23589,1025,1,4112,33,17,8463,8193,16,138513,5393,17664,138292,1285,29740,257,21793,13324,513]

theorem envBound40912 : H12AffineFastState.Bounded env40912 := by
  intro p hp
  have h : env40912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40911_40912 : H12AffineEnvironment.transform 14 0 env40911 = env40912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40911 == env40912) = true)

theorem identity40912 : scanCanonicalize (H12AffineFastState.compose env40912 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40912 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40913 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,131072,23589,1025,1,4112,33,17,3,269,16,138513,5393,17664,138292,1285,21792,257,21793,5376,513]

theorem envBound40913 : H12AffineFastState.Bounded env40913 := by
  intro p hp
  have h : env40913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40912_40913 : H12AffineEnvironment.transform 12 268 env40912 = env40913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40912 == env40913) = true)

theorem identity40913 : scanCanonicalize (H12AffineFastState.compose env40913 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40913 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40914 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16401,23589,1025,1,4112,33,17,3,269,16,23808,5393,17664,23589,1285,21792,257,21793,5376,513]

theorem envBound40914 : H12AffineFastState.Bounded env40914 := by
  intro p hp
  have h : env40914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40913_40914 : H12AffineEnvironment.transform 16 16401 env40913 = env40914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40913 == env40914) = true)

theorem identity40914 : scanCanonicalize (H12AffineFastState.compose env40914 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40914 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40915 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4112,33,17,3,269,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound40915 : H12AffineFastState.Bounded env40915 := by
  intro p hp
  have h : env40915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40914_40915 : H12AffineEnvironment.transform 13 5376 env40914 = env40915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40914 == env40915) = true)

theorem identity40915 : scanCanonicalize (H12AffineFastState.compose env40915 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40916 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5173,2049,1025,1,4112,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound40916 : H12AffineFastState.Bounded env40916 := by
  intro p hp
  have h : env40916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40915_40916 : H12AffineEnvironment.transform 7 36 env40915 = env40916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40915 == env40916) = true)

def env40917 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,0,34,1029,2049,1025,1,32,33,17,3,41,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound40917 : H12AffineFastState.Bounded env40917 := by
  intro p hp
  have h : env40917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40916_40917 : H12AffineEnvironment.transform 11 48 env40916 = env40917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40916 == env40917) = true)

theorem identity40917 : scanCanonicalize (H12AffineFastState.compose env40917 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40918 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,0,3,1029,2049,1025,1,1,0,17,3,8,16,2048,1029,17,2049,1024,1,4,0,1044,513]

theorem envBound40918 : H12AffineFastState.Bounded env40918 := by
  intro p hp
  have h : env40918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40917_40918 : H12AffineEnvironment.transform 4 1 env40917 = env40918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40917 == env40918) = true)

def env40919 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,0,0,3,17,2049,21,1,1,0,17,3,8,16,2048,17,17,2049,20,1,4,0,0,513]

theorem envBound40919 : H12AffineFastState.Bounded env40919 := by
  intro p hp
  have h : env40919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40918_40919 : H12AffineEnvironment.transform 9 20 env40918 = env40919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40918 == env40919) = true)

theorem identity40919 : scanCanonicalize (H12AffineFastState.compose env40919 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40920 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,0,3,17,1,21,1,1,0,17,3,8,16,0,17,17,1,20,1,4,0,0,513]

theorem envBound40920 : H12AffineFastState.Bounded env40920 := by
  intro p hp
  have h : env40920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40919_40920 : H12AffineEnvironment.transform 10 0 env40919 = env40920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40919 == env40920) = true)

def leafEnv40920 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,0,3,17,1,21,1,1,0,17,3,21,8,1,16,0,17,17,1,20,1,4,0,5,2,0,513,1,1,0]

def active40920 : List Nat := [0,1,2,3,8]

def tree40920 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40920 : H12WitnessSearch.Good tree40920 := H12GlobalWitnessIndex.good

theorem leafIdentity40920 : H12AffineFastState.composeSystem env40920 rootObs = leafEnv40920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40920 rootObs == leafEnv40920) = true)

theorem terminalChecked40920 : H12PackedTerminal.terminalCheckFast leafEnv40920 active40920 tree40920 = true := by decide +kernel

def env40921 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,1,0,3,16,2049,20,1,1,0,17,3,8,16,2048,16,17,2049,21,1,4,0,1,513]

theorem envBound40921 : H12AffineFastState.Bounded env40921 := by
  intro p hp
  have h : env40921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40918_40921 : H12AffineEnvironment.transform 9 21 env40918 = env40921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env40918 == env40921) = true)

theorem identity40921 : scanCanonicalize (H12AffineFastState.compose env40921 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound40921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40922 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,17,9,1,0,3,16,523,20,1,1,0,17,3,8,16,522,16,17,523,21,1,4,0,1,513]

theorem envBound40922 : H12AffineFastState.Bounded env40922 := by
  intro p hp
  have h : env40922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40921_40922 : H12AffineEnvironment.transform 10 522 env40921 = env40922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env40921 == env40922) = true)

def leafEnv40922 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,17,9,1,0,3,16,523,20,1,1,0,17,3,20,8,1,16,522,16,17,523,21,1,4,0,5,2,1,513,1,1,0]

def active40922 : List Nat := [0,1,2,3,8]

def tree40922 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40922 : H12WitnessSearch.Good tree40922 := H12GlobalWitnessIndex.good

theorem leafIdentity40922 : H12AffineFastState.composeSystem env40922 rootObs = leafEnv40922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40922 rootObs == leafEnv40922) = true)

theorem terminalChecked40922 : H12PackedTerminal.terminalCheckFast leafEnv40922 active40922 tree40922 = true := by decide +kernel

def env40923 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,0,34,1028,2049,1025,1,33,33,17,3,41,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound40923 : H12AffineFastState.Bounded env40923 := by
  intro p hp
  have h : env40923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40916_40923 : H12AffineEnvironment.transform 11 49 env40916 = env40923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40916 == env40923) = true)

theorem identity40923 : scanCanonicalize (H12AffineFastState.compose env40923 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40924 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,49,40,1,0,34,16,2049,21,1,33,33,17,3,41,16,2048,16,49,2049,53,32,37,33,1,513]

theorem envBound40924 : H12AffineFastState.Bounded env40924 := by
  intro p hp
  have h : env40924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40923_40924 : H12AffineEnvironment.transform 9 20 env40923 = env40924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40923 == env40924) = true)

def env40925 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,8,1,0,2,16,2049,21,1,1,1,17,3,9,16,2048,16,17,2049,21,0,5,1,1,513]

theorem envBound40925 : H12AffineFastState.Bounded env40925 := by
  intro p hp
  have h : env40925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40924_40925 : H12AffineEnvironment.transform 4 0 env40924 = env40925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40924 == env40925) = true)

theorem identity40925 : scanCanonicalize (H12AffineFastState.compose env40925 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound40925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40926 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,17,8,1,0,2,16,522,21,1,1,1,17,3,9,16,523,16,17,522,21,0,5,1,1,513]

theorem envBound40926 : H12AffineFastState.Bounded env40926 := by
  intro p hp
  have h : env40926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40925_40926 : H12AffineEnvironment.transform 10 523 env40925 = env40926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env40925 == env40926) = true)

def leafEnv40926 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,17,8,1,0,2,16,522,21,1,1,1,17,3,20,9,1,16,523,16,17,522,21,0,5,1,5,3,1,513,1,1,0]

def active40926 : List Nat := [0,1,2,3,8]

def tree40926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40926 : H12WitnessSearch.Good tree40926 := H12GlobalWitnessIndex.good

theorem leafIdentity40926 : H12AffineFastState.composeSystem env40926 rootObs = leafEnv40926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40926 rootObs == leafEnv40926) = true)

theorem terminalChecked40926 : H12PackedTerminal.terminalCheckFast leafEnv40926 active40926 tree40926 = true := by decide +kernel

def env40927 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,0,3,16,2049,21,1,0,0,17,3,8,16,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound40927 : H12AffineFastState.Bounded env40927 := by
  intro p hp
  have h : env40927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40924_40927 : H12AffineEnvironment.transform 4 1 env40924 = env40927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40924 == env40927) = true)

theorem identity40927 : scanCanonicalize (H12AffineFastState.compose env40927 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40928 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,1,0,3,16,0,21,1,0,0,17,3,8,16,1,16,16,0,20,1,4,0,1,513]

theorem envBound40928 : H12AffineFastState.Bounded env40928 := by
  intro p hp
  have h : env40928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40927_40928 : H12AffineEnvironment.transform 10 1 env40927 = env40928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40927 == env40928) = true)

def leafEnv40928 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,1,0,3,16,0,21,1,0,0,17,3,21,8,1,16,1,16,16,0,20,1,4,0,5,2,1,513,1,0,0]

def active40928 : List Nat := [0,1,2,3,8]

def tree40928 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40928 : H12WitnessSearch.Good tree40928 := H12GlobalWitnessIndex.good

theorem leafIdentity40928 : H12AffineFastState.composeSystem env40928 rootObs = leafEnv40928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40928 rootObs == leafEnv40928) = true)

theorem terminalChecked40928 : H12PackedTerminal.terminalCheckFast leafEnv40928 active40928 tree40928 = true := by decide +kernel

def env40929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound40929 : H12AffineFastState.Bounded env40929 := by
  intro p hp
  have h : env40929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40496_40929 : H12AffineEnvironment.transform 26 30393345 env40496 = env40929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env40496 == env40929) = true)

def env40930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound40930 : H12AffineFastState.Bounded env40930 := by
  intro p hp
  have h : env40930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40929_40930 : H12AffineEnvironment.transform 18 1024 env40929 = env40930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40929 == env40930) = true)

theorem identity40930 : scanCanonicalize (H12AffineFastState.compose env40930 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510000) := by decide +kernel

theorem selectedBound40930 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510000,8328,65,12585009,2510012,10507600,8830976,8801313,6729201,256,10882204,10939704,8874998]

theorem envBound40931 : H12AffineFastState.Bounded env40931 := by
  intro p hp
  have h : env40931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40930_40931 : H12AffineEnvironment.transform 23 510000 env40930 = env40931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env40930 == env40931) = true)

def env40932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513340,510000,8328,65,6705549,2510012,396524,2136508,2102685,6729201,256,21792,46212,2175562]

theorem envBound40932 : H12AffineFastState.Bounded env40932 := by
  intro p hp
  have h : env40932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40931_40932 : H12AffineEnvironment.transform 22 2513340 env40931 = env40932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513340 env40931 == env40932) = true)

def env40933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513340,510000,8328,65,2409525,2510012,396524,2136508,2102685,2373705,256,21792,46212,2175562]

theorem envBound40933 : H12AffineFastState.Bounded env40933 := by
  intro p hp
  have h : env40933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40932_40933 : H12AffineEnvironment.transform 21 169400 env40932 = env40933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env40932 == env40933) = true)

def env40934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,510000,8328,65,316533,417020,396524,35324,1501,272393,256,21792,46212,74250]

theorem envBound40934 : H12AffineFastState.Bounded env40934 := by
  intro p hp
  have h : env40934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40933_40934 : H12AffineEnvironment.transform 20 4160 env40933 = env40934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40933 == env40934) = true)

theorem identity40934 : scanCanonicalize (H12AffineFastState.compose env40934 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound40934 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,169400,16,98780,8328,65,171417,5392,17664,35324,1501,156133,256,21792,46212,74250]

theorem envBound40935 : H12AffineFastState.Bounded env40935 := by
  intro p hp
  have h : env40935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40934_40935 : H12AffineEnvironment.transform 17 149996 env40934 = env40935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env40934 == env40935) = true)

def env40936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,16,98644,8192,65,171281,5392,17664,35188,1365,156013,256,21792,46092,74250]

theorem envBound40936 : H12AffineFastState.Bounded env40936 := by
  intro p hp
  have h : env40936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40935_40936 : H12AffineEnvironment.transform 6 8 env40935 = env40936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40935 == env40936) = true)

theorem identity40936 : scanCanonicalize (H12AffineFastState.compose env40936 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound40936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21792,16,98644,8192,65,23809,5392,17664,35188,1365,41341,256,21792,46092,74250]

theorem envBound40937 : H12AffineFastState.Bounded env40937 := by
  intro p hp
  have h : env40937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40936_40937 : H12AffineEnvironment.transform 16 49168 env40936 = env40937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40936 == env40937) = true)

theorem identity40937 : scanCanonicalize (H12AffineFastState.compose env40937 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound40937 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env40938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,49168,35188,1024,32769,4160,21792,16,32850,8192,65,23809,5392,17664,35188,1365,41341,256,21792,46092,8972]

theorem envBound40938 : H12AffineFastState.Bounded env40938 := by
  intro p hp
  have h : env40938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40937_40938 : H12AffineEnvironment.transform 15 262 env40937 = env40938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env40937 == env40938) = true)

theorem identity40938 : scanCanonicalize (H12AffineFastState.compose env40938 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound40938 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,262,24860,10360,1024,8461,4160,21792,16,8542,8192,65,23809,5392,17664,10360,1365,113,256,21792,5376,8972]

theorem envBound40939 : H12AffineFastState.Bounded env40939 := by
  intro p hp
  have h : env40939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40938_40939 : H12AffineEnvironment.transform 14 8460 env40938 = env40939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env40938 == env40939) = true)

theorem identity40939 : scanCanonicalize (H12AffineFastState.compose env40939 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound40939 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8460,262,5393,10360,1024,8461,4160,8493,16,8542,8192,65,10508,5392,12557,10360,1365,113,256,8493,5376,8972]

theorem envBound40940 : H12AffineFastState.Bounded env40940 := by
  intro p hp
  have h : env40940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40939_40940 : H12AffineEnvironment.transform 13 13325 env40939 = env40940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env40939 == env40940) = true)

theorem identity40940 : scanCanonicalize (H12AffineFastState.compose env40940 (packedSelected [1,8,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40940 : packedSelected [1,8,10,14,16] rootPS < 2^1333 := by decide +kernel

def env40941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5157,292,262,5393,2128,1024,293,4160,261,16,374,40,65,2340,5392,4389,2128,1365,113,256,261,5376,804]

theorem envBound40941 : H12AffineFastState.Bounded env40941 := by
  intro p hp
  have h : env40941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40940_40941 : H12AffineEnvironment.transform 12 40 env40940 = env40941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40940 == env40941) = true)

theorem identity40941 : scanCanonicalize (H12AffineFastState.compose env40941 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40941 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40942 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5157,81,115,5220,2128,1024,80,4160,112,16,3,40,65,2129,5221,4176,2128,1056,113,117,112,5237,593]

theorem envBound40942 : H12AffineFastState.Bounded env40942 := by
  intro p hp
  have h : env40942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40941_40942 : H12AffineEnvironment.transform 7 117 env40941 = env40942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40941 == env40942) = true)

theorem identity40942 : scanCanonicalize (H12AffineFastState.compose env40942 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40942 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40943 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4112,32,16,3,40,17,2049,5173,4096,2048,1056,33,37,32,5157,513]

theorem envBound40943 : H12AffineFastState.Bounded env40943 := by
  intro p hp
  have h : env40943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40942_40943 : H12AffineEnvironment.transform 5 16 env40942 = env40943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40942 == env40943) = true)

theorem identity40943 : scanCanonicalize (H12AffineFastState.compose env40943 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound40943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40944 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,4096,40,4096,1,35,4113,2048,37,0,4112,32,16,3,40,17,2049,4112,4096,2048,5,33,37,32,4096,513]

theorem envBound40944 : H12AffineFastState.Bounded env40944 := by
  intro p hp
  have h : env40944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40943_40944 : H12AffineEnvironment.transform 9 37 env40943 = env40944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env40943 == env40944) = true)

theorem identity40944 : scanCanonicalize (H12AffineFastState.compose env40944 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound40944 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40945 : List Nat := [2,4,8,16,32,16,8,37,512,37,2048,2074,40,2074,1,35,2059,2048,37,0,2058,32,16,3,40,17,2049,2058,2074,2048,5,33,37,32,2074,513]

theorem envBound40945 : H12AffineFastState.Bounded env40945 := by
  intro p hp
  have h : env40945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40944_40945 : H12AffineEnvironment.transform 11 2074 env40944 = env40945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env40944 == env40945) = true)

theorem identity40945 : scanCanonicalize (H12AffineFastState.compose env40945 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound40945 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40946 : List Nat := [2,4,8,16,32,16,8,37,512,37,43,49,40,49,1,35,32,43,37,0,33,32,16,3,40,17,42,33,49,43,5,33,37,32,49,513]

theorem envBound40946 : H12AffineFastState.Bounded env40946 := by
  intro p hp
  have h : env40946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40945_40946 : H12AffineEnvironment.transform 10 43 env40945 = env40946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env40945 == env40946) = true)

theorem identity40946 : scanCanonicalize (H12AffineFastState.compose env40946 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound40946 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40947 : List Nat := [2,4,8,16,32,16,8,37,31,37,43,49,40,49,1,35,32,43,37,0,33,32,16,3,40,17,42,33,49,43,5,33,37,32,49,30]

theorem envBound40947 : H12AffineFastState.Bounded env40947 := by
  intro p hp
  have h : env40947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40946_40947 : H12AffineEnvironment.transform 8 31 env40946 = env40947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env40946 == env40947) = true)

def env40948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,98645,8193,65,171280,5392,17664,35189,1364,156012,256,21792,46093,74250]

theorem envBound40948 : H12AffineFastState.Bounded env40948 := by
  intro p hp
  have h : env40948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40935_40948 : H12AffineEnvironment.transform 6 9 env40935 = env40948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40935 == env40948) = true)

theorem identity40948 : scanCanonicalize (H12AffineFastState.compose env40948 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound40948 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1024,32769,4160,62589,16,98645,8193,65,64604,5392,17664,35189,1364,32,256,21792,46093,74250]

theorem envBound40949 : H12AffineFastState.Bounded env40949 := by
  intro p hp
  have h : env40949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40948_40949 : H12AffineEnvironment.transform 16 24908 env40948 = env40949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env40948 == env40949) = true)

theorem identity40949 : scanCanonicalize (H12AffineFastState.compose env40949 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound40949 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,10281,1024,32769,4160,62589,16,29790,8193,65,64604,5392,17664,35189,1364,32,256,21792,46093,55041]

theorem envBound40950 : H12AffineFastState.Bounded env40950 := by
  intro p hp
  have h : env40950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40949_40950 : H12AffineEnvironment.transform 15 62731 env40949 = env40950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env40949 == env40950) = true)

theorem identity40950 : scanCanonicalize (H12AffineFastState.compose env40950 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40950 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env40951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,24908,10281,1024,8540,4160,21792,16,29790,8193,65,23809,5392,17664,10280,1364,32,256,21792,5456,30300]

theorem envBound40951 : H12AffineFastState.Bounded env40951 := by
  intro p hp
  have h : env40951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40950_40951 : H12AffineEnvironment.transform 14 8541 env40950 = env40951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40950 == env40951) = true)

theorem identity40951 : scanCanonicalize (H12AffineFastState.compose env40951 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40951 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,5393,10281,1024,8540,4160,8573,16,3,8193,65,10588,5392,12637,10280,1364,32,256,8573,5456,513]

theorem envBound40952 : H12AffineFastState.Bounded env40952 := by
  intro p hp
  have h : env40952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40951_40952 : H12AffineEnvironment.transform 13 13405 env40951 = env40952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40951 == env40952) = true)

theorem identity40952 : scanCanonicalize (H12AffineFastState.compose env40952 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40952 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5393,2421,1024,0,4160,33,16,3,349,65,2048,5392,4097,2420,1364,32,256,33,5456,513]

theorem envBound40953 : H12AffineFastState.Bounded env40953 := by
  intro p hp
  have h : env40953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40952_40953 : H12AffineEnvironment.transform 12 348 env40952 = env40953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40952 == env40953) = true)

theorem identity40953 : scanCanonicalize (H12AffineFastState.compose env40953 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound40953 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,348,1296,1,343,1280,2421,1024,0,81,33,16,3,349,65,2048,1281,16,2420,1364,32,256,33,1345,513]

theorem envBound40954 : H12AffineFastState.Bounded env40954 := by
  intro p hp
  have h : env40954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40953_40954 : H12AffineEnvironment.transform 11 17 env40953 = env40954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env40953 == env40954) = true)

theorem identity40954 : scanCanonicalize (H12AffineFastState.compose env40954 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound40954 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1557,17,348,1296,1,343,1280,1888,1024,0,81,33,16,3,349,65,1557,1281,16,1889,1364,32,256,33,1345,513]

theorem envBound40955 : H12AffineFastState.Bounded env40955 := by
  intro p hp
  have h : env40955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40954_40955 : H12AffineEnvironment.transform 10 1557 env40954 = env40955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env40954 == env40955) = true)

theorem identity40955 : scanCanonicalize (H12AffineFastState.compose env40955 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 864) := by decide +kernel

theorem selectedBound40955 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40956 : List Nat := [2,4,8,16,32,64,9,256,512,864,373,17,348,624,1,343,608,0,864,0,81,33,16,3,349,65,373,609,16,1,564,32,256,33,545,513]

theorem envBound40956 : H12AffineFastState.Bounded env40956 := by
  intro p hp
  have h : env40956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40955_40956 : H12AffineEnvironment.transform 9 864 env40955 = env40956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 864 env40955 == env40956) = true)

theorem identity40956 : scanCanonicalize (H12AffineFastState.compose env40956 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound40956 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40957 : List Nat := [2,4,8,16,32,64,9,256,277,117,373,17,348,357,1,343,373,0,117,0,81,33,16,3,349,65,373,372,16,1,289,32,256,33,308,276]

theorem envBound40957 : H12AffineFastState.Bounded env40957 := by
  intro p hp
  have h : env40957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40956_40957 : H12AffineEnvironment.transform 8 277 env40956 = env40957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env40956 == env40957) = true)

theorem identity40957 : scanCanonicalize (H12AffineFastState.compose env40957 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40957 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env40958 : List Nat := [2,4,8,16,0,64,9,256,277,85,341,17,348,325,1,343,341,0,85,0,81,1,16,3,349,65,341,340,16,1,257,0,256,1,276,276]

theorem envBound40958 : H12AffineFastState.Bounded env40958 := by
  intro p hp
  have h : env40958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40957_40958 : H12AffineEnvironment.transform 4 0 env40957 = env40958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40957 == env40958) = true)

theorem identity40958 : scanCanonicalize (H12AffineFastState.compose env40958 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40958 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env40959 : List Nat := [2,4,8,1,0,64,9,256,260,68,324,0,333,325,1,326,324,0,68,0,64,1,1,3,332,65,324,325,1,1,257,0,256,1,261,261]

theorem envBound40959 : H12AffineFastState.Bounded env40959 := by
  intro p hp
  have h : env40959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40958_40959 : H12AffineEnvironment.transform 3 1 env40958 = env40959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40958 == env40959) = true)

theorem identity40959 : scanCanonicalize (H12AffineFastState.compose env40959 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40960 : List Nat := [2,4,8,1,0,64,9,4,0,68,64,0,73,65,1,66,64,0,68,0,64,1,1,3,72,65,64,65,1,1,5,0,4,1,1,1]

theorem envBound40960 : H12AffineFastState.Bounded env40960 := by
  intro p hp
  have h : env40960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40959_40960 : H12AffineEnvironment.transform 7 4 env40959 = env40960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40959 == env40960) = true)

def env40961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,510000,8328,65,316532,417021,396524,35325,1500,272392,256,21792,46212,74251]

theorem envBound40961 : H12AffineFastState.Bounded env40961 := by
  intro p hp
  have h : env40961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40933_40961 : H12AffineEnvironment.transform 20 4161 env40933 = env40961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40933 == env40961) = true)

theorem identity40961 : scanCanonicalize (H12AffineFastState.compose env40961 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40961 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,156013,412157,474341,8328,65,270497,417021,396524,32040,1500,272392,256,21792,16465,74251]

theorem envBound40962 : H12AffineFastState.Bounded env40962 := by
  intro p hp
  have h : env40962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40961_40962 : H12AffineEnvironment.transform 14 29909 env40961 = env40962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40961 == env40962) = true)

def env40963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32240,1024,29908,4161,156013,144397,213269,8328,65,23889,139533,160028,32040,1500,22008,256,21792,16465,74251]

theorem envBound40963 : H12AffineFastState.Bounded env40963 := by
  intro p hp
  have h : env40963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40962_40963 : H12AffineEnvironment.transform 17 32240 env40962 = env40963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env40962 == env40963) = true)

theorem identity40963 : scanCanonicalize (H12AffineFastState.compose env40963 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound40963 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79250,32240,1024,29908,4161,87295,65951,29831,8328,65,23889,70815,83086,32040,1500,22008,256,21792,16465,74251]

theorem envBound40964 : H12AffineFastState.Bounded env40964 := by
  intro p hp
  have h : env40964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40963_40964 : H12AffineEnvironment.transform 16 79250 env40963 = env40964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env40963 == env40964) = true)

theorem identity40964 : scanCanonicalize (H12AffineFastState.compose env40964 (packedSelected [5,8,10,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40964 : packedSelected [5,8,10,19,24,28] rootPS < 2^1333 := by decide +kernel

def env40965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,5528,32240,1024,29908,4161,29941,8597,29831,8328,65,23889,13461,25732,32040,1500,22008,256,21792,16465,513]

theorem envBound40965 : H12AffineFastState.Bounded env40965 := by
  intro p hp
  have h : env40965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40964_40965 : H12AffineEnvironment.transform 15 8202 env40964 = env40965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40964 == env40965) = true)

theorem identity40965 : scanCanonicalize (H12AffineFastState.compose env40965 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40965 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env40966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21977,262,5528,23804,1024,21976,4161,22009,153,21899,388,65,23889,5529,17800,23588,1500,22008,256,21792,16465,513]

theorem envBound40966 : H12AffineFastState.Bounded env40966 := by
  intro p hp
  have h : env40966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40965_40966 : H12AffineEnvironment.transform 12 268 env40965 = env40966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40965 == env40966) = true)

theorem identity40966 : scanCanonicalize (H12AffineFastState.compose env40966 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40966 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,216,262,5528,2557,1024,217,4161,248,153,138,388,65,2128,5529,4233,2341,1500,249,256,33,5456,513]

theorem envBound40967 : H12AffineFastState.Bounded env40967 := by
  intro p hp
  have h : env40967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40966_40967 : H12AffineEnvironment.transform 13 5377 env40966 = env40967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40966 == env40967) = true)

theorem identity40967 : scanCanonicalize (H12AffineFastState.compose env40967 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound40967 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40968 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,268,4540,216,262,4389,2557,189,217,4161,248,153,138,388,65,2128,4388,4233,2341,353,249,256,33,4589,513]

theorem envBound40968 : H12AffineFastState.Bounded env40968 := by
  intro p hp
  have h : env40968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40967_40968 : H12AffineEnvironment.transform 9 189 env40967 = env40968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env40967 == env40968) = true)

theorem identity40968 : scanCanonicalize (H12AffineFastState.compose env40968 (packedSelected [2,6,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40968 : packedSelected [2,6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env40969 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,268,4405,81,262,4389,2420,52,80,4161,113,16,3,269,65,2128,4388,4096,2341,353,112,256,33,4452,513]

theorem envBound40969 : H12AffineFastState.Bounded env40969 := by
  intro p hp
  have h : env40969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40968_40969 : H12AffineEnvironment.transform 6 9 env40968 = env40969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40968 == env40969) = true)

theorem identity40969 : scanCanonicalize (H12AffineFastState.compose env40969 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2667) := by decide +kernel

theorem selectedBound40969 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40970 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2667,268,2910,81,262,2894,2420,52,80,2602,113,16,3,269,65,2128,2895,2667,2341,353,112,256,33,2831,513]

theorem envBound40970 : H12AffineFastState.Bounded env40970 := by
  intro p hp
  have h : env40970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40969_40970 : H12AffineEnvironment.transform 11 2667 env40969 = env40970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2667 env40969 == env40970) = true)

theorem identity40970 : scanCanonicalize (H12AffineFastState.compose env40970 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound40970 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40971 : List Nat := [2,4,8,16,26,64,9,256,512,14,2048,2641,268,2910,81,262,2894,2382,14,80,2576,75,16,3,269,65,2128,2895,2641,2335,347,74,256,27,2831,513]

theorem envBound40971 : H12AffineFastState.Bounded env40971 := by
  intro p hp
  have h : env40971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40970_40971 : H12AffineEnvironment.transform 4 26 env40970 = env40971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env40970 == env40971) = true)

theorem identity40971 : scanCanonicalize (H12AffineFastState.compose env40971 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40971 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40972 : List Nat := [2,4,8,16,26,17,9,256,512,14,2048,2560,268,2831,0,262,2847,2335,14,1,2576,26,16,3,269,16,2049,2846,2560,2335,266,27,256,27,2831,513]

theorem envBound40972 : H12AffineFastState.Bounded env40972 := by
  intro p hp
  have h : env40972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40971_40972 : H12AffineEnvironment.transform 5 17 env40971 = env40972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40971 == env40972) = true)

theorem identity40972 : scanCanonicalize (H12AffineFastState.compose env40972 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40973 : List Nat := [2,4,8,16,26,17,9,4,512,14,2048,2560,8,2571,0,2,2587,2075,14,1,2576,26,16,3,9,16,2049,2586,2560,2075,14,27,4,27,2571,513]

theorem envBound40973 : H12AffineFastState.Bounded env40973 := by
  intro p hp
  have h : env40973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40972_40973 : H12AffineEnvironment.transform 7 4 env40972 = env40973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40972 == env40973) = true)

theorem identity40973 : scanCanonicalize (H12AffineFastState.compose env40973 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound40973 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40974 : List Nat := [2,4,8,16,26,17,9,4,512,14,11,523,8,512,0,2,528,16,14,1,539,26,16,3,9,16,10,529,523,16,14,27,4,27,512,513]

theorem envBound40974 : H12AffineFastState.Bounded env40974 := by
  intro p hp
  have h : env40974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40973_40974 : H12AffineEnvironment.transform 10 11 env40973 = env40974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env40973 == env40974) = true)

theorem identity40974 : scanCanonicalize (H12AffineFastState.compose env40974 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40974 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40975 : List Nat := [2,4,2,16,16,17,3,4,512,4,1,513,2,512,0,2,528,16,4,1,529,16,16,3,3,16,0,529,513,16,4,17,4,17,512,513]

theorem envBound40975 : H12AffineFastState.Bounded env40975 := by
  intro p hp
  have h : env40975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40974_40975 : H12AffineEnvironment.transform 2 2 env40974 = env40975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40974 == env40975) = true)

theorem identity40975 : scanCanonicalize (H12AffineFastState.compose env40975 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound40975 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40976 : List Nat := [2,4,2,16,16,17,3,4,5,4,1,4,2,5,0,2,21,16,4,1,20,16,16,3,3,16,0,20,4,16,4,17,4,17,5,4]

theorem envBound40976 : H12AffineFastState.Bounded env40976 := by
  intro p hp
  have h : env40976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40975_40976 : H12AffineEnvironment.transform 8 5 env40975 = env40976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env40975 == env40976) = true)

theorem identity40976 : scanCanonicalize (H12AffineFastState.compose env40976 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound40976 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40977 : List Nat := [2,4,2,5,5,4,3,4,5,4,1,4,2,5,0,2,0,5,4,1,1,5,5,3,3,5,0,1,4,5,4,4,4,4,5,4]

theorem envBound40977 : H12AffineFastState.Bounded env40977 := by
  intro p hp
  have h : env40977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40976_40977 : H12AffineEnvironment.transform 3 5 env40976 = env40977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env40976 == env40977) = true)

theorem identity40977 : scanCanonicalize (H12AffineFastState.compose env40977 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40977 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40978 : List Nat := [0,4,0,5,5,4,1,4,5,4,1,4,0,5,0,0,0,5,4,1,1,5,5,1,1,5,0,1,4,5,4,4,4,4,5,4]

theorem envBound40978 : H12AffineFastState.Bounded env40978 := by
  intro p hp
  have h : env40978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40977_40978 : H12AffineEnvironment.transform 0 0 env40977 = env40978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40977 == env40978) = true)

def env40979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32241,1024,29908,4161,156013,144396,213268,8328,65,23888,139532,160029,32040,1500,22009,256,21792,16465,74251]

theorem envBound40979 : H12AffineFastState.Bounded env40979 := by
  intro p hp
  have h : env40979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40962_40979 : H12AffineEnvironment.transform 17 32241 env40962 = env40979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env40962 == env40979) = true)

theorem identity40979 : scanCanonicalize (H12AffineFastState.compose env40979 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound40979 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79130,32241,1024,29908,4161,87159,65814,29710,8328,65,23888,70678,82951,32040,1500,22009,256,21792,16465,74251]

theorem envBound40980 : H12AffineFastState.Bounded env40980 := by
  intro p hp
  have h : env40980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40979_40980 : H12AffineEnvironment.transform 16 79130 env40979 = env40980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env40979 == env40980) = true)

theorem identity40980 : scanCanonicalize (H12AffineFastState.compose env40980 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30163) := by decide +kernel

theorem selectedBound40980 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env40981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30163,16585,32241,1024,29908,4161,8612,29893,29710,8328,65,23888,25029,12756,32040,1500,22009,256,21792,16465,22488]

theorem envBound40981 : H12AffineFastState.Bounded env40981 := by
  intro p hp
  have h : env40981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40980_40981 : H12AffineEnvironment.transform 15 30163 env40980 = env40981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30163 env40980 == env40981) = true)

theorem identity40981 : scanCanonicalize (H12AffineFastState.compose env40981 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound40981 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env40982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,263,13341,2341,1024,0,4161,8612,17,218,8328,65,10628,5393,12756,2556,1500,8493,256,8692,13445,8972]

theorem envBound40982 : H12AffineFastState.Bounded env40982 := by
  intro p hp
  have h : env40982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40981_40982 : H12AffineEnvironment.transform 13 13524 env40981 = env40982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env40981 == env40982) = true)

theorem identity40982 : scanCanonicalize (H12AffineFastState.compose env40982 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound40982 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env40983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5237,1,263,5308,2341,1024,0,4161,261,17,218,41,65,2341,5393,4469,2556,1500,396,256,341,5156,941]

theorem envBound40983 : H12AffineFastState.Bounded env40983 := by
  intro p hp
  have h : env40983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40982_40983 : H12AffineEnvironment.transform 12 161 env40982 = env40983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env40982 == env40983) = true)

theorem identity40983 : scanCanonicalize (H12AffineFastState.compose env40983 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40983 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40984 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,161,5237,1,171,5308,2185,1024,0,4161,169,17,218,41,65,2185,5309,4313,2128,1136,32,172,249,5156,513]

theorem envBound40984 : H12AffineFastState.Bounded env40984 := by
  intro p hp
  have h : env40984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40983_40984 : H12AffineEnvironment.transform 7 172 env40983 = env40984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40983 == env40984) = true)

theorem identity40984 : scanCanonicalize (H12AffineFastState.compose env40984 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40985 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5157,1,171,5308,2185,1024,0,4113,169,17,138,41,17,2185,5309,4233,2048,1056,32,172,169,5156,513]

theorem envBound40985 : H12AffineFastState.Bounded env40985 := by
  intro p hp
  have h : env40985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40984_40985 : H12AffineEnvironment.transform 5 16 env40984 = env40985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40984 == env40985) = true)

theorem identity40985 : scanCanonicalize (H12AffineFastState.compose env40985 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound40985 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40986 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,4096,161,4248,1,171,4097,2185,189,0,4113,169,17,138,41,17,2185,4096,4233,2048,157,32,172,169,4249,513]

theorem envBound40986 : H12AffineFastState.Bounded env40986 := by
  intro p hp
  have h : env40986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40985_40986 : H12AffineEnvironment.transform 9 189 env40985 = env40986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env40985 == env40986) = true)

def env40987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513340,510000,8328,65,2409524,2510012,396524,2136508,2102685,2373704,256,21792,46212,2175562]

theorem envBound40987 : H12AffineFastState.Bounded env40987 := by
  intro p hp
  have h : env40987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40932_40987 : H12AffineEnvironment.transform 21 169401 env40932 = env40987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env40932 == env40987) = true)

def env40988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,510000,8328,65,316532,417020,396524,35324,1501,272392,256,21792,46212,74250]

theorem envBound40988 : H12AffineFastState.Bounded env40988 := by
  intro p hp
  have h : env40988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40987_40988 : H12AffineEnvironment.transform 20 4160 env40987 = env40988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40987 == env40988) = true)

def env40989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169401,156116,253976,8328,65,64604,160980,140484,35324,1501,32,256,21792,46212,74250]

theorem envBound40989 : H12AffineFastState.Bounded env40989 := by
  intro p hp
  have h : env40989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40988_40989 : H12AffineEnvironment.transform 17 10280 env40988 = env40989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40988 == env40989) = true)

def env40990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21929,41412,73736,8328,65,64604,46276,58580,35324,1501,32,256,21792,46212,74250]

theorem envBound40990 : H12AffineFastState.Bounded env40990 := by
  intro p hp
  have h : env40990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40989_40990 : H12AffineEnvironment.transform 16 49168 env40989 = env40990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40989 == env40990) = true)

theorem identity40990 : scanCanonicalize (H12AffineFastState.compose env40990 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40990 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1024,8541,4160,21929,152,73736,8328,65,23808,5528,17800,10400,1501,32,256,21792,5592,74250]

theorem envBound40991 : H12AffineFastState.Bounded env40991 := by
  intro p hp
  have h : env40991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40990_40991 : H12AffineEnvironment.transform 14 8540 env40990 = env40991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40990 == env40991) = true)

theorem identity40991 : scanCanonicalize (H12AffineFastState.compose env40991 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 4297) := by decide +kernel

theorem selectedBound40991 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env40992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8540,65536,12677,10280,1024,8541,4160,1376,152,73736,8328,65,3529,5528,5441,10400,1501,32,256,1513,5592,74250]

theorem envBound40992 : H12AffineFastState.Bounded env40992 := by
  intro p hp
  have h : env40992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40991_40992 : H12AffineEnvironment.transform 13 4297 env40991 = env40992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4297 env40991 == env40992) = true)

theorem identity40992 : scanCanonicalize (H12AffineFastState.compose env40992 (packedSelected [2,3,4,6,10,16,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound40992 : packedSelected [2,3,4,6,10,16,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8540,399,12677,10280,1024,8541,4160,1376,152,8583,8328,65,3529,5528,5441,10400,1501,32,256,1513,5592,9093]

theorem envBound40993 : H12AffineFastState.Bounded env40993 := by
  intro p hp
  have h : env40993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40992_40993 : H12AffineEnvironment.transform 15 399 env40992 = env40993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env40992 == env40993) = true)

theorem identity40993 : scanCanonicalize (H12AffineFastState.compose env40993 (packedSelected [1,2,4,6,8,11,16,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40993 : packedSelected [1,2,4,6,8,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env40994 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4297,8432,35,12329,10280,1024,8433,4160,1228,152,8235,8328,65,3173,5172,5357,10400,1137,32,172,1093,5236,8745]

theorem envBound40994 : H12AffineFastState.Bounded env40994 := by
  intro p hp
  have h : env40994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40993_40994 : H12AffineEnvironment.transform 7 172 env40993 = env40994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40993 == env40994) = true)

theorem identity40994 : scanCanonicalize (H12AffineFastState.compose env40994 (packedSelected [3,5,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound40994 : packedSelected [3,5,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env40995 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1052,4297,1260,35,5173,3124,1024,1261,4160,1228,152,1079,1172,65,3173,5172,5357,3260,1137,32,172,1093,5236,1589]

theorem envBound40995 : H12AffineFastState.Bounded env40995 := by
  intro p hp
  have h : env40995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40994_40995 : H12AffineEnvironment.transform 12 1052 env40994 = env40995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env40994 == env40995) = true)

theorem identity40995 : scanCanonicalize (H12AffineFastState.compose env40995 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40995 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40996 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,1052,4112,1077,35,5173,3124,1024,1076,4160,1045,65,1079,1101,65,3173,5172,5172,3173,1137,32,117,1093,5236,1589]

theorem envBound40996 : H12AffineFastState.Bounded env40996 := by
  intro p hp
  have h : env40996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40995_40996 : H12AffineEnvironment.transform 6 89 env40995 = env40996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40995 == env40996) = true)

theorem identity40996 : scanCanonicalize (H12AffineFastState.compose env40996 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound40996 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40997 : List Nat := [2,4,8,16,32,64,89,117,512,100,2048,4096,120,4112,81,35,4177,2128,100,80,4160,113,65,83,41,65,2049,4176,4176,2049,21,32,117,33,4112,593]

theorem envBound40997 : H12AffineFastState.Bounded env40997 := by
  intro p hp
  have h : env40997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40996_40997 : H12AffineEnvironment.transform 9 100 env40996 = env40997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env40996 == env40997) = true)

theorem identity40997 : scanCanonicalize (H12AffineFastState.compose env40997 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40997 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env40998 : List Nat := [2,4,8,16,1,64,89,84,512,69,2048,4096,89,4112,81,2,4177,2128,69,80,4160,80,65,83,8,65,2049,4176,4176,2049,21,1,84,0,4112,593]

theorem envBound40998 : H12AffineFastState.Bounded env40998 := by
  intro p hp
  have h : env40998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40997_40998 : H12AffineEnvironment.transform 4 1 env40997 = env40998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40997 == env40998) = true)

theorem identity40998 : scanCanonicalize (H12AffineFastState.compose env40998 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40998 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40999 : List Nat := [2,4,8,16,1,17,8,5,512,20,2048,4096,8,4112,0,2,4096,2049,20,1,4113,1,16,2,8,16,2049,4097,4097,2049,21,1,5,0,4112,512]

theorem envBound40999 : H12AffineFastState.Bounded env40999 := by
  intro p hp
  have h : env40999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40998_40999 : H12AffineEnvironment.transform 5 17 env40998 = env40999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40998 == env40999) = true)

def env41000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21928,41413,73737,8328,65,64604,46277,58581,35324,1501,32,256,21792,46212,74250]

theorem envBound41000 : H12AffineFastState.Bounded env41000 := by
  intro p hp
  have h : env41000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40989_41000 : H12AffineEnvironment.transform 16 49169 env40989 = env41000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40989 == env41000) = true)

theorem identity41000 : scanCanonicalize (H12AffineFastState.compose env41000 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound41000 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1024,8661,4160,21928,17,73737,8328,65,23944,5393,17665,10280,1501,32,256,21792,5456,74250]

theorem envBound41001 : H12AffineFastState.Bounded env41001 := by
  intro p hp
  have h : env41001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41000_41001 : H12AffineEnvironment.transform 14 8660 env41000 = env41001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env41000 == env41001) = true)

theorem identity41001 : scanCanonicalize (H12AffineFastState.compose env41001 (packedSelected [4,5,7,9,19,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound41001 : packedSelected [4,5,7,9,19,24,27] rootPS < 2^1333 := by decide +kernel

def env41002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,28699,25029,10280,1024,8661,4160,21928,17,20498,8328,65,23944,5393,17665,10280,1501,32,256,21792,5456,21009]

theorem envBound41002 : H12AffineFastState.Bounded env41002 := by
  intro p hp
  have h : env41002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41001_41002 : H12AffineEnvironment.transform 15 28699 env41001 = env41002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env41001 == env41002) = true)

theorem identity41002 : scanCanonicalize (H12AffineFastState.compose env41002 (packedSelected [0,2,5,6,7,16,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41002 : packedSelected [0,2,5,6,7,16,19,24] rootPS < 2^1333 := by decide +kernel

def env41003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,216,20759,16585,2340,1024,217,4160,21928,17,20498,388,65,23944,5393,17665,2340,1501,32,256,21792,5456,21009]

theorem envBound41003 : H12AffineFastState.Bounded env41003 := by
  intro p hp
  have h : env41003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41002_41003 : H12AffineEnvironment.transform 12 268 env41002 = env41003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41002 == env41003) = true)

theorem identity41003 : scanCanonicalize (H12AffineFastState.compose env41003 (packedSelected [2,4,6,11,20,22,23] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound41003 : packedSelected [2,4,6,11,20,22,23] rootPS < 2^1333 := by decide +kernel

def env41004 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,268,16384,216,20759,16585,2340,188,217,4160,20756,17,20498,388,65,22836,4525,16829,2340,353,32,256,20892,4588,21009]

theorem envBound41004 : H12AffineFastState.Bounded env41004 := by
  intro p hp
  have h : env41004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41003_41004 : H12AffineEnvironment.transform 9 188 env41003 = env41004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env41003 == env41004) = true)

theorem identity41004 : scanCanonicalize (H12AffineFastState.compose env41004 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41004 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env41005 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,4096,121,16384,216,20578,16585,2129,188,217,4160,20577,17,20498,241,65,22593,4312,16584,2129,20,32,117,20713,4249,21009]

theorem envBound41005 : H12AffineFastState.Bounded env41005 := by
  intro p hp
  have h : env41005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41004_41005 : H12AffineEnvironment.transform 7 117 env41004 = env41005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41004 == env41005) = true)

theorem identity41005 : scanCanonicalize (H12AffineFastState.compose env41005 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound41005 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41006 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,4096,121,4161,216,35,4232,2129,188,217,4160,32,17,83,241,65,2048,4312,4233,2129,20,32,117,168,4249,592]

theorem envBound41006 : H12AffineFastState.Bounded env41006 := by
  intro p hp
  have h : env41006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41005_41006 : H12AffineEnvironment.transform 13 4161 env41005 = env41006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env41005 == env41006) = true)

theorem identity41006 : scanCanonicalize (H12AffineFastState.compose env41006 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41006 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41007 : List Nat := [2,4,8,16,32,16,128,37,512,188,2048,4096,41,4113,136,35,4232,2049,188,137,4112,32,17,3,161,17,2048,4232,4233,2049,20,32,37,168,4249,512]

theorem envBound41007 : H12AffineFastState.Bounded env41007 := by
  intro p hp
  have h : env41007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41006_41007 : H12AffineEnvironment.transform 5 16 env41006 = env41007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41006 == env41007) = true)

theorem identity41007 : scanCanonicalize (H12AffineFastState.compose env41007 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound41007 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41008 : List Nat := [2,4,8,16,32,16,128,37,512,188,2048,2096,41,2081,136,35,2232,2049,188,137,2080,32,17,3,161,17,2048,2232,2233,2049,20,32,37,168,2217,512]

theorem envBound41008 : H12AffineFastState.Bounded env41008 := by
  intro p hp
  have h : env41008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41007_41008 : H12AffineEnvironment.transform 11 2096 env41007 = env41008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env41007 == env41008) = true)

theorem identity41008 : scanCanonicalize (H12AffineFastState.compose env41008 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound41008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41009 : List Nat := [2,4,8,16,32,16,41,37,512,21,2048,2096,41,2081,33,35,2065,2049,21,32,2080,32,17,3,8,17,2048,2065,2064,2049,20,32,37,1,2048,512]

theorem envBound41009 : H12AffineFastState.Bounded env41009 := by
  intro p hp
  have h : env41009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41008_41009 : H12AffineEnvironment.transform 6 41 env41008 = env41009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env41008 == env41009) = true)

theorem identity41009 : scanCanonicalize (H12AffineFastState.compose env41009 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41009 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41010 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,2064,9,2049,1,3,2065,2049,21,0,2048,0,17,3,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound41010 : H12AffineFastState.Bounded env41010 := by
  intro p hp
  have h : env41010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41009_41010 : H12AffineEnvironment.transform 4 0 env41009 = env41010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41009 == env41010) = true)

def env41011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169401,156117,253977,8328,65,64605,160981,140485,35324,1501,33,256,21792,46212,74250]

theorem envBound41011 : H12AffineFastState.Bounded env41011 := by
  intro p hp
  have h : env41011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40988_41011 : H12AffineEnvironment.transform 17 10281 env40988 = env41011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40988 == env41011) = true)

def env41012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21929,41413,73737,8328,65,64605,46277,58581,35324,1501,33,256,21792,46212,74250]

theorem envBound41012 : H12AffineFastState.Bounded env41012 := by
  intro p hp
  have h : env41012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_41012 : H12AffineEnvironment.transform 16 49168 env41011 = env41012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env41011 == env41012) = true)

def env41013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,49168,2557,1024,32769,4160,21929,32785,66013,348,65,56713,38161,50433,35324,1501,33,256,21792,38224,66526]

theorem envBound41013 : H12AffineFastState.Bounded env41013 := by
  intro p hp
  have h : env41013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41012_41013 : H12AffineEnvironment.transform 12 468 env41012 = env41013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env41012 == env41013) = true)

theorem identity41013 : scanCanonicalize (H12AffineFastState.compose env41013 (packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound41013 : packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env41014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,65536,5393,2557,1024,21760,4160,21929,21776,66013,348,65,2184,16400,4096,23805,1501,33,256,21792,16465,66526]

theorem envBound41014 : H12AffineFastState.Bounded env41014 := by
  intro p hp
  have h : env41014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41013_41014 : H12AffineEnvironment.transform 14 21761 env41013 = env41014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env41013 == env41014) = true)

theorem identity41014 : scanCanonicalize (H12AffineFastState.compose env41014 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound41014 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env41015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,21591,5393,2557,1024,21760,4160,21929,21776,21898,348,65,2184,16400,4096,23805,1501,33,256,21792,16465,22409]

theorem envBound41015 : H12AffineFastState.Bounded env41015 := by
  intro p hp
  have h : env41015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41014_41015 : H12AffineEnvironment.transform 15 21591 env41014 = env41015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env41014 == env41015) = true)

theorem identity41015 : scanCanonicalize (H12AffineFastState.compose env41015 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound41015 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env41016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5393,2557,1024,137,4160,32,153,3,348,65,2184,5529,4096,2420,1501,33,256,169,5592,512]

theorem envBound41016 : H12AffineFastState.Bounded env41016 := by
  intro p hp
  have h : env41016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41015_41016 : H12AffineEnvironment.transform 13 5513 env41015 = env41016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env41015 == env41016) = true)

theorem identity41016 : scanCanonicalize (H12AffineFastState.compose env41016 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound41016 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,137,4096,468,5513,136,478,5393,372,1024,137,4160,32,153,3,348,65,1,5529,4096,509,1501,33,256,169,5592,512]

theorem envBound41017 : H12AffineFastState.Bounded env41017 := by
  intro p hp
  have h : env41017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41016_41017 : H12AffineEnvironment.transform 10 137 env41016 = env41017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env41016 == env41017) = true)

theorem identity41017 : scanCanonicalize (H12AffineFastState.compose env41017 (packedSelected [1,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound41017 : packedSelected [1,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env41018 : List Nat := [2,4,8,16,32,64,120,256,512,1024,113,4096,300,5489,112,294,5393,372,1024,113,4160,32,97,3,348,65,1,5473,4096,261,1317,33,256,81,5408,512]

theorem envBound41018 : H12AffineFastState.Bounded env41018 := by
  intro p hp
  have h : env41018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41017_41018 : H12AffineEnvironment.transform 6 120 env41017 = env41018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env41017 == env41018) = true)

theorem identity41018 : scanCanonicalize (H12AffineFastState.compose env41018 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound41018 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env41019 : List Nat := [2,4,8,16,32,64,120,84,512,1024,113,4096,120,5157,112,114,5189,32,1024,113,4160,32,97,3,8,65,1,5173,4096,81,1137,33,84,81,5236,512]

theorem envBound41019 : H12AffineFastState.Bounded env41019 := by
  intro p hp
  have h : env41019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41018_41019 : H12AffineEnvironment.transform 7 84 env41018 = env41019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env41018 == env41019) = true)

theorem identity41019 : scanCanonicalize (H12AffineFastState.compose env41019 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound41019 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41020 : List Nat := [2,4,8,16,32,64,120,84,512,1024,113,1028,120,33,112,114,65,32,1024,113,1092,32,97,3,8,65,1,49,1028,81,1137,33,84,81,112,512]

theorem envBound41020 : H12AffineFastState.Bounded env41020 := by
  intro p hp
  have h : env41020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41019_41020 : H12AffineEnvironment.transform 11 1028 env41019 = env41020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env41019 == env41020) = true)

def env41021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,49168,2556,1024,32769,4160,21929,32784,66012,349,65,56712,38160,50432,35324,1501,33,256,21792,38225,66527]

theorem envBound41021 : H12AffineFastState.Bounded env41021 := by
  intro p hp
  have h : env41021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41012_41021 : H12AffineEnvironment.transform 12 469 env41012 = env41021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env41012 == env41021) = true)

theorem identity41021 : scanCanonicalize (H12AffineFastState.compose env41021 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound41021 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,478,49168,2556,1024,32769,4160,21929,32784,2,349,65,56712,38160,50432,35324,1501,33,256,21792,38225,513]

theorem envBound41022 : H12AffineFastState.Bounded env41022 := by
  intro p hp
  have h : env41022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41021_41022 : H12AffineEnvironment.transform 15 478 env41021 = env41022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env41021 == env41022) = true)

theorem identity41022 : scanCanonicalize (H12AffineFastState.compose env41022 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41022 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,0,478,16400,2556,1024,1,4160,21929,16,2,349,65,23944,5392,17664,2556,1501,33,256,21792,5457,513]

theorem envBound41023 : H12AffineFastState.Bounded env41023 := by
  intro p hp
  have h : env41023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41022_41023 : H12AffineEnvironment.transform 14 0 env41022 = env41023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41022 == env41023) = true)

theorem identity41023 : scanCanonicalize (H12AffineFastState.compose env41023 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41023 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env41024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,478,5393,2556,1024,1,4160,168,16,2,349,65,2185,5392,4097,2556,1501,33,256,33,5457,513]

theorem envBound41024 : H12AffineFastState.Bounded env41024 := by
  intro p hp
  have h : env41024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41023_41024 : H12AffineEnvironment.transform 13 5377 env41023 = env41024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41023 == env41024) = true)

theorem identity41024 : scanCanonicalize (H12AffineFastState.compose env41024 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound41024 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41025 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,128,5204,0,139,5188,2217,1024,1,4160,168,16,2,8,65,2185,5189,4097,2217,1160,33,85,33,5124,513]

theorem envBound41025 : H12AffineFastState.Bounded env41025 := by
  intro p hp
  have h : env41025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41024_41025 : H12AffineEnvironment.transform 7 85 env41024 = env41025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env41024 == env41025) = true)

theorem identity41025 : scanCanonicalize (H12AffineFastState.compose env41025 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41025 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41026 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,9,5204,0,2,5188,2080,1024,1,4160,33,16,2,8,65,2048,5189,4097,2080,1025,33,85,33,5124,513]

theorem envBound41026 : H12AffineFastState.Bounded env41026 := by
  intro p hp
  have h : env41026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41025_41026 : H12AffineEnvironment.transform 6 9 env41025 = env41026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41025 == env41026) = true)

theorem identity41026 : scanCanonicalize (H12AffineFastState.compose env41026 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound41026 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41027 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,4096,9,4113,0,2,4097,2080,69,1,4160,33,16,2,8,65,2048,4096,4097,2080,68,33,85,33,4161,513]

theorem envBound41027 : H12AffineFastState.Bounded env41027 := by
  intro p hp
  have h : env41027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41026_41027 : H12AffineEnvironment.transform 9 69 env41026 = env41027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env41026 == env41027) = true)

theorem identity41027 : scanCanonicalize (H12AffineFastState.compose env41027 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound41027 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41028 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,49,9,32,0,2,48,2080,69,1,113,33,16,2,8,65,2048,49,48,2080,68,33,85,33,112,513]

theorem envBound41028 : H12AffineFastState.Bounded env41028 := by
  intro p hp
  have h : env41028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41027_41028 : H12AffineEnvironment.transform 11 49 env41027 = env41028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env41027 == env41028) = true)

theorem identity41028 : scanCanonicalize (H12AffineFastState.compose env41028 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41028 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41029 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,9,0,0,2,16,2048,69,1,81,1,16,2,8,65,2048,17,16,2048,68,1,85,1,80,513]

theorem envBound41029 : H12AffineFastState.Bounded env41029 := by
  intro p hp
  have h : env41029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41028_41029 : H12AffineEnvironment.transform 4 0 env41028 = env41029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41028 == env41029) = true)

theorem identity41029 : scanCanonicalize (H12AffineFastState.compose env41029 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound41029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41030 : List Nat := [2,4,8,16,0,64,9,85,512,69,593,17,9,0,0,2,16,593,69,1,81,1,16,2,8,65,593,17,16,593,68,1,85,1,80,513]

theorem envBound41030 : H12AffineFastState.Bounded env41030 := by
  intro p hp
  have h : env41030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41029_41030 : H12AffineEnvironment.transform 10 593 env41029 = env41030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env41029 == env41030) = true)

theorem identity41030 : scanCanonicalize (H12AffineFastState.compose env41030 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound41030 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41031 : List Nat := [2,4,8,16,0,64,9,85,80,69,1,17,9,0,0,2,16,1,69,1,81,1,16,2,8,65,1,17,16,1,68,1,85,1,80,81]

theorem envBound41031 : H12AffineFastState.Bounded env41031 := by
  intro p hp
  have h : env41031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41030_41031 : H12AffineEnvironment.transform 8 80 env41030 = env41031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env41030 == env41031) = true)

theorem identity41031 : scanCanonicalize (H12AffineFastState.compose env41031 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound41031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41032 : List Nat := [2,4,8,16,0,26,9,15,10,31,1,17,9,0,0,2,16,1,31,1,11,1,16,2,8,27,1,17,16,1,30,1,15,1,10,11]

theorem envBound41032 : H12AffineFastState.Bounded env41032 := by
  intro p hp
  have h : env41032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41031_41032 : H12AffineEnvironment.transform 5 26 env41031 = env41032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env41031 == env41032) = true)

theorem identity41032 : scanCanonicalize (H12AffineFastState.compose env41032 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41032 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41033 : List Nat := [2,4,8,11,0,1,9,15,10,4,1,10,9,0,0,2,11,1,4,1,11,1,11,2,8,0,1,10,11,1,5,1,15,1,10,11]

theorem envBound41033 : H12AffineFastState.Bounded env41033 := by
  intro p hp
  have h : env41033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41032_41033 : H12AffineEnvironment.transform 3 11 env41032 = env41033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41032 == env41033) = true)

theorem identity41033 : scanCanonicalize (H12AffineFastState.compose env41033 (packedSelected [12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41033 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env41034 : List Nat := [2,4,3,0,0,1,2,4,1,4,1,1,2,0,0,2,0,1,4,1,0,1,0,2,3,0,1,1,0,1,5,1,4,1,1,0]

theorem envBound41034 : H12AffineFastState.Bounded env41034 := by
  intro p hp
  have h : env41034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41033_41034 : H12AffineEnvironment.transform 2 3 env41033 = env41034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41033 == env41034) = true)

def env41035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21928,41412,73736,8328,65,64605,46276,58580,35324,1501,33,256,21792,46212,74250]

theorem envBound41035 : H12AffineFastState.Bounded env41035 := by
  intro p hp
  have h : env41035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41011_41035 : H12AffineEnvironment.transform 16 49169 env41011 = env41035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env41011 == env41035) = true)

theorem identity41035 : scanCanonicalize (H12AffineFastState.compose env41035 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41035 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21793,41293,73736,8193,65,64605,46157,58461,35189,1364,33,256,21792,46093,74250]

theorem envBound41036 : H12AffineFastState.Bounded env41036 := by
  intro p hp
  have h : env41036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41035_41036 : H12AffineEnvironment.transform 6 9 env41035 = env41036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41035 == env41036) = true)

theorem identity41036 : scanCanonicalize (H12AffineFastState.compose env41036 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41036 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env41037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1024,29788,4160,21793,21776,73736,8193,65,2048,16400,4096,32040,1364,33,256,21792,16464,74250]

theorem envBound41037 : H12AffineFastState.Bounded env41037 := by
  intro p hp
  have h : env41037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41036_41037 : H12AffineEnvironment.transform 14 29789 env41036 = env41037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41036 == env41037) = true)

theorem identity41037 : scanCanonicalize (H12AffineFastState.compose env41037 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41037 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env41038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13388,10281,1024,8540,4160,33,16,73736,8193,65,2048,5392,4096,10280,1364,33,256,32,5456,74250]

theorem envBound41038 : H12AffineFastState.Bounded env41038 := by
  intro p hp
  have h : env41038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41037_41038 : H12AffineEnvironment.transform 13 5376 env41037 = env41038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41037 == env41038) = true)

theorem identity41038 : scanCanonicalize (H12AffineFastState.compose env41038 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound41038 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,5376,33,65536,5424,2389,1024,32,4160,33,16,65908,381,65,2048,5392,4096,2388,1364,33,256,32,5456,66422]

theorem envBound41039 : H12AffineFastState.Bounded env41039 := by
  intro p hp
  have h : env41039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41038_41039 : H12AffineEnvironment.transform 12 380 env41038 = env41039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env41038 == env41039) = true)

def env41040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,510000,8328,65,316533,417021,396524,35325,1500,272393,256,21792,46212,74251]

theorem envBound41040 : H12AffineFastState.Bounded env41040 := by
  intro p hp
  have h : env41040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40987_41040 : H12AffineEnvironment.transform 20 4161 env40987 = env41040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40987 == env41040) = true)

theorem identity41040 : scanCanonicalize (H12AffineFastState.compose env41040 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound41040 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169401,62661,95496,8328,65,158029,57797,45524,35325,1500,169265,256,21792,46212,74251]

theorem envBound41041 : H12AffineFastState.Bounded env41041 := by
  intro p hp
  have h : env41041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41040_41041 : H12AffineEnvironment.transform 17 179512 env41040 = env41041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env41040 == env41041) = true)

theorem identity41041 : scanCanonicalize (H12AffineFastState.compose env41041 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41041 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4161,169401,62661,21762,8328,65,158029,57797,45524,35325,1500,169265,256,21792,46212,513]

theorem envBound41042 : H12AffineFastState.Bounded env41042 := by
  intro p hp
  have h : env41042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41041_41042 : H12AffineEnvironment.transform 15 8202 env41041 = env41042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41041 == env41042) = true)

theorem identity41042 : scanCanonicalize (H12AffineFastState.compose env41042 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound41042 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env41043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16537,64929,1024,32769,4161,54560,62661,21762,8328,65,10708,57797,45524,35325,1500,54696,256,21792,46212,513]

theorem envBound41043 : H12AffineFastState.Bounded env41043 := by
  intro p hp
  have h : env41043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41042_41043 : H12AffineEnvironment.transform 16 16537 env41042 = env41043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env41042 == env41043) = true)

theorem identity41043 : scanCanonicalize (H12AffineFastState.compose env41043 (packedSelected [2,3,6,7,10,11,14,15,19,20,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound41043 : packedSelected [2,3,6,7,10,11,14,15,19,20,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env41044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,8202,16537,32121,1024,217,4161,22008,29725,21762,8328,65,10708,24861,12556,2341,1500,21872,256,21792,13404,513]

theorem envBound41044 : H12AffineFastState.Bounded env41044 := by
  intro p hp
  have h : env41044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41043_41044 : H12AffineEnvironment.transform 14 216 env41043 = env41044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env41043 == env41044) = true)

theorem identity41044 : scanCanonicalize (H12AffineFastState.compose env41044 (packedSelected [1,2,3,5,6,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41044 : packedSelected [1,2,3,5,6,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,216,8202,13508,2340,1024,217,4161,8613,64,8543,8328,65,10708,5440,12556,2341,1500,8493,256,8573,13404,513]

theorem envBound41045 : H12AffineFastState.Bounded env41045 := by
  intro p hp
  have h : env41045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41044_41045 : H12AffineEnvironment.transform 13 13405 env41044 = env41045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41044 == env41045) = true)

theorem identity41045 : scanCanonicalize (H12AffineFastState.compose env41045 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41045 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,216,262,5576,2340,1024,217,4161,169,64,83,388,65,2264,5440,4096,2341,1500,33,256,113,5456,513]

theorem envBound41046 : H12AffineFastState.Bounded env41046 := by
  intro p hp
  have h : env41046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41045_41046 : H12AffineEnvironment.transform 12 268 env41045 = env41046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41045 == env41046) = true)

theorem identity41046 : scanCanonicalize (H12AffineFastState.compose env41046 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41046 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,80,262,5440,2340,1024,81,4161,33,64,83,268,65,2128,5440,4096,2341,1364,33,256,113,5456,513]

theorem envBound41047 : H12AffineFastState.Bounded env41047 := by
  intro p hp
  have h : env41047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41046_41047 : H12AffineEnvironment.transform 6 8 env41046 = env41047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41046 == env41047) = true)

theorem identity41047 : scanCanonicalize (H12AffineFastState.compose env41047 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound41047 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,268,3124,80,262,3109,2340,1024,81,2340,33,64,83,268,65,2128,3109,2405,2341,1364,33,256,113,3125,513]

theorem envBound41048 : H12AffineFastState.Bounded env41048 := by
  intro p hp
  have h : env41048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41047_41048 : H12AffineEnvironment.transform 11 2405 env41047 = env41048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env41047 == env41048) = true)

theorem identity41048 : scanCanonicalize (H12AffineFastState.compose env41048 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41048 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41049 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,268,3124,1,262,3109,2340,1024,0,2340,33,17,2,268,16,2049,3109,2356,2341,1285,33,256,32,3125,513]

theorem envBound41049 : H12AffineFastState.Bounded env41049 := by
  intro p hp
  have h : env41049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41048_41049 : H12AffineEnvironment.transform 5 17 env41048 = env41049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41048 == env41049) = true)

theorem identity41049 : scanCanonicalize (H12AffineFastState.compose env41049 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41050 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2356,268,2340,1,262,2357,2340,272,0,2340,33,17,2,268,16,2049,2357,2356,2341,21,33,256,32,2341,513]

theorem envBound41050 : H12AffineFastState.Bounded env41050 := by
  intro p hp
  have h : env41050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41049_41050 : H12AffineEnvironment.transform 9 272 env41049 = env41050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41049 == env41050) = true)

def env41051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513341,510000,8328,65,6705548,2510012,396525,2136509,2102684,6729201,256,21793,46213,2175563]

theorem envBound41051 : H12AffineFastState.Bounded env41051 := by
  intro p hp
  have h : env41051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40931_41051 : H12AffineEnvironment.transform 22 2513341 env40931 = env41051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513341 env40931 == env41051) = true)

def env41052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513341,510000,8328,65,2409524,2510012,396525,2136509,2102684,2373705,256,21793,46213,2175563]

theorem envBound41052 : H12AffineFastState.Bounded env41052 := by
  intro p hp
  have h : env41052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41051_41052 : H12AffineEnvironment.transform 21 169400 env41051 = env41052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env41051 == env41052) = true)

def env41053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,510000,8328,65,316532,417020,396525,35325,1500,272393,256,21793,46213,74251]

theorem envBound41053 : H12AffineFastState.Bounded env41053 := by
  intro p hp
  have h : env41053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41052_41053 : H12AffineEnvironment.transform 20 4160 env41052 = env41053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41052 == env41053) = true)

theorem identity41053 : scanCanonicalize (H12AffineFastState.compose env41053 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound41053 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,4160,169400,120014,21763,8328,65,215367,115151,102878,35325,1500,243002,256,21793,46213,74251]

theorem envBound41054 : H12AffineFastState.Bounded env41054 := by
  intro p hp
  have h : env41054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41053_41054 : H12AffineEnvironment.transform 17 236851 env41053 = env41054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env41053 == env41054) = true)

def env41055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62708,120014,21763,8328,65,75787,115151,102878,35325,1500,119926,256,21793,46213,74251]

theorem envBound41055 : H12AffineFastState.Bounded env41055 := by
  intro p hp
  have h : env41055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41054_41055 : H12AffineEnvironment.transform 16 24908 env41054 = env41055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env41054 == env41055) = true)

def env41056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62588,119878,21763,8192,65,75787,115015,102742,35189,1364,119926,256,21793,46093,74251]

theorem envBound41056 : H12AffineFastState.Bounded env41056 := by
  intro p hp
  have h : env41056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41055_41056 : H12AffineEnvironment.transform 6 8 env41055 = env41056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41055 == env41056) = true)

theorem identity41056 : scanCanonicalize (H12AffineFastState.compose env41056 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound41056 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,24908,35188,1024,32769,4160,62588,41293,21763,8192,65,23808,46156,58461,35189,1364,41341,256,21793,46093,22272]

theorem envBound41057 : H12AffineFastState.Bounded env41057 := by
  intro p hp
  have h : env41057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41056_41057 : H12AffineEnvironment.transform 15 29963 env41056 = env41057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env41056 == env41057) = true)

theorem identity41057 : scanCanonicalize (H12AffineFastState.compose env41057 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41057 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,29963,24908,23668,1024,21761,4160,8572,29773,21763,8192,65,23808,24908,12637,23669,1364,29821,256,21793,24845,22272]

theorem envBound41058 : H12AffineFastState.Bounded env41058 := by
  intro p hp
  have h : env41058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41057_41058 : H12AffineEnvironment.transform 14 21760 env41057 = env41058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41057 == env41058) = true)

theorem identity41058 : scanCanonicalize (H12AffineFastState.compose env41058 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound41058 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env41059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,343,5392,10280,1024,8541,4160,8572,17,8543,8192,65,10588,5392,12637,10281,1364,33,256,8573,5457,9052]

theorem envBound41059 : H12AffineFastState.Bounded env41059 := by
  intro p hp
  have h : env41059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41058_41059 : H12AffineEnvironment.transform 13 13404 env41058 = env41059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env41058 == env41059) = true)

theorem identity41059 : scanCanonicalize (H12AffineFastState.compose env41059 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41059 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41060 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,8540,343,4096,10280,272,8541,4160,8572,17,8543,8192,65,10588,4096,12637,10281,68,33,256,8573,4161,9052]

theorem envBound41060 : H12AffineFastState.Bounded env41060 := by
  intro p hp
  have h : env41060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41059_41060 : H12AffineEnvironment.transform 9 272 env41059 = env41060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41059 == env41060) = true)

theorem identity41060 : scanCanonicalize (H12AffineFastState.compose env41060 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound41060 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env41061 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,8192,10589,8540,343,2065,10280,272,8541,2129,8572,17,8543,8192,65,10588,2065,10572,10281,68,33,256,8573,2128,9052]

theorem envBound41061 : H12AffineFastState.Bounded env41061 := by
  intro p hp
  have h : env41061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41060_41061 : H12AffineEnvironment.transform 11 2065 env41060 = env41061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env41060 == env41061) = true)

theorem identity41061 : scanCanonicalize (H12AffineFastState.compose env41061 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41061 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41062 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,41,2420,373,343,2065,2049,272,372,2129,341,17,374,41,65,2421,2065,2405,2048,68,33,256,340,2128,885]

theorem envBound41062 : H12AffineFastState.Bounded env41062 := by
  intro p hp
  have h : env41062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41061_41062 : H12AffineEnvironment.transform 12 41 env41061 = env41062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41061 == env41062) = true)

theorem identity41062 : scanCanonicalize (H12AffineFastState.compose env41062 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41062 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41063 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2065,41,2340,293,263,2065,2049,272,292,2049,261,17,294,41,17,2341,2065,2357,2048,20,33,256,260,2048,805]

theorem envBound41063 : H12AffineFastState.Bounded env41063 := by
  intro p hp
  have h : env41063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41062_41063 : H12AffineEnvironment.transform 5 16 env41062 = env41063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41062 == env41063) = true)

theorem identity41063 : scanCanonicalize (H12AffineFastState.compose env41063 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41063 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41064 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,16,41,293,293,263,16,0,272,292,0,261,17,294,41,17,292,16,308,1,20,33,256,260,1,805]

theorem envBound41064 : H12AffineFastState.Bounded env41064 := by
  intro p hp
  have h : env41064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41063_41064 : H12AffineEnvironment.transform 10 1 env41063 = env41064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41063 == env41064) = true)

theorem identity41064 : scanCanonicalize (H12AffineFastState.compose env41064 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41064 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41065 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,16,41,1,1,35,16,0,52,0,0,33,17,2,41,17,0,16,16,1,20,33,36,32,1,513]

theorem envBound41065 : H12AffineFastState.Bounded env41065 := by
  intro p hp
  have h : env41065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41064_41065 : H12AffineEnvironment.transform 7 36 env41064 = env41065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41064 == env41065) = true)

theorem identity41065 : scanCanonicalize (H12AffineFastState.compose env41065 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41066 : List Nat := [2,4,8,0,32,0,8,36,512,36,1,0,41,1,1,35,0,0,36,0,0,33,1,2,41,1,0,0,0,1,4,33,36,32,1,513]

theorem envBound41066 : H12AffineFastState.Bounded env41066 := by
  intro p hp
  have h : env41066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41065_41066 : H12AffineEnvironment.transform 3 0 env41065 = env41066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41065 == env41066) = true)

theorem identity41066 : scanCanonicalize (H12AffineFastState.compose env41066 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound41066 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41067 : List Nat := [2,4,8,0,32,0,8,36,11,36,1,0,41,1,1,35,0,0,36,0,0,33,1,2,41,1,0,0,0,1,4,33,36,32,1,10]

theorem envBound41067 : H12AffineFastState.Bounded env41067 := by
  intro p hp
  have h : env41067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41066_41067 : H12AffineEnvironment.transform 8 11 env41066 = env41067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env41066 == env41067) = true)

def env41068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4160,62589,119879,21763,8193,65,75787,115014,102743,35188,1365,119926,256,21793,46092,74251]

theorem envBound41068 : H12AffineFastState.Bounded env41068 := by
  intro p hp
  have h : env41068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41055_41068 : H12AffineEnvironment.transform 6 9 env41055 = env41068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41055 == env41068) = true)

theorem identity41068 : scanCanonicalize (H12AffineFastState.compose env41068 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound41068 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24908,10281,1024,32769,4160,62589,17,21763,8193,65,64605,5392,17665,35188,1365,32,256,21793,46092,63069]

theorem envBound41069 : H12AffineFastState.Bounded env41069 := by
  intro p hp
  have h : env41069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41068_41069 : H12AffineEnvironment.transform 15 54358 env41068 = env41069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env41068 == env41069) = true)

theorem identity41069 : scanCanonicalize (H12AffineFastState.compose env41069 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41069 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,24908,10281,1024,21761,4160,8573,17,21763,8193,65,10589,5392,17665,23668,1365,32,256,21793,24844,9053]

theorem envBound41070 : H12AffineFastState.Bounded env41070 := by
  intro p hp
  have h : env41070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41069_41070 : H12AffineEnvironment.transform 14 21760 env41069 = env41070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41069 == env41070) = true)

theorem identity41070 : scanCanonicalize (H12AffineFastState.compose env41070 (packedSelected [1,8,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41070 : packedSelected [1,8,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21760,342,16449,2340,1024,21761,4160,112,17,21763,268,65,2128,5392,17665,23668,1365,32,256,21793,16385,592]

theorem envBound41071 : H12AffineFastState.Bounded env41071 := by
  intro p hp
  have h : env41071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41070_41071 : H12AffineEnvironment.transform 12 269 env41070 = env41071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41070 == env41071) = true)

theorem identity41071 : scanCanonicalize (H12AffineFastState.compose env41071 (packedSelected [3,5,7,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1361) := by decide +kernel

theorem selectedBound41071 : packedSelected [3,5,7,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env41072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1361,4096,269,16384,21760,342,16449,1141,1024,21761,4160,112,17,21763,268,65,1281,5392,17665,20773,1365,32,256,21793,16385,592]

theorem envBound41072 : H12AffineFastState.Bounded env41072 := by
  intro p hp
  have h : env41072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41071_41072 : H12AffineEnvironment.transform 10 1361 env41071 = env41072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1361 env41071 == env41072) = true)

theorem identity41072 : scanCanonicalize (H12AffineFastState.compose env41072 (packedSelected [0,2,3,5,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound41072 : packedSelected [0,2,3,5,7,14,16] rootPS < 2^1333 := by decide +kernel

def env41073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1361,4096,269,33,5409,342,96,1141,1024,5408,4160,112,17,5410,268,65,1281,5392,1312,4356,1365,32,256,5376,32,592]

theorem envBound41073 : H12AffineFastState.Bounded env41073 := by
  intro p hp
  have h : env41073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41072_41073 : H12AffineEnvironment.transform 13 33 env41072 = env41073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env41072 == env41073) = true)

def env41074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62709,120014,21763,8328,65,75786,115151,102878,35325,1500,119927,256,21793,46213,74251]

theorem envBound41074 : H12AffineFastState.Bounded env41074 := by
  intro p hp
  have h : env41074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41054_41074 : H12AffineEnvironment.transform 16 24909 env41054 = env41074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env41054 == env41074) = true)

def env41075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62589,119878,21763,8192,65,75786,115015,102742,35189,1364,119927,256,21793,46093,74251]

theorem envBound41075 : H12AffineFastState.Bounded env41075 := by
  intro p hp
  have h : env41075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41074_41075 : H12AffineEnvironment.transform 6 8 env41074 = env41075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41074 == env41075) = true)

theorem identity41075 : scanCanonicalize (H12AffineFastState.compose env41075 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41075 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,89378,1024,8541,4160,21793,95514,21763,8192,65,75786,90139,77834,10281,1364,95531,256,21793,5457,74251]

theorem envBound41076 : H12AffineFastState.Bounded env41076 := by
  intro p hp
  have h : env41076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41075_41076 : H12AffineEnvironment.transform 14 8540 env41075 = env41076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41075 == env41076) = true)

theorem identity41076 : scanCanonicalize (H12AffineFastState.compose env41076 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound41076 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env41077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21795,24909,2049,1024,8541,4160,21793,8249,21763,8192,65,32041,13624,25897,10281,1364,8200,256,21793,5457,30504]

theorem envBound41077 : H12AffineFastState.Bounded env41077 := by
  intro p hp
  have h : env41077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41076_41077 : H12AffineEnvironment.transform 15 21795 env41076 = env41077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env41076 == env41077) = true)

theorem identity41077 : scanCanonicalize (H12AffineFastState.compose env41077 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound41077 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8282,5172,2049,1024,8541,4160,8280,8249,8314,8192,65,2128,13624,4176,10281,1364,8200,256,8280,5457,593]

theorem envBound41078 : H12AffineFastState.Bounded env41078 := by
  intro p hp
  have h : env41078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41077_41078 : H12AffineEnvironment.transform 13 13689 env41077 = env41078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env41077 == env41078) = true)

theorem identity41078 : scanCanonicalize (H12AffineFastState.compose env41078 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41078 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5457,372,114,5172,2049,1024,373,4160,112,17,82,40,65,2128,5392,4176,2049,1364,32,256,112,5457,593]

theorem envBound41079 : H12AffineFastState.Bounded env41079 := by
  intro p hp
  have h : env41079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41078_41079 : H12AffineEnvironment.transform 12 40 env41078 = env41079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41078 == env41079) = true)

theorem identity41079 : scanCanonicalize (H12AffineFastState.compose env41079 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41079 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41080 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5157,0,114,5172,2049,1024,1,4160,112,17,82,40,65,2128,5220,4176,2049,1056,32,116,112,5157,593]

theorem envBound41080 : H12AffineFastState.Bounded env41080 := by
  intro p hp
  have h : env41080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41079_41080 : H12AffineEnvironment.transform 7 116 env41079 = env41080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41079 == env41080) = true)

theorem identity41080 : scanCanonicalize (H12AffineFastState.compose env41080 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41080 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env41081 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5172,2049,1024,1,4113,33,17,3,40,16,2049,5173,4097,2049,1056,32,37,33,5157,512]

theorem envBound41081 : H12AffineFastState.Bounded env41081 := by
  intro p hp
  have h : env41081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41080_41081 : H12AffineEnvironment.transform 5 17 env41080 = env41081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41080 == env41081) = true)

theorem identity41081 : scanCanonicalize (H12AffineFastState.compose env41081 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound41081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41082 : List Nat := [2,4,8,16,32,17,8,37,512,5,2048,4096,40,4128,0,35,4145,2049,5,1,4113,33,17,3,40,16,2049,4144,4097,2049,37,32,37,33,4128,512]

theorem envBound41082 : H12AffineFastState.Bounded env41082 := by
  intro p hp
  have h : env41082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41081_41082 : H12AffineEnvironment.transform 9 5 env41081 = env41082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env41081 == env41082) = true)

theorem identity41082 : scanCanonicalize (H12AffineFastState.compose env41082 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound41082 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41083 : List Nat := [2,4,8,16,32,17,8,37,512,5,2048,561,40,529,0,35,512,2049,5,1,544,33,17,3,40,16,2049,513,560,2049,37,32,37,33,529,512]

theorem envBound41083 : H12AffineFastState.Bounded env41083 := by
  intro p hp
  have h : env41083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41082_41083 : H12AffineEnvironment.transform 11 561 env41082 = env41083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env41082 == env41083) = true)

theorem identity41083 : scanCanonicalize (H12AffineFastState.compose env41083 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound41083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41084 : List Nat := [2,4,8,16,32,17,8,37,512,5,17,561,40,529,0,35,512,16,5,1,544,33,17,3,40,16,16,513,560,16,37,32,37,33,529,512]

theorem envBound41084 : H12AffineFastState.Bounded env41084 := by
  intro p hp
  have h : env41084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41083_41084 : H12AffineEnvironment.transform 10 17 env41083 = env41084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env41083 == env41084) = true)

theorem identity41084 : scanCanonicalize (H12AffineFastState.compose env41084 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41084 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41085 : List Nat := [2,4,8,16,0,17,8,5,512,5,17,529,8,529,0,3,512,16,5,1,512,1,17,3,8,16,16,513,528,16,5,0,5,1,529,512]

theorem envBound41085 : H12AffineFastState.Bounded env41085 := by
  intro p hp
  have h : env41085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41084_41085 : H12AffineEnvironment.transform 4 0 env41084 = env41085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41084 == env41085) = true)

end H12CloudChart1