import H12CloudChart1Data013

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans3428_3440 : H12AffineEnvironment.transform 11 1297 env3428 = env3440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env3428 == env3440) = true)

theorem identity3440 : scanCanonicalize (H12AffineFastState.compose env3440 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3440 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3441 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,25914,1044,262144,1024,32768,1297,41260,16,41002,8225,17,320825,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound3441 : H12AffineFastState.Bounded env3441 := by
  intro p hp
  have h : env3441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3440_3441 : H12AffineEnvironment.transform 6 40 env3440 = env3441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3440 == env3441) = true)

theorem identity3441 : scanCanonicalize (H12AffineFastState.compose env3441 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3441 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3442 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,25914,1044,1039,1024,32768,1297,41260,16,41002,8225,17,57654,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound3442 : H12AffineFastState.Bounded env3442 := by
  intro p hp
  have h : env3442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3441_3442 : H12AffineEnvironment.transform 17 1039 env3441 = env3442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1039 env3441 == env3442) = true)

theorem identity3442 : scanCanonicalize (H12AffineFastState.compose env3442 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 1290) := by decide +kernel

theorem selectedBound3442 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env3443 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,1290,25914,1044,1039,1024,1290,1297,9254,16,9504,8225,17,25660,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound3443 : H12AffineFastState.Bounded env3443 := by
  intro p hp
  have h : env3443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3442_3443 : H12AffineEnvironment.transform 14 1290 env3442 = env3443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1290 env3442 == env3443) = true)

theorem identity3443 : scanCanonicalize (H12AffineFastState.compose env3443 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3443 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3444 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,1038,25662,1044,1039,1024,1038,1045,9254,16,9252,8225,17,25660,16384,16384,19509,16404,17429,4,17428,1045,513]

theorem envBound3444 : H12AffineFastState.Bounded env3444 := by
  intro p hp
  have h : env3444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3443_3444 : H12AffineEnvironment.transform 7 4 env3443 = env3444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3443 == env3444) = true)

theorem identity3444 : scanCanonicalize (H12AffineFastState.compose env3444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound3444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3445 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,8195,1038,1085,1044,1039,1024,1038,1045,9254,16,9252,8225,17,1087,8195,8195,11318,8215,9238,4,9239,1045,513]

theorem envBound3445 : H12AffineFastState.Bounded env3445 := by
  intro p hp
  have h : env3445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3444_3445 : H12AffineEnvironment.transform 13 8195 env3444 = env3445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env3444 == env3445) = true)

theorem identity3445 : scanCanonicalize (H12AffineFastState.compose env3445 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound3445 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env3446 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1071,1045,8192,8195,1038,1085,1044,1039,1024,1038,1045,9254,16,9252,8225,17,1087,8195,8195,8217,8215,9238,4,9239,1045,513]

theorem envBound3446 : H12AffineFastState.Bounded env3446 := by
  intro p hp
  have h : env3446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3445_3446 : H12AffineEnvironment.transform 10 1071 env3445 = env3446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env3445 == env3446) = true)

theorem identity3446 : scanCanonicalize (H12AffineFastState.compose env3446 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound3446 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3447 : List Nat := [2,4,8,16,32,17,40,4,32,1024,1071,1045,8192,8195,1038,1085,1044,1039,1024,1038,1045,9254,16,9252,8225,17,1087,8195,8195,8217,8215,9238,4,9239,1045,33]

theorem envBound3447 : H12AffineFastState.Bounded env3447 := by
  intro p hp
  have h : env3447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3446_3447 : H12AffineEnvironment.transform 8 32 env3446 = env3447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3446 == env3447) = true)

theorem identity3447 : scanCanonicalize (H12AffineFastState.compose env3447 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound3447 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env3448 : List Nat := [2,4,8,16,32,17,40,4,32,52,27,33,8192,8195,58,9,32,59,52,58,33,8210,16,8208,8225,17,11,8195,8195,8217,8215,8226,4,8227,33,33]

theorem envBound3448 : H12AffineFastState.Bounded env3448 := by
  intro p hp
  have h : env3448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3447_3448 : H12AffineEnvironment.transform 9 52 env3447 = env3448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env3447 == env3448) = true)

theorem identity3448 : scanCanonicalize (H12AffineFastState.compose env3448 (packedSelected [0,1,4] rootPS)) = affineNative (2^(12+1) ^^^ 45) := by decide +kernel

theorem selectedBound3448 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env3449 : List Nat := [2,4,8,16,32,17,40,4,32,52,27,33,45,46,58,9,32,59,52,58,33,63,16,61,12,17,11,46,46,52,58,15,4,14,33,33]

theorem envBound3449 : H12AffineFastState.Bounded env3449 := by
  intro p hp
  have h : env3449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3448_3449 : H12AffineEnvironment.transform 12 45 env3448 = env3449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 45 env3448 == env3449) = true)

theorem identity3449 : scanCanonicalize (H12AffineFastState.compose env3449 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3449 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env3450 : List Nat := [2,4,8,11,32,10,40,4,32,47,0,33,45,46,33,9,32,32,47,33,33,36,11,38,12,10,11,46,46,47,33,15,4,14,33,33]

theorem envBound3450 : H12AffineFastState.Bounded env3450 := by
  intro p hp
  have h : env3450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3449_3450 : H12AffineEnvironment.transform 3 11 env3449 = env3450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3449 == env3450) = true)

theorem identity3450 : scanCanonicalize (H12AffineFastState.compose env3450 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3451 : List Nat := [2,4,8,11,10,10,2,4,10,5,0,11,7,4,11,9,10,10,5,11,11,14,11,12,12,10,11,4,4,5,11,15,4,14,11,11]

theorem envBound3451 : H12AffineFastState.Bounded env3451 := by
  intro p hp
  have h : env3451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3450_3451 : H12AffineEnvironment.transform 4 10 env3450 = env3451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3450 == env3451) = true)

theorem identity3451 : scanCanonicalize (H12AffineFastState.compose env3451 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3451 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3452 : List Nat := [2,4,2,1,0,0,2,4,0,5,0,1,7,4,1,3,0,0,5,1,1,4,1,6,6,0,1,4,4,5,1,5,4,4,1,1]

theorem envBound3452 : H12AffineFastState.Bounded env3452 := by
  intro p hp
  have h : env3452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3451_3452 : H12AffineEnvironment.transform 2 2 env3451 = env3452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3451 == env3452) = true)

theorem identity3452 : scanCanonicalize (H12AffineFastState.compose env3452 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3453 : List Nat := [2,0,2,1,0,0,2,0,0,1,0,1,3,0,1,3,0,0,1,1,1,0,1,2,2,0,1,0,0,1,1,1,0,0,1,1]

theorem envBound3453 : H12AffineFastState.Bounded env3453 := by
  intro p hp
  have h : env3453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3452_3453 : H12AffineEnvironment.transform 1 0 env3452 = env3453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3452 == env3453) = true)

def env3454 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41261,5377,41002,8329,5376,323712,16384,16812,22560,74794,17680,256,20481,95382,5820]

theorem envBound3454 : H12AffineFastState.Bounded env3454 := by
  intro p hp
  have h : env3454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3426_3454 : H12AffineEnvironment.transform 21 41261 env3426 = env3454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env3426 == env3454) = true)

theorem identity3454 : scanCanonicalize (H12AffineFastState.compose env3454 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3454 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3455 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,41261,5377,41002,8225,5376,323624,16384,16644,22560,74794,17680,256,20481,95294,5652]

theorem envBound3455 : H12AffineFastState.Bounded env3455 := by
  intro p hp
  have h : env3455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3454_3455 : H12AffineEnvironment.transform 6 40 env3454 = env3455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3454 == env3455) = true)

def env3456 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,16384,32768,65536,1045,262144,1024,32768,1296,41261,17,41002,8225,16,320824,16384,16644,19760,74794,17680,256,17681,90414,772]

theorem envBound3456 : H12AffineFastState.Bounded env3456 := by
  intro p hp
  have h : env3456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3455_3456 : H12AffineEnvironment.transform 11 1296 env3455 = env3456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env3455 == env3456) = true)

def env3457 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,16384,32768,65536,1044,262144,1024,32768,1297,41261,16,41002,8225,17,320825,16384,16644,19761,74794,17680,256,17680,90415,773]

theorem envBound3457 : H12AffineFastState.Bounded env3457 := by
  intro p hp
  have h : env3457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3455_3457 : H12AffineEnvironment.transform 11 1297 env3455 = env3457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env3455 == env3457) = true)

theorem identity3457 : scanCanonicalize (H12AffineFastState.compose env3457 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3457 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3458 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41001,16,41002,8225,17,320573,16384,16384,19509,74794,17428,4,17428,90155,513]

theorem envBound3458 : H12AffineFastState.Bounded env3458 := by
  intro p hp
  have h : env3458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3457_3458 : H12AffineEnvironment.transform 7 4 env3457 = env3458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3457 == env3458) = true)

theorem identity3458 : scanCanonicalize (H12AffineFastState.compose env3458 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 26143) := by decide +kernel

theorem selectedBound3458 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3459 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1045,8192,16384,32768,26143,1044,262144,1024,32768,1045,41001,16,41002,8225,17,320573,16384,16384,19509,16949,17428,4,17428,1588,513]

theorem envBound3459 : H12AffineFastState.Bounded env3459 := by
  intro p hp
  have h : env3459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3458_3459 : H12AffineEnvironment.transform 15 26143 env3458 = env3459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26143 env3458 == env3459) = true)

theorem identity3459 : scanCanonicalize (H12AffineFastState.compose env3459 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3459 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3460 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,16384,32768,26126,1029,262144,1024,32768,1028,41001,1,41002,8225,0,320556,16384,16384,19492,16932,17413,4,17413,1573,513]

theorem envBound3460 : H12AffineFastState.Bounded env3460 := by
  intro p hp
  have h : env3460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3459_3460 : H12AffineEnvironment.transform 3 1 env3459 = env3460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3459 == env3460) = true)

theorem identity3460 : scanCanonicalize (H12AffineFastState.compose env3460 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8744) := by decide +kernel

theorem selectedBound3460 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3461 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,16384,8744,26126,1029,262144,1024,8744,1028,513,1,514,8225,0,280068,16384,16384,19492,16932,17413,4,17413,1573,513]

theorem envBound3461 : H12AffineFastState.Bounded env3461 := by
  intro p hp
  have h : env3461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3460_3461 : H12AffineEnvironment.transform 14 8744 env3460 = env3461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8744 env3460 == env3461) = true)

theorem identity3461 : scanCanonicalize (H12AffineFastState.compose env3461 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1066) := by decide +kernel

theorem selectedBound3461 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3462 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,1066,8744,8740,1029,262144,1024,8744,1028,513,1,514,8225,0,262702,1066,1066,2062,1550,47,4,47,1573,513]

theorem envBound3462 : H12AffineFastState.Bounded env3462 := by
  intro p hp
  have h : env3462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3461_3462 : H12AffineEnvironment.transform 13 1066 env3461 = env3462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1066 env3461 == env3462) = true)

theorem identity3462 : scanCanonicalize (H12AffineFastState.compose env3462 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2062) := by decide +kernel

theorem selectedBound3462 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env3463 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,8192,1066,8744,8740,1029,2062,1024,8744,1028,513,1,514,8225,0,2592,1066,1066,2062,1550,47,4,47,1573,513]

theorem envBound3463 : H12AffineFastState.Bounded env3463 := by
  intro p hp
  have h : env3463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3462_3463 : H12AffineEnvironment.transform 17 2062 env3462 = env3463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2062 env3462 == env3463) = true)

theorem identity3463 : scanCanonicalize (H12AffineFastState.compose env3463 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 3112) := by decide +kernel

theorem selectedBound3463 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env3464 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,1028,3112,1066,3584,3596,1029,2062,1024,3584,1028,513,1,514,3081,0,2592,1066,1066,2062,1550,47,4,47,1573,513]

theorem envBound3464 : H12AffineFastState.Bounded env3464 := by
  intro p hp
  have h : env3464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3463_3464 : H12AffineEnvironment.transform 12 3112 env3463 = env3464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3112 env3463 == env3464) = true)

theorem identity3464 : scanCanonicalize (H12AffineFastState.compose env3464 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound3464 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3465 : List Nat := [2,4,8,1,32,0,40,4,512,1024,42,1028,1026,1066,1578,1574,1029,36,1024,1578,1028,513,1,514,1059,0,522,1066,1066,36,1550,47,4,47,1573,513]

theorem envBound3465 : H12AffineFastState.Bounded env3465 := by
  intro p hp
  have h : env3465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3464_3465 : H12AffineEnvironment.transform 10 42 env3464 = env3465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env3464 == env3465) = true)

theorem identity3465 : scanCanonicalize (H12AffineFastState.compose env3465 (packedSelected [0,1,2,6,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3465 : packedSelected [0,1,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env3466 : List Nat := [2,4,3,1,32,0,35,4,512,1024,33,1028,1026,1057,1569,1574,1029,36,1024,1569,1028,513,1,514,1059,0,513,1057,1057,36,1541,36,4,36,1573,513]

theorem envBound3466 : H12AffineFastState.Bounded env3466 := by
  intro p hp
  have h : env3466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3465_3466 : H12AffineEnvironment.transform 2 3 env3465 = env3466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3465 == env3466) = true)

theorem identity3466 : scanCanonicalize (H12AffineFastState.compose env3466 (packedSelected [1,6] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound3466 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env3467 : List Nat := [2,4,3,1,32,0,35,4,5,1024,33,1028,1026,1057,1060,1059,1029,36,1024,1060,1028,4,1,7,1059,0,4,1057,1057,36,1024,36,4,36,1056,4]

theorem envBound3467 : H12AffineFastState.Bounded env3467 := by
  intro p hp
  have h : env3467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3466_3467 : H12AffineEnvironment.transform 8 5 env3466 = env3467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env3466 == env3467) = true)

theorem identity3467 : scanCanonicalize (H12AffineFastState.compose env3467 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound3467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3468 : List Nat := [2,4,3,1,4,0,7,4,5,1024,5,1028,1026,1029,1024,1031,1029,0,1024,1024,1028,4,1,7,1031,0,4,1029,1029,0,1024,0,4,0,1028,4]

theorem envBound3468 : H12AffineFastState.Bounded env3468 := by
  intro p hp
  have h : env3468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3467_3468 : H12AffineEnvironment.transform 4 4 env3467 = env3468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env3467 == env3468) = true)

def env3469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16893,22640,74795,12644668,257,20561,8479127,8389613]

theorem envBound3469 : H12AffineFastState.Bounded env3469 := by
  intro p hp
  have h : env3469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3417_3469 : H12AffineEnvironment.transform 18 1025 env3417 = env3469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3417 == env3469) = true)

theorem identity3469 : scanCanonicalize (H12AffineFastState.compose env3469 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound3469 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,303232,4176,4525,2080,74795,12624236,257,1,8466887,8389613]

theorem envBound3470 : H12AffineFastState.Bounded env3470 := by
  intro p hp
  have h : env3470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3469_3470 : H12AffineEnvironment.transform 13 4176 env3469 = env3470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env3469 == env3470) = true)

def env3471 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,4194304,8388608,41002,8329,8388609,303232,4096,4525,2080,74795,12624188,257,1,8466839,8389565]

theorem envBound3471 : H12AffineFastState.Bounded env3471 := by
  intro p hp
  have h : env3471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3470_3471 : H12AffineEnvironment.transform 5 16 env3470 = env3471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3470 == env3471) = true)

def env3472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2080,1025,32768,4096,4194304,8388608,41002,8329,8388609,43168,4096,4525,2080,74795,12624188,257,1,8466839,8389565]

theorem envBound3472 : H12AffineFastState.Bounded env3472 := by
  intro p hp
  have h : env3472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3471_3472 : H12AffineEnvironment.transform 17 2080 env3471 = env3472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env3471 == env3472) = true)

theorem identity3472 : scanCanonicalize (H12AffineFastState.compose env3472 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound3472 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env3473 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,4194304,8388608,41002,8329,8388609,43168,4096,4525,2080,1192,12624188,257,1,8392980,8389565]

theorem envBound3473 : H12AffineFastState.Bounded env3473 := by
  intro p hp
  have h : env3473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3472_3473 : H12AffineEnvironment.transform 15 8323 env3472 = env3473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env3472 == env3473) = true)

theorem identity3473 : scanCanonicalize (H12AffineFastState.compose env3473 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound3473 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env3474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,41089,8388608,41002,8329,8388609,43168,4096,4525,2080,1192,8389053,257,1,8392980,8389565]

theorem envBound3474 : H12AffineFastState.Bounded env3474 := by
  intro p hp
  have h : env3474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3473_3474 : H12AffineEnvironment.transform 21 41089 env3473 = env3474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3473 == env3474) = true)

theorem identity3474 : scanCanonicalize (H12AffineFastState.compose env3474 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 185) := by decide +kernel

theorem selectedBound3474 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4524,2080,1025,32768,4096,41089,185,41002,8329,184,43168,4096,4525,2080,1192,260,257,1,4525,772]

theorem envBound3475 : H12AffineFastState.Bounded env3475 := by
  intro p hp
  have h : env3475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3474_3475 : H12AffineEnvironment.transform 22 185 env3474 = env3475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env3474 == env3475) = true)

theorem identity3475 : scanCanonicalize (H12AffineFastState.compose env3475 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3475 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14224,8323,4524,2080,1025,14224,4096,5905,185,6074,8329,184,7984,4096,4525,2080,1192,260,257,1,4525,772]

theorem envBound3476 : H12AffineFastState.Bounded env3476 := by
  intro p hp
  have h : env3476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3475_3476 : H12AffineEnvironment.transform 14 14224 env3475 = env3476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3475 == env3476) = true)

theorem identity3476 : scanCanonicalize (H12AffineFastState.compose env3476 (packedSelected [0,1,4,5,7,8,9,24] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound3476 : packedSelected [0,1,4,5,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env3477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1840,8352,8323,1692,2080,1025,8352,1840,33,185,138,8329,184,2048,1840,1693,2080,1192,260,257,1,1693,772]

theorem envBound3477 : H12AffineFastState.Bounded env3477 := by
  intro p hp
  have h : env3477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3476_3477 : H12AffineEnvironment.transform 11 1840 env3476 = env3477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env3476 == env3477) = true)

theorem identity3477 : scanCanonicalize (H12AffineFastState.compose env3477 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3477 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3478 : List Nat := [2,4,8,16,32,16,19,256,512,1024,2048,1840,8192,1840,8243,8208,1551,2080,1025,8243,1840,33,42,25,8218,43,2048,1840,1550,2080,1083,260,257,1,1550,772]

theorem envBound3478 : H12AffineFastState.Bounded env3478 := by
  intro p hp
  have h : env3478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3477_3478 : H12AffineEnvironment.transform 6 19 env3477 = env3478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3477 == env3478) = true)

theorem identity3478 : scanCanonicalize (H12AffineFastState.compose env3478 (packedSelected [3,4,5,7,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3478 : packedSelected [3,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env3479 : List Nat := [2,4,8,16,32,16,19,256,512,1024,1551,1840,8192,1840,8243,8208,1551,1583,1025,8243,1840,33,42,25,8218,43,1551,1840,1550,1583,1083,260,257,1,1550,772]

theorem envBound3479 : H12AffineFastState.Bounded env3479 := by
  intro p hp
  have h : env3479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3478_3479 : H12AffineEnvironment.transform 10 1551 env3478 = env3479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3478 == env3479) = true)

theorem identity3479 : scanCanonicalize (H12AffineFastState.compose env3479 (packedSelected [1,4,8,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound3479 : packedSelected [1,4,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3480 : List Nat := [2,4,8,16,32,16,19,37,512,1024,1551,1557,8192,1557,8243,8208,1551,1583,1025,8243,1557,33,42,25,8218,43,1551,1557,1550,1583,1083,33,36,1,1550,545]

theorem envBound3480 : H12AffineFastState.Bounded env3480 := by
  intro p hp
  have h : env3480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3479_3480 : H12AffineEnvironment.transform 7 37 env3479 = env3480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env3479 == env3480) = true)

theorem identity3480 : scanCanonicalize (H12AffineFastState.compose env3480 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3480 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3481 : List Nat := [2,4,8,16,27,16,19,30,512,1024,1551,1557,8192,1557,8200,8208,1551,1556,1025,8200,1557,26,17,25,8218,16,1551,1557,1550,1556,1024,26,31,1,1550,538]

theorem envBound3481 : H12AffineFastState.Bounded env3481 := by
  intro p hp
  have h : env3481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3480_3481 : H12AffineEnvironment.transform 4 27 env3480 = env3481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3480 == env3481) = true)

theorem identity3481 : scanCanonicalize (H12AffineFastState.compose env3481 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound3481 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3482 : List Nat := [2,4,8,16,27,16,19,30,512,1024,1551,1557,1053,1557,1045,1037,1551,1556,1025,1045,1557,26,17,25,1031,16,1551,1557,1550,1556,1024,26,31,1,1550,538]

theorem envBound3482 : H12AffineFastState.Bounded env3482 := by
  intro p hp
  have h : env3482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3481_3482 : H12AffineEnvironment.transform 12 1053 env3481 = env3482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env3481 == env3482) = true)

theorem identity3482 : scanCanonicalize (H12AffineFastState.compose env3482 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3482 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3483 : List Nat := [2,4,8,11,0,11,8,5,512,1024,1551,1550,1030,1550,1038,1037,1551,1551,1025,1038,1550,1,10,2,1031,11,1551,1550,1550,1551,1024,1,4,1,1550,513]

theorem envBound3483 : H12AffineFastState.Bounded env3483 := by
  intro p hp
  have h : env3483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3482_3483 : H12AffineEnvironment.transform 3 11 env3482 = env3483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3482 == env3483) = true)

theorem identity3483 : scanCanonicalize (H12AffineFastState.compose env3483 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3483 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3484 : List Nat := [2,4,8,11,0,11,8,5,512,4,523,522,2,522,10,9,523,523,5,10,522,1,10,2,3,11,523,522,522,523,4,1,4,1,522,513]

theorem envBound3484 : H12AffineFastState.Bounded env3484 := by
  intro p hp
  have h : env3484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3483_3484 : H12AffineEnvironment.transform 9 4 env3483 = env3484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3483 == env3484) = true)

theorem identity3484 : scanCanonicalize (H12AffineFastState.compose env3484 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound3484 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3485 : List Nat := [2,4,8,11,0,11,8,5,15,4,4,5,2,5,10,9,4,4,5,10,5,1,10,2,3,11,4,5,5,4,4,1,4,1,5,14]

theorem envBound3485 : H12AffineFastState.Bounded env3485 := by
  intro p hp
  have h : env3485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3484_3485 : H12AffineEnvironment.transform 8 15 env3484 = env3485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env3484 == env3485) = true)

theorem identity3485 : scanCanonicalize (H12AffineFastState.compose env3485 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3485 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3486 : List Nat := [2,0,8,11,0,11,8,1,11,0,0,1,2,1,10,9,0,0,1,10,1,1,10,2,3,11,0,1,1,0,0,1,0,1,1,10]

theorem envBound3486 : H12AffineFastState.Bounded env3486 := by
  intro p hp
  have h : env3486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3485_3486 : H12AffineEnvironment.transform 1 0 env3485 = env3486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3485 == env3486) = true)

def env3487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2081,1025,32768,4096,4194304,8388608,41002,8329,8388609,43169,4096,4525,2080,74795,12624188,257,1,8466839,8389565]

theorem envBound3487 : H12AffineFastState.Bounded env3487 := by
  intro p hp
  have h : env3487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3471_3487 : H12AffineEnvironment.transform 17 2081 env3471 = env3487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3471 == env3487) = true)

theorem identity3487 : scanCanonicalize (H12AffineFastState.compose env3487 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(22+1) ^^^ 4292887) := by decide +kernel

theorem selectedBound3487 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env3488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,2081,1025,32768,4096,4194304,4292887,41002,8329,4292886,43169,4096,4525,2080,74795,73771,257,1,4239488,4293290]

theorem envBound3488 : H12AffineFastState.Bounded env3488 := by
  intro p hp
  have h : env3488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3487_3488 : H12AffineEnvironment.transform 22 4292887 env3487 = env3488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292887 env3487 == env3488) = true)

theorem identity3488 : scanCanonicalize (H12AffineFastState.compose env3488 (packedSelected [2,3,4,5,8,9,11,13,17,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound3488 : packedSelected [2,3,4,5,8,9,11,13,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env3489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8582,4524,2081,1025,32768,4096,4194304,4235409,41002,8329,4235408,43169,4096,4525,2080,1453,429,257,1,4239488,4236076]

theorem envBound3489 : H12AffineFastState.Bounded env3489 := by
  intro p hp
  have h : env3489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3488_3489 : H12AffineEnvironment.transform 15 8582 env3488 = env3489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env3488 == env3489) = true)

theorem identity3489 : scanCanonicalize (H12AffineFastState.compose env3489 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11782) := by decide +kernel

theorem selectedBound3489 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env3490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,11782,8582,4524,2081,1025,11782,4096,4194304,4198039,3628,8329,4198038,1703,4096,4525,2080,1453,429,257,1,4202118,4197674]

theorem envBound3490 : H12AffineFastState.Bounded env3490 := by
  intro p hp
  have h : env3490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3489_3490 : H12AffineEnvironment.transform 14 11782 env3489 = env3490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11782 env3489 == env3490) = true)

theorem identity3490 : scanCanonicalize (H12AffineFastState.compose env3490 (packedSelected [0,4,6,7,9,11,17,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound3490 : packedSelected [0,4,6,7,9,11,17,21,32] rootPS < 2^1333 := by decide +kernel

def env3491 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,4096,8192,4096,8352,8582,4524,1671,1025,8352,4096,4194304,4194353,138,8329,4194352,1703,4096,4525,1670,1453,429,257,1,4198432,4195212]

theorem envBound3491 : H12AffineFastState.Bounded env3491 := by
  intro p hp
  have h : env3491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3490_3491 : H12AffineEnvironment.transform 10 1702 env3490 = env3491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env3490 == env3491) = true)

theorem identity3491 : scanCanonicalize (H12AffineFastState.compose env3491 (packedSelected [0,1,2,6,7,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3491 : packedSelected [0,1,2,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env3492 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,4096,8192,4096,8352,8234,4096,1671,1025,8352,4096,4194304,4194353,138,8329,4194352,1703,4096,4097,1670,1025,1,173,1,4198432,4194848]

theorem envBound3492 : H12AffineFastState.Bounded env3492 := by
  intro p hp
  have h : env3492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3491_3492 : H12AffineEnvironment.transform 7 172 env3491 = env3492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3491 == env3492) = true)

theorem identity3492 : scanCanonicalize (H12AffineFastState.compose env3492 (packedSelected [1,4,5,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3492 : packedSelected [1,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env3493 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,4096,8192,4096,8201,8234,4096,1582,1025,8201,4096,4194304,4194353,35,8224,4194352,1550,4096,4097,1583,1025,1,4,1,4198432,4194848]

theorem envBound3493 : H12AffineFastState.Bounded env3493 := by
  intro p hp
  have h : env3493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3492_3493 : H12AffineEnvironment.transform 6 41 env3492 = env3493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3492 == env3493) = true)

theorem identity3493 : scanCanonicalize (H12AffineFastState.compose env3493 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3493 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3494 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1588,8192,1588,8201,8234,1588,1582,1025,8201,1588,4194304,4194353,35,8224,4194352,1550,1588,1589,1583,1025,1,4,1,4195860,4194848]

theorem envBound3494 : H12AffineFastState.Bounded env3494 := by
  intro p hp
  have h : env3494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3493_3494 : H12AffineEnvironment.transform 11 1588 env3493 = env3494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3493 == env3494) = true)

theorem identity3494 : scanCanonicalize (H12AffineFastState.compose env3494 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3494 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3495 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1588,1031,1588,1038,1069,1588,1582,1025,1038,1588,4194304,4194353,35,1063,4194352,1550,1588,1589,1583,1025,1,4,1,4195860,4194848]

theorem envBound3495 : H12AffineFastState.Bounded env3495 := by
  intro p hp
  have h : env3495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3494_3495 : H12AffineEnvironment.transform 12 1031 env3494 = env3495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3494 == env3495) = true)

theorem identity3495 : scanCanonicalize (H12AffineFastState.compose env3495 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 544) := by decide +kernel

theorem selectedBound3495 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3496 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1588,1031,1588,1038,1069,1588,1582,1025,1038,1588,544,529,35,1063,528,1550,1588,1589,1583,1025,1,4,1,1076,0]

theorem envBound3496 : H12AffineFastState.Bounded env3496 := by
  intro p hp
  have h : env3496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3495_3496 : H12AffineEnvironment.transform 21 544 env3495 = env3496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 544 env3495 == env3496) = true)

theorem identity3496 : scanCanonicalize (H12AffineFastState.compose env3496 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound3496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3497 : List Nat := [2,4,8,16,32,16,41,5,512,53,570,513,50,513,59,24,513,539,52,59,513,544,529,35,18,528,571,513,512,538,52,1,4,1,1,0]

theorem envBound3497 : H12AffineFastState.Bounded env3497 := by
  intro p hp
  have h : env3497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3496_3497 : H12AffineEnvironment.transform 9 53 env3496 = env3497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env3496 == env3497) = true)

def env3498 : List Nat := [2,4,8,16,32,16,41,5,0,53,58,1,50,1,59,24,1,27,52,59,1,32,17,35,18,16,59,1,0,26,52,1,4,1,1,0]

theorem envBound3498 : H12AffineFastState.Bounded env3498 := by
  intro p hp
  have h : env3498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3497_3498 : H12AffineEnvironment.transform 8 0 env3497 = env3498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3497 == env3498) = true)

theorem identity3498 : scanCanonicalize (H12AffineFastState.compose env3498 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3499 : List Nat := [2,4,8,11,32,11,41,5,0,46,33,1,41,1,32,3,1,0,47,32,1,32,10,35,9,11,32,1,0,1,47,1,4,1,1,0]

theorem envBound3499 : H12AffineFastState.Bounded env3499 := by
  intro p hp
  have h : env3499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3498_3499 : H12AffineEnvironment.transform 3 11 env3498 = env3499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3498 == env3499) = true)

def env3500 : List Nat := [2,4,8,16,32,16,41,5,1,53,59,0,50,0,59,24,0,26,52,59,0,33,16,35,18,17,58,0,1,27,52,1,4,1,1,0]

theorem envBound3500 : H12AffineFastState.Bounded env3500 := by
  intro p hp
  have h : env3500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3497_3500 : H12AffineEnvironment.transform 8 1 env3497 = env3500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3497 == env3500) = true)

theorem identity3500 : scanCanonicalize (H12AffineFastState.compose env3500 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound3500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3501 : List Nat := [2,4,8,5,32,5,41,5,1,32,46,0,39,0,46,13,0,15,33,46,0,33,5,35,7,4,47,0,1,14,33,1,4,1,1,0]

theorem envBound3501 : H12AffineFastState.Bounded env3501 := by
  intro p hp
  have h : env3501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3500_3501 : H12AffineEnvironment.transform 3 5 env3500 = env3501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env3500 == env3501) = true)

theorem identity3501 : scanCanonicalize (H12AffineFastState.compose env3501 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound3501 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3502 : List Nat := [2,4,8,5,14,5,7,5,1,14,0,0,9,0,0,13,0,15,15,0,0,15,5,13,7,4,1,0,1,14,15,1,4,1,1,0]

theorem envBound3502 : H12AffineFastState.Bounded env3502 := by
  intro p hp
  have h : env3502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3501_3502 : H12AffineEnvironment.transform 4 14 env3501 = env3502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env3501 == env3502) = true)

theorem identity3502 : scanCanonicalize (H12AffineFastState.compose env3502 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3502 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3503 : List Nat := [2,1,8,0,11,0,2,0,1,11,0,0,9,0,0,8,0,10,10,0,0,10,0,8,2,1,1,0,1,11,10,1,1,1,1,0]

theorem envBound3503 : H12AffineFastState.Bounded env3503 := by
  intro p hp
  have h : env3503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3502_3503 : H12AffineEnvironment.transform 1 1 env3502 = env3503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3502 == env3503) = true)

def leafEnv3503 : List Nat := [2,1,8,0,11,0,2,0,1,11,0,0,9,0,0,8,0,10,10,0,0,10,0,8,11,2,1,1,1,0,1,11,10,1,1,1,0,3,1,0,1,1,0]

def active3503 : List Nat := [0,2]

def tree3503 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3503 : H12WitnessSearch.Good tree3503 := H12GlobalWitnessIndex.good

theorem leafIdentity3503 : H12AffineFastState.composeSystem env3503 rootObs = leafEnv3503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3503 rootObs == leafEnv3503) = true)

theorem terminalChecked3503 : H12PackedTerminal.terminalCheckFast leafEnv3503 active3503 tree3503 = true := by decide +kernel

def env3504 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,4194304,8388608,41002,8329,8388608,303232,4097,4525,2080,74795,12624189,257,1,8466838,8389564]

theorem envBound3504 : H12AffineFastState.Bounded env3504 := by
  intro p hp
  have h : env3504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3470_3504 : H12AffineEnvironment.transform 5 17 env3470 = env3504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3470 == env3504) = true)

theorem identity3504 : scanCanonicalize (H12AffineFastState.compose env3504 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3504 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3505 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,4194304,444,41002,8329,444,303232,4097,4525,2080,74795,4235393,257,1,77866,512]

theorem envBound3505 : H12AffineFastState.Bounded env3505 := by
  intro p hp
  have h : env3505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3504_3505 : H12AffineEnvironment.transform 22 444 env3504 = env3505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3504 == env3505) = true)

theorem identity3505 : scanCanonicalize (H12AffineFastState.compose env3505 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3505 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3506 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4096,41349,444,41002,8329,444,303232,4097,4525,2080,74795,260,257,1,77866,512]

theorem envBound3506 : H12AffineFastState.Bounded env3506 := by
  intro p hp
  have h : env3506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3505_3506 : H12AffineEnvironment.transform 21 41349 env3505 = env3506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3505 == env3506) = true)

theorem identity3506 : scanCanonicalize (H12AffineFastState.compose env3506 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3506 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3507 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,38843,4525,262144,1025,32768,4096,41349,444,41002,8329,444,303232,4097,4525,2080,45968,260,257,1,42897,512]

theorem envBound3507 : H12AffineFastState.Bounded env3507 := by
  intro p hp
  have h : env3507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3506_3507 : H12AffineEnvironment.transform 15 38843 env3506 = env3507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3506 == env3507) = true)

theorem identity3507 : scanCanonicalize (H12AffineFastState.compose env3507 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14136) := by decide +kernel

theorem selectedBound3507 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3508 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,14136,8323,4525,262144,1025,14136,4096,5821,444,5906,8329,444,268216,4097,4525,2080,1192,260,257,1,4265,512]

theorem envBound3508 : H12AffineFastState.Bounded env3508 := by
  intro p hp
  have h : env3508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3507_3508 : H12AffineEnvironment.transform 14 14136 env3507 = env3508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14136 env3507 == env3508) = true)

theorem identity3508 : scanCanonicalize (H12AffineFastState.compose env3508 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3508 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3509 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,14136,8323,4525,2341,1025,14136,4096,5821,444,5906,8329,444,7837,4097,4525,2080,1192,260,257,1,4265,512]

theorem envBound3509 : H12AffineFastState.Bounded env3509 := by
  intro p hp
  have h : env3509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3508_3509 : H12AffineEnvironment.transform 17 2341 env3508 = env3509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3508 == env3509) = true)

theorem identity3509 : scanCanonicalize (H12AffineFastState.compose env3509 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3509 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3510 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,4097,13885,8323,4264,2080,1025,13885,4096,5821,185,5655,8329,185,7837,4097,4264,2080,1192,1,4,1,4265,512]

theorem envBound3510 : H12AffineFastState.Bounded env3510 := by
  intro p hp
  have h : env3510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3509_3510 : H12AffineEnvironment.transform 7 5 env3509 = env3510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3509 == env3510) = true)

theorem identity3510 : scanCanonicalize (H12AffineFastState.compose env3510 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3510 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3511 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1588,8192,1589,8201,8323,1692,2080,1025,8201,1588,137,185,35,8329,185,2217,1589,1692,2080,1192,1,4,1,1693,512]

theorem envBound3511 : H12AffineFastState.Bounded env3511 := by
  intro p hp
  have h : env3511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3510_3511 : H12AffineEnvironment.transform 11 1588 env3510 = env3511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3510 == env3511) = true)

theorem identity3511 : scanCanonicalize (H12AffineFastState.compose env3511 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3511 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3512 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,8192,1589,8201,8235,1588,2080,1025,8201,1588,33,17,35,8225,17,2049,1589,1588,2080,1024,1,4,1,1589,512]

theorem envBound3512 : H12AffineFastState.Bounded env3512 := by
  intro p hp
  have h : env3512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3511_3512 : H12AffineEnvironment.transform 6 40 env3511 = env3512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3511 == env3512) = true)

theorem identity3512 : scanCanonicalize (H12AffineFastState.compose env3512 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound3512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3513 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,2617,1589,2608,2578,1588,2080,1025,2608,1588,33,17,35,2584,17,2049,1589,1588,2080,1024,1,4,1,1589,512]

theorem envBound3513 : H12AffineFastState.Bounded env3513 := by
  intro p hp
  have h : env3513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3512_3513 : H12AffineEnvironment.transform 12 2617 env3512 = env3513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env3512 == env3513) = true)

theorem identity3513 : scanCanonicalize (H12AffineFastState.compose env3513 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3513 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3514 : List Nat := [2,4,8,1,32,0,40,5,512,1024,2048,1573,2600,1572,2593,2563,1573,2080,1025,2593,1573,33,0,35,2569,0,2049,1572,1573,2080,1024,1,4,1,1572,512]

theorem envBound3514 : H12AffineFastState.Bounded env3514 := by
  intro p hp
  have h : env3514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3513_3514 : H12AffineEnvironment.transform 3 1 env3513 = env3514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3513 == env3514) = true)

def env3515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849105,16385,16892,547953,598058,12644668,525568,545872,8479127,8914924]

theorem envBound3515 : H12AffineFastState.Bounded env3515 := by
  intro p hp
  have h : env3515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3416_3515 : H12AffineEnvironment.transform 27 16385 env3416 = env3515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3416 == env3515) = true)

def env3516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,12644668,256,20560,8479127,8389612]

theorem envBound3516 : H12AffineFastState.Bounded env3516 := by
  intro p hp
  have h : env3516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3515_3516 : H12AffineEnvironment.transform 18 1024 env3515 = env3516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3515 == env3516) = true)

theorem identity3516 : scanCanonicalize (H12AffineFastState.compose env3516 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46529) := by decide +kernel

theorem selectedBound3516 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46529,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,8406269,256,20560,8479127,8389612]

theorem envBound3517 : H12AffineFastState.Bounded env3517 := by
  intro p hp
  have h : env3517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3516_3517 : H12AffineEnvironment.transform 21 46529 env3516 = env3517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env3516 == env3517) = true)

def env3518 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,46481,8388608,41002,8329,8388608,323713,16385,16812,22561,74794,8406189,256,20480,8479127,8389564]

theorem envBound3518 : H12AffineFastState.Bounded env3518 := by
  intro p hp
  have h : env3518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3517_3518 : H12AffineEnvironment.transform 5 16 env3517 = env3518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3517 == env3518) = true)

def env3519 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4096,46125,8388608,41002,8329,8388608,323713,16385,16400,22561,74794,8406189,188,20480,8478763,8389120]

theorem envBound3519 : H12AffineFastState.Bounded env3519 := by
  intro p hp
  have h : env3519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3518_3519 : H12AffineEnvironment.transform 7 188 env3518 = env3519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3518 == env3519) = true)

theorem identity3519 : scanCanonicalize (H12AffineFastState.compose env3519 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 46108) := by decide +kernel

theorem selectedBound3519 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3520 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1024,32768,4096,46125,46108,41002,8329,46108,323713,16385,16400,22561,74794,61617,188,20480,119863,46620]

theorem envBound3520 : H12AffineFastState.Bounded env3520 := by
  intro p hp
  have h : env3520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3519_3520 : H12AffineEnvironment.transform 22 46108 env3519 = env3520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46108 env3519 == env3520) = true)

def env3521 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4096,46125,46092,41002,8329,46092,323713,16385,16384,22561,74794,61601,172,20480,119847,46604]

theorem envBound3521 : H12AffineFastState.Bounded env3521 := by
  intro p hp
  have h : env3521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3520_3521 : H12AffineEnvironment.transform 3 0 env3520 = env3521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3520 == env3521) = true)

theorem identity3521 : scanCanonicalize (H12AffineFastState.compose env3521 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3521 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3522 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,28802,4096,262144,1024,32768,4096,46125,46092,41002,8329,46092,323713,16385,16384,22561,21672,61601,172,20480,42149,46604]

theorem envBound3522 : H12AffineFastState.Bounded env3522 := by
  intro p hp
  have h : env3522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3521_3522 : H12AffineEnvironment.transform 15 28802 env3521 = env3522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3521 == env3522) = true)

theorem identity3522 : scanCanonicalize (H12AffineFastState.compose env3522 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound3522 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3523 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,32768,25735,1029,262144,1024,32768,1029,41000,40969,41002,8329,40969,320644,16385,16384,19492,16557,58532,172,17413,42149,41481]

theorem envBound3523 : H12AffineFastState.Bounded env3523 := by
  intro p hp
  have h : env3523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3522_3523 : H12AffineEnvironment.transform 11 1029 env3522 = env3523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env3522 == env3523) = true)

theorem identity3523 : scanCanonicalize (H12AffineFastState.compose env3523 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8833) := by decide +kernel

theorem selectedBound3523 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3524 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,8833,25735,1029,262144,1024,8833,1029,681,648,683,8329,648,280069,16385,16384,19492,16557,17957,172,17413,1572,136]

theorem envBound3524 : H12AffineFastState.Bounded env3524 := by
  intro p hp
  have h : env3524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3523_3524 : H12AffineEnvironment.transform 14 8833 env3523 = env3524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env3523 == env3524) = true)

theorem identity3524 : scanCanonicalize (H12AffineFastState.compose env3524 (packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound3524 : packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3525 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,16384,8833,25735,1029,2561,1024,8833,1029,681,648,683,8329,648,19460,16385,16384,19492,16557,17957,172,17413,1572,136]

theorem envBound3525 : H12AffineFastState.Bounded env3525 := by
  intro p hp
  have h : env3525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3524_3525 : H12AffineEnvironment.transform 17 2561 env3524 = env3525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env3524 == env3525) = true)

theorem identity3525 : scanCanonicalize (H12AffineFastState.compose env3525 (packedSelected [1,5,6,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 8363) := by decide +kernel

theorem selectedBound3525 : packedSelected [1,5,6,11,12,15] rootPS < 2^1333 := by decide +kernel

def env3526 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,1029,8192,8363,8833,1068,1029,2561,1024,8833,1029,681,648,683,8329,648,11439,8362,8363,11407,8198,9870,172,9390,1572,136]

theorem envBound3526 : H12AffineFastState.Bounded env3526 := by
  intro p hp
  have h : env3526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3525_3526 : H12AffineEnvironment.transform 13 8363 env3525 = env3526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8363 env3525 == env3526) = true)

theorem identity3526 : scanCanonicalize (H12AffineFastState.compose env3526 (packedSelected [0,2,3,4,5,6,7,9,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound3526 : packedSelected [0,2,3,4,5,6,7,9,18] rootPS < 2^1333 := by decide +kernel

def env3527 : List Nat := [2,4,8,0,32,0,128,172,137,1024,2048,1029,8192,8363,8200,1068,1029,2184,1024,8200,1029,32,1,34,8329,1,11439,8362,8363,11407,8198,9223,172,9390,1197,136]

theorem envBound3527 : H12AffineFastState.Bounded env3527 := by
  intro p hp
  have h : env3527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3526_3527 : H12AffineEnvironment.transform 8 137 env3526 = env3527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env3526 == env3527) = true)

theorem identity3527 : scanCanonicalize (H12AffineFastState.compose env3527 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound3527 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3528 : List Nat := [2,4,8,0,32,0,128,172,137,1024,2048,1029,2089,2178,2081,1068,1029,2184,1024,2081,1029,32,1,34,2208,1,1158,2179,2178,1190,2095,3118,172,3207,1197,136]

theorem envBound3528 : H12AffineFastState.Bounded env3528 := by
  intro p hp
  have h : env3528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3527_3528 : H12AffineEnvironment.transform 12 2089 env3527 = env3528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env3527 == env3528) = true)

theorem identity3528 : scanCanonicalize (H12AffineFastState.compose env3528 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3528 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3529 : List Nat := [2,4,8,0,32,0,34,14,43,1024,2048,1029,2089,2080,2081,1068,1029,2090,1024,2081,1029,32,1,34,2050,1,1060,2081,2080,1028,2095,3118,14,3109,1039,42]

theorem envBound3529 : H12AffineFastState.Bounded env3529 := by
  intro p hp
  have h : env3529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3528_3529 : H12AffineEnvironment.transform 6 34 env3528 = env3529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3528 == env3529) = true)

theorem identity3529 : scanCanonicalize (H12AffineFastState.compose env3529 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1066) := by decide +kernel

theorem selectedBound3529 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3530 : List Nat := [2,4,8,0,32,0,34,14,43,1024,1066,1029,1027,1034,1035,1068,1029,1024,1024,1035,1029,32,1,34,1064,1,1060,1035,1034,1028,1029,4,14,15,1039,42]

theorem envBound3530 : H12AffineFastState.Bounded env3530 := by
  intro p hp
  have h : env3530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3529_3530 : H12AffineEnvironment.transform 10 1066 env3529 = env3530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1066 env3529 == env3530) = true)

theorem identity3530 : scanCanonicalize (H12AffineFastState.compose env3530 (packedSelected [2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound3530 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env3531 : List Nat := [2,4,8,0,15,0,13,14,4,1024,1029,1029,1027,1034,1035,1027,1029,1024,1024,1035,1029,15,1,13,1031,1,1035,1035,1034,1028,1029,4,14,15,1039,5]

theorem envBound3531 : H12AffineFastState.Bounded env3531 := by
  intro p hp
  have h : env3531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3530_3531 : H12AffineEnvironment.transform 4 15 env3530 = env3531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env3530 == env3531) = true)

theorem identity3531 : scanCanonicalize (H12AffineFastState.compose env3531 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3532 : List Nat := [2,4,8,0,15,0,13,14,4,14,11,11,13,4,5,13,11,14,14,5,11,15,1,13,9,1,5,5,4,10,11,4,14,15,1,5]

theorem envBound3532 : H12AffineFastState.Bounded env3532 := by
  intro p hp
  have h : env3532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3531_3532 : H12AffineEnvironment.transform 9 14 env3531 = env3532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3531 == env3532) = true)

theorem identity3532 : scanCanonicalize (H12AffineFastState.compose env3532 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3533 : List Nat := [2,4,3,0,4,0,6,5,4,5,0,0,6,4,5,6,0,5,5,5,0,4,1,6,2,1,5,5,4,1,0,4,5,4,1,5]

theorem envBound3533 : H12AffineFastState.Bounded env3533 := by
  intro p hp
  have h : env3533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3532_3533 : H12AffineEnvironment.transform 2 3 env3532 = env3533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3532 == env3533) = true)

def leafEnv3533 : List Nat := [2,4,3,0,4,0,6,5,4,5,0,0,6,4,5,6,0,5,5,5,0,4,1,6,1,2,1,1,5,5,4,1,0,4,5,4,5,3,1,5,1,4,0]

def active3533 : List Nat := [0,1]

def tree3533 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3533 : H12WitnessSearch.Good tree3533 := H12GlobalWitnessIndex.good

theorem leafIdentity3533 : H12AffineFastState.composeSystem env3533 rootObs = leafEnv3533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3533 rootObs == leafEnv3533) = true)

theorem terminalChecked3533 : H12PackedTerminal.terminalCheckFast leafEnv3533 active3533 tree3533 = true := by decide +kernel

def env3534 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,46125,46093,41002,8329,46093,323713,16385,16385,22561,74794,61600,173,20480,119846,46605]

theorem envBound3534 : H12AffineFastState.Bounded env3534 := by
  intro p hp
  have h : env3534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3520_3534 : H12AffineEnvironment.transform 3 1 env3520 = env3534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3520 == env3534) = true)

theorem identity3534 : scanCanonicalize (H12AffineFastState.compose env3534 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3534 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3535 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,46125,46093,41002,8224,46093,323624,16385,16385,22561,74794,61449,4,20480,119846,46605]

theorem envBound3535 : H12AffineFastState.Bounded env3535 := by
  intro p hp
  have h : env3535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3534_3535 : H12AffineEnvironment.transform 6 41 env3534 = env3535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3534 == env3535) = true)

theorem identity3535 : scanCanonicalize (H12AffineFastState.compose env3535 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound3535 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3536 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53282,4097,262144,1024,32768,4096,46125,46093,41002,8224,46093,323624,16385,16385,22561,62472,61449,4,20480,1028,46605]

theorem envBound3536 : H12AffineFastState.Bounded env3536 := by
  intro p hp
  have h : env3536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3535_3536 : H12AffineEnvironment.transform 15 53282 env3535 = env3536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env3535 == env3536) = true)

theorem identity3536 : scanCanonicalize (H12AffineFastState.compose env3536 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22529) := by decide +kernel

theorem selectedBound3536 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3537 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53282,4097,22529,1024,32768,4096,46125,46093,41002,8224,46093,43049,16385,16385,22561,62472,61449,4,20480,1028,46605]

theorem envBound3537 : H12AffineFastState.Bounded env3537 := by
  intro p hp
  have h : env3537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3536_3537 : H12AffineEnvironment.transform 17 22529 env3536 = env3537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22529 env3536 == env3537) = true)

theorem identity3537 : scanCanonicalize (H12AffineFastState.compose env3537 (packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3537 : packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3538 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1550,4096,8192,16384,32768,53282,4097,22031,1024,32768,4096,46125,46093,41002,8224,46093,42535,16385,16385,22063,62472,61449,4,20480,1028,46605]

theorem envBound3538 : H12AffineFastState.Bounded env3538 := by
  intro p hp
  have h : env3538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3537_3538 : H12AffineEnvironment.transform 10 1550 env3537 = env3538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3537 == env3538) = true)

theorem identity3538 : scanCanonicalize (H12AffineFastState.compose env3538 (packedSelected [0,3,4,5,6,7,9,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3538 : packedSelected [0,3,4,5,6,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env3539 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1550,4096,8192,16384,1582,22028,4097,22031,1024,1582,4096,12803,12835,9732,8224,12835,8201,16385,16385,22063,29222,30247,4,20480,1028,12323]

theorem envBound3539 : H12AffineFastState.Bounded env3539 := by
  intro p hp
  have h : env3539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3538_3539 : H12AffineEnvironment.transform 14 1582 env3538 = env3539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1582 env3538 == env3539) = true)

theorem identity3539 : scanCanonicalize (H12AffineFastState.compose env3539 (packedSelected [2,3,4,8,9,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 8707) := by decide +kernel

theorem selectedBound3539 : packedSelected [2,3,4,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env3540 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1550,4096,8192,8707,1582,13327,4097,13324,1024,1582,4096,12803,12835,9732,8224,12835,8201,8706,8706,13356,4133,5156,4,12803,1028,12323]

theorem envBound3540 : H12AffineFastState.Bounded env3540 := by
  intro p hp
  have h : env3540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3539_3540 : H12AffineEnvironment.transform 13 8707 env3539 = env3540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8707 env3539 == env3540) = true)

theorem identity3540 : scanCanonicalize (H12AffineFastState.compose env3540 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(12+1) ^^^ 1575) := by decide +kernel

theorem selectedBound3540 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env3541 : List Nat := [2,4,8,1,32,1,41,4,512,1024,1550,4096,1575,1060,1582,4648,4097,4651,1024,1582,4096,5156,5124,35,1543,5124,1582,1061,1061,4619,4133,5156,4,5156,1028,5636]

theorem envBound3541 : H12AffineFastState.Bounded env3541 := by
  intro p hp
  have h : env3541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3540_3541 : H12AffineEnvironment.transform 12 1575 env3540 = env3541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1575 env3540 == env3541) = true)

theorem identity3541 : scanCanonicalize (H12AffineFastState.compose env3541 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3541 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3542 : List Nat := [2,4,8,1,32,1,41,4,512,4,522,4096,547,32,554,4648,4097,4651,4,554,4096,4128,4096,35,515,4096,554,33,33,4619,4133,4128,4,4128,0,4608]

theorem envBound3542 : H12AffineFastState.Bounded env3542 := by
  intro p hp
  have h : env3542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3541_3542 : H12AffineEnvironment.transform 9 4 env3541 = env3542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3541 == env3542) = true)

theorem identity3542 : scanCanonicalize (H12AffineFastState.compose env3542 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3542 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env3543 : List Nat := [2,4,8,1,1,1,8,4,512,4,522,4096,514,1,523,4617,4097,4618,4,523,4096,4097,4096,2,515,4096,523,0,0,4619,4100,4097,4,4097,0,4608]

theorem envBound3543 : H12AffineFastState.Bounded env3543 := by
  intro p hp
  have h : env3543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3542_3543 : H12AffineEnvironment.transform 4 1 env3542 = env3543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3542 == env3543) = true)

theorem identity3543 : scanCanonicalize (H12AffineFastState.compose env3543 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound3543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3544 : List Nat := [2,4,8,1,1,1,8,4,11,4,1,4096,9,1,0,4098,4097,4097,4,0,4096,4097,4096,2,8,4096,0,0,0,4096,4100,4097,4,4097,0,4107]

theorem envBound3544 : H12AffineFastState.Bounded env3544 := by
  intro p hp
  have h : env3544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3543_3544 : H12AffineEnvironment.transform 8 11 env3543 = env3544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env3543 == env3544) = true)

theorem identity3544 : scanCanonicalize (H12AffineFastState.compose env3544 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound3544 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3545 : List Nat := [2,4,8,1,1,1,8,4,11,4,1,11,9,1,0,9,10,10,4,0,11,10,11,2,8,11,0,0,0,11,15,10,4,10,0,0]

theorem envBound3545 : H12AffineFastState.Bounded env3545 := by
  intro p hp
  have h : env3545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3544_3545 : H12AffineEnvironment.transform 11 11 env3544 = env3545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env3544 == env3545) = true)

theorem identity3545 : scanCanonicalize (H12AffineFastState.compose env3545 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3545 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3546 : List Nat := [2,4,3,1,1,1,3,4,0,4,1,0,2,1,0,2,1,1,4,0,0,1,0,2,3,0,0,0,0,0,4,1,4,1,0,0]

theorem envBound3546 : H12AffineFastState.Bounded env3546 := by
  intro p hp
  have h : env3546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3545_3546 : H12AffineEnvironment.transform 2 3 env3545 = env3546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3545 == env3546) = true)

def env3547 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1024,32768,4096,46124,8388608,41002,8329,8388608,323713,16385,16401,22561,74794,8406189,189,20480,8478762,8389121]

theorem envBound3547 : H12AffineFastState.Bounded env3547 := by
  intro p hp
  have h : env3547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3518_3547 : H12AffineEnvironment.transform 7 189 env3518 = env3547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3518 == env3547) = true)

theorem identity3547 : scanCanonicalize (H12AffineFastState.compose env3547 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound3547 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3548 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,4096,8192,16384,32768,53403,4113,262144,1024,32768,4096,46124,8388608,41002,8329,8388608,323713,16385,16401,22561,62641,8406189,189,20480,8433841,8389121]

theorem envBound3548 : H12AffineFastState.Bounded env3548 := by
  intro p hp
  have h : env3548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3547_3548 : H12AffineEnvironment.transform 15 53403 env3547 = env3548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env3547 == env3548) = true)

def env3549 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1024,32768,4096,46124,8388608,41002,8329,8388608,323713,16385,16385,22561,62625,8406189,173,20480,8433825,8389121]

theorem envBound3549 : H12AffineFastState.Bounded env3549 := by
  intro p hp
  have h : env3549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3548_3549 : H12AffineEnvironment.transform 3 0 env3548 = env3549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3548 == env3549) = true)

def env3550 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8352,28715,4097,262144,1024,8352,4096,5260,8388608,138,8329,8388608,282657,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3550 : H12AffineFastState.Bounded env3550 := by
  intro p hp
  have h : env3550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3549_3550 : H12AffineEnvironment.transform 14 8352 env3549 = env3550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3549 == env3550) = true)

theorem identity3550 : scanCanonicalize (H12AffineFastState.compose env3550 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound3550 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3551 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8352,28715,4097,19493,1024,8352,4096,5260,8388608,138,8329,8388608,7172,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3551 : H12AffineFastState.Bounded env3551 := by
  intro p hp
  have h : env3551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3550_3551 : H12AffineEnvironment.transform 17 19493 env3550 = env3551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env3550 == env3551) = true)

theorem identity3551 : scanCanonicalize (H12AffineFastState.compose env3551 (packedSelected [2,3,5,6,10,13,17,21] rootPS)) = affineNative (2^(12+1) ^^^ 2219) := by decide +kernel

theorem selectedBound3551 : packedSelected [2,3,5,6,10,13,17,21] rootPS < 2^1333 := by decide +kernel

def env3552 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,16384,2059,22656,4097,19493,1024,2059,4096,5260,8388608,138,2082,8388608,7172,16385,16385,22561,21505,8406189,173,20480,8392705,8389121]

theorem envBound3552 : H12AffineFastState.Bounded env3552 := by
  intro p hp
  have h : env3552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3551_3552 : H12AffineEnvironment.transform 12 2219 env3551 = env3552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2219 env3551 == env3552) = true)

theorem identity3552 : scanCanonicalize (H12AffineFastState.compose env3552 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(22+1) ^^^ 5293) := by decide +kernel

theorem selectedBound3552 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env3553 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,16384,2059,22656,4097,19493,1024,2059,4096,5260,5293,138,2082,5293,7172,16385,16385,22561,21505,20480,173,20480,1196,5804]

theorem envBound3553 : H12AffineFastState.Bounded env3553 := by
  intro p hp
  have h : env3553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3552_3553 : H12AffineEnvironment.transform 22 5293 env3552 = env3553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5293 env3552 == env3553) = true)

theorem identity3553 : scanCanonicalize (H12AffineFastState.compose env3553 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 2723) := by decide +kernel

theorem selectedBound3553 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3554 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,2219,2723,2059,4643,4097,1670,1024,2059,4096,5260,5293,138,2082,5293,7172,2722,2722,4738,7842,6819,173,6819,1196,5804]

theorem envBound3554 : H12AffineFastState.Bounded env3554 := by
  intro p hp
  have h : env3554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3553_3554 : H12AffineEnvironment.transform 13 2723 env3553 = env3554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2723 env3553 == env3554) = true)

theorem identity3554 : scanCanonicalize (H12AffineFastState.compose env3554 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound3554 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env3555 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,648,2219,2723,2059,171,649,1670,1024,2059,648,1540,1573,138,2082,1573,3724,2722,2722,10,3114,2091,173,2091,1196,1060]

theorem envBound3555 : H12AffineFastState.Bounded env3555 := by
  intro p hp
  have h : env3555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3554_3555 : H12AffineEnvironment.transform 11 648 env3554 = env3555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env3554 == env3555) = true)

theorem identity3555 : scanCanonicalize (H12AffineFastState.compose env3555 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3555 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env3556 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,544,2051,2571,2059,3,545,1582,1024,2059,544,1540,1573,34,2082,1573,3620,2570,2570,10,3114,2091,5,2091,1028,1060]

theorem envBound3556 : H12AffineFastState.Bounded env3556 := by
  intro p hp
  have h : env3556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3555_3556 : H12AffineEnvironment.transform 6 40 env3555 = env3556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3555 == env3556) = true)

theorem identity3556 : scanCanonicalize (H12AffineFastState.compose env3556 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound3556 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3557 : List Nat := [2,4,8,0,32,0,40,5,512,1024,43,544,40,544,32,3,545,1582,1024,32,544,1540,1573,34,9,1573,1551,545,545,10,1025,0,5,0,1028,1060]

theorem envBound3557 : H12AffineFastState.Bounded env3557 := by
  intro p hp
  have h : env3557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3556_3557 : H12AffineEnvironment.transform 10 43 env3556 = env3557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env3556 == env3557) = true)

theorem identity3557 : scanCanonicalize (H12AffineFastState.compose env3557 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3557 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3558 : List Nat := [2,4,8,0,32,0,40,5,512,5,43,544,40,544,32,3,545,555,5,32,544,513,544,34,9,544,522,545,545,10,4,0,5,0,1,33]

theorem envBound3558 : H12AffineFastState.Bounded env3558 := by
  intro p hp
  have h : env3558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3557_3558 : H12AffineEnvironment.transform 9 5 env3557 = env3558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3557 == env3558) = true)

theorem identity3558 : scanCanonicalize (H12AffineFastState.compose env3558 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound3558 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3559 : List Nat := [2,4,8,0,32,0,40,5,33,5,43,1,40,1,32,3,0,10,5,32,1,32,1,34,9,1,43,0,0,10,4,0,5,0,1,33]

theorem envBound3559 : H12AffineFastState.Bounded env3559 := by
  intro p hp
  have h : env3559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3558_3559 : H12AffineEnvironment.transform 8 33 env3558 = env3559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3558 == env3559) = true)

theorem identity3559 : scanCanonicalize (H12AffineFastState.compose env3559 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3560 : List Nat := [2,4,3,0,32,0,35,5,33,5,32,1,35,1,32,3,0,1,5,32,1,32,1,34,2,1,32,0,0,1,4,0,5,0,1,33]

theorem envBound3560 : H12AffineFastState.Bounded env3560 := by
  intro p hp
  have h : env3560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3559_3560 : H12AffineEnvironment.transform 2 3 env3559 = env3560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3559 == env3560) = true)

def env3561 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8353,28714,4097,262144,1024,8353,4096,5261,8388608,139,8329,8388608,282656,16385,16385,22561,21504,8406189,173,20480,8392704,8389121]

theorem envBound3561 : H12AffineFastState.Bounded env3561 := by
  intro p hp
  have h : env3561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3549_3561 : H12AffineEnvironment.transform 14 8353 env3549 = env3561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3549 == env3561) = true)

theorem identity3561 : scanCanonicalize (H12AffineFastState.compose env3561 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3561 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3562 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8353,28714,4097,2081,1024,8353,4096,5261,8388608,139,8329,8388608,22529,16385,16385,22561,21504,8406189,173,20480,8392704,8389121]

theorem envBound3562 : H12AffineFastState.Bounded env3562 := by
  intro p hp
  have h : env3562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3561_3562 : H12AffineEnvironment.transform 17 2081 env3561 = env3562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3561 == env3562) = true)

theorem identity3562 : scanCanonicalize (H12AffineFastState.compose env3562 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(22+1) ^^^ 9766) := by decide +kernel

theorem selectedBound3562 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3563 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,16384,8353,28714,4097,2081,1024,8353,4096,5261,9766,139,8329,9766,22529,16385,16385,22561,21504,25227,173,20480,13862,9255]

theorem envBound3563 : H12AffineFastState.Bounded env3563 := by
  intro p hp
  have h : env3563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3562_3563 : H12AffineEnvironment.transform 22 9766 env3562 = env3563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9766 env3562 == env3563) = true)

theorem identity3563 : scanCanonicalize (H12AffineFastState.compose env3563 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 7815) := by decide +kernel

theorem selectedBound3563 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env3564 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,8192,7815,8353,11949,4097,2081,1024,8353,4096,5261,9766,139,8329,9766,1670,7814,7814,1702,2695,15372,173,3719,13862,9255]

theorem envBound3564 : H12AffineFastState.Bounded env3564 := by
  intro p hp
  have h : env3564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3563_3564 : H12AffineEnvironment.transform 13 7815 env3563 = env3564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7815 env3563 == env3564) = true)

theorem identity3564 : scanCanonicalize (H12AffineFastState.compose env3564 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4643) := by decide +kernel

theorem selectedBound3564 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env3565 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,4096,4643,7815,4738,7310,4097,2081,1024,4738,4096,5261,5125,139,4778,5125,1670,7814,7814,1702,2695,3631,173,3719,1029,5636]

theorem envBound3565 : H12AffineFastState.Bounded env3565 := by
  intro p hp
  have h : env3565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3564_3565 : H12AffineEnvironment.transform 12 4643 env3564 = env3565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4643 env3564 == env3565) = true)

theorem identity3565 : scanCanonicalize (H12AffineFastState.compose env3565 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound3565 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env3566 : List Nat := [2,4,8,0,32,0,128,173,130,1024,2048,4096,4257,7173,4096,7310,4097,2081,1024,4096,4096,5261,5125,139,4136,5125,1028,7172,7172,1060,2053,3245,173,3077,1029,5254]

theorem envBound3566 : H12AffineFastState.Bounded env3566 := by
  intro p hp
  have h : env3566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3565_3566 : H12AffineEnvironment.transform 8 130 env3565 = env3566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env3565 == env3566) = true)

def env3567 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1024,32768,4096,46124,8388608,41002,8329,8388608,323713,16385,16384,22561,62624,8406189,172,20480,8433824,8389121]

theorem envBound3567 : H12AffineFastState.Bounded env3567 := by
  intro p hp
  have h : env3567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3548_3567 : H12AffineEnvironment.transform 3 1 env3548 = env3567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3548 == env3567) = true)

theorem identity3567 : scanCanonicalize (H12AffineFastState.compose env3567 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5293) := by decide +kernel

theorem selectedBound3567 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3568 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1024,32768,4096,46124,5293,41002,8329,5293,323713,16385,16384,22561,62624,20480,172,20480,41997,5804]

theorem envBound3568 : H12AffineFastState.Bounded env3568 := by
  intro p hp
  have h : env3568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3567_3568 : H12AffineEnvironment.transform 22 5293 env3567 = env3568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5293 env3567 == env3568) = true)

theorem identity3568 : scanCanonicalize (H12AffineFastState.compose env3568 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3568 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3569 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53283,4096,262144,1024,32768,4096,46124,5124,41002,8224,5124,323624,16385,16384,22561,62473,20480,5,20480,41997,5637]

theorem envBound3569 : H12AffineFastState.Bounded env3569 := by
  intro p hp
  have h : env3569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3568_3569 : H12AffineEnvironment.transform 6 41 env3568 = env3569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3568 == env3569) = true)

theorem identity3569 : scanCanonicalize (H12AffineFastState.compose env3569 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound3569 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3570 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53283,4096,43048,1024,32768,4096,46124,5124,41002,8224,5124,22528,16385,16384,22561,62473,20480,5,20480,41997,5637]

theorem envBound3570 : H12AffineFastState.Bounded env3570 := by
  intro p hp
  have h : env3570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3569_3570 : H12AffineEnvironment.transform 17 43048 env3569 = env3570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env3569 == env3570) = true)

theorem identity3570 : scanCanonicalize (H12AffineFastState.compose env3570 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 13357) := by decide +kernel

theorem selectedBound3570 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3571 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,16384,13357,25614,4096,7173,1024,13357,4096,1,5124,5127,8224,5124,22528,16385,16384,22561,16420,20480,5,20480,4128,5637]

theorem envBound3571 : H12AffineFastState.Bounded env3571 := by
  intro p hp
  have h : env3571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3570_3571 : H12AffineEnvironment.transform 14 13357 env3570 = env3571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13357 env3570 == env3571) = true)

theorem identity3571 : scanCanonicalize (H12AffineFastState.compose env3571 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4618) := by decide +kernel

theorem selectedBound3571 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3572 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,4096,8192,4618,13357,13828,4096,7173,1024,13357,4096,1,5124,5127,8224,5124,2570,4619,4618,2603,4654,522,5,522,4128,5637]

theorem envBound3572 : H12AffineFastState.Bounded env3572 := by
  intro p hp
  have h : env3572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3571_3572 : H12AffineEnvironment.transform 13 4618 env3571 = env3572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4618 env3571 == env3572) = true)

theorem identity3572 : scanCanonicalize (H12AffineFastState.compose env3572 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2570) := by decide +kernel

theorem selectedBound3572 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env3573 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,2570,8192,2048,11815,11278,2570,1551,1024,11815,2570,1,3598,3597,8224,3598,2570,2049,2048,2603,2084,522,5,522,2602,3087]

theorem envBound3573 : H12AffineFastState.Bounded env3573 := by
  intro p hp
  have h : env3573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3572_3573 : H12AffineEnvironment.transform 11 2570 env3572 = env3573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2570 env3572 == env3573) = true)

theorem identity3573 : scanCanonicalize (H12AffineFastState.compose env3573 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound3573 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3574 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,2570,1069,2048,2570,2083,2570,1551,1024,2570,2570,1,3598,3597,1037,3598,2570,2049,2048,2603,2084,522,5,522,2602,3087]

theorem envBound3574 : H12AffineFastState.Bounded env3574 := by
  intro p hp
  have h : env3574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3573_3574 : H12AffineEnvironment.transform 12 1069 env3573 = env3574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env3573 == env3574) = true)

theorem identity3574 : scanCanonicalize (H12AffineFastState.compose env3574 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3574 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3575 : List Nat := [2,4,8,1,32,1,41,5,512,14,2048,2570,35,2048,2570,2083,2570,513,14,2570,2570,1,2560,2563,3,2560,2570,2049,2048,2603,2084,522,5,522,2602,2049]

theorem envBound3575 : H12AffineFastState.Bounded env3575 := by
  intro p hp
  have h : env3575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3574_3575 : H12AffineEnvironment.transform 9 14 env3574 = env3575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3574 == env3575) = true)

theorem identity3575 : scanCanonicalize (H12AffineFastState.compose env3575 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3575 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3576 : List Nat := [2,4,8,1,1,1,8,5,512,14,2048,2570,2,2048,2570,2050,2570,513,14,2570,2570,1,2560,2563,3,2560,2570,2049,2048,2570,2053,522,5,522,2571,2049]

theorem envBound3576 : H12AffineFastState.Bounded env3576 := by
  intro p hp
  have h : env3576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3575_3576 : H12AffineEnvironment.transform 4 1 env3575 = env3576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3575 == env3576) = true)

def env3577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46480,8388608,41002,8329,8388609,323712,16385,16813,22560,74794,8406188,256,20481,8479127,8389565]

theorem envBound3577 : H12AffineFastState.Bounded env3577 := by
  intro p hp
  have h : env3577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3517_3577 : H12AffineEnvironment.transform 5 17 env3517 = env3577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3517 == env3577) = true)

theorem identity3577 : scanCanonicalize (H12AffineFastState.compose env3577 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3577 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46480,445,41002,8329,444,323712,16385,16813,22560,74794,17681,256,20481,90154,512]

theorem envBound3578 : H12AffineFastState.Bounded env3578 := by
  intro p hp
  have h : env3578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3577_3578 : H12AffineEnvironment.transform 22 445 env3577 = env3578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3577 == env3578) = true)

theorem identity3578 : scanCanonicalize (H12AffineFastState.compose env3578 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound3578 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1464,262144,1024,32768,1045,41349,445,41002,8329,444,320661,16385,16813,19509,74794,17681,256,17428,90154,512]

theorem envBound3579 : H12AffineFastState.Bounded env3579 := by
  intro p hp
  have h : env3579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3578_3579 : H12AffineEnvironment.transform 11 1045 env3578 = env3579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env3578 == env3579) = true)

theorem identity3579 : scanCanonicalize (H12AffineFastState.compose env3579 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33710) := by decide +kernel

theorem selectedBound3579 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,33710,1464,262144,1024,32768,1045,41349,445,41002,8329,444,320661,16385,16813,19509,42884,17681,256,17428,58244,512]

theorem envBound3580 : H12AffineFastState.Bounded env3580 := by
  intro p hp
  have h : env3580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3579_3580 : H12AffineEnvironment.transform 15 33710 env3579 = env3580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33710 env3579 == env3580) = true)

theorem identity3580 : scanCanonicalize (H12AffineFastState.compose env3580 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3580 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25750,1464,262144,1024,26424,1045,18109,445,18194,8329,444,263085,16385,16813,19509,16572,17681,256,17428,1212,512]

theorem envBound3581 : H12AffineFastState.Bounded env3581 := by
  intro p hp
  have h : env3581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3580_3581 : H12AffineEnvironment.transform 14 26424 env3580 = env3581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3580 == env3581) = true)

theorem identity3581 : scanCanonicalize (H12AffineFastState.compose env3581 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound3581 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3582 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26424,25750,1464,20157,1024,26424,1045,18109,445,18194,8329,444,19728,16385,16813,19509,16572,17681,256,17428,1212,512]

theorem envBound3582 : H12AffineFastState.Bounded env3582 := by
  intro p hp
  have h : env3582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3581_3582 : H12AffineEnvironment.transform 17 20157 env3581 = env3582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env3581 == env3582) = true)

theorem identity3582 : scanCanonicalize (H12AffineFastState.compose env3582 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound3582 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env3583 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,1841,8201,9127,1464,2444,1024,8201,1045,396,445,35,8329,444,2593,1840,1692,2820,1933,544,256,805,1212,512]

theorem envBound3583 : H12AffineFastState.Bounded env3583 := by
  intro p hp
  have h : env3583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3582_3583 : H12AffineEnvironment.transform 13 1841 env3582 = env3583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env3582 == env3583) = true)

theorem identity3583 : scanCanonicalize (H12AffineFastState.compose env3583 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3583 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env3584 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1693,8201,8715,1044,2080,1024,8201,1045,32,17,35,8329,16,2593,1692,1692,2728,1569,544,172,649,1212,512]

theorem envBound3584 : H12AffineFastState.Bounded env3584 := by
  intro p hp
  have h : env3584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3583_3584 : H12AffineEnvironment.transform 7 172 env3583 = env3584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3583 == env3584) = true)

theorem identity3584 : scanCanonicalize (H12AffineFastState.compose env3584 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3584 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3585 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1045,8192,1693,8201,8715,1044,1582,1024,8201,1045,32,17,35,8329,16,1071,1692,1692,1190,1569,544,172,649,1212,512]

theorem envBound3585 : H12AffineFastState.Bounded env3585 := by
  intro p hp
  have h : env3585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3584_3585 : H12AffineEnvironment.transform 10 1550 env3584 = env3585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3584 == env3585) = true)

theorem identity3585 : scanCanonicalize (H12AffineFastState.compose env3585 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1199) := by decide +kernel

theorem selectedBound3585 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env3586 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1045,1199,1693,1190,1700,1044,1582,1024,1190,1045,32,17,35,1062,16,1071,1692,1692,1190,1569,544,172,649,1212,512]

theorem envBound3586 : H12AffineFastState.Bounded env3586 := by
  intro p hp
  have h : env3586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3585_3586 : H12AffineEnvironment.transform 12 1199 env3585 = env3586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1199 env3585 == env3586) = true)

theorem identity3586 : scanCanonicalize (H12AffineFastState.compose env3586 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound3586 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env3587 : List Nat := [2,4,8,16,32,17,128,172,512,135,649,146,40,538,33,547,147,681,135,33,146,32,17,35,161,16,168,539,539,33,678,544,172,649,59,512]

theorem envBound3587 : H12AffineFastState.Bounded env3587 := by
  intro p hp
  have h : env3587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3586_3587 : H12AffineEnvironment.transform 9 135 env3586 = env3587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env3586 == env3587) = true)

theorem identity3587 : scanCanonicalize (H12AffineFastState.compose env3587 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3587 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3588 : List Nat := [2,4,8,10,32,11,128,172,512,135,649,136,40,512,33,547,137,681,135,33,136,32,11,35,161,10,168,513,513,33,678,544,172,649,33,512]

theorem envBound3588 : H12AffineFastState.Bounded env3588 := by
  intro p hp
  have h : env3588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3587_3588 : H12AffineEnvironment.transform 3 10 env3587 = env3588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3587 == env3588) = true)

def env3589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,12644668,257,20561,8479127,8389613]

theorem envBound3589 : H12AffineFastState.Bounded env3589 := by
  intro p hp
  have h : env3589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3515_3589 : H12AffineEnvironment.transform 18 1025 env3515 = env3589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3515 == env3589) = true)

theorem identity3589 : scanCanonicalize (H12AffineFastState.compose env3589 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255936) := by decide +kernel

theorem selectedBound3589 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,4255936,41002,8329,4255889,323792,16385,16892,22640,74795,508,257,20561,4297047,4256557]

theorem envBound3590 : H12AffineFastState.Bounded env3590 := by
  intro p hp
  have h : env3590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3589_3590 : H12AffineEnvironment.transform 22 4255936 env3589 = env3590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255936 env3589 == env3590) = true)

def env3591 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,4255888,41002,8329,4255889,323712,16385,16812,22560,74795,428,257,20481,4296967,4256557]

theorem envBound3591 : H12AffineFastState.Bounded env3591 := by
  intro p hp
  have h : env3591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3590_3591 : H12AffineEnvironment.transform 5 16 env3590 = env3591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3590 == env3591) = true)

theorem identity3591 : scanCanonicalize (H12AffineFastState.compose env3591 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61741) := by decide +kernel

theorem selectedBound3591 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3592 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61741,445,41002,8329,444,323712,16385,16812,22560,74795,428,257,20481,90154,512]

theorem envBound3592 : H12AffineFastState.Bounded env3592 := by
  intro p hp
  have h : env3592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3591_3592 : H12AffineEnvironment.transform 21 61741 env3591 = env3592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61741 env3591 == env3592) = true)

theorem identity3592 : scanCanonicalize (H12AffineFastState.compose env3592 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3592 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1025,32768,4096,41348,445,41002,8329,444,303145,4264,4357,2185,74795,428,257,168,77955,512]

theorem envBound3593 : H12AffineFastState.Bounded env3593 := by
  intro p hp
  have h : env3593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3592_3593 : H12AffineEnvironment.transform 13 4265 env3592 = env3593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3592 == env3593) = true)

theorem identity3593 : scanCanonicalize (H12AffineFastState.compose env3593 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3593 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3594 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,38843,4524,262144,1025,32768,4096,41348,445,41002,8329,444,303145,4264,4357,2185,45968,428,257,168,42808,512]

theorem envBound3594 : H12AffineFastState.Bounded env3594 := by
  intro p hp
  have h : env3594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3593_3594 : H12AffineEnvironment.transform 15 38843 env3593 = env3594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3593 == env3594) = true)

theorem identity3594 : scanCanonicalize (H12AffineFastState.compose env3594 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound3594 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3595 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8234,4524,262144,1025,14225,4096,5653,445,6075,8329,444,268216,4264,4357,2185,1025,428,257,168,4265,512]

theorem envBound3595 : H12AffineFastState.Bounded env3595 := by
  intro p hp
  have h : env3595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3594_3595 : H12AffineEnvironment.transform 14 14225 env3594 = env3595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env3594 == env3595) = true)

theorem identity3595 : scanCanonicalize (H12AffineFastState.compose env3595 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound3595 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3596 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8234,4524,2445,1025,14225,4096,5653,445,6075,8329,444,7733,4264,4357,2185,1025,428,257,168,4265,512]

theorem envBound3596 : H12AffineFastState.Bounded env3596 := by
  intro p hp
  have h : env3596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3595_3596 : H12AffineEnvironment.transform 17 2445 env3595 = env3596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env3595 == env3596) = true)

theorem identity3596 : scanCanonicalize (H12AffineFastState.compose env3596 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3596 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3597 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4265,13885,8234,4096,2081,1025,13885,4096,5653,17,5655,8329,16,7733,4264,4265,2185,1025,0,173,168,4265,512]

theorem envBound3597 : H12AffineFastState.Bounded env3597 := by
  intro p hp
  have h : env3597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3596_3597 : H12AffineEnvironment.transform 7 172 env3596 = env3597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3596 == env3597) = true)

theorem identity3597 : scanCanonicalize (H12AffineFastState.compose env3597 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound3597 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3598 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,4096,8192,4265,13885,8234,4096,643,1025,13885,4096,5653,17,5655,8329,16,5271,4264,4265,555,1025,0,173,168,4265,512]

theorem envBound3598 : H12AffineFastState.Bounded env3598 := by
  intro p hp
  have h : env3598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3597_3598 : H12AffineEnvironment.transform 10 674 env3597 = env3598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env3597 == env3598) = true)

theorem identity3598 : scanCanonicalize (H12AffineFastState.compose env3598 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3598 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3599 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,1692,8192,1589,8353,8234,1692,643,1025,8353,1692,137,17,139,8329,16,523,1588,1589,555,1025,0,173,168,1589,512]

theorem envBound3599 : H12AffineFastState.Bounded env3599 := by
  intro p hp
  have h : env3599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3598_3599 : H12AffineEnvironment.transform 11 1692 env3598 = env3599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env3598 == env3599) = true)

theorem identity3599 : scanCanonicalize (H12AffineFastState.compose env3599 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound3599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3600 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,1692,19,1589,178,57,1692,643,1025,178,1692,137,17,139,154,16,523,1588,1589,555,1025,0,173,168,1589,512]

theorem envBound3600 : H12AffineFastState.Bounded env3600 := by
  intro p hp
  have h : env3600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3599_3600 : H12AffineEnvironment.transform 12 19 env3599 = env3600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env3599 == env3600) = true)

theorem identity3600 : scanCanonicalize (H12AffineFastState.compose env3600 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3600 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3601 : List Nat := [2,4,8,16,32,16,41,5,512,1024,523,1589,19,1589,27,57,1589,554,1025,27,1589,32,17,34,51,16,523,1588,1589,555,1025,0,4,1,1589,512]

theorem envBound3601 : H12AffineFastState.Bounded env3601 := by
  intro p hp
  have h : env3601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3600_3601 : H12AffineEnvironment.transform 6 41 env3600 = env3601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3600 == env3601) = true)

theorem identity3601 : scanCanonicalize (H12AffineFastState.compose env3601 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound3601 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3602 : List Nat := [2,4,8,16,17,16,24,5,512,1024,523,1540,19,1540,27,8,1540,539,1025,27,1540,17,17,19,2,16,523,1541,1540,538,1025,0,4,1,1540,512]

theorem envBound3602 : H12AffineFastState.Bounded env3602 := by
  intro p hp
  have h : env3602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3601_3602 : H12AffineEnvironment.transform 4 17 env3601 = env3602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env3601 == env3602) = true)

theorem identity3602 : scanCanonicalize (H12AffineFastState.compose env3602 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3602 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3603 : List Nat := [2,4,2,16,17,16,18,5,512,1024,513,1540,19,1540,17,2,1540,529,1025,17,1540,17,17,19,2,16,513,1541,1540,528,1025,0,4,1,1540,512]

theorem envBound3603 : H12AffineFastState.Bounded env3603 := by
  intro p hp
  have h : env3603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3602_3603 : H12AffineEnvironment.transform 2 2 env3602 = env3603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3602 == env3603) = true)

theorem identity3603 : scanCanonicalize (H12AffineFastState.compose env3603 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3603 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3604 : List Nat := [2,4,2,0,1,0,2,5,512,1024,513,1540,3,1540,1,2,1540,513,1025,1,1540,1,1,3,2,0,513,1541,1540,512,1025,0,4,1,1540,512]

theorem envBound3604 : H12AffineFastState.Bounded env3604 := by
  intro p hp
  have h : env3604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3603_3604 : H12AffineEnvironment.transform 3 0 env3603 = env3604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3603 == env3604) = true)

theorem identity3604 : scanCanonicalize (H12AffineFastState.compose env3604 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3605 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,3,1029,1,2,1029,0,1025,1,1029,1,1,3,2,0,0,1028,1029,1,1025,0,4,1,1029,1]

theorem envBound3605 : H12AffineFastState.Bounded env3605 := by
  intro p hp
  have h : env3605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3604_3605 : H12AffineEnvironment.transform 8 1 env3604 = env3605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3604 == env3605) = true)

def leafEnv3605 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,3,1029,1,2,1029,0,1025,1,1029,1,1,3,1024,2,1,0,0,1028,1029,1,1025,0,4,1,5,2,1029,1,1,1028,0]

def active3605 : List Nat := [0,1,9]

def tree3605 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3605 : H12WitnessSearch.Good tree3605 := H12GlobalWitnessIndex.good

theorem leafIdentity3605 : H12AffineFastState.composeSystem env3605 rootObs = leafEnv3605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3605 rootObs == leafEnv3605) = true)

theorem terminalChecked3605 : H12PackedTerminal.terminalCheckFast leafEnv3605 active3605 tree3605 = true := by decide +kernel

def env3606 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,4255889,41002,8329,4255889,323713,16385,16813,22561,74795,429,257,20480,4296966,4256557]

theorem envBound3606 : H12AffineFastState.Bounded env3606 := by
  intro p hp
  have h : env3606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3590_3606 : H12AffineEnvironment.transform 5 17 env3590 = env3606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3590 == env3606) = true)

def env3607 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4096,4194304,4255889,41002,8329,4255889,323713,16385,16401,22561,74795,17,189,20480,4296890,4256401]

theorem envBound3607 : H12AffineFastState.Bounded env3607 := by
  intro p hp
  have h : env3607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3606_3607 : H12AffineEnvironment.transform 7 188 env3606 = env3607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3606 == env3607) = true)

theorem identity3607 : scanCanonicalize (H12AffineFastState.compose env3607 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 28832) := by decide +kernel

theorem selectedBound3607 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3608 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28832,65536,4113,262144,1025,28832,4096,4194304,4194353,20618,8329,4194353,262177,16385,16401,22561,74795,17,189,20480,4284442,4194865]

theorem envBound3608 : H12AffineFastState.Bounded env3608 := by
  intro p hp
  have h : env3608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3607_3608 : H12AffineEnvironment.transform 14 28832 env3607 = env3608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28832 env3607 == env3608) = true)

def env3609 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28832,65536,4113,262144,1025,28832,4096,20512,20497,20618,8329,20497,262177,16385,16401,22561,74795,17,189,20480,77882,21009]

theorem envBound3609 : H12AffineFastState.Bounded env3609 := by
  intro p hp
  have h : env3609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3608_3609 : H12AffineEnvironment.transform 21 20512 env3608 = env3609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20512 env3608 == env3609) = true)

theorem identity3609 : scanCanonicalize (H12AffineFastState.compose env3609 (packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3609 : packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3610 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,1677,13869,65536,4113,262144,1025,13869,4096,5805,5788,5639,8329,5788,262177,1676,1692,7852,74795,17,189,5773,77882,5276]

theorem envBound3610 : H12AffineFastState.Bounded env3610 := by
  intro p hp
  have h : env3610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3609_3610 : H12AffineEnvironment.transform 13 1677 env3609 = env3610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env3609 == env3610) = true)

theorem identity3610 : scanCanonicalize (H12AffineFastState.compose env3610 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound3610 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3611 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1589,13869,65536,4113,262144,1025,13869,4096,5653,5668,5639,8241,5668,262177,1588,1572,7700,74795,17,5,5685,77882,5156]

theorem envBound3611 : H12AffineFastState.Bounded env3611 := by
  intro p hp
  have h : env3611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3610_3611 : H12AffineEnvironment.transform 6 56 env3610 = env3611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3610 == env3611) = true)

theorem identity3611 : scanCanonicalize (H12AffineFastState.compose env3611 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13838) := by decide +kernel

theorem selectedBound3611 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3612 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1589,13869,13838,4113,262144,1025,13869,4096,5653,5668,5639,8241,5668,262177,1588,1572,7700,4645,17,5,5685,1588,5156]

theorem envBound3612 : H12AffineFastState.Bounded env3612 := by
  intro p hp
  have h : env3612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3611_3612 : H12AffineEnvironment.transform 15 13838 env3611 = env3612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13838 env3611 == env3612) = true)

theorem identity3612 : scanCanonicalize (H12AffineFastState.compose env3612 (packedSelected [1,2,5,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 15398) := by decide +kernel

theorem selectedBound3612 : packedSelected [1,2,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3613 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,8192,1589,13869,13838,4113,15398,1025,13869,4096,5653,5668,5639,8241,5668,15367,1588,1572,7700,4645,17,5,5685,1588,5156]

theorem envBound3613 : H12AffineFastState.Bounded env3613 := by
  intro p hp
  have h : env3613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3612_3613 : H12AffineEnvironment.transform 17 15398 env3612 = env3613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 15398 env3612 == env3613) = true)

theorem identity3613 : scanCanonicalize (H12AffineFastState.compose env3613 (packedSelected [1,2,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound3613 : packedSelected [1,2,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env3614 : List Nat := [2,4,8,16,32,17,56,4,512,1024,2048,4096,563,1589,5150,5181,4113,7701,1025,5150,4096,5653,5668,5639,514,5668,7732,1588,1572,7700,4645,17,5,5685,1588,5156]

theorem envBound3614 : H12AffineFastState.Bounded env3614 := by
  intro p hp
  have h : env3614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3613_3614 : H12AffineEnvironment.transform 12 563 env3613 = env3614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env3613 == env3614) = true)

def env3615 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28832,65536,4113,262144,1025,28832,4096,20513,20496,20618,8329,20496,262177,16385,16401,22561,74795,17,189,20480,77883,21008]

theorem envBound3615 : H12AffineFastState.Bounded env3615 := by
  intro p hp
  have h : env3615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3608_3615 : H12AffineEnvironment.transform 21 20513 env3608 = env3615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20513 env3608 == env3615) = true)

theorem identity3615 : scanCanonicalize (H12AffineFastState.compose env3615 (packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 26142) := by decide +kernel

theorem selectedBound3615 : packedSelected [0,2,3,5,7,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3616 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,28832,26142,4113,262144,1025,28832,4096,20513,20496,20618,8329,20496,262177,16385,16401,22561,16949,17,189,20480,22053,21008]

theorem envBound3616 : H12AffineFastState.Bounded env3616 := by
  intro p hp
  have h : env3616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3615_3616 : H12AffineEnvironment.transform 15 26142 env3615 = env3616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26142 env3615 == env3616) = true)

theorem identity3616 : scanCanonicalize (H12AffineFastState.compose env3616 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3616 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3617 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4265,8201,14007,4113,262144,1025,8201,4096,136,185,35,8329,185,262177,4264,4280,2184,4764,17,189,169,1676,697]

theorem envBound3617 : H12AffineFastState.Bounded env3617 := by
  intro p hp
  have h : env3617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3616_3617 : H12AffineEnvironment.transform 13 4265 env3616 = env3617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3616 == env3617) = true)

theorem identity3617 : scanCanonicalize (H12AffineFastState.compose env3617 (packedSelected [0,2,3,5,7,10,11,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound3617 : packedSelected [0,2,3,5,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env3618 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,4265,8201,14007,4113,7701,1025,8201,4096,136,185,35,8329,185,7732,4264,4280,2184,4764,17,189,169,1676,697]

theorem envBound3618 : H12AffineFastState.Bounded env3618 := by
  intro p hp
  have h : env3618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3617_3618 : H12AffineEnvironment.transform 17 7701 env3617 = env3618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env3617 == env3618) = true)

theorem identity3618 : scanCanonicalize (H12AffineFastState.compose env3618 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound3618 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env3619 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1572,8192,1677,8201,8339,1589,2097,1025,8201,1572,136,185,35,8329,185,2064,1676,1692,2184,1208,17,189,169,1676,697]

theorem envBound3619 : H12AffineFastState.Bounded env3619 := by
  intro p hp
  have h : env3619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3618_3619 : H12AffineEnvironment.transform 11 1572 env3618 = env3619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env3618 == env3619) = true)

theorem identity3619 : scanCanonicalize (H12AffineFastState.compose env3619 (packedSelected [6,13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3619 : packedSelected [6,13] rootPS < 2^1333 := by decide +kernel

def env3620 : List Nat := [2,4,8,16,32,17,34,30,512,1024,2048,1572,8192,1583,8201,8241,1589,2097,1025,8201,1572,42,27,35,8235,27,2064,1582,1598,2090,1050,17,31,11,1582,539]

theorem envBound3620 : H12AffineFastState.Bounded env3620 := by
  intro p hp
  have h : env3620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3619_3620 : H12AffineEnvironment.transform 6 34 env3619 = env3620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3619 == env3620) = true)

theorem identity3620 : scanCanonicalize (H12AffineFastState.compose env3620 (packedSelected [8,10,28] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3620 : packedSelected [8,10,28] rootPS < 2^1333 := by decide +kernel

def env3621 : List Nat := [2,4,8,1,32,0,34,15,512,1024,2048,1572,8192,1583,8201,8224,1572,2080,1025,8201,1572,42,10,35,8235,10,2049,1582,1583,2090,1035,0,14,11,1582,522]

theorem envBound3621 : H12AffineFastState.Bounded env3621 := by
  intro p hp
  have h : env3621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3620_3621 : H12AffineEnvironment.transform 3 1 env3620 = env3621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3620 == env3621) = true)

theorem identity3621 : scanCanonicalize (H12AffineFastState.compose env3621 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2595) := by decide +kernel

theorem selectedBound3621 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env3622 : List Nat := [2,4,8,1,32,0,34,15,512,1024,2048,1572,2595,1583,2602,2563,1572,2080,1025,2602,1572,42,10,35,2568,10,2049,1582,1583,2090,1035,0,14,11,1582,522]

theorem envBound3622 : H12AffineFastState.Bounded env3622 := by
  intro p hp
  have h : env3622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3621_3622 : H12AffineEnvironment.transform 12 2595 env3621 = env3622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2595 env3621 == env3622) = true)

def env3623 : List Nat := [2,4,8,1,32,0,34,15,512,1024,1540,1572,1063,1583,1070,1031,1572,1572,1025,1070,1572,42,10,35,1036,10,1541,1582,1583,1582,1035,0,14,11,1582,522]

theorem envBound3623 : H12AffineFastState.Bounded env3623 := by
  intro p hp
  have h : env3623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3622_3623 : H12AffineEnvironment.transform 10 1540 env3622 = env3623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env3622 == env3623) = true)

def env3624 : List Nat := [2,4,8,1,32,0,34,15,32,1024,1060,1028,1063,1039,1070,1031,1028,1028,1025,1070,1028,42,10,35,1036,10,1061,1038,1039,1038,1035,0,14,11,1038,42]

theorem envBound3624 : H12AffineFastState.Bounded env3624 := by
  intro p hp
  have h : env3624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3623_3624 : H12AffineEnvironment.transform 8 32 env3623 = env3624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env3623 == env3624) = true)

theorem identity3624 : scanCanonicalize (H12AffineFastState.compose env3624 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound3624 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3625 : List Nat := [2,4,8,1,32,0,34,15,32,47,11,43,8,32,1,40,43,43,46,1,43,42,10,35,35,10,10,33,32,33,36,0,14,11,33,42]

theorem envBound3625 : H12AffineFastState.Bounded env3625 := by
  intro p hp
  have h : env3625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3624_3625 : H12AffineEnvironment.transform 9 47 env3624 = env3625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env3624 == env3625) = true)

theorem identity3625 : scanCanonicalize (H12AffineFastState.compose env3625 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3625 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3626 : List Nat := [2,4,8,1,11,0,9,15,11,4,11,0,8,11,1,3,0,0,5,1,0,1,10,8,8,10,10,10,11,10,15,0,14,11,10,1]

theorem envBound3626 : H12AffineFastState.Bounded env3626 := by
  intro p hp
  have h : env3626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3625_3626 : H12AffineEnvironment.transform 4 11 env3625 = env3626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3625 == env3626) = true)

def env3627 : List Nat := [2,0,8,1,11,0,9,11,11,0,11,0,8,11,1,3,0,0,1,1,0,1,10,8,8,10,10,10,11,10,11,0,10,11,10,1]

theorem envBound3627 : H12AffineFastState.Bounded env3627 := by
  intro p hp
  have h : env3627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3626_3627 : H12AffineEnvironment.transform 1 0 env3626 = env3627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3626 == env3627) = true)

def leafEnv3627 : List Nat := [2,0,8,1,11,0,9,11,11,0,11,0,8,11,1,3,0,0,1,1,0,1,10,8,10,8,1,10,10,10,11,10,11,0,10,11,1,8,10,1,1,10,0]

def active3627 : List Nat := [0,2]

def tree3627 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3627 : H12WitnessSearch.Good tree3627 := H12GlobalWitnessIndex.good

theorem leafIdentity3627 : H12AffineFastState.composeSystem env3627 rootObs = leafEnv3627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3627 rootObs == leafEnv3627) = true)

theorem terminalChecked3627 : H12PackedTerminal.terminalCheckFast leafEnv3627 active3627 tree3627 = true := by decide +kernel

def env3628 : List Nat := [2,1,8,1,11,0,9,10,11,1,11,0,8,11,1,3,0,0,0,1,0,1,10,8,8,10,10,10,11,10,10,0,11,11,10,1]

theorem envBound3628 : H12AffineFastState.Bounded env3628 := by
  intro p hp
  have h : env3628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3626_3628 : H12AffineEnvironment.transform 1 1 env3626 = env3628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3626 == env3628) = true)

theorem identity3628 : scanCanonicalize (H12AffineFastState.compose env3628 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3629 : List Nat := [2,1,2,1,1,0,3,0,1,1,1,0,2,1,1,3,0,0,0,1,0,1,0,2,2,0,0,0,1,0,0,0,1,1,0,1]

theorem envBound3629 : H12AffineFastState.Bounded env3629 := by
  intro p hp
  have h : env3629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3628_3629 : H12AffineEnvironment.transform 2 2 env3628 = env3629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3628 == env3629) = true)

def leafEnv3629 : List Nat := [2,1,2,1,1,0,3,0,1,1,1,0,2,1,1,3,0,0,0,1,0,1,0,2,1,2,1,0,0,0,1,0,0,0,1,1,0,2,0,1,1,0,0]

def active3629 : List Nat := [0]

def tree3629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3629 : H12WitnessSearch.Good tree3629 := H12GlobalWitnessIndex.good

theorem leafIdentity3629 : H12AffineFastState.composeSystem env3629 rootObs = leafEnv3629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3629 rootObs == leafEnv3629) = true)

theorem terminalChecked3629 : H12PackedTerminal.terminalCheckFast leafEnv3629 active3629 tree3629 = true := by decide +kernel

def env3630 : List Nat := [2,4,8,1,32,0,34,15,33,1024,1061,1029,1063,1038,1070,1031,1029,1029,1025,1070,1029,42,10,35,1036,10,1060,1039,1038,1039,1035,0,14,11,1039,43]

theorem envBound3630 : H12AffineFastState.Bounded env3630 := by
  intro p hp
  have h : env3630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3623_3630 : H12AffineEnvironment.transform 8 33 env3623 = env3630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3623 == env3630) = true)

theorem identity3630 : scanCanonicalize (H12AffineFastState.compose env3630 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3630 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3631 : List Nat := [2,4,8,1,32,0,34,15,33,5,32,0,34,11,43,2,0,0,4,43,0,42,10,35,9,10,33,10,11,10,14,0,14,11,10,43]

theorem envBound3631 : H12AffineFastState.Bounded env3631 := by
  intro p hp
  have h : env3631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3630_3631 : H12AffineEnvironment.transform 9 5 env3630 = env3631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3630 == env3631) = true)

theorem identity3631 : scanCanonicalize (H12AffineFastState.compose env3631 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3631 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env3632 : List Nat := [2,4,3,1,32,0,34,4,33,5,32,0,34,0,32,2,0,0,4,32,0,33,1,35,2,1,33,1,0,1,5,0,5,0,1,32]

theorem envBound3632 : H12AffineFastState.Bounded env3632 := by
  intro p hp
  have h : env3632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3631_3632 : H12AffineEnvironment.transform 2 3 env3631 = env3632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3631 == env3632) = true)

theorem identity3632 : scanCanonicalize (H12AffineFastState.compose env3632 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3633 : List Nat := [2,0,3,1,32,0,34,0,33,1,32,0,34,0,32,2,0,0,0,32,0,33,1,35,2,1,33,1,0,1,1,0,1,0,1,32]

theorem envBound3633 : H12AffineFastState.Bounded env3633 := by
  intro p hp
  have h : env3633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3632_3633 : H12AffineEnvironment.transform 1 0 env3632 = env3633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3632 == env3633) = true)

theorem identity3633 : scanCanonicalize (H12AffineFastState.compose env3633 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3633 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3634 : List Nat := [2,0,3,1,1,0,3,0,0,1,1,0,3,0,1,2,0,0,0,1,0,0,1,2,2,1,0,1,0,1,1,0,1,0,1,1]

theorem envBound3634 : H12AffineFastState.Bounded env3634 := by
  intro p hp
  have h : env3634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3633_3634 : H12AffineEnvironment.transform 4 1 env3633 = env3634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3633 == env3634) = true)

def leafEnv3634 : List Nat := [2,0,3,1,1,0,3,0,0,1,1,0,3,0,1,2,0,0,0,1,0,0,1,2,0,2,1,1,0,1,0,1,1,0,1,0,1,3,1,1,1,1,0]

def active3634 : List Nat := [0]

def tree3634 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3634 : H12WitnessSearch.Good tree3634 := H12GlobalWitnessIndex.good

theorem leafIdentity3634 : H12AffineFastState.composeSystem env3634 rootObs = leafEnv3634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3634 rootObs == leafEnv3634) = true)

theorem terminalChecked3634 : H12PackedTerminal.terminalCheckFast leafEnv3634 active3634 tree3634 = true := by decide +kernel

def env3635 : List Nat := [2,4,8,1,32,0,34,15,512,1024,1541,1572,1062,1583,1071,1030,1572,1573,1025,1071,1572,42,10,35,1037,10,1540,1582,1583,1583,1035,0,14,11,1582,522]

theorem envBound3635 : H12AffineFastState.Bounded env3635 := by
  intro p hp
  have h : env3635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3622_3635 : H12AffineEnvironment.transform 10 1541 env3622 = env3635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env3622 == env3635) = true)

theorem identity3635 : scanCanonicalize (H12AffineFastState.compose env3635 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3636 : List Nat := [2,4,2,1,32,0,34,5,512,1024,1541,1572,1062,1573,1061,1030,1572,1573,1025,1061,1572,32,0,35,1031,0,1540,1572,1573,1573,1025,0,4,1,1572,512]

theorem envBound3636 : H12AffineFastState.Bounded env3636 := by
  intro p hp
  have h : env3636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3635_3636 : H12AffineEnvironment.transform 2 2 env3635 = env3636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3635 == env3636) = true)

theorem identity3636 : scanCanonicalize (H12AffineFastState.compose env3636 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3636 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3637 : List Nat := [2,4,2,1,1,0,3,5,512,1024,1541,1541,1031,1540,1028,1030,1541,1540,1025,1028,1541,1,0,2,1031,0,1540,1541,1540,1540,1025,0,4,1,1541,512]

theorem envBound3637 : H12AffineFastState.Bounded env3637 := by
  intro p hp
  have h : env3637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3636_3637 : H12AffineEnvironment.transform 4 1 env3636 = env3637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3636 == env3637) = true)

theorem identity3637 : scanCanonicalize (H12AffineFastState.compose env3637 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3638 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1028,1028,1031,1029,1028,1030,1028,1029,1025,1028,1028,1,0,2,1031,0,1029,1028,1029,1029,1025,0,4,1,1028,1]

theorem envBound3638 : H12AffineFastState.Bounded env3638 := by
  intro p hp
  have h : env3638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3637_3638 : H12AffineEnvironment.transform 8 1 env3637 = env3638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3637 == env3638) = true)

theorem identity3638 : scanCanonicalize (H12AffineFastState.compose env3638 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3638 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3639 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,1,2,0,1,3,1,0,4,1,1,1,0,2,2,0,0,1,0,0,4,0,4,1,1,1]

theorem envBound3639 : H12AffineFastState.Bounded env3639 := by
  intro p hp
  have h : env3639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3638_3639 : H12AffineEnvironment.transform 9 5 env3638 = env3639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3638 == env3639) = true)

def leafEnv3639 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,1,2,0,1,3,1,0,4,1,1,1,0,2,5,2,1,0,0,1,0,0,4,0,4,1,5,2,1,1,1,1,0]

def active3639 : List Nat := [0,1]

def tree3639 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3639 : H12WitnessSearch.Good tree3639 := H12GlobalWitnessIndex.good

theorem leafIdentity3639 : H12AffineFastState.composeSystem env3639 rootObs = leafEnv3639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3639 rootObs == leafEnv3639) = true)

theorem terminalChecked3639 : H12PackedTerminal.terminalCheckFast leafEnv3639 active3639 tree3639 = true := by decide +kernel

def env3640 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4096,4194304,4255889,41002,8329,4255889,323713,16385,16400,22561,74795,16,188,20480,4296891,4256400]

theorem envBound3640 : H12AffineFastState.Bounded env3640 := by
  intro p hp
  have h : env3640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3606_3640 : H12AffineEnvironment.transform 7 189 env3606 = env3640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3606 == env3640) = true)

theorem identity3640 : scanCanonicalize (H12AffineFastState.compose env3640 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound3640 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3641 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53403,4112,262144,1025,32768,4096,4194304,4255889,41002,8329,4255889,323713,16385,16400,22561,62640,16,188,20480,4210720,4256400]

theorem envBound3641 : H12AffineFastState.Bounded env3641 := by
  intro p hp
  have h : env3641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3640_3641 : H12AffineEnvironment.transform 15 53403 env3640 = env3641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env3640 == env3641) = true)

def env3642 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,32768,32923,4112,262144,1025,32768,4096,4194304,4235409,41002,8329,4235409,303233,4097,4112,2081,42160,16,188,0,4198432,4235920]

theorem envBound3642 : H12AffineFastState.Bounded env3642 := by
  intro p hp
  have h : env3642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3641_3642 : H12AffineEnvironment.transform 13 4096 env3641 = env3642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3641 == env3642) = true)

theorem identity3642 : scanCanonicalize (H12AffineFastState.compose env3642 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8369) := by decide +kernel

theorem selectedBound3642 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3643 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8369,8234,4112,262144,1025,8369,4096,4194304,4194336,155,8329,4194336,262192,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3643 : H12AffineFastState.Bounded env3643 := by
  intro p hp
  have h : env3643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3642_3643 : H12AffineEnvironment.transform 14 8369 env3642 = env3643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8369 env3642 == env3643) = true)

theorem identity3643 : scanCanonicalize (H12AffineFastState.compose env3643 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2096) := by decide +kernel

theorem selectedBound3643 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3644 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4096,8369,8234,4112,2096,1025,8369,4096,4194304,4194336,155,8329,4194336,2048,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3644 : H12AffineFastState.Bounded env3644 := by
  intro p hp
  have h : env3644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3643_3644 : H12AffineEnvironment.transform 17 2096 env3643 = env3644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2096 env3643 == env3644) = true)

theorem identity3644 : scanCanonicalize (H12AffineFastState.compose env3644 (packedSelected [1,3,4,5,7,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2578) := by decide +kernel

theorem selectedBound3644 : packedSelected [1,3,4,5,7,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env3645 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,2578,4096,2723,2616,4112,2096,1025,2723,4096,4194304,4194336,155,2715,4194336,2048,4097,4112,2081,1025,16,188,0,4198432,4194849]

theorem envBound3645 : H12AffineFastState.Bounded env3645 := by
  intro p hp
  have h : env3645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3644_3645 : H12AffineEnvironment.transform 12 2578 env3644 = env3645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2578 env3644 == env3645) = true)

theorem identity3645 : scanCanonicalize (H12AffineFastState.compose env3645 (packedSelected [4,9,20] rootPS)) = affineNative (2^(21+1) ^^^ 153) := by decide +kernel

theorem selectedBound3645 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3646 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,2578,4096,2723,2616,4112,2096,1025,2723,4096,153,185,155,2715,185,2048,4097,4112,2081,1025,16,188,0,4281,696]

theorem envBound3646 : H12AffineFastState.Bounded env3646 := by
  intro p hp
  have h : env3646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3645_3646 : H12AffineEnvironment.transform 21 153 env3645 = env3646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 153 env3645 == env3646) = true)

theorem identity3646 : scanCanonicalize (H12AffineFastState.compose env3646 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3646 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3647 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1588,2578,1588,2723,2616,1572,2096,1025,2723,1588,153,185,155,2715,185,2048,1589,1572,2081,1025,16,188,0,1677,696]

theorem envBound3647 : H12AffineFastState.Bounded env3647 := by
  intro p hp
  have h : env3647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3646_3647 : H12AffineEnvironment.transform 11 1588 env3646 = env3647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3646 == env3647) = true)

theorem identity3647 : scanCanonicalize (H12AffineFastState.compose env3647 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound3647 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3648 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1588,2578,1588,2587,2616,1572,2096,1025,2587,1588,33,1,35,2595,1,2048,1589,1572,2081,1025,16,4,0,1589,512]

theorem envBound3648 : H12AffineFastState.Bounded env3648 := by
  intro p hp
  have h : env3648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3647_3648 : H12AffineEnvironment.transform 6 56 env3647 = env3648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3647 == env3648) = true)

theorem identity3648 : scanCanonicalize (H12AffineFastState.compose env3648 (packedSelected [1,2,3,4,6,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3648 : packedSelected [1,2,3,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env3649 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1572,2562,1572,2571,2600,1572,2080,1025,2571,1572,33,1,35,2595,1,2048,1573,1572,2081,1025,0,4,0,1573,512]

theorem envBound3649 : H12AffineFastState.Bounded env3649 := by
  intro p hp
  have h : env3649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3648_3649 : H12AffineEnvironment.transform 3 0 env3648 = env3649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3648 == env3649) = true)

theorem identity3649 : scanCanonicalize (H12AffineFastState.compose env3649 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3650 : List Nat := [2,4,2,0,32,1,34,5,512,1024,2048,1572,2562,1572,2561,2594,1572,2080,1025,2561,1572,33,1,35,2595,1,2048,1573,1572,2081,1025,0,4,0,1573,512]

theorem envBound3650 : H12AffineFastState.Bounded env3650 := by
  intro p hp
  have h : env3650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3649_3650 : H12AffineEnvironment.transform 2 2 env3649 = env3650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3649 == env3650) = true)

theorem identity3650 : scanCanonicalize (H12AffineFastState.compose env3650 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound3650 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3651 : List Nat := [2,4,2,0,32,1,34,5,512,1024,512,1572,2,1572,1,34,1572,544,1025,1,1572,33,1,35,35,1,512,1573,1572,545,1025,0,4,0,1573,512]

theorem envBound3651 : H12AffineFastState.Bounded env3651 := by
  intro p hp
  have h : env3651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3650_3651 : H12AffineEnvironment.transform 10 512 env3650 = env3651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env3650 == env3651) = true)

theorem identity3651 : scanCanonicalize (H12AffineFastState.compose env3651 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3651 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3652 : List Nat := [2,4,2,0,32,1,34,5,1,1024,1,1061,2,1061,1,34,1061,33,1025,1,1061,33,1,35,35,1,1,1060,1061,32,1025,0,4,0,1060,1]

theorem envBound3652 : H12AffineFastState.Bounded env3652 := by
  intro p hp
  have h : env3652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3651_3652 : H12AffineEnvironment.transform 8 1 env3651 = env3652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3651 == env3652) = true)

theorem identity3652 : scanCanonicalize (H12AffineFastState.compose env3652 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3653 : List Nat := [2,4,2,0,0,1,2,5,1,1024,1,1029,2,1029,1,2,1029,1,1025,1,1029,1,1,3,3,1,1,1028,1029,0,1025,0,4,0,1028,1]

theorem envBound3653 : H12AffineFastState.Bounded env3653 := by
  intro p hp
  have h : env3653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3652_3653 : H12AffineEnvironment.transform 4 0 env3652 = env3653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3652 == env3653) = true)

def env3654 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,4097,32768,32922,4112,262144,1025,32768,4096,4194304,4235408,41002,8329,4235408,303232,4096,4113,2080,42161,16,188,1,4198433,4235921]

theorem envBound3654 : H12AffineFastState.Bounded env3654 := by
  intro p hp
  have h : env3654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3641_3654 : H12AffineEnvironment.transform 13 4097 env3641 = env3654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3641 == env3654) = true)

theorem identity3654 : scanCanonicalize (H12AffineFastState.compose env3654 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3654 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3655 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32907,4097,262144,1025,32768,4096,4194304,4235393,41002,8329,4235393,303232,4096,4096,2080,42144,1,173,1,4198433,4235904]

theorem envBound3655 : H12AffineFastState.Bounded env3655 := by
  intro p hp
  have h : env3655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3654_3655 : H12AffineEnvironment.transform 3 1 env3654 = env3655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3654 == env3655) = true)

theorem identity3655 : scanCanonicalize (H12AffineFastState.compose env3655 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 264192) := by decide +kernel

theorem selectedBound3655 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3656 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32907,4097,262144,1025,32768,4096,264192,305281,41002,8329,305281,303232,4096,4096,2080,42144,1,173,1,268321,305792]

theorem envBound3656 : H12AffineFastState.Bounded env3656 := by
  intro p hp
  have h : env3656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3655_3656 : H12AffineEnvironment.transform 21 264192 env3655 = env3656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264192 env3655 == env3656) = true)

theorem identity3656 : scanCanonicalize (H12AffineFastState.compose env3656 (packedSelected [4,9,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound3656 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3657 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,4097,32768,32907,4097,43049,1025,32768,4096,41001,168,41002,8329,168,2217,4096,4096,2080,42144,1,173,1,45064,681]

theorem envBound3657 : H12AffineFastState.Bounded env3657 := by
  intro p hp
  have h : env3657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3656_3657 : H12AffineEnvironment.transform 17 43049 env3656 = env3657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env3656 == env3657) = true)

theorem identity3657 : scanCanonicalize (H12AffineFastState.compose env3657 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3657 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3658 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1573,8192,1572,32768,32907,1572,43049,1025,32768,1573,41001,168,41002,8329,168,2217,1573,1573,2080,42144,1,173,1,42541,681]

theorem envBound3658 : H12AffineFastState.Bounded env3658 := by
  intro p hp
  have h : env3658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3657_3658 : H12AffineEnvironment.transform 11 1573 env3657 = env3658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env3657 == env3658) = true)

theorem identity3658 : scanCanonicalize (H12AffineFastState.compose env3658 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound3658 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3659 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1573,8192,1572,1540,1679,1572,11821,1025,1540,1573,9773,168,9774,8329,168,2217,1573,1573,2080,8868,1,173,1,8233,681]

theorem envBound3659 : H12AffineFastState.Bounded env3659 := by
  intro p hp
  have h : env3659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3658_3659 : H12AffineEnvironment.transform 14 1540 env3658 = env3659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env3658 == env3659) = true)

theorem identity3659 : scanCanonicalize (H12AffineFastState.compose env3659 (packedSelected [2,6,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound3659 : packedSelected [2,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env3660 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1573,9,1572,1540,1679,1572,3620,1025,1540,1573,1572,168,1575,128,168,2217,1573,1573,2080,685,1,173,1,32,681]

theorem envBound3660 : H12AffineFastState.Bounded env3660 := by
  intro p hp
  have h : env3660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3659_3660 : H12AffineEnvironment.transform 12 9 env3659 = env3660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env3659 == env3660) = true)

theorem identity3660 : scanCanonicalize (H12AffineFastState.compose env3660 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound3660 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env3661 : List Nat := [2,4,8,1,32,0,2,46,512,1024,2048,1573,9,1572,1540,1549,1572,3620,1025,1540,1573,1572,42,1575,2,42,2091,1573,1573,2080,559,1,47,1,32,555]

theorem envBound3661 : H12AffineFastState.Bounded env3661 := by
  intro p hp
  have h : env3661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3660_3661 : H12AffineEnvironment.transform 6 2 env3660 = env3661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env3660 == env3661) = true)

theorem identity3661 : scanCanonicalize (H12AffineFastState.compose env3661 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound3661 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3662 : List Nat := [2,4,8,1,32,0,2,46,512,517,2048,32,9,33,1,8,33,2081,516,1,32,33,42,34,2,42,2091,32,32,2080,559,1,47,1,32,555]

theorem envBound3662 : H12AffineFastState.Bounded env3662 := by
  intro p hp
  have h : env3662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3661_3662 : H12AffineEnvironment.transform 9 517 env3661 = env3662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env3661 == env3662) = true)

theorem identity3662 : scanCanonicalize (H12AffineFastState.compose env3662 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound3662 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env3663 : List Nat := [2,4,8,1,32,0,2,46,512,517,0,32,9,33,1,8,33,33,516,1,32,33,42,34,2,42,43,32,32,32,559,1,47,1,32,555]

theorem envBound3663 : H12AffineFastState.Bounded env3663 := by
  intro p hp
  have h : env3663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3662_3663 : H12AffineEnvironment.transform 10 0 env3662 = env3663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env3662 == env3663) = true)

theorem identity3663 : scanCanonicalize (H12AffineFastState.compose env3663 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3663 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3664 : List Nat := [2,4,8,1,32,0,2,46,1,4,0,32,9,33,1,8,33,33,5,1,32,33,42,34,2,42,43,32,32,32,46,1,47,1,32,42]

theorem envBound3664 : H12AffineFastState.Bounded env3664 := by
  intro p hp
  have h : env3664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3663_3664 : H12AffineEnvironment.transform 8 1 env3663 = env3664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3663 == env3664) = true)

theorem identity3664 : scanCanonicalize (H12AffineFastState.compose env3664 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3665 : List Nat := [2,4,3,1,32,0,2,37,1,4,0,32,2,33,1,3,33,33,5,1,32,33,33,34,2,33,32,32,32,32,37,1,36,1,32,33]

theorem envBound3665 : H12AffineFastState.Bounded env3665 := by
  intro p hp
  have h : env3665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3664_3665 : H12AffineEnvironment.transform 2 3 env3664 = env3665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3664 == env3665) = true)

def env3666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849105,268435456,268435965,547953,598059,12644668,525568,545872,8479127,8914924]

theorem envBound3666 : H12AffineFastState.Bounded env3666 := by
  intro p hp
  have h : env3666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3415_3666 : H12AffineEnvironment.transform 20 4097 env3415 = env3666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env3415 == env3666) = true)

def env3667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849105,16384,16893,547953,598059,12644668,525568,545872,8479127,8914924]

theorem envBound3667 : H12AffineFastState.Bounded env3667 := by
  intro p hp
  have h : env3667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3666_3667 : H12AffineEnvironment.transform 27 16384 env3666 = env3667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3666 == env3667) = true)

def env3668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323793,16384,16893,22641,74795,12644668,256,20560,8479127,8389612]

theorem envBound3668 : H12AffineFastState.Bounded env3668 := by
  intro p hp
  have h : env3668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3667_3668 : H12AffineEnvironment.transform 18 1024 env3667 = env3668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3667 == env3668) = true)

theorem identity3668 : scanCanonicalize (H12AffineFastState.compose env3668 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound3668 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4265,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,303224,4265,4436,2264,74795,12624277,256,249,8466750,8389612]

theorem envBound3669 : H12AffineFastState.Bounded env3669 := by
  intro p hp
  have h : env3669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3668_3669 : H12AffineEnvironment.transform 13 4265 env3668 = env3669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env3668 == env3669) = true)

def env3670 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,8388608,41002,8329,8388609,303144,4265,4356,2184,74795,12624277,256,169,8466750,8389564]

theorem envBound3670 : H12AffineFastState.Bounded env3670 := by
  intro p hp
  have h : env3670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3669_3670 : H12AffineEnvironment.transform 5 16 env3669 = env3670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3669 == env3670) = true)

theorem identity3670 : scanCanonicalize (H12AffineFastState.compose env3670 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3670 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,444,41002,8329,445,303144,4265,4356,2184,74795,4235305,256,169,77954,512]

theorem envBound3671 : H12AffineFastState.Bounded env3671 := by
  intro p hp
  have h : env3671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3670_3671 : H12AffineEnvironment.transform 22 444 env3670 = env3671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3670 == env3671) = true)

theorem identity3671 : scanCanonicalize (H12AffineFastState.compose env3671 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3671 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,41348,444,41002,8329,445,303144,4265,4356,2184,74795,429,256,169,77954,512]

theorem envBound3672 : H12AffineFastState.Bounded env3672 := by
  intro p hp
  have h : env3672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3671_3672 : H12AffineEnvironment.transform 21 41348 env3671 = env3672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3671 == env3672) = true)

theorem identity3672 : scanCanonicalize (H12AffineFastState.compose env3672 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3672 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3673 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,38842,4524,262144,1024,32768,4097,41348,444,41002,8329,445,303144,4265,4356,2184,45969,429,256,169,42808,512]

theorem envBound3673 : H12AffineFastState.Bounded env3673 := by
  intro p hp
  have h : env3673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3672_3673 : H12AffineEnvironment.transform 15 38842 env3672 = env3673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3672 == env3673) = true)

theorem identity3673 : scanCanonicalize (H12AffineFastState.compose env3673 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound3673 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3674 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8235,4524,262144,1024,14225,4097,5653,444,6075,8329,445,268217,4265,4356,2184,1024,429,256,169,4265,512]

theorem envBound3674 : H12AffineFastState.Bounded env3674 := by
  intro p hp
  have h : env3674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3673_3674 : H12AffineEnvironment.transform 14 14225 env3673 = env3674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env3673 == env3674) = true)

theorem identity3674 : scanCanonicalize (H12AffineFastState.compose env3674 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3674 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3675 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14225,8235,4524,2341,1024,14225,4097,5653,444,6075,8329,445,7836,4265,4356,2184,1024,429,256,169,4265,512]

theorem envBound3675 : H12AffineFastState.Bounded env3675 := by
  intro p hp
  have h : env3675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3674_3675 : H12AffineEnvironment.transform 17 2341 env3674 = env3675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3674 == env3675) = true)

theorem identity3675 : scanCanonicalize (H12AffineFastState.compose env3675 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound3675 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3676 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1944,8192,1841,8201,8235,1588,2341,1024,8201,1945,397,444,35,8329,445,2308,1841,1692,2184,1024,429,256,169,1841,512]

theorem envBound3676 : H12AffineFastState.Bounded env3676 := by
  intro p hp
  have h : env3676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3675_3676 : H12AffineEnvironment.transform 11 1944 env3675 = env3676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env3675 == env3676) = true)

theorem identity3676 : scanCanonicalize (H12AffineFastState.compose env3676 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3676 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3677 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1840,8192,1841,8201,8235,1588,2341,1024,8201,1841,293,276,35,8225,277,2308,1841,1588,2080,1024,261,256,1,1841,512]

theorem envBound3677 : H12AffineFastState.Bounded env3677 := by
  intro p hp
  have h : env3677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3676_3677 : H12AffineEnvironment.transform 6 40 env3676 = env3677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3676 == env3677) = true)

theorem identity3677 : scanCanonicalize (H12AffineFastState.compose env3677 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound3677 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3678 : List Nat := [2,4,8,16,32,16,40,256,512,273,2048,545,8192,544,8201,8235,805,2341,273,8201,544,293,276,35,8225,277,2308,544,805,2080,273,261,256,1,544,512]

theorem envBound3678 : H12AffineFastState.Bounded env3678 := by
  intro p hp
  have h : env3678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3677_3678 : H12AffineEnvironment.transform 9 273 env3677 = env3678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env3677 == env3678) = true)

theorem identity3678 : scanCanonicalize (H12AffineFastState.compose env3678 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3678 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3679 : List Nat := [2,4,8,16,27,16,19,256,512,273,2048,538,8192,539,8201,8208,798,2334,273,8201,539,286,276,24,8218,277,2308,539,798,2075,273,261,256,1,539,512]

theorem envBound3679 : H12AffineFastState.Bounded env3679 := by
  intro p hp
  have h : env3679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3678_3679 : H12AffineEnvironment.transform 4 27 env3678 = env3679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3678 == env3679) = true)

def env3680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4097,4194304,8388608,41002,8329,8388608,303145,4265,4357,2185,74795,12624277,256,168,8466750,8389565]

theorem envBound3680 : H12AffineFastState.Bounded env3680 := by
  intro p hp
  have h : env3680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3669_3680 : H12AffineEnvironment.transform 5 17 env3669 = env3680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3669 == env3680) = true)

def env3681 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,262144,1024,32768,4097,4194304,8388608,41002,8329,8388608,303145,4265,4265,2185,74795,12623929,172,168,8466578,8389137]

theorem envBound3681 : H12AffineFastState.Bounded env3681 := by
  intro p hp
  have h : env3681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3680_3681 : H12AffineEnvironment.transform 7 172 env3680 = env3681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3680 == env3681) = true)

theorem identity3681 : scanCanonicalize (H12AffineFastState.compose env3681 (packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 106143) := by decide +kernel

theorem selectedBound3681 : packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env3682 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,4194304,8388608,41002,8329,8388608,81590,4265,4265,2185,74795,12623929,172,168,8466578,8389137]

theorem envBound3682 : H12AffineFastState.Bounded env3682 := by
  intro p hp
  have h : env3682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3681_3682 : H12AffineEnvironment.transform 17 106143 env3681 = env3682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106143 env3681 == env3682) = true)

def env3683 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41088,8388608,41002,8329,8388608,81590,4265,4265,2185,74795,8388793,172,168,8466578,8389137]

theorem envBound3683 : H12AffineFastState.Bounded env3683 := by
  intro p hp
  have h : env3683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3682_3683 : H12AffineEnvironment.transform 21 41088 env3682 = env3683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3682 == env3683) = true)

theorem identity3683 : scanCanonicalize (H12AffineFastState.compose env3683 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound3683 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3684 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,13973,65536,4097,75786,1024,13973,4097,5653,8388608,5823,8329,8388608,81590,4265,4265,2185,74795,8388793,172,168,8466578,8389137]

theorem envBound3684 : H12AffineFastState.Bounded env3684 := by
  intro p hp
  have h : env3684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3683_3684 : H12AffineEnvironment.transform 14 13973 env3683 = env3684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env3683 == env3684) = true)

theorem identity3684 : scanCanonicalize (H12AffineFastState.compose env3684 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3684 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3685 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13885,65536,4097,75786,1024,13885,4097,5653,8388608,5655,8225,8388608,81438,4097,4097,2081,74795,8388625,4,0,8466490,8389137]

theorem envBound3685 : H12AffineFastState.Bounded env3685 := by
  intro p hp
  have h : env3685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3684_3685 : H12AffineEnvironment.transform 6 40 env3684 = env3685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3684 == env3685) = true)

theorem identity3685 : scanCanonicalize (H12AffineFastState.compose env3685 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(22+1) ^^^ 79375) := by decide +kernel

theorem selectedBound3685 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3686 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13885,65536,4097,75786,1024,13885,4097,5653,79375,5655,8225,79375,81438,4097,4097,2081,74795,79390,4,0,1589,78878]

theorem envBound3686 : H12AffineFastState.Bounded env3686 := by
  intro p hp
  have h : env3686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3685_3686 : H12AffineEnvironment.transform 22 79375 env3685 = env3686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 79375 env3685 == env3686) = true)

def env3687 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41089,8388608,41002,8329,8388608,81590,4265,4265,2185,74795,8388792,172,168,8466578,8389137]

theorem envBound3687 : H12AffineFastState.Bounded env3687 := by
  intro p hp
  have h : env3687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3682_3687 : H12AffineEnvironment.transform 21 41089 env3682 = env3687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3682 == env3687) = true)

theorem identity3687 : scanCanonicalize (H12AffineFastState.compose env3687 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 5669) := by decide +kernel

theorem selectedBound3687 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3688 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,4265,32768,65536,4097,106143,1024,32768,4097,41089,5669,41002,8329,5669,81590,4265,4265,2185,74795,5789,172,168,75447,5172]

theorem envBound3688 : H12AffineFastState.Bounded env3688 := by
  intro p hp
  have h : env3688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3687_3688 : H12AffineEnvironment.transform 22 5669 env3687 = env3688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5669 env3687 == env3688) = true)

theorem identity3688 : scanCanonicalize (H12AffineFastState.compose env3688 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3688 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3689 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1693,8192,1588,32768,65536,1692,100354,1024,32768,1692,41089,184,41002,8329,184,75819,1588,1588,2185,74795,0,172,168,75447,681]

theorem envBound3689 : H12AffineFastState.Bounded env3689 := by
  intro p hp
  have h : env3689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3688_3689 : H12AffineEnvironment.transform 11 1693 env3688 = env3689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3688 == env3689) = true)

theorem identity3689 : scanCanonicalize (H12AffineFastState.compose env3689 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3689 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1