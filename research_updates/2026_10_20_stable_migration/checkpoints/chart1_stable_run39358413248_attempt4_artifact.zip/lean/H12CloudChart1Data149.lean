import H12CloudChart1Data148

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans37781_37782 : H12AffineEnvironment.transform 16 16400 env37781 = env37782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37781 == env37782) = true)

theorem identity37782 : scanCanonicalize (H12AffineFastState.compose env37782 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37782 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env37783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,2097152,4194304,16,16777216,8193,65,21039476,18949465,2118977,2421,16852316,23160137,257,18965864,18949401,16777731]

theorem envBound37783 : H12AffineFastState.Bounded env37783 := by
  intro p hp
  have h : env37783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37782_37783 : H12AffineEnvironment.transform 14 8541 env37782 = env37783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37782 == env37783) = true)

theorem identity37783 : scanCanonicalize (H12AffineFastState.compose env37783 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 65876) := by decide +kernel

theorem selectedBound37783 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env37784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,2097152,4194304,16,65876,8193,65,4196384,2106381,2118977,2421,9224,6317085,257,2122812,2106445,66391]

theorem envBound37784 : H12AffineFastState.Bounded env37784 := by
  intro p hp
  have h : env37784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37783_37784 : H12AffineEnvironment.transform 23 65876 env37783 = env37784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65876 env37783 == env37784) = true)

theorem identity37784 : scanCanonicalize (H12AffineFastState.compose env37784 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound37784 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS < 2^1333 := by decide +kernel

def env37785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,17680,4194304,16,65876,8193,65,4196384,24861,4177,2421,9224,4202765,257,8492,24925,66391]

theorem envBound37785 : H12AffineFastState.Bounded env37785 := by
  intro p hp
  have h : env37785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37784_37785 : H12AffineEnvironment.transform 20 17680 env37784 = env37785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env37784 == env37785) = true)

theorem identity37785 : scanCanonicalize (H12AffineFastState.compose env37785 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound37785 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env37786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,17680,8572,16,65876,8193,65,10588,24861,4177,2421,9224,113,257,8492,24925,66391]

theorem envBound37786 : H12AffineFastState.Bounded env37786 := by
  intro p hp
  have h : env37786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37785_37786 : H12AffineEnvironment.transform 21 8572 env37785 = env37786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env37785 == env37786) = true)

theorem identity37786 : scanCanonicalize (H12AffineFastState.compose env37786 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37786 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env37787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,65536,16400,2421,1025,0,17680,32,16,65876,349,65,2048,16449,4177,2421,1364,113,257,112,16385,66391]

theorem envBound37787 : H12AffineFastState.Bounded env37787 := by
  intro p hp
  have h : env37787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37786_37787 : H12AffineEnvironment.transform 12 348 env37786 = env37787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37786 == env37787) = true)

theorem identity37787 : scanCanonicalize (H12AffineFastState.compose env37787 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2145) := by decide +kernel

theorem selectedBound37787 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env37788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2145,348,16384,1,65536,16400,2421,1025,0,17680,32,16,65876,349,65,2048,16449,2096,2421,1364,113,257,112,16385,66391]

theorem envBound37788 : H12AffineFastState.Bounded env37788 := by
  intro p hp
  have h : env37788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37787_37788 : H12AffineEnvironment.transform 11 2145 env37787 = env37788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2145 env37787 == env37788) = true)

theorem identity37788 : scanCanonicalize (H12AffineFastState.compose env37788 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37788 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37789 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2065,300,16384,1,65536,16400,2309,1025,0,17680,32,16,65828,301,49,2048,16433,2096,2309,1316,1,257,0,16385,66343]

theorem envBound37789 : H12AffineFastState.Bounded env37789 := by
  intro p hp
  have h : env37789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37788_37789 : H12AffineEnvironment.transform 5 48 env37788 = env37789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37788 == env37789) = true)

theorem identity37789 : scanCanonicalize (H12AffineFastState.compose env37789 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound37789 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37790 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2065,300,16384,1,262,16400,2309,1025,0,17680,32,16,34,301,49,2048,16433,2096,2309,1316,1,257,0,16385,545]

theorem envBound37790 : H12AffineFastState.Bounded env37790 := by
  intro p hp
  have h : env37790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37789_37790 : H12AffineEnvironment.transform 15 262 env37789 = env37790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env37789 == env37790) = true)

theorem identity37790 : scanCanonicalize (H12AffineFastState.compose env37790 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound37790 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env37791 : List Nat := [2,4,8,16,32,48,9,256,512,1024,260,277,300,16384,1,262,16400,1,1025,0,17680,32,16,34,301,49,260,16433,308,1,1316,1,257,0,16385,545]

theorem envBound37791 : H12AffineFastState.Bounded env37791 := by
  intro p hp
  have h : env37791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37790_37791 : H12AffineEnvironment.transform 10 260 env37790 = env37791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env37790 == env37791) = true)

theorem identity37791 : scanCanonicalize (H12AffineFastState.compose env37791 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37791 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env37792 : List Nat := [2,4,8,16,32,48,9,256,512,52,260,277,300,16384,1,262,16400,1,53,0,16676,32,16,34,301,49,260,16433,308,1,272,1,257,0,16385,545]

theorem envBound37792 : H12AffineFastState.Bounded env37792 := by
  intro p hp
  have h : env37792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37791_37792 : H12AffineEnvironment.transform 9 52 env37791 = env37792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37791 == env37792) = true)

def env37793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,16777216,8193,65,21039476,18973700,2118976,2421,16876544,23160137,257,18990132,18949400,16819039]

theorem envBound37793 : H12AffineFastState.Bounded env37793 := by
  intro p hp
  have h : env37793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37781_37793 : H12AffineEnvironment.transform 16 16401 env37781 = env37793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37781 == env37793) = true)

def env37794 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,16777216,8193,65,21039104,18973700,2118708,2049,16876544,23159869,117,18990132,18949228,16818731]

theorem envBound37794 : H12AffineFastState.Bounded env37794 := by
  intro p hp
  have h : env37794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37793_37794 : H12AffineEnvironment.transform 7 116 env37793 = env37794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37793 == env37794) = true)

theorem identity37794 : scanCanonicalize (H12AffineFastState.compose env37794 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound37794 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env37795 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212885,8193,65,6343701,16401,2118708,2049,2113557,4235304,117,33,57465,2188862]

theorem envBound37795 : H12AffineFastState.Bounded env37795 := by
  intro p hp
  have h : env37795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37794_37795 : H12AffineEnvironment.transform 23 2212885 env37794 = env37795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env37794 == env37795) = true)

def env37796 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212885,8193,17,6343701,16401,2118708,2049,2113557,4235304,37,33,57385,2188862]

theorem envBound37796 : H12AffineFastState.Bounded env37796 := by
  intro p hp
  have h : env37796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37795_37796 : H12AffineEnvironment.transform 5 16 env37795 = env37796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37795 == env37796) = true)

theorem identity37796 : scanCanonicalize (H12AffineFastState.compose env37796 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound37796 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env37797 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,73771,17,2212885,8193,17,2223166,16401,2118708,2049,2113557,98307,37,33,57385,2188862]

theorem envBound37797 : H12AffineFastState.Bounded env37797 := by
  intro p hp
  have h : env37797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37796_37797 : H12AffineEnvironment.transform 21 73771 env37796 = env37797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env37796 == env37797) = true)

theorem identity37797 : scanCanonicalize (H12AffineFastState.compose env37797 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound37797 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37798 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,65536,16401,10281,1025,8232,2097152,73771,17,2188348,8193,17,2182167,16401,2118708,2049,2113557,73770,37,33,16384,2188862]

theorem envBound37798 : H12AffineFastState.Bounded env37798 := by
  intro p hp
  have h : env37798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37797_37798 : H12AffineEnvironment.transform 14 8233 env37797 = env37798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env37797 == env37798) = true)

theorem identity37798 : scanCanonicalize (H12AffineFastState.compose env37798 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound37798 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env37799 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,65536,16401,10281,1025,8232,25629,73771,17,65569,8193,17,75786,16401,12329,2049,9224,73770,37,33,16384,66083]

theorem envBound37799 : H12AffineFastState.Bounded env37799 := by
  intro p hp
  have h : env37799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37798_37799 : H12AffineEnvironment.transform 20 25629 env37798 = env37799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env37798 == env37799) = true)

theorem identity37799 : scanCanonicalize (H12AffineFastState.compose env37799 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound37799 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37800 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,21510,16401,10281,1025,8232,25629,29741,17,21543,8193,17,31756,16401,12329,2049,9224,29740,37,33,16384,22053]

theorem envBound37800 : H12AffineFastState.Bounded env37800 := by
  intro p hp
  have h : env37800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37799_37800 : H12AffineEnvironment.transform 15 21510 env37799 = env37800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env37799 == env37800) = true)

theorem identity37800 : scanCanonicalize (H12AffineFastState.compose env37800 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37800 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env37801 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,1,21510,16401,2049,1025,0,17461,21509,17,21543,41,17,23588,16401,4097,2049,1056,21508,37,33,16384,22053]

theorem envBound37801 : H12AffineFastState.Bounded env37801 := by
  intro p hp
  have h : env37801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37800_37801 : H12AffineEnvironment.transform 12 40 env37800 = env37801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37800 == env37801) = true)

theorem identity37801 : scanCanonicalize (H12AffineFastState.compose env37801 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound37801 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37802 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,3108,40,16384,1,18466,16401,2049,1025,0,17461,18465,17,18435,41,17,16384,16401,3109,2049,1056,18464,37,33,16384,18945]

theorem envBound37802 : H12AffineFastState.Bounded env37802 := by
  intro p hp
  have h : env37802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37801_37802 : H12AffineEnvironment.transform 11 3108 env37801 = env37802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env37801 == env37802) = true)

def env37803 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212885,8193,16,6343701,16401,2118708,2049,2113557,4235304,36,33,57384,2188862]

theorem envBound37803 : H12AffineFastState.Bounded env37803 := by
  intro p hp
  have h : env37803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37795_37803 : H12AffineEnvironment.transform 5 17 env37795 = env37803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37795 == env37803) = true)

theorem identity37803 : scanCanonicalize (H12AffineFastState.compose env37803 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37803 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env37804 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,1,65536,16401,2049,1025,0,2097152,4194304,17,2180116,8193,16,6310932,16401,2118708,2049,2113557,4202537,36,33,24617,2188862]

theorem envBound37804 : H12AffineFastState.Bounded env37804 := by
  intro p hp
  have h : env37804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37803_37804 : H12AffineEnvironment.transform 14 1 env37803 = env37804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37803 == env37804) = true)

theorem identity37804 : scanCanonicalize (H12AffineFastState.compose env37804 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122813) := by decide +kernel

theorem selectedBound37804 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env37805 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,1,65536,16401,2049,1025,0,2097152,2122813,17,2180116,8193,16,10281,16401,2118708,2049,2113557,2114580,36,33,24617,2188862]

theorem envBound37805 : H12AffineFastState.Bounded env37805 := by
  intro p hp
  have h : env37805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37804_37805 : H12AffineEnvironment.transform 21 2122813 env37804 = env37805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122813 env37804 == env37805) = true)

theorem identity37805 : scanCanonicalize (H12AffineFastState.compose env37805 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(20+1) ^^^ 12313) := by decide +kernel

theorem selectedBound37805 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env37806 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,1,65536,16401,2049,1025,0,12313,21540,17,95245,8193,16,10281,16401,25645,2049,28684,29709,36,33,24617,87591]

theorem envBound37806 : H12AffineFastState.Bounded env37806 := by
  intro p hp
  have h : env37806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37805_37806 : H12AffineEnvironment.transform 20 12313 env37805 = env37806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12313 env37805 == env37806) = true)

theorem identity37806 : scanCanonicalize (H12AffineFastState.compose env37806 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound37806 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env37807 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,5124,1,65536,5141,2049,1025,0,12313,32,17,73737,8193,16,10281,5141,12329,2049,9224,8201,36,33,13357,66083]

theorem envBound37807 : H12AffineFastState.Bounded env37807 := by
  intro p hp
  have h : env37807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37806_37807 : H12AffineEnvironment.transform 13 5124 env37806 = env37807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env37806 == env37807) = true)

theorem identity37807 : scanCanonicalize (H12AffineFastState.compose env37807 (packedSelected [0,1,2,3,4,5,7,8,9,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound37807 : packedSelected [0,1,2,3,4,5,7,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env37808 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,4096,8192,5124,1,65536,5141,32,1025,0,12313,32,17,73737,8193,16,8200,5141,12329,32,9224,8201,36,33,13357,66083]

theorem envBound37808 : H12AffineFastState.Bounded env37808 := by
  intro p hp
  have h : env37808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37807_37808 : H12AffineEnvironment.transform 10 33 env37807 = env37808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env37807 == env37808) = true)

theorem identity37808 : scanCanonicalize (H12AffineFastState.compose env37808 (packedSelected [0,1,4,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound37808 : packedSelected [0,1,4,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37809 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,1060,8192,32,1,65536,49,32,1025,0,9277,32,17,73737,8193,16,8200,49,9229,32,9224,8201,36,33,8201,66083]

theorem envBound37809 : H12AffineFastState.Bounded env37809 := by
  intro p hp
  have h : env37809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37808_37809 : H12AffineEnvironment.transform 11 1060 env37808 = env37809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env37808 == env37809) = true)

theorem identity37809 : scanCanonicalize (H12AffineFastState.compose env37809 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 1079) := by decide +kernel

theorem selectedBound37809 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37810 : List Nat := [2,4,8,16,32,17,9,37,512,1024,33,1060,8192,32,1,1079,49,32,1025,0,9277,32,17,9278,8193,16,8200,49,9229,32,9224,8201,36,33,8201,1556]

theorem envBound37810 : H12AffineFastState.Bounded env37810 := by
  intro p hp
  have h : env37810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37809_37810 : H12AffineEnvironment.transform 15 1079 env37809 = env37810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1079 env37809 == env37810) = true)

theorem identity37810 : scanCanonicalize (H12AffineFastState.compose env37810 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37810 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37811 : List Nat := [2,4,8,16,32,17,9,37,512,20,33,48,8192,32,1,35,49,32,21,0,8233,32,17,8234,8193,16,8200,49,8217,32,8220,8201,36,33,8201,512]

theorem envBound37811 : H12AffineFastState.Bounded env37811 := by
  intro p hp
  have h : env37811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37810_37811 : H12AffineEnvironment.transform 9 20 env37810 = env37811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37810 == env37811) = true)

theorem identity37811 : scanCanonicalize (H12AffineFastState.compose env37811 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37811 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37812 : List Nat := [2,4,8,16,0,17,9,5,512,20,1,16,8192,0,1,3,17,0,21,0,8201,0,17,8202,8193,16,8200,17,8217,0,8220,8201,4,1,8201,512]

theorem envBound37812 : H12AffineFastState.Bounded env37812 := by
  intro p hp
  have h : env37812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37811_37812 : H12AffineEnvironment.transform 4 0 env37811 = env37812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37811 == env37812) = true)

def env37813 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,16777216,8193,65,21039105,18973700,2118709,2048,16876544,23159868,116,18990132,18949229,16818730]

theorem envBound37813 : H12AffineFastState.Bounded env37813 := by
  intro p hp
  have h : env37813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37793_37813 : H12AffineEnvironment.transform 7 117 env37793 = env37813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37793 == env37813) = true)

theorem identity37813 : scanCanonicalize (H12AffineFastState.compose env37813 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound37813 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env37814 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,65,21039105,16834618,77835,2048,16876544,20971522,116,16818186,16793683,16818730]

theorem envBound37814 : H12AffineFastState.Bounded env37814 := by
  intro p hp
  have h : env37814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37813_37814 : H12AffineEnvironment.transform 20 91198 env37813 = env37814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env37813 == env37814) = true)

def env37815 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,17,21039105,16834618,77835,2048,16876544,20971522,36,16818186,16793603,16818730]

theorem envBound37815 : H12AffineFastState.Bounded env37815 := by
  intro p hp
  have h : env37815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37814_37815 : H12AffineEnvironment.transform 5 16 env37814 = env37815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37814 == env37815) = true)

theorem identity37815 : scanCanonicalize (H12AffineFastState.compose env37815 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292609) := by decide +kernel

theorem selectedBound37815 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37816 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,4292609,8193,17,34816,4284475,77835,2048,4195329,98307,36,4268043,4308994,4268587]

theorem envBound37816 : H12AffineFastState.Bounded env37816 := by
  intro p hp
  have h : env37816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37815_37816 : H12AffineEnvironment.transform 23 4292609 env37815 = env37816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292609 env37815 == env37816) = true)

theorem identity37816 : scanCanonicalize (H12AffineFastState.compose env37816 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound37816 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37817 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,8232,65536,16401,10281,1025,8233,91198,4194304,17,4268073,8193,17,10280,4284475,77835,2048,4195329,73771,36,4268043,4284458,4268587]

theorem envBound37817 : H12AffineFastState.Bounded env37817 := by
  intro p hp
  have h : env37817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37816_37817 : H12AffineEnvironment.transform 14 8232 env37816 = env37817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env37816 == env37817) = true)

theorem identity37817 : scanCanonicalize (H12AffineFastState.compose env37817 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound37817 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env37818 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8232,65536,13372,10281,1025,8233,69651,4194304,17,4268073,8193,17,10280,4264982,77835,2048,4195329,73771,36,4268043,4264967,4268587]

theorem envBound37818 : H12AffineFastState.Bounded env37818 := by
  intro p hp
  have h : env37818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37817_37818 : H12AffineEnvironment.transform 13 13357 env37817 = env37818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env37817 == env37818) = true)

theorem identity37818 : scanCanonicalize (H12AffineFastState.compose env37818 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37818 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env37819 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5125,0,65536,5140,2049,1025,1,69651,4194304,17,4259841,41,17,2048,4264982,69667,2048,4195329,65539,36,4259875,4264967,4260355]

theorem envBound37819 : H12AffineFastState.Bounded env37819 := by
  intro p hp
  have h : env37819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37818_37819 : H12AffineEnvironment.transform 12 40 env37818 = env37819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37818 == env37819) = true)

theorem identity37819 : scanCanonicalize (H12AffineFastState.compose env37819 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound37819 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37820 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5125,0,65536,5140,2049,1025,1,69651,33,17,65568,41,17,2048,70711,69667,2048,1056,65539,36,65538,70694,66082]

theorem envBound37820 : H12AffineFastState.Bounded env37820 := by
  intro p hp
  have h : env37820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37819_37820 : H12AffineEnvironment.transform 21 33 env37819 = env37820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env37819 == env37820) = true)

theorem identity37820 : scanCanonicalize (H12AffineFastState.compose env37820 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound37820 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37821 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,40,2049,0,65536,2064,2049,1025,1,68631,33,17,65568,41,17,2048,67635,68647,2048,1056,65539,36,65538,67618,66082]

theorem envBound37821 : H12AffineFastState.Bounded env37821 := by
  intro p hp
  have h : env37821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37820_37821 : H12AffineEnvironment.transform 11 3076 env37820 = env37821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env37820 == env37821) = true)

theorem identity37821 : scanCanonicalize (H12AffineFastState.compose env37821 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound37821 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37822 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,40,2049,0,34,2064,2049,1025,1,3125,33,17,2,41,17,2048,2065,3077,2048,1056,33,36,32,2048,512]

theorem envBound37822 : H12AffineFastState.Bounded env37822 := by
  intro p hp
  have h : env37822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37821_37822 : H12AffineEnvironment.transform 15 34 env37821 = env37822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env37821 == env37822) = true)

theorem identity37822 : scanCanonicalize (H12AffineFastState.compose env37822 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37823 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,40,2049,0,34,2064,2049,52,1,2048,33,17,2,41,17,2048,2065,2096,2048,21,33,36,32,2048,512]

theorem envBound37823 : H12AffineFastState.Bounded env37823 := by
  intro p hp
  have h : env37823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37822_37823 : H12AffineEnvironment.transform 9 53 env37822 = env37823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37822 == env37823) = true)

theorem identity37823 : scanCanonicalize (H12AffineFastState.compose env37823 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37824 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,48,40,0,0,34,17,0,52,1,1,33,17,2,41,17,1,16,49,1,21,33,36,32,1,512]

theorem envBound37824 : H12AffineFastState.Bounded env37824 := by
  intro p hp
  have h : env37824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37823_37824 : H12AffineEnvironment.transform 10 1 env37823 = env37824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37823 == env37824) = true)

theorem identity37824 : scanCanonicalize (H12AffineFastState.compose env37824 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37824 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37825 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,8,0,0,2,17,0,20,1,1,1,17,2,9,17,1,16,17,1,21,1,4,0,1,512]

theorem envBound37825 : H12AffineFastState.Bounded env37825 := by
  intro p hp
  have h : env37825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37824_37825 : H12AffineEnvironment.transform 4 0 env37824 = env37825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37824 == env37825) = true)

theorem identity37825 : scanCanonicalize (H12AffineFastState.compose env37825 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37826 : List Nat := [2,4,8,0,0,0,9,5,512,5,1,0,8,0,0,2,1,0,4,1,1,1,1,2,9,1,1,0,1,1,5,1,4,0,1,512]

theorem envBound37826 : H12AffineFastState.Bounded env37826 := by
  intro p hp
  have h : env37826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37825_37826 : H12AffineEnvironment.transform 3 0 env37825 = env37826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37825 == env37826) = true)

theorem identity37826 : scanCanonicalize (H12AffineFastState.compose env37826 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound37826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37827 : List Nat := [2,4,8,0,0,0,9,5,15,5,1,0,8,0,0,2,1,0,4,1,1,1,1,2,9,1,1,0,1,1,5,1,4,0,1,15]

theorem envBound37827 : H12AffineFastState.Bounded env37827 := by
  intro p hp
  have h : env37827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37826_37827 : H12AffineEnvironment.transform 8 15 env37826 = env37827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env37826 == env37827) = true)

def env37828 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,16,21039105,16834618,77835,2048,16876544,20971522,37,16818186,16793602,16818730]

theorem envBound37828 : H12AffineFastState.Bounded env37828 := by
  intro p hp
  have h : env37828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37814_37828 : H12AffineEnvironment.transform 5 17 env37814 = env37828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37814 == env37828) = true)

theorem identity37828 : scanCanonicalize (H12AffineFastState.compose env37828 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235274) := by decide +kernel

theorem selectedBound37828 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37829 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,4235274,8193,16,108555,4210736,77835,2048,4269066,40968,37,4194304,4251656,4194848]

theorem envBound37829 : H12AffineFastState.Bounded env37829 := by
  intro p hp
  have h : env37829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37828_37829 : H12AffineEnvironment.transform 23 4235274 env37828 = env37829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235274 env37828 == env37829) = true)

theorem identity37829 : scanCanonicalize (H12AffineFastState.compose env37829 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound37829 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env37830 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,8200,17,32770,8193,16,108555,24632,77835,2048,66562,40968,37,8200,49152,8744]

theorem envBound37830 : H12AffineFastState.Bounded env37830 := by
  intro p hp
  have h : env37830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37829_37830 : H12AffineEnvironment.transform 21 8200 env37829 = env37830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env37829 == env37830) = true)

theorem identity37830 : scanCanonicalize (H12AffineFastState.compose env37830 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound37830 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env37831 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,34,16401,34817,1025,32769,25628,8200,17,32770,8193,16,43049,24632,12329,2048,1056,40968,37,8200,49152,8744]

theorem envBound37831 : H12AffineFastState.Bounded env37831 := by
  intro p hp
  have h : env37831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37830_37831 : H12AffineEnvironment.transform 15 34 env37830 = env37831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env37830 == env37831) = true)

theorem identity37831 : scanCanonicalize (H12AffineFastState.compose env37831 (packedSelected [0,1,2,6,7,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37831 : packedSelected [0,1,2,6,7,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env37832 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,1,34,16401,2048,1025,0,25628,8200,17,3,8193,16,10280,24632,12329,2048,1056,8201,37,8200,16385,8744]

theorem envBound37832 : H12AffineFastState.Bounded env37832 := by
  intro p hp
  have h : env37832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37831_37832 : H12AffineEnvironment.transform 14 1 env37831 = env37832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37831 == env37832) = true)

theorem identity37832 : scanCanonicalize (H12AffineFastState.compose env37832 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound37832 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37833 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5124,1,34,5141,2048,1025,0,12312,8200,17,3,8193,16,10280,13372,12329,2048,1056,8201,37,8200,5125,8744]

theorem envBound37833 : H12AffineFastState.Bounded env37833 := by
  intro p hp
  have h : env37833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37832_37833 : H12AffineEnvironment.transform 13 5124 env37832 = env37833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env37832 == env37833) = true)

theorem identity37833 : scanCanonicalize (H12AffineFastState.compose env37833 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37833 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37834 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5124,1,34,5141,2048,1025,0,4144,32,17,3,41,16,2048,5140,4097,2048,1056,33,37,32,5125,512]

theorem envBound37834 : H12AffineFastState.Bounded env37834 := by
  intro p hp
  have h : env37834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37833_37834 : H12AffineEnvironment.transform 12 40 env37833 = env37834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37833 == env37834) = true)

theorem identity37834 : scanCanonicalize (H12AffineFastState.compose env37834 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound37834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37835 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3077,40,2049,1,34,2064,2048,1025,0,3125,32,17,3,41,16,2048,2065,3076,2048,1056,33,37,32,2048,512]

theorem envBound37835 : H12AffineFastState.Bounded env37835 := by
  intro p hp
  have h : env37835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37834_37835 : H12AffineEnvironment.transform 11 3077 env37834 = env37835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env37834 == env37835) = true)

theorem identity37835 : scanCanonicalize (H12AffineFastState.compose env37835 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37835 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37836 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3077,9,2049,1,3,2064,2048,1025,0,3092,1,17,3,8,16,2048,2065,3076,2048,1025,0,4,1,2048,512]

theorem envBound37836 : H12AffineFastState.Bounded env37836 := by
  intro p hp
  have h : env37836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37835_37836 : H12AffineEnvironment.transform 4 1 env37835 = env37836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37835 == env37836) = true)

theorem identity37836 : scanCanonicalize (H12AffineFastState.compose env37836 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37837 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2065,9,2049,1,3,2064,2048,21,0,2048,1,17,3,8,16,2048,2065,2064,2048,21,0,4,1,2048,512]

theorem envBound37837 : H12AffineFastState.Bounded env37837 := by
  intro p hp
  have h : env37837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37836_37837 : H12AffineEnvironment.transform 9 20 env37836 = env37837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37836 == env37837) = true)

theorem identity37837 : scanCanonicalize (H12AffineFastState.compose env37837 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37838 : List Nat := [2,4,8,16,1,17,9,5,0,20,2048,2065,9,2049,1,3,2064,2048,21,0,2048,1,17,3,8,16,2048,2065,2064,2048,21,0,4,1,2048,0]

theorem envBound37838 : H12AffineFastState.Bounded env37838 := by
  intro p hp
  have h : env37838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37837_37838 : H12AffineEnvironment.transform 8 0 env37837 = env37838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37837 == env37838) = true)

theorem identity37838 : scanCanonicalize (H12AffineFastState.compose env37838 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound37838 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37839 : List Nat := [2,4,8,16,1,17,9,5,0,20,30,15,9,31,1,3,14,30,21,0,30,1,17,3,8,16,30,15,14,30,21,0,4,1,30,0]

theorem envBound37839 : H12AffineFastState.Bounded env37839 := by
  intro p hp
  have h : env37839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37838_37839 : H12AffineEnvironment.transform 10 30 env37838 = env37839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env37838 == env37839) = true)

def leafEnv37839 : List Nat := [2,4,8,16,1,17,9,5,0,20,30,15,9,31,1,3,14,30,21,0,30,1,17,3,20,8,1,16,30,15,14,30,21,0,4,1,5,2,30,0,1,31,0]

def active37839 : List Nat := [0,1,2,3]

def tree37839 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37839 : H12WitnessSearch.Good tree37839 := H12GlobalWitnessIndex.good

theorem leafIdentity37839 : H12AffineFastState.composeSystem env37839 rootObs = leafEnv37839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37839 rootObs == leafEnv37839) = true)

theorem terminalChecked37839 : H12PackedTerminal.terminalCheckFast leafEnv37839 active37839 tree37839 = true := by decide +kernel

def env37840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,16777216,8193,65,21039477,18973700,2233680,2420,17024016,23160137,257,19104804,19096840,16966479]

theorem envBound37840 : H12AffineFastState.Bounded env37840 := by
  intro p hp
  have h : env37840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37780_37840 : H12AffineEnvironment.transform 22 147457 env37780 = env37840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env37780 == env37840) = true)

theorem identity37840 : scanCanonicalize (H12AffineFastState.compose env37840 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound37840 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,188750,8193,65,4450363,2319690,2233680,2420,75102,6521863,257,2188650,2196550,513]

theorem envBound37841 : H12AffineFastState.Bounded env37841 := by
  intro p hp
  have h : env37841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37840_37841 : H12AffineEnvironment.transform 23 188750 env37840 = env37841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env37840 == env37841) = true)

def env37842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41310,8193,65,4302891,2172250,2118976,2420,75102,6407191,257,2188650,2196550,513]

theorem envBound37842 : H12AffineFastState.Bounded env37842 := by
  intro p hp
  have h : env37842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37841_37842 : H12AffineEnvironment.transform 16 16400 env37841 = env37842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37841 == env37842) = true)

theorem identity37842 : scanCanonicalize (H12AffineFastState.compose env37842 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound37842 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115734,4194304,17,41310,8193,65,4302891,57676,102742,2420,75102,4194305,257,41340,16464,513]

theorem envBound37843 : H12AffineFastState.Bounded env37843 := by
  intro p hp
  have h : env37843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37842_37843 : H12AffineEnvironment.transform 20 115734 env37842 = env37843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env37842 == env37843) = true)

def env37844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91198,4194304,17,374,8193,65,4261891,16740,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound37844 : H12AffineFastState.Bounded env37844 := by
  intro p hp
  have h : env37844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37843_37844 : H12AffineEnvironment.transform 14 8232 env37843 = env37844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env37843 == env37844) = true)

theorem identity37844 : scanCanonicalize (H12AffineFastState.compose env37844 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound37844 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env37845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91198,8201,17,374,8193,65,75786,16740,78206,2420,75102,8200,257,340,16464,513]

theorem envBound37845 : H12AffineFastState.Bounded env37845 := by
  intro p hp
  have h : env37845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37844_37845 : H12AffineEnvironment.transform 21 8201 env37844 = env37845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env37844 == env37845) = true)

theorem identity37845 : scanCanonicalize (H12AffineFastState.compose env37845 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37845 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env37846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,343,16400,10588,1025,8233,25961,8201,17,374,8193,65,10589,16740,12329,2420,9225,8200,257,340,16464,513]

theorem envBound37846 : H12AffineFastState.Bounded env37846 := by
  intro p hp
  have h : env37846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37845_37846 : H12AffineEnvironment.transform 15 343 env37845 = env37846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37845 == env37846) = true)

theorem identity37846 : scanCanonicalize (H12AffineFastState.compose env37846 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37846 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env37847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,373,343,16400,2049,1025,372,17460,340,17,374,348,65,2048,16740,4468,2420,1364,341,257,340,16464,513]

theorem envBound37847 : H12AffineFastState.Bounded env37847 := by
  intro p hp
  have h : env37847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37846_37847 : H12AffineEnvironment.transform 12 349 env37846 = env37847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37846 == env37847) = true)

theorem identity37847 : scanCanonicalize (H12AffineFastState.compose env37847 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37847 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37848 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,293,263,16400,2049,1025,292,17460,260,17,294,268,17,2048,16692,4388,2340,1284,261,257,260,16384,513]

theorem envBound37848 : H12AffineFastState.Bounded env37848 := by
  intro p hp
  have h : env37848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37847_37848 : H12AffineEnvironment.transform 5 16 env37847 = env37848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37847 == env37848) = true)

theorem identity37848 : scanCanonicalize (H12AffineFastState.compose env37848 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37848 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37849 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,16384,0,34,16400,2049,1025,1,17460,33,17,3,41,17,2048,16401,4097,2049,1057,32,36,33,16384,513]

theorem envBound37849 : H12AffineFastState.Bounded env37849 := by
  intro p hp
  have h : env37849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37848_37849 : H12AffineEnvironment.transform 7 37 env37848 = env37849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37848 == env37849) = true)

theorem identity37849 : scanCanonicalize (H12AffineFastState.compose env37849 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound37849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37850 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5173,2049,1025,1,4113,33,17,3,41,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound37850 : H12AffineFastState.Bounded env37850 := by
  intro p hp
  have h : env37850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37849_37850 : H12AffineEnvironment.transform 13 5157 env37849 = env37850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env37849 == env37850) = true)

def env37851 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,0,34,1029,2049,1025,1,33,33,17,3,41,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound37851 : H12AffineFastState.Bounded env37851 := by
  intro p hp
  have h : env37851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37850_37851 : H12AffineEnvironment.transform 11 48 env37850 = env37851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37850 == env37851) = true)

theorem identity37851 : scanCanonicalize (H12AffineFastState.compose env37851 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37852 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,0,3,1029,2049,1025,1,0,0,17,3,8,17,2048,1028,16,2049,1024,1,5,0,1045,513]

theorem envBound37852 : H12AffineFastState.Bounded env37852 := by
  intro p hp
  have h : env37852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37851_37852 : H12AffineEnvironment.transform 4 1 env37851 = env37852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37851 == env37852) = true)

def env37853 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,9,1,0,3,17,2049,21,1,0,0,17,3,8,17,2048,16,16,2049,20,1,5,0,1,513]

theorem envBound37853 : H12AffineFastState.Bounded env37853 := by
  intro p hp
  have h : env37853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37852_37853 : H12AffineEnvironment.transform 9 20 env37852 = env37853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37852 == env37853) = true)

theorem identity37853 : scanCanonicalize (H12AffineFastState.compose env37853 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37854 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,9,1,0,3,17,1,21,1,0,0,17,3,8,17,0,16,16,1,20,1,5,0,1,513]

theorem envBound37854 : H12AffineFastState.Bounded env37854 := by
  intro p hp
  have h : env37854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37853_37854 : H12AffineEnvironment.transform 10 0 env37853 = env37854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37853 == env37854) = true)

def leafEnv37854 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,9,1,0,3,17,1,21,1,0,0,17,3,21,8,1,17,0,16,16,1,20,1,5,0,5,2,1,513,1,0,0]

def active37854 : List Nat := [0,1,2,3,8]

def tree37854 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37854 : H12WitnessSearch.Good tree37854 := H12GlobalWitnessIndex.good

theorem leafIdentity37854 : H12AffineFastState.composeSystem env37854 rootObs = leafEnv37854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37854 rootObs == leafEnv37854) = true)

theorem terminalChecked37854 : H12PackedTerminal.terminalCheckFast leafEnv37854 active37854 tree37854 = true := by decide +kernel

def env37855 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,0,0,3,16,2049,20,1,0,0,17,3,8,17,2048,17,16,2049,21,1,5,0,0,513]

theorem envBound37855 : H12AffineFastState.Bounded env37855 := by
  intro p hp
  have h : env37855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37852_37855 : H12AffineEnvironment.transform 9 21 env37852 = env37855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37852 == env37855) = true)

theorem identity37855 : scanCanonicalize (H12AffineFastState.compose env37855 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37856 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,17,9,0,0,3,16,523,20,1,0,0,17,3,8,17,522,17,16,523,21,1,5,0,0,513]

theorem envBound37856 : H12AffineFastState.Bounded env37856 := by
  intro p hp
  have h : env37856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37855_37856 : H12AffineEnvironment.transform 10 522 env37855 = env37856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37855 == env37856) = true)

def leafEnv37856 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,17,9,0,0,3,16,523,20,1,0,0,17,3,20,8,1,17,522,17,16,523,21,1,5,0,5,2,0,513,1,0,0]

def active37856 : List Nat := [0,1,2,3,8]

def tree37856 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37856 : H12WitnessSearch.Good tree37856 := H12GlobalWitnessIndex.good

theorem leafIdentity37856 : H12AffineFastState.composeSystem env37856 rootObs = leafEnv37856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37856 rootObs == leafEnv37856) = true)

theorem terminalChecked37856 : H12PackedTerminal.terminalCheckFast leafEnv37856 active37856 tree37856 = true := by decide +kernel

def env37857 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,0,34,1028,2049,1025,1,32,33,17,3,41,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound37857 : H12AffineFastState.Bounded env37857 := by
  intro p hp
  have h : env37857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37850_37857 : H12AffineEnvironment.transform 11 49 env37850 = env37857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37850 == env37857) = true)

theorem identity37857 : scanCanonicalize (H12AffineFastState.compose env37857 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37857 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37858 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,49,40,0,0,34,16,2049,21,1,32,33,17,3,41,17,2048,17,48,2049,53,32,36,33,0,513]

theorem envBound37858 : H12AffineFastState.Bounded env37858 := by
  intro p hp
  have h : env37858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37857_37858 : H12AffineEnvironment.transform 9 20 env37857 = env37858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37857 == env37858) = true)

def env37859 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,0,0,2,16,2049,21,1,0,1,17,3,9,17,2048,17,16,2049,21,0,4,1,0,513]

theorem envBound37859 : H12AffineFastState.Bounded env37859 := by
  intro p hp
  have h : env37859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37858_37859 : H12AffineEnvironment.transform 4 0 env37858 = env37859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37858 == env37859) = true)

theorem identity37859 : scanCanonicalize (H12AffineFastState.compose env37859 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37860 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,17,8,0,0,2,16,523,21,1,0,1,17,3,9,17,522,17,16,523,21,0,4,1,0,513]

theorem envBound37860 : H12AffineFastState.Bounded env37860 := by
  intro p hp
  have h : env37860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37859_37860 : H12AffineEnvironment.transform 10 522 env37859 = env37860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37859 == env37860) = true)

def leafEnv37860 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,17,8,0,0,2,16,523,21,1,0,1,17,3,20,9,1,17,522,17,16,523,21,0,4,1,5,3,0,513,1,0,0]

def active37860 : List Nat := [0,1,2,3,8]

def tree37860 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37860 : H12WitnessSearch.Good tree37860 := H12GlobalWitnessIndex.good

theorem leafIdentity37860 : H12AffineFastState.composeSystem env37860 rootObs = leafEnv37860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37860 rootObs == leafEnv37860) = true)

theorem terminalChecked37860 : H12PackedTerminal.terminalCheckFast leafEnv37860 active37860 tree37860 = true := by decide +kernel

def env37861 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,0,0,3,16,2049,21,1,1,0,17,3,8,17,2048,17,17,2049,20,1,5,0,0,513]

theorem envBound37861 : H12AffineFastState.Bounded env37861 := by
  intro p hp
  have h : env37861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37858_37861 : H12AffineEnvironment.transform 4 1 env37858 = env37861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37858 == env37861) = true)

theorem identity37861 : scanCanonicalize (H12AffineFastState.compose env37861 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37862 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,9,0,0,3,16,0,21,1,1,0,17,3,8,17,1,17,17,0,20,1,5,0,0,513]

theorem envBound37862 : H12AffineFastState.Bounded env37862 := by
  intro p hp
  have h : env37862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37861_37862 : H12AffineEnvironment.transform 10 1 env37861 = env37862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37861 == env37862) = true)

def leafEnv37862 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,9,0,0,3,16,0,21,1,1,0,17,3,21,8,1,17,1,17,17,0,20,1,5,0,5,2,0,513,1,1,0]

def active37862 : List Nat := [0,1,2,3,8]

def tree37862 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37862 : H12WitnessSearch.Good tree37862 := H12GlobalWitnessIndex.good

theorem leafIdentity37862 : H12AffineFastState.composeSystem env37862 rootObs = leafEnv37862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37862 rootObs == leafEnv37862) = true)

theorem terminalChecked37862 : H12PackedTerminal.terminalCheckFast leafEnv37862 active37862 tree37862 = true := by decide +kernel

def env37863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91199,4194304,17,375,8193,65,4261890,16741,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound37863 : H12AffineFastState.Bounded env37863 := by
  intro p hp
  have h : env37863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37843_37863 : H12AffineEnvironment.transform 14 8233 env37843 = env37863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env37843 == env37863) = true)

theorem identity37863 : scanCanonicalize (H12AffineFastState.compose env37863 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound37863 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env37864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91199,8572,17,375,8193,65,76158,16741,78207,2420,75102,8573,257,341,16464,513]

theorem envBound37864 : H12AffineFastState.Bounded env37864 := by
  intro p hp
  have h : env37864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37863_37864 : H12AffineEnvironment.transform 21 8572 env37863 = env37864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env37863 == env37864) = true)

theorem identity37864 : scanCanonicalize (H12AffineFastState.compose env37864 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound37864 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env37865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,35,16400,10589,1025,8232,25628,8572,17,375,8193,65,10589,16741,12636,2420,9597,8573,257,341,16464,513]

theorem envBound37865 : H12AffineFastState.Bounded env37865 := by
  intro p hp
  have h : env37865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37864_37865 : H12AffineEnvironment.transform 15 35 env37864 = env37865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env37864 == env37865) = true)

theorem identity37865 : scanCanonicalize (H12AffineFastState.compose env37865 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37865 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env37866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,35,16400,2420,1025,1,17461,341,17,375,40,65,2420,16741,4469,2420,1364,340,257,341,16464,513]

theorem envBound37866 : H12AffineFastState.Bounded env37866 := by
  intro p hp
  have h : env37866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37865_37866 : H12AffineEnvironment.transform 12 41 env37865 = env37866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37865 == env37866) = true)

theorem identity37866 : scanCanonicalize (H12AffineFastState.compose env37866 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37866 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37867 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,16384,0,35,16400,2128,1025,1,17461,113,17,83,40,65,2128,16449,4177,2128,1136,112,37,113,16464,513]

theorem envBound37867 : H12AffineFastState.Bounded env37867 := by
  intro p hp
  have h : env37867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37866_37867 : H12AffineEnvironment.transform 7 36 env37866 = env37867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37866 == env37867) = true)

theorem identity37867 : scanCanonicalize (H12AffineFastState.compose env37867 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound37867 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37868 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5237,0,35,5221,2128,1025,1,4160,113,17,83,40,65,2128,5172,4177,2128,1136,112,37,113,5157,513]

theorem envBound37868 : H12AffineFastState.Bounded env37868 := by
  intro p hp
  have h : env37868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37867_37868 : H12AffineEnvironment.transform 13 5237 env37867 = env37868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env37867 == env37868) = true)

theorem identity37868 : scanCanonicalize (H12AffineFastState.compose env37868 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37869 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1025,1,4112,33,17,3,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound37869 : H12AffineFastState.Bounded env37869 := by
  intro p hp
  have h : env37869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37868_37869 : H12AffineEnvironment.transform 5 16 env37868 = env37869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37868 == env37869) = true)

def env37870 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,0,35,1029,2048,1025,1,32,33,17,3,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound37870 : H12AffineFastState.Bounded env37870 := by
  intro p hp
  have h : env37870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37869_37870 : H12AffineEnvironment.transform 11 48 env37869 = env37870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37869 == env37870) = true)

theorem identity37870 : scanCanonicalize (H12AffineFastState.compose env37870 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound37870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37871 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1540,48,41,1045,0,35,1029,1540,1025,1,32,33,17,3,40,17,1540,1028,49,1540,1056,32,37,33,1045,513]

theorem envBound37871 : H12AffineFastState.Bounded env37871 := by
  intro p hp
  have h : env37871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37870_37871 : H12AffineEnvironment.transform 10 1540 env37870 = env37871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env37870 == env37871) = true)

def env37872 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,48,41,33,0,35,49,560,53,1,32,33,17,3,40,17,560,48,49,560,20,32,37,33,33,513]

theorem envBound37872 : H12AffineFastState.Bounded env37872 := by
  intro p hp
  have h : env37872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37871_37872 : H12AffineEnvironment.transform 9 52 env37871 = env37872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37871 == env37872) = true)

theorem identity37872 : scanCanonicalize (H12AffineFastState.compose env37872 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37873 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,11,18,26,0,24,10,523,14,1,27,26,17,3,19,17,523,11,10,523,20,27,30,26,26,513]

theorem envBound37873 : H12AffineFastState.Bounded env37873 := by
  intro p hp
  have h : env37873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37872_37873 : H12AffineEnvironment.transform 4 27 env37872 = env37873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37872 == env37873) = true)

def leafEnv37873 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,11,18,26,0,24,10,523,14,1,27,26,17,3,21,19,1,17,523,11,10,523,20,27,30,26,5,25,26,513,1,27,0]

def active37873 : List Nat := [0,1,2,3,8]

def tree37873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37873 : H12WitnessSearch.Good tree37873 := H12GlobalWitnessIndex.good

theorem leafIdentity37873 : H12AffineFastState.composeSystem env37873 rootObs = leafEnv37873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37873 rootObs == leafEnv37873) = true)

theorem terminalChecked37873 : H12PackedTerminal.terminalCheckFast leafEnv37873 active37873 tree37873 = true := by decide +kernel

def env37874 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,48,41,32,0,35,48,561,52,1,32,33,17,3,40,17,561,49,49,561,21,32,37,33,32,513]

theorem envBound37874 : H12AffineFastState.Bounded env37874 := by
  intro p hp
  have h : env37874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37871_37874 : H12AffineEnvironment.transform 9 53 env37871 = env37874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37871 == env37874) = true)

theorem identity37874 : scanCanonicalize (H12AffineFastState.compose env37874 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37874 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37875 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,48,41,32,0,35,48,33,52,1,32,33,17,3,40,17,33,49,49,33,21,32,37,33,32,17]

theorem envBound37875 : H12AffineFastState.Bounded env37875 := by
  intro p hp
  have h : env37875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37874_37875 : H12AffineEnvironment.transform 8 16 env37874 = env37875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37874 == env37875) = true)

def leafEnv37875 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,48,41,32,0,35,48,33,52,1,32,33,17,3,20,40,1,17,33,49,49,33,21,32,37,33,5,34,32,17,1,32,0]

def active37875 : List Nat := [0,1,2,3,4]

def tree37875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37875 : H12WitnessSearch.Good tree37875 := H12GlobalWitnessIndex.good

theorem leafIdentity37875 : H12AffineFastState.composeSystem env37875 rootObs = leafEnv37875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37875 rootObs == leafEnv37875) = true)

theorem terminalChecked37875 : H12PackedTerminal.terminalCheckFast leafEnv37875 active37875 tree37875 = true := by decide +kernel

def env37876 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,0,35,1028,2048,1025,1,33,33,17,3,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound37876 : H12AffineFastState.Bounded env37876 := by
  intro p hp
  have h : env37876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37869_37876 : H12AffineEnvironment.transform 11 49 env37869 = env37876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37869 == env37876) = true)

theorem identity37876 : scanCanonicalize (H12AffineFastState.compose env37876 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound37876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37877 : List Nat := [2,4,8,16,32,16,9,36,512,1024,561,49,41,1044,0,35,1028,561,1025,1,33,33,17,3,40,17,561,1029,48,561,1056,32,37,33,1044,513]

theorem envBound37877 : H12AffineFastState.Bounded env37877 := by
  intro p hp
  have h : env37877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37876_37877 : H12AffineEnvironment.transform 10 561 env37876 = env37877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env37876 == env37877) = true)

def env37878 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,49,41,32,0,35,48,561,53,1,33,33,17,3,40,17,561,49,48,561,20,32,37,33,32,513]

theorem envBound37878 : H12AffineFastState.Bounded env37878 := by
  intro p hp
  have h : env37878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37877_37878 : H12AffineEnvironment.transform 9 52 env37877 = env37878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37877 == env37878) = true)

theorem identity37878 : scanCanonicalize (H12AffineFastState.compose env37878 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37879 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,11,19,26,0,25,10,523,15,1,27,27,17,3,18,17,523,11,10,523,20,26,31,27,26,513]

theorem envBound37879 : H12AffineFastState.Bounded env37879 := by
  intro p hp
  have h : env37879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37878_37879 : H12AffineEnvironment.transform 4 26 env37878 = env37879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37878 == env37879) = true)

def leafEnv37879 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,11,19,26,0,25,10,523,15,1,27,27,17,3,21,18,1,17,523,11,10,523,20,26,31,27,5,24,26,513,1,27,0]

def active37879 : List Nat := [0,1,2,3,8]

def tree37879 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37879 : H12WitnessSearch.Good tree37879 := H12GlobalWitnessIndex.good

theorem leafIdentity37879 : H12AffineFastState.composeSystem env37879 rootObs = leafEnv37879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37879 rootObs == leafEnv37879) = true)

theorem terminalChecked37879 : H12PackedTerminal.terminalCheckFast leafEnv37879 active37879 tree37879 = true := by decide +kernel

def env37880 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,49,41,33,0,35,49,561,52,1,33,33,17,3,40,17,561,48,48,561,21,32,37,33,33,513]

theorem envBound37880 : H12AffineFastState.Bounded env37880 := by
  intro p hp
  have h : env37880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37877_37880 : H12AffineEnvironment.transform 9 53 env37877 = env37880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37877 == env37880) = true)

theorem identity37880 : scanCanonicalize (H12AffineFastState.compose env37880 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37881 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,49,41,33,0,35,49,32,52,1,33,33,17,3,40,17,32,48,48,32,21,32,37,33,33,16]

theorem envBound37881 : H12AffineFastState.Bounded env37881 := by
  intro p hp
  have h : env37881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37880_37881 : H12AffineEnvironment.transform 8 17 env37880 = env37881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37880 == env37881) = true)

def leafEnv37881 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,49,41,33,0,35,49,32,52,1,33,33,17,3,20,40,1,17,32,48,48,32,21,32,37,33,5,34,33,16,1,33,0]

def active37881 : List Nat := [0,1,2,3,4]

def tree37881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37881 : H12WitnessSearch.Good tree37881 := H12GlobalWitnessIndex.good

theorem leafIdentity37881 : H12AffineFastState.composeSystem env37881 rootObs = leafEnv37881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37881 rootObs == leafEnv37881) = true)

theorem terminalChecked37881 : H12PackedTerminal.terminalCheckFast leafEnv37881 active37881 tree37881 = true := by decide +kernel

def env37882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,41311,8193,65,4302890,2172251,2118977,2420,75102,6407190,257,2188650,2196550,513]

theorem envBound37882 : H12AffineFastState.Bounded env37882 := by
  intro p hp
  have h : env37882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37841_37882 : H12AffineEnvironment.transform 16 16401 env37841 = env37882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37841 == env37882) = true)

theorem identity37882 : scanCanonicalize (H12AffineFastState.compose env37882 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37882 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2098512,2118977,2420,1365,6349853,257,2114913,2139213,513]

theorem envBound37883 : H12AffineFastState.Bounded env37883 := by
  intro p hp
  have h : env37883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37882_37883 : H12AffineEnvironment.transform 15 8203 env37882 = env37883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37882 == env37883) = true)

theorem identity37883 : scanCanonicalize (H12AffineFastState.compose env37883 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound37883 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,32,16,41311,8193,65,34817,2098512,2118977,2420,1365,2155581,257,2114913,2139213,513]

theorem envBound37884 : H12AffineFastState.Bounded env37884 := by
  intro p hp
  have h : env37884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37883_37884 : H12AffineEnvironment.transform 21 32 env37883 = env37884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env37883 == env37884) = true)

theorem identity37884 : scanCanonicalize (H12AffineFastState.compose env37884 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37884 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,2097152,32,16,2,8193,65,10588,2098512,2118977,2420,1365,2114912,257,2114913,2098448,513]

theorem envBound37885 : H12AffineFastState.Bounded env37885 := by
  intro p hp
  have h : env37885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37884_37885 : H12AffineEnvironment.transform 14 8541 env37884 = env37885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37884 == env37885) = true)

theorem identity37885 : scanCanonicalize (H12AffineFastState.compose env37885 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound37885 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,25676,32,16,2,8193,65,10588,24860,12557,2420,1365,8492,257,8493,24924,513]

theorem envBound37886 : H12AffineFastState.Bounded env37886 := by
  intro p hp
  have h : env37886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37885_37886 : H12AffineEnvironment.transform 20 25676 env37885 = env37886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env37885 == env37886) = true)

theorem identity37886 : scanCanonicalize (H12AffineFastState.compose env37886 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37886 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1025,8540,12621,32,16,2,8193,65,10588,13341,12557,2420,1365,8492,257,8493,13405,513]

theorem envBound37887 : H12AffineFastState.Bounded env37887 := by
  intro p hp
  have h : env37887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37886_37887 : H12AffineEnvironment.transform 13 5377 env37886 = env37887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37886 == env37887) = true)

theorem identity37887 : scanCanonicalize (H12AffineFastState.compose env37887 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37887 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,263,5392,2341,1025,80,4161,32,16,2,269,65,2128,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound37888 : H12AffineFastState.Bounded env37888 := by
  intro p hp
  have h : env37888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37887_37888 : H12AffineEnvironment.transform 12 268 env37887 = env37888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37887 == env37888) = true)

theorem identity37888 : scanCanonicalize (H12AffineFastState.compose env37888 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound37888 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37889 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4453,81,263,4468,2341,101,80,4161,32,16,2,269,65,2128,4469,4097,2420,305,32,257,33,4405,513]

theorem envBound37889 : H12AffineFastState.Bounded env37889 := by
  intro p hp
  have h : env37889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37888_37889 : H12AffineEnvironment.transform 9 100 env37888 = env37889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env37888 == env37889) = true)

theorem identity37889 : scanCanonicalize (H12AffineFastState.compose env37889 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound37889 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37890 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,268,2340,81,263,2357,2341,101,80,2048,32,16,2,269,65,2128,2356,2112,2420,305,32,257,33,2420,513]

theorem envBound37890 : H12AffineFastState.Bounded env37890 := by
  intro p hp
  have h : env37890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37889_37890 : H12AffineEnvironment.transform 11 2113 env37889 = env37890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env37889 == env37890) = true)

theorem identity37890 : scanCanonicalize (H12AffineFastState.compose env37890 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37890 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37891 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2064,268,2340,0,263,2357,2341,52,1,2048,32,16,2,269,16,2049,2356,2065,2341,305,32,257,33,2341,513]

theorem envBound37891 : H12AffineFastState.Bounded env37891 := by
  intro p hp
  have h : env37891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37890_37891 : H12AffineEnvironment.transform 5 17 env37890 = env37891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37890 == env37891) = true)

theorem identity37891 : scanCanonicalize (H12AffineFastState.compose env37891 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound37891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37892 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,308,268,0,0,263,17,1,52,1,292,32,16,2,269,16,293,16,309,1,305,32,257,33,1,513]

theorem envBound37892 : H12AffineFastState.Bounded env37892 := by
  intro p hp
  have h : env37892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37891_37892 : H12AffineEnvironment.transform 10 292 env37891 = env37892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env37891 == env37892) = true)

def env37893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,4294967296,525568,4308116845,27337992,25733062]

theorem envBound37893 : H12AffineFastState.Bounded env37893 := by
  intro p hp
  have h : env37893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31960_37893 : H12AffineEnvironment.transform 28 77616401 env31960 = env37893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env31960 == env37893) = true)

def env37894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound37894 : H12AffineFastState.Bounded env37894 := by
  intro p hp
  have h : env37894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37893_37894 : H12AffineEnvironment.transform 31 145662400 env37893 = env37894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env37893 == env37894) = true)

def env37895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound37895 : H12AffineFastState.Bounded env37895 := by
  intro p hp
  have h : env37895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37894_37895 : H12AffineEnvironment.transform 29 155254784 env37894 = env37895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env37894 == env37895) = true)

def env37896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound37896 : H12AffineFastState.Bounded env37896 := by
  intro p hp
  have h : env37896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37895_37896 : H12AffineEnvironment.transform 25 64 env37895 = env37896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env37895 == env37896) = true)

def env37897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound37897 : H12AffineFastState.Bounded env37897 := by
  intro p hp
  have h : env37897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37896_37897 : H12AffineEnvironment.transform 26 30393344 env37896 = env37897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env37896 == env37897) = true)

def env37898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound37898 : H12AffineFastState.Bounded env37898 := by
  intro p hp
  have h : env37898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37897_37898 : H12AffineEnvironment.transform 18 1024 env37897 = env37898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37897 == env37898) = true)

theorem identity37898 : scanCanonicalize (H12AffineFastState.compose env37898 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188736) := by decide +kernel

theorem selectedBound37898 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188736,8328,64,15115712,57676,10507601,8830976,10543568,4194304,256,8429933,8405192,10601990]

theorem envBound37899 : H12AffineFastState.Bounded env37899 := by
  intro p hp
  have h : env37899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37898_37899 : H12AffineEnvironment.transform 23 2188736 env37898 = env37899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188736 env37898 == env37899) = true)

def env37900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62540,2188736,8328,64,6705548,57676,2138397,406604,2102684,4194304,256,21793,46212,2175562]

theorem envBound37900 : H12AffineFastState.Bounded env37900 := by
  intro p hp
  have h : env37900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37899_37900 : H12AffineEnvironment.transform 22 62540 env37899 = env37900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env37899 == env37900) = true)

def env37901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62540,2188736,8328,64,410092,57676,2138397,406604,2102684,2101344,256,21793,46212,2175562]

theorem envBound37901 : H12AffineFastState.Bounded env37901 := by
  intro p hp
  have h : env37901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37900_37901 : H12AffineEnvironment.transform 21 2101344 env37900 = env37901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env37900 == env37901) = true)

def env37902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73856,8328,64,410092,57676,58461,406604,20700,21792,256,21793,46212,96010]

theorem envBound37902 : H12AffineFastState.Bounded env37902 := by
  intro p hp
  have h : env37902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37901_37902 : H12AffineEnvironment.transform 20 17728 env37901 = env37902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env37901 == env37902) = true)

theorem identity37902 : scanCanonicalize (H12AffineFastState.compose env37902 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound37902 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,17728,21792,62540,41311,8328,64,410092,57676,58461,406604,20700,21792,256,21793,46212,63189]

theorem envBound37903 : H12AffineFastState.Bounded env37903 := by
  intro p hp
  have h : env37903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37902_37903 : H12AffineEnvironment.transform 15 33247 env37902 = env37903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env37902 == env37903) = true)

theorem identity37903 : scanCanonicalize (H12AffineFastState.compose env37903 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound37903 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,56436,1024,32769,17728,21792,62540,41311,8328,64,171416,57676,58461,190520,20700,21792,256,21793,46212,63189]

theorem envBound37904 : H12AffineFastState.Bounded env37904 := by
  intro p hp
  have h : env37904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37903_37904 : H12AffineEnvironment.transform 17 56436 env37903 = env37904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env37903 == env37904) = true)

theorem identity37904 : scanCanonicalize (H12AffineFastState.compose env37904 (packedSelected [0,2,4,12,15,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound37904 : packedSelected [0,2,4,12,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env37905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,32768,33247,131072,43096,1024,32769,12652,8460,32864,41311,8328,64,171416,38240,36977,171028,9456,8460,256,8461,46212,33529]

theorem envBound37905 : H12AffineFastState.Bounded env37905 := by
  intro p hp
  have h : env37905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37904_37905 : H12AffineEnvironment.transform 13 13356 env37904 = env37905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env37904 == env37905) = true)

theorem identity37905 : scanCanonicalize (H12AffineFastState.compose env37905 (packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound37905 : packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS < 2^1333 := by decide +kernel

def env37906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,248,295,131072,10400,1024,249,12652,8460,152,8615,8328,64,138592,5528,4233,138476,9456,8460,256,8461,13436,513]

theorem envBound37906 : H12AffineFastState.Bounded env37906 := by
  intro p hp
  have h : env37906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37905_37906 : H12AffineEnvironment.transform 14 248 env37905 = env37906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env37905 == env37906) = true)

theorem identity37906 : scanCanonicalize (H12AffineFastState.compose env37906 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound37906 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env37907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,248,295,13461,10400,1024,249,12652,8460,152,8615,8328,64,10741,5528,4233,10361,9456,8460,256,8461,13436,513]

theorem envBound37907 : H12AffineFastState.Bounded env37907 := by
  intro p hp
  have h : env37907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37906_37907 : H12AffineEnvironment.transform 16 13461 env37906 = env37907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env37906 == env37907) = true)

theorem identity37907 : scanCanonicalize (H12AffineFastState.compose env37907 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound37907 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env37908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5513,248,295,5424,2309,1024,249,4297,169,152,2,301,64,2128,5528,4233,2524,1365,169,256,168,5593,513]

theorem envBound37908 : H12AffineFastState.Bounded env37908 := by
  intro p hp
  have h : env37908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37907_37908 : H12AffineEnvironment.transform 12 421 env37907 = env37908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env37907 == env37908) = true)

theorem identity37908 : scanCanonicalize (H12AffineFastState.compose env37908 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37908 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env37909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5376,113,295,5424,2309,1024,112,4160,32,17,2,301,64,2128,5393,4096,2389,1365,32,256,33,5456,513]

theorem envBound37909 : H12AffineFastState.Bounded env37909 := by
  intro p hp
  have h : env37909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37908_37909 : H12AffineEnvironment.transform 6 9 env37908 = env37909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37908 == env37909) = true)

theorem identity37909 : scanCanonicalize (H12AffineFastState.compose env37909 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37909 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37910 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,300,5376,32,295,5424,2309,1024,33,4113,32,17,2,301,17,2049,5393,4096,2308,1284,32,256,33,5377,513]

theorem envBound37910 : H12AffineFastState.Bounded env37910 := by
  intro p hp
  have h : env37910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37909_37910 : H12AffineEnvironment.transform 5 17 env37909 = env37910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37909 == env37910) = true)

theorem identity37910 : scanCanonicalize (H12AffineFastState.compose env37910 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37910 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37911 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5376,1,262,5393,2309,1024,0,4113,1,17,2,268,17,2049,5393,4096,2308,1284,1,256,0,5377,513]

theorem envBound37911 : H12AffineFastState.Bounded env37911 := by
  intro p hp
  have h : env37911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37910_37911 : H12AffineEnvironment.transform 4 1 env37910 = env37911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37910 == env37911) = true)

theorem identity37911 : scanCanonicalize (H12AffineFastState.compose env37911 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound37911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37912 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,1297,269,17,1,262,0,2309,1024,0,1280,1,17,2,268,17,2049,0,1297,2308,1284,1,256,0,16,513]

theorem envBound37912 : H12AffineFastState.Bounded env37912 := by
  intro p hp
  have h : env37912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37911_37912 : H12AffineEnvironment.transform 11 1297 env37911 = env37912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env37911 == env37912) = true)

theorem identity37912 : scanCanonicalize (H12AffineFastState.compose env37912 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound37912 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37913 : List Nat := [2,4,8,16,1,17,9,256,261,1024,2048,1297,269,17,1,262,0,2309,1024,0,1280,1,17,2,268,17,2049,0,1297,2308,1284,1,256,0,16,260]

theorem envBound37913 : H12AffineFastState.Bounded env37913 := by
  intro p hp
  have h : env37913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37912_37913 : H12AffineEnvironment.transform 8 261 env37912 = env37913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env37912 == env37913) = true)

theorem identity37913 : scanCanonicalize (H12AffineFastState.compose env37913 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound37913 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37914 : List Nat := [2,4,8,16,1,17,9,256,261,1024,276,1297,269,17,1,262,0,17,1024,0,1280,1,17,2,268,17,277,0,1297,16,1284,1,256,0,16,260]

theorem envBound37914 : H12AffineFastState.Bounded env37914 := by
  intro p hp
  have h : env37914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37913_37914 : H12AffineEnvironment.transform 10 276 env37913 = env37914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env37913 == env37914) = true)

theorem identity37914 : scanCanonicalize (H12AffineFastState.compose env37914 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37914 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37915 : List Nat := [2,4,8,16,1,17,9,5,0,1024,17,1044,8,17,1,3,0,17,1024,0,1029,1,17,2,9,17,16,0,1044,16,1025,1,5,0,16,1]

theorem envBound37915 : H12AffineFastState.Bounded env37915 := by
  intro p hp
  have h : env37915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37914_37915 : H12AffineEnvironment.transform 7 5 env37914 = env37915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37914 == env37915) = true)

def env37916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62540,73857,8328,64,410092,57676,58460,406604,20701,21793,256,21793,46212,96011]

theorem envBound37916 : H12AffineFastState.Bounded env37916 := by
  intro p hp
  have h : env37916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37901_37916 : H12AffineEnvironment.transform 20 17729 env37901 = env37916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env37901 == env37916) = true)

theorem identity37916 : scanCanonicalize (H12AffineFastState.compose env37916 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound37916 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,262144,1024,32769,17729,21793,62540,41431,8328,64,410092,57676,58460,406604,20701,21793,256,21793,46212,63069]

theorem envBound37917 : H12AffineFastState.Bounded env37917 := by
  intro p hp
  have h : env37917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37916_37917 : H12AffineEnvironment.transform 15 33110 env37916 = env37917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env37916 == env37917) = true)

def env37918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10400,1024,32769,17729,21793,62540,41431,8328,64,158028,57676,58460,138476,20701,21793,256,21793,46212,63069]

theorem envBound37918 : H12AffineFastState.Bounded env37918 := by
  intro p hp
  have h : env37918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37917_37918 : H12AffineEnvironment.transform 17 10400 env37917 = env37918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37917 == env37918) = true)

theorem identity37918 : scanCanonicalize (H12AffineFastState.compose env37918 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57488) := by decide +kernel

theorem selectedBound37918 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env37919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,57488,10400,1024,32769,17729,21793,62540,41431,8328,64,35292,57676,58460,64636,20701,21793,256,21793,46212,63069]

theorem envBound37919 : H12AffineFastState.Bounded env37919 := by
  intro p hp
  have h : env37919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37918_37919 : H12AffineEnvironment.transform 16 57488 env37918 = env37919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57488 env37918 == env37919) = true)

theorem identity37919 : scanCanonicalize (H12AffineFastState.compose env37919 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37919 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env37920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57368,10280,1024,32769,17729,21793,62540,41311,8192,64,35156,57676,58460,64636,20565,21793,256,21793,46092,63069]

theorem envBound37920 : H12AffineFastState.Bounded env37920 := by
  intro p hp
  have h : env37920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37919_37920 : H12AffineEnvironment.transform 6 8 env37919 = env37920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37919 == env37920) = true)

theorem identity37920 : scanCanonicalize (H12AffineFastState.compose env37920 (packedSelected [4,9,12,14,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37920 : packedSelected [4,9,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16709,10280,1024,8540,17729,21793,21777,2,8192,64,10249,16401,17665,23841,20565,21793,256,21793,5457,22272]

theorem envBound37921 : H12AffineFastState.Bounded env37921 := by
  intro p hp
  have h : env37921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37920_37921 : H12AffineEnvironment.transform 14 8541 env37920 = env37921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37920 == env37921) = true)

theorem identity37921 : scanCanonicalize (H12AffineFastState.compose env37921 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound37921 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env37922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,8203,13641,10280,1024,8540,12621,8493,8477,2,8192,64,10249,13341,12557,10541,9305,8493,256,8493,5457,8972]

theorem envBound37922 : H12AffineFastState.Bounded env37922 := by
  intro p hp
  have h : env37922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37921_37922 : H12AffineEnvironment.transform 13 13324 env37921 = env37922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env37921 == env37922) = true)

theorem identity37922 : scanCanonicalize (H12AffineFastState.compose env37922 (packedSelected [1,2,3,5,6,8,10,12,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37922 : packedSelected [1,2,3,5,6,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env37923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5189,2340,1024,80,4161,33,17,2,268,64,2309,5393,4097,2081,1365,33,256,33,5457,512]

theorem envBound37923 : H12AffineFastState.Bounded env37923 := by
  intro p hp
  have h : env37923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37922_37923 : H12AffineEnvironment.transform 12 268 env37922 = env37923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37922 == env37923) = true)

theorem identity37923 : scanCanonicalize (H12AffineFastState.compose env37923 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37923 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37924 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5237,81,114,5189,2129,1024,80,4161,33,17,2,121,64,2160,5220,4097,2081,1056,33,117,33,5156,512]

theorem envBound37924 : H12AffineFastState.Bounded env37924 := by
  intro p hp
  have h : env37924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37923_37924 : H12AffineEnvironment.transform 7 117 env37923 = env37924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37923 == env37924) = true)

theorem identity37924 : scanCanonicalize (H12AffineFastState.compose env37924 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37924 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env37925 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,121,4161,81,114,4209,2129,52,80,4161,33,17,2,121,64,2160,4176,4097,2081,20,33,117,33,4112,512]

theorem envBound37925 : H12AffineFastState.Bounded env37925 := by
  intro p hp
  have h : env37925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37924_37925 : H12AffineEnvironment.transform 9 52 env37924 = env37925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37924 == env37925) = true)

def env37926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10401,1024,32769,17729,21793,62540,41431,8328,64,158029,57676,58460,138477,20701,21793,256,21793,46212,63069]

theorem envBound37926 : H12AffineFastState.Bounded env37926 := by
  intro p hp
  have h : env37926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37917_37926 : H12AffineEnvironment.transform 17 10401 env37917 = env37926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37917 == env37926) = true)

theorem identity37926 : scanCanonicalize (H12AffineFastState.compose env37926 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 46441) := by decide +kernel

theorem selectedBound37926 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env37927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,46441,10401,1024,32769,17729,21793,62540,41431,8328,64,56356,57676,58460,43396,20701,21793,256,21793,46212,63069]

theorem envBound37927 : H12AffineFastState.Bounded env37927 := by
  intro p hp
  have h : env37927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37926_37927 : H12AffineEnvironment.transform 16 46441 env37926 = env37927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46441 env37926 == env37927) = true)

theorem identity37927 : scanCanonicalize (H12AffineFastState.compose env37927 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37927 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env37928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,46441,10401,1024,32769,4160,32,41293,41431,8328,64,35109,46157,45405,43396,1500,32,256,32,46212,41820]

theorem envBound37928 : H12AffineFastState.Bounded env37928 := by
  intro p hp
  have h : env37928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37927_37928 : H12AffineEnvironment.transform 13 5377 env37927 = env37928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37927 == env37928) = true)

theorem identity37928 : scanCanonicalize (H12AffineFastState.compose env37928 (packedSelected [0,4,7,21,22] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound37928 : packedSelected [0,4,7,21,22] rootPS < 2^1333 := by decide +kernel

def env37929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5377,32768,33110,38296,2128,1024,32769,4160,32,33212,33062,121,64,35109,38076,37292,35189,1500,32,256,32,38005,33709]

theorem envBound37929 : H12AffineFastState.Bounded env37929 := by
  intro p hp
  have h : env37929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37928_37929 : H12AffineEnvironment.transform 12 241 env37928 = env37929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env37928 == env37929) = true)

theorem identity37929 : scanCanonicalize (H12AffineFastState.compose env37929 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37929 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env37930 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5157,32768,32882,38076,2128,1024,32769,4160,32,32920,32770,121,64,34817,38076,37000,34897,1272,32,36,32,38005,33417]

theorem envBound37930 : H12AffineFastState.Bounded env37930 := by
  intro p hp
  have h : env37930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37929_37930 : H12AffineEnvironment.transform 7 36 env37929 = env37930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37929 == env37930) = true)

theorem identity37930 : scanCanonicalize (H12AffineFastState.compose env37930 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound37930 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env37931 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5157,136,250,5172,2128,1024,137,4160,32,16,138,121,64,2185,5172,4096,2265,1272,32,36,32,5373,513]

theorem envBound37931 : H12AffineFastState.Bounded env37931 := by
  intro p hp
  have h : env37931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37930_37931 : H12AffineEnvironment.transform 14 136 env37930 = env37931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env37930 == env37931) = true)

theorem identity37931 : scanCanonicalize (H12AffineFastState.compose env37931 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37931 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37932 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5157,136,171,5172,2049,1024,137,4113,32,16,138,40,17,2185,5172,4096,2184,1193,32,36,32,5292,513]

theorem envBound37932 : H12AffineFastState.Bounded env37932 := by
  intro p hp
  have h : env37932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37931_37932 : H12AffineEnvironment.transform 5 17 env37931 = env37932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37931 == env37932) = true)

theorem identity37932 : scanCanonicalize (H12AffineFastState.compose env37932 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37932 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37933 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,4096,160,4112,136,171,4097,2049,53,137,4113,32,16,138,40,17,2185,4097,4096,2184,156,32,36,32,4249,513]

theorem envBound37933 : H12AffineFastState.Bounded env37933 := by
  intro p hp
  have h : env37933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37932_37933 : H12AffineEnvironment.transform 9 53 env37932 = env37933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37932 == env37933) = true)

theorem identity37933 : scanCanonicalize (H12AffineFastState.compose env37933 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37934 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,1,34,4097,2049,53,0,4113,32,16,3,40,17,2048,4097,4096,2049,21,32,36,32,4112,513]

theorem envBound37934 : H12AffineFastState.Bounded env37934 := by
  intro p hp
  have h : env37934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37933_37934 : H12AffineEnvironment.transform 6 9 env37933 = env37934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37933 == env37934) = true)

theorem identity37934 : scanCanonicalize (H12AffineFastState.compose env37934 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37935 : List Nat := [2,4,8,0,32,1,9,36,512,37,2048,4096,41,4096,1,34,4097,2049,37,0,4097,32,0,3,40,1,2048,4097,4096,2049,5,32,36,32,4096,513]

theorem envBound37935 : H12AffineFastState.Bounded env37935 := by
  intro p hp
  have h : env37935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37934_37935 : H12AffineEnvironment.transform 3 0 env37934 = env37935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37934 == env37935) = true)

theorem identity37935 : scanCanonicalize (H12AffineFastState.compose env37935 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound37935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37936 : List Nat := [2,4,8,0,32,1,9,36,11,37,2048,4096,41,4096,1,34,4097,2049,37,0,4097,32,0,3,40,1,2048,4097,4096,2049,5,32,36,32,4096,10]

theorem envBound37936 : H12AffineFastState.Bounded env37936 := by
  intro p hp
  have h : env37936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37935_37936 : H12AffineEnvironment.transform 8 11 env37935 = env37936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env37935 == env37936) = true)

def env37937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62540,2188736,8328,64,410093,57676,2138397,406604,2102684,2101345,256,21793,46212,2175562]

theorem envBound37937 : H12AffineFastState.Bounded env37937 := by
  intro p hp
  have h : env37937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37900_37937 : H12AffineEnvironment.transform 21 2101345 env37900 = env37937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env37900 == env37937) = true)

def env37938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62540,73856,8328,64,410093,57676,58461,406604,20700,21793,256,21793,46212,96010]

theorem envBound37938 : H12AffineFastState.Bounded env37938 := by
  intro p hp
  have h : env37938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37937_37938 : H12AffineEnvironment.transform 20 17728 env37937 = env37938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env37937 == env37938) = true)

theorem identity37938 : scanCanonicalize (H12AffineFastState.compose env37938 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound37938 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,262144,1024,32769,17728,21793,62540,21763,8328,64,410093,57676,58461,406604,20700,21793,256,21793,46212,649]

theorem envBound37939 : H12AffineFastState.Bounded env37939 := by
  intro p hp
  have h : env37939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37938_37939 : H12AffineEnvironment.transform 15 30083 env37938 = env37939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env37938 == env37939) = true)

theorem identity37939 : scanCanonicalize (H12AffineFastState.compose env37939 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37939 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,17728,21793,62540,21763,8192,64,409957,57676,58461,406604,20564,21793,256,21793,46092,513]

theorem envBound37940 : H12AffineFastState.Bounded env37940 := by
  intro p hp
  have h : env37940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37939_37940 : H12AffineEnvironment.transform 6 8 env37939 = env37940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37939 == env37940) = true)

theorem identity37940 : scanCanonicalize (H12AffineFastState.compose env37940 (packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound37940 : packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS < 2^1333 := by decide +kernel

def env37941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,182628,1024,32769,17728,21793,62540,21763,8192,64,34817,57676,58461,64808,20564,21793,256,21793,46092,513]

theorem envBound37941 : H12AffineFastState.Bounded env37941 := by
  intro p hp
  have h : env37941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37940_37941 : H12AffineEnvironment.transform 17 182628 env37940 = env37941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env37940 == env37941) = true)

theorem identity37941 : scanCanonicalize (H12AffineFastState.compose env37941 (packedSelected [3,5,10,12,15,16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound37941 : packedSelected [3,5,10,12,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,2421,1024,32769,17728,21793,62540,21763,8192,64,34817,57676,58461,64808,20564,21793,256,21793,46092,513]

theorem envBound37942 : H12AffineFastState.Bounded env37942 := by
  intro p hp
  have h : env37942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37941_37942 : H12AffineEnvironment.transform 16 49169 env37941 = env37942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env37941 == env37942) = true)

theorem identity37942 : scanCanonicalize (H12AffineFastState.compose env37942 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37942 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env37943 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,2341,1024,32769,17680,21793,62492,21763,8192,16,34817,57628,58381,64808,20484,21793,256,21793,46092,513]

theorem envBound37943 : H12AffineFastState.Bounded env37943 := by
  intro p hp
  have h : env37943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37942_37943 : H12AffineEnvironment.transform 5 16 env37942 = env37943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37942 == env37943) = true)

theorem identity37943 : scanCanonicalize (H12AffineFastState.compose env37943 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound37943 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37944 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,29963,5392,2341,1024,21760,17680,21793,8477,21763,8192,16,23808,13341,12556,10281,20484,21793,256,21793,24845,513]

theorem envBound37944 : H12AffineFastState.Bounded env37944 := by
  intro p hp
  have h : env37944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37943_37944 : H12AffineEnvironment.transform 14 21761 env37943 = env37944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env37943 == env37944) = true)

theorem identity37944 : scanCanonicalize (H12AffineFastState.compose env37944 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37944 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37945 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21761,21510,5392,2341,1024,21760,17680,21793,16,21763,269,16,23808,5392,4097,2340,20484,21793,256,21793,16384,513]

theorem envBound37945 : H12AffineFastState.Bounded env37945 := by
  intro p hp
  have h : env37945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37944_37945 : H12AffineEnvironment.transform 12 269 env37944 = env37945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37944 == env37945) = true)

theorem identity37945 : scanCanonicalize (H12AffineFastState.compose env37945 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37945 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37946 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,16384,21761,21510,5392,2308,1024,21760,17680,21760,16,21763,269,16,23808,5392,4097,2309,20484,21760,256,21760,16384,513]

theorem envBound37946 : H12AffineFastState.Bounded env37946 := by
  intro p hp
  have h : env37946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37945_37946 : H12AffineEnvironment.transform 4 1 env37945 = env37946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37945 == env37946) = true)

theorem identity37946 : scanCanonicalize (H12AffineFastState.compose env37946 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37946 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37947 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,16384,21509,21510,5140,2048,1024,21508,17428,21508,16,21511,9,16,23556,5140,4097,2049,20484,21508,4,21508,16384,513]

theorem envBound37947 : H12AffineFastState.Bounded env37947 := by
  intro p hp
  have h : env37947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37946_37947 : H12AffineEnvironment.transform 7 4 env37946 = env37947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37946 == env37947) = true)

theorem identity37947 : scanCanonicalize (H12AffineFastState.compose env37947 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3093) := by decide +kernel

theorem selectedBound37947 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37948 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,3093,6160,6163,5140,2048,1024,6161,2049,6161,16,6162,9,16,4113,5140,4097,2049,7185,6161,4,6161,3093,513]

theorem envBound37948 : H12AffineFastState.Bounded env37948 := by
  intro p hp
  have h : env37948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37947_37948 : H12AffineEnvironment.transform 13 3093 env37947 = env37948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3093 env37947 == env37948) = true)

theorem identity37948 : scanCanonicalize (H12AffineFastState.compose env37948 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37948 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37949 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,4096,9,1044,4113,4114,5140,1,1024,4112,0,4112,16,4115,9,16,4113,5140,4097,0,5136,4112,4,4112,1044,513]

theorem envBound37949 : H12AffineFastState.Bounded env37949 := by
  intro p hp
  have h : env37949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37948_37949 : H12AffineEnvironment.transform 10 1 env37948 = env37949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37948 == env37949) = true)

theorem identity37949 : scanCanonicalize (H12AffineFastState.compose env37949 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1051) := by decide +kernel

theorem selectedBound37949 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env37950 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1051,9,1044,1034,1033,15,1,1024,1035,0,1035,16,1032,9,16,1034,15,1050,0,11,1035,4,1035,1044,513]

theorem envBound37950 : H12AffineFastState.Bounded env37950 := by
  intro p hp
  have h : env37950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37949_37950 : H12AffineEnvironment.transform 11 1051 env37949 = env37950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1051 env37949 == env37950) = true)

def env37951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62540,73857,8328,64,410093,57676,58460,406604,20701,21792,256,21793,46212,96011]

theorem envBound37951 : H12AffineFastState.Bounded env37951 := by
  intro p hp
  have h : env37951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37937_37951 : H12AffineEnvironment.transform 20 17729 env37937 = env37951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env37937 == env37951) = true)

theorem identity37951 : scanCanonicalize (H12AffineFastState.compose env37951 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound37951 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17729,21792,62540,21899,8328,64,410093,57676,58460,406604,20701,21792,256,21793,46212,513]

theorem envBound37952 : H12AffineFastState.Bounded env37952 := by
  intro p hp
  have h : env37952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37951_37952 : H12AffineEnvironment.transform 15 29962 env37951 = env37952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env37951 == env37952) = true)

theorem identity37952 : scanCanonicalize (H12AffineFastState.compose env37952 (packedSelected [11,12,15,18,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound37952 : packedSelected [11,12,15,18,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10400,1024,32769,17729,21792,62540,21899,8328,64,158029,57676,58460,138476,20701,21792,256,21793,46212,513]

theorem envBound37953 : H12AffineFastState.Bounded env37953 := by
  intro p hp
  have h : env37953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37952_37953 : H12AffineEnvironment.transform 17 10400 env37952 = env37953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37952 == env37953) = true)

theorem identity37953 : scanCanonicalize (H12AffineFastState.compose env37953 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound37953 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,5440,10400,1024,32769,17729,21792,62540,21899,8328,64,31757,57676,58460,2476,20701,21792,256,21793,46212,513]

theorem envBound37954 : H12AffineFastState.Bounded env37954 := by
  intro p hp
  have h : env37954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37953_37954 : H12AffineEnvironment.transform 16 5440 env37953 = env37954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env37953 == env37954) = true)

theorem identity37954 : scanCanonicalize (H12AffineFastState.compose env37954 (packedSelected [1,2,4,5,8,9,12,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound37954 : packedSelected [1,2,4,5,8,9,12,15,20,24] rootPS < 2^1333 := by decide +kernel

def env37955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,29962,5440,10400,1024,21761,17729,21792,8524,21899,8328,64,31757,13388,12636,2476,20701,21792,256,21793,24964,513]

theorem envBound37955 : H12AffineFastState.Bounded env37955 := by
  intro p hp
  have h : env37955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37954_37955 : H12AffineEnvironment.transform 14 21760 env37954 = env37955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env37954 == env37955) = true)

theorem identity37955 : scanCanonicalize (H12AffineFastState.compose env37955 (packedSelected [2,12,14,15,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound37955 : packedSelected [2,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env37956 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,29962,5440,10360,1024,21761,17729,21792,8524,21843,8272,64,31757,13388,12636,2420,20485,21792,256,21793,24924,513]

theorem envBound37956 : H12AffineFastState.Bounded env37956 := by
  intro p hp
  have h : env37956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37955_37956 : H12AffineEnvironment.transform 6 88 env37955 = env37956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env37955 == env37956) = true)

theorem identity37956 : scanCanonicalize (H12AffineFastState.compose env37956 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37956 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env37957 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,16384,21760,21590,5440,2340,1024,21761,17729,21792,16,21843,268,64,23889,5392,4096,2420,20485,21792,256,21793,16384,513]

theorem envBound37957 : H12AffineFastState.Bounded env37957 := by
  intro p hp
  have h : env37957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37956_37957 : H12AffineEnvironment.transform 12 348 env37956 = env37957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37956 == env37957) = true)

theorem identity37957 : scanCanonicalize (H12AffineFastState.compose env37957 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37957 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37958 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,21510,5392,2340,1024,21761,17681,21792,16,21763,268,16,23809,5392,4096,2340,20485,21792,256,21793,16384,513]

theorem envBound37958 : H12AffineFastState.Bounded env37958 := by
  intro p hp
  have h : env37958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37957_37958 : H12AffineEnvironment.transform 5 16 env37957 = env37958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37957 == env37958) = true)

theorem identity37958 : scanCanonicalize (H12AffineFastState.compose env37958 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37958 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37959 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,21540,21510,5172,2048,1024,21541,17461,21508,16,21543,40,16,23589,5172,4096,2048,20485,21508,36,21509,16384,513]

theorem envBound37959 : H12AffineFastState.Bounded env37959 := by
  intro p hp
  have h : env37959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37958_37959 : H12AffineEnvironment.transform 7 36 env37958 = env37959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37958 == env37959) = true)

theorem identity37959 : scanCanonicalize (H12AffineFastState.compose env37959 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound37959 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env37960 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4112,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound37960 : H12AffineFastState.Bounded env37960 := by
  intro p hp
  have h : env37960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37959_37960 : H12AffineEnvironment.transform 13 5157 env37959 = env37960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env37959 == env37960) = true)

def env37961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62541,2188736,8328,64,6705549,57676,2138396,406605,2102685,4194304,256,21792,46213,2175563]

theorem envBound37961 : H12AffineFastState.Bounded env37961 := by
  intro p hp
  have h : env37961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37899_37961 : H12AffineEnvironment.transform 22 62541 env37899 = env37961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env37899 == env37961) = true)

def env37962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62541,2188736,8328,64,410093,57676,2138396,406605,2102685,2101344,256,21792,46213,2175563]

theorem envBound37962 : H12AffineFastState.Bounded env37962 := by
  intro p hp
  have h : env37962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37961_37962 : H12AffineEnvironment.transform 21 2101344 env37961 = env37962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env37961 == env37962) = true)

def env37963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73856,8328,64,410093,57676,58460,406605,20701,21792,256,21792,46213,96011]

theorem envBound37963 : H12AffineFastState.Bounded env37963 := by
  intro p hp
  have h : env37963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37962_37963 : H12AffineEnvironment.transform 20 17728 env37962 = env37963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env37962 == env37963) = true)

theorem identity37963 : scanCanonicalize (H12AffineFastState.compose env37963 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37963 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73736,8192,64,409957,57676,58460,406605,20565,21792,256,21792,46093,96011]

theorem envBound37964 : H12AffineFastState.Bounded env37964 := by
  intro p hp
  have h : env37964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37963_37964 : H12AffineEnvironment.transform 6 8 env37963 = env37964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37963 == env37964) = true)

def env37965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,17728,21792,62541,73736,8192,64,158029,57676,58460,138341,20565,21792,256,21792,46093,96011]

theorem envBound37965 : H12AffineFastState.Bounded env37965 := by
  intro p hp
  have h : env37965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37964_37965 : H12AffineEnvironment.transform 17 10280 env37964 = env37965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env37964 == env37965) = true)

theorem identity37965 : scanCanonicalize (H12AffineFastState.compose env37965 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound37965 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1024,32769,17728,21792,62541,21762,8192,64,158029,57676,58460,138341,20565,21792,256,21792,46093,513]

theorem envBound37966 : H12AffineFastState.Bounded env37966 := by
  intro p hp
  have h : env37966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37965_37966 : H12AffineEnvironment.transform 15 29962 env37965 = env37966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env37965 == env37966) = true)

theorem identity37966 : scanCanonicalize (H12AffineFastState.compose env37966 (packedSelected [1,8,10,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound37966 : packedSelected [1,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env37967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,13340,10280,1024,32769,17728,21792,62541,21762,8192,64,23889,57676,58460,10361,20565,21792,256,21792,46093,513]

theorem envBound37967 : H12AffineFastState.Bounded env37967 := by
  intro p hp
  have h : env37967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37966_37967 : H12AffineEnvironment.transform 16 13340 env37966 = env37967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env37966 == env37967) = true)

theorem identity37967 : scanCanonicalize (H12AffineFastState.compose env37967 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound37967 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,29962,13340,10280,1024,21540,17728,21792,8296,21762,8192,64,23889,13673,12409,10361,20565,21792,256,21792,24616,513]

theorem envBound37968 : H12AffineFastState.Bounded env37968 := by
  intro p hp
  have h : env37968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37967_37968 : H12AffineEnvironment.transform 14 21541 env37967 = env37968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env37967 == env37968) = true)

theorem identity37968 : scanCanonicalize (H12AffineFastState.compose env37968 (packedSelected [0,1,4,7,8,9,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound37968 : packedSelected [0,1,4,7,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env37969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11577,14620,6195,13340,10280,1024,14621,10361,14361,8296,14395,8192,64,12392,13673,12409,10361,15724,14361,256,14361,3345,513]

theorem envBound37969 : H12AffineFastState.Bounded env37969 := by
  intro p hp
  have h : env37969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37968_37969 : H12AffineEnvironment.transform 13 11577 env37968 = env37969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env37968 == env37969) = true)

theorem identity37969 : scanCanonicalize (H12AffineFastState.compose env37969 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37969 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env37970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,3173,6208,6195,5440,2420,1024,6209,2341,6469,308,6503,348,64,4404,5173,4389,2341,7216,6469,256,6469,3345,513]

theorem envBound37970 : H12AffineFastState.Bounded env37970 := by
  intro p hp
  have h : env37970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37969_37970 : H12AffineEnvironment.transform 12 348 env37969 = env37970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37969 == env37970) = true)

theorem identity37970 : scanCanonicalize (H12AffineFastState.compose env37970 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37970 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37971 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,3124,6161,6195,5393,2341,1024,6160,2341,6420,308,6454,269,17,4404,5173,4389,2341,7216,6420,256,6420,3345,513]

theorem envBound37971 : H12AffineFastState.Bounded env37971 := by
  intro p hp
  have h : env37971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37970_37971 : H12AffineEnvironment.transform 5 17 env37970 = env37971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37970 == env37971) = true)

theorem identity37971 : scanCanonicalize (H12AffineFastState.compose env37971 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37971 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37972 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,3124,6161,6195,5172,2048,1024,6160,2048,6193,17,6163,40,17,4113,5173,4096,2048,7216,6193,37,6193,3124,513]

theorem envBound37972 : H12AffineFastState.Bounded env37972 := by
  intro p hp
  have h : env37972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37971_37972 : H12AffineEnvironment.transform 7 37 env37971 = env37972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37971 == env37972) = true)

theorem identity37972 : scanCanonicalize (H12AffineFastState.compose env37972 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound37972 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37973 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,3124,2081,2051,1028,2048,1024,2080,2048,2049,17,2083,40,17,33,1029,48,2048,3072,2049,37,2049,3124,513]

theorem envBound37973 : H12AffineFastState.Bounded env37973 := by
  intro p hp
  have h : env37973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37972_37973 : H12AffineEnvironment.transform 11 48 env37972 = env37973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37972 == env37973) = true)

theorem identity37973 : scanCanonicalize (H12AffineFastState.compose env37973 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 26) := by decide +kernel

theorem selectedBound37973 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env37974 : List Nat := [2,4,8,16,32,17,8,37,512,26,2048,48,40,2094,2081,2051,30,2048,26,2080,2048,2049,17,2083,40,17,33,31,48,2048,2074,2049,37,2049,2094,513]

theorem envBound37974 : H12AffineFastState.Bounded env37974 := by
  intro p hp
  have h : env37974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37973_37974 : H12AffineEnvironment.transform 9 26 env37973 = env37974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 26 env37973 == env37974) = true)

theorem identity37974 : scanCanonicalize (H12AffineFastState.compose env37974 (packedSelected [0,1,5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound37974 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env37975 : List Nat := [2,4,6,16,32,17,6,37,512,20,2048,48,38,2080,2081,2051,16,2048,20,2080,2048,2049,17,2083,38,17,33,17,48,2048,2068,2049,37,2049,2080,513]

theorem envBound37975 : H12AffineFastState.Bounded env37975 := by
  intro p hp
  have h : env37975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37974_37975 : H12AffineEnvironment.transform 2 6 env37974 = env37975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env37974 == env37975) = true)

theorem identity37975 : scanCanonicalize (H12AffineFastState.compose env37975 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound37975 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37976 : List Nat := [2,4,6,16,32,17,6,37,512,20,33,48,38,1,0,34,16,33,20,1,33,32,17,2,38,17,33,17,48,33,53,32,37,32,1,513]

theorem envBound37976 : H12AffineFastState.Bounded env37976 := by
  intro p hp
  have h : env37976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37975_37976 : H12AffineEnvironment.transform 10 33 env37975 = env37976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env37975 == env37976) = true)

theorem identity37976 : scanCanonicalize (H12AffineFastState.compose env37976 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37977 : List Nat := [2,1,3,16,32,17,3,32,512,17,33,48,35,1,0,34,16,33,17,1,33,32,17,2,35,17,33,17,48,33,48,32,32,32,1,513]

theorem envBound37977 : H12AffineFastState.Bounded env37977 := by
  intro p hp
  have h : env37977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37976_37977 : H12AffineEnvironment.transform 1 1 env37976 = env37977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37976 == env37977) = true)

theorem identity37977 : scanCanonicalize (H12AffineFastState.compose env37977 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37978 : List Nat := [2,1,3,0,32,1,3,32,512,1,33,32,35,1,0,34,0,33,1,1,33,32,1,2,35,1,33,1,32,33,32,32,32,32,1,513]

theorem envBound37978 : H12AffineFastState.Bounded env37978 := by
  intro p hp
  have h : env37978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37977_37978 : H12AffineEnvironment.transform 3 0 env37977 = env37978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37977 == env37978) = true)

theorem identity37978 : scanCanonicalize (H12AffineFastState.compose env37978 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37978 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env37979 : List Nat := [2,1,3,0,0,1,3,0,512,1,1,0,3,1,0,2,0,1,1,1,1,0,1,2,3,1,1,1,0,1,0,0,0,0,1,513]

theorem envBound37979 : H12AffineFastState.Bounded env37979 := by
  intro p hp
  have h : env37979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37978_37979 : H12AffineEnvironment.transform 4 0 env37978 = env37979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37978 == env37979) = true)

theorem identity37979 : scanCanonicalize (H12AffineFastState.compose env37979 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound37979 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37980 : List Nat := [2,1,3,0,0,1,3,0,2,1,1,0,3,1,0,2,0,1,1,1,1,0,1,2,3,1,1,1,0,1,0,0,0,0,1,3]

theorem envBound37980 : H12AffineFastState.Bounded env37980 := by
  intro p hp
  have h : env37980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37979_37980 : H12AffineEnvironment.transform 8 2 env37979 = env37980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env37979 == env37980) = true)

def env37981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,17728,21792,62541,73736,8192,64,158028,57676,58460,138340,20565,21792,256,21792,46093,96011]

theorem envBound37981 : H12AffineFastState.Bounded env37981 := by
  intro p hp
  have h : env37981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37964_37981 : H12AffineEnvironment.transform 17 10281 env37964 = env37981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37964 == env37981) = true)

theorem identity37981 : scanCanonicalize (H12AffineFastState.compose env37981 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37981 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,17728,21792,16,73736,8192,64,158028,5393,4097,138340,20565,21792,256,21792,16464,96011]

theorem envBound37982 : H12AffineFastState.Bounded env37982 := by
  intro p hp
  have h : env37982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37981_37982 : H12AffineEnvironment.transform 14 29789 env37981 = env37982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37981 == env37982) = true)

theorem identity37982 : scanCanonicalize (H12AffineFastState.compose env37982 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound37982 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env37983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5392,10281,1024,29788,17728,21792,16,73736,8192,64,31836,5393,4097,2420,20565,21792,256,21792,16464,96011]

theorem envBound37983 : H12AffineFastState.Bounded env37983 := by
  intro p hp
  have h : env37983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37982_37983 : H12AffineEnvironment.transform 16 5392 env37982 = env37983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env37982 == env37983) = true)

theorem identity37983 : scanCanonicalize (H12AffineFastState.compose env37983 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound37983 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,32,65536,5392,10281,1024,33,12605,8541,16,73736,8192,64,2081,5393,4097,2420,9256,8541,256,8541,13357,66422]

theorem envBound37984 : H12AffineFastState.Bounded env37984 := by
  intro p hp
  have h : env37984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37983_37984 : H12AffineEnvironment.transform 13 13437 env37983 = env37984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env37983 == env37984) = true)

theorem identity37984 : scanCanonicalize (H12AffineFastState.compose env37984 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37984 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37985 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12653,32,65536,4096,10281,272,33,12605,8541,16,73736,8192,64,2081,4097,4097,2420,8504,8541,256,8541,12605,66422]

theorem envBound37985 : H12AffineFastState.Bounded env37985 := by
  intro p hp
  have h : env37985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37984_37985 : H12AffineEnvironment.transform 9 272 env37984 = env37985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37984 == env37985) = true)

theorem identity37985 : scanCanonicalize (H12AffineFastState.compose env37985 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound37985 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37986 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12653,32,375,4096,10281,272,33,12605,8541,16,8575,8192,64,2081,4097,4097,2420,8504,8541,256,8541,12605,513]

theorem envBound37986 : H12AffineFastState.Bounded env37986 := by
  intro p hp
  have h : env37986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37985_37986 : H12AffineEnvironment.transform 15 375 env37985 = env37986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env37985 == env37986) = true)

theorem identity37986 : scanCanonicalize (H12AffineFastState.compose env37986 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound37986 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env37987 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,4096,8192,12653,32,375,4096,8312,272,33,12605,8541,16,8575,8192,64,112,4097,4097,293,8504,8541,256,8541,12605,513]

theorem envBound37987 : H12AffineFastState.Bounded env37987 := by
  intro p hp
  have h : env37987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37986_37987 : H12AffineEnvironment.transform 10 81 env37986 = env37987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env37986 == env37987) = true)

theorem identity37987 : scanCanonicalize (H12AffineFastState.compose env37987 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound37987 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env37988 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,4096,4429,32,32,375,4096,4405,272,33,112,4112,16,4146,4429,64,112,4097,4097,293,4213,4112,256,4112,112,513]

theorem envBound37988 : H12AffineFastState.Bounded env37988 := by
  intro p hp
  have h : env37988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37987_37988 : H12AffineEnvironment.transform 12 4429 env37987 = env37988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env37987 == env37988) = true)

theorem identity37988 : scanCanonicalize (H12AffineFastState.compose env37988 (packedSelected [1,2,3,5,8,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound37988 : packedSelected [1,2,3,5,8,14,15] rootPS < 2^1333 := by decide +kernel

def env37989 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,49,380,32,32,375,49,260,272,33,112,33,16,3,380,64,112,48,48,293,68,33,256,33,112,513]

theorem envBound37989 : H12AffineFastState.Bounded env37989 := by
  intro p hp
  have h : env37989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37988_37989 : H12AffineEnvironment.transform 11 49 env37988 = env37989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37988 == env37989) = true)

theorem identity37989 : scanCanonicalize (H12AffineFastState.compose env37989 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37990 : List Nat := [2,4,8,16,32,64,8,4,512,20,81,49,120,32,32,115,49,0,20,33,112,33,16,3,120,64,112,48,48,33,68,33,4,33,112,513]

theorem envBound37990 : H12AffineFastState.Bounded env37990 := by
  intro p hp
  have h : env37990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37989_37990 : H12AffineEnvironment.transform 7 4 env37989 = env37990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37989 == env37990) = true)

theorem identity37990 : scanCanonicalize (H12AffineFastState.compose env37990 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound37990 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37991 : List Nat := [2,4,8,16,32,64,8,4,81,20,81,49,120,32,32,115,49,0,20,33,112,33,16,3,120,64,112,48,48,33,68,33,4,33,112,80]

theorem envBound37991 : H12AffineFastState.Bounded env37991 := by
  intro p hp
  have h : env37991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37990_37991 : H12AffineEnvironment.transform 8 81 env37990 = env37991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env37990 == env37991) = true)

theorem identity37991 : scanCanonicalize (H12AffineFastState.compose env37991 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound37991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37992 : List Nat := [2,4,8,16,32,32,8,4,49,20,49,49,24,32,32,19,49,0,20,33,16,33,16,3,24,32,16,48,48,33,36,33,4,33,16,48]

theorem envBound37992 : H12AffineFastState.Bounded env37992 := by
  intro p hp
  have h : env37992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37991_37992 : H12AffineEnvironment.transform 5 32 env37991 = env37992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env37991 == env37992) = true)

theorem identity37992 : scanCanonicalize (H12AffineFastState.compose env37992 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37993 : List Nat := [2,4,8,16,1,1,8,4,16,20,16,16,24,1,1,19,16,0,20,0,16,0,16,3,24,1,16,17,17,0,5,0,4,0,16,17]

theorem envBound37993 : H12AffineFastState.Bounded env37993 := by
  intro p hp
  have h : env37993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37992_37993 : H12AffineEnvironment.transform 4 1 env37992 = env37993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37992 == env37993) = true)

theorem identity37993 : scanCanonicalize (H12AffineFastState.compose env37993 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37993 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37994 : List Nat := [2,4,8,1,1,1,8,4,1,5,1,1,9,1,1,2,1,0,5,0,1,0,1,3,9,1,1,0,0,0,5,0,4,0,1,0]

theorem envBound37994 : H12AffineFastState.Bounded env37994 := by
  intro p hp
  have h : env37994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37993_37994 : H12AffineEnvironment.transform 3 1 env37993 = env37994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37993 == env37994) = true)

def env37995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62541,73857,8328,64,410093,57676,58461,406605,20700,21793,256,21792,46213,96010]

theorem envBound37995 : H12AffineFastState.Bounded env37995 := by
  intro p hp
  have h : env37995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37962_37995 : H12AffineEnvironment.transform 20 17729 env37962 = env37995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env37962 == env37995) = true)

theorem identity37995 : scanCanonicalize (H12AffineFastState.compose env37995 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound37995 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1024,32769,17729,21793,62541,73857,8328,64,203846,57676,58461,223718,20700,21793,256,21792,46213,96010]

theorem envBound37996 : H12AffineFastState.Bounded env37996 := by
  intro p hp
  have h : env37996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37995_37996 : H12AffineEnvironment.transform 17 89515 env37995 = env37996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env37995 == env37996) = true)

def env37997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89515,1024,29789,17729,21793,17,73857,8328,64,203846,5392,4097,223718,20700,21793,256,21792,16601,96010]

theorem envBound37997 : H12AffineFastState.Bounded env37997 := by
  intro p hp
  have h : env37997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37996_37997 : H12AffineEnvironment.transform 14 29788 env37996 = env37997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env37996 == env37997) = true)

theorem identity37997 : scanCanonicalize (H12AffineFastState.compose env37997 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound37997 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,5393,89515,1024,29789,17729,21793,17,73857,8328,64,67927,5392,4097,97527,20700,21793,256,21792,16601,96010]

theorem envBound37998 : H12AffineFastState.Bounded env37998 := by
  intro p hp
  have h : env37998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37997_37998 : H12AffineEnvironment.transform 16 5393 env37997 = env37998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env37997 == env37998) = true)

theorem identity37998 : scanCanonicalize (H12AffineFastState.compose env37998 (packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37998 : packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21840,65536,5393,89515,1024,21841,17729,21793,17,65933,388,64,67927,5392,4097,89595,20700,21793,256,21792,16601,87558]

theorem envBound37999 : H12AffineFastState.Bounded env37999 := by
  intro p hp
  have h : env37999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37998_37999 : H12AffineEnvironment.transform 12 268 env37998 = env37999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37998 == env37999) = true)

theorem identity37999 : scanCanonicalize (H12AffineFastState.compose env37999 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound37999 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,217,65536,5393,67618,1024,216,4296,168,17,65933,388,64,67927,5392,4097,67698,1365,168,256,169,5456,66447]

theorem envBound38000 : H12AffineFastState.Bounded env38000 := by
  intro p hp
  have h : env38000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37999_38000 : H12AffineEnvironment.transform 13 5513 env37999 = env38000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env37999 == env38000) = true)

theorem identity38000 : scanCanonicalize (H12AffineFastState.compose env38000 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38000 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38001 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,136,65536,5393,67618,1024,137,4249,168,17,65933,388,17,67846,5392,4097,67619,1284,168,256,169,5377,66447]

theorem envBound38001 : H12AffineFastState.Bounded env38001 := by
  intro p hp
  have h : env38001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38000_38001 : H12AffineEnvironment.transform 5 17 env38000 = env38001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38000 == env38001) = true)

theorem identity38001 : scanCanonicalize (H12AffineFastState.compose env38001 (packedSelected [0,1,2,3,5,8,9,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound38001 : packedSelected [0,1,2,3,5,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env38002 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3108,268,2477,136,65536,2357,67618,1024,137,3261,168,17,65933,388,17,67846,2356,3109,67619,1284,168,256,169,2341,66447]

theorem envBound38002 : H12AffineFastState.Bounded env38002 := by
  intro p hp
  have h : env38002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38001_38002 : H12AffineEnvironment.transform 11 3108 env38001 = env38002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env38001 == env38002) = true)

theorem identity38002 : scanCanonicalize (H12AffineFastState.compose env38002 (packedSelected [0,1,2,4,7,8,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound38002 : packedSelected [0,1,2,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env38003 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3108,268,2477,136,399,2357,2477,1024,137,3261,168,17,2,388,17,2185,2356,3109,2476,1284,168,256,169,2341,512]

theorem envBound38003 : H12AffineFastState.Bounded env38003 := by
  intro p hp
  have h : env38003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38002_38003 : H12AffineEnvironment.transform 15 399 env38002 = env38003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env38002 == env38003) = true)

theorem identity38003 : scanCanonicalize (H12AffineFastState.compose env38003 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound38003 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38004 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,3108,129,2080,136,2,2232,2080,1024,137,3261,168,17,2,9,17,2185,2233,3109,2081,1161,168,141,169,2216,512]

theorem envBound38004 : H12AffineFastState.Bounded env38004 := by
  intro p hp
  have h : env38004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38003_38004 : H12AffineEnvironment.transform 7 141 env38003 = env38004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env38003 == env38004) = true)

theorem identity38004 : scanCanonicalize (H12AffineFastState.compose env38004 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38005 : List Nat := [2,4,8,16,0,17,128,141,512,1024,2048,3076,129,2048,136,2,2200,2048,1024,137,3229,136,17,2,9,17,2185,2201,3077,2049,1161,136,141,137,2184,512]

theorem envBound38005 : H12AffineFastState.Bounded env38005 := by
  intro p hp
  have h : env38005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38004_38005 : H12AffineEnvironment.transform 4 0 env38004 = env38005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38004 == env38005) = true)

def env38006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89515,1024,29788,17729,21793,16,73857,8328,64,203846,5393,4096,223718,20700,21793,256,21792,16600,96010]

theorem envBound38006 : H12AffineFastState.Bounded env38006 := by
  intro p hp
  have h : env38006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37996_38006 : H12AffineEnvironment.transform 14 29789 env37996 = env38006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37996 == env38006) = true)

theorem identity38006 : scanCanonicalize (H12AffineFastState.compose env38006 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound38006 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env38007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,217,65536,131072,76079,1024,216,12741,8613,16,73857,8328,64,203846,5393,4096,204130,9304,8613,256,8612,13404,66446]

theorem envBound38007 : H12AffineFastState.Bounded env38007 := by
  intro p hp
  have h : env38007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38006_38007 : H12AffineEnvironment.transform 13 13444 env38006 = env38007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env38006 == env38007) = true)

def env38008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,65536,131072,76079,1024,80,12621,8493,16,73737,8192,64,203846,5393,4096,204130,9304,8493,256,8492,13404,66310]

theorem envBound38008 : H12AffineFastState.Bounded env38008 := by
  intro p hp
  have h : env38008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38007_38008 : H12AffineEnvironment.transform 6 8 env38007 = env38008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38007 == env38008) = true)

theorem identity38008 : scanCanonicalize (H12AffineFastState.compose env38008 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound38008 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env38009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,65536,79130,76079,1024,80,12621,8493,16,73737,8192,64,10588,5393,4096,10360,9304,8493,256,8492,13404,66310]

theorem envBound38009 : H12AffineFastState.Bounded env38009 := by
  intro p hp
  have h : env38009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38008_38009 : H12AffineEnvironment.transform 16 79130 env38008 = env38009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env38008 == env38009) = true)

theorem identity38009 : scanCanonicalize (H12AffineFastState.compose env38009 (packedSelected [2,3,4,5,6,10,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38009 : packedSelected [2,3,4,5,6,10,20,22] rootPS < 2^1333 := by decide +kernel

def env38010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,8203,5393,2340,1024,80,12621,8493,16,2,8192,64,10588,5393,4096,10360,9304,8493,256,8492,13404,8973]

theorem envBound38010 : H12AffineFastState.Bounded env38010 := by
  intro p hp
  have h : env38010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38009_38010 : H12AffineEnvironment.transform 15 8203 env38009 = env38010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38009 == env38010) = true)

theorem identity38010 : scanCanonicalize (H12AffineFastState.compose env38010 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound38010 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env38011 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13324,81,8203,5221,2128,1024,80,12345,8281,16,2,8192,64,10280,5221,4096,10360,9304,8281,116,8280,13404,8825]

theorem envBound38011 : H12AffineFastState.Bounded env38011 := by
  intro p hp
  have h : env38011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38010_38011 : H12AffineEnvironment.transform 7 116 env38010 = env38011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env38010 == env38011) = true)

theorem identity38011 : scanCanonicalize (H12AffineFastState.compose env38011 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38011 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38012 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5156,81,35,5221,2128,1024,80,4113,113,16,2,40,64,2048,5221,4096,2128,1136,113,116,112,5236,593]

theorem envBound38012 : H12AffineFastState.Bounded env38012 := by
  intro p hp
  have h : env38012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38011_38012 : H12AffineEnvironment.transform 12 40 env38011 = env38012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38011 == env38012) = true)

def env38013 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,8,5124,81,3,5189,2128,1024,80,4113,81,16,2,8,64,2048,5189,4096,2128,1104,81,84,80,5204,593]

theorem envBound38013 : H12AffineFastState.Bounded env38013 := by
  intro p hp
  have h : env38013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38012_38013 : H12AffineEnvironment.transform 4 0 env38012 = env38013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38012 == env38013) = true)

def env38014 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,2112,8,3140,81,3,3077,2128,1024,80,2129,81,16,2,8,64,2048,3077,2112,2128,1104,81,84,80,3092,593]

theorem envBound38014 : H12AffineFastState.Bounded env38014 := by
  intro p hp
  have h : env38014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38013_38014 : H12AffineEnvironment.transform 11 2112 env38013 = env38014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env38013 == env38014) = true)

theorem identity38014 : scanCanonicalize (H12AffineFastState.compose env38014 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38014 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38015 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2064,8,3092,1,3,3077,2048,1024,0,2049,1,16,2,8,16,2048,3077,2064,2048,1024,1,4,0,3092,513]

theorem envBound38015 : H12AffineFastState.Bounded env38015 := by
  intro p hp
  have h : env38015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38014_38015 : H12AffineEnvironment.transform 5 16 env38014 = env38015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38014 == env38015) = true)

def env38016 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1044,1,3,1029,0,1024,0,1,1,16,2,8,16,0,1029,16,0,1024,1,4,0,1044,513]

theorem envBound38016 : H12AffineFastState.Bounded env38016 := by
  intro p hp
  have h : env38016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38015_38016 : H12AffineEnvironment.transform 10 0 env38015 = env38016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38015 == env38016) = true)

def env38017 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1,17,8,1045,1,3,1028,1,1024,0,0,1,16,2,8,16,1,1028,17,1,1024,1,4,0,1045,513]

theorem envBound38017 : H12AffineFastState.Bounded env38017 := by
  intro p hp
  have h : env38017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38015_38017 : H12AffineEnvironment.transform 10 1 env38015 = env38017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38015 == env38017) = true)

theorem identity38017 : scanCanonicalize (H12AffineFastState.compose env38017 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound38017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38018 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,1,1,3,16,1,20,0,0,1,16,2,8,16,1,16,17,1,20,1,4,0,1,513]

theorem envBound38018 : H12AffineFastState.Bounded env38018 := by
  intro p hp
  have h : env38018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38017_38018 : H12AffineEnvironment.transform 9 20 env38017 = env38018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38017 == env38018) = true)

theorem identity38018 : scanCanonicalize (H12AffineFastState.compose env38018 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound38018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38019 : List Nat := [2,4,8,16,0,16,8,4,11,20,1,17,8,1,1,3,16,1,20,0,0,1,16,2,8,16,1,16,17,1,20,1,4,0,1,10]

theorem envBound38019 : H12AffineFastState.Bounded env38019 := by
  intro p hp
  have h : env38019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38018_38019 : H12AffineEnvironment.transform 8 11 env38018 = env38019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env38018 == env38019) = true)

def leafEnv38019 : List Nat := [2,4,8,16,0,16,8,4,11,20,1,17,8,1,1,3,16,1,20,0,0,1,16,2,20,8,1,16,1,16,17,1,20,1,4,0,4,3,1,10,1,0,0]

def active38019 : List Nat := [0,1,2,3]

def tree38019 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38019 : H12WitnessSearch.Good tree38019 := H12GlobalWitnessIndex.good

theorem leafIdentity38019 : H12AffineFastState.composeSystem env38019 rootObs = leafEnv38019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38019 rootObs == leafEnv38019) = true)

theorem terminalChecked38019 : H12PackedTerminal.terminalCheckFast leafEnv38019 active38019 tree38019 = true := by decide +kernel

def env38020 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,2113,8,3141,81,3,3076,2128,1024,80,2128,81,16,2,8,64,2048,3076,2113,2128,1104,81,84,80,3093,593]

theorem envBound38020 : H12AffineFastState.Bounded env38020 := by
  intro p hp
  have h : env38020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38013_38020 : H12AffineEnvironment.transform 11 2113 env38013 = env38020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env38013 == env38020) = true)

def env38021 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2065,8,3093,1,3,3076,2048,1024,0,2048,1,16,2,8,16,2048,3076,2065,2048,1024,1,4,0,3093,513]

theorem envBound38021 : H12AffineFastState.Bounded env38021 := by
  intro p hp
  have h : env38021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38020_38021 : H12AffineEnvironment.transform 5 16 env38020 = env38021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38020 == env38021) = true)

def env38022 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,1,3,1028,0,1024,0,0,1,16,2,8,16,0,1028,17,0,1024,1,4,0,1045,513]

theorem envBound38022 : H12AffineFastState.Bounded env38022 := by
  intro p hp
  have h : env38022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38021_38022 : H12AffineEnvironment.transform 10 0 env38021 = env38022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38021 == env38022) = true)

theorem identity38022 : scanCanonicalize (H12AffineFastState.compose env38022 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38023 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,1,3,17,0,21,0,0,1,16,2,8,16,0,17,17,0,21,1,4,0,0,513]

theorem envBound38023 : H12AffineFastState.Bounded env38023 := by
  intro p hp
  have h : env38023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38022_38023 : H12AffineEnvironment.transform 9 21 env38022 = env38023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38022 == env38023) = true)

def env38024 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1,16,8,1044,1,3,1029,1,1024,0,1,1,16,2,8,16,1,1029,16,1,1024,1,4,0,1044,513]

theorem envBound38024 : H12AffineFastState.Bounded env38024 := by
  intro p hp
  have h : env38024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38021_38024 : H12AffineEnvironment.transform 10 1 env38021 = env38024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38021 == env38024) = true)

def env38025 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,8,0,1,3,17,1,20,0,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,513]

theorem envBound38025 : H12AffineFastState.Bounded env38025 := by
  intro p hp
  have h : env38025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38024_38025 : H12AffineEnvironment.transform 9 20 env38024 = env38025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38024 == env38025) = true)

theorem identity38025 : scanCanonicalize (H12AffineFastState.compose env38025 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound38025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38026 : List Nat := [2,4,8,16,0,16,8,4,11,20,1,16,8,0,1,3,17,1,20,0,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,10]

theorem envBound38026 : H12AffineFastState.Bounded env38026 := by
  intro p hp
  have h : env38026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38025_38026 : H12AffineEnvironment.transform 8 11 env38025 = env38026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env38025 == env38026) = true)

def leafEnv38026 : List Nat := [2,4,8,16,0,16,8,4,11,20,1,16,8,0,1,3,17,1,20,0,1,1,16,2,20,8,1,16,1,17,16,1,20,1,4,0,4,3,0,10,1,1,0]

def active38026 : List Nat := [0,1,2,3]

def tree38026 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38026 : H12WitnessSearch.Good tree38026 := H12GlobalWitnessIndex.good

theorem leafIdentity38026 : H12AffineFastState.composeSystem env38026 rootObs = leafEnv38026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38026 rootObs == leafEnv38026) = true)

theorem terminalChecked38026 : H12PackedTerminal.terminalCheckFast leafEnv38026 active38026 tree38026 = true := by decide +kernel

def env38027 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,8,1,1,3,16,1,21,0,1,1,16,2,8,16,1,16,16,1,21,1,4,0,1,513]

theorem envBound38027 : H12AffineFastState.Bounded env38027 := by
  intro p hp
  have h : env38027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38024_38027 : H12AffineEnvironment.transform 9 21 env38024 = env38027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38024 == env38027) = true)

def env38028 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,2064,8,3092,0,3,3076,2049,1024,1,2049,0,16,2,8,17,2048,3076,2064,2049,1025,0,5,1,3093,512]

theorem envBound38028 : H12AffineFastState.Bounded env38028 := by
  intro p hp
  have h : env38028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38020_38028 : H12AffineEnvironment.transform 5 17 env38020 = env38028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38020 == env38028) = true)

theorem identity38028 : scanCanonicalize (H12AffineFastState.compose env38028 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38028 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38029 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2064,8,2049,0,3,2065,2049,21,1,2049,0,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound38029 : H12AffineFastState.Bounded env38029 := by
  intro p hp
  have h : env38029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38028_38029 : H12AffineEnvironment.transform 9 21 env38028 = env38029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38028 == env38029) = true)

theorem identity38029 : scanCanonicalize (H12AffineFastState.compose env38029 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38030 : List Nat := [2,4,8,16,0,17,8,5,1,21,2048,2064,8,2049,0,3,2065,2049,21,1,2049,0,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,1]

theorem envBound38030 : H12AffineFastState.Bounded env38030 := by
  intro p hp
  have h : env38030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38029_38030 : H12AffineEnvironment.transform 8 1 env38029 = env38030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38029 == env38030) = true)

theorem identity38030 : scanCanonicalize (H12AffineFastState.compose env38030 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound38030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38031 : List Nat := [2,4,8,16,0,17,8,5,1,21,31,15,8,30,0,3,14,30,21,1,30,0,16,2,8,17,31,14,15,30,20,0,5,1,31,1]

theorem envBound38031 : H12AffineFastState.Bounded env38031 := by
  intro p hp
  have h : env38031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38030_38031 : H12AffineEnvironment.transform 10 31 env38030 = env38031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env38030 == env38031) = true)

def leafEnv38031 : List Nat := [2,4,8,16,0,17,8,5,1,21,31,15,8,30,0,3,14,30,21,1,30,0,16,2,20,8,1,17,31,14,15,30,20,0,5,1,4,3,31,1,1,31,0]

def active38031 : List Nat := [0,1,2,3]

def tree38031 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38031 : H12WitnessSearch.Good tree38031 := H12GlobalWitnessIndex.good

theorem leafIdentity38031 : H12AffineFastState.composeSystem env38031 rootObs = leafEnv38031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38031 rootObs == leafEnv38031) = true)

theorem terminalChecked38031 : H12PackedTerminal.terminalCheckFast leafEnv38031 active38031 tree38031 = true := by decide +kernel

end H12CloudChart1