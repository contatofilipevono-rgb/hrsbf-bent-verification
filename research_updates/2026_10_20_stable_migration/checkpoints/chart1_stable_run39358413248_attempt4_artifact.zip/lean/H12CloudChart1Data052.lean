import H12CloudChart1Data051

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound13039 : H12AffineFastState.Bounded env13039 := by
  intro p hp
  have h : env13039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13038_13039 : H12AffineEnvironment.transform 14 372 env13038 = env13039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env13038 == env13039) = true)

theorem identity13039 : scanCanonicalize (H12AffineFastState.compose env13039 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13039 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,372,342,5220,2049,1025,373,4161,340,17,374,349,64,2048,5393,4469,2420,1365,340,257,341,5156,513]

theorem envBound13040 : H12AffineFastState.Bounded env13040 := by
  intro p hp
  have h : env13040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13039_13040 : H12AffineEnvironment.transform 13 5237 env13039 = env13040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13039 == env13040) = true)

def env13041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169352,95497,8328,64,2049,163976,45524,284041,156817,411973,257,21792,46213,213830]

theorem envBound13041 : H12AffineFastState.Bounded env13041 := by
  intro p hp
  have h : env13041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13017_13041 : H12AffineEnvironment.transform 21 272513 env13017 = env13041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13017 == env13041) = true)

def env13042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169216,95497,8192,64,2049,163840,45404,283905,156697,411973,257,21792,46093,213830]

theorem envBound13042 : H12AffineFastState.Bounded env13042 := by
  intro p hp
  have h : env13042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13041_13042 : H12AffineEnvironment.transform 6 8 env13041 = env13042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13041 == env13042) = true)

def env13043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,16,95497,8192,64,2049,5392,45404,283905,61705,318549,257,21792,46093,120406]

theorem envBound13043 : H12AffineFastState.Bounded env13043 := by
  intro p hp
  have h : env13043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13042_13043 : H12AffineEnvironment.transform 16 38160 env13042 = env13043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13042 == env13043) = true)

theorem identity13043 : scanCanonicalize (H12AffineFastState.compose env13043 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound13043 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,58396,272393,16,41310,8192,64,2049,5392,45404,283905,61705,318549,257,21792,46093,513]

theorem envBound13044 : H12AffineFastState.Bounded env13044 := by
  intro p hp
  have h : env13044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13043_13044 : H12AffineEnvironment.transform 15 54359 env13043 = env13044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env13043 == env13044) = true)

theorem identity13044 : scanCanonicalize (H12AffineFastState.compose env13044 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13044 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,38160,262144,1025,32769,50496,264533,16,32770,348,64,2049,5392,36864,283905,53333,318549,257,21792,38225,513]

theorem envBound13045 : H12AffineFastState.Bounded env13045 := by
  intro p hp
  have h : env13045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13044_13045 : H12AffineEnvironment.transform 12 348 env13044 = env13045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13044 == env13045) = true)

theorem identity13045 : scanCanonicalize (H12AffineFastState.compose env13045 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13045 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,38160,262144,1025,32769,36928,264533,16,32770,348,64,2049,5392,36864,262145,34133,297301,257,32,38225,513]

theorem envBound13046 : H12AffineFastState.Bounded env13046 := by
  intro p hp
  have h : env13046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13045_13046 : H12AffineEnvironment.transform 13 5376 env13045 = env13046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13045 == env13046) = true)

theorem identity13046 : scanCanonicalize (H12AffineFastState.compose env13046 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound13046 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,38160,2421,1025,32769,36928,32,16,32770,348,64,2049,5392,36864,2420,34133,32800,257,32,38225,513]

theorem envBound13047 : H12AffineFastState.Bounded env13047 := by
  intro p hp
  have h : env13047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13046_13047 : H12AffineEnvironment.transform 17 2421 env13046 = env13047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env13046 == env13047) = true)

theorem identity13047 : scanCanonicalize (H12AffineFastState.compose env13047 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13047 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13048 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4112,32768,33111,36864,2421,273,32769,36928,32,16,32770,348,64,2049,4096,36864,2420,32837,32800,257,32,36929,513]

theorem envBound13048 : H12AffineFastState.Bounded env13048 := by
  intro p hp
  have h : env13048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13047_13048 : H12AffineEnvironment.transform 9 272 env13047 = env13048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13047 == env13048) = true)

theorem identity13048 : scanCanonicalize (H12AffineFastState.compose env13048 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound13048 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env13049 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4112,2129,2310,6225,2421,273,2128,6161,32,16,2131,348,64,2049,4096,6225,2420,2068,2161,257,32,6160,513]

theorem envBound13049 : H12AffineFastState.Bounded env13049 := by
  intro p hp
  have h : env13049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13048_13049 : H12AffineEnvironment.transform 14 2129 env13048 = env13049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env13048 == env13049) = true)

theorem identity13049 : scanCanonicalize (H12AffineFastState.compose env13049 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound13049 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env13050 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,17,348,1,2129,2310,2112,2421,273,2128,2048,32,16,2131,348,64,2049,17,2112,2420,2068,2161,257,32,2049,513]

theorem envBound13050 : H12AffineFastState.Bounded env13050 := by
  intro p hp
  have h : env13050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13049_13050 : H12AffineEnvironment.transform 11 17 env13049 = env13050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env13049 == env13050) = true)

theorem identity13050 : scanCanonicalize (H12AffineFastState.compose env13050 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound13050 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13051 : List Nat := [2,4,8,16,32,64,8,256,512,272,293,17,348,1,372,35,357,80,273,373,293,32,16,374,348,64,292,17,357,81,305,340,257,32,292,513]

theorem envBound13051 : H12AffineFastState.Bounded env13051 := by
  intro p hp
  have h : env13051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13050_13051 : H12AffineEnvironment.transform 10 293 env13050 = env13051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env13050 == env13051) = true)

theorem identity13051 : scanCanonicalize (H12AffineFastState.compose env13051 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13051 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env13052 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,17,121,1,81,35,64,80,52,80,0,32,16,83,121,64,1,17,64,81,20,113,36,32,1,513]

theorem envBound13052 : H12AffineFastState.Bounded env13052 := by
  intro p hp
  have h : env13052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13051_13052 : H12AffineEnvironment.transform 7 37 env13051 = env13052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13051 == env13052) = true)

theorem identity13052 : scanCanonicalize (H12AffineFastState.compose env13052 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13052 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13053 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,17,41,1,1,35,16,0,52,0,0,32,16,3,41,16,1,17,16,1,20,33,36,32,1,513]

theorem envBound13053 : H12AffineFastState.Bounded env13053 := by
  intro p hp
  have h : env13053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13052_13053 : H12AffineEnvironment.transform 5 16 env13052 = env13053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13052 == env13053) = true)

theorem identity13053 : scanCanonicalize (H12AffineFastState.compose env13053 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound13053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13054 : List Nat := [2,4,8,16,32,16,8,37,49,53,0,17,41,1,1,35,16,0,52,0,0,32,16,3,41,16,1,17,16,1,20,33,36,32,1,48]

theorem envBound13054 : H12AffineFastState.Bounded env13054 := by
  intro p hp
  have h : env13054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13053_13054 : H12AffineEnvironment.transform 8 49 env13053 = env13054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env13053 == env13054) = true)

theorem identity13054 : scanCanonicalize (H12AffineFastState.compose env13054 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13055 : List Nat := [2,4,8,16,16,16,8,21,1,5,0,17,25,1,1,19,16,0,4,0,0,16,16,3,25,16,1,17,16,1,20,17,20,16,1,0]

theorem envBound13055 : H12AffineFastState.Bounded env13055 := by
  intro p hp
  have h : env13055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13054_13055 : H12AffineEnvironment.transform 4 16 env13054 = env13055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13054 == env13055) = true)

def env13056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95497,8192,64,2049,5393,45404,283905,61704,318548,257,21792,46093,120407]

theorem envBound13056 : H12AffineFastState.Bounded env13056 := by
  intro p hp
  have h : env13056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13042_13056 : H12AffineEnvironment.transform 16 38161 env13042 = env13056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13042 == env13056) = true)

theorem identity13056 : scanCanonicalize (H12AffineFastState.compose env13056 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound13056 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1025,32769,58397,119927,17,95497,8192,64,2049,5393,45404,108927,61704,73770,257,21792,46093,120407]

theorem envBound13057 : H12AffineFastState.Bounded env13057 := by
  intro p hp
  have h : env13057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13056_13057 : H12AffineEnvironment.transform 17 130174 env13056 = env13057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env13056 == env13057) = true)

theorem identity13057 : scanCanonicalize (H12AffineFastState.compose env13057 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound13057 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env13058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,38161,43128,1025,32769,58397,32881,17,8463,8192,64,2049,5393,45404,64889,61704,29740,257,21792,46093,33361]

theorem envBound13058 : H12AffineFastState.Bounded env13058 := by
  intro p hp
  have h : env13058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13057_13058 : H12AffineEnvironment.transform 15 21510 env13057 = env13058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env13057 == env13058) = true)

theorem identity13058 : scanCanonicalize (H12AffineFastState.compose env13058 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound13058 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env13059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,343,38161,43128,1025,32769,45388,32881,17,8463,8192,64,2049,5393,45404,43048,42073,8573,257,113,46093,33361]

theorem envBound13059 : H12AffineFastState.Bounded env13059 := by
  intro p hp
  have h : env13059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13058_13059 : H12AffineEnvironment.transform 13 5457 env13058 = env13059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env13058 == env13059) = true)

theorem identity13059 : scanCanonicalize (H12AffineFastState.compose env13059 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13059 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env13060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,32768,343,38161,35108,1025,32769,36880,32881,17,83,348,64,2049,5393,36864,35188,34053,33,257,113,38225,33361]

theorem envBound13060 : H12AffineFastState.Bounded env13060 := by
  intro p hp
  have h : env13060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13059_13060 : H12AffineEnvironment.transform 12 348 env13059 = env13060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13059 == env13060) = true)

theorem identity13060 : scanCanonicalize (H12AffineFastState.compose env13060 (packedSelected [0,1,2,4,5,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 7937) := by decide +kernel

theorem selectedBound13060 : packedSelected [0,1,2,4,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env13061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,7937,343,2576,5669,1025,7936,3857,8048,17,83,348,64,2049,5393,3841,5749,6660,33,257,113,2640,7504]

theorem envBound13061 : H12AffineFastState.Bounded env13061 := by
  intro p hp
  have h : env13061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13060_13061 : H12AffineEnvironment.transform 14 7937 env13060 = env13061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7937 env13060 == env13061) = true)

theorem identity13061 : scanCanonicalize (H12AffineFastState.compose env13061 (packedSelected [4,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound13061 : packedSelected [4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env13062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1077,348,356,2868,343,2576,528,1025,2869,3857,2885,17,83,348,64,2049,292,3841,576,3633,33,257,113,2640,2405]

theorem envBound13062 : H12AffineFastState.Bounded env13062 := by
  intro p hp
  have h : env13062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13061_13062 : H12AffineEnvironment.transform 11 1077 env13061 = env13062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env13061 == env13062) = true)

theorem identity13062 : scanCanonicalize (H12AffineFastState.compose env13062 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound13062 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env13063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,820,1077,348,356,0,343,292,528,1025,1,1061,113,17,83,348,64,821,292,1077,576,1285,33,257,113,356,593]

theorem envBound13063 : H12AffineFastState.Bounded env13063 := by
  intro p hp
  have h : env13063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13062_13063 : H12AffineEnvironment.transform 10 820 env13062 = env13063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env13062 == env13063) = true)

theorem identity13063 : scanCanonicalize (H12AffineFastState.compose env13063 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound13063 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env13064 : List Nat := [2,4,8,16,32,64,8,256,512,833,820,884,348,356,0,343,292,528,832,1,868,113,17,83,348,64,821,292,884,576,580,33,257,113,356,593]

theorem envBound13064 : H12AffineFastState.Bounded env13064 := by
  intro p hp
  have h : env13064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13063_13064 : H12AffineEnvironment.transform 9 833 env13063 = env13064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env13063 == env13064) = true)

theorem identity13064 : scanCanonicalize (H12AffineFastState.compose env13064 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13064 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13065 : List Nat := [2,4,8,16,32,64,8,116,512,565,576,512,40,16,0,35,80,528,564,1,528,113,17,83,40,64,577,80,512,576,580,33,117,113,16,593]

theorem envBound13065 : H12AffineFastState.Bounded env13065 := by
  intro p hp
  have h : env13065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13064_13065 : H12AffineEnvironment.transform 7 116 env13064 = env13065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13064 == env13065) = true)

def env13066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272392,169217,95497,8193,64,2049,163841,45405,283904,156696,411973,257,21792,46092,213830]

theorem envBound13066 : H12AffineFastState.Bounded env13066 := by
  intro p hp
  have h : env13066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13041_13066 : H12AffineEnvironment.transform 6 9 env13041 = env13066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13041 == env13066) = true)

def env13067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95497,8193,64,2049,5393,45405,283904,61704,318549,257,21792,46092,120406]

theorem envBound13067 : H12AffineFastState.Bounded env13067 := by
  intro p hp
  have h : env13067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13066_13067 : H12AffineEnvironment.transform 16 38160 env13066 = env13067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env13066 == env13067) = true)

theorem identity13067 : scanCanonicalize (H12AffineFastState.compose env13067 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound13067 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89378,1025,32769,58396,95530,17,95497,8193,64,2049,5393,45405,67618,61704,98679,257,21792,46092,120406]

theorem envBound13068 : H12AffineFastState.Bounded env13068 := by
  intro p hp
  have h : env13068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13067_13068 : H12AffineEnvironment.transform 17 89378 env13067 = env13068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env13067 == env13068) = true)

theorem identity13068 : scanCanonicalize (H12AffineFastState.compose env13068 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13068 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env13069 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,65536,37941,89095,1025,32769,58396,95247,17,95276,8193,64,2049,5172,45176,67618,61485,98386,36,21509,46092,120406]

theorem envBound13069 : H12AffineFastState.Bounded env13069 := by
  intro p hp
  have h : env13069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13068_13069 : H12AffineEnvironment.transform 7 37 env13068 = env13069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13068 == env13069) = true)

theorem identity13069 : scanCanonicalize (H12AffineFastState.compose env13069 (packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 62510) := by decide +kernel

theorem selectedBound13069 : packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env13070 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,62510,37941,43049,1025,32769,58396,32801,17,32770,8193,64,2049,5172,45176,64524,61485,29820,36,21509,46092,8824]

theorem envBound13070 : H12AffineFastState.Bounded env13070 := by
  intro p hp
  have h : env13070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13069_13070 : H12AffineEnvironment.transform 15 62510 env13069 = env13070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62510 env13069 == env13070) = true)

theorem identity13070 : scanCanonicalize (H12AffineFastState.compose env13070 (packedSelected [3,5,10,11,12,15,16,20,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound13070 : packedSelected [3,5,10,11,12,15,16,20,32] rootPS < 2^1333 := by decide +kernel

def env13071 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29709,35,24632,23588,1025,29708,4113,29740,17,29711,8193,64,2049,5172,17525,2049,1056,29820,36,21509,16385,8824]

theorem envBound13071 : H12AffineFastState.Bounded env13071 := by
  intro p hp
  have h : env13071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13070_13071 : H12AffineEnvironment.transform 14 29709 env13070 = env13071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env13070 == env13071) = true)

theorem identity13071 : scanCanonicalize (H12AffineFastState.compose env13071 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound13071 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env13072 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,8233,35,13340,2048,1025,8232,4113,8200,17,8235,8193,64,2049,5172,4177,2049,1056,8280,36,33,5157,8824]

theorem envBound13072 : H12AffineFastState.Bounded env13072 := by
  intro p hp
  have h : env13072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13071_13072 : H12AffineEnvironment.transform 13 5156 env13071 = env13072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env13071 == env13072) = true)

theorem identity13072 : scanCanonicalize (H12AffineFastState.compose env13072 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13072 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env13073 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8233,35,13340,2048,1025,8232,4113,8200,17,8235,8193,16,2049,5172,4097,2049,1056,8200,36,33,5157,8744]

theorem envBound13073 : H12AffineFastState.Bounded env13073 := by
  intro p hp
  have h : env13073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13072_13073 : H12AffineEnvironment.transform 5 16 env13072 = env13073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13072 == env13073) = true)

def env13074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,16,95497,8193,64,2049,5392,45405,283904,61705,318548,257,21792,46092,120407]

theorem envBound13074 : H12AffineFastState.Bounded env13074 := by
  intro p hp
  have h : env13074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13066_13074 : H12AffineEnvironment.transform 16 38161 env13066 = env13074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env13066 == env13074) = true)

theorem identity13074 : scanCanonicalize (H12AffineFastState.compose env13074 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound13074 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,38161,262144,1025,32769,58397,272392,16,3,8193,64,2049,5392,45405,283904,61705,318548,257,21792,46092,41821]

theorem envBound13075 : H12AffineFastState.Bounded env13075 := by
  intro p hp
  have h : env13075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13074_13075 : H12AffineEnvironment.transform 15 29962 env13074 = env13075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env13074 == env13075) = true)

theorem identity13075 : scanCanonicalize (H12AffineFastState.compose env13075 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound13075 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env13076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,38161,56356,1025,32769,58397,62508,16,3,8193,64,2049,5392,45405,35108,61705,112,257,21792,46092,41821]

theorem envBound13076 : H12AffineFastState.Bounded env13076 := by
  intro p hp
  have h : env13076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13075_13076 : H12AffineEnvironment.transform 17 56356 env13075 = env13076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env13075 == env13076) = true)

theorem identity13076 : scanCanonicalize (H12AffineFastState.compose env13076 (packedSelected [1,3,4,5,8,9,11,12,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound13076 : packedSelected [1,3,4,5,8,9,11,12,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env13077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,343,38161,43129,1025,32769,36928,32881,16,3,8193,64,2049,5392,45405,35108,34132,112,257,8573,46092,41821]

theorem envBound13077 : H12AffineFastState.Bounded env13077 := by
  intro p hp
  have h : env13077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13076_13077 : H12AffineEnvironment.transform 13 13405 env13076 = env13077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env13076 == env13077) = true)

theorem identity13077 : scanCanonicalize (H12AffineFastState.compose env13077 (packedSelected [1,3,4,5,8,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13077 : packedSelected [1,3,4,5,8,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env13078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,343,38161,35109,1025,32769,36928,32881,16,3,349,64,2049,5392,36865,35108,34132,112,257,33,38224,33281]

theorem envBound13078 : H12AffineFastState.Bounded env13078 := by
  intro p hp
  have h : env13078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13077_13078 : H12AffineEnvironment.transform 12 348 env13077 = env13078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13077 == env13078) = true)

theorem identity13078 : scanCanonicalize (H12AffineFastState.compose env13078 (packedSelected [0,1,2,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13078 : packedSelected [0,1,2,5,7,10] rootPS < 2^1333 := by decide +kernel

def env13079 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,32768,34,37988,34896,1025,32769,36928,32881,16,3,40,64,2049,5221,36865,34897,33825,112,116,33,37925,33281]

theorem envBound13079 : H12AffineFastState.Bounded env13079 := by
  intro p hp
  have h : env13079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13078_13079 : H12AffineEnvironment.transform 7 117 env13078 = env13079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13078 == env13079) = true)

theorem identity13079 : scanCanonicalize (H12AffineFastState.compose env13079 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound13079 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13080 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,1,34,5221,2129,1025,0,4161,112,16,3,40,64,2049,5221,4096,2128,1056,112,116,33,5156,512]

theorem envBound13080 : H12AffineFastState.Bounded env13080 := by
  intro p hp
  have h : env13080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13079_13080 : H12AffineEnvironment.transform 14 1 env13079 = env13080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13079 == env13080) = true)

theorem identity13080 : scanCanonicalize (H12AffineFastState.compose env13080 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13080 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13081 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,41,5124,1,34,5141,2081,1025,0,4145,0,16,3,40,48,2049,5141,4096,2080,1056,0,4,33,5156,512]

theorem envBound13081 : H12AffineFastState.Bounded env13081 := by
  intro p hp
  have h : env13081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13080_13081 : H12AffineEnvironment.transform 5 48 env13080 = env13081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13080 == env13081) = true)

theorem identity13081 : scanCanonicalize (H12AffineFastState.compose env13081 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13081 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13082 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,1,3,5141,2048,1025,0,4112,0,16,3,9,17,2049,5141,4096,2049,1025,0,4,0,5125,512]

theorem envBound13082 : H12AffineFastState.Bounded env13082 := by
  intro p hp
  have h : env13082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13081_13082 : H12AffineEnvironment.transform 4 1 env13081 = env13082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13081 == env13082) = true)

theorem identity13082 : scanCanonicalize (H12AffineFastState.compose env13082 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound13082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13083 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,4096,8,4112,1,3,4097,2048,21,0,4112,0,16,3,9,17,2049,4097,4096,2049,21,0,4,0,4113,512]

theorem envBound13083 : H12AffineFastState.Bounded env13083 := by
  intro p hp
  have h : env13083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13082_13083 : H12AffineEnvironment.transform 9 20 env13082 = env13083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13082 == env13083) = true)

def env13084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169353,95496,8328,64,4464768,163977,45525,284040,156817,4350405,257,21792,46213,213830]

theorem envBound13084 : H12AffineFastState.Bounded env13084 := by
  intro p hp
  have h : env13084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13016_13084 : H12AffineEnvironment.transform 22 169353 env13016 = env13084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env13016 == env13084) = true)

def env13085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169353,95496,8328,64,2048,163977,45525,284040,156817,411973,257,21792,46213,213830]

theorem envBound13085 : H12AffineFastState.Bounded env13085 := by
  intro p hp
  have h : env13085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13084_13085 : H12AffineEnvironment.transform 21 272512 env13084 = env13085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13084 == env13085) = true)

theorem identity13085 : scanCanonicalize (H12AffineFastState.compose env13085 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound13085 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272512,62660,95496,8328,64,2048,57796,45525,284040,1500,272392,257,21792,46213,74251]

theorem envBound13086 : H12AffineFastState.Bounded env13086 := by
  intro p hp
  have h : env13086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13085_13086 : H12AffineEnvironment.transform 16 24909 env13085 = env13086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env13085 == env13086) = true)

theorem identity13086 : scanCanonicalize (H12AffineFastState.compose env13086 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13086 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env13087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,4161,272512,62660,21762,8328,64,2048,57796,45525,284040,1500,272392,257,21792,46213,513]

theorem envBound13087 : H12AffineFastState.Bounded env13087 := by
  intro p hp
  have h : env13087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13086_13087 : H12AffineEnvironment.transform 15 8202 env13086 = env13087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13086 == env13087) = true)

theorem identity13087 : scanCanonicalize (H12AffineFastState.compose env13087 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound13087 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env13088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,23669,1025,32769,4161,29941,62660,21762,8328,64,2048,57796,45525,2557,1500,29821,257,21792,46213,513]

theorem envBound13088 : H12AffineFastState.Bounded env13088 := by
  intro p hp
  have h : env13088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13087_13088 : H12AffineEnvironment.transform 17 23669 env13087 = env13088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env13087 == env13088) = true)

theorem identity13088 : scanCanonicalize (H12AffineFastState.compose env13088 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound13088 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env13089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8202,24909,23669,1025,21897,4161,29941,8524,21762,8328,64,2048,13388,25693,2557,1500,29821,257,21792,24845,513]

theorem envBound13089 : H12AffineFastState.Bounded env13089 := by
  intro p hp
  have h : env13089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13088_13089 : H12AffineEnvironment.transform 14 21896 env13088 = env13089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env13088 == env13089) = true)

theorem identity13089 : scanCanonicalize (H12AffineFastState.compose env13089 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound13089 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env13090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,0,8202,13509,2557,1025,1,4161,8573,8524,138,8328,64,2048,13388,12757,2557,1500,8693,257,168,13445,513]

theorem envBound13090 : H12AffineFastState.Bounded env13090 := by
  intro p hp
  have h : env13090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13089_13090 : H12AffineEnvironment.transform 13 5512 env13089 = env13090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env13089 == env13090) = true)

theorem identity13090 : scanCanonicalize (H12AffineFastState.compose env13090 (packedSelected [0,2,6,7,17] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound13090 : packedSelected [0,2,6,7,17] rootPS < 2^1333 := by decide +kernel

def env13091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,357,0,8202,8232,2557,1025,1,1196,8573,8524,138,8328,64,2048,8353,9528,2557,1500,8693,257,168,8296,513]

theorem envBound13091 : H12AffineFastState.Bounded env13091 := by
  intro p hp
  have h : env13091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13090_13091 : H12AffineEnvironment.transform 11 1261 env13090 = env13091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env13090 == env13091) = true)

theorem identity13091 : scanCanonicalize (H12AffineFastState.compose env13091 (packedSelected [3,4,5,6,9,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13091 : packedSelected [3,4,5,6,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env13092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,40,357,0,34,0,2557,1025,1,1196,341,356,138,160,64,2048,137,1296,2557,1500,477,257,168,64,513]

theorem envBound13092 : H12AffineFastState.Bounded env13092 := by
  intro p hp
  have h : env13092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13091_13092 : H12AffineEnvironment.transform 12 40 env13091 = env13092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13091 == env13092) = true)

theorem identity13092 : scanCanonicalize (H12AffineFastState.compose env13092 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound13092 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13093 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1261,40,152,0,34,0,2048,1025,1,1196,168,153,138,160,64,2048,137,1261,2048,1057,32,252,168,64,513]

theorem envBound13093 : H12AffineFastState.Bounded env13093 := by
  intro p hp
  have h : env13093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13092_13093 : H12AffineEnvironment.transform 7 253 env13092 = env13093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env13092 == env13093) = true)

theorem identity13093 : scanCanonicalize (H12AffineFastState.compose env13093 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound13093 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env13094 : List Nat := [2,4,8,16,32,64,128,253,512,1024,137,1261,40,152,0,34,0,137,1025,1,1196,168,153,138,160,64,137,137,1261,137,1057,32,252,168,64,513]

theorem envBound13094 : H12AffineFastState.Bounded env13094 := by
  intro p hp
  have h : env13094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13093_13094 : H12AffineEnvironment.transform 10 137 env13093 = env13094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env13093 == env13094) = true)

theorem identity13094 : scanCanonicalize (H12AffineFastState.compose env13094 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13094 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13095 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1,1125,40,16,0,34,0,1,1025,1,1060,32,17,2,40,64,1,1,1125,1,1057,32,116,32,64,513]

theorem envBound13095 : H12AffineFastState.Bounded env13095 := by
  intro p hp
  have h : env13095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13094_13095 : H12AffineEnvironment.transform 6 8 env13094 = env13095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13094 == env13095) = true)

theorem identity13095 : scanCanonicalize (H12AffineFastState.compose env13095 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound13095 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13096 : List Nat := [2,4,8,16,32,64,8,117,512,111,1,10,40,16,0,34,0,1,110,1,75,32,17,2,40,64,1,1,10,1,78,32,116,32,64,513]

theorem envBound13096 : H12AffineFastState.Bounded env13096 := by
  intro p hp
  have h : env13096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13095_13096 : H12AffineEnvironment.transform 9 111 env13095 = env13096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env13095 == env13096) = true)

theorem identity13096 : scanCanonicalize (H12AffineFastState.compose env13096 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound13096 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13097 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,10,2,16,0,8,0,1,68,1,75,10,17,2,2,64,1,1,10,1,78,10,94,10,64,513]

theorem envBound13097 : H12AffineFastState.Bounded env13097 := by
  intro p hp
  have h : env13097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13096_13097 : H12AffineEnvironment.transform 4 10 env13096 = env13097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env13096 == env13097) = true)

theorem identity13097 : scanCanonicalize (H12AffineFastState.compose env13097 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13097 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env13098 : List Nat := [2,4,8,16,10,16,8,15,512,21,1,10,2,16,0,8,0,1,20,1,27,10,17,2,2,16,1,1,10,1,30,10,14,10,16,513]

theorem envBound13098 : H12AffineFastState.Bounded env13098 := by
  intro p hp
  have h : env13098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13097_13098 : H12AffineEnvironment.transform 5 16 env13097 = env13098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13097 == env13098) = true)

theorem identity13098 : scanCanonicalize (H12AffineFastState.compose env13098 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13099 : List Nat := [2,4,8,10,10,10,8,15,512,15,1,10,2,10,0,8,0,1,14,1,1,10,11,2,2,10,1,1,10,1,4,10,14,10,10,513]

theorem envBound13099 : H12AffineFastState.Bounded env13099 := by
  intro p hp
  have h : env13099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13098_13099 : H12AffineEnvironment.transform 3 10 env13098 = env13099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13098 == env13099) = true)

theorem identity13099 : scanCanonicalize (H12AffineFastState.compose env13099 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound13099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13100 : List Nat := [2,1,8,10,10,10,8,10,512,10,1,10,2,10,0,8,0,1,11,1,1,10,11,2,2,10,1,1,10,1,1,10,11,10,10,513]

theorem envBound13100 : H12AffineFastState.Bounded env13100 := by
  intro p hp
  have h : env13100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13099_13100 : H12AffineEnvironment.transform 1 1 env13099 = env13100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env13099 == env13100) = true)

def env13101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169353,95496,8328,64,2049,163977,45525,284040,156817,411972,257,21792,46213,213830]

theorem envBound13101 : H12AffineFastState.Bounded env13101 := by
  intro p hp
  have h : env13101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13084_13101 : H12AffineEnvironment.transform 21 272513 env13084 = env13101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13084 == env13101) = true)

theorem identity13101 : scanCanonicalize (H12AffineFastState.compose env13101 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound13101 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160012,272513,155996,95496,8328,64,2049,160860,17664,284040,156817,411972,257,21792,16464,213830]

theorem envBound13102 : H12AffineFastState.Bounded env13102 := by
  intro p hp
  have h : env13102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13101_13102 : H12AffineEnvironment.transform 14 29909 env13101 = env13102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env13101 == env13102) = true)

theorem identity13102 : scanCanonicalize (H12AffineFastState.compose env13102 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound13102 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env13103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1025,29908,160012,156132,155996,95496,8328,64,2049,160860,17664,138477,156817,33,257,21792,16464,213830]

theorem envBound13103 : H12AffineFastState.Bounded env13103 := by
  intro p hp
  have h : env13103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13102_13103 : H12AffineEnvironment.transform 17 149861 env13102 = env13103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env13102 == env13103) = true)

def env13104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1025,29788,160012,156012,155996,95496,8192,64,2049,160860,17664,138341,156697,33,257,21792,16464,213830]

theorem envBound13104 : H12AffineFastState.Bounded env13104 := by
  intro p hp
  have h : env13104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13103_13104 : H12AffineEnvironment.transform 6 8 env13103 = env13104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13103 == env13104) = true)

theorem identity13104 : scanCanonicalize (H12AffineFastState.compose env13104 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound13104 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,82247,67618,1025,29788,77899,73771,73755,95496,8192,64,2049,79131,17664,89378,75102,33,257,21792,16464,513]

theorem envBound13105 : H12AffineFastState.Bounded env13105 := by
  intro p hp
  have h : env13105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13104_13105 : H12AffineEnvironment.transform 16 82247 env13104 = env13105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env13104 == env13105) = true)

theorem identity13105 : scanCanonicalize (H12AffineFastState.compose env13105 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound13105 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,343,16400,2421,1025,29788,12572,8572,8524,29791,8192,64,2049,13388,17664,23669,9225,33,257,21792,16464,513]

theorem envBound13106 : H12AffineFastState.Bounded env13106 := by
  intro p hp
  have h : env13106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13105_13106 : H12AffineEnvironment.transform 15 343 env13105 = env13106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env13105 == env13106) = true)

theorem identity13106 : scanCanonicalize (H12AffineFastState.compose env13106 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13106 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,343,5393,2421,1025,8541,12572,8572,8524,8542,8192,64,2049,13388,4097,2420,9225,33,257,33,5457,513]

theorem envBound13107 : H12AffineFastState.Bounded env13107 := by
  intro p hp
  have h : env13107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13106_13107 : H12AffineEnvironment.transform 13 5377 env13106 = env13107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13106 == env13107) = true)

theorem identity13107 : scanCanonicalize (H12AffineFastState.compose env13107 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13107 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env13108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5393,2421,1025,1,4160,32,16,2,348,64,2049,5392,4097,2420,1365,33,257,33,5457,513]

theorem envBound13108 : H12AffineFastState.Bounded env13108 := by
  intro p hp
  have h : env13108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13107_13108 : H12AffineEnvironment.transform 12 348 env13107 = env13108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13107 == env13108) = true)

theorem identity13108 : scanCanonicalize (H12AffineFastState.compose env13108 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13108 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13109 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,348,4404,0,343,4388,2421,52,1,4160,32,16,2,348,64,2049,4389,4097,2420,352,33,257,33,4452,513]

theorem envBound13109 : H12AffineFastState.Bounded env13109 := by
  intro p hp
  have h : env13109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13108_13109 : H12AffineEnvironment.transform 9 53 env13108 = env13109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13108 == env13109) = true)

theorem identity13109 : scanCanonicalize (H12AffineFastState.compose env13109 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13109 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13110 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,41,4161,0,34,4177,2048,52,1,4160,32,16,2,41,64,2049,4176,4097,2049,21,33,116,33,4113,513]

theorem envBound13110 : H12AffineFastState.Bounded env13110 := by
  intro p hp
  have h : env13110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13109_13110 : H12AffineEnvironment.transform 7 117 env13109 = env13110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13109 == env13110) = true)

def env13111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,149861,1025,29789,160012,156013,155996,95496,8193,64,2049,160860,17664,138340,156696,33,257,21792,16464,213830]

theorem envBound13111 : H12AffineFastState.Bounded env13111 := by
  intro p hp
  have h : env13111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13103_13111 : H12AffineEnvironment.transform 6 9 env13103 = env13111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13103 == env13111) = true)

theorem identity13111 : scanCanonicalize (H12AffineFastState.compose env13111 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound13111 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,131072,149861,1025,29789,160012,156013,155996,3,8193,64,2049,160860,17664,138340,156696,33,257,21792,16464,144973]

theorem envBound13112 : H12AffineFastState.Bounded env13112 := by
  intro p hp
  have h : env13112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13111_13112 : H12AffineEnvironment.transform 15 29963 env13111 = env13112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env13111 == env13112) = true)

theorem identity13112 : scanCanonicalize (H12AffineFastState.compose env13112 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13112 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env13113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,131072,138341,1025,8541,140300,144493,144476,3,8193,64,2049,139612,4096,138340,143640,33,257,32,5456,144973]

theorem envBound13113 : H12AffineFastState.Bounded env13113 := by
  intro p hp
  have h : env13113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13112_13113 : H12AffineEnvironment.transform 13 5376 env13112 = env13113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13112 == env13113) = true)

theorem identity13113 : scanCanonicalize (H12AffineFastState.compose env13113 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13113 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,35,131072,138341,1025,373,132132,136261,136308,3,41,64,2049,131444,4096,138340,135472,33,257,32,5456,136805]

theorem envBound13114 : H12AffineFastState.Bounded env13114 := by
  intro p hp
  have h : env13114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13113_13114 : H12AffineEnvironment.transform 12 40 env13113 = env13114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13113 == env13114) = true)

theorem identity13114 : scanCanonicalize (H12AffineFastState.compose env13114 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13114 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env13115 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,81,35,131072,138341,1025,80,132132,136261,136308,3,41,64,2049,131153,4096,138340,135189,33,36,32,5237,136805]

theorem envBound13115 : H12AffineFastState.Bounded env13115 := by
  intro p hp
  have h : env13115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13114_13115 : H12AffineEnvironment.transform 7 37 env13114 = env13115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13114 == env13115) = true)

theorem identity13115 : scanCanonicalize (H12AffineFastState.compose env13115 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound13115 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env13116 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,81,35,2113,5156,1025,80,3173,7172,7221,3,41,64,2049,2064,4096,5157,6228,33,36,32,5237,7716]

theorem envBound13116 : H12AffineFastState.Bounded env13116 := by
  intro p hp
  have h : env13116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13115_13116 : H12AffineEnvironment.transform 16 2113 env13115 = env13116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env13115 == env13116) = true)

theorem identity13116 : scanCanonicalize (H12AffineFastState.compose env13116 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13116 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env13117 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,35,2065,5156,1025,0,3125,7172,7221,3,41,16,2049,2064,4096,5157,6148,33,36,32,5157,7716]

theorem envBound13117 : H12AffineFastState.Bounded env13117 := by
  intro p hp
  have h : env13117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13116_13117 : H12AffineEnvironment.transform 5 16 env13116 = env13117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13116 == env13117) = true)

theorem identity13117 : scanCanonicalize (H12AffineFastState.compose env13117 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13117 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env13118 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,1,35,2065,4112,53,0,2049,6192,6145,3,41,16,2049,2064,4096,4113,6148,33,36,32,4113,6672]

theorem envBound13118 : H12AffineFastState.Bounded env13118 := by
  intro p hp
  have h : env13118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13117_13118 : H12AffineEnvironment.transform 9 52 env13117 = env13118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13117 == env13118) = true)

theorem identity13118 : scanCanonicalize (H12AffineFastState.compose env13118 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2591) := by decide +kernel

theorem selectedBound13118 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env13119 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2591,40,2574,1,35,2065,2575,53,0,2049,559,542,3,41,16,2049,2064,2591,2574,539,33,36,32,2574,15]

theorem envBound13119 : H12AffineFastState.Bounded env13119 := by
  intro p hp
  have h : env13119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13118_13119 : H12AffineEnvironment.transform 11 2591 env13118 = env13119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2591 env13118 == env13119) = true)

theorem identity13119 : scanCanonicalize (H12AffineFastState.compose env13119 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound13119 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13120 : List Nat := [2,4,8,16,32,16,9,37,15,52,2048,2064,40,2049,1,35,2065,2048,53,0,2049,32,17,3,41,16,2049,2064,2064,2049,20,33,36,32,2049,15]

theorem envBound13120 : H12AffineFastState.Bounded env13120 := by
  intro p hp
  have h : env13120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13119_13120 : H12AffineEnvironment.transform 8 15 env13119 = env13120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env13119 == env13120) = true)

theorem identity13120 : scanCanonicalize (H12AffineFastState.compose env13120 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound13120 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13121 : List Nat := [2,4,8,16,32,16,9,37,15,52,4,20,40,5,1,35,21,4,53,0,5,32,17,3,41,16,5,20,20,5,20,33,36,32,5,15]

theorem envBound13121 : H12AffineFastState.Bounded env13121 := by
  intro p hp
  have h : env13121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13120_13121 : H12AffineEnvironment.transform 10 4 env13120 = env13121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env13120 == env13121) = true)

theorem identity13121 : scanCanonicalize (H12AffineFastState.compose env13121 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound13121 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13122 : List Nat := [2,4,8,9,32,9,9,37,15,45,4,13,40,5,1,35,12,4,44,0,5,32,8,3,41,9,5,13,13,5,13,33,36,32,5,15]

theorem envBound13122 : H12AffineFastState.Bounded env13122 := by
  intro p hp
  have h : env13122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13121_13122 : H12AffineEnvironment.transform 3 9 env13121 = env13122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env13121 == env13122) = true)

theorem identity13122 : scanCanonicalize (H12AffineFastState.compose env13122 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13123 : List Nat := [2,4,8,9,1,9,9,4,15,12,4,13,9,5,1,2,12,4,13,0,5,1,8,3,8,9,5,13,13,5,13,0,5,1,5,15]

theorem envBound13123 : H12AffineFastState.Bounded env13123 := by
  intro p hp
  have h : env13123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13122_13123 : H12AffineEnvironment.transform 4 1 env13122 = env13123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13122 == env13123) = true)

theorem identity13123 : scanCanonicalize (H12AffineFastState.compose env13123 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13123 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13124 : List Nat := [2,0,8,9,1,9,9,0,11,8,0,9,9,1,1,2,8,0,9,0,1,1,8,3,8,9,1,9,9,1,9,0,1,1,1,11]

theorem envBound13124 : H12AffineFastState.Bounded env13124 := by
  intro p hp
  have h : env13124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13123_13124 : H12AffineEnvironment.transform 1 0 env13123 = env13124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13123 == env13124) = true)

def env13125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,8388608,8642689,8328,64,4464768,8393985,8528989,8830977,156817,12645453,257,21793,46212,213830]

theorem envBound13125 : H12AffineFastState.Bounded env13125 := by
  intro p hp
  have h : env13125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13015_13125 : H12AffineEnvironment.transform 20 160013 env13015 = env13125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160013 env13015 == env13125) = true)

def env13126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169352,95497,8328,64,4464768,163977,45525,284041,156817,4350405,257,21793,46212,213830]

theorem envBound13126 : H12AffineFastState.Bounded env13126 := by
  intro p hp
  have h : env13126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13125_13126 : H12AffineEnvironment.transform 22 169352 env13125 = env13126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env13125 == env13126) = true)

def env13127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169352,95497,8328,64,2048,163977,45525,284041,156817,411973,257,21793,46212,213830]

theorem envBound13127 : H12AffineFastState.Bounded env13127 := by
  intro p hp
  have h : env13127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13126_13127 : H12AffineEnvironment.transform 21 272512 env13126 = env13127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13126 == env13127) = true)

theorem identity13127 : scanCanonicalize (H12AffineFastState.compose env13127 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound13127 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272512,169352,21763,8328,64,2048,163977,45525,284041,156817,411973,257,21793,46212,156492]

theorem envBound13128 : H12AffineFastState.Bounded env13128 := by
  intro p hp
  have h : env13128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13127_13128 : H12AffineEnvironment.transform 15 8202 env13127 = env13128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env13127 == env13128) = true)

def env13129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272392,169216,21763,8192,64,2048,163841,45405,283905,156697,411973,257,21793,46092,156492]

theorem envBound13129 : H12AffineFastState.Bounded env13129 := by
  intro p hp
  have h : env13129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13128_13129 : H12AffineEnvironment.transform 6 8 env13128 = env13129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13128 == env13129) = true)

theorem identity13129 : scanCanonicalize (H12AffineFastState.compose env13129 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound13129 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env13130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157752,1025,32769,160013,147504,169216,21763,8192,64,2048,163841,45405,146745,156697,8573,257,21793,46092,156492]

theorem envBound13130 : H12AffineFastState.Bounded env13130 := by
  intro p hp
  have h : env13130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13129_13130 : H12AffineEnvironment.transform 17 157752 env13129 = env13130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env13129 == env13130) = true)

theorem identity13130 : scanCanonicalize (H12AffineFastState.compose env13130 (packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound13130 : packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,57677,35189,1025,32769,36928,41341,29773,21763,8192,64,2048,24908,45405,56436,34132,8573,257,21793,46092,33281]

theorem envBound13131 : H12AffineFastState.Bounded env13131 := by
  intro p hp
  have h : env13131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13130_13131 : H12AffineEnvironment.transform 16 57677 env13130 = env13131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env13130 == env13131) = true)

theorem identity13131 : scanCanonicalize (H12AffineFastState.compose env13131 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound13131 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env13132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,13388,23668,1025,21760,17729,29820,29773,21763,8192,64,2048,24908,25692,2421,20565,8573,257,21793,24845,22272]

theorem envBound13132 : H12AffineFastState.Bounded env13132 := by
  intro p hp
  have h : env13132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13131_13132 : H12AffineEnvironment.transform 14 21761 env13131 = env13132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env13131 == env13132) = true)

theorem identity13132 : scanCanonicalize (H12AffineFastState.compose env13132 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound13132 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,373,8202,13388,2048,1025,372,4405,8200,8249,375,8192,64,2048,13624,12328,2421,1057,8573,257,341,13689,884]

theorem envBound13133 : H12AffineFastState.Bounded env13133 := by
  intro p hp
  have h : env13133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13132_13133 : H12AffineEnvironment.transform 13 5236 env13132 = env13133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env13132 == env13133) = true)

theorem identity13133 : scanCanonicalize (H12AffineFastState.compose env13133 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13133 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13134 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,0,8202,13388,2048,1025,1,4160,8200,8249,2,8192,64,2048,13389,12328,2048,1057,8200,116,32,13324,513]

theorem envBound13134 : H12AffineFastState.Bounded env13134 := by
  intro p hp
  have h : env13134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13133_13134 : H12AffineEnvironment.transform 7 117 env13133 = env13134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13133 == env13134) = true)

theorem identity13134 : scanCanonicalize (H12AffineFastState.compose env13134 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5196) := by decide +kernel

theorem selectedBound13134 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env13135 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,5196,5236,0,5190,0,2048,1025,1,4160,5188,5237,2,5196,64,2048,1,1124,2048,1057,5188,116,32,64,513]

theorem envBound13135 : H12AffineFastState.Bounded env13135 := by
  intro p hp
  have h : env13135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13134_13135 : H12AffineEnvironment.transform 12 5196 env13134 = env13135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5196 env13134 == env13135) = true)

theorem identity13135 : scanCanonicalize (H12AffineFastState.compose env13135 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound13135 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env13136 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3173,2089,2065,0,2083,0,2048,1025,1,3109,2081,2064,2,2089,64,2048,1,1124,2048,1057,2081,116,32,64,513]

theorem envBound13136 : H12AffineFastState.Bounded env13136 := by
  intro p hp
  have h : env13136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13135_13136 : H12AffineEnvironment.transform 11 3173 env13135 = env13136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env13135 == env13136) = true)

theorem identity13136 : scanCanonicalize (H12AffineFastState.compose env13136 (packedSelected [6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13136 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env13137 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3125,2089,2065,0,2083,0,2048,1025,1,3109,2081,2064,2,2089,16,2048,1,1076,2048,1057,2081,36,32,16,513]

theorem envBound13137 : H12AffineFastState.Bounded env13137 := by
  intro p hp
  have h : env13137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13136_13137 : H12AffineEnvironment.transform 5 16 env13136 = env13137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13136 == env13137) = true)

theorem identity13137 : scanCanonicalize (H12AffineFastState.compose env13137 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound13137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13138 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1061,16,1036,1076,0,1030,0,1061,1025,1,0,1028,1077,2,1036,16,1061,1,1076,1061,1057,1028,36,32,16,513]

theorem envBound13138 : H12AffineFastState.Bounded env13138 := by
  intro p hp
  have h : env13138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13137_13138 : H12AffineEnvironment.transform 10 1061 env13137 = env13138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env13137 == env13138) = true)

def env13139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272393,169217,21763,8193,64,2048,163840,45404,283904,156696,411973,257,21793,46093,156492]

theorem envBound13139 : H12AffineFastState.Bounded env13139 := by
  intro p hp
  have h : env13139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13128_13139 : H12AffineEnvironment.transform 6 9 env13128 = env13139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13128 == env13139) = true)

theorem identity13139 : scanCanonicalize (H12AffineFastState.compose env13139 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 16741) := by decide +kernel

theorem selectedBound13139 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env13140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16741,262144,1025,32769,12392,272393,54372,21763,8193,64,2048,49509,45404,283904,9597,264224,257,21793,46093,8745]

theorem envBound13140 : H12AffineFastState.Bounded env13140 := by
  intro p hp
  have h : env13140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13139_13140 : H12AffineEnvironment.transform 16 16741 env13139 = env13140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16741 env13139 == env13140) = true)

theorem identity13140 : scanCanonicalize (H12AffineFastState.compose env13140 (packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound13140 : packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS < 2^1333 := by decide +kernel

def env13141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,8202,16741,262144,1025,372,12392,272393,21777,21763,8193,64,2048,16400,12329,283904,9597,264224,257,21793,13688,8745]

theorem envBound13141 : H12AffineFastState.Bounded env13141 := by
  intro p hp
  have h : env13141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13140_13141 : H12AffineEnvironment.transform 14 373 env13140 = env13141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env13140 == env13141) = true)

theorem identity13141 : scanCanonicalize (H12AffineFastState.compose env13141 (packedSelected [6,9,16,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound13141 : packedSelected [6,9,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env13142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,8202,16741,23809,1025,372,12392,29960,21777,21763,8193,64,2048,16400,12329,2049,9597,21793,257,21793,13688,8745]

theorem envBound13142 : H12AffineFastState.Bounded env13142 := by
  intro p hp
  have h : env13142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13141_13142 : H12AffineEnvironment.transform 17 23809 env13141 = env13142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env13141 == env13142) = true)

theorem identity13142 : scanCanonicalize (H12AffineFastState.compose env13142 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound13142 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env13143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,373,343,16741,23809,1025,372,4405,21589,21777,21763,348,64,2048,16400,4468,2049,1056,21793,257,21793,5157,884]

theorem envBound13143 : H12AffineFastState.Bounded env13143 := by
  intro p hp
  have h : env13143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13142_13143 : H12AffineEnvironment.transform 12 349 env13142 = env13143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env13142 == env13143) = true)

theorem identity13143 : scanCanonicalize (H12AffineFastState.compose env13143 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound13143 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env13144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,373,343,5392,2420,1025,372,4405,32,356,374,348,64,2048,5221,4468,2049,1056,340,257,340,5157,884]

theorem envBound13144 : H12AffineFastState.Bounded env13144 := by
  intro p hp
  have h : env13144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13143_13144 : H12AffineEnvironment.transform 13 5237 env13143 = env13144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env13143 == env13144) = true)

theorem identity13144 : scanCanonicalize (H12AffineFastState.compose env13144 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound13144 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13145 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4112,373,343,4469,2420,100,372,4405,32,356,374,348,64,2048,4096,4468,2049,69,340,257,340,4160,884]

theorem envBound13145 : H12AffineFastState.Bounded env13145 := by
  intro p hp
  have h : env13145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13144_13145 : H12AffineEnvironment.transform 9 101 env13144 = env13145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env13144 == env13145) = true)

theorem identity13145 : scanCanonicalize (H12AffineFastState.compose env13145 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound13145 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env13146 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,308,349,292,373,343,65,2420,100,372,1,32,356,374,348,64,2048,308,64,2049,69,340,257,340,372,884]

theorem envBound13146 : H12AffineFastState.Bounded env13146 := by
  intro p hp
  have h : env13146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13145_13146 : H12AffineEnvironment.transform 11 308 env13145 = env13146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env13145 == env13146) = true)

theorem identity13146 : scanCanonicalize (H12AffineFastState.compose env13146 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound13146 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env13147 : List Nat := [2,4,8,16,32,64,9,256,512,101,46,308,349,292,373,343,65,346,100,372,1,32,356,374,348,64,46,308,64,47,69,340,257,340,372,884]

theorem envBound13147 : H12AffineFastState.Bounded env13147 := by
  intro p hp
  have h : env13147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13146_13147 : H12AffineEnvironment.transform 10 46 env13146 = env13147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env13146 == env13147) = true)

theorem identity13147 : scanCanonicalize (H12AffineFastState.compose env13147 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound13147 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env13148 : List Nat := [2,4,8,16,32,64,9,11,512,101,46,63,86,47,126,92,65,81,100,127,1,32,111,125,87,64,46,63,64,47,69,95,10,95,127,639]

theorem envBound13148 : H12AffineFastState.Bounded env13148 := by
  intro p hp
  have h : env13148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13147_13148 : H12AffineEnvironment.transform 7 11 env13147 = env13148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env13147 == env13148) = true)

theorem identity13148 : scanCanonicalize (H12AffineFastState.compose env13148 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound13148 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env13149 : List Nat := [2,4,8,16,32,62,9,11,512,27,46,63,40,47,0,34,63,47,26,1,1,32,17,3,41,62,46,63,62,47,59,33,10,33,1,513]

theorem envBound13149 : H12AffineFastState.Bounded env13149 := by
  intro p hp
  have h : env13149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13148_13149 : H12AffineEnvironment.transform 5 62 env13148 = env13149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env13148 == env13149) = true)

theorem identity13149 : scanCanonicalize (H12AffineFastState.compose env13149 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound13149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13150 : List Nat := [2,4,8,16,5,27,9,11,512,27,11,26,13,10,0,7,26,10,26,1,1,5,17,3,12,27,11,26,27,10,30,4,10,4,1,513]

theorem envBound13150 : H12AffineFastState.Bounded env13150 := by
  intro p hp
  have h : env13150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13149_13150 : H12AffineEnvironment.transform 4 5 env13149 = env13150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env13149 == env13150) = true)

theorem identity13150 : scanCanonicalize (H12AffineFastState.compose env13150 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound13150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13151 : List Nat := [2,2,8,16,3,27,9,11,512,27,11,26,11,10,0,1,26,10,26,1,1,3,17,3,10,27,11,26,27,10,24,2,10,2,1,513]

theorem envBound13151 : H12AffineFastState.Bounded env13151 := by
  intro p hp
  have h : env13151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13150_13151 : H12AffineEnvironment.transform 1 2 env13150 = env13151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env13150 == env13151) = true)

theorem identity13151 : scanCanonicalize (H12AffineFastState.compose env13151 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13152 : List Nat := [2,2,8,10,3,1,9,11,512,1,11,0,11,10,0,1,0,10,0,1,1,3,11,3,10,1,11,0,1,10,2,2,10,2,1,513]

theorem envBound13152 : H12AffineFastState.Bounded env13152 := by
  intro p hp
  have h : env13152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13151_13152 : H12AffineEnvironment.transform 3 10 env13151 = env13152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13151 == env13152) = true)

def env13153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169352,95497,8328,64,2049,163977,45525,284041,156817,411972,257,21793,46212,213830]

theorem envBound13153 : H12AffineFastState.Bounded env13153 := by
  intro p hp
  have h : env13153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13126_13153 : H12AffineEnvironment.transform 21 272513 env13126 = env13153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13126 == env13153) = true)

theorem identity13153 : scanCanonicalize (H12AffineFastState.compose env13153 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound13153 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95497,8328,64,2049,79130,45525,284041,119042,392407,257,21793,46212,63189]

theorem envBound13154 : H12AffineFastState.Bounded env13154 := by
  intro p hp
  have h : env13154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13153_13154 : H12AffineEnvironment.transform 16 112019 env13153 = env13154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env13153 == env13154) = true)

def env13155 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95497,8328,16,2049,79130,45445,284041,119042,392327,257,21793,46212,63109]

theorem envBound13155 : H12AffineFastState.Bounded env13155 := by
  intro p hp
  have h : env13155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13154_13155 : H12AffineEnvironment.transform 5 16 env13154 = env13155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13154 == env13155) = true)

theorem identity13155 : scanCanonicalize (H12AffineFastState.compose env13155 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound13155 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env13156 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,76078,1025,32769,115870,65967,73755,95497,8328,16,2049,79130,45445,97447,119042,54697,257,21793,46212,63109]

theorem envBound13156 : H12AffineFastState.Bounded env13156 := by
  intro p hp
  have h : env13156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13155_13156 : H12AffineEnvironment.transform 17 76078 env13155 = env13156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env13155 == env13156) = true)

theorem identity13156 : scanCanonicalize (H12AffineFastState.compose env13156 (packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound13156 : packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS < 2^1333 := by decide +kernel

def env13157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,65536,90259,76078,1025,21761,70046,65967,73755,95497,8328,16,2049,79130,25733,97447,66562,169,257,21793,24964,9093]

theorem envBound13157 : H12AffineFastState.Bounded env13157 := by
  intro p hp
  have h : env13157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13156_13157 : H12AffineEnvironment.transform 14 21760 env13156 = env13157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env13156 == env13157) = true)

theorem identity13157 : scanCanonicalize (H12AffineFastState.compose env13157 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound13157 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env13158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,65536,82199,67754,1025,21761,70046,65967,65951,87181,268,16,2049,70814,17665,89379,66562,169,257,21793,16384,513]

theorem envBound13158 : H12AffineFastState.Bounded env13158 := by
  intro p hp
  have h : env13158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13157_13158 : H12AffineEnvironment.transform 12 388 env13157 = env13158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env13157 == env13158) = true)

theorem identity13158 : scanCanonicalize (H12AffineFastState.compose env13158 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13158 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env13159 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,65536,82199,67618,1025,21761,69910,65831,65815,87045,268,16,2049,70678,17665,89379,66562,33,257,21793,16384,513]

theorem envBound13159 : H12AffineFastState.Bounded env13159 := by
  intro p hp
  have h : env13159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13158_13159 : H12AffineEnvironment.transform 6 8 env13158 = env13159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13158 == env13159) = true)

theorem identity13159 : scanCanonicalize (H12AffineFastState.compose env13159 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound13159 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13160 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,263,16400,2341,1025,21761,4113,32,16,21762,268,16,2049,5393,17665,23588,1285,33,257,21793,16384,513]

theorem envBound13160 : H12AffineFastState.Bounded env13160 := by
  intro p hp
  have h : env13160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13159_13160 : H12AffineEnvironment.transform 15 263 env13159 = env13160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env13159 == env13160) = true)

theorem identity13160 : scanCanonicalize (H12AffineFastState.compose env13160 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13160 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13161 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1025,1,4113,32,16,2,268,16,2049,5393,4097,2340,1285,33,257,33,5376,513]

theorem envBound13161 : H12AffineFastState.Bounded env13161 := by
  intro p hp
  have h : env13161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13160_13161 : H12AffineEnvironment.transform 13 5376 env13160 = env13161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13160 == env13161) = true)

theorem identity13161 : scanCanonicalize (H12AffineFastState.compose env13161 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13161 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13162 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4405,0,263,4389,2341,52,1,4113,32,16,2,268,16,2049,4388,4097,2340,304,33,257,33,4405,513]

theorem envBound13162 : H12AffineFastState.Bounded env13162 := by
  intro p hp
  have h : env13162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13161_13162 : H12AffineEnvironment.transform 9 53 env13161 = env13162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13161 == env13162) = true)

def env13163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95497,8328,17,2049,79130,45444,284041,119042,392326,257,21793,46212,63108]

theorem envBound13163 : H12AffineFastState.Bounded env13163 := by
  intro p hp
  have h : env13163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13154_13163 : H12AffineEnvironment.transform 5 17 env13154 = env13163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13154 == env13163) = true)

theorem identity13163 : scanCanonicalize (H12AffineFastState.compose env13163 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound13163 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env13164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,64808,1025,32769,115870,54697,73755,95497,8328,17,2049,79130,45444,43169,119042,65966,257,21793,46212,63108]

theorem envBound13164 : H12AffineFastState.Bounded env13164 := by
  intro p hp
  have h : env13164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13163_13164 : H12AffineEnvironment.transform 17 64808 env13163 = env13164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env13163 == env13164) = true)

theorem identity13164 : scanCanonicalize (H12AffineFastState.compose env13164 (packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound13164 : packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env13165 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,112019,43049,1025,32769,102815,32936,73755,73736,8328,17,2049,79130,45444,43169,99331,65966,257,32,46212,41861]

theorem envBound13165 : H12AffineFastState.Bounded env13165 := by
  intro p hp
  have h : env13165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13164_13165 : H12AffineEnvironment.transform 13 5377 env13164 = env13165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env13164 == env13165) = true)

theorem identity13165 : scanCanonicalize (H12AffineFastState.compose env13165 (packedSelected [1,3,5,8,10,16,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound13165 : packedSelected [1,3,5,8,10,16,20,26] rootPS < 2^1333 := by decide +kernel

def env13166 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8322,38161,43049,1025,32769,45341,32936,153,138,8328,17,2049,5528,45444,43169,42113,8492,257,32,46212,41861]

theorem envBound13166 : H12AffineFastState.Bounded env13166 := by
  intro p hp
  have h : env13166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13165_13166 : H12AffineEnvironment.transform 15 8322 env13165 = env13166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env13165 == env13166) = true)

theorem identity13166 : scanCanonicalize (H12AffineFastState.compose env13166 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13166 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env13167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,32768,399,38161,35108,1025,32769,36880,32936,153,138,389,17,2049,5528,37001,35244,34188,33,257,32,38281,33416]

theorem envBound13167 : H12AffineFastState.Bounded env13167 := by
  intro p hp
  have h : env13167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13166_13167 : H12AffineEnvironment.transform 12 269 env13166 = env13167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13166 == env13167) = true)

theorem identity13167 : scanCanonicalize (H12AffineFastState.compose env13167 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound13167 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env13168 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,136,399,5529,2476,1025,137,4248,32,153,138,389,17,2049,5528,4097,2340,1284,33,257,32,5377,512]

theorem envBound13168 : H12AffineFastState.Bounded env13168 := by
  intro p hp
  have h : env13168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13167_13168 : H12AffineEnvironment.transform 14 136 env13167 = env13168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env13167 == env13168) = true)

theorem identity13168 : scanCanonicalize (H12AffineFastState.compose env13168 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound13168 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13169 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,269,5377,32,295,5425,2308,1025,33,4144,32,49,34,301,17,2049,5424,4097,2340,1284,33,257,32,5377,512]

theorem envBound13169 : H12AffineFastState.Bounded env13169 := by
  intro p hp
  have h : env13169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13168_13169 : H12AffineEnvironment.transform 6 40 env13168 = env13169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13168 == env13169) = true)

theorem identity13169 : scanCanonicalize (H12AffineFastState.compose env13169 (packedSelected [0,1,2,3,5,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13169 : packedSelected [0,1,2,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env13170 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,1,262,5392,2308,1025,0,4113,1,16,3,268,17,2049,5393,4097,2309,1284,0,257,1,5377,512]

theorem envBound13170 : H12AffineFastState.Bounded env13170 := by
  intro p hp
  have h : env13170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13169_13170 : H12AffineEnvironment.transform 4 1 env13169 = env13170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13169 == env13170) = true)

theorem identity13170 : scanCanonicalize (H12AffineFastState.compose env13170 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13170 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13171 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,9,5125,1,2,5140,2048,1025,0,4113,1,16,3,8,17,2049,5141,4097,2049,1024,0,5,1,5125,512]

theorem envBound13171 : H12AffineFastState.Bounded env13171 := by
  intro p hp
  have h : env13171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13170_13171 : H12AffineEnvironment.transform 7 4 env13170 = env13171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13170 == env13171) = true)

def env13172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169353,95496,8328,64,4464768,163976,45524,284040,156817,4350404,257,21793,46212,213830]

theorem envBound13172 : H12AffineFastState.Bounded env13172 := by
  intro p hp
  have h : env13172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13125_13172 : H12AffineEnvironment.transform 22 169353 env13125 = env13172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env13125 == env13172) = true)

def env13173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169353,95496,8328,64,2048,163976,45524,284040,156817,411972,257,21793,46212,213830]

theorem envBound13173 : H12AffineFastState.Bounded env13173 := by
  intro p hp
  have h : env13173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13172_13173 : H12AffineEnvironment.transform 21 272512 env13172 = env13173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env13172 == env13173) = true)

theorem identity13173 : scanCanonicalize (H12AffineFastState.compose env13173 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound13173 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,160013,272512,169353,41431,8328,64,2048,163976,45524,284040,156817,411972,257,21793,46212,169881]

theorem envBound13174 : H12AffineFastState.Bounded env13174 := by
  intro p hp
  have h : env13174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13173_13174 : H12AffineEnvironment.transform 15 54495 env13173 = env13174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env13173 == env13174) = true)

def env13175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272392,169217,41311,8192,64,2048,163840,45404,283904,156697,411972,257,21793,46092,169745]

theorem envBound13175 : H12AffineFastState.Bounded env13175 := by
  intro p hp
  have h : env13175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13174_13175 : H12AffineEnvironment.transform 6 8 env13174 = env13175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13174 == env13175) = true)

theorem identity13175 : scanCanonicalize (H12AffineFastState.compose env13175 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound13175 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env13176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138340,1025,32769,160013,144492,169217,41311,8192,64,2048,163840,45404,149860,156697,21792,257,21793,46092,169745]

theorem envBound13176 : H12AffineFastState.Bounded env13176 := by
  intro p hp
  have h : env13176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13175_13176 : H12AffineEnvironment.transform 17 138340 env13175 = env13176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env13175 == env13176) = true)

theorem identity13176 : scanCanonicalize (H12AffineFastState.compose env13176 (packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound13176 : packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env13177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24908,32040,1025,32769,4161,21792,62541,41311,8192,64,2048,57676,45404,10280,1365,21792,257,21793,46092,63069]

theorem envBound13177 : H12AffineFastState.Bounded env13177 := by
  intro p hp
  have h : env13177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13176_13177 : H12AffineEnvironment.transform 16 24908 env13176 = env13177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env13176 == env13177) = true)

theorem identity13177 : scanCanonicalize (H12AffineFastState.compose env13177 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21873) := by decide +kernel

theorem selectedBound13177 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env13178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21873,294,24908,32040,1025,21872,4161,21792,8508,29742,8192,64,2048,13373,25645,10280,1365,21792,257,21793,24957,9004]

theorem envBound13178 : H12AffineFastState.Bounded env13178 := by
  intro p hp
  have h : env13178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13177_13178 : H12AffineEnvironment.transform 14 21873 env13177 = env13178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21873 env13177 == env13178) = true)

theorem identity13178 : scanCanonicalize (H12AffineFastState.compose env13178 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound13178 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env13179 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,21760,294,24893,32040,1025,21761,4144,21792,8508,29742,8192,49,2048,13373,25645,10280,1316,21792,257,21793,24844,9004]

theorem envBound13179 : H12AffineFastState.Bounded env13179 := by
  intro p hp
  have h : env13179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13178_13179 : H12AffineEnvironment.transform 5 49 env13178 = env13179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env13178 == env13179) = true)

theorem identity13179 : scanCanonicalize (H12AffineFastState.compose env13179 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound13179 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env13180 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,16384,21760,294,16400,23557,1025,21761,4144,21792,17,21763,301,49,2048,5392,17664,2309,1316,21792,257,21793,16417,513]

theorem envBound13180 : H12AffineFastState.Bounded env13180 := by
  intro p hp
  have h : env13180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13179_13180 : H12AffineEnvironment.transform 12 301 env13179 = env13180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env13179 == env13180) = true)

theorem identity13180 : scanCanonicalize (H12AffineFastState.compose env13180 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound13180 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13181 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,5408,32,294,5424,2341,1025,33,4144,0,17,35,301,49,2048,5392,4128,2309,1316,0,257,1,5377,513]

theorem envBound13181 : H12AffineFastState.Bounded env13181 := by
  intro p hp
  have h : env13181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13180_13181 : H12AffineEnvironment.transform 13 5408 env13180 = env13181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env13180 == env13181) = true)

theorem identity13181 : scanCanonicalize (H12AffineFastState.compose env13181 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound13181 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env13182 : List Nat := [2,4,8,16,32,49,8,256,512,1024,309,4096,301,5408,32,294,5424,16,1025,33,4144,0,17,35,301,49,309,5392,4128,48,1316,0,257,1,5377,513]

theorem envBound13182 : H12AffineFastState.Bounded env13182 := by
  intro p hp
  have h : env13182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13181_13182 : H12AffineEnvironment.transform 10 309 env13181 = env13182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env13181 == env13182) = true)

theorem identity13182 : scanCanonicalize (H12AffineFastState.compose env13182 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound13182 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env13183 : List Nat := [2,4,8,16,32,49,8,256,512,1024,309,1312,301,0,32,294,16,16,1025,33,1296,0,17,35,301,49,309,48,1280,48,1316,0,257,1,33,513]

theorem envBound13183 : H12AffineFastState.Bounded env13183 := by
  intro p hp
  have h : env13183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13182_13183 : H12AffineEnvironment.transform 11 1312 env13182 = env13183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env13182 == env13183) = true)

theorem identity13183 : scanCanonicalize (H12AffineFastState.compose env13183 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound13183 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env13184 : List Nat := [2,4,8,16,32,49,8,256,512,800,309,512,301,0,32,294,16,16,801,33,560,0,17,35,301,49,309,48,544,48,516,0,257,1,33,513]

theorem envBound13184 : H12AffineFastState.Bounded env13184 := by
  intro p hp
  have h : env13184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13183_13184 : H12AffineEnvironment.transform 9 800 env13183 = env13184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env13183 == env13184) = true)

theorem identity13184 : scanCanonicalize (H12AffineFastState.compose env13184 (packedSelected [1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound13184 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env13185 : List Nat := [2,4,8,16,32,49,8,256,17,305,309,17,301,0,32,294,16,16,304,33,33,0,17,35,301,49,309,48,49,48,21,0,257,1,33,16]

theorem envBound13185 : H12AffineFastState.Bounded env13185 := by
  intro p hp
  have h : env13185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13184_13185 : H12AffineEnvironment.transform 8 17 env13184 = env13185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env13184 == env13185) = true)

theorem identity13185 : scanCanonicalize (H12AffineFastState.compose env13185 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13186 : List Nat := [2,4,8,16,17,0,8,256,17,256,260,17,284,0,17,279,16,16,257,16,16,0,17,18,284,0,260,1,0,1,21,0,257,1,16,16]

theorem envBound13186 : H12AffineFastState.Bounded env13186 := by
  intro p hp
  have h : env13186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13185_13186 : H12AffineEnvironment.transform 4 17 env13185 = env13186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13185 == env13186) = true)

theorem identity13186 : scanCanonicalize (H12AffineFastState.compose env13186 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13186 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env13187 : List Nat := [2,4,3,16,17,0,3,256,17,256,260,17,279,0,17,279,16,16,257,16,16,0,17,18,279,0,260,1,0,1,21,0,257,1,16,16]

theorem envBound13187 : H12AffineFastState.Bounded env13187 := by
  intro p hp
  have h : env13187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13186_13187 : H12AffineEnvironment.transform 2 3 env13186 = env13187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13186 == env13187) = true)

theorem identity13187 : scanCanonicalize (H12AffineFastState.compose env13187 (packedSelected [9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13187 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env13188 : List Nat := [2,4,3,16,17,0,3,4,17,4,0,17,19,0,17,19,16,16,5,16,16,0,17,18,19,0,0,1,0,1,21,0,5,1,16,16]

theorem envBound13188 : H12AffineFastState.Bounded env13188 := by
  intro p hp
  have h : env13188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13187_13188 : H12AffineEnvironment.transform 7 4 env13187 = env13188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13187 == env13188) = true)

theorem identity13188 : scanCanonicalize (H12AffineFastState.compose env13188 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13188 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13189 : List Nat := [2,4,3,1,0,0,3,4,0,4,0,0,2,0,0,2,1,1,5,1,1,0,0,3,2,0,0,1,0,1,4,0,5,1,1,1]

theorem envBound13189 : H12AffineFastState.Bounded env13189 := by
  intro p hp
  have h : env13189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13188_13189 : H12AffineEnvironment.transform 3 1 env13188 = env13189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13188 == env13189) = true)

def env13190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272393,169216,41310,8193,64,2048,163841,45405,283905,156696,411972,257,21793,46093,169744]

theorem envBound13190 : H12AffineFastState.Bounded env13190 := by
  intro p hp
  have h : env13190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13174_13190 : H12AffineEnvironment.transform 6 9 env13174 = env13190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13174 == env13190) = true)

theorem identity13190 : scanCanonicalize (H12AffineFastState.compose env13190 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound13190 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env13191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46393,262144,1025,32769,50228,272393,8249,41310,8193,64,2048,13624,45405,283905,53537,326781,257,21793,46093,8745]

theorem envBound13191 : H12AffineFastState.Bounded env13191 := by
  intro p hp
  have h : env13191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13190_13191 : H12AffineEnvironment.transform 16 46393 env13190 = env13191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env13190 == env13191) = true)

theorem identity13191 : scanCanonicalize (H12AffineFastState.compose env13191 (packedSelected [1,3,7,10,17,19,20,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound13191 : packedSelected [1,3,7,10,17,19,20,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env13192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46393,35189,1025,32769,50228,41340,8249,41310,8193,64,2048,13624,45405,56436,53537,29960,257,21793,46093,8745]

theorem envBound13192 : H12AffineFastState.Bounded env13192 := by
  intro p hp
  have h : env13192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13191_13192 : H12AffineEnvironment.transform 17 35189 env13191 = env13192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env13191 == env13192) = true)

theorem identity13192 : scanCanonicalize (H12AffineFastState.compose env13192 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13192 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env13193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,37989,35189,1025,32769,50228,32800,357,32770,349,64,2048,5220,36865,56436,53537,21588,257,21793,38225,885]

theorem envBound13193 : H12AffineFastState.Bounded env13193 := by
  intro p hp
  have h : env13193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13192_13193 : H12AffineEnvironment.transform 12 348 env13192 = env13193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13192 == env13193) = true)

theorem identity13193 : scanCanonicalize (H12AffineFastState.compose env13193 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound13193 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env13194 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,32768,54358,37989,34817,1025,32769,50228,32800,17,32770,41,64,2048,5220,36865,56436,53333,21588,117,21589,37925,513]

theorem envBound13194 : H12AffineFastState.Bounded env13194 := by
  intro p hp
  have h : env13194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13193_13194 : H12AffineEnvironment.transform 7 116 env13193 = env13194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env13193 == env13194) = true)

theorem identity13194 : scanCanonicalize (H12AffineFastState.compose env13194 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound13194 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13195 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,21621,35,16400,23668,1025,21620,4161,21589,17,21623,41,64,2048,5220,17524,2049,1056,21588,117,21589,16464,513]

theorem envBound13195 : H12AffineFastState.Bounded env13195 := by
  intro p hp
  have h : env13195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13194_13195 : H12AffineEnvironment.transform 14 21621 env13194 = env13195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env13194 == env13195) = true)

theorem identity13195 : scanCanonicalize (H12AffineFastState.compose env13195 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound13195 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13196 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5157,80,35,5173,2129,1025,81,4161,112,17,82,41,64,2048,5220,4177,2049,1056,113,117,112,5237,513]

theorem envBound13196 : H12AffineFastState.Bounded env13196 := by
  intro p hp
  have h : env13196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13195_13196 : H12AffineEnvironment.transform 13 5157 env13195 = env13196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env13195 == env13196) = true)

theorem identity13196 : scanCanonicalize (H12AffineFastState.compose env13196 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound13196 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13197 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1045,40,48,80,35,32,2129,1025,81,1108,112,17,82,41,64,2048,113,1092,2049,1056,113,117,112,96,513]

theorem envBound13197 : H12AffineFastState.Bounded env13197 := by
  intro p hp
  have h : env13197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13196_13197 : H12AffineEnvironment.transform 11 1045 env13196 = env13197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env13196 == env13197) = true)

theorem identity13197 : scanCanonicalize (H12AffineFastState.compose env13197 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound13197 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env13198 : List Nat := [2,4,8,16,32,48,9,4,512,1024,2048,1045,40,48,32,35,32,2081,1025,33,1060,0,17,34,41,48,2048,1,1076,2049,1056,1,5,0,16,513]

theorem envBound13198 : H12AffineFastState.Bounded env13198 := by
  intro p hp
  have h : env13198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13197_13198 : H12AffineEnvironment.transform 5 48 env13197 = env13198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env13197 == env13198) = true)

theorem identity13198 : scanCanonicalize (H12AffineFastState.compose env13198 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13198 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env13199 : List Nat := [2,4,8,16,32,48,9,4,512,52,2048,33,40,48,32,35,32,2081,53,33,16,0,17,34,41,48,2048,1,0,2049,20,1,5,0,16,513]

theorem envBound13199 : H12AffineFastState.Bounded env13199 := by
  intro p hp
  have h : env13199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13198_13199 : H12AffineEnvironment.transform 9 52 env13198 = env13199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13198 == env13199) = true)

theorem identity13199 : scanCanonicalize (H12AffineFastState.compose env13199 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound13199 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env13200 : List Nat := [2,4,8,16,32,48,9,4,512,52,59,33,40,48,32,35,32,26,53,33,16,0,17,34,41,48,59,1,0,58,20,1,5,0,16,513]

theorem envBound13200 : H12AffineFastState.Bounded env13200 := by
  intro p hp
  have h : env13200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13199_13200 : H12AffineEnvironment.transform 10 59 env13199 = env13200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env13199 == env13200) = true)

theorem identity13200 : scanCanonicalize (H12AffineFastState.compose env13200 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13200 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env13201 : List Nat := [2,4,8,16,32,48,9,4,1,52,59,33,40,48,32,35,32,26,53,33,16,0,17,34,41,48,59,1,0,58,20,1,5,0,16,0]

theorem envBound13201 : H12AffineFastState.Bounded env13201 := by
  intro p hp
  have h : env13201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13200_13201 : H12AffineEnvironment.transform 8 1 env13200 = env13201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13200 == env13201) = true)

theorem identity13201 : scanCanonicalize (H12AffineFastState.compose env13201 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13201 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env13202 : List Nat := [2,4,8,16,0,16,9,4,1,20,27,1,8,16,0,3,0,26,21,1,16,0,17,2,9,16,27,1,0,26,20,1,5,0,16,0]

theorem envBound13202 : H12AffineFastState.Bounded env13202 := by
  intro p hp
  have h : env13202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13201_13202 : H12AffineEnvironment.transform 4 0 env13201 = env13202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13201 == env13202) = true)

def env13203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169353,95496,8328,64,2049,163976,45524,284040,156817,411973,257,21793,46212,213830]

theorem envBound13203 : H12AffineFastState.Bounded env13203 := by
  intro p hp
  have h : env13203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13172_13203 : H12AffineEnvironment.transform 21 272513 env13172 = env13203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env13172 == env13203) = true)

theorem identity13203 : scanCanonicalize (H12AffineFastState.compose env13203 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound13203 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env13204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272513,120014,95496,8328,64,2049,115151,45524,284040,75222,329730,257,21793,46212,513]

theorem envBound13204 : H12AffineFastState.Bounded env13204 := by
  intro p hp
  have h : env13204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13203_13204 : H12AffineEnvironment.transform 16 82247 env13203 = env13204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env13203 == env13204) = true)

def env13205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,119878,95496,8192,64,2049,115015,45404,283904,75102,329730,257,21793,46092,513]

theorem envBound13205 : H12AffineFastState.Bounded env13205 := by
  intro p hp
  have h : env13205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13204_13205 : H12AffineEnvironment.transform 6 8 env13204 = env13205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13204 == env13205) = true)

def env13206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,77898,33,119878,95496,8192,64,2049,115015,45404,32040,75102,73770,257,21793,46092,513]

theorem envBound13206 : H12AffineFastState.Bounded env13206 := by
  intro p hp
  have h : env13206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13205_13206 : H12AffineEnvironment.transform 17 10280 env13205 = env13206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13205 == env13206) = true)

theorem identity13206 : scanCanonicalize (H12AffineFastState.compose env13206 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound13206 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env13207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,5393,10280,1025,32769,25628,33,32784,8542,8192,64,2049,38161,45404,32040,28936,29820,257,21793,46092,513]

theorem envBound13207 : H12AffineFastState.Bounded env13207 := by
  intro p hp
  have h : env13207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13206_13207 : H12AffineEnvironment.transform 15 21590 env13206 = env13207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env13206 == env13207) = true)

theorem identity13207 : scanCanonicalize (H12AffineFastState.compose env13207 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13207 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env13208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21590,5393,10280,1025,1,25628,33,16,8542,8192,64,2049,5393,12636,32040,28936,29820,257,21793,13324,513]

theorem envBound13208 : H12AffineFastState.Bounded env13208 := by
  intro p hp
  have h : env13208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13207_13208 : H12AffineEnvironment.transform 14 0 env13207 = env13208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13207 == env13208) = true)

theorem identity13208 : scanCanonicalize (H12AffineFastState.compose env13208 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13208 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env13209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,21590,5393,2341,1025,1,17681,33,16,83,269,64,2049,5393,4177,23589,20485,21873,257,21793,5377,513]

theorem envBound13209 : H12AffineFastState.Bounded env13209 := by
  intro p hp
  have h : env13209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13208_13209 : H12AffineEnvironment.transform 12 269 env13208 = env13209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13208 == env13209) = true)

theorem identity13209 : scanCanonicalize (H12AffineFastState.compose env13209 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13209 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,0,342,5393,2341,1025,1,4113,33,16,83,269,64,2049,5393,4177,2341,1285,113,257,33,5377,513]

theorem envBound13210 : H12AffineFastState.Bounded env13210 := by
  intro p hp
  have h : env13210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13209_13210 : H12AffineEnvironment.transform 13 5376 env13209 = env13210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13209 == env13210) = true)

def env13211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,77898,32,119878,95496,8192,64,2049,115015,45404,32041,75102,73771,257,21793,46092,513]

theorem envBound13211 : H12AffineFastState.Bounded env13211 := by
  intro p hp
  have h : env13211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13205_13211 : H12AffineEnvironment.transform 17 10281 env13205 = env13211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env13205 == env13211) = true)

theorem identity13211 : scanCanonicalize (H12AffineFastState.compose env13211 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound13211 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1025,32769,58396,32,16,41310,8192,64,2049,5393,45404,32041,61704,62589,257,21793,46092,513]

theorem envBound13212 : H12AffineFastState.Bounded env13212 := by
  intro p hp
  have h : env13212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13211_13212 : H12AffineEnvironment.transform 15 54358 env13211 = env13212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env13211 == env13212) = true)

theorem identity13212 : scanCanonicalize (H12AffineFastState.compose env13212 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound13212 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env13213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,2048,32768,40022,38161,10281,1025,32769,44060,32,16,41310,8192,64,2049,5393,45404,13609,47368,48253,257,7457,46092,513]

theorem envBound13213 : H12AffineFastState.Bounded env13213 := by
  intro p hp
  have h : env13213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13212_13213 : H12AffineEnvironment.transform 13 2048 env13212 = env13213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env13212 == env13213) = true)

theorem identity13213 : scanCanonicalize (H12AffineFastState.compose env13213 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13213 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env13214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,2048,32768,40022,38161,2421,1025,32769,36160,32,16,32770,348,64,2049,5393,36864,5237,38996,40225,257,7457,38224,513]

theorem envBound13214 : H12AffineFastState.Bounded env13214 := by
  intro p hp
  have h : env13214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13213_13214 : H12AffineEnvironment.transform 12 348 env13213 = env13214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13213 == env13214) = true)

theorem identity13214 : scanCanonicalize (H12AffineFastState.compose env13214 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13214 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env13215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,348,1296,32768,37190,38161,1125,1025,32769,32848,32,16,32770,348,64,1297,5393,36864,5237,38212,36913,257,4145,38224,513]

theorem envBound13215 : H12AffineFastState.Bounded env13215 := by
  intro p hp
  have h : env13215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13214_13215 : H12AffineEnvironment.transform 10 1296 env13214 = env13215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env13214 == env13215) = true)

theorem identity13215 : scanCanonicalize (H12AffineFastState.compose env13215 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound13215 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env13216 : List Nat := [2,4,8,16,32,64,8,256,512,273,1,4096,348,1,32768,37190,36864,372,272,32769,32848,32,16,32770,348,64,0,4096,36864,4452,36949,36913,257,4145,36929,513]

theorem envBound13216 : H12AffineFastState.Bounded env13216 := by
  intro p hp
  have h : env13216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13215_13216 : H12AffineEnvironment.transform 9 273 env13215 = env13216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13215 == env13216) = true)

theorem identity13216 : scanCanonicalize (H12AffineFastState.compose env13216 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 4452) := by decide +kernel

theorem selectedBound13216 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13217 : List Nat := [2,4,8,16,32,64,8,256,512,273,1,4096,348,1,4452,34,356,372,272,4453,4404,32,16,4454,348,64,0,4096,356,4452,305,341,257,4145,293,513]

theorem envBound13217 : H12AffineFastState.Bounded env13217 := by
  intro p hp
  have h : env13217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13216_13217 : H12AffineEnvironment.transform 14 4452 env13216 = env13217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4452 env13216 == env13217) = true)

theorem identity13217 : scanCanonicalize (H12AffineFastState.compose env13217 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13217 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env13218 : List Nat := [2,4,8,16,32,64,8,117,512,100,1,4096,41,1,4113,34,17,1,101,4112,4161,32,16,4115,41,64,0,4096,17,4113,68,32,116,4145,80,513]

theorem envBound13218 : H12AffineFastState.Bounded env13218 := by
  intro p hp
  have h : env13218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13217_13218 : H12AffineEnvironment.transform 7 117 env13217 = env13218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13217 == env13218) = true)

theorem identity13218 : scanCanonicalize (H12AffineFastState.compose env13218 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound13218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13219 : List Nat := [2,4,8,16,32,64,8,117,512,100,1,64,41,1,81,34,17,1,101,80,1,32,16,83,41,64,0,64,17,81,68,32,116,113,80,513]

theorem envBound13219 : H12AffineFastState.Bounded env13219 := by
  intro p hp
  have h : env13219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13218_13219 : H12AffineEnvironment.transform 11 64 env13218 = env13219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env13218 == env13219) = true)

theorem identity13219 : scanCanonicalize (H12AffineFastState.compose env13219 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13219 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13220 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,16,41,1,1,34,17,1,53,0,1,32,16,3,41,16,0,16,17,1,20,32,36,33,0,513]

theorem envBound13220 : H12AffineFastState.Bounded env13220 := by
  intro p hp
  have h : env13220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13219_13220 : H12AffineEnvironment.transform 5 16 env13219 = env13220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13219 == env13220) = true)

theorem identity13220 : scanCanonicalize (H12AffineFastState.compose env13220 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound13220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13221 : List Nat := [2,4,8,16,32,16,8,37,33,52,1,16,41,1,1,34,17,1,53,0,1,32,16,3,41,16,0,16,17,1,20,32,36,33,0,32]

theorem envBound13221 : H12AffineFastState.Bounded env13221 := by
  intro p hp
  have h : env13221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13220_13221 : H12AffineEnvironment.transform 8 33 env13220 = env13221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env13220 == env13221) = true)

theorem identity13221 : scanCanonicalize (H12AffineFastState.compose env13221 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13222 : List Nat := [2,4,8,16,0,16,8,5,1,20,1,16,9,1,1,2,17,1,21,0,1,0,16,3,9,16,0,16,17,1,20,0,4,1,0,0]

theorem envBound13222 : H12AffineFastState.Bounded env13222 := by
  intro p hp
  have h : env13222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13221_13222 : H12AffineEnvironment.transform 4 0 env13221 = env13222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13221 == env13222) = true)

def env13223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272392,119879,95496,8193,64,2049,115014,45405,283905,75103,329730,257,21793,46093,513]

theorem envBound13223 : H12AffineFastState.Bounded env13223 := by
  intro p hp
  have h : env13223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13204_13223 : H12AffineEnvironment.transform 6 9 env13204 = env13223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13204 == env13223) = true)

theorem identity13223 : scanCanonicalize (H12AffineFastState.compose env13223 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13223 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,262144,1025,32769,69910,264532,119879,87124,349,64,2049,115014,36865,283905,66563,329730,257,21793,38225,513]

theorem envBound13224 : H12AffineFastState.Bounded env13224 := by
  intro p hp
  have h : env13224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13223_13224 : H12AffineEnvironment.transform 12 348 env13223 = env13224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13223 == env13224) = true)

theorem identity13224 : scanCanonicalize (H12AffineFastState.compose env13224 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound13224 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env13225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,65536,82247,262144,1025,21841,69910,264532,65815,87124,349,64,2049,70678,17745,283905,66563,329730,257,21793,16385,513]

theorem envBound13225 : H12AffineFastState.Bounded env13225 := by
  intro p hp
  have h : env13225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13224_13225 : H12AffineEnvironment.transform 14 21840 env13224 = env13225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env13224 == env13225) = true)

theorem identity13225 : scanCanonicalize (H12AffineFastState.compose env13225 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 89174) := by decide +kernel

theorem selectedBound13225 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,65536,82247,89174,1025,21841,69910,87298,65815,87124,349,64,2049,70678,17745,67927,66563,21588,257,21793,16385,513]

theorem envBound13226 : H12AffineFastState.Bounded env13226 := by
  intro p hp
  have h : env13226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13225_13226 : H12AffineEnvironment.transform 17 89174 env13225 = env13226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89174 env13225 == env13226) = true)

theorem identity13226 : scanCanonicalize (H12AffineFastState.compose env13226 (packedSelected [0,1,4,5,7,8,9,11,14,17,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound13226 : packedSelected [0,1,4,5,7,8,9,11,14,17,18,24] rootPS < 2^1333 := by decide +kernel

def env13227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,80,65536,70727,67926,1025,81,69910,65538,65815,65876,349,64,2049,70678,4177,67927,66563,340,257,33,5377,513]

theorem envBound13227 : H12AffineFastState.Bounded env13227 := by
  intro p hp
  have h : env13227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13226_13227 : H12AffineEnvironment.transform 13 5376 env13226 = env13227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env13226 == env13227) = true)

theorem identity13227 : scanCanonicalize (H12AffineFastState.compose env13227 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13227 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env13228 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,80,65536,69746,67926,52,81,69910,65538,65815,65876,349,64,2049,69667,4177,67927,65590,340,257,33,4404,513]

theorem envBound13228 : H12AffineFastState.Bounded env13228 := by
  intro p hp
  have h : env13228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13227_13228 : H12AffineEnvironment.transform 9 53 env13227 = env13228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13227 == env13228) = true)

theorem identity13228 : scanCanonicalize (H12AffineFastState.compose env13228 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound13228 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env13229 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,80,263,4469,2129,52,81,4113,261,16,83,349,64,2049,4388,4177,2128,305,340,257,33,4404,513]

theorem envBound13229 : H12AffineFastState.Bounded env13229 := by
  intro p hp
  have h : env13229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13228_13229 : H12AffineEnvironment.transform 15 263 env13228 = env13229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env13228 == env13229) = true)

theorem identity13229 : scanCanonicalize (H12AffineFastState.compose env13229 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound13229 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env13230 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,2049,80,263,2113,2129,52,81,2341,261,16,83,349,64,2049,2064,2405,2128,305,340,257,33,2048,513]

theorem envBound13230 : H12AffineFastState.Bounded env13230 := by
  intro p hp
  have h : env13230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13229_13230 : H12AffineEnvironment.transform 11 2356 env13229 = env13230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env13229 == env13230) = true)

theorem identity13230 : scanCanonicalize (H12AffineFastState.compose env13230 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13230 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env13231 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2356,269,2049,1,263,2064,2048,52,0,2341,261,16,2,268,17,2049,2064,2356,2049,305,261,257,33,2048,513]

theorem envBound13231 : H12AffineFastState.Bounded env13231 := by
  intro p hp
  have h : env13231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13230_13231 : H12AffineEnvironment.transform 5 17 env13230 = env13231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13230 == env13231) = true)

theorem identity13231 : scanCanonicalize (H12AffineFastState.compose env13231 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound13231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13232 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2080,25,2049,1,19,2064,2048,52,0,2097,17,16,2,24,17,2049,2064,2080,2049,37,17,21,33,2048,513]

theorem envBound13232 : H12AffineFastState.Bounded env13232 := by
  intro p hp
  have h : env13232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13231_13232 : H12AffineEnvironment.transform 7 20 env13231 = env13232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env13231 == env13232) = true)

theorem identity13232 : scanCanonicalize (H12AffineFastState.compose env13232 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13232 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13233 : List Nat := [2,4,8,16,32,17,9,20,0,53,2048,2080,25,2049,1,19,2064,2048,52,0,2097,17,16,2,24,17,2049,2064,2080,2049,37,17,21,33,2048,1]

theorem envBound13233 : H12AffineFastState.Bounded env13233 := by
  intro p hp
  have h : env13233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13232_13233 : H12AffineEnvironment.transform 8 0 env13232 = env13233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13232 == env13233) = true)

theorem identity13233 : scanCanonicalize (H12AffineFastState.compose env13233 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13233 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13234 : List Nat := [2,4,8,1,32,0,9,5,0,36,2048,2080,8,2049,1,2,2049,2048,37,0,2080,0,1,2,9,0,2049,2049,2080,2049,37,0,4,33,2048,1]

theorem envBound13234 : H12AffineFastState.Bounded env13234 := by
  intro p hp
  have h : env13234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13233_13234 : H12AffineEnvironment.transform 3 1 env13233 = env13234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13233 == env13234) = true)

theorem identity13234 : scanCanonicalize (H12AffineFastState.compose env13234 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13235 : List Nat := [2,4,8,1,0,0,9,5,0,4,2048,2048,8,2049,1,2,2049,2048,5,0,2048,0,1,2,9,0,2049,2049,2048,2049,5,0,4,1,2048,1]

theorem envBound13235 : H12AffineFastState.Bounded env13235 := by
  intro p hp
  have h : env13235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13234_13235 : H12AffineEnvironment.transform 4 0 env13234 = env13235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13234 == env13235) = true)

def env13236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound13236 : H12AffineFastState.Bounded env13236 := by
  intro p hp
  have h : env13236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12743_13236 : H12AffineEnvironment.transform 26 30393345 env12743 = env13236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env12743 == env13236) = true)

def env13237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound13237 : H12AffineFastState.Bounded env13237 := by
  intro p hp
  have h : env13237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13236_13237 : H12AffineEnvironment.transform 18 1024 env13236 = env13237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13236 == env13237) = true)

theorem identity13237 : scanCanonicalize (H12AffineFastState.compose env13237 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188736) := by decide +kernel

theorem selectedBound13237 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env13238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188736,8328,64,15115713,57676,10507600,8830977,10543568,4194304,256,8429933,8405192,10601990]

theorem envBound13238 : H12AffineFastState.Bounded env13238 := by
  intro p hp
  have h : env13238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13237_13238 : H12AffineEnvironment.transform 23 2188736 env13237 = env13238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188736 env13237 == env13238) = true)

def env13239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62540,2188736,8328,64,6705549,57676,2138396,406605,2102684,4194304,256,21793,46212,2175562]

theorem envBound13239 : H12AffineFastState.Bounded env13239 := by
  intro p hp
  have h : env13239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13238_13239 : H12AffineEnvironment.transform 22 62540 env13238 = env13239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env13238 == env13239) = true)

def env13240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62540,2188736,8328,64,410093,57676,2138396,406605,2102684,2101344,256,21793,46212,2175562]

theorem envBound13240 : H12AffineFastState.Bounded env13240 := by
  intro p hp
  have h : env13240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13239_13240 : H12AffineEnvironment.transform 21 2101344 env13239 = env13240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env13239 == env13240) = true)

def env13241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73856,8328,64,410093,57676,58460,406605,20700,21792,256,21793,46212,96010]

theorem envBound13241 : H12AffineFastState.Bounded env13241 := by
  intro p hp
  have h : env13241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13240_13241 : H12AffineEnvironment.transform 20 17728 env13240 = env13241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env13240 == env13241) = true)

theorem identity13241 : scanCanonicalize (H12AffineFastState.compose env13241 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound13241 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,17728,21792,62540,41311,8328,64,410093,57676,58460,406605,20700,21792,256,21793,46212,63189]

theorem envBound13242 : H12AffineFastState.Bounded env13242 := by
  intro p hp
  have h : env13242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13241_13242 : H12AffineEnvironment.transform 15 33247 env13241 = env13242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env13241 == env13242) = true)

theorem identity13242 : scanCanonicalize (H12AffineFastState.compose env13242 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound13242 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env13243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,56436,1024,32769,17728,21792,62540,41311,8328,64,171417,57676,58460,190521,20700,21792,256,21793,46212,63189]

theorem envBound13243 : H12AffineFastState.Bounded env13243 := by
  intro p hp
  have h : env13243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13242_13243 : H12AffineEnvironment.transform 17 56436 env13242 = env13243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env13242 == env13243) = true)

theorem identity13243 : scanCanonicalize (H12AffineFastState.compose env13243 (packedSelected [0,2,4,12,15,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound13243 : packedSelected [0,2,4,12,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env13244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,32768,33247,131072,43096,1024,32769,12652,8460,32864,41311,8328,64,171417,38240,36976,171029,9456,8460,256,8461,46212,33529]

theorem envBound13244 : H12AffineFastState.Bounded env13244 := by
  intro p hp
  have h : env13244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13243_13244 : H12AffineEnvironment.transform 13 13356 env13243 = env13244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env13243 == env13244) = true)

theorem identity13244 : scanCanonicalize (H12AffineFastState.compose env13244 (packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound13244 : packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS < 2^1333 := by decide +kernel

def env13245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,248,295,131072,10400,1024,249,12652,8460,152,8615,8328,64,138593,5528,4232,138477,9456,8460,256,8461,13436,513]

theorem envBound13245 : H12AffineFastState.Bounded env13245 := by
  intro p hp
  have h : env13245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13244_13245 : H12AffineEnvironment.transform 14 248 env13244 = env13245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env13244 == env13245) = true)

theorem identity13245 : scanCanonicalize (H12AffineFastState.compose env13245 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13245 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env13246 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,13324,216,263,131072,10368,1024,217,12620,8460,152,8583,8328,64,138561,5528,4232,138445,9424,8460,256,8461,13404,513]

theorem envBound13246 : H12AffineFastState.Bounded env13246 := by
  intro p hp
  have h : env13246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13245_13246 : H12AffineEnvironment.transform 4 0 env13245 = env13246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13245 == env13246) = true)

theorem identity13246 : scanCanonicalize (H12AffineFastState.compose env13246 (packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13246 : packedSelected [0,1,4,6,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env13247 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,8192,13324,80,263,131072,10248,1024,81,12620,8460,16,8463,8192,64,138561,5392,4096,138309,9304,8460,256,8461,13404,513]

theorem envBound13247 : H12AffineFastState.Bounded env13247 := by
  intro p hp
  have h : env13247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13246_13247 : H12AffineEnvironment.transform 6 8 env13246 = env13247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13246 == env13247) = true)

theorem identity13247 : scanCanonicalize (H12AffineFastState.compose env13247 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound13247 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env13248 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,348,5456,80,263,131072,2388,1024,81,4112,80,16,83,348,64,138561,5392,4096,138309,1284,80,256,81,5376,513]

theorem envBound13248 : H12AffineFastState.Bounded env13248 := by
  intro p hp
  have h : env13248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13247_13248 : H12AffineEnvironment.transform 12 348 env13247 = env13248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env13247 == env13248) = true)

theorem identity13248 : scanCanonicalize (H12AffineFastState.compose env13248 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13248 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env13249 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,5376,0,263,131072,2308,1024,1,4112,0,16,3,268,16,138513,5392,4096,138261,1284,0,256,1,5376,513]

theorem envBound13249 : H12AffineFastState.Bounded env13249 := by
  intro p hp
  have h : env13249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13248_13249 : H12AffineEnvironment.transform 5 16 env13248 = env13249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13248 == env13249) = true)

theorem identity13249 : scanCanonicalize (H12AffineFastState.compose env13249 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound13249 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env13250 : List Nat := [2,4,8,16,0,16,8,256,512,1024,788,4096,268,5376,0,263,131072,528,1024,1,4112,0,16,3,268,16,136709,5392,4096,136961,1284,0,256,1,5376,513]

theorem envBound13250 : H12AffineFastState.Bounded env13250 := by
  intro p hp
  have h : env13250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13249_13250 : H12AffineEnvironment.transform 10 788 env13249 = env13250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env13249 == env13250) = true)

theorem identity13250 : scanCanonicalize (H12AffineFastState.compose env13250 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound13250 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13251 : List Nat := [2,4,8,16,0,16,8,256,512,1024,788,4096,268,5376,0,263,5393,528,1024,1,4112,0,16,3,268,16,788,5392,4096,528,1284,0,256,1,5376,513]

theorem envBound13251 : H12AffineFastState.Bounded env13251 := by
  intro p hp
  have h : env13251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13250_13251 : H12AffineEnvironment.transform 16 5393 env13250 = env13251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env13250 == env13251) = true)

theorem identity13251 : scanCanonicalize (H12AffineFastState.compose env13251 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound13251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13252 : List Nat := [2,4,8,16,0,16,8,256,512,1024,788,260,268,1028,0,263,1045,528,1024,1,276,0,16,3,268,16,788,1044,260,528,1284,0,256,1,1028,513]

theorem envBound13252 : H12AffineFastState.Bounded env13252 := by
  intro p hp
  have h : env13252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13251_13252 : H12AffineEnvironment.transform 11 260 env13251 = env13252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env13251 == env13252) = true)

theorem identity13252 : scanCanonicalize (H12AffineFastState.compose env13252 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 287) := by decide +kernel

theorem selectedBound13252 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13253 : List Nat := [2,4,8,16,0,16,8,256,287,1024,11,260,268,1028,0,263,1045,271,1024,1,276,0,16,3,268,16,11,1044,260,271,1284,0,256,1,1028,286]

theorem envBound13253 : H12AffineFastState.Bounded env13253 := by
  intro p hp
  have h : env13253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13252_13253 : H12AffineEnvironment.transform 8 287 env13252 = env13253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 287 env13252 == env13253) = true)

theorem identity13253 : scanCanonicalize (H12AffineFastState.compose env13253 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 283) := by decide +kernel

theorem selectedBound13253 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13254 : List Nat := [2,4,8,16,0,16,8,256,287,283,11,260,268,287,0,263,270,271,283,1,276,0,16,3,268,16,11,271,260,271,31,0,256,1,287,286]

theorem envBound13254 : H12AffineFastState.Bounded env13254 := by
  intro p hp
  have h : env13254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13253_13254 : H12AffineEnvironment.transform 9 283 env13253 = env13254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 283 env13253 == env13254) = true)

theorem identity13254 : scanCanonicalize (H12AffineFastState.compose env13254 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13254 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env13255 : List Nat := [2,4,2,16,0,16,2,256,277,273,1,260,262,277,0,263,260,261,273,1,276,0,16,3,262,16,1,261,260,261,21,0,256,1,277,276]

theorem envBound13255 : H12AffineFastState.Bounded env13255 := by
  intro p hp
  have h : env13255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13254_13255 : H12AffineEnvironment.transform 2 2 env13254 = env13255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13254 == env13255) = true)

theorem identity13255 : scanCanonicalize (H12AffineFastState.compose env13255 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound13255 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env13256 : List Nat := [2,4,2,7,0,7,2,256,258,262,1,260,262,258,0,263,260,261,262,1,259,0,7,3,262,7,1,261,260,261,2,0,256,1,258,259]

theorem envBound13256 : H12AffineFastState.Bounded env13256 := by
  intro p hp
  have h : env13256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13255_13256 : H12AffineEnvironment.transform 3 7 env13255 = env13256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env13255 == env13256) = true)

def env13257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62540,73857,8328,64,410093,57676,58461,406605,20701,21793,256,21793,46212,96011]

theorem envBound13257 : H12AffineFastState.Bounded env13257 := by
  intro p hp
  have h : env13257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13240_13257 : H12AffineEnvironment.transform 20 17729 env13240 = env13257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env13240 == env13257) = true)

theorem identity13257 : scanCanonicalize (H12AffineFastState.compose env13257 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound13257 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,262144,1024,32769,17729,21793,62540,41431,8328,64,410093,57676,58461,406605,20701,21793,256,21793,46212,63069]

theorem envBound13258 : H12AffineFastState.Bounded env13258 := by
  intro p hp
  have h : env13258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13257_13258 : H12AffineEnvironment.transform 15 33110 env13257 = env13258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env13257 == env13258) = true)

def env13259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10400,1024,32769,17729,21793,62540,41431,8328,64,158029,57676,58461,138477,20701,21793,256,21793,46212,63069]

theorem envBound13259 : H12AffineFastState.Bounded env13259 := by
  intro p hp
  have h : env13259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13258_13259 : H12AffineEnvironment.transform 17 10400 env13258 = env13259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env13258 == env13259) = true)

theorem identity13259 : scanCanonicalize (H12AffineFastState.compose env13259 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound13259 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env13260 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,16384,32768,32906,131072,10400,1024,32769,17565,21757,62540,40971,8328,64,157841,57488,58461,138477,20701,21757,220,21757,46212,63069]

theorem envBound13260 : H12AffineFastState.Bounded env13260 := by
  intro p hp
  have h : env13260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13259_13260 : H12AffineEnvironment.transform 7 220 env13259 = env13260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env13259 == env13260) = true)

theorem identity13260 : scanCanonicalize (H12AffineFastState.compose env13260 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound13260 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env13261 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,16384,29908,29790,131072,10400,1024,29909,17565,21757,152,21727,8328,64,157841,5188,4233,138477,20701,21757,220,21757,16464,649]

theorem envBound13261 : H12AffineFastState.Bounded env13261 := by
  intro p hp
  have h : env13261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13260_13261 : H12AffineEnvironment.transform 14 29908 env13260 = env13261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env13260 == env13261) = true)

def env13262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10401,1024,32769,17729,21793,62540,41431,8328,64,158028,57676,58461,138476,20701,21793,256,21793,46212,63069]

theorem envBound13262 : H12AffineFastState.Bounded env13262 := by
  intro p hp
  have h : env13262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13258_13262 : H12AffineEnvironment.transform 17 10401 env13258 = env13262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env13258 == env13262) = true)

theorem identity13262 : scanCanonicalize (H12AffineFastState.compose env13262 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound13262 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env13263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,32768,33110,131072,10401,1024,32769,4452,260,41065,41431,8328,64,146793,46441,45176,138476,1272,260,256,260,46212,41592]

theorem envBound13263 : H12AffineFastState.Bounded env13263 := by
  intro p hp
  have h : env13263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13262_13263 : H12AffineEnvironment.transform 13 5157 env13262 = env13263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env13262 == env13263) = true)

theorem identity13263 : scanCanonicalize (H12AffineFastState.compose env13263 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound13263 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env13264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,8541,8203,131072,10401,1024,8540,4452,260,308,138,8328,64,146793,5172,4389,138476,1272,260,256,260,5593,805]

theorem envBound13264 : H12AffineFastState.Bounded env13264 := by
  intro p hp
  have h : env13264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13263_13264 : H12AffineEnvironment.transform 14 8541 env13263 = env13264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env13263 == env13264) = true)

theorem identity13264 : scanCanonicalize (H12AffineFastState.compose env13264 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound13264 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env13265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5157,8541,8203,5221,10401,1024,8540,4452,260,308,138,8328,64,10508,5172,4389,2185,1272,260,256,260,5593,805]

theorem envBound13265 : H12AffineFastState.Bounded env13265 := by
  intro p hp
  have h : env13265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13264_13265 : H12AffineEnvironment.transform 16 5221 env13264 = env13265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env13264 == env13265) = true)

theorem identity13265 : scanCanonicalize (H12AffineFastState.compose env13265 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound13265 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env13266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5157,373,35,5221,2185,1024,372,4452,260,308,138,160,64,2340,5172,4389,2185,1272,260,256,260,5593,805]

theorem envBound13266 : H12AffineFastState.Bounded env13266 := by
  intro p hp
  have h : env13266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13265_13266 : H12AffineEnvironment.transform 12 40 env13265 = env13266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env13265 == env13266) = true)

theorem identity13266 : scanCanonicalize (H12AffineFastState.compose env13266 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13266 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env13267 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,40,5157,216,35,5221,2185,1024,217,4297,169,153,138,160,64,2185,5172,4232,2185,1272,169,173,169,5236,648]

theorem envBound13267 : H12AffineFastState.Bounded env13267 := by
  intro p hp
  have h : env13267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13266_13267 : H12AffineEnvironment.transform 7 173 env13266 = env13267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13266 == env13267) = true)

theorem identity13267 : scanCanonicalize (H12AffineFastState.compose env13267 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound13267 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env13268 : List Nat := [2,4,8,16,32,64,128,173,512,1024,81,4096,40,5157,216,35,5221,216,1024,217,4297,169,153,138,160,64,216,5172,4232,216,1272,169,173,169,5236,648]

theorem envBound13268 : H12AffineFastState.Bounded env13268 := by
  intro p hp
  have h : env13268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13267_13268 : H12AffineEnvironment.transform 10 81 env13267 = env13268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env13267 == env13268) = true)

theorem identity13268 : scanCanonicalize (H12AffineFastState.compose env13268 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound13268 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env13269 : List Nat := [2,4,8,16,32,64,128,173,512,1024,81,1197,40,136,216,35,200,216,1024,217,1124,169,153,138,160,64,216,153,1061,216,1272,169,173,169,217,648]

theorem envBound13269 : H12AffineFastState.Bounded env13269 := by
  intro p hp
  have h : env13269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13268_13269 : H12AffineEnvironment.transform 11 1197 env13268 = env13269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env13268 == env13269) = true)

theorem identity13269 : scanCanonicalize (H12AffineFastState.compose env13269 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound13269 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env13270 : List Nat := [2,4,8,16,32,64,89,116,512,1024,81,1140,40,81,1,35,17,1,1024,0,1124,112,64,83,121,64,1,64,1061,1,1057,112,116,112,0,593]

theorem envBound13270 : H12AffineFastState.Bounded env13270 := by
  intro p hp
  have h : env13270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13269_13270 : H12AffineEnvironment.transform 6 89 env13269 = env13270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env13269 == env13270) = true)

theorem identity13270 : scanCanonicalize (H12AffineFastState.compose env13270 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13270 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env13271 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,1061,40,0,1,35,17,1,1024,0,1077,33,17,2,40,17,1,17,1061,1,1057,33,37,33,0,512]

theorem envBound13271 : H12AffineFastState.Bounded env13271 := by
  intro p hp
  have h : env13271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13270_13271 : H12AffineEnvironment.transform 5 17 env13270 = env13271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13270 == env13271) = true)

theorem identity13271 : scanCanonicalize (H12AffineFastState.compose env13271 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13272 : List Nat := [2,4,8,0,32,1,8,37,512,1024,0,1061,40,0,1,35,1,1,1024,0,1061,33,1,2,40,1,1,1,1061,1,1057,33,37,33,0,512]

theorem envBound13272 : H12AffineFastState.Bounded env13272 := by
  intro p hp
  have h : env13272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13271_13272 : H12AffineEnvironment.transform 3 0 env13271 = env13272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13271 == env13272) = true)

theorem identity13272 : scanCanonicalize (H12AffineFastState.compose env13272 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound13272 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13273 : List Nat := [2,4,8,0,32,1,8,37,512,517,0,544,40,0,1,35,1,1,517,0,544,33,1,2,40,1,1,1,544,1,548,33,37,33,0,512]

theorem envBound13273 : H12AffineFastState.Bounded env13273 := by
  intro p hp
  have h : env13273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13272_13273 : H12AffineEnvironment.transform 9 517 env13272 = env13273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env13272 == env13273) = true)

theorem identity13273 : scanCanonicalize (H12AffineFastState.compose env13273 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13273 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13274 : List Nat := [2,4,8,0,0,1,8,5,512,517,0,512,8,0,1,3,1,1,517,0,512,1,1,2,8,1,1,1,512,1,516,1,5,1,0,512]

theorem envBound13274 : H12AffineFastState.Bounded env13274 := by
  intro p hp
  have h : env13274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13273_13274 : H12AffineEnvironment.transform 4 0 env13273 = env13274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13273 == env13274) = true)

theorem identity13274 : scanCanonicalize (H12AffineFastState.compose env13274 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13274 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13275 : List Nat := [2,4,8,0,0,1,8,5,0,5,0,0,8,0,1,3,1,1,5,0,0,1,1,2,8,1,1,1,0,1,4,1,5,1,0,0]

theorem envBound13275 : H12AffineFastState.Bounded env13275 := by
  intro p hp
  have h : env13275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13274_13275 : H12AffineEnvironment.transform 8 0 env13274 = env13275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13274 == env13275) = true)

theorem identity13275 : scanCanonicalize (H12AffineFastState.compose env13275 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound13275 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13276 : List Nat := [2,0,8,0,0,1,8,1,0,1,0,0,8,0,1,3,1,1,1,0,0,1,1,2,8,1,1,1,0,1,0,1,1,1,0,0]

theorem envBound13276 : H12AffineFastState.Bounded env13276 := by
  intro p hp
  have h : env13276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13275_13276 : H12AffineEnvironment.transform 1 0 env13275 = env13276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env13275 == env13276) = true)

def env13277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62540,2188736,8328,64,410092,57676,2138396,406605,2102684,2101345,256,21793,46212,2175562]

theorem envBound13277 : H12AffineFastState.Bounded env13277 := by
  intro p hp
  have h : env13277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13239_13277 : H12AffineEnvironment.transform 21 2101345 env13239 = env13277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env13239 == env13277) = true)

def env13278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62540,73856,8328,64,410092,57676,58460,406605,20700,21793,256,21793,46212,96010]

theorem envBound13278 : H12AffineFastState.Bounded env13278 := by
  intro p hp
  have h : env13278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13277_13278 : H12AffineEnvironment.transform 20 17728 env13277 = env13278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env13277 == env13278) = true)

theorem identity13278 : scanCanonicalize (H12AffineFastState.compose env13278 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound13278 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,262144,1024,32769,17728,21793,62540,21763,8328,64,410092,57676,58460,406605,20700,21793,256,21793,46212,649]

theorem envBound13279 : H12AffineFastState.Bounded env13279 := by
  intro p hp
  have h : env13279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13278_13279 : H12AffineEnvironment.transform 15 30083 env13278 = env13279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env13278 == env13279) = true)

theorem identity13279 : scanCanonicalize (H12AffineFastState.compose env13279 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13279 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,17728,21793,62540,21763,8192,64,409956,57676,58460,406605,20564,21793,256,21793,46092,513]

theorem envBound13280 : H12AffineFastState.Bounded env13280 := by
  intro p hp
  have h : env13280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13279_13280 : H12AffineEnvironment.transform 6 8 env13279 = env13280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13279 == env13280) = true)

theorem identity13280 : scanCanonicalize (H12AffineFastState.compose env13280 (packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound13280 : packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS < 2^1333 := by decide +kernel

def env13281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,146745,1024,32769,17728,21793,62540,21763,8192,64,31837,57676,58460,2420,20564,21793,256,21793,46092,513]

theorem envBound13281 : H12AffineFastState.Bounded env13281 := by
  intro p hp
  have h : env13281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13280_13281 : H12AffineEnvironment.transform 17 146745 env13280 = env13281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env13280 == env13281) = true)

theorem identity13281 : scanCanonicalize (H12AffineFastState.compose env13281 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound13281 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env13282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,131072,146745,1024,29789,17728,21793,16,21763,8192,64,31837,5392,4096,2420,20564,21793,256,21793,16464,513]

theorem envBound13282 : H12AffineFastState.Bounded env13282 := by
  intro p hp
  have h : env13282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13281_13282 : H12AffineEnvironment.transform 14 29788 env13281 = env13282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env13281 == env13282) = true)

def env13283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62540,73857,8328,64,410092,57676,58461,406605,20701,21792,256,21793,46212,96011]

theorem envBound13283 : H12AffineFastState.Bounded env13283 := by
  intro p hp
  have h : env13283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13277_13283 : H12AffineEnvironment.transform 20 17729 env13277 = env13283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env13277 == env13283) = true)

theorem identity13283 : scanCanonicalize (H12AffineFastState.compose env13283 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound13283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env13284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17729,21792,62540,21899,8328,64,410092,57676,58461,406605,20701,21792,256,21793,46212,513]

theorem envBound13284 : H12AffineFastState.Bounded env13284 := by
  intro p hp
  have h : env13284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13283_13284 : H12AffineEnvironment.transform 15 29962 env13283 = env13284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env13283 == env13284) = true)

theorem identity13284 : scanCanonicalize (H12AffineFastState.compose env13284 (packedSelected [11,12,15,18,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound13284 : packedSelected [11,12,15,18,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env13285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10400,1024,32769,17729,21792,62540,21899,8328,64,158028,57676,58461,138477,20701,21792,256,21793,46212,513]

theorem envBound13285 : H12AffineFastState.Bounded env13285 := by
  intro p hp
  have h : env13285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13284_13285 : H12AffineEnvironment.transform 17 10400 env13284 = env13285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env13284 == env13285) = true)

theorem identity13285 : scanCanonicalize (H12AffineFastState.compose env13285 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound13285 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env13286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,29962,131072,10400,1024,8461,17729,21792,21824,21899,8328,64,158028,16448,17745,138477,20701,21792,256,21793,5512,513]

theorem envBound13286 : H12AffineFastState.Bounded env13286 := by
  intro p hp
  have h : env13286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13285_13286 : H12AffineEnvironment.transform 14 8460 env13285 = env13286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env13285 == env13286) = true)

theorem identity13286 : scanCanonicalize (H12AffineFastState.compose env13286 (packedSelected [0,4,6,7,11,14,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13286 : packedSelected [0,4,6,7,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env13287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,0,21510,131072,2476,1024,1,17729,21792,21824,21899,388,64,149568,16448,17745,138477,20701,21792,256,21793,5512,513]

theorem envBound13287 : H12AffineFastState.Bounded env13287 := by
  intro p hp
  have h : env13287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13286_13287 : H12AffineEnvironment.transform 12 268 env13286 = env13287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13286 == env13287) = true)

theorem identity13287 : scanCanonicalize (H12AffineFastState.compose env13287 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound13287 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env13288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5592,0,478,131072,2476,1024,1,4249,248,152,83,388,64,138648,5528,4233,138477,1285,248,256,249,5512,513]

theorem envBound13288 : H12AffineFastState.Bounded env13288 := by
  intro p hp
  have h : env13288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13287_13288 : H12AffineEnvironment.transform 13 5592 env13287 = env13288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env13287 == env13288) = true)

theorem identity13288 : scanCanonicalize (H12AffineFastState.compose env13288 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound13288 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env13289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5592,0,478,5392,2476,1024,1,4249,248,152,83,388,64,2184,5528,4233,2557,1285,248,256,249,5512,513]

theorem envBound13289 : H12AffineFastState.Bounded env13289 := by
  intro p hp
  have h : env13289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13288_13289 : H12AffineEnvironment.transform 16 5392 env13288 = env13289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env13288 == env13289) = true)

theorem identity13289 : scanCanonicalize (H12AffineFastState.compose env13289 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13289 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,0,343,5392,2341,1024,1,4112,113,17,83,269,64,2049,5393,4096,2420,1285,113,256,112,5377,513]

theorem envBound13290 : H12AffineFastState.Bounded env13290 := by
  intro p hp
  have h : env13290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13289_13290 : H12AffineEnvironment.transform 6 9 env13289 = env13290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13289 == env13290) = true)

theorem identity13290 : scanCanonicalize (H12AffineFastState.compose env13290 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound13290 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env13291 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,268,4113,0,343,4176,2341,320,1,4112,113,17,83,269,64,2049,4177,4096,2420,69,113,256,112,4161,513]

theorem envBound13291 : H12AffineFastState.Bounded env13291 := by
  intro p hp
  have h : env13291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13290_13291 : H12AffineEnvironment.transform 9 320 env13290 = env13291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env13290 == env13291) = true)

theorem identity13291 : scanCanonicalize (H12AffineFastState.compose env13291 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound13291 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env13292 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2324,268,2309,0,343,2372,2341,320,1,2308,113,17,83,269,64,2049,2373,2324,2420,69,113,256,112,2389,513]

theorem envBound13292 : H12AffineFastState.Bounded env13292 := by
  intro p hp
  have h : env13292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13291_13292 : H12AffineEnvironment.transform 11 2324 env13291 = env13292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env13291 == env13292) = true)

theorem identity13292 : scanCanonicalize (H12AffineFastState.compose env13292 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound13292 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env13293 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2145,121,2160,0,34,2097,2128,53,1,2161,113,17,83,120,64,2049,2096,2145,2049,69,113,117,112,2080,513]

theorem envBound13293 : H12AffineFastState.Bounded env13293 := by
  intro p hp
  have h : env13293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13292_13293 : H12AffineEnvironment.transform 7 117 env13292 = env13293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env13292 == env13293) = true)

theorem identity13293 : scanCanonicalize (H12AffineFastState.compose env13293 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 606) := by decide +kernel

theorem selectedBound13293 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env13294 : List Nat := [2,4,8,16,32,64,9,117,512,53,606,575,121,558,0,34,623,526,53,1,559,113,17,83,120,64,607,622,575,607,69,113,117,112,638,513]

theorem envBound13294 : H12AffineFastState.Bounded env13294 := by
  intro p hp
  have h : env13294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13293_13294 : H12AffineEnvironment.transform 10 606 env13293 = env13294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 606 env13293 == env13294) = true)

theorem identity13294 : scanCanonicalize (H12AffineFastState.compose env13294 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13294 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13295 : List Nat := [2,4,8,16,32,16,9,37,512,53,526,575,41,558,0,34,575,526,53,1,559,33,17,3,40,16,527,574,575,527,21,33,37,32,558,513]

end H12CloudChart1