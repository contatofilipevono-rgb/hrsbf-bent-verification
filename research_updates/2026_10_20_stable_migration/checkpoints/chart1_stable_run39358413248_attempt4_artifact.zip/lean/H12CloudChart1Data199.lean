import H12CloudChart1Data198

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env50410 : List Nat := [2,4,8,16,0,64,8,85,512,1024,576,577,8,1557,1,2,1541,577,1025,0,512,0,16,3,8,65,576,1540,576,576,1025,0,84,0,1605,512]

theorem envBound50410 : H12AffineFastState.Bounded env50410 := by
  intro p hp
  have h : env50410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50409_50410 : H12AffineEnvironment.transform 4 0 env50409 = env50410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50409 == env50410) = true)

theorem identity50410 : scanCanonicalize (H12AffineFastState.compose env50410 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50410 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50411 : List Nat := [2,4,8,16,0,17,8,4,512,1024,529,528,8,1557,1,2,1541,528,1025,0,512,0,16,3,8,16,529,1540,529,529,1025,0,5,0,1556,512]

theorem envBound50411 : H12AffineFastState.Bounded env50411 := by
  intro p hp
  have h : env50411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50410_50411 : H12AffineEnvironment.transform 5 17 env50410 = env50411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50410 == env50411) = true)

theorem identity50411 : scanCanonicalize (H12AffineFastState.compose env50411 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50412 : List Nat := [2,4,8,16,0,17,8,4,16,1024,1,0,8,1029,1,2,1045,0,1025,0,16,0,16,3,8,16,1,1044,1,1,1025,0,5,0,1028,16]

theorem envBound50412 : H12AffineFastState.Bounded env50412 := by
  intro p hp
  have h : env50412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50411_50412 : H12AffineEnvironment.transform 8 16 env50411 = env50412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50411 == env50412) = true)

theorem identity50412 : scanCanonicalize (H12AffineFastState.compose env50412 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50412 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50413 : List Nat := [2,4,8,16,0,17,8,4,16,4,1,0,8,1,1,2,17,0,5,0,16,0,16,3,8,16,1,16,1,1,5,0,5,0,0,16]

theorem envBound50413 : H12AffineFastState.Bounded env50413 := by
  intro p hp
  have h : env50413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50412_50413 : H12AffineEnvironment.transform 9 4 env50412 = env50413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50412 == env50413) = true)

def env50414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,16777216,8328,65,16959643,18973836,333994,2330107,19188202,16851104,257,17074518,17066226,19263036]

theorem envBound50414 : H12AffineFastState.Bounded env50414 := by
  intro p hp
  have h : env50414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50301_50414 : H12AffineEnvironment.transform 21 2114913 env50301 = env50414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env50301 == env50414) = true)

def env50415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431208,8328,65,2609267,302180,333994,2330107,119042,2373704,257,2199998,2191386,63188]

theorem envBound50415 : H12AffineFastState.Bounded env50415 := by
  intro p hp
  have h : env50415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50414_50415 : H12AffineEnvironment.transform 23 2431208 env50414 = env50415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env50414 == env50415) = true)

def env50416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329896,8328,65,507955,302180,333994,236987,119042,272392,257,98814,90202,63188]

theorem envBound50416 : H12AffineFastState.Bounded env50416 := by
  intro p hp
  have h : env50416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50416 : H12AffineEnvironment.transform 20 4160 env50415 = env50416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50415 == env50416) = true)

theorem identity50416 : scanCanonicalize (H12AffineFastState.compose env50416 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound50416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108927,1025,32769,4160,21793,62660,41431,8328,65,158028,79131,45525,236987,119042,98679,257,98814,90202,63188]

theorem envBound50417 : H12AffineFastState.Bounded env50417 := by
  intro p hp
  have h : env50417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50416_50417 : H12AffineEnvironment.transform 17 108927 env50416 = env50417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env50416 == env50417) = true)

theorem identity50417 : scanCanonicalize (H12AffineFastState.compose env50417 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound50417 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89514,1025,29908,4160,21793,17,21762,8328,65,158028,79131,17664,223598,75223,95650,257,95531,90202,513]

theorem envBound50418 : H12AffineFastState.Bounded env50418 := by
  intro p hp
  have h : env50418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50417_50418 : H12AffineEnvironment.transform 14 29909 env50417 = env50418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env50417 == env50418) = true)

theorem identity50418 : scanCanonicalize (H12AffineFastState.compose env50418 (packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50418 : packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env50419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,131072,89514,1025,21896,4160,21793,17,21762,468,65,149520,70727,17664,215090,66699,87294,257,87159,82182,513]

theorem envBound50419 : H12AffineFastState.Bounded env50419 := by
  intro p hp
  have h : env50419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50418_50419 : H12AffineEnvironment.transform 12 348 env50418 = env50419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50418 == env50419) = true)

theorem identity50419 : scanCanonicalize (H12AffineFastState.compose env50419 (packedSelected [1,2,3,7,8,10,11,12,15,18,19,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 71099) := by decide +kernel

theorem selectedBound50419 : packedSelected [1,2,3,7,8,10,11,12,15,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,71099,89514,1025,21896,4160,21793,17,21762,468,65,89515,70727,17664,23945,66699,87294,257,87159,82182,513]

theorem envBound50420 : H12AffineFastState.Bounded env50420 := by
  intro p hp
  have h : env50420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50419_50420 : H12AffineEnvironment.transform 16 71099 env50419 = env50420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 71099 env50419 == env50420) = true)

theorem identity50420 : scanCanonicalize (H12AffineFastState.compose env50420 (packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound50420 : packedSelected [1,2,3,4,5,8,9,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env50421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5237,508,65536,71099,68063,1025,509,4160,340,17,375,468,65,68062,70727,4469,2556,66699,65675,257,65538,71027,513]

theorem envBound50421 : H12AffineFastState.Bounded env50421 := by
  intro p hp
  have h : env50421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50420_50421 : H12AffineEnvironment.transform 13 5237 env50420 = env50421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env50420 == env50421) = true)

theorem identity50421 : scanCanonicalize (H12AffineFastState.compose env50421 (packedSelected [0,2,4,7,11,14,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50421 : packedSelected [0,2,4,7,11,14,17,18,22] rootPS < 2^1333 := by decide +kernel

def env50422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,373,65536,70962,67926,1025,372,4160,340,17,375,349,65,67927,70727,4469,2421,66562,65538,257,65538,71027,513]

theorem envBound50422 : H12AffineFastState.Bounded env50422 := by
  intro p hp
  have h : env50422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50421_50422 : H12AffineEnvironment.transform 6 9 env50421 = env50422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50421 == env50422) = true)

theorem identity50422 : scanCanonicalize (H12AffineFastState.compose env50422 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50422 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env50423 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,65536,70727,67619,1025,1,4160,33,17,2,40,65,67618,70727,4096,2048,66562,65538,116,65538,70662,513]

theorem envBound50423 : H12AffineFastState.Bounded env50423 := by
  intro p hp
  have h : env50423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50422_50423 : H12AffineEnvironment.transform 7 117 env50422 = env50423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50422 == env50423) = true)

theorem identity50423 : scanCanonicalize (H12AffineFastState.compose env50423 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound50423 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50424 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1061,41,80,0,65536,65634,67619,1025,1,1125,33,17,2,40,65,67618,65634,1061,2048,66562,65538,116,65538,65571,513]

theorem envBound50424 : H12AffineFastState.Bounded env50424 := by
  intro p hp
  have h : env50424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50423_50424 : H12AffineEnvironment.transform 11 1061 env50423 = env50424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env50423 == env50424) = true)

theorem identity50424 : scanCanonicalize (H12AffineFastState.compose env50424 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound50424 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env50425 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1061,41,80,0,1047,1141,3124,1025,1,1125,33,17,2,40,65,3125,1141,1061,2048,21,1045,116,1045,1076,513]

theorem envBound50425 : H12AffineFastState.Bounded env50425 := by
  intro p hp
  have h : env50425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50424_50425 : H12AffineEnvironment.transform 15 1047 env50424 = env50425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env50424 == env50425) = true)

theorem identity50425 : scanCanonicalize (H12AffineFastState.compose env50425 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound50425 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env50426 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1125,1061,41,80,0,1047,1141,81,1025,1,1125,33,17,2,40,65,80,1141,1061,1125,21,1045,116,1045,1076,513]

theorem envBound50426 : H12AffineFastState.Bounded env50426 := by
  intro p hp
  have h : env50426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50425_50426 : H12AffineEnvironment.transform 10 1125 env50425 = env50426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env50425 == env50426) = true)

theorem identity50426 : scanCanonicalize (H12AffineFastState.compose env50426 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50426 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50427 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1077,1061,41,0,0,1047,1061,1,1025,1,1077,33,17,2,40,17,0,1061,1061,1077,21,1045,36,1045,1076,513]

theorem envBound50427 : H12AffineFastState.Bounded env50427 := by
  intro p hp
  have h : env50427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50426_50427 : H12AffineEnvironment.transform 5 16 env50426 = env50427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50426 == env50427) = true)

theorem identity50427 : scanCanonicalize (H12AffineFastState.compose env50427 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50427 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50428 : List Nat := [2,4,8,16,16,16,9,21,512,1024,1029,1045,25,0,0,1047,1045,1,1025,1,1029,17,17,2,24,17,0,1045,1045,1029,21,1045,20,1045,1028,513]

theorem envBound50428 : H12AffineFastState.Bounded env50428 := by
  intro p hp
  have h : env50428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50427_50428 : H12AffineEnvironment.transform 4 16 env50427 = env50428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50427 == env50428) = true)

theorem identity50428 : scanCanonicalize (H12AffineFastState.compose env50428 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50428 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50429 : List Nat := [2,4,8,0,0,0,9,5,512,1024,1029,1029,9,0,0,1031,1029,1,1025,1,1029,1,1,2,8,1,0,1029,1029,1029,5,1029,4,1029,1028,513]

theorem envBound50429 : H12AffineFastState.Bounded env50429 := by
  intro p hp
  have h : env50429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50428_50429 : H12AffineEnvironment.transform 3 0 env50428 = env50429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50428 == env50429) = true)

theorem identity50429 : scanCanonicalize (H12AffineFastState.compose env50429 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound50429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50430 : List Nat := [2,4,8,0,0,0,9,5,512,5,0,0,9,0,0,2,0,1,4,1,0,1,1,2,8,1,0,0,0,0,5,0,4,0,1,513]

theorem envBound50430 : H12AffineFastState.Bounded env50430 := by
  intro p hp
  have h : env50430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50429_50430 : H12AffineEnvironment.transform 9 5 env50429 = env50430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env50429 == env50430) = true)

theorem identity50430 : scanCanonicalize (H12AffineFastState.compose env50430 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50431 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,0,9,0,0,2,0,1,4,1,0,1,1,2,8,1,0,0,0,0,5,0,4,0,1,0]

theorem envBound50431 : H12AffineFastState.Bounded env50431 := by
  intro p hp
  have h : env50431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50430_50431 : H12AffineEnvironment.transform 8 1 env50430 = env50431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50430 == env50431) = true)

def env50432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329897,8328,65,507954,302180,333994,236986,119042,272393,257,98815,90203,63188]

theorem envBound50432 : H12AffineFastState.Bounded env50432 := by
  intro p hp
  have h : env50432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50432 : H12AffineEnvironment.transform 20 4161 env50415 = env50432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50415 == env50432) = true)

theorem identity50432 : scanCanonicalize (H12AffineFastState.compose env50432 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound50432 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,21792,297317,318582,8328,65,398573,302180,314485,149861,1501,272393,257,21792,46212,63188]

theorem envBound50433 : H12AffineFastState.Bounded env50433 := by
  intro p hp
  have h : env50433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50432_50433 : H12AffineEnvironment.transform 15 54495 env50432 = env50433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env50432 == env50433) = true)

def env50434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4161,21792,41293,62558,8328,65,146629,46156,58461,149861,1501,33,257,21792,46212,63188]

theorem envBound50434 : H12AffineFastState.Bounded env50434 := by
  intro p hp
  have h : env50434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50433_50434 : H12AffineEnvironment.transform 17 10280 env50433 = env50434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50433 == env50434) = true)

theorem identity50434 : scanCanonicalize (H12AffineFastState.compose env50434 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound50434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,131072,10280,1025,8660,4161,21792,152,21899,8328,65,146629,5529,17800,149861,1501,33,257,21792,5457,22273]

theorem envBound50435 : H12AffineFastState.Bounded env50435 := by
  intro p hp
  have h : env50435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50434_50435 : H12AffineEnvironment.transform 14 8661 env50434 = env50435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env50434 == env50435) = true)

theorem identity50435 : scanCanonicalize (H12AffineFastState.compose env50435 (packedSelected [2,3,4,6,11,16,19,22,23,24,31] rootPS)) = affineNative (2^(16+1) ^^^ 24800) := by decide +kernel

theorem selectedBound50435 : packedSelected [2,3,4,6,11,16,19,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env50436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,24800,10280,1025,8660,4161,21792,152,21899,8328,65,23589,5529,17800,10629,1501,33,257,21792,5457,22273]

theorem envBound50436 : H12AffineFastState.Bounded env50436 := by
  intro p hp
  have h : env50436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50435_50436 : H12AffineEnvironment.transform 16 24800 env50435 = env50436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24800 env50435 == env50436) = true)

theorem identity50436 : scanCanonicalize (H12AffineFastState.compose env50436 (packedSelected [7,12,14,15,16,27] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound50436 : packedSelected [7,12,14,15,16,27] rootPS < 2^1333 := by decide +kernel

def env50437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12344,8661,1330,4312,10280,1025,8660,4161,9496,152,9651,8328,65,11293,5529,13744,10629,1501,33,257,9496,5457,10041]

theorem envBound50437 : H12AffineFastState.Bounded env50437 := by
  intro p hp
  have h : env50437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50436_50437 : H12AffineEnvironment.transform 13 12344 env50436 = env50437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env50436 == env50437) = true)

theorem identity50437 : scanCanonicalize (H12AffineFastState.compose env50437 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50437 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50438 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,12344,8432,1047,4312,10280,1025,8433,4161,9277,152,9366,8328,65,11293,5308,13461,10400,1272,33,36,9277,5236,9756]

theorem envBound50438 : H12AffineFastState.Bounded env50438 := by
  intro p hp
  have h : env50438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50437_50438 : H12AffineEnvironment.transform 7 37 env50437 = env50438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50437 == env50438) = true)

theorem identity50438 : scanCanonicalize (H12AffineFastState.compose env50438 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50438 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env50439 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,120,4160,136,1047,4312,2128,1025,137,4161,1093,152,1262,240,65,3173,5308,5357,2264,1272,33,36,1093,5236,1636]

theorem envBound50439 : H12AffineFastState.Bounded env50439 := by
  intro p hp
  have h : env50439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50438_50439 : H12AffineEnvironment.transform 12 120 env50438 = env50439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50438 == env50439) = true)

theorem identity50439 : scanCanonicalize (H12AffineFastState.compose env50439 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50439 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env50440 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,4096,120,4160,80,1047,4096,2128,1025,81,4161,1093,64,1078,40,65,3173,5220,5173,2048,1056,33,36,1093,5236,1636]

theorem envBound50440 : H12AffineFastState.Bounded env50440 := by
  intro p hp
  have h : env50440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50439_50440 : H12AffineEnvironment.transform 6 88 env50439 = env50440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50439 == env50440) = true)

theorem identity50440 : scanCanonicalize (H12AffineFastState.compose env50440 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50440 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50441 : List Nat := [2,4,8,16,32,64,88,37,512,52,2048,4096,120,4160,80,35,4096,2128,53,81,4161,113,64,2,40,65,2129,4176,4097,2048,20,33,36,113,4160,592]

theorem envBound50441 : H12AffineFastState.Bounded env50441 := by
  intro p hp
  have h : env50441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50440_50441 : H12AffineEnvironment.transform 9 52 env50440 = env50441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50440 == env50441) = true)

theorem identity50441 : scanCanonicalize (H12AffineFastState.compose env50441 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound50441 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env50442 : List Nat := [2,4,8,16,32,64,88,37,512,52,81,4096,120,4160,80,35,4096,1,53,81,4161,113,64,2,40,65,0,4176,4097,81,20,33,36,113,4160,592]

theorem envBound50442 : H12AffineFastState.Bounded env50442 := by
  intro p hp
  have h : env50442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50441_50442 : H12AffineEnvironment.transform 10 81 env50441 = env50442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env50441 == env50442) = true)

theorem identity50442 : scanCanonicalize (H12AffineFastState.compose env50442 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound50442 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50443 : List Nat := [2,4,8,16,32,64,88,37,512,52,81,64,120,0,80,35,64,1,53,81,1,113,64,2,40,65,0,16,65,81,20,33,36,113,0,592]

theorem envBound50443 : H12AffineFastState.Bounded env50443 := by
  intro p hp
  have h : env50443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50442_50443 : H12AffineEnvironment.transform 11 64 env50442 = env50443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env50442 == env50443) = true)

def env50444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4161,21792,41292,62559,8328,65,146628,46157,58460,149861,1501,32,257,21792,46212,63188]

theorem envBound50444 : H12AffineFastState.Bounded env50444 := by
  intro p hp
  have h : env50444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50433_50444 : H12AffineEnvironment.transform 17 10281 env50433 = env50444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50433 == env50444) = true)

def env50445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5528,10281,1025,32769,4161,21792,41292,62559,8328,65,10588,46157,58460,23805,1501,32,257,21792,46212,63188]

theorem envBound50445 : H12AffineFastState.Bounded env50445 := by
  intro p hp
  have h : env50445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50444_50445 : H12AffineEnvironment.transform 16 5528 env50444 = env50445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env50444 == env50445) = true)

theorem identity50445 : scanCanonicalize (H12AffineFastState.compose env50445 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound50445 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env50446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33111,5528,10281,1025,32769,4161,168,41292,41431,8328,65,10588,46157,45524,2421,1501,32,257,168,46212,41820]

theorem envBound50446 : H12AffineFastState.Bounded env50446 := by
  intro p hp
  have h : env50446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50445_50446 : H12AffineEnvironment.transform 13 5512 env50445 = env50446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env50445 == env50446) = true)

theorem identity50446 : scanCanonicalize (H12AffineFastState.compose env50446 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound50446 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,136,479,5528,10281,1025,137,4161,168,8644,8543,8328,65,10588,13509,12636,2421,1501,32,257,168,13324,9172]

theorem envBound50447 : H12AffineFastState.Bounded env50447 := by
  intro p hp
  have h : env50447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50446_50447 : H12AffineEnvironment.transform 14 136 env50446 = env50447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env50446 == env50447) = true)

theorem identity50447 : scanCanonicalize (H12AffineFastState.compose env50447 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50447 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,136,479,5528,2340,1025,137,4161,168,201,82,389,65,2129,5576,4177,2421,1501,32,257,168,5377,729]

theorem envBound50448 : H12AffineFastState.Bounded env50448 := by
  intro p hp
  have h : env50448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50447_50448 : H12AffineEnvironment.transform 12 269 env50447 = env50448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50447 == env50448) = true)

theorem identity50448 : scanCanonicalize (H12AffineFastState.compose env50448 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound50448 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env50449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,508,269,1140,136,479,1124,2340,1025,137,445,168,201,82,389,65,2129,1076,429,2421,1501,32,257,168,1277,729]

theorem envBound50449 : H12AffineFastState.Bounded env50449 := by
  intro p hp
  have h : env50449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50448_50449 : H12AffineEnvironment.transform 11 508 env50448 = env50449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env50448 == env50449) = true)

theorem identity50449 : scanCanonicalize (H12AffineFastState.compose env50449 (packedSelected [1,2,6,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound50449 : packedSelected [1,2,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env50450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,340,508,269,1140,136,479,1124,112,1025,137,445,168,201,82,389,65,261,1076,429,33,1501,32,257,168,1277,729]

theorem envBound50450 : H12AffineFastState.Bounded env50450 := by
  intro p hp
  have h : env50450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50449_50450 : H12AffineEnvironment.transform 10 340 env50449 = env50450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env50449 == env50450) = true)

theorem identity50450 : scanCanonicalize (H12AffineFastState.compose env50450 (packedSelected [0,2,5,6,7,8,16] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound50450 : packedSelected [0,2,5,6,7,8,16] rootPS < 2^1333 := by decide +kernel

def env50451 : List Nat := [2,4,8,16,32,64,128,215,512,1024,131,43,218,1140,136,8,1124,112,1025,137,106,168,201,82,82,65,210,1076,122,33,1034,32,214,168,1277,729]

theorem envBound50451 : H12AffineFastState.Bounded env50451 := by
  intro p hp
  have h : env50451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50450_50451 : H12AffineEnvironment.transform 7 215 env50450 = env50451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env50450 == env50451) = true)

theorem identity50451 : scanCanonicalize (H12AffineFastState.compose env50451 (packedSelected [0,2,3,6,7,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50451 : packedSelected [0,2,3,6,7,8,19] rootPS < 2^1333 := by decide +kernel

def env50452 : List Nat := [2,4,8,16,32,64,88,15,512,1024,91,43,2,1140,80,8,1124,112,1025,81,106,112,17,82,82,65,10,1076,122,33,1034,32,14,112,1061,513]

theorem envBound50452 : H12AffineFastState.Bounded env50452 := by
  intro p hp
  have h : env50452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50451_50452 : H12AffineEnvironment.transform 6 88 env50451 = env50452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50451 == env50452) = true)

theorem identity50452 : scanCanonicalize (H12AffineFastState.compose env50452 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50452 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50453 : List Nat := [2,4,8,16,32,64,88,15,512,4,91,43,2,112,80,8,96,112,5,81,106,112,17,82,82,65,10,48,122,33,14,32,14,112,33,513]

theorem envBound50453 : H12AffineFastState.Bounded env50453 := by
  intro p hp
  have h : env50453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50452_50453 : H12AffineEnvironment.transform 9 4 env50452 = env50453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50452 == env50453) = true)

theorem identity50453 : scanCanonicalize (H12AffineFastState.compose env50453 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50453 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50454 : List Nat := [2,4,8,16,32,16,8,15,512,4,11,43,2,32,0,8,48,32,5,1,58,32,17,2,2,17,10,48,42,33,14,32,14,32,33,513]

theorem envBound50454 : H12AffineFastState.Bounded env50454 := by
  intro p hp
  have h : env50454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50453_50454 : H12AffineEnvironment.transform 5 16 env50453 = env50454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50453 == env50454) = true)

theorem identity50454 : scanCanonicalize (H12AffineFastState.compose env50454 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50455 : List Nat := [2,4,8,16,16,16,8,15,512,4,11,27,2,16,0,8,0,16,5,1,10,16,17,2,2,17,10,0,26,17,14,16,14,16,17,513]

theorem envBound50455 : H12AffineFastState.Bounded env50455 := by
  intro p hp
  have h : env50455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50454_50455 : H12AffineEnvironment.transform 4 16 env50454 = env50455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50454 == env50455) = true)

theorem identity50455 : scanCanonicalize (H12AffineFastState.compose env50455 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50455 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50456 : List Nat := [2,3,8,16,16,16,8,8,512,3,11,27,2,16,0,8,0,16,2,1,10,16,17,2,2,17,10,0,26,17,9,16,9,16,17,513]

theorem envBound50456 : H12AffineFastState.Bounded env50456 := by
  intro p hp
  have h : env50456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50455_50456 : H12AffineEnvironment.transform 1 3 env50455 = env50456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50455 == env50456) = true)

theorem identity50456 : scanCanonicalize (H12AffineFastState.compose env50456 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50456 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50457 : List Nat := [2,3,8,10,10,10,8,8,512,3,11,1,2,10,0,8,0,10,2,1,10,10,11,2,2,11,10,0,0,11,9,10,9,10,11,513]

theorem envBound50457 : H12AffineFastState.Bounded env50457 := by
  intro p hp
  have h : env50457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50456_50457 : H12AffineEnvironment.transform 3 10 env50456 = env50457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50456 == env50457) = true)

theorem identity50457 : scanCanonicalize (H12AffineFastState.compose env50457 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50457 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50458 : List Nat := [2,3,0,2,2,2,0,0,512,3,3,1,2,2,0,0,0,2,2,1,2,2,3,2,2,3,2,0,0,3,1,2,1,2,3,513]

theorem envBound50458 : H12AffineFastState.Bounded env50458 := by
  intro p hp
  have h : env50458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50457_50458 : H12AffineEnvironment.transform 2 0 env50457 = env50458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50457 == env50458) = true)

def env50459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5529,10281,1025,32769,4161,21792,41292,62559,8328,65,10589,46157,58460,23804,1501,32,257,21792,46212,63188]

theorem envBound50459 : H12AffineFastState.Bounded env50459 := by
  intro p hp
  have h : env50459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50444_50459 : H12AffineEnvironment.transform 16 5529 env50444 = env50459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env50444 == env50459) = true)

theorem identity50459 : scanCanonicalize (H12AffineFastState.compose env50459 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound50459 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env50460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,343,5529,10281,1025,21897,4161,21792,29892,8663,8328,65,10589,25029,12756,23804,1501,32,257,21792,24844,9052]

theorem envBound50460 : H12AffineFastState.Bounded env50460 := by
  intro p hp
  have h : env50460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50459_50460 : H12AffineEnvironment.transform 14 21896 env50459 = env50460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env50459 == env50460) = true)

theorem identity50460 : scanCanonicalize (H12AffineFastState.compose env50460 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50460 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,343,5529,2420,1025,21897,4161,21792,21913,138,469,65,2048,16536,4233,23804,1501,32,257,21792,16465,513]

theorem envBound50461 : H12AffineFastState.Bounded env50461 := by
  intro p hp
  have h : env50461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50460_50461 : H12AffineEnvironment.transform 12 349 env50460 = env50461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50460 == env50461) = true)

theorem identity50461 : scanCanonicalize (H12AffineFastState.compose env50461 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound50461 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,0,343,5529,2420,1025,1,4161,168,17,138,469,65,2048,5392,4233,2420,1501,32,257,168,5593,513]

theorem envBound50462 : H12AffineFastState.Bounded env50462 := by
  intro p hp
  have h : env50462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50461_50462 : H12AffineEnvironment.transform 13 5512 env50461 = env50462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env50461 == env50462) = true)

theorem identity50462 : scanCanonicalize (H12AffineFastState.compose env50462 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50462 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50463 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5456,0,343,5441,2420,1025,1,4161,112,17,82,269,65,2048,5392,4177,2420,1285,32,257,112,5377,513]

theorem envBound50463 : H12AffineFastState.Bounded env50463 := by
  intro p hp
  have h : env50463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50462_50463 : H12AffineEnvironment.transform 6 88 env50462 = env50463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50462 == env50463) = true)

theorem identity50463 : scanCanonicalize (H12AffineFastState.compose env50463 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50463 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50464 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,121,5236,0,115,5221,2128,1025,1,4161,112,17,82,41,65,2048,5172,4177,2128,1057,32,37,112,5157,513]

theorem envBound50464 : H12AffineFastState.Bounded env50464 := by
  intro p hp
  have h : env50464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50463_50464 : H12AffineEnvironment.transform 7 36 env50463 = env50464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50463 == env50464) = true)

theorem identity50464 : scanCanonicalize (H12AffineFastState.compose env50464 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50464 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50465 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5172,2049,1025,1,4112,33,17,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound50465 : H12AffineFastState.Bounded env50465 := by
  intro p hp
  have h : env50465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50464_50465 : H12AffineEnvironment.transform 5 17 env50464 = env50465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50464 == env50465) = true)

def env50466 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,0,34,1028,2049,1025,1,32,33,17,3,41,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound50466 : H12AffineFastState.Bounded env50466 := by
  intro p hp
  have h : env50466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50465_50466 : H12AffineEnvironment.transform 11 48 env50465 = env50466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50465 == env50466) = true)

theorem identity50466 : scanCanonicalize (H12AffineFastState.compose env50466 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50467 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,48,40,0,0,34,17,2049,20,1,32,33,17,3,41,16,2048,17,48,2049,52,32,37,33,0,513]

theorem envBound50467 : H12AffineFastState.Bounded env50467 := by
  intro p hp
  have h : env50467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50466_50467 : H12AffineEnvironment.transform 9 21 env50466 = env50467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50466 == env50467) = true)

def env50468 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,8,0,0,2,17,2049,20,1,0,1,17,3,9,16,2048,17,16,2049,20,0,5,1,0,513]

theorem envBound50468 : H12AffineFastState.Bounded env50468 := by
  intro p hp
  have h : env50468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50467_50468 : H12AffineEnvironment.transform 4 0 env50467 = env50468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50467 == env50468) = true)

theorem identity50468 : scanCanonicalize (H12AffineFastState.compose env50468 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50468 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50469 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,16,8,0,0,2,17,522,20,1,0,1,17,3,9,16,523,17,16,522,20,0,5,1,0,513]

theorem envBound50469 : H12AffineFastState.Bounded env50469 := by
  intro p hp
  have h : env50469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50468_50469 : H12AffineEnvironment.transform 10 523 env50468 = env50469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50468 == env50469) = true)

def leafEnv50469 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,16,8,0,0,2,17,522,20,1,0,1,17,3,21,9,1,16,523,17,16,522,20,0,5,1,5,3,0,513,1,0,0]

def active50469 : List Nat := [0,1,2,3,8]

def tree50469 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50469 : H12WitnessSearch.Good tree50469 := H12GlobalWitnessIndex.good

theorem leafIdentity50469 : H12AffineFastState.composeSystem env50469 rootObs = leafEnv50469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50469 rootObs == leafEnv50469) = true)

theorem terminalChecked50469 : H12PackedTerminal.terminalCheckFast leafEnv50469 active50469 tree50469 = true := by decide +kernel

def env50470 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,0,3,17,2049,20,1,1,0,17,3,8,16,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound50470 : H12AffineFastState.Bounded env50470 := by
  intro p hp
  have h : env50470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50467_50470 : H12AffineEnvironment.transform 4 1 env50467 = env50470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50467 == env50470) = true)

theorem identity50470 : scanCanonicalize (H12AffineFastState.compose env50470 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50471 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,0,0,3,17,0,20,1,1,0,17,3,8,16,1,17,17,0,21,1,4,0,0,513]

theorem envBound50471 : H12AffineFastState.Bounded env50471 := by
  intro p hp
  have h : env50471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50470_50471 : H12AffineEnvironment.transform 10 1 env50470 = env50471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50470 == env50471) = true)

def leafEnv50471 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,0,0,3,17,0,20,1,1,0,17,3,20,8,1,16,1,17,17,0,21,1,4,0,5,2,0,513,1,1,0]

def active50471 : List Nat := [0,1,2,3,8]

def tree50471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50471 : H12WitnessSearch.Good tree50471 := H12GlobalWitnessIndex.good

theorem leafIdentity50471 : H12AffineFastState.composeSystem env50471 rootObs = leafEnv50471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50471 rootObs == leafEnv50471) = true)

theorem terminalChecked50471 : H12PackedTerminal.terminalCheckFast leafEnv50471 active50471 tree50471 = true := by decide +kernel

def env50472 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,0,34,1029,2049,1025,1,33,33,17,3,41,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound50472 : H12AffineFastState.Bounded env50472 := by
  intro p hp
  have h : env50472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50465_50472 : H12AffineEnvironment.transform 11 49 env50465 = env50472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50465 == env50472) = true)

theorem identity50472 : scanCanonicalize (H12AffineFastState.compose env50472 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50473 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,0,3,1029,2049,1025,1,0,0,17,3,8,16,2048,1029,16,2049,1024,1,4,0,1044,513]

theorem envBound50473 : H12AffineFastState.Bounded env50473 := by
  intro p hp
  have h : env50473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50472_50473 : H12AffineEnvironment.transform 4 1 env50472 = env50473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50472 == env50473) = true)

def env50474 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,0,0,3,17,2049,21,1,0,0,17,3,8,16,2048,17,16,2049,20,1,4,0,0,513]

theorem envBound50474 : H12AffineFastState.Bounded env50474 := by
  intro p hp
  have h : env50474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50473_50474 : H12AffineEnvironment.transform 9 20 env50473 = env50474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50473 == env50474) = true)

theorem identity50474 : scanCanonicalize (H12AffineFastState.compose env50474 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound50474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50475 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,16,9,0,0,3,17,523,21,1,0,0,17,3,8,16,522,17,16,523,20,1,4,0,0,513]

theorem envBound50475 : H12AffineFastState.Bounded env50475 := by
  intro p hp
  have h : env50475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50474_50475 : H12AffineEnvironment.transform 10 522 env50474 = env50475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env50474 == env50475) = true)

def leafEnv50475 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,16,9,0,0,3,17,523,21,1,0,0,17,3,21,8,1,16,522,17,16,523,20,1,4,0,5,2,0,513,1,0,0]

def active50475 : List Nat := [0,1,2,3,8]

def tree50475 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50475 : H12WitnessSearch.Good tree50475 := H12GlobalWitnessIndex.good

theorem leafIdentity50475 : H12AffineFastState.composeSystem env50475 rootObs = leafEnv50475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50475 rootObs == leafEnv50475) = true)

theorem terminalChecked50475 : H12PackedTerminal.terminalCheckFast leafEnv50475 active50475 tree50475 = true := by decide +kernel

def env50476 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,1,0,3,16,2049,20,1,0,0,17,3,8,16,2048,16,16,2049,21,1,4,0,1,513]

theorem envBound50476 : H12AffineFastState.Bounded env50476 := by
  intro p hp
  have h : env50476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50473_50476 : H12AffineEnvironment.transform 9 21 env50473 = env50476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50473 == env50476) = true)

theorem identity50476 : scanCanonicalize (H12AffineFastState.compose env50476 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50477 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,1,0,3,16,1,20,1,0,0,17,3,8,16,0,16,16,1,21,1,4,0,1,513]

theorem envBound50477 : H12AffineFastState.Bounded env50477 := by
  intro p hp
  have h : env50477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50476_50477 : H12AffineEnvironment.transform 10 0 env50476 = env50477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50476 == env50477) = true)

def leafEnv50477 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,1,0,3,16,1,20,1,0,0,17,3,20,8,1,16,0,16,16,1,21,1,4,0,5,2,1,513,1,0,0]

def active50477 : List Nat := [0,1,2,3,8]

def tree50477 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50477 : H12WitnessSearch.Good tree50477 := H12GlobalWitnessIndex.good

theorem leafIdentity50477 : H12AffineFastState.composeSystem env50477 rootObs = leafEnv50477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50477 rootObs == leafEnv50477) = true)

theorem terminalChecked50477 : H12PackedTerminal.terminalCheckFast leafEnv50477 active50477 tree50477 = true := by decide +kernel

def env50478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431209,8328,65,2609266,302181,333994,2330107,119043,2373705,257,2199999,2191387,63189]

theorem envBound50478 : H12AffineFastState.Bounded env50478 := by
  intro p hp
  have h : env50478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50414_50478 : H12AffineEnvironment.transform 23 2431209 env50414 = env50478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env50414 == env50478) = true)

def env50479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329897,8328,65,507954,302181,333994,236987,119043,272393,257,98815,90203,63189]

theorem envBound50479 : H12AffineFastState.Bounded env50479 := by
  intro p hp
  have h : env50479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50478_50479 : H12AffineEnvironment.transform 20 4160 env50478 = env50479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50478 == env50479) = true)

theorem identity50479 : scanCanonicalize (H12AffineFastState.compose env50479 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50479 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294321,272547,8328,65,450616,302181,276640,179633,61705,272393,257,41461,16465,63189]

theorem envBound50480 : H12AffineFastState.Bounded env50480 := by
  intro p hp
  have h : env50480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50479_50480 : H12AffineEnvironment.transform 15 8202 env50479 = env50480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50479 == env50480) = true)

def env50481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294201,272427,8192,65,450616,302181,276520,179513,61705,272393,257,41341,16465,63069]

theorem envBound50481 : H12AffineFastState.Bounded env50481 := by
  intro p hp
  have h : env50481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50480_50481 : H12AffineEnvironment.transform 6 8 env50480 = env50481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50480 == env50481) = true)

theorem identity50481 : scanCanonicalize (H12AffineFastState.compose env50481 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound50481 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,262144,1025,32769,4160,21793,294201,272427,8192,65,283765,302181,276520,2420,61705,272393,257,41341,16465,63069]

theorem envBound50482 : H12AffineFastState.Bounded env50482 := by
  intro p hp
  have h : env50482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50481_50482 : H12AffineEnvironment.transform 16 46157 env50481 = env50482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env50481 == env50482) = true)

theorem identity50482 : scanCanonicalize (H12AffineFastState.compose env50482 (packedSelected [0,9,17,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound50482 : packedSelected [0,9,17,22,27] rootPS < 2^1333 := by decide +kernel

def env50483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,10361,1025,32769,4160,21793,21824,82,8192,65,31756,46108,4177,2420,61705,112,257,41341,16465,63069]

theorem envBound50483 : H12AffineFastState.Bounded env50483 := by
  intro p hp
  have h : env50483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50482_50483 : H12AffineEnvironment.transform 17 10361 env50482 = env50483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env50482 == env50483) = true)

theorem identity50483 : scanCanonicalize (H12AffineFastState.compose env50483 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50483 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,38208,2420,1025,32769,4160,21793,21824,82,269,65,23809,38161,4177,2420,53252,112,257,32880,16465,55120]

theorem envBound50484 : H12AffineFastState.Bounded env50484 := by
  intro p hp
  have h : env50484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50483_50484 : H12AffineEnvironment.transform 12 269 env50483 = env50484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50483 == env50484) = true)

theorem identity50484 : scanCanonicalize (H12AffineFastState.compose env50484 (packedSelected [2,3,4,6,7,8,12,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound50484 : packedSelected [2,3,4,6,7,8,12,16,17,19] rootPS < 2^1333 := by decide +kernel

def env50485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,3344,32768,263,38208,2420,1025,32769,4160,6193,6224,82,269,65,4113,38161,4177,2420,40212,112,257,32880,3393,39488]

theorem envBound50485 : H12AffineFastState.Bounded env50485 := by
  intro p hp
  have h : env50485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50484_50485 : H12AffineEnvironment.transform 13 3344 env50484 = env50485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env50484 == env50485) = true)

theorem identity50485 : scanCanonicalize (H12AffineFastState.compose env50485 (packedSelected [0,1,4,5,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound50485 : packedSelected [0,1,4,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env50486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,3344,372,263,5172,2420,1025,373,4160,6193,6224,82,269,65,4113,5221,4177,2420,7264,112,257,260,3393,6964]

theorem envBound50486 : H12AffineFastState.Bounded env50486 := by
  intro p hp
  have h : env50486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50485_50486 : H12AffineEnvironment.transform 14 372 env50485 = env50486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env50485 == env50486) = true)

theorem identity50486 : scanCanonicalize (H12AffineFastState.compose env50486 (packedSelected [0,2,3,6,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50486 : packedSelected [0,2,3,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50487 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,3173,1,114,5172,2049,1025,0,4160,6193,6224,82,120,65,4113,5221,4177,2049,7264,112,116,113,3124,6721]

theorem envBound50487 : H12AffineFastState.Bounded env50487 := by
  intro p hp
  have h : env50487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50486_50487 : H12AffineEnvironment.transform 7 117 env50486 = env50487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50486 == env50487) = true)

theorem identity50487 : scanCanonicalize (H12AffineFastState.compose env50487 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound50487 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50488 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,120,3173,1,114,2112,2049,1025,0,3124,1093,1060,82,120,65,3173,2065,3109,2049,20,112,116,113,3124,1589]

theorem envBound50488 : H12AffineFastState.Bounded env50488 := by
  intro p hp
  have h : env50488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50487_50488 : H12AffineEnvironment.transform 11 3188 env50487 = env50488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env50487 == env50488) = true)

theorem identity50488 : scanCanonicalize (H12AffineFastState.compose env50488 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50488 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50489 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,3076,8,3093,1,2,2096,2049,1025,0,3124,1077,1060,34,8,49,3093,2065,3109,2049,20,0,4,1,3124,1589]

theorem envBound50489 : H12AffineFastState.Bounded env50489 := by
  intro p hp
  have h : env50489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50488_50489 : H12AffineEnvironment.transform 5 48 env50488 = env50489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50488 == env50489) = true)

theorem identity50489 : scanCanonicalize (H12AffineFastState.compose env50489 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50489 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env50490 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,2064,8,2049,1,2,2096,2049,21,0,2080,33,48,34,8,49,2049,2065,2097,2049,20,0,4,1,2080,545]

theorem envBound50490 : H12AffineFastState.Bounded env50490 := by
  intro p hp
  have h : env50490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50489_50490 : H12AffineEnvironment.transform 9 20 env50489 = env50490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50489 == env50490) = true)

theorem identity50490 : scanCanonicalize (H12AffineFastState.compose env50490 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50490 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50491 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,2064,8,2049,1,2,2064,2049,21,0,2048,1,16,2,8,17,2049,2065,2065,2049,20,0,4,1,2048,513]

theorem envBound50491 : H12AffineFastState.Bounded env50491 := by
  intro p hp
  have h : env50491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50490_50491 : H12AffineEnvironment.transform 4 0 env50490 = env50491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50490 == env50491) = true)

theorem identity50491 : scanCanonicalize (H12AffineFastState.compose env50491 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound50491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50492 : List Nat := [2,4,8,16,0,16,8,5,512,20,16,0,8,17,1,2,0,17,21,0,16,1,16,2,8,17,17,1,1,17,20,0,4,1,16,513]

theorem envBound50492 : H12AffineFastState.Bounded env50492 := by
  intro p hp
  have h : env50492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50491_50492 : H12AffineEnvironment.transform 10 16 env50491 = env50492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env50491 == env50492) = true)

theorem identity50492 : scanCanonicalize (H12AffineFastState.compose env50492 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound50492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50493 : List Nat := [2,4,8,16,0,16,8,5,10,20,16,0,8,17,1,2,0,17,21,0,16,1,16,2,8,17,17,1,1,17,20,0,4,1,16,11]

theorem envBound50493 : H12AffineFastState.Bounded env50493 := by
  intro p hp
  have h : env50493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50492_50493 : H12AffineEnvironment.transform 8 10 env50492 = env50493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env50492 == env50493) = true)

def env50494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,21793,294200,272426,8193,65,450616,302181,276521,179512,61705,272393,257,41340,16465,63068]

theorem envBound50494 : H12AffineFastState.Bounded env50494 := by
  intro p hp
  have h : env50494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50480_50494 : H12AffineEnvironment.transform 6 9 env50480 = env50494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50480 == env50494) = true)

theorem identity50494 : scanCanonicalize (H12AffineFastState.compose env50494 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50494 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,262144,1025,29788,4160,21793,294200,272426,8193,65,398437,288824,276521,149861,1364,272393,257,21793,16465,513]

theorem envBound50495 : H12AffineFastState.Bounded env50495 := by
  intro p hp
  have h : env50495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50494_50495 : H12AffineEnvironment.transform 14 29789 env50494 = env50495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50494 == env50495) = true)

theorem identity50495 : scanCanonicalize (H12AffineFastState.compose env50495 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50495 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env50496 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,262144,1025,29709,4113,21793,294200,272426,8193,16,398388,288824,276521,149812,1285,272393,257,21793,16384,513]

theorem envBound50496 : H12AffineFastState.Bounded env50496 := by
  intro p hp
  have h : env50496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50495_50496 : H12AffineEnvironment.transform 5 17 env50495 = env50496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50495 == env50496) = true)

theorem identity50496 : scanCanonicalize (H12AffineFastState.compose env50496 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound50496 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env50497 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,32041,1025,29709,4113,21793,17,21763,8193,16,157981,5393,17664,149812,1285,21792,257,21793,16384,513]

theorem envBound50497 : H12AffineFastState.Bounded env50497 := by
  intro p hp
  have h : env50497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50496_50497 : H12AffineEnvironment.transform 17 32041 env50496 = env50497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env50496 == env50497) = true)

theorem identity50497 : scanCanonicalize (H12AffineFastState.compose env50497 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound50497 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50498 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,24861,32041,1025,29709,4113,21793,17,21763,8193,16,2048,5393,17664,10281,1285,21792,257,21793,16384,513]

theorem envBound50498 : H12AffineFastState.Bounded env50498 := by
  intro p hp
  have h : env50498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50497_50498 : H12AffineEnvironment.transform 16 24861 env50497 = env50498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env50497 == env50498) = true)

theorem identity50498 : scanCanonicalize (H12AffineFastState.compose env50498 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50498 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env50499 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,5393,2341,1025,1,4113,8493,17,8463,8193,16,2048,5393,12556,10281,1285,8492,257,8493,13324,513]

theorem envBound50499 : H12AffineFastState.Bounded env50499 := by
  intro p hp
  have h : env50499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50498_50499 : H12AffineEnvironment.transform 13 13324 env50498 = env50499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50498 == env50499) = true)

theorem identity50499 : scanCanonicalize (H12AffineFastState.compose env50499 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50499 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50500 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4113,33,17,3,269,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound50500 : H12AffineFastState.Bounded env50500 := by
  intro p hp
  have h : env50500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50499_50500 : H12AffineEnvironment.transform 12 268 env50499 = env50500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50499 == env50500) = true)

theorem identity50500 : scanCanonicalize (H12AffineFastState.compose env50500 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50501 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5173,2049,1025,1,4113,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound50501 : H12AffineFastState.Bounded env50501 := by
  intro p hp
  have h : env50501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50500_50501 : H12AffineEnvironment.transform 7 36 env50500 = env50501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50500 == env50501) = true)

def env50502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329896,8328,65,507955,302181,333994,236986,119043,272392,257,98814,90202,63189]

theorem envBound50502 : H12AffineFastState.Bounded env50502 := by
  intro p hp
  have h : env50502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50478_50502 : H12AffineEnvironment.transform 20 4161 env50478 = env50502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50478 == env50502) = true)

theorem identity50502 : scanCanonicalize (H12AffineFastState.compose env50502 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound50502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1025,32769,4161,21792,17,21763,8328,65,171416,115150,17665,236986,119043,95651,257,98814,90202,63189]

theorem envBound50503 : H12AffineFastState.Bounded env50503 := by
  intro p hp
  have h : env50503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50502_50503 : H12AffineEnvironment.transform 17 89515 env50502 = env50503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env50502 == env50503) = true)

def env50504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4161,21792,17,21763,8192,65,171280,115014,17665,236850,119043,95531,257,98678,90202,63069]

theorem envBound50504 : H12AffineFastState.Bounded env50504 := by
  intro p hp
  have h : env50504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50503_50504 : H12AffineEnvironment.transform 6 8 env50503 = env50504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50503 == env50504) = true)

theorem identity50504 : scanCanonicalize (H12AffineFastState.compose env50504 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50504 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,89379,1025,8540,4161,21792,17,21763,8192,65,146509,90139,17665,212079,94302,95531,257,73771,90202,22272]

theorem envBound50505 : H12AffineFastState.Bounded env50505 := by
  intro p hp
  have h : env50505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50504_50505 : H12AffineEnvironment.transform 14 8541 env50504 = env50505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50504 == env50505) = true)

theorem identity50505 : scanCanonicalize (H12AffineFastState.compose env50505 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50505 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env50506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,32041,1025,8540,4161,21792,17,21763,8192,65,146509,16401,17665,138341,20564,21793,257,33,16464,22272]

theorem envBound50506 : H12AffineFastState.Bounded env50506 := by
  intro p hp
  have h : env50506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50505_50506 : H12AffineEnvironment.transform 15 8202 env50505 = env50506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50505 == env50506) = true)

theorem identity50506 : scanCanonicalize (H12AffineFastState.compose env50506 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound50506 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env50507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,131072,10588,1025,8540,4161,341,17,374,8192,65,146509,5220,4468,138341,1057,340,257,33,5157,885]

theorem envBound50507 : H12AffineFastState.Bounded env50507 := by
  intro p hp
  have h : env50507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50506_50507 : H12AffineEnvironment.transform 13 5237 env50506 = env50507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env50506 == env50507) = true)

theorem identity50507 : scanCanonicalize (H12AffineFastState.compose env50507 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50507 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env50508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,80,263,131072,2129,1025,81,4161,341,17,374,269,65,138560,5220,4468,138341,1057,340,257,33,5157,885]

theorem envBound50508 : H12AffineFastState.Bounded env50508 := by
  intro p hp
  have h : env50508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50507_50508 : H12AffineEnvironment.transform 12 269 env50507 = env50508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50507 == env50508) = true)

theorem identity50508 : scanCanonicalize (H12AffineFastState.compose env50508 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50508 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env50509 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,1,263,131072,2048,1025,0,4112,260,17,295,269,16,138513,5173,4389,138292,1057,261,257,33,5157,804]

theorem envBound50509 : H12AffineFastState.Bounded env50509 := by
  intro p hp
  have h : env50509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50508_50509 : H12AffineEnvironment.transform 5 17 env50508 = env50509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50508 == env50509) = true)

theorem identity50509 : scanCanonicalize (H12AffineFastState.compose env50509 (packedSelected [6,7,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 3328) := by decide +kernel

theorem selectedBound50509 : packedSelected [6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50510 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,1,263,3328,2048,1025,0,4112,260,17,295,269,16,4113,5173,4389,4404,1057,261,257,33,5157,804]

theorem envBound50510 : H12AffineFastState.Bounded env50510 := by
  intro p hp
  have h : env50510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50509_50510 : H12AffineEnvironment.transform 16 3328 env50509 = env50510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3328 env50509 == env50510) = true)

theorem identity50510 : scanCanonicalize (H12AffineFastState.compose env50510 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound50510 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env50511 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2357,269,3345,1,263,3328,2048,1025,0,2341,260,17,295,269,16,2340,3328,2064,2049,1057,261,257,33,3344,804]

theorem envBound50511 : H12AffineFastState.Bounded env50511 := by
  intro p hp
  have h : env50511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50510_50511 : H12AffineEnvironment.transform 11 2357 env50510 = env50511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env50510 == env50511) = true)

theorem identity50511 : scanCanonicalize (H12AffineFastState.compose env50511 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50511 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50512 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,41,3125,1,35,3108,2048,1025,0,2049,32,17,3,41,16,2048,3108,2064,2049,1057,33,37,33,3124,512]

theorem envBound50512 : H12AffineFastState.Bounded env50512 := by
  intro p hp
  have h : env50512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50511_50512 : H12AffineEnvironment.transform 7 36 env50511 = env50512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50511 == env50512) = true)

theorem identity50512 : scanCanonicalize (H12AffineFastState.compose env50512 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound50512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50513 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1029,1044,41,48,1,35,33,1029,1025,0,1028,32,17,3,41,16,1029,33,1045,1028,1057,33,37,33,49,512]

theorem envBound50513 : H12AffineFastState.Bounded env50513 := by
  intro p hp
  have h : env50513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50512_50513 : H12AffineEnvironment.transform 10 1029 env50512 = env50513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env50512 == env50513) = true)

theorem identity50513 : scanCanonicalize (H12AffineFastState.compose env50513 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50513 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50514 : List Nat := [2,4,8,16,11,17,8,15,512,1024,1029,1044,2,27,1,8,10,1029,1025,0,1028,11,17,3,2,16,1029,10,1045,1028,1034,10,14,10,26,512]

theorem envBound50514 : H12AffineFastState.Bounded env50514 := by
  intro p hp
  have h : env50514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50513_50514 : H12AffineEnvironment.transform 4 11 env50513 = env50514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50513 == env50514) = true)

theorem identity50514 : scanCanonicalize (H12AffineFastState.compose env50514 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50514 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50515 : List Nat := [2,4,8,1,11,0,8,15,512,1024,1029,1029,2,10,1,8,10,1029,1025,0,1028,11,0,3,2,1,1029,10,1028,1028,1034,10,14,10,11,512]

theorem envBound50515 : H12AffineFastState.Bounded env50515 := by
  intro p hp
  have h : env50515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50514_50515 : H12AffineEnvironment.transform 3 1 env50514 = env50515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50514 == env50515) = true)

theorem identity50515 : scanCanonicalize (H12AffineFastState.compose env50515 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound50515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50516 : List Nat := [2,4,8,1,11,0,8,15,512,10,15,15,2,10,1,8,10,15,11,0,14,11,0,3,2,1,15,10,14,14,0,10,14,10,11,512]

theorem envBound50516 : H12AffineFastState.Bounded env50516 := by
  intro p hp
  have h : env50516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50515_50516 : H12AffineEnvironment.transform 9 10 env50515 = env50516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env50515 == env50516) = true)

theorem identity50516 : scanCanonicalize (H12AffineFastState.compose env50516 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50516 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50517 : List Nat := [2,4,2,1,1,0,2,5,512,0,5,5,2,0,1,2,0,5,1,0,4,1,0,3,2,1,5,0,4,4,0,0,4,0,1,512]

theorem envBound50517 : H12AffineFastState.Bounded env50517 := by
  intro p hp
  have h : env50517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50516_50517 : H12AffineEnvironment.transform 2 2 env50516 = env50517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50516 == env50517) = true)

def env50518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4161,21792,17,21763,8193,65,171281,115015,17665,236851,119043,95530,257,98679,90202,63068]

theorem envBound50518 : H12AffineFastState.Bounded env50518 := by
  intro p hp
  have h : env50518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50503_50518 : H12AffineEnvironment.transform 6 9 env50503 = env50518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50503 == env50518) = true)

theorem identity50518 : scanCanonicalize (H12AffineFastState.compose env50518 (packedSelected [1,2,3,10,12,14,15,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound50518 : packedSelected [1,2,3,10,12,14,15,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env50519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,78959,89378,1025,32769,4161,21792,17,21763,8193,65,108926,115015,17665,43356,119043,95530,257,98679,90202,63068]

theorem envBound50519 : H12AffineFastState.Bounded env50519 := by
  intro p hp
  have h : env50519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50518_50519 : H12AffineEnvironment.transform 16 78959 env50518 = env50519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env50518 == env50519) = true)

theorem identity50519 : scanCanonicalize (H12AffineFastState.compose env50519 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50519 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,78959,89378,1025,29788,4161,21792,17,21763,8193,65,89379,79130,17665,23809,75102,95530,257,95530,90202,513]

theorem envBound50520 : H12AffineFastState.Bounded env50520 := by
  intro p hp
  have h : env50520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50519_50520 : H12AffineEnvironment.transform 14 29789 env50519 = env50520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50519 == env50520) = true)

theorem identity50520 : scanCanonicalize (H12AffineFastState.compose env50520 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound50520 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env50521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,24633,2420,1025,29788,4161,21792,17,21763,8193,65,2421,24908,17665,23809,28936,8572,257,8572,13324,513]

theorem envBound50521 : H12AffineFastState.Bounded env50521 := by
  intro p hp
  have h : env50521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50520_50521 : H12AffineEnvironment.transform 15 21590 env50520 = env50521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env50520 == env50521) = true)

theorem identity50521 : scanCanonicalize (H12AffineFastState.compose env50521 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50521 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5220,2420,1025,1,4161,8573,17,8542,8193,65,2421,5393,12636,10588,1365,8572,257,8572,13324,513]

theorem envBound50522 : H12AffineFastState.Bounded env50522 := by
  intro p hp
  have h : env50522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50521_50522 : H12AffineEnvironment.transform 13 13405 env50521 = env50522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50521 == env50522) = true)

theorem identity50522 : scanCanonicalize (H12AffineFastState.compose env50522 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50522 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50523 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,0,8203,5220,2049,1025,1,4161,8200,17,8235,8193,65,2048,5220,12329,10281,1056,8201,116,8201,13324,513]

theorem envBound50523 : H12AffineFastState.Bounded env50523 := by
  intro p hp
  have h : env50523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50522_50523 : H12AffineEnvironment.transform 7 117 env50522 = env50523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50522 == env50523) = true)

theorem identity50523 : scanCanonicalize (H12AffineFastState.compose env50523 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50523 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env50524 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,4096,8192,13405,0,8203,5220,0,1025,1,4161,8200,17,8235,8193,65,1,5220,12329,8232,1056,8201,116,8201,13324,513]

theorem envBound50524 : H12AffineFastState.Bounded env50524 := by
  intro p hp
  have h : env50524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50523_50524 : H12AffineEnvironment.transform 10 1 env50523 = env50524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50523 == env50524) = true)

def env50525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound50525 : H12AffineFastState.Bounded env50525 := by
  intro p hp
  have h : env50525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50098_50525 : H12AffineEnvironment.transform 26 30393345 env50098 = env50525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env50098 == env50525) = true)

def env50526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound50526 : H12AffineFastState.Bounded env50526 := by
  intro p hp
  have h : env50526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50525_50526 : H12AffineEnvironment.transform 18 1024 env50525 = env50526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env50525 == env50526) = true)

theorem identity50526 : scanCanonicalize (H12AffineFastState.compose env50526 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound50526 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362363,18973837,10507601,8456378,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound50527 : H12AffineFastState.Bounded env50527 := by
  intro p hp
  have h : env50527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50526_50527 : H12AffineEnvironment.transform 17 247994 env50526 = env50527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env50526 == env50527) = true)

def env50528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784807,5393,10507601,8456378,10491277,4256860,256,8410417,8434837,10564186]

theorem envBound50528 : H12AffineFastState.Bounded env50528 := by
  intro p hp
  have h : env50528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50527_50528 : H12AffineEnvironment.transform 23 2199964 env50527 = env50528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env50527 == env50528) = true)

def env50529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,8388608,98780,8328,65,12683623,5393,8406289,8456378,8390093,4256860,256,8410417,8434837,8462874]

theorem envBound50529 : H12AffineFastState.Bounded env50529 := by
  intro p hp
  have h : env50529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50528_50529 : H12AffineEnvironment.transform 20 4160 env50528 = env50529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50528 == env50529) = true)

def env50530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374560,98780,8328,65,215367,5393,4359473,4442266,4376045,4256860,256,4363537,4355253,4448826]

theorem envBound50530 : H12AffineFastState.Bounded env50530 := by
  intro p hp
  have h : env50530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50529_50530 : H12AffineEnvironment.transform 22 4374560 env50529 = env50530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env50529 == env50530) = true)

def env50531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100522,1024,32769,4160,4194304,4227120,98780,8328,65,67927,5393,4244769,4294794,4228605,4256860,256,4248833,4207781,4301354]

theorem envBound50531 : H12AffineFastState.Bounded env50531 := by
  intro p hp
  have h : env50531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50530_50531 : H12AffineEnvironment.transform 16 16400 env50530 = env50531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50530 == env50531) = true)

theorem identity50531 : scanCanonicalize (H12AffineFastState.compose env50531 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound50531 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100522,1024,32769,4160,168,32920,98780,8328,65,67927,5393,50569,100386,34133,62708,256,54697,13325,107138]

theorem envBound50532 : H12AffineFastState.Bounded env50532 := by
  intro p hp
  have h : env50532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50531_50532 : H12AffineEnvironment.transform 21 168 env50531 = env50532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env50531 == env50532) = true)

theorem identity50532 : scanCanonicalize (H12AffineFastState.compose env50532 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound50532 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env50533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10400,1024,32769,4160,168,32920,8662,8328,65,43357,5393,50569,10280,34133,62708,256,54697,13325,648]

theorem envBound50533 : H12AffineFastState.Bounded env50533 := by
  intro p hp
  have h : env50533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50532_50533 : H12AffineEnvironment.transform 15 40970 env50532 = env50533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env50532 == env50533) = true)

theorem identity50533 : scanCanonicalize (H12AffineFastState.compose env50533 (packedSelected [3,5,8,10,17,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50533 : packedSelected [3,5,8,10,17,28,31] rootPS < 2^1333 := by decide +kernel

def env50534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10281,1024,32769,4160,33,32785,8543,8193,65,43357,5393,50432,10280,34133,62589,256,54560,13325,513]

theorem envBound50534 : H12AffineFastState.Bounded env50534 := by
  intro p hp
  have h : env50534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50533_50534 : H12AffineEnvironment.transform 6 9 env50533 = env50534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50533 == env50534) = true)

theorem identity50534 : scanCanonicalize (H12AffineFastState.compose env50534 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50534 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21591,16400,10281,1024,29788,4160,33,29772,8543,8193,65,23808,5393,12637,10280,28936,32,256,8573,13325,513]

theorem envBound50535 : H12AffineFastState.Bounded env50535 := by
  intro p hp
  have h : env50535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50534_50535 : H12AffineEnvironment.transform 14 29789 env50534 = env50535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50534 == env50535) = true)

theorem identity50535 : scanCanonicalize (H12AffineFastState.compose env50535 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50535 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,5393,10281,1024,8541,4160,33,8525,8543,8193,65,2049,5393,12637,10280,9225,32,256,8573,13325,513]

theorem envBound50536 : H12AffineFastState.Bounded env50536 := by
  intro p hp
  have h : env50536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50535_50536 : H12AffineEnvironment.transform 13 5377 env50535 = env50536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50535 == env50536) = true)

theorem identity50536 : scanCanonicalize (H12AffineFastState.compose env50536 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50536 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env50537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5393,2420,1024,0,4160,33,16,2,348,65,2049,5393,4096,2421,1364,32,256,32,5456,513]

theorem envBound50537 : H12AffineFastState.Bounded env50537 := by
  intro p hp
  have h : env50537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50536_50537 : H12AffineEnvironment.transform 12 349 env50536 = env50537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50536 == env50537) = true)

theorem identity50537 : scanCanonicalize (H12AffineFastState.compose env50537 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50537 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50538 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,1,115,5172,2129,1024,0,4160,33,16,2,121,65,2049,5172,4096,2128,1137,32,37,32,5237,513]

theorem envBound50538 : H12AffineFastState.Bounded env50538 := by
  intro p hp
  have h : env50538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50537_50538 : H12AffineEnvironment.transform 7 37 env50537 = env50538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50537 == env50538) = true)

theorem identity50538 : scanCanonicalize (H12AffineFastState.compose env50538 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50538 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50539 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,1,115,4097,2129,53,0,4160,33,16,2,121,65,2049,4097,4096,2128,68,32,37,32,4160,513]

theorem envBound50539 : H12AffineFastState.Bounded env50539 := by
  intro p hp
  have h : env50539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50538_50539 : H12AffineEnvironment.transform 9 53 env50538 = env50539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50538 == env50539) = true)

theorem identity50539 : scanCanonicalize (H12AffineFastState.compose env50539 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound50539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50540 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,96,120,113,1,115,97,2129,53,0,32,33,16,2,121,65,2049,97,96,2128,68,32,37,32,32,513]

theorem envBound50540 : H12AffineFastState.Bounded env50540 := by
  intro p hp
  have h : env50540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50539_50540 : H12AffineEnvironment.transform 11 96 env50539 = env50540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env50539 == env50540) = true)

theorem identity50540 : scanCanonicalize (H12AffineFastState.compose env50540 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound50540 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50541 : List Nat := [2,4,8,16,32,64,9,37,512,53,80,96,120,113,1,115,97,1,53,0,32,33,16,2,121,65,81,97,96,0,68,32,37,32,32,513]

theorem envBound50541 : H12AffineFastState.Bounded env50541 := by
  intro p hp
  have h : env50541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50540_50541 : H12AffineEnvironment.transform 10 80 env50540 = env50541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env50540 == env50541) = true)

theorem identity50541 : scanCanonicalize (H12AffineFastState.compose env50541 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50541 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50542 : List Nat := [2,4,8,16,32,0,9,37,512,53,16,32,56,49,1,51,33,1,53,0,32,33,16,2,57,1,17,33,32,0,4,32,37,32,32,513]

theorem envBound50542 : H12AffineFastState.Bounded env50542 := by
  intro p hp
  have h : env50542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50541_50542 : H12AffineEnvironment.transform 5 0 env50541 = env50542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50541 == env50542) = true)

theorem identity50542 : scanCanonicalize (H12AffineFastState.compose env50542 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound50542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50543 : List Nat := [2,4,8,16,32,0,9,37,59,53,16,32,56,49,1,51,33,1,53,0,32,33,16,2,57,1,17,33,32,0,4,32,37,32,32,58]

theorem envBound50543 : H12AffineFastState.Bounded env50543 := by
  intro p hp
  have h : env50543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50542_50543 : H12AffineEnvironment.transform 8 59 env50542 = env50543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env50542 == env50543) = true)

theorem identity50543 : scanCanonicalize (H12AffineFastState.compose env50543 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50543 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env50544 : List Nat := [2,4,8,16,16,0,9,21,11,5,16,16,8,1,1,3,17,1,5,0,16,17,16,2,9,1,17,17,16,0,4,16,21,16,16,10]

theorem envBound50544 : H12AffineFastState.Bounded env50544 := by
  intro p hp
  have h : env50544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50543_50544 : H12AffineEnvironment.transform 4 16 env50543 = env50544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50543 == env50544) = true)

theorem identity50544 : scanCanonicalize (H12AffineFastState.compose env50544 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50544 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50545 : List Nat := [2,4,8,10,10,0,9,15,11,5,10,10,8,1,1,3,11,1,5,0,10,11,10,2,9,1,11,11,10,0,4,10,15,10,10,10]

theorem envBound50545 : H12AffineFastState.Bounded env50545 := by
  intro p hp
  have h : env50545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50544_50545 : H12AffineEnvironment.transform 3 10 env50544 = env50545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50544 == env50545) = true)

theorem identity50545 : scanCanonicalize (H12AffineFastState.compose env50545 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50546 : List Nat := [2,4,3,1,1,0,2,4,0,5,1,1,3,1,1,3,0,1,5,0,1,0,1,2,2,1,0,0,1,0,4,1,4,1,1,1]

theorem envBound50546 : H12AffineFastState.Bounded env50546 := by
  intro p hp
  have h : env50546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50545_50546 : H12AffineEnvironment.transform 2 3 env50545 = env50546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50545 == env50546) = true)

def env50547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,100523,1024,32769,4160,4194304,4227121,98780,8328,65,67926,5393,4244768,4294795,4228604,4256860,256,4248832,4207780,4301355]

theorem envBound50547 : H12AffineFastState.Bounded env50547 := by
  intro p hp
  have h : env50547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50530_50547 : H12AffineEnvironment.transform 16 16401 env50530 = env50547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50530 == env50547) = true)

theorem identity50547 : scanCanonicalize (H12AffineFastState.compose env50547 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound50547 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,16401,43049,1024,32769,4160,4194304,4227121,41310,8328,65,10708,5393,4244768,4237321,4228604,4256860,256,4248832,4207780,4227753]

theorem envBound50548 : H12AffineFastState.Bounded env50548 := by
  intro p hp
  have h : env50548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50547_50548 : H12AffineEnvironment.transform 15 8322 env50547 = env50548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env50547 == env50548) = true)

theorem identity50548 : scanCanonicalize (H12AffineFastState.compose env50548 (packedSelected [1,3,4,7,9,10,14,16,19,20,24,26,27,28,31,35] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound50548 : packedSelected [1,3,4,7,9,10,14,16,19,20,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,16401,43049,1024,32769,4160,32936,153,41310,8328,65,10708,5393,17800,10401,1364,29940,256,21928,46092,513]

theorem envBound50549 : H12AffineFastState.Bounded env50549 := by
  intro p hp
  have h : env50549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50548_50549 : H12AffineEnvironment.transform 21 32936 env50548 = env50549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env50548 == env50549) = true)

theorem identity50549 : scanCanonicalize (H12AffineFastState.compose env50549 (packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50549 : packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env50550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32800,17,41310,8192,65,10588,5393,17664,10281,1364,29820,256,21792,46092,513]

theorem envBound50550 : H12AffineFastState.Bounded env50550 := by
  intro p hp
  have h : env50550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50549_50550 : H12AffineEnvironment.transform 6 8 env50549 = env50550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50549 == env50550) = true)

theorem identity50550 : scanCanonicalize (H12AffineFastState.compose env50550 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50550 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2421,1024,8541,4160,8572,17,2,8192,65,10588,5393,17664,10281,1364,29820,256,21792,5456,513]

theorem envBound50551 : H12AffineFastState.Bounded env50551 := by
  intro p hp
  have h : env50551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50550_50551 : H12AffineEnvironment.transform 14 8540 env50550 = env50551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50550 == env50551) = true)

theorem identity50551 : scanCanonicalize (H12AffineFastState.compose env50551 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50551 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50552 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8312,8202,16401,2129,1024,8313,4160,8280,17,2,8192,65,10360,5173,17444,10281,1136,29820,36,21508,5236,513]

theorem envBound50552 : H12AffineFastState.Bounded env50552 := by
  intro p hp
  have h : env50552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50551_50552 : H12AffineEnvironment.transform 7 36 env50551 = env50552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50551 == env50552) = true)

theorem identity50552 : scanCanonicalize (H12AffineFastState.compose env50552 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound50552 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env50553 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8312,8202,12408,2129,1024,8313,4160,8280,17,2,8192,65,10360,5173,13389,10281,1136,1045,36,9325,5236,513]

theorem envBound50553 : H12AffineFastState.Bounded env50553 := by
  intro p hp
  have h : env50553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50552_50553 : H12AffineEnvironment.transform 13 12393 env50552 = env50553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env50552 == env50553) = true)

def env50554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374561,98780,8328,65,215366,5393,4359472,4442267,4376044,4256860,256,4363536,4355252,4448827]

theorem envBound50554 : H12AffineFastState.Bounded env50554 := by
  intro p hp
  have h : env50554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50529_50554 : H12AffineEnvironment.transform 22 4374561 env50529 = env50554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env50529 == env50554) = true)

theorem identity50554 : scanCanonicalize (H12AffineFastState.compose env50554 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound50554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,180273,16,98780,8328,65,215366,5393,17665,67754,1501,144493,256,21793,46213,74250]

theorem envBound50555 : H12AffineFastState.Bounded env50555 := by
  intro p hp
  have h : env50555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50554_50555 : H12AffineEnvironment.transform 21 180273 env50554 = env50555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env50554 == env50555) = true)

def env50556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180273,16,98644,8192,65,215366,5393,17665,67618,1365,144493,256,21793,46093,74250]

theorem envBound50556 : H12AffineFastState.Bounded env50556 := by
  intro p hp
  have h : env50556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50555_50556 : H12AffineEnvironment.transform 6 8 env50555 = env50556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50555 == env50556) = true)

theorem identity50556 : scanCanonicalize (H12AffineFastState.compose env50556 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound50556 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35188,1024,32769,4160,98679,16,98644,8192,65,2048,5393,17665,67618,1365,95531,256,21793,46093,74250]

theorem envBound50557 : H12AffineFastState.Bounded env50557 := by
  intro p hp
  have h : env50557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50556_50557 : H12AffineEnvironment.transform 16 82246 env50556 = env50557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env50556 == env50557) = true)

theorem identity50557 : scanCanonicalize (H12AffineFastState.compose env50557 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50557 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82246,35188,1024,32769,4160,98679,16,98644,348,65,2048,5393,17665,67618,1365,87159,256,21793,38225,66390]

theorem envBound50558 : H12AffineFastState.Bounded env50558 := by
  intro p hp
  have h : env50558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50557_50558 : H12AffineEnvironment.transform 12 348 env50557 = env50558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50557 == env50558) = true)

theorem identity50558 : scanCanonicalize (H12AffineFastState.compose env50558 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound50558 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21590,5392,35188,1024,32769,4160,54561,16,54530,348,65,2048,5393,17665,23668,1365,33,256,21793,38225,22272]

theorem envBound50559 : H12AffineFastState.Bounded env50559 := by
  intro p hp
  have h : env50559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50558_50559 : H12AffineEnvironment.transform 15 21590 env50558 = env50559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env50558 == env50559) = true)

theorem identity50559 : scanCanonicalize (H12AffineFastState.compose env50559 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound50559 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,5392,23668,1024,21761,4160,33,16,2,348,65,2048,5393,17665,23668,1365,33,256,21793,16465,22272]

theorem envBound50560 : H12AffineFastState.Bounded env50560 := by
  intro p hp
  have h : env50560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50559_50560 : H12AffineEnvironment.transform 14 21760 env50559 = env50560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env50559 == env50560) = true)

theorem identity50560 : scanCanonicalize (H12AffineFastState.compose env50560 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1140) := by decide +kernel

theorem selectedBound50560 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env50561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1140,4468,4130,5392,6144,1024,4469,4160,33,16,2,348,65,2048,5393,373,6144,1365,33,256,4437,1061,4980]

theorem envBound50561 : H12AffineFastState.Bounded env50561 := by
  intro p hp
  have h : env50561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50560_50561 : H12AffineEnvironment.transform 13 1140 env50560 = env50561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1140 env50560 == env50561) = true)

theorem identity50561 : scanCanonicalize (H12AffineFastState.compose env50561 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound50561 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env50562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,64,4096,348,1140,4468,4130,5392,4160,1024,4469,4160,33,16,2,348,65,64,5393,373,4160,1365,33,256,4437,1061,4980]

theorem envBound50562 : H12AffineFastState.Bounded env50562 := by
  intro p hp
  have h : env50562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50561_50562 : H12AffineEnvironment.transform 10 64 env50561 = env50562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env50561 == env50562) = true)

theorem identity50562 : scanCanonicalize (H12AffineFastState.compose env50562 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound50562 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env50563 : List Nat := [2,4,8,16,32,64,8,53,512,1024,64,4096,105,1140,4161,4130,5157,4160,1024,4160,4160,33,16,2,105,65,64,5156,64,4160,1120,33,53,4192,1061,4673]

theorem envBound50563 : H12AffineFastState.Bounded env50563 := by
  intro p hp
  have h : env50563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50562_50563 : H12AffineEnvironment.transform 7 53 env50562 = env50563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env50562 == env50563) = true)

theorem identity50563 : scanCanonicalize (H12AffineFastState.compose env50563 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound50563 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env50564 : List Nat := [2,4,8,16,32,64,8,53,512,84,64,4096,105,32,4161,4130,4209,4160,84,4160,4160,33,16,2,105,65,64,4208,64,4160,52,33,53,4192,113,4673]

theorem envBound50564 : H12AffineFastState.Bounded env50564 := by
  intro p hp
  have h : env50564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50563_50564 : H12AffineEnvironment.transform 9 84 env50563 = env50564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env50563 == env50564) = true)

theorem identity50564 : scanCanonicalize (H12AffineFastState.compose env50564 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound50564 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env50565 : List Nat := [2,4,8,16,32,64,8,53,512,84,64,65,105,32,0,99,48,1,84,1,1,33,16,2,105,65,64,49,64,1,52,33,53,33,113,512]

theorem envBound50565 : H12AffineFastState.Bounded env50565 := by
  intro p hp
  have h : env50565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50564_50565 : H12AffineEnvironment.transform 11 65 env50564 = env50565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env50564 == env50565) = true)

theorem identity50565 : scanCanonicalize (H12AffineFastState.compose env50565 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound50565 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50566 : List Nat := [2,4,8,16,32,64,8,53,65,84,64,65,105,32,0,99,48,1,84,1,1,33,16,2,105,65,64,49,64,1,52,33,53,33,113,65]

theorem envBound50566 : H12AffineFastState.Bounded env50566 := by
  intro p hp
  have h : env50566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50565_50566 : H12AffineEnvironment.transform 8 65 env50565 = env50566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env50565 == env50566) = true)

theorem identity50566 : scanCanonicalize (H12AffineFastState.compose env50566 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound50566 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50567 : List Nat := [2,4,8,16,32,49,8,53,48,37,49,48,24,32,0,18,48,1,37,1,1,33,16,2,24,48,49,49,49,1,52,33,53,33,0,48]

theorem envBound50567 : H12AffineFastState.Bounded env50567 := by
  intro p hp
  have h : env50567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50566_50567 : H12AffineEnvironment.transform 5 49 env50566 = env50567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env50566 == env50567) = true)

def env50568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180273,16,98645,8193,65,215366,5393,17665,67619,1364,144493,256,21793,46092,74250]

theorem envBound50568 : H12AffineFastState.Bounded env50568 := by
  intro p hp
  have h : env50568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50555_50568 : H12AffineEnvironment.transform 6 9 env50555 = env50568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50555 == env50568) = true)

theorem identity50568 : scanCanonicalize (H12AffineFastState.compose env50568 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound50568 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4160,73771,16,98645,8193,65,43356,5393,17665,67619,1364,119927,256,21793,46092,74250]

theorem envBound50569 : H12AffineFastState.Bounded env50569 := by
  intro p hp
  have h : env50569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50568_50569 : H12AffineEnvironment.transform 16 122906 env50568 = env50569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env50568 == env50569) = true)

theorem identity50569 : scanCanonicalize (H12AffineFastState.compose env50569 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound50569 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env50570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1024,32769,4160,32800,16,8542,8193,65,43356,5393,17665,43048,1364,29820,256,21793,46092,33281]

theorem envBound50570 : H12AffineFastState.Bounded env50570 := by
  intro p hp
  have h : env50570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50569_50570 : H12AffineEnvironment.transform 15 40971 env50569 = env50570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env50569 == env50570) = true)

def env50571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,8388608,98781,8328,65,12683622,5393,8406288,8456378,8390092,4256860,256,8410417,8434837,8462875]

theorem envBound50571 : H12AffineFastState.Bounded env50571 := by
  intro p hp
  have h : env50571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50528_50571 : H12AffineEnvironment.transform 20 4161 env50528 = env50571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50528 == env50571) = true)

def env50572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374560,98781,8328,65,215366,5393,4359472,4442266,4376044,4256860,256,4363537,4355253,4448827]

theorem envBound50572 : H12AffineFastState.Bounded env50572 := by
  intro p hp
  have h : env50572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50571_50572 : H12AffineEnvironment.transform 22 4374560 env50571 = env50572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env50571 == env50572) = true)

theorem identity50572 : scanCanonicalize (H12AffineFastState.compose env50572 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50572 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4161,4194304,4338932,95497,8328,65,215366,5393,4354532,4406350,4337976,4194440,256,4350405,4355253,4396783]

theorem envBound50573 : H12AffineFastState.Bounded env50573 := by
  intro p hp
  have h : env50573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50572_50573 : H12AffineEnvironment.transform 14 29908 env50572 = env50573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50572 == env50573) = true)

def env50574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4161,144612,16,95497,8328,65,215366,5393,17664,67754,1500,144492,256,21793,16465,74251]

theorem envBound50574 : H12AffineFastState.Bounded env50574 := by
  intro p hp
  have h : env50574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50573_50574 : H12AffineEnvironment.transform 21 144612 env50573 = env50574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144612 env50573 == env50574) = true)

theorem identity50574 : scanCanonicalize (H12AffineFastState.compose env50574 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50574 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,138340,1024,29909,4161,144612,16,21763,8328,65,158028,5393,17664,10400,1500,144492,256,21793,16465,513]

theorem envBound50575 : H12AffineFastState.Bounded env50575 := by
  intro p hp
  have h : env50575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50574_50575 : H12AffineEnvironment.transform 15 8202 env50574 = env50575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50574 == env50575) = true)

theorem identity50575 : scanCanonicalize (H12AffineFastState.compose env50575 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound50575 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env50576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,8202,131072,138340,1024,8580,4161,144612,16,82,8328,65,146461,5393,4177,10400,1500,144492,256,112,5376,513]

theorem envBound50576 : H12AffineFastState.Bounded env50576 := by
  intro p hp
  have h : env50576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50575_50576 : H12AffineEnvironment.transform 13 5457 env50575 = env50576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env50575 == env50576) = true)

theorem identity50576 : scanCanonicalize (H12AffineFastState.compose env50576 (packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50576 : packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env50577 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,8202,131072,138292,1024,8580,4113,144564,16,2,8328,17,146461,5393,4097,10400,1420,144444,256,32,5376,513]

theorem envBound50577 : H12AffineFastState.Bounded env50577 := by
  intro p hp
  have h : env50577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50576_50577 : H12AffineEnvironment.transform 5 16 env50576 = env50577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50576 == env50577) = true)

theorem identity50577 : scanCanonicalize (H12AffineFastState.compose env50577 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50578 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,137,262,131072,138292,1024,136,4113,136632,16,2,388,17,138513,5393,4097,2476,1420,136496,256,32,5376,513]

theorem envBound50578 : H12AffineFastState.Bounded env50578 := by
  intro p hp
  have h : env50578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50577_50578 : H12AffineEnvironment.transform 12 268 env50577 = env50578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50577 == env50578) = true)

theorem identity50578 : scanCanonicalize (H12AffineFastState.compose env50578 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 1589) := by decide +kernel

theorem selectedBound50578 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env50579 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,137,262,1589,6657,1024,136,4113,5005,16,2,388,17,6948,5393,4097,2476,1420,4869,256,32,5376,513]

theorem envBound50579 : H12AffineFastState.Bounded env50579 := by
  intro p hp
  have h : env50579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50578_50579 : H12AffineEnvironment.transform 16 1589 env50578 = env50579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1589 env50578 == env50579) = true)

theorem identity50579 : scanCanonicalize (H12AffineFastState.compose env50579 (packedSelected [17] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound50579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50580 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,804,268,1573,137,262,1589,2341,1024,136,821,169,16,2,388,17,2048,1589,805,2476,1420,33,256,32,1572,513]

theorem envBound50580 : H12AffineFastState.Bounded env50580 := by
  intro p hp
  have h : env50580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50579_50580 : H12AffineEnvironment.transform 11 804 env50579 = env50580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env50579 == env50580) = true)

theorem identity50580 : scanCanonicalize (H12AffineFastState.compose env50580 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50580 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50581 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,804,268,529,137,262,513,2341,52,136,821,169,16,2,388,17,2048,513,805,2476,440,33,256,32,528,513]

theorem envBound50581 : H12AffineFastState.Bounded env50581 := by
  intro p hp
  have h : env50581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50580_50581 : H12AffineEnvironment.transform 9 52 env50580 = env50581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50580 == env50581) = true)

theorem identity50581 : scanCanonicalize (H12AffineFastState.compose env50581 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound50581 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50582 : List Nat := [2,4,8,16,32,16,128,256,260,52,2048,32,268,277,137,262,261,2341,52,136,49,169,16,2,388,17,2048,261,33,2476,440,33,256,32,276,261]

theorem envBound50582 : H12AffineFastState.Bounded env50582 := by
  intro p hp
  have h : env50582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50581_50582 : H12AffineEnvironment.transform 8 260 env50581 = env50582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env50581 == env50582) = true)

theorem identity50582 : scanCanonicalize (H12AffineFastState.compose env50582 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound50582 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env50583 : List Nat := [2,4,8,16,32,16,128,256,260,52,390,32,268,277,137,262,261,163,52,136,49,169,16,2,388,17,390,261,33,42,440,33,256,32,276,261]

theorem envBound50583 : H12AffineFastState.Bounded env50583 := by
  intro p hp
  have h : env50583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50582_50583 : H12AffineEnvironment.transform 10 390 env50582 = env50583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env50582 == env50583) = true)

theorem identity50583 : scanCanonicalize (H12AffineFastState.compose env50583 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50583 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env50584 : List Nat := [2,4,8,16,1,16,128,256,260,21,390,1,268,277,137,262,261,130,21,136,16,136,16,2,388,17,390,261,0,11,409,0,256,1,276,261]

theorem envBound50584 : H12AffineFastState.Bounded env50584 := by
  intro p hp
  have h : env50584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50583_50584 : H12AffineEnvironment.transform 4 1 env50583 = env50584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50583 == env50584) = true)

theorem identity50584 : scanCanonicalize (H12AffineFastState.compose env50584 (packedSelected [3,4] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound50584 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env50585 : List Nat := [2,4,8,16,1,16,128,8,12,21,142,1,4,29,137,14,13,130,21,136,16,136,16,2,140,17,142,13,0,11,145,0,8,1,28,13]

theorem envBound50585 : H12AffineFastState.Bounded env50585 := by
  intro p hp
  have h : env50585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50584_50585 : H12AffineEnvironment.transform 7 8 env50584 = env50585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env50584 == env50585) = true)

theorem identity50585 : scanCanonicalize (H12AffineFastState.compose env50585 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50585 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env50586 : List Nat := [2,4,8,16,1,16,8,8,12,21,6,1,4,29,1,14,13,10,21,0,16,0,16,2,4,17,6,13,0,11,25,0,8,1,28,13]

theorem envBound50586 : H12AffineFastState.Bounded env50586 := by
  intro p hp
  have h : env50586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50585_50586 : H12AffineEnvironment.transform 6 8 env50585 = env50586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50585 == env50586) = true)

theorem identity50586 : scanCanonicalize (H12AffineFastState.compose env50586 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50586 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50587 : List Nat := [2,4,8,11,1,11,8,8,12,14,6,1,4,6,1,14,13,10,14,0,11,0,11,2,4,10,6,13,0,11,2,0,8,1,7,13]

theorem envBound50587 : H12AffineFastState.Bounded env50587 := by
  intro p hp
  have h : env50587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50586_50587 : H12AffineEnvironment.transform 3 11 env50586 = env50587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50586 == env50587) = true)

theorem identity50587 : scanCanonicalize (H12AffineFastState.compose env50587 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50588 : List Nat := [0,4,8,9,1,9,8,8,12,12,4,1,4,4,1,12,13,8,12,0,9,0,9,0,4,8,4,13,0,9,0,0,8,1,5,13]

theorem envBound50588 : H12AffineFastState.Bounded env50588 := by
  intro p hp
  have h : env50588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50587_50588 : H12AffineEnvironment.transform 0 0 env50587 = env50588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50587 == env50588) = true)

theorem identity50588 : scanCanonicalize (H12AffineFastState.compose env50588 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50589 : List Nat := [0,4,4,5,1,5,4,4,0,0,4,1,4,4,1,0,1,4,0,0,5,0,5,0,4,4,4,1,0,5,0,0,4,1,5,1]

theorem envBound50589 : H12AffineFastState.Bounded env50589 := by
  intro p hp
  have h : env50589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50588_50589 : H12AffineEnvironment.transform 2 4 env50588 = env50589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50588 == env50589) = true)

theorem identity50589 : scanCanonicalize (H12AffineFastState.compose env50589 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50589 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50590 : List Nat := [0,1,1,0,1,0,1,1,0,0,1,1,1,1,1,0,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,1]

theorem envBound50590 : H12AffineFastState.Bounded env50590 := by
  intro p hp
  have h : env50590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50589_50590 : H12AffineEnvironment.transform 1 1 env50589 = env50590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50589 == env50590) = true)

def env50591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4161,144613,17,95497,8328,65,215366,5393,17665,67755,1501,144493,256,21792,16464,74250]

theorem envBound50591 : H12AffineFastState.Bounded env50591 := by
  intro p hp
  have h : env50591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50573_50591 : H12AffineEnvironment.transform 21 144613 env50573 = env50591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env50573 == env50591) = true)

def env50592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212078,1024,8661,4161,144613,17,73737,8328,65,203846,5393,4097,67755,1501,144493,256,32,5456,74250]

theorem envBound50592 : H12AffineFastState.Bounded env50592 := by
  intro p hp
  have h : env50592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50591_50592 : H12AffineEnvironment.transform 13 5376 env50591 = env50592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50591 == env50592) = true)

theorem identity50592 : scanCanonicalize (H12AffineFastState.compose env50592 (packedSelected [0,1,3,9,11,16,20,22,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound50592 : packedSelected [0,1,3,9,11,16,20,22,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env50593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5576,76198,1024,8661,4161,8493,17,73737,8328,65,67982,5393,4097,67755,1501,8613,256,32,5456,74250]

theorem envBound50593 : H12AffineFastState.Bounded env50593 := by
  intro p hp
  have h : env50593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50592_50593 : H12AffineEnvironment.transform 16 5576 env50592 = env50593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env50592 == env50593) = true)

theorem identity50593 : scanCanonicalize (H12AffineFastState.compose env50593 (packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound50593 : packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env50594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,65536,5576,67699,1024,0,4161,248,17,66012,349,65,67982,5393,4097,67755,1501,112,256,32,5456,66527]

theorem envBound50594 : H12AffineFastState.Bounded env50594 := by
  intro p hp
  have h : env50594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50593_50594 : H12AffineEnvironment.transform 12 469 env50593 = env50594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env50593 == env50594) = true)

theorem identity50594 : scanCanonicalize (H12AffineFastState.compose env50594 (packedSelected [0,1,5,6,7,8,14,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50594 : packedSelected [0,1,5,6,7,8,14,20,24] rootPS < 2^1333 := by decide +kernel

def env50595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,5441,67699,1024,0,4161,113,17,65877,349,65,67847,5393,4097,67618,1364,112,256,32,5456,66390]

theorem envBound50595 : H12AffineFastState.Bounded env50595 := by
  intro p hp
  have h : env50595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50594_50595 : H12AffineEnvironment.transform 6 9 env50594 = env50595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50594 == env50595) = true)

theorem identity50595 : scanCanonicalize (H12AffineFastState.compose env50595 (packedSelected [1,2,3,4,5,8,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound50595 : packedSelected [1,2,3,4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env50596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,1095,5441,3124,1024,0,4161,113,17,1298,349,65,3392,5393,4097,3173,1364,112,256,32,5456,1809]

theorem envBound50596 : H12AffineFastState.Bounded env50596 := by
  intro p hp
  have h : env50596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50595_50596 : H12AffineEnvironment.transform 15 1095 env50595 = env50596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env50595 == env50596) = true)

theorem identity50596 : scanCanonicalize (H12AffineFastState.compose env50596 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50596 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50597 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,348,4160,1,263,4097,2420,320,0,4161,113,17,82,349,65,2048,4177,4097,2341,20,112,256,32,4112,593]

theorem envBound50597 : H12AffineFastState.Bounded env50597 := by
  intro p hp
  have h : env50597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50596_50597 : H12AffineEnvironment.transform 9 320 env50596 = env50597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50596 == env50597) = true)

theorem identity50597 : scanCanonicalize (H12AffineFastState.compose env50597 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound50597 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50598 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2097,348,2161,1,263,2096,2420,320,0,2160,113,17,82,349,65,2048,2144,2096,2341,20,112,256,32,2081,593]

theorem envBound50598 : H12AffineFastState.Bounded env50598 := by
  intro p hp
  have h : env50598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50597_50598 : H12AffineEnvironment.transform 11 2097 env50597 = env50598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env50597 == env50598) = true)

theorem identity50598 : scanCanonicalize (H12AffineFastState.compose env50598 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50598 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env50599 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,2097,300,2049,1,263,2096,2308,304,0,2048,1,17,34,301,49,2048,2064,2096,2341,20,0,256,32,2081,545]

theorem envBound50599 : H12AffineFastState.Bounded env50599 := by
  intro p hp
  have h : env50599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50598_50599 : H12AffineEnvironment.transform 5 48 env50598 = env50599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50598 == env50599) = true)

def env50600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212078,1024,8660,4161,144613,17,73736,8328,65,203847,5393,4096,67755,1501,144493,256,33,5457,74250]

theorem envBound50600 : H12AffineFastState.Bounded env50600 := by
  intro p hp
  have h : env50600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50591_50600 : H12AffineEnvironment.transform 13 5377 env50591 = env50600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50591 == env50600) = true)

theorem identity50600 : scanCanonicalize (H12AffineFastState.compose env50600 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50600 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,212078,1024,8541,4161,144492,17,73736,8193,65,203847,5393,4096,67618,1364,144493,256,33,5457,74250]

theorem envBound50601 : H12AffineFastState.Bounded env50601 := by
  intro p hp
  have h : env50601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50600_50601 : H12AffineEnvironment.transform 6 9 env50600 = env50601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50600 == env50601) = true)

def env50602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374561,98781,8328,65,215367,5393,4359473,4442267,4376045,4256860,256,4363536,4355252,4448826]

theorem envBound50602 : H12AffineFastState.Bounded env50602 := by
  intro p hp
  have h : env50602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50571_50602 : H12AffineEnvironment.transform 22 4374561 env50571 = env50602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env50571 == env50602) = true)

theorem identity50602 : scanCanonicalize (H12AffineFastState.compose env50602 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound50602 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,144613,62660,98781,8328,65,215367,5393,45524,130174,61704,180409,256,41461,16465,120543]

theorem envBound50603 : H12AffineFastState.Bounded env50603 := by
  intro p hp
  have h : env50603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50602_50603 : H12AffineEnvironment.transform 21 144613 env50602 = env50603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env50602 == env50603) = true)

def env50604 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4113,144565,62612,98701,8328,17,215319,5393,45444,130094,61704,180409,256,41381,16385,120463]

theorem envBound50604 : H12AffineFastState.Bounded env50604 := by
  intro p hp
  have h : env50604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50603_50604 : H12AffineEnvironment.transform 5 16 env50603 = env50604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50603 == env50604) = true)

theorem identity50604 : scanCanonicalize (H12AffineFastState.compose env50604 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 46228) := by decide +kernel

theorem selectedBound50604 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env50605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46228,97326,1024,32769,4113,32801,62612,98701,8328,17,130435,5393,45444,130094,61704,29741,256,41381,16385,120463]

theorem envBound50605 : H12AffineFastState.Bounded env50605 := by
  intro p hp
  have h : env50605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50604_50605 : H12AffineEnvironment.transform 16 46228 env50604 = env50605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46228 env50604 == env50605) = true)

theorem identity50605 : scanCanonicalize (H12AffineFastState.compose env50605 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound50605 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46228,43168,1024,32769,4113,32801,62612,21763,8328,17,10509,5393,45444,10400,61704,29741,256,41381,16385,513]

theorem envBound50606 : H12AffineFastState.Bounded env50606 := by
  intro p hp
  have h : env50606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50605_50606 : H12AffineEnvironment.transform 15 54414 env50605 = env50606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env50605 == env50606) = true)

theorem identity50606 : scanCanonicalize (H12AffineFastState.compose env50606 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound50606 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8202,16400,23588,1024,29829,4113,29861,16,21763,8328,17,10509,5393,17664,10400,1420,29741,256,21793,16385,513]

theorem envBound50607 : H12AffineFastState.Bounded env50607 := by
  intro p hp
  have h : env50607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50606_50607 : H12AffineEnvironment.transform 14 29828 env50606 = env50607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env50606 == env50607) = true)

theorem identity50607 : scanCanonicalize (H12AffineFastState.compose env50607 (packedSelected [3,4,5,7,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50607 : packedSelected [3,4,5,7,15,17,18] rootPS < 2^1333 := by decide +kernel

def env50608 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,136,8202,13340,10280,1024,137,4113,169,16,8463,8328,17,10509,5393,12556,10400,1420,33,256,8493,13325,513]

theorem envBound50608 : H12AffineFastState.Bounded env50608 := by
  intro p hp
  have h : env50608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50607_50608 : H12AffineEnvironment.transform 13 13324 env50607 = env50608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50607 == env50608) = true)

theorem identity50608 : scanCanonicalize (H12AffineFastState.compose env50608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound50608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50609 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,8192,12693,136,8202,12677,10280,409,137,4113,169,16,8463,8328,17,10509,4232,12556,10400,21,33,256,8493,12692,513]

theorem envBound50609 : H12AffineFastState.Bounded env50609 := by
  intro p hp
  have h : env50609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50608_50609 : H12AffineEnvironment.transform 9 409 env50608 = env50609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env50608 == env50609) = true)

theorem identity50609 : scanCanonicalize (H12AffineFastState.compose env50609 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2731) := by decide +kernel

theorem selectedBound50609 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50610 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,2731,6974,136,2721,6958,643,409,137,4113,169,16,2980,2595,17,934,4232,7079,523,21,33,256,2950,6975,513]

theorem envBound50610 : H12AffineFastState.Bounded env50610 := by
  intro p hp
  have h : env50610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50609_50610 : H12AffineEnvironment.transform 12 2731 env50609 = env50610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2731 env50609 == env50610) = true)

theorem identity50610 : scanCanonicalize (H12AffineFastState.compose env50610 (packedSelected [1,3,7,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2461) := by decide +kernel

theorem selectedBound50610 : packedSelected [1,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env50611 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,2461,2731,675,136,2721,691,643,409,137,2444,169,16,2980,2595,17,934,2325,570,523,21,33,256,2950,674,513]

theorem envBound50611 : H12AffineFastState.Bounded env50611 := by
  intro p hp
  have h : env50611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50610_50611 : H12AffineEnvironment.transform 11 2461 env50610 = env50611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2461 env50610 == env50611) = true)

theorem identity50611 : scanCanonicalize (H12AffineFastState.compose env50611 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50611 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50612 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2324,2594,554,1,2600,570,522,272,0,2309,32,16,2861,2595,17,815,2325,570,523,21,33,256,2831,555,513]

theorem envBound50612 : H12AffineFastState.Bounded env50612 := by
  intro p hp
  have h : env50612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50611_50612 : H12AffineEnvironment.transform 6 9 env50611 = env50612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50611 == env50612) = true)

theorem identity50612 : scanCanonicalize (H12AffineFastState.compose env50612 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound50612 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50613 : List Nat := [2,4,8,16,32,16,9,256,271,272,2048,2324,2349,293,1,2343,309,261,272,0,2309,32,16,2082,2348,17,32,2325,309,260,21,33,256,2048,292,270]

theorem envBound50613 : H12AffineFastState.Bounded env50613 := by
  intro p hp
  have h : env50613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50612_50613 : H12AffineEnvironment.transform 8 271 env50612 = env50613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env50612 == env50613) = true)

theorem identity50613 : scanCanonicalize (H12AffineFastState.compose env50613 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50613 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50614 : List Nat := [2,4,8,16,32,16,9,5,10,21,2048,2065,2088,32,1,2082,48,0,21,0,2048,32,16,2082,2089,17,32,2064,48,1,21,33,5,2048,33,11]

theorem envBound50614 : H12AffineFastState.Bounded env50614 := by
  intro p hp
  have h : env50614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50613_50614 : H12AffineEnvironment.transform 7 5 env50613 = env50614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50613 == env50614) = true)

theorem identity50614 : scanCanonicalize (H12AffineFastState.compose env50614 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound50614 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50615 : List Nat := [2,4,8,16,32,16,9,5,10,21,33,48,9,32,1,3,48,0,21,0,33,32,16,3,8,17,32,49,48,1,21,33,5,33,33,11]

theorem envBound50615 : H12AffineFastState.Bounded env50615 := by
  intro p hp
  have h : env50615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50614_50615 : H12AffineEnvironment.transform 10 33 env50614 = env50615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env50614 == env50615) = true)

theorem identity50615 : scanCanonicalize (H12AffineFastState.compose env50615 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50616 : List Nat := [2,4,8,16,0,16,9,5,10,21,1,16,9,0,1,3,16,0,21,0,1,0,16,3,8,17,0,17,16,1,21,1,5,1,1,11]

theorem envBound50616 : H12AffineFastState.Bounded env50616 := by
  intro p hp
  have h : env50616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50615_50616 : H12AffineEnvironment.transform 4 0 env50615 = env50616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50615 == env50616) = true)

theorem identity50616 : scanCanonicalize (H12AffineFastState.compose env50616 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound50616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50617 : List Nat := [2,4,7,16,0,16,6,5,5,21,1,16,6,0,1,3,16,0,21,0,1,0,16,3,7,17,0,17,16,1,21,1,5,1,1,4]

theorem envBound50617 : H12AffineFastState.Bounded env50617 := by
  intro p hp
  have h : env50617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50616_50617 : H12AffineEnvironment.transform 2 7 env50616 = env50617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env50616 == env50617) = true)

theorem identity50617 : scanCanonicalize (H12AffineFastState.compose env50617 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50618 : List Nat := [2,4,7,6,0,6,6,5,5,3,1,6,6,0,1,3,6,0,3,0,1,0,6,3,7,7,0,7,6,1,3,1,5,1,1,4]

theorem envBound50618 : H12AffineFastState.Bounded env50618 := by
  intro p hp
  have h : env50618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50617_50618 : H12AffineEnvironment.transform 3 6 env50617 = env50618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50617 == env50618) = true)

def env50619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4112,144564,62613,98700,8328,16,215318,5393,45445,130095,61704,180409,256,41380,16384,120462]

theorem envBound50619 : H12AffineFastState.Bounded env50619 := by
  intro p hp
  have h : env50619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50603_50619 : H12AffineEnvironment.transform 5 17 env50603 = env50619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50603 == env50619) = true)

theorem identity50619 : scanCanonicalize (H12AffineFastState.compose env50619 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50619 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env50620 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,65536,131072,215226,1024,1,4112,144564,29845,65932,8328,16,215318,5393,12677,97327,28936,147641,256,8612,16384,87694]

theorem envBound50620 : H12AffineFastState.Bounded env50620 := by
  intro p hp
  have h : env50620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50619_50620 : H12AffineEnvironment.transform 14 0 env50619 = env50620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50619 == env50620) = true)

theorem identity50620 : scanCanonicalize (H12AffineFastState.compose env50620 (packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound50620 : packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50621 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,263,131072,149949,1024,1,4112,144564,29845,139,8328,16,149521,5393,12677,32040,28936,147641,256,8612,16384,22409]

theorem envBound50621 : H12AffineFastState.Bounded env50621 := by
  intro p hp
  have h : env50621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50620_50621 : H12AffineEnvironment.transform 15 263 env50620 = env50621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env50620 == env50621) = true)

theorem identity50621 : scanCanonicalize (H12AffineFastState.compose env50621 (packedSelected [16,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50621 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env50622 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,263,13340,32161,1024,1,4112,168,29845,139,8328,16,31757,5393,12677,32040,28936,29861,256,8612,16384,22409]

theorem envBound50622 : H12AffineFastState.Bounded env50622 := by
  intro p hp
  have h : env50622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50621_50622 : H12AffineEnvironment.transform 16 13340 env50621 = env50622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env50621 == env50622) = true)

theorem identity50622 : scanCanonicalize (H12AffineFastState.compose env50622 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound50622 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env50623 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,0,263,13340,10281,1024,1,4112,168,8477,139,8328,16,10629,5393,12677,10400,9344,8493,256,8612,5512,513]

theorem envBound50623 : H12AffineFastState.Bounded env50623 := by
  intro p hp
  have h : env50623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50622_50623 : H12AffineEnvironment.transform 13 5512 env50622 = env50623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env50622 == env50623) = true)

theorem identity50623 : scanCanonicalize (H12AffineFastState.compose env50623 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound50623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50624 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,0,263,5528,2477,1024,1,4112,168,153,139,268,16,2049,5393,4097,2340,1284,169,256,32,5512,513]

theorem envBound50624 : H12AffineFastState.Bounded env50624 := by
  intro p hp
  have h : env50624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50623_50624 : H12AffineEnvironment.transform 12 388 env50623 = env50624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env50623 == env50624) = true)

def env50625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784806,5392,10507601,8456378,10491276,4256861,256,8410416,8434836,10564187]

theorem envBound50625 : H12AffineFastState.Bounded env50625 := by
  intro p hp
  have h : env50625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50527_50625 : H12AffineEnvironment.transform 23 2199965 env50527 = env50625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env50527 == env50625) = true)

def env50626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,8388608,98781,8328,65,12683622,5392,8406289,8456378,8390092,4256861,256,8410416,8434836,8462875]

theorem envBound50626 : H12AffineFastState.Bounded env50626 := by
  intro p hp
  have h : env50626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50625_50626 : H12AffineEnvironment.transform 20 4160 env50625 = env50626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50625 == env50626) = true)

def env50627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374560,98781,8328,65,215366,5392,4359473,4442266,4376044,4256861,256,4363536,4355252,4448827]

theorem envBound50627 : H12AffineFastState.Bounded env50627 := by
  intro p hp
  have h : env50627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50626_50627 : H12AffineEnvironment.transform 22 4374560 env50626 = env50627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env50626 == env50627) = true)

theorem identity50627 : scanCanonicalize (H12AffineFastState.compose env50627 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound50627 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,201967,120015,98781,8328,65,215366,5392,102878,56437,119043,254130,256,98815,90203,63188]

theorem envBound50628 : H12AffineFastState.Bounded env50628 := by
  intro p hp
  have h : env50628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50627_50628 : H12AffineEnvironment.transform 21 201967 env50627 = env50628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env50627 == env50628) = true)

def env50629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130174,1024,32769,4160,73771,120015,98781,8328,65,97666,5392,102878,56437,119043,119926,256,98815,90203,63188]

theorem envBound50629 : H12AffineFastState.Bounded env50629 := by
  intro p hp
  have h : env50629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50628_50629 : H12AffineEnvironment.transform 16 13508 env50628 = env50629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env50628 == env50629) = true)

theorem identity50629 : scanCanonicalize (H12AffineFastState.compose env50629 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50629 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env50630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4160,73771,119878,98644,8193,65,97547,5392,102743,56437,119043,119926,256,98678,90203,63069]

theorem envBound50630 : H12AffineFastState.Bounded env50630 := by
  intro p hp
  have h : env50630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50629_50630 : H12AffineEnvironment.transform 6 9 env50629 = env50630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50629 == env50630) = true)

theorem identity50630 : scanCanonicalize (H12AffineFastState.compose env50630 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound50630 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,10281,1024,32769,4160,62588,17,21763,8193,65,43356,5392,17664,56437,1364,33,256,21793,46092,63069]

theorem envBound50631 : H12AffineFastState.Bounded env50631 := by
  intro p hp
  have h : env50631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50630_50631 : H12AffineEnvironment.transform 15 54359 env50630 = env50631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env50630 == env50631) = true)

theorem identity50631 : scanCanonicalize (H12AffineFastState.compose env50631 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50631 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13389,10281,1024,29789,4160,32,17,21763,8193,65,23808,5392,17664,10281,1364,33,256,21793,16464,513]

theorem envBound50632 : H12AffineFastState.Bounded env50632 := by
  intro p hp
  have h : env50632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50631_50632 : H12AffineEnvironment.transform 14 29788 env50631 = env50632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50631 == env50632) = true)

theorem identity50632 : scanCanonicalize (H12AffineFastState.compose env50632 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound50632 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env50633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8203,13389,10281,1024,80,4160,32,17,8462,8193,65,10509,5392,12557,10281,1364,33,256,8492,13405,513]

theorem envBound50633 : H12AffineFastState.Bounded env50633 := by
  intro p hp
  have h : env50633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50632_50633 : H12AffineEnvironment.transform 13 13325 env50632 = env50633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env50632 == env50633) = true)

theorem identity50633 : scanCanonicalize (H12AffineFastState.compose env50633 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50633 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env50634 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,8203,13340,10281,1024,1,4113,32,17,8462,8193,16,10509,5392,12557,10281,1285,33,256,8492,13324,513]

theorem envBound50634 : H12AffineFastState.Bounded env50634 := by
  intro p hp
  have h : env50634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50633_50634 : H12AffineEnvironment.transform 5 17 env50633 = env50634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50633 == env50634) = true)

theorem identity50634 : scanCanonicalize (H12AffineFastState.compose env50634 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound50634 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50635 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,8192,8493,0,8203,8508,10281,1024,1,1329,32,17,8462,8193,16,10509,48,9261,10281,1285,33,256,8492,8492,513]

theorem envBound50635 : H12AffineFastState.Bounded env50635 := by
  intro p hp
  have h : env50635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50634_50635 : H12AffineEnvironment.transform 11 1312 env50634 = env50635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env50634 == env50635) = true)

theorem identity50635 : scanCanonicalize (H12AffineFastState.compose env50635 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50635 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50636 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,269,32,0,262,49,2340,1024,1,1329,32,17,3,268,16,2048,48,1312,2340,1285,33,256,33,33,513]

theorem envBound50636 : H12AffineFastState.Bounded env50636 := by
  intro p hp
  have h : env50636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50635_50636 : H12AffineEnvironment.transform 12 269 env50635 = env50636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50635 == env50636) = true)

theorem identity50636 : scanCanonicalize (H12AffineFastState.compose env50636 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound50636 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50637 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,17,269,32,0,262,49,2340,305,1,0,32,17,3,268,16,2048,48,17,2340,52,33,256,33,33,513]

theorem envBound50637 : H12AffineFastState.Bounded env50637 := by
  intro p hp
  have h : env50637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50636_50637 : H12AffineEnvironment.transform 9 305 env50636 = env50637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env50636 == env50637) = true)

theorem identity50637 : scanCanonicalize (H12AffineFastState.compose env50637 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound50637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50638 : List Nat := [2,4,8,16,32,17,9,256,512,305,555,17,269,32,0,262,49,783,305,1,0,32,17,3,268,16,555,48,17,783,52,33,256,33,33,513]

theorem envBound50638 : H12AffineFastState.Bounded env50638 := by
  intro p hp
  have h : env50638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50637_50638 : H12AffineEnvironment.transform 10 555 env50637 = env50638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env50637 == env50638) = true)

theorem identity50638 : scanCanonicalize (H12AffineFastState.compose env50638 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound50638 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50639 : List Nat := [2,4,8,16,32,17,9,256,43,305,0,17,269,32,0,262,49,292,305,1,0,32,17,3,268,16,0,48,17,292,52,33,256,33,33,42]

theorem envBound50639 : H12AffineFastState.Bounded env50639 := by
  intro p hp
  have h : env50639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50638_50639 : H12AffineEnvironment.transform 8 43 env50638 = env50639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env50638 == env50639) = true)

theorem identity50639 : scanCanonicalize (H12AffineFastState.compose env50639 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50639 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50640 : List Nat := [2,4,8,16,32,17,9,36,43,21,0,17,41,32,0,34,49,0,21,1,0,32,17,3,40,16,0,48,17,0,52,33,36,33,33,42]

theorem envBound50640 : H12AffineFastState.Bounded env50640 := by
  intro p hp
  have h : env50640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50639_50640 : H12AffineEnvironment.transform 7 36 env50639 = env50640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50639 == env50640) = true)

theorem identity50640 : scanCanonicalize (H12AffineFastState.compose env50640 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound50640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50641 : List Nat := [2,4,8,15,32,14,9,36,43,10,0,14,41,32,0,34,46,0,10,1,0,32,14,3,40,15,0,47,14,0,43,33,36,33,33,42]

theorem envBound50641 : H12AffineFastState.Bounded env50641 := by
  intro p hp
  have h : env50641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50640_50641 : H12AffineEnvironment.transform 3 15 env50640 = env50641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env50640 == env50641) = true)

theorem identity50641 : scanCanonicalize (H12AffineFastState.compose env50641 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50642 : List Nat := [1,4,8,12,32,13,9,36,40,9,0,13,41,32,0,33,45,0,9,1,0,32,13,0,40,12,0,44,13,0,40,33,36,33,33,41]

theorem envBound50642 : H12AffineFastState.Bounded env50642 := by
  intro p hp
  have h : env50642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50641_50642 : H12AffineEnvironment.transform 0 1 env50641 = env50642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50641 == env50642) = true)

def env50643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130175,1024,32769,4160,73770,120015,98781,8328,65,97667,5392,102878,56437,119043,119927,256,98815,90203,63188]

theorem envBound50643 : H12AffineFastState.Bounded env50643 := by
  intro p hp
  have h : env50643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50628_50643 : H12AffineEnvironment.transform 16 13509 env50628 = env50643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env50628 == env50643) = true)

theorem identity50643 : scanCanonicalize (H12AffineFastState.compose env50643 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound50643 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env50644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,13509,100387,1024,32769,4160,73770,106643,98781,8328,65,68063,5392,102878,43049,107871,106539,256,98815,70663,33416]

theorem envBound50644 : H12AffineFastState.Bounded env50644 := by
  intro p hp
  have h : env50644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50643_50644 : H12AffineEnvironment.transform 13 13404 env50643 = env50644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env50643 == env50644) = true)

theorem identity50644 : scanCanonicalize (H12AffineFastState.compose env50644 (packedSelected [4,5,7,8,9,10,14,15,17,18,19,23,24,27,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound50644 : packedSelected [4,5,7,8,9,10,14,15,17,18,19,23,24,27,28,35,38] rootPS < 2^1333 := by decide +kernel

def env50645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,262,13509,35109,1024,32769,4160,8492,41365,32987,8328,65,2265,5392,37080,43049,42073,41261,256,33017,5377,33416]

theorem envBound50645 : H12AffineFastState.Bounded env50645 := by
  intro p hp
  have h : env50645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50644_50645 : H12AffineEnvironment.transform 15 262 env50644 = env50645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env50644 == env50645) = true)

theorem identity50645 : scanCanonicalize (H12AffineFastState.compose env50645 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50645 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env50646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,32768,262,5577,35109,1024,32769,4160,32,32921,32987,388,65,2265,5392,37080,35109,34133,32801,256,33017,5377,33416]

theorem envBound50646 : H12AffineFastState.Bounded env50646 := by
  intro p hp
  have h : env50646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50645_50646 : H12AffineEnvironment.transform 12 268 env50645 = env50646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50645 == env50646) = true)

theorem identity50646 : scanCanonicalize (H12AffineFastState.compose env50646 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound50646 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env50647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,136,262,5577,2477,1024,137,4160,32,17,83,388,65,2265,5392,4176,2477,1501,169,256,113,5377,512]

theorem envBound50647 : H12AffineFastState.Bounded env50647 := by
  intro p hp
  have h : env50647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50646_50647 : H12AffineEnvironment.transform 14 136 env50646 = env50647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env50646 == env50647) = true)

theorem identity50647 : scanCanonicalize (H12AffineFastState.compose env50647 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50647 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50648 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,268,5456,136,262,5577,2445,1024,137,4160,0,17,83,388,65,2265,5392,4176,2445,1501,137,256,81,5377,512]

theorem envBound50648 : H12AffineFastState.Bounded env50648 := by
  intro p hp
  have h : env50648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50647_50648 : H12AffineEnvironment.transform 4 0 env50647 = env50648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50647 == env50648) = true)

theorem identity50648 : scanCanonicalize (H12AffineFastState.compose env50648 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound50648 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50649 : List Nat := [2,4,8,16,0,64,128,85,512,1024,2048,4096,89,5125,136,83,5276,2264,1024,137,4160,0,17,83,209,65,2265,5189,4176,2264,1160,137,85,81,5204,512]

theorem envBound50649 : H12AffineFastState.Bounded env50649 := by
  intro p hp
  have h : env50649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50648_50649 : H12AffineEnvironment.transform 7 85 env50648 = env50649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env50648 == env50649) = true)

theorem identity50649 : scanCanonicalize (H12AffineFastState.compose env50649 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound50649 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env50650 : List Nat := [2,4,8,16,0,64,128,85,512,20,2048,4096,89,4113,136,83,4232,2264,20,137,4160,0,17,83,209,65,2265,4177,4176,2264,156,137,85,81,4160,512]

theorem envBound50650 : H12AffineFastState.Bounded env50650 := by
  intro p hp
  have h : env50650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50649_50650 : H12AffineEnvironment.transform 9 20 env50649 = env50650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env50649 == env50650) = true)

theorem identity50650 : scanCanonicalize (H12AffineFastState.compose env50650 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound50650 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env50651 : List Nat := [2,4,8,16,0,64,128,85,512,20,2048,2113,89,2128,136,83,2249,2264,20,137,2049,0,17,83,209,65,2265,2064,2065,2264,156,137,85,81,2049,512]

theorem envBound50651 : H12AffineFastState.Bounded env50651 := by
  intro p hp
  have h : env50651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50650_50651 : H12AffineEnvironment.transform 11 2113 env50650 = env50651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env50650 == env50651) = true)

theorem identity50651 : scanCanonicalize (H12AffineFastState.compose env50651 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50651 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env50652 : List Nat := [2,4,8,16,0,64,89,85,512,20,2048,2113,89,2128,81,83,2064,2049,20,80,2049,0,17,83,8,65,2048,2064,2065,2049,69,80,85,81,2049,512]

theorem envBound50652 : H12AffineFastState.Bounded env50652 := by
  intro p hp
  have h : env50652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50651_50652 : H12AffineEnvironment.transform 6 89 env50651 = env50652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50651 == env50652) = true)

theorem identity50652 : scanCanonicalize (H12AffineFastState.compose env50652 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50652 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50653 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,1,3,2064,2049,20,0,2049,0,17,3,8,17,2048,2064,2065,2049,21,0,5,1,2049,512]

theorem envBound50653 : H12AffineFastState.Bounded env50653 := by
  intro p hp
  have h : env50653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50652_50653 : H12AffineEnvironment.transform 5 16 env50652 = env50653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50652 == env50653) = true)

def env50654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374561,98781,8328,65,215367,5392,4359472,4442267,4376045,4256861,256,4363537,4355253,4448826]

theorem envBound50654 : H12AffineFastState.Bounded env50654 := by
  intro p hp
  have h : env50654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50626_50654 : H12AffineEnvironment.transform 22 4374561 env50626 = env50654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env50626 == env50654) = true)

theorem identity50654 : scanCanonicalize (H12AffineFastState.compose env50654 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound50654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4160,4194304,4374561,21762,8328,65,171416,5392,4359472,4332612,4376045,4256861,256,4363537,4355253,4339429]

theorem envBound50655 : H12AffineFastState.Bounded env50655 := by
  intro p hp
  have h : env50655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50654_50655 : H12AffineEnvironment.transform 15 54495 env50654 = env50655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env50654 == env50655) = true)

def env50656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4160,180408,153,21762,8328,65,171416,5392,17800,56572,1365,144613,256,21929,46093,63069]

theorem envBound50656 : H12AffineFastState.Bounded env50656 := by
  intro p hp
  have h : env50656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50655_50656 : H12AffineEnvironment.transform 21 180408 env50655 = env50656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env50655 == env50656) = true)

theorem identity50656 : scanCanonicalize (H12AffineFastState.compose env50656 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50656 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env50657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,54495,131072,138341,1024,32769,4160,180408,153,21762,389,65,171416,5392,17800,56572,1365,136680,256,21929,38144,55120]

theorem envBound50657 : H12AffineFastState.Bounded env50657 := by
  intro p hp
  have h : env50657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50656_50657 : H12AffineEnvironment.transform 12 269 env50656 = env50657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50656 == env50657) = true)

theorem identity50657 : scanCanonicalize (H12AffineFastState.compose env50657 (packedSelected [0,1,4,7,10,11,22,26,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50657 : packedSelected [0,1,4,7,10,11,22,26,28,32] rootPS < 2^1333 := by decide +kernel

def env50658 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,54278,131072,138341,1024,32769,4160,180321,64,21762,348,65,171329,5392,17745,56357,1365,136497,256,21872,38144,55120]

theorem envBound50658 : H12AffineFastState.Bounded env50658 := by
  intro p hp
  have h : env50658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50657_50658 : H12AffineEnvironment.transform 6 89 env50657 = env50658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50657 == env50658) = true)

theorem identity50658 : scanCanonicalize (H12AffineFastState.compose env50658 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound50658 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env50659 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,54278,49168,56437,1024,32769,4160,113,64,21762,348,65,23889,5392,17745,56357,1365,54561,256,21872,38144,55120]

theorem envBound50659 : H12AffineFastState.Bounded env50659 := by
  intro p hp
  have h : env50659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50658_50659 : H12AffineEnvironment.transform 16 49168 env50658 = env50659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env50658 == env50659) = true)

theorem identity50659 : scanCanonicalize (H12AffineFastState.compose env50659 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound50659 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50660 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21761,263,5393,2420,1024,21760,4160,113,64,21762,348,65,23889,5392,17745,2340,1365,32,256,21872,16385,593]

theorem envBound50660 : H12AffineFastState.Bounded env50660 := by
  intro p hp
  have h : env50660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50659_50660 : H12AffineEnvironment.transform 14 21761 env50659 = env50660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env50659 == env50660) = true)

theorem identity50660 : scanCanonicalize (H12AffineFastState.compose env50660 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50660 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50661 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,263,5393,2340,1024,21760,4112,33,16,21762,268,17,23809,5392,17665,2340,1285,32,256,21792,16385,513]

theorem envBound50661 : H12AffineFastState.Bounded env50661 := by
  intro p hp
  have h : env50661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50660_50661 : H12AffineEnvironment.transform 5 16 env50660 = env50661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50660 == env50661) = true)

theorem identity50661 : scanCanonicalize (H12AffineFastState.compose env50661 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50661 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env50662 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4112,33,16,3,268,17,2048,5392,4096,2340,1285,32,256,33,5376,513]

theorem envBound50662 : H12AffineFastState.Bounded env50662 := by
  intro p hp
  have h : env50662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50661_50662 : H12AffineEnvironment.transform 13 5377 env50661 = env50662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50661 == env50662) = true)

theorem identity50662 : scanCanonicalize (H12AffineFastState.compose env50662 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50663 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4112,33,16,3,40,17,2048,5172,4096,2048,1057,32,36,33,5156,513]

theorem envBound50663 : H12AffineFastState.Bounded env50663 := by
  intro p hp
  have h : env50663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50662_50663 : H12AffineEnvironment.transform 7 36 env50662 = env50663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50662 == env50663) = true)

theorem identity50663 : scanCanonicalize (H12AffineFastState.compose env50663 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound50663 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1