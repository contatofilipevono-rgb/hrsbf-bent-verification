import H12CloudChart1Data172

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound43858 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env43859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,217,262,5440,2476,1024,216,4161,169,153,138,389,65,2185,5528,4232,2477,1501,168,256,33,5457,513]

theorem envBound43859 : H12AffineFastState.Bounded env43859 := by
  intro p hp
  have h : env43859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43858_43859 : H12AffineEnvironment.transform 12 269 env43858 = env43859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43858 == env43859) = true)

theorem identity43859 : scanCanonicalize (H12AffineFastState.compose env43859 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43859 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,262,5440,2341,1024,81,4161,32,16,3,268,65,2048,5393,4097,2340,1364,33,256,33,5457,513]

theorem envBound43860 : H12AffineFastState.Bounded env43860 := by
  intro p hp
  have h : env43860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43859_43860 : H12AffineEnvironment.transform 6 9 env43859 = env43860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43859 == env43860) = true)

theorem identity43860 : scanCanonicalize (H12AffineFastState.compose env43860 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound43860 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43861 : List Nat := [2,4,8,16,32,64,9,256,512,769,2048,4096,269,4609,80,262,4673,2341,769,81,4161,32,16,3,268,65,2048,4624,4097,2340,597,33,256,33,4688,513]

theorem envBound43861 : H12AffineFastState.Bounded env43861 := by
  intro p hp
  have h : env43861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43860_43861 : H12AffineEnvironment.transform 9 769 env43860 = env43861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env43860 == env43861) = true)

theorem identity43861 : scanCanonicalize (H12AffineFastState.compose env43861 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43861 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43862 : List Nat := [2,4,8,16,32,49,9,256,512,769,2048,4096,269,4609,33,262,4656,2341,769,32,4144,32,16,3,268,48,2048,4624,4097,2340,548,33,256,33,4641,513]

theorem envBound43862 : H12AffineFastState.Bounded env43862 := by
  intro p hp
  have h : env43862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43861_43862 : H12AffineEnvironment.transform 5 49 env43861 = env43862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43861 == env43862) = true)

theorem identity43862 : scanCanonicalize (H12AffineFastState.compose env43862 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound43862 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43863 : List Nat := [2,4,8,16,32,49,9,256,512,769,48,4096,269,4609,33,262,4656,277,769,32,4144,32,16,3,268,48,48,4624,4097,276,548,33,256,33,4641,513]

theorem envBound43863 : H12AffineFastState.Bounded env43863 := by
  intro p hp
  have h : env43863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43862_43863 : H12AffineEnvironment.transform 10 48 env43862 = env43863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env43862 == env43863) = true)

theorem identity43863 : scanCanonicalize (H12AffineFastState.compose env43863 (packedSelected [0,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43863 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env43864 : List Nat := [2,4,8,16,32,49,9,256,17,272,48,4096,269,4112,33,262,4129,277,272,32,4144,32,16,3,268,48,48,4097,4097,276,53,33,256,33,4144,16]

theorem envBound43864 : H12AffineFastState.Bounded env43864 := by
  intro p hp
  have h : env43864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43863_43864 : H12AffineEnvironment.transform 8 17 env43863 = env43864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43863 == env43864) = true)

theorem identity43864 : scanCanonicalize (H12AffineFastState.compose env43864 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43864 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43865 : List Nat := [2,4,8,16,17,0,9,256,17,272,1,4096,269,4112,16,262,4112,277,272,17,4097,17,16,3,268,1,1,4097,4097,276,4,16,256,16,4097,16]

theorem envBound43865 : H12AffineFastState.Bounded env43865 := by
  intro p hp
  have h : env43865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43864_43865 : H12AffineEnvironment.transform 4 17 env43864 = env43865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43864 == env43865) = true)

theorem identity43865 : scanCanonicalize (H12AffineFastState.compose env43865 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound43865 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env43866 : List Nat := [2,4,8,16,17,0,9,256,17,272,1,17,269,1,16,262,1,277,272,17,16,17,16,3,268,1,1,16,16,276,4,16,256,16,16,16]

theorem envBound43866 : H12AffineFastState.Bounded env43866 := by
  intro p hp
  have h : env43866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43865_43866 : H12AffineEnvironment.transform 11 17 env43865 = env43866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env43865 == env43866) = true)

theorem identity43866 : scanCanonicalize (H12AffineFastState.compose env43866 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43867 : List Nat := [2,4,8,16,17,0,9,5,17,21,1,17,8,1,16,3,1,16,21,17,16,17,16,3,9,1,1,16,16,17,4,16,5,16,16,16]

theorem envBound43867 : H12AffineFastState.Bounded env43867 := by
  intro p hp
  have h : env43867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43866_43867 : H12AffineEnvironment.transform 7 5 env43866 = env43867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43866 == env43867) = true)

theorem identity43867 : scanCanonicalize (H12AffineFastState.compose env43867 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43867 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43868 : List Nat := [2,4,8,1,0,0,9,5,0,4,1,0,8,1,1,3,1,1,4,0,1,0,1,3,9,1,1,1,1,0,4,1,5,1,1,1]

theorem envBound43868 : H12AffineFastState.Bounded env43868 := by
  intro p hp
  have h : env43868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43867_43868 : H12AffineEnvironment.transform 3 1 env43867 = env43868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43867 == env43868) = true)

theorem identity43868 : scanCanonicalize (H12AffineFastState.compose env43868 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43868 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43869 : List Nat := [2,0,8,1,0,0,9,1,0,0,1,0,8,1,1,3,1,1,0,0,1,0,1,3,9,1,1,1,1,0,0,1,1,1,1,1]

theorem envBound43869 : H12AffineFastState.Bounded env43869 := by
  intro p hp
  have h : env43869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43868_43869 : H12AffineEnvironment.transform 1 0 env43868 = env43869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43868 == env43869) = true)

theorem identity43869 : scanCanonicalize (H12AffineFastState.compose env43869 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43870 : List Nat := [0,0,8,1,0,0,9,1,0,0,1,0,8,1,1,1,1,1,0,0,1,0,1,1,9,1,1,1,1,0,0,1,1,1,1,1]

theorem envBound43870 : H12AffineFastState.Bounded env43870 := by
  intro p hp
  have h : env43870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43869_43870 : H12AffineEnvironment.transform 0 0 env43869 = env43870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43869 == env43870) = true)

theorem identity43870 : scanCanonicalize (H12AffineFastState.compose env43870 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound43870 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43871 : List Nat := [0,0,0,1,0,0,1,1,0,0,1,0,0,1,1,1,1,1,0,0,1,0,1,1,1,1,1,1,1,0,0,1,1,1,1,1]

theorem envBound43871 : H12AffineFastState.Bounded env43871 := by
  intro p hp
  have h : env43871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43870_43871 : H12AffineEnvironment.transform 2 0 env43870 = env43871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env43870 == env43871) = true)

def env43872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1024,32769,4161,54641,264500,285735,8328,65,316668,269365,281637,35188,1501,272393,256,21793,46213,63189]

theorem envBound43872 : H12AffineFastState.Bounded env43872 := by
  intro p hp
  have h : env43872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43854_43872 : H12AffineEnvironment.transform 16 16449 env43854 = env43872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env43854 == env43872) = true)

theorem identity43872 : scanCanonicalize (H12AffineFastState.compose env43872 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound43872 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,56572,1024,32769,4161,54641,54728,32987,8328,65,2048,49353,37081,35188,1501,62709,256,21793,46213,63189]

theorem envBound43873 : H12AffineFastState.Bounded env43873 := by
  intro p hp
  have h : env43873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43872_43873 : H12AffineEnvironment.transform 17 56572 env43872 = env43873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env43872 == env43873) = true)

theorem identity43873 : scanCanonicalize (H12AffineFastState.compose env43873 (packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound43873 : packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS < 2^1333 := by decide +kernel

def env43874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13689,32768,41382,13624,43397,1024,32769,4161,40968,41137,32987,8328,65,2048,46512,37081,35188,1501,33164,256,8280,46213,33708]

theorem envBound43874 : H12AffineFastState.Bounded env43874 := by
  intro p hp
  have h : env43874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43873_43874 : H12AffineEnvironment.transform 13 13689 env43873 = env43874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env43873 == env43874) = true)

theorem identity43874 : scanCanonicalize (H12AffineFastState.compose env43874 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound43874 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env43875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5377,32768,33246,5440,35325,1024,32769,4161,32880,32969,32987,240,65,2048,38344,37081,35188,1501,33164,256,32,38141,33708]

theorem envBound43875 : H12AffineFastState.Bounded env43875 := by
  intro p hp
  have h : env43875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43874_43875 : H12AffineEnvironment.transform 12 120 env43874 = env43875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env43874 == env43875) = true)

theorem identity43875 : scanCanonicalize (H12AffineFastState.compose env43875 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43875 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env43876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5377,1,479,5440,2556,1024,0,4161,113,200,218,240,65,2048,5577,4312,2421,1501,397,256,32,5372,941]

theorem envBound43876 : H12AffineFastState.Bounded env43876 := by
  intro p hp
  have h : env43876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43875_43876 : H12AffineEnvironment.transform 14 1 env43875 = env43876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43875 == env43876) = true)

theorem identity43876 : scanCanonicalize (H12AffineFastState.compose env43876 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound43876 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env43877 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,120,5372,1,34,5309,2049,1024,0,4161,113,200,218,240,65,2048,5172,4312,2184,1056,112,253,32,5372,592]

theorem envBound43877 : H12AffineFastState.Bounded env43877 := by
  intro p hp
  have h : env43877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43876_43877 : H12AffineEnvironment.transform 7 253 env43876 = env43877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env43876 == env43877) = true)

theorem identity43877 : scanCanonicalize (H12AffineFastState.compose env43877 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43877 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43878 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5236,1,34,5173,2049,1024,0,4161,113,64,82,120,65,2048,5172,4176,2048,1056,112,117,32,5236,592]

theorem envBound43878 : H12AffineFastState.Bounded env43878 := by
  intro p hp
  have h : env43878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43877_43878 : H12AffineEnvironment.transform 6 8 env43877 = env43878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43877 == env43878) = true)

def env43879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513204,510137,8328,65,2409660,2509877,396388,2136373,2102684,2373705,256,21793,46213,2175563]

theorem envBound43879 : H12AffineFastState.Bounded env43879 := by
  intro p hp
  have h : env43879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43828_43879 : H12AffineEnvironment.transform 21 169265 env43828 = env43879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env43828 == env43879) = true)

def env43880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,510137,8328,65,316668,416885,396388,35189,1500,272393,256,21793,46213,74251]

theorem envBound43880 : H12AffineFastState.Bounded env43880 := by
  intro p hp
  have h : env43880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43879_43880 : H12AffineEnvironment.transform 20 4160 env43879 = env43880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43879 == env43880) = true)

theorem identity43880 : scanCanonicalize (H12AffineFastState.compose env43880 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43880 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,169265,412020,452787,8328,65,316668,416885,396388,35189,1500,272393,256,21793,46213,513]

theorem envBound43881 : H12AffineFastState.Bounded env43881 := by
  intro p hp
  have h : env43881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43880_43881 : H12AffineEnvironment.transform 15 8202 env43880 = env43881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43880 == env43881) = true)

def env43882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,54561,264548,305315,8328,65,316668,269413,281716,35189,1500,272393,256,21793,46213,513]

theorem envBound43882 : H12AffineFastState.Bounded env43882 := by
  intro p hp
  have h : env43882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43881_43882 : H12AffineEnvironment.transform 16 16400 env43881 = env43882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env43881 == env43882) = true)

theorem identity43882 : scanCanonicalize (H12AffineFastState.compose env43882 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound43882 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,2420,1024,32769,4160,54561,16,41431,8328,65,56712,5393,17664,35189,1500,8573,256,21793,46213,513]

theorem envBound43883 : H12AffineFastState.Bounded env43883 := by
  intro p hp
  have h : env43883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43882_43883 : H12AffineEnvironment.transform 17 2420 env43882 = env43883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env43882 == env43883) = true)

theorem identity43883 : scanCanonicalize (H12AffineFastState.compose env43883 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound43883 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8202,16400,2420,1024,21896,4160,168,16,29790,8328,65,2049,5393,17664,23804,1500,8573,256,21793,24844,513]

theorem envBound43884 : H12AffineFastState.Bounded env43884 := by
  intro p hp
  have h : env43884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43883_43884 : H12AffineEnvironment.transform 14 21897 env43883 = env43884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env43883 == env43884) = true)

theorem identity43884 : scanCanonicalize (H12AffineFastState.compose env43884 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound43884 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env43885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21897,478,16400,2420,1024,21896,4160,168,16,21898,348,65,2049,5393,17664,23804,1500,169,256,21793,16600,513]

theorem envBound43885 : H12AffineFastState.Bounded env43885 := by
  intro p hp
  have h : env43885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43884_43885 : H12AffineEnvironment.transform 12 468 env43884 = env43885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env43884 == env43885) = true)

theorem identity43885 : scanCanonicalize (H12AffineFastState.compose env43885 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound43885 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,0,478,5529,2420,1024,1,4160,168,16,3,348,65,2049,5393,4233,2421,1500,169,256,168,5457,513]

theorem envBound43886 : H12AffineFastState.Bounded env43886 := by
  intro p hp
  have h : env43886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43885_43886 : H12AffineEnvironment.transform 13 5513 env43885 = env43886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env43885 == env43886) = true)

theorem identity43886 : scanCanonicalize (H12AffineFastState.compose env43886 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43886 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env43887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,468,1417,0,478,1433,2420,1024,1,64,168,16,3,348,65,2049,1297,137,2421,1500,169,256,168,1361,513]

theorem envBound43887 : H12AffineFastState.Bounded env43887 := by
  intro p hp
  have h : env43887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43886_43887 : H12AffineEnvironment.transform 11 0 env43886 = env43887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43886 == env43887) = true)

theorem identity43887 : scanCanonicalize (H12AffineFastState.compose env43887 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound43887 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env43888 : List Nat := [2,4,8,16,32,11,128,256,512,1024,2048,0,415,1417,0,405,1433,2367,1024,1,11,168,16,3,279,10,2049,1297,137,2366,1431,169,256,168,1306,513]

theorem envBound43888 : H12AffineFastState.Bounded env43888 := by
  intro p hp
  have h : env43888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43887_43888 : H12AffineEnvironment.transform 5 11 env43887 = env43888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env43887 == env43888) = true)

theorem identity43888 : scanCanonicalize (H12AffineFastState.compose env43888 (packedSelected [4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43888 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env43889 : List Nat := [2,4,8,16,32,11,128,256,512,272,2048,0,415,153,0,405,137,2367,272,1,11,168,16,3,279,10,2049,1,137,2366,135,169,256,168,10,513]

theorem envBound43889 : H12AffineFastState.Bounded env43889 := by
  intro p hp
  have h : env43889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43888_43889 : H12AffineEnvironment.transform 9 272 env43888 = env43889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43888 == env43889) = true)

def env43890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4160,54560,264549,305314,8328,65,316668,269412,281717,35189,1500,272393,256,21793,46213,513]

theorem envBound43890 : H12AffineFastState.Bounded env43890 := by
  intro p hp
  have h : env43890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43881_43890 : H12AffineEnvironment.transform 16 16401 env43881 = env43890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43881 == env43890) = true)

def env43891 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4112,54560,264501,305314,8328,17,316588,269364,281637,35109,1420,272393,256,21793,46213,513]

theorem envBound43891 : H12AffineFastState.Bounded env43891 := by
  intro p hp
  have h : env43891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43890_43891 : H12AffineEnvironment.transform 5 16 env43890 = env43891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43890 == env43891) = true)

theorem identity43891 : scanCanonicalize (H12AffineFastState.compose env43891 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound43891 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env43892 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32161,1024,32769,4112,54560,29844,54531,8328,17,43277,24981,12676,35109,1420,21928,256,21793,46213,513]

theorem envBound43892 : H12AffineFastState.Bounded env43892 := by
  intro p hp
  have h : env43892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43891_43892 : H12AffineEnvironment.transform 17 32161 env43891 = env43892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env43891 == env43892) = true)

theorem identity43892 : scanCanonicalize (H12AffineFastState.compose env43892 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43892 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43893 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32041,1024,32769,4112,54560,29724,54531,8192,17,43277,24861,12556,35109,1284,21792,256,21793,46093,513]

theorem envBound43893 : H12AffineFastState.Bounded env43893 := by
  intro p hp
  have h : env43893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43892_43893 : H12AffineEnvironment.transform 6 8 env43892 = env43893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43892 == env43893) = true)

theorem identity43893 : scanCanonicalize (H12AffineFastState.compose env43893 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43893 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env43894 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,263,16401,23588,1024,32769,4112,54560,21777,54531,269,17,34816,16400,4097,35109,1284,21792,256,21793,38144,513]

theorem envBound43894 : H12AffineFastState.Bounded env43894 := by
  intro p hp
  have h : env43894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43893_43894 : H12AffineEnvironment.transform 12 269 env43893 = env43894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43893 == env43894) = true)

def env43895 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4113,54560,264500,305314,8328,16,316589,269365,281636,35108,1421,272393,256,21793,46213,513]

theorem envBound43895 : H12AffineFastState.Bounded env43895 := by
  intro p hp
  have h : env43895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43890_43895 : H12AffineEnvironment.transform 5 17 env43890 = env43895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43890 == env43895) = true)

theorem identity43895 : scanCanonicalize (H12AffineFastState.compose env43895 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound43895 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env43896 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1024,32769,4113,54560,8476,32906,8328,16,64645,13341,25612,35108,1421,33,256,21793,46213,513]

theorem envBound43896 : H12AffineFastState.Bounded env43896 := by
  intro p hp
  have h : env43896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43895_43896 : H12AffineEnvironment.transform 17 10280 env43895 = env43896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43895 == env43896) = true)

theorem identity43896 : scanCanonicalize (H12AffineFastState.compose env43896 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 12465) := by decide +kernel

theorem selectedBound43896 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43897 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,12465,32768,8202,12448,10280,1024,32769,4113,42385,8476,32906,8328,16,35892,13341,5309,35108,1421,33,256,9616,46213,513]

theorem envBound43897 : H12AffineFastState.Bounded env43897 := by
  intro p hp
  have h : env43897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43896_43897 : H12AffineEnvironment.transform 13 12465 env43896 = env43897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12465 env43896 == env43897) = true)

theorem identity43897 : scanCanonicalize (H12AffineFastState.compose env43897 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound43897 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env43898 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1053,5292,32768,1047,5309,3125,1024,32769,4113,33164,1281,32906,1173,16,35892,4096,5309,35108,1421,33,256,397,37016,513]

theorem envBound43898 : H12AffineFastState.Bounded env43898 := by
  intro p hp
  have h : env43898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43897_43898 : H12AffineEnvironment.transform 12 1053 env43897 = env43898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env43897 == env43898) = true)

theorem identity43898 : scanCanonicalize (H12AffineFastState.compose env43898 (packedSelected [0,1,4,5,7,8,9,11,12,14,15,17,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43898 : packedSelected [0,1,4,5,7,8,9,11,12,14,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env43899 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1053,5292,32768,1047,5309,3125,1024,32769,4113,32936,1061,32906,1173,16,35892,4096,5309,34816,1193,33,36,169,37016,513]

theorem envBound43899 : H12AffineFastState.Bounded env43899 := by
  intro p hp
  have h : env43899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43898_43899 : H12AffineEnvironment.transform 7 36 env43898 = env43899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43898 == env43899) = true)

theorem identity43899 : scanCanonicalize (H12AffineFastState.compose env43899 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43899 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43900 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,1053,5156,32768,1047,5173,3125,1024,32769,4113,32800,1061,32770,1053,16,35892,4096,5173,34816,1057,33,36,33,36880,513]

theorem envBound43900 : H12AffineFastState.Bounded env43900 := by
  intro p hp
  have h : env43900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43899_43900 : H12AffineEnvironment.transform 6 8 env43899 = env43900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43899 == env43900) = true)

theorem identity43900 : scanCanonicalize (H12AffineFastState.compose env43900 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43900 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43901 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1053,3125,32768,1047,3108,3125,1024,32769,2048,32800,1061,32770,1053,16,35892,2065,3108,34816,1057,33,36,33,34817,513]

theorem envBound43901 : H12AffineFastState.Bounded env43901 := by
  intro p hp
  have h : env43901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43900_43901 : H12AffineEnvironment.transform 11 2065 env43900 = env43901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env43900 == env43901) = true)

theorem identity43901 : scanCanonicalize (H12AffineFastState.compose env43901 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound43901 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43902 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,1053,3125,1076,1047,3108,3125,1024,1077,2048,1044,1061,1078,1053,16,2048,2065,3108,3124,1057,33,36,33,3125,513]

theorem envBound43902 : H12AffineFastState.Bounded env43902 := by
  intro p hp
  have h : env43902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43901_43902 : H12AffineEnvironment.transform 14 1076 env43901 = env43902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env43901 == env43902) = true)

theorem identity43902 : scanCanonicalize (H12AffineFastState.compose env43902 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound43902 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43903 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1589,1572,1053,512,1076,1047,529,512,1024,1077,1589,1044,1061,1078,1053,16,1589,1572,529,513,1057,33,36,33,512,513]

theorem envBound43903 : H12AffineFastState.Bounded env43903 := by
  intro p hp
  have h : env43903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43902_43903 : H12AffineEnvironment.transform 10 1589 env43902 = env43903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env43902 == env43903) = true)

theorem identity43903 : scanCanonicalize (H12AffineFastState.compose env43903 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound43903 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43904 : List Nat := [2,4,8,16,32,17,8,36,512,20,545,560,9,512,32,3,529,512,20,33,545,0,49,34,9,16,545,560,529,513,53,33,36,33,512,513]

theorem envBound43904 : H12AffineFastState.Bounded env43904 := by
  intro p hp
  have h : env43904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43903_43904 : H12AffineEnvironment.transform 9 20 env43903 = env43904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43903 == env43904) = true)

theorem identity43904 : scanCanonicalize (H12AffineFastState.compose env43904 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43904 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env43905 : List Nat := [2,4,8,16,1,17,8,5,512,20,512,529,9,512,1,3,529,512,20,0,512,0,16,3,9,16,512,529,529,513,20,0,5,0,512,513]

theorem envBound43905 : H12AffineFastState.Bounded env43905 := by
  intro p hp
  have h : env43905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43904_43905 : H12AffineEnvironment.transform 4 1 env43904 = env43905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43904 == env43905) = true)

theorem identity43905 : scanCanonicalize (H12AffineFastState.compose env43905 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43906 : List Nat := [2,4,8,16,1,17,8,5,1,20,1,16,9,1,1,3,16,1,20,0,1,0,16,3,9,16,1,16,16,0,20,0,5,0,1,0]

theorem envBound43906 : H12AffineFastState.Bounded env43906 := by
  intro p hp
  have h : env43906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43905_43906 : H12AffineEnvironment.transform 8 1 env43905 = env43906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43905 == env43906) = true)

def env43907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,510137,8328,65,316669,416884,396388,35188,1501,272392,256,21793,46213,74250]

theorem envBound43907 : H12AffineFastState.Bounded env43907 := by
  intro p hp
  have h : env43907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43879_43907 : H12AffineEnvironment.transform 20 4161 env43879 = env43907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43879 == env43907) = true)

theorem identity43907 : scanCanonicalize (H12AffineFastState.compose env43907 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound43907 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,4161,169265,120015,21763,8328,65,215367,115150,102878,35188,1501,243122,256,21793,46213,74250]

theorem envBound43908 : H12AffineFastState.Bounded env43908 := by
  intro p hp
  have h : env43908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43907_43908 : H12AffineEnvironment.transform 17 236986 env43907 = env43908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env43907 == env43908) = true)

def env43909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130174,1024,32769,4161,62709,120015,21763,8328,65,75907,115150,102878,35188,1501,119926,256,21793,46213,74250]

theorem envBound43909 : H12AffineFastState.Bounded env43909 := by
  intro p hp
  have h : env43909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43908_43909 : H12AffineEnvironment.transform 16 25028 env43908 = env43909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env43908 == env43909) = true)

theorem identity43909 : scanCanonicalize (H12AffineFastState.compose env43909 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound43909 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env43910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,25028,64928,1024,32769,4161,62709,54545,21763,8328,65,10589,49168,36864,35188,1501,54696,256,21793,46213,9172]

theorem envBound43910 : H12AffineFastState.Bounded env43910 := by
  intro p hp
  have h : env43910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43909_43910 : H12AffineEnvironment.transform 15 478 env43909 = env43910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env43909 == env43910) = true)

theorem identity43910 : scanCanonicalize (H12AffineFastState.compose env43910 (packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound43910 : packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS < 2^1333 := by decide +kernel

def env43911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29828,478,25028,2340,1024,29829,4161,113,8597,21763,8328,65,10589,13460,25732,32240,1501,8492,256,21793,16385,9172]

theorem envBound43911 : H12AffineFastState.Bounded env43911 := by
  intro p hp
  have h : env43911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43910_43911 : H12AffineEnvironment.transform 14 29828 env43910 = env43911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env43910 == env43911) = true)

theorem identity43911 : scanCanonicalize (H12AffineFastState.compose env43911 (packedSelected [0,3,4,7,10,17,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound43911 : packedSelected [0,3,4,7,10,17,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,0,478,5440,2340,1024,1,4161,113,8597,8583,8328,65,10589,13460,4096,2420,1501,8492,256,8613,13445,9172]

theorem envBound43912 : H12AffineFastState.Bounded env43912 := by
  intro p hp
  have h : env43912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43911_43912 : H12AffineEnvironment.transform 13 13444 env43911 = env43912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env43911 == env43912) = true)

theorem identity43912 : scanCanonicalize (H12AffineFastState.compose env43912 (packedSelected [0,3,5,6,7,11,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound43912 : packedSelected [0,3,5,6,7,11,14,16] rootPS < 2^1333 := by decide +kernel

def env43913 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,13357,0,375,5440,2340,1024,1,4161,113,8508,8494,8225,65,10589,13373,4096,2420,1396,8492,256,8460,13356,9085]

theorem envBound43913 : H12AffineFastState.Bounded env43913 := by
  intro p hp
  have h : env43913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43912_43913 : H12AffineEnvironment.transform 6 41 env43912 = env43913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env43912 == env43913) = true)

theorem identity43913 : scanCanonicalize (H12AffineFastState.compose env43913 (packedSelected [0,3,5,6,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43913 : packedSelected [0,3,5,6,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env43914 : List Nat := [2,4,8,16,32,64,41,4,512,1024,2048,4096,8192,13357,0,115,5188,2080,1024,1,4161,113,8248,8234,8225,65,10329,13373,4096,2160,1136,8232,4,8200,13356,8825]

theorem envBound43914 : H12AffineFastState.Bounded env43914 := by
  intro p hp
  have h : env43914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43913_43914 : H12AffineEnvironment.transform 7 4 env43913 = env43914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43913 == env43914) = true)

def env43915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130175,1024,32769,4161,62708,120015,21763,8328,65,75906,115150,102878,35188,1501,119927,256,21793,46213,74250]

theorem envBound43915 : H12AffineFastState.Bounded env43915 := by
  intro p hp
  have h : env43915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43908_43915 : H12AffineEnvironment.transform 16 25029 env43908 = env43915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env43908 == env43915) = true)

theorem identity43915 : scanCanonicalize (H12AffineFastState.compose env43915 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound43915 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env43916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,16401,122283,1024,32769,4161,54560,120015,21763,348,65,67926,115150,102878,35188,1501,119927,256,21793,38225,66526]

theorem envBound43916 : H12AffineFastState.Bounded env43916 := by
  intro p hp
  have h : env43916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43915_43916 : H12AffineEnvironment.transform 12 468 env43915 = env43916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env43915 == env43916) = true)

theorem identity43916 : scanCanonicalize (H12AffineFastState.compose env43916 (packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound43916 : packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS < 2^1333 := by decide +kernel

def env43917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,32768,65536,5529,100387,1024,32769,4161,32936,98631,139,348,65,67926,103494,102878,35188,1501,98815,256,169,38225,66526]

theorem envBound43917 : H12AffineFastState.Bounded env43917 := by
  intro p hp
  have h : env43917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43916_43917 : H12AffineEnvironment.transform 13 5512 env43916 = env43917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env43916 == env43917) = true)

theorem identity43917 : scanCanonicalize (H12AffineFastState.compose env43917 (packedSelected [0,3,4,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound43917 : packedSelected [0,3,4,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env43918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,80,65536,5529,67699,1024,81,4161,248,65815,139,348,65,67926,70678,70030,2340,1501,65967,256,169,5377,66526]

theorem envBound43918 : H12AffineFastState.Bounded env43918 := by
  intro p hp
  have h : env43918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43917_43918 : H12AffineEnvironment.transform 14 80 env43917 = env43918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env43917 == env43918) = true)

theorem identity43918 : scanCanonicalize (H12AffineFastState.compose env43918 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound43918 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,80,114,5529,2049,1024,81,4161,248,357,139,348,65,2340,5220,4604,2340,1501,477,256,169,5377,940]

theorem envBound43919 : H12AffineFastState.Bounded env43919 := by
  intro p hp
  have h : env43919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43918_43919 : H12AffineEnvironment.transform 15 114 env43918 = env43919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env43918 == env43919) = true)

theorem identity43919 : scanCanonicalize (H12AffineFastState.compose env43919 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43919 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,0,34,5529,2049,1024,1,4113,168,309,139,268,17,2340,5172,4524,2340,1421,397,256,169,5377,940]

theorem envBound43920 : H12AffineFastState.Bounded env43920 := by
  intro p hp
  have h : env43920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43919_43920 : H12AffineEnvironment.transform 5 16 env43919 = env43920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43919 == env43920) = true)

theorem identity43920 : scanCanonicalize (H12AffineFastState.compose env43920 (packedSelected [0,1,3,4,5,6,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43920 : packedSelected [0,1,3,4,5,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env43921 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,388,4249,0,34,4232,2049,273,1,4113,168,309,139,268,17,2340,4389,4524,2340,156,397,256,169,4112,940]

theorem envBound43921 : H12AffineFastState.Bounded env43921 := by
  intro p hp
  have h : env43921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43920_43921 : H12AffineEnvironment.transform 9 273 env43920 = env43921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43920 == env43921) = true)

theorem identity43921 : scanCanonicalize (H12AffineFastState.compose env43921 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43921 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43922 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,4113,0,34,4096,2049,273,1,4113,32,309,3,268,17,2340,4389,4388,2340,20,261,256,33,4112,804]

theorem envBound43922 : H12AffineFastState.Bounded env43922 := by
  intro p hp
  have h : env43922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43921_43922 : H12AffineEnvironment.transform 6 8 env43921 = env43922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43921 == env43922) = true)

theorem identity43922 : scanCanonicalize (H12AffineFastState.compose env43922 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2846) := by decide +kernel

theorem selectedBound43922 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43923 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2846,268,2831,0,34,2846,2049,273,1,2831,32,309,3,268,17,2340,2619,2618,2340,20,261,256,33,2830,804]

theorem envBound43923 : H12AffineFastState.Bounded env43923 := by
  intro p hp
  have h : env43923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43922_43923 : H12AffineEnvironment.transform 11 2846 env43922 = env43923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2846 env43922 == env43923) = true)

theorem identity43923 : scanCanonicalize (H12AffineFastState.compose env43923 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43923 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env43924 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,2846,268,2831,0,2,2846,2049,273,1,2831,0,277,3,268,17,2308,2587,2586,2308,20,261,256,1,2830,772]

theorem envBound43924 : H12AffineFastState.Bounded env43924 := by
  intro p hp
  have h : env43924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43923_43924 : H12AffineEnvironment.transform 4 0 env43923 = env43924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43923 == env43924) = true)

theorem identity43924 : scanCanonicalize (H12AffineFastState.compose env43924 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43924 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43925 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2586,8,2571,0,2,2586,2049,21,1,2571,0,17,3,8,17,2048,2587,2586,2048,20,1,4,1,2570,512]

theorem envBound43925 : H12AffineFastState.Bounded env43925 := by
  intro p hp
  have h : env43925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43924_43925 : H12AffineEnvironment.transform 7 4 env43924 = env43925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43924 == env43925) = true)

theorem identity43925 : scanCanonicalize (H12AffineFastState.compose env43925 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound43925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43926 : List Nat := [2,4,8,16,0,16,8,4,512,21,516,30,8,15,0,2,30,517,21,1,15,0,17,3,8,17,516,31,30,516,20,1,4,1,14,512]

theorem envBound43926 : H12AffineFastState.Bounded env43926 := by
  intro p hp
  have h : env43926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43925_43926 : H12AffineEnvironment.transform 10 516 env43925 = env43926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env43925 == env43926) = true)

theorem identity43926 : scanCanonicalize (H12AffineFastState.compose env43926 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43927 : List Nat := [2,4,8,7,0,7,8,4,512,2,516,9,8,15,0,2,9,517,2,1,15,0,6,3,8,6,516,8,9,516,3,1,4,1,14,512]

theorem envBound43927 : H12AffineFastState.Bounded env43927 := by
  intro p hp
  have h : env43927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43926_43927 : H12AffineEnvironment.transform 3 7 env43926 = env43927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43926 == env43927) = true)

theorem identity43927 : scanCanonicalize (H12AffineFastState.compose env43927 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound43927 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43928 : List Nat := [2,4,7,7,0,7,7,4,512,2,516,6,7,0,0,2,6,517,2,1,0,0,6,3,7,6,516,7,6,516,3,1,4,1,1,512]

theorem envBound43928 : H12AffineFastState.Bounded env43928 := by
  intro p hp
  have h : env43928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43927_43928 : H12AffineEnvironment.transform 2 7 env43927 = env43928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env43927 == env43928) = true)

theorem identity43928 : scanCanonicalize (H12AffineFastState.compose env43928 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43928 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43929 : List Nat := [2,4,7,7,0,7,7,4,4,2,0,6,7,0,0,2,6,1,2,1,0,0,6,3,7,6,0,7,6,0,3,1,4,1,1,4]

theorem envBound43929 : H12AffineFastState.Bounded env43929 := by
  intro p hp
  have h : env43929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43928_43929 : H12AffineEnvironment.transform 8 4 env43928 = env43929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43928 == env43929) = true)

def env43930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513205,510137,8328,65,6705548,2509877,396389,2136372,2102685,6729080,256,21792,46212,2175562]

theorem envBound43930 : H12AffineFastState.Bounded env43930 := by
  intro p hp
  have h : env43930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43827_43930 : H12AffineEnvironment.transform 22 2513205 env43827 = env43930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513205 env43827 == env43930) = true)

def env43931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513205,510137,8328,65,2409660,2509877,396389,2136372,2102685,2373704,256,21792,46212,2175562]

theorem envBound43931 : H12AffineFastState.Bounded env43931 := by
  intro p hp
  have h : env43931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43930_43931 : H12AffineEnvironment.transform 21 169264 env43930 = env43931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env43930 == env43931) = true)

def env43932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,510137,8328,65,316668,416885,396389,35188,1501,272392,256,21792,46212,74250]

theorem envBound43932 : H12AffineFastState.Bounded env43932 := by
  intro p hp
  have h : env43932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43931_43932 : H12AffineEnvironment.transform 20 4160 env43931 = env43932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43931 == env43932) = true)

theorem identity43932 : scanCanonicalize (H12AffineFastState.compose env43932 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound43932 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,169264,62661,95497,8328,65,158028,57797,45525,35188,1501,169400,256,21792,46212,74250]

theorem envBound43933 : H12AffineFastState.Bounded env43933 := by
  intro p hp
  have h : env43933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43932_43933 : H12AffineEnvironment.transform 17 179632 env43932 = env43933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env43932 == env43933) = true)

theorem identity43933 : scanCanonicalize (H12AffineFastState.compose env43933 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43933 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179632,1024,32769,4160,169264,62661,21762,8328,65,158028,57797,45525,35188,1501,169400,256,21792,46212,513]

theorem envBound43934 : H12AffineFastState.Bounded env43934 := by
  intro p hp
  have h : env43934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43933_43934 : H12AffineEnvironment.transform 15 8203 env43933 = env43934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43933 == env43934) = true)

theorem identity43934 : scanCanonicalize (H12AffineFastState.compose env43934 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound43934 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env43935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64929,1024,32769,4160,54561,62661,21762,8328,65,10589,57797,45525,35188,1501,54697,256,21792,46212,513]

theorem envBound43935 : H12AffineFastState.Bounded env43935 := by
  intro p hp
  have h : env43935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43934_43935 : H12AffineEnvironment.transform 16 16401 env43934 = env43935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43934 == env43935) = true)

theorem identity43935 : scanCanonicalize (H12AffineFastState.compose env43935 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound43935 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16401,2420,1024,29908,4160,8692,16,21762,8328,65,10589,5392,17664,32161,1501,8572,256,21792,16465,513]

theorem envBound43936 : H12AffineFastState.Bounded env43936 := by
  intro p hp
  have h : env43936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43935_43936 : H12AffineEnvironment.transform 14 29909 env43935 = env43936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env43935 == env43936) = true)

theorem identity43936 : scanCanonicalize (H12AffineFastState.compose env43936 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43936 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,16401,2420,1024,21897,4160,169,16,21762,469,65,2048,5392,17664,23804,1501,33,256,21792,16465,513]

theorem envBound43937 : H12AffineFastState.Bounded env43937 := by
  intro p hp
  have h : env43937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43936_43937 : H12AffineEnvironment.transform 12 349 env43936 = env43937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43936 == env43937) = true)

theorem identity43937 : scanCanonicalize (H12AffineFastState.compose env43937 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43937 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,16401,2420,1024,21761,4160,33,16,21762,349,65,2048,5392,17664,23668,1365,33,256,21792,16465,513]

theorem envBound43938 : H12AffineFastState.Bounded env43938 := by
  intro p hp
  have h : env43938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43937_43938 : H12AffineEnvironment.transform 6 8 env43937 = env43938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43937 == env43938) = true)

theorem identity43938 : scanCanonicalize (H12AffineFastState.compose env43938 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43938 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43939 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21760,263,16401,2341,1024,21761,4113,33,16,21762,268,16,2048,5392,17664,23589,1284,33,256,21792,16384,513]

theorem envBound43939 : H12AffineFastState.Bounded env43939 := by
  intro p hp
  have h : env43939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43938_43939 : H12AffineEnvironment.transform 5 17 env43938 = env43939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43938 == env43939) = true)

theorem identity43939 : scanCanonicalize (H12AffineFastState.compose env43939 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound43939 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43940 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,268,16384,18725,263,16401,2341,1024,18724,3124,33,16,18727,268,16,2048,2357,17664,16384,1284,33,256,18693,16384,513]

theorem envBound43940 : H12AffineFastState.Bounded env43940 := by
  intro p hp
  have h : env43940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43939_43940 : H12AffineEnvironment.transform 11 3109 env43939 = env43940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env43939 == env43940) = true)

theorem identity43940 : scanCanonicalize (H12AffineFastState.compose env43940 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound43940 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env43941 : List Nat := [2,4,8,16,32,17,8,256,512,543,2048,2618,268,16384,18725,263,16401,2341,543,18724,2603,33,16,18727,268,16,2048,2357,17183,16384,795,33,256,18693,16384,513]

theorem envBound43941 : H12AffineFastState.Bounded env43941 := by
  intro p hp
  have h : env43941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43940_43941 : H12AffineEnvironment.transform 9 543 env43940 = env43941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env43940 == env43941) = true)

theorem identity43941 : scanCanonicalize (H12AffineFastState.compose env43941 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound43941 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env43942 : List Nat := [2,4,8,16,32,17,8,256,512,543,261,831,268,16384,16416,263,16401,32,543,16417,814,33,16,16418,268,16,261,48,17183,16384,795,33,256,16384,16384,513]

theorem envBound43942 : H12AffineFastState.Bounded env43942 := by
  intro p hp
  have h : env43942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43941_43942 : H12AffineEnvironment.transform 10 261 env43941 = env43942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env43941 == env43942) = true)

theorem identity43942 : scanCanonicalize (H12AffineFastState.compose env43942 (packedSelected [0,2,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43942 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env43943 : List Nat := [2,4,8,16,32,17,8,36,512,543,33,539,40,16384,16416,35,16401,32,543,16417,522,33,16,16418,40,16,33,48,16955,16384,575,33,36,16384,16384,513]

theorem envBound43943 : H12AffineFastState.Bounded env43943 := by
  intro p hp
  have h : env43943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43942_43943 : H12AffineEnvironment.transform 7 36 env43942 = env43943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43942 == env43943) = true)

theorem identity43943 : scanCanonicalize (H12AffineFastState.compose env43943 (packedSelected [0,1,2] rootPS)) = affineNative (2^(13+1) ^^^ 572) := by decide +kernel

theorem selectedBound43943 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43944 : List Nat := [2,4,8,16,32,17,8,36,512,543,33,539,40,572,540,35,557,32,543,541,522,33,16,542,40,16,33,48,7,572,575,33,36,572,572,513]

theorem envBound43944 : H12AffineFastState.Bounded env43944 := by
  intro p hp
  have h : env43944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43943_43944 : H12AffineEnvironment.transform 13 572 env43943 = env43944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 572 env43943 == env43944) = true)

def env43945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,510137,8328,65,316669,416884,396389,35189,1500,272393,256,21792,46212,74251]

theorem envBound43945 : H12AffineFastState.Bounded env43945 := by
  intro p hp
  have h : env43945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43931_43945 : H12AffineEnvironment.transform 20 4161 env43931 = env43945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43931 == env43945) = true)

def env43946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169264,155996,254097,8328,65,64725,160860,140365,35189,1500,33,256,21792,46212,74251]

theorem envBound43946 : H12AffineFastState.Bounded env43946 := by
  intro p hp
  have h : env43946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43945_43946 : H12AffineEnvironment.transform 17 10280 env43945 = env43946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43945 == env43946) = true)

def env43947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21792,41292,73857,8328,65,64725,46156,58461,35189,1500,33,256,21792,46212,74251]

theorem envBound43947 : H12AffineFastState.Bounded env43947 := by
  intro p hp
  have h : env43947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43946_43947 : H12AffineEnvironment.transform 16 49168 env43946 = env43947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43946 == env43947) = true)

theorem identity43947 : scanCanonicalize (H12AffineFastState.compose env43947 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound43947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1024,8660,4161,21792,153,73857,8328,65,23808,5529,17800,10400,1500,33,256,21792,5457,74251]

theorem envBound43948 : H12AffineFastState.Bounded env43948 := by
  intro p hp
  have h : env43948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43947_43948 : H12AffineEnvironment.transform 14 8661 env43947 = env43948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env43947 == env43948) = true)

theorem identity43948 : scanCanonicalize (H12AffineFastState.compose env43948 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound43948 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1432,65536,17800,3173,1024,1433,4161,21792,153,66764,1221,65,23808,5529,17800,3309,1500,33,256,21792,5457,67142]

theorem envBound43949 : H12AffineFastState.Bounded env43949 := by
  intro p hp
  have h : env43949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43948_43949 : H12AffineEnvironment.transform 12 1101 env43948 = env43949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env43948 == env43949) = true)

theorem identity43949 : scanCanonicalize (H12AffineFastState.compose env43949 (packedSelected [0,1,2,3,5,6,7,8,10,16,26] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound43949 : packedSelected [0,1,2,3,5,6,7,8,10,16,26] rootPS < 2^1333 := by decide +kernel

def env43950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1432,1046,17800,3173,1024,1433,4161,21792,153,218,1221,65,23808,5529,17800,3309,1500,33,256,21792,5457,592]

theorem envBound43950 : H12AffineFastState.Bounded env43950 := by
  intro p hp
  have h : env43950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43949_43950 : H12AffineEnvironment.transform 15 1046 env43949 = env43950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env43949 == env43950) = true)

theorem identity43950 : scanCanonicalize (H12AffineFastState.compose env43950 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound43950 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env43951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5236,1432,1046,4604,3173,1024,1433,4161,340,153,218,1221,65,2420,5529,4604,3309,1500,33,256,340,5457,592]

theorem envBound43951 : H12AffineFastState.Bounded env43951 := by
  intro p hp
  have h : env43951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43950_43951 : H12AffineEnvironment.transform 13 5236 env43950 = env43951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env43950 == env43951) = true)

theorem identity43951 : scanCanonicalize (H12AffineFastState.compose env43951 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43951 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env43952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5236,1296,1046,4468,3173,1024,1297,4161,340,17,82,1101,65,2420,5393,4468,3173,1364,33,256,340,5457,592]

theorem envBound43952 : H12AffineFastState.Bounded env43952 := by
  intro p hp
  have h : env43952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43951_43952 : H12AffineEnvironment.transform 6 8 env43951 = env43952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43951 == env43952) = true)

theorem identity43952 : scanCanonicalize (H12AffineFastState.compose env43952 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43952 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43953 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4453,1,263,4468,2420,273,0,4161,340,17,82,348,65,2420,4096,4468,2420,69,33,256,340,4160,592]

theorem envBound43953 : H12AffineFastState.Bounded env43953 := by
  intro p hp
  have h : env43953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43952_43953 : H12AffineEnvironment.transform 9 273 env43952 = env43953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43952 == env43953) = true)

theorem identity43953 : scanCanonicalize (H12AffineFastState.compose env43953 (packedSelected [0,4,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound43953 : packedSelected [0,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43954 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2096,348,2389,1,263,2372,2420,273,0,2161,340,17,82,348,65,2420,2096,2372,2420,69,33,256,340,2160,592]

theorem envBound43954 : H12AffineFastState.Bounded env43954 := by
  intro p hp
  have h : env43954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43953_43954 : H12AffineEnvironment.transform 11 2096 env43953 = env43954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env43953 == env43954) = true)

theorem identity43954 : scanCanonicalize (H12AffineFastState.compose env43954 (packedSelected [7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43954 : packedSelected [7,10,12] rootPS < 2^1333 := by decide +kernel

def env43955 : List Nat := [2,4,8,16,32,64,8,4,512,21,2048,2096,88,2129,1,3,2112,2160,21,0,2161,80,17,82,88,65,2160,2096,2112,2160,69,33,4,80,2160,592]

theorem envBound43955 : H12AffineFastState.Bounded env43955 := by
  intro p hp
  have h : env43955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43954_43955 : H12AffineEnvironment.transform 7 4 env43954 = env43955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43954 == env43955) = true)

theorem identity43955 : scanCanonicalize (H12AffineFastState.compose env43955 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43955 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43956 : List Nat := [2,4,8,16,32,16,8,4,512,21,2048,2096,8,2049,1,3,2064,2080,21,0,2081,0,17,2,8,17,2080,2096,2064,2080,21,33,4,0,2080,512]

theorem envBound43956 : H12AffineFastState.Bounded env43956 := by
  intro p hp
  have h : env43956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43955_43956 : H12AffineEnvironment.transform 5 16 env43955 = env43956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43955 == env43956) = true)

theorem identity43956 : scanCanonicalize (H12AffineFastState.compose env43956 (packedSelected [0,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43956 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env43957 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2064,8,2049,1,3,2064,2048,21,0,2049,0,17,2,8,17,2048,2064,2064,2048,21,1,4,0,2048,512]

theorem envBound43957 : H12AffineFastState.Bounded env43957 := by
  intro p hp
  have h : env43957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43956_43957 : H12AffineEnvironment.transform 4 0 env43956 = env43957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43956 == env43957) = true)

def env43958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21793,41293,73856,8328,65,64725,46157,58460,35189,1500,33,256,21792,46212,74251]

theorem envBound43958 : H12AffineFastState.Bounded env43958 := by
  intro p hp
  have h : env43958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43946_43958 : H12AffineEnvironment.transform 16 49169 env43946 = env43958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43946 == env43958) = true)

theorem identity43958 : scanCanonicalize (H12AffineFastState.compose env43958 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43958 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1024,8541,4161,21793,17,73856,8328,65,23945,5393,17664,10281,1500,33,256,21792,5592,74251]

theorem envBound43959 : H12AffineFastState.Bounded env43959 := by
  intro p hp
  have h : env43959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43958_43959 : H12AffineEnvironment.transform 14 8540 env43958 = env43959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43958 == env43959) = true)

theorem identity43959 : scanCanonicalize (H12AffineFastState.compose env43959 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound43959 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env43960 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,16384,8540,65536,24909,10280,189,8541,4161,20892,17,73856,8328,65,22836,4524,16829,10281,353,33,256,20893,4453,74251]

theorem envBound43960 : H12AffineFastState.Bounded env43960 := by
  intro p hp
  have h : env43960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43959_43960 : H12AffineEnvironment.transform 9 189 env43959 = env43960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env43959 == env43960) = true)

theorem identity43960 : scanCanonicalize (H12AffineFastState.compose env43960 (packedSelected [2,4,6,11,16,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound43960 : packedSelected [2,4,6,11,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env43961 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,16384,8540,114,24909,10280,189,8541,4161,20892,17,8434,8328,65,22836,4524,16829,10281,353,33,256,20893,4453,8825]

theorem envBound43961 : H12AffineFastState.Bounded env43961 := by
  intro p hp
  have h : env43961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43960_43961 : H12AffineEnvironment.transform 15 114 env43960 = env43961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env43960 == env43961) = true)

theorem identity43961 : scanCanonicalize (H12AffineFastState.compose env43961 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound43961 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env43962 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,8192,4161,8540,114,12556,10280,189,8541,4161,477,17,8434,8328,65,2421,4524,4604,10281,353,33,256,476,4453,8825]

theorem envBound43962 : H12AffineFastState.Bounded env43962 := by
  intro p hp
  have h : env43962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43961_43962 : H12AffineEnvironment.transform 13 4161 env43961 = env43962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env43961 == env43962) = true)

theorem identity43962 : scanCanonicalize (H12AffineFastState.compose env43962 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43962 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env43963 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,348,4161,0,114,4176,2420,189,1,4161,477,17,430,468,65,2421,4524,4604,2421,353,33,256,476,4453,805]

theorem envBound43963 : H12AffineFastState.Bounded env43963 := by
  intro p hp
  have h : env43963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43962_43963 : H12AffineEnvironment.transform 12 348 env43962 = env43963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43962 == env43963) = true)

theorem identity43963 : scanCanonicalize (H12AffineFastState.compose env43963 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43963 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43964 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,240,4161,0,114,4176,2264,189,1,4161,113,17,2,120,65,2265,4096,4176,2265,205,33,172,112,4297,649]

theorem envBound43964 : H12AffineFastState.Bounded env43964 := by
  intro p hp
  have h : env43964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43963_43964 : H12AffineEnvironment.transform 7 172 env43963 = env43964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43963 == env43964) = true)

theorem identity43964 : scanCanonicalize (H12AffineFastState.compose env43964 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound43964 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43965 : List Nat := [2,4,8,16,32,64,128,172,512,189,80,4096,240,4161,0,114,4176,136,189,1,4161,113,17,2,120,65,137,4096,4176,137,205,33,172,112,4297,649]

theorem envBound43965 : H12AffineFastState.Bounded env43965 := by
  intro p hp
  have h : env43965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43964_43965 : H12AffineEnvironment.transform 10 80 env43964 = env43965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env43964 == env43965) = true)

theorem identity43965 : scanCanonicalize (H12AffineFastState.compose env43965 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound43965 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43966 : List Nat := [2,4,8,16,32,64,128,172,512,189,80,64,240,1,0,114,16,136,189,1,1,113,17,2,120,65,137,64,16,137,205,33,172,112,137,649]

theorem envBound43966 : H12AffineFastState.Bounded env43966 := by
  intro p hp
  have h : env43966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43965_43966 : H12AffineEnvironment.transform 11 64 env43965 = env43966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env43965 == env43966) = true)

theorem identity43966 : scanCanonicalize (H12AffineFastState.compose env43966 (packedSelected [1,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound43966 : packedSelected [1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env43967 : List Nat := [2,4,8,16,32,64,88,116,512,101,80,64,40,1,0,114,16,80,101,1,1,113,17,2,120,65,81,64,16,81,21,33,116,112,81,593]

theorem envBound43967 : H12AffineFastState.Bounded env43967 := by
  intro p hp
  have h : env43967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43966_43967 : H12AffineEnvironment.transform 6 88 env43966 = env43967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env43966 == env43967) = true)

theorem identity43967 : scanCanonicalize (H12AffineFastState.compose env43967 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound43967 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env43968 : List Nat := [2,4,8,16,32,0,24,52,512,37,16,0,40,1,0,50,16,16,37,1,1,49,17,2,56,1,17,0,16,17,21,33,52,48,17,529]

theorem envBound43968 : H12AffineFastState.Bounded env43968 := by
  intro p hp
  have h : env43968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43967_43968 : H12AffineEnvironment.transform 5 0 env43967 = env43968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43967 == env43968) = true)

theorem identity43968 : scanCanonicalize (H12AffineFastState.compose env43968 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43968 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43969 : List Nat := [2,4,8,1,32,0,9,37,512,37,1,0,40,1,0,35,1,1,37,1,1,32,0,2,41,1,0,0,1,0,4,33,37,33,0,512]

theorem envBound43969 : H12AffineFastState.Bounded env43969 := by
  intro p hp
  have h : env43969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43968_43969 : H12AffineEnvironment.transform 3 1 env43968 = env43969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43968 == env43969) = true)

theorem identity43969 : scanCanonicalize (H12AffineFastState.compose env43969 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43970 : List Nat := [2,4,8,1,1,0,9,4,512,4,1,0,9,1,0,2,1,1,4,1,1,1,0,2,8,1,0,0,1,0,4,0,4,0,0,512]

theorem envBound43970 : H12AffineFastState.Bounded env43970 := by
  intro p hp
  have h : env43970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43969_43970 : H12AffineEnvironment.transform 4 1 env43969 = env43970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43969 == env43970) = true)

theorem identity43970 : scanCanonicalize (H12AffineFastState.compose env43970 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound43970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43971 : List Nat := [2,4,8,1,1,0,9,4,5,4,1,0,9,1,0,2,1,1,4,1,1,1,0,2,8,1,0,0,1,0,4,0,4,0,0,5]

theorem envBound43971 : H12AffineFastState.Bounded env43971 := by
  intro p hp
  have h : env43971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43970_43971 : H12AffineEnvironment.transform 8 5 env43970 = env43971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env43970 == env43971) = true)

theorem identity43971 : scanCanonicalize (H12AffineFastState.compose env43971 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43971 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43972 : List Nat := [2,1,8,1,1,0,9,1,0,1,1,0,9,1,0,2,1,1,1,1,1,1,0,2,8,1,0,0,1,0,1,0,1,0,0,0]

theorem envBound43972 : H12AffineFastState.Bounded env43972 := by
  intro p hp
  have h : env43972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43971_43972 : H12AffineEnvironment.transform 1 1 env43971 = env43972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43971 == env43972) = true)

def env43973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169264,155997,254096,8328,65,64724,160861,140364,35189,1500,32,256,21792,46212,74251]

theorem envBound43973 : H12AffineFastState.Bounded env43973 := by
  intro p hp
  have h : env43973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43945_43973 : H12AffineEnvironment.transform 17 10281 env43945 = env43973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43945 == env43973) = true)

def env43974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21792,41293,73856,8328,65,64724,46157,58460,35189,1500,32,256,21792,46212,74251]

theorem envBound43974 : H12AffineFastState.Bounded env43974 := by
  intro p hp
  have h : env43974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43973_43974 : H12AffineEnvironment.transform 16 49168 env43973 = env43974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43973 == env43974) = true)

theorem identity43974 : scanCanonicalize (H12AffineFastState.compose env43974 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound43974 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1024,32769,4161,21792,41293,2,8328,65,64724,46157,58460,35189,1500,32,256,21792,46212,649]

theorem envBound43975 : H12AffineFastState.Bounded env43975 := by
  intro p hp
  have h : env43975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43974_43975 : H12AffineEnvironment.transform 15 8322 env43974 = env43975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env43974 == env43975) = true)

theorem identity43975 : scanCanonicalize (H12AffineFastState.compose env43975 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound43975 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env43976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8322,46157,10281,1024,32769,4161,8573,41293,2,8328,65,34953,46157,36865,35189,1500,32,256,8573,46212,649]

theorem envBound43976 : H12AffineFastState.Bounded env43976 := by
  intro p hp
  have h : env43976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43975_43976 : H12AffineEnvironment.transform 13 13405 env43975 = env43976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env43975 == env43976) = true)

theorem identity43976 : scanCanonicalize (H12AffineFastState.compose env43976 (packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43976 : packedSelected [0,2,6,7,10,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env43977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,32768,398,38209,2341,1024,32769,4161,113,32833,2,388,65,34953,38209,36865,35189,1500,32,256,113,38280,649]

theorem envBound43977 : H12AffineFastState.Bounded env43977 := by
  intro p hp
  have h : env43977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43976_43977 : H12AffineEnvironment.transform 12 268 env43976 = env43977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43976 == env43977) = true)

theorem identity43977 : scanCanonicalize (H12AffineFastState.compose env43977 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound43977 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env43978 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,32768,343,38209,2341,1024,32769,4161,113,32833,2,349,65,34896,38209,36865,35189,1285,32,256,113,38225,592]

theorem envBound43978 : H12AffineFastState.Bounded env43978 := by
  intro p hp
  have h : env43978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43977_43978 : H12AffineEnvironment.transform 6 89 env43977 = env43978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env43977 == env43978) = true)

theorem identity43978 : scanCanonicalize (H12AffineFastState.compose env43978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound43978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43979 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,81,343,5392,2341,1024,80,4161,113,16,2,349,65,2049,5392,4176,2340,1285,32,256,113,5376,592]

theorem envBound43979 : H12AffineFastState.Bounded env43979 := by
  intro p hp
  have h : env43979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43978_43979 : H12AffineEnvironment.transform 14 81 env43978 = env43979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env43978 == env43979) = true)

theorem identity43979 : scanCanonicalize (H12AffineFastState.compose env43979 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43979 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43980 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,0,268,1361,81,343,1296,2341,1024,80,65,113,16,2,349,65,2049,1296,80,2340,1285,32,256,113,1280,592]

theorem envBound43980 : H12AffineFastState.Bounded env43980 := by
  intro p hp
  have h : env43980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43979_43980 : H12AffineEnvironment.transform 11 0 env43979 = env43980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43979 == env43980) = true)

def env43981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21793,41292,73857,8328,65,64724,46156,58461,35189,1500,32,256,21792,46212,74251]

theorem envBound43981 : H12AffineFastState.Bounded env43981 := by
  intro p hp
  have h : env43981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43973_43981 : H12AffineEnvironment.transform 16 49169 env43973 = env43981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43973 == env43981) = true)

theorem identity43981 : scanCanonicalize (H12AffineFastState.compose env43981 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21793,41292,73737,8192,65,64604,46156,58461,35189,1364,32,256,21792,46092,74251]

theorem envBound43982 : H12AffineFastState.Bounded env43982 := by
  intro p hp
  have h : env43982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43981_43982 : H12AffineEnvironment.transform 6 8 env43981 = env43982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43981 == env43982) = true)

theorem identity43982 : scanCanonicalize (H12AffineFastState.compose env43982 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43982 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10281,1024,8540,4161,21793,17,73737,8192,65,23809,5393,17664,10280,1364,32,256,21792,5457,74251]

theorem envBound43983 : H12AffineFastState.Bounded env43983 := by
  intro p hp
  have h : env43983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43982_43983 : H12AffineEnvironment.transform 14 8541 env43982 = env43983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43982 == env43983) = true)

theorem identity43983 : scanCanonicalize (H12AffineFastState.compose env43983 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound43983 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24908,10281,1024,8540,4161,21793,17,8543,8192,65,23809,5393,17664,10280,1364,32,256,21792,5457,9053]

theorem envBound43984 : H12AffineFastState.Bounded env43984 := by
  intro p hp
  have h : env43984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43983_43984 : H12AffineEnvironment.transform 15 342 env43983 = env43984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env43983 == env43984) = true)

theorem identity43984 : scanCanonicalize (H12AffineFastState.compose env43984 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound43984 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,342,5393,10281,1024,8540,4161,8572,17,8543,8192,65,10588,5393,12637,10280,1364,32,256,8573,5457,9053]

theorem envBound43985 : H12AffineFastState.Bounded env43985 := by
  intro p hp
  have h : env43985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43984_43985 : H12AffineEnvironment.transform 13 13405 env43984 = env43985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env43984 == env43985) = true)

theorem identity43985 : scanCanonicalize (H12AffineFastState.compose env43985 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43985 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5393,2421,1024,0,4161,32,17,3,348,65,2048,5393,4097,2420,1364,32,256,33,5457,513]

theorem envBound43986 : H12AffineFastState.Bounded env43986 := by
  intro p hp
  have h : env43986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43985_43986 : H12AffineEnvironment.transform 12 348 env43985 = env43986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43985 == env43986) = true)

theorem identity43986 : scanCanonicalize (H12AffineFastState.compose env43986 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2926) := by decide +kernel

theorem selectedBound43986 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2926,348,3695,1,342,3711,2421,1024,0,2863,32,17,3,348,65,2048,3711,2927,2420,1364,32,256,33,3647,513]

theorem envBound43987 : H12AffineFastState.Bounded env43987 := by
  intro p hp
  have h : env43987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43986_43987 : H12AffineEnvironment.transform 11 2926 env43986 = env43987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2926 env43986 == env43987) = true)

theorem identity43987 : scanCanonicalize (H12AffineFastState.compose env43987 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43988 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2879,269,3646,1,263,3630,2340,1024,0,2863,32,17,3,269,16,2048,3630,2878,2341,1285,32,256,33,3647,513]

theorem envBound43988 : H12AffineFastState.Bounded env43988 := by
  intro p hp
  have h : env43988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43987_43988 : H12AffineEnvironment.transform 5 17 env43987 = env43988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43987 == env43988) = true)

theorem identity43988 : scanCanonicalize (H12AffineFastState.compose env43988 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound43988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43989 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1818,1061,269,292,1,263,308,1598,1024,0,1077,32,17,3,269,16,1818,308,1060,1599,1285,32,256,33,293,513]

theorem envBound43989 : H12AffineFastState.Bounded env43989 := by
  intro p hp
  have h : env43989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43988_43989 : H12AffineEnvironment.transform 10 1818 env43988 = env43989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env43988 == env43989) = true)

theorem identity43989 : scanCanonicalize (H12AffineFastState.compose env43989 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound43989 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43990 : List Nat := [2,4,8,16,32,17,8,256,512,543,261,570,269,292,1,263,308,33,543,0,554,32,17,3,269,16,261,308,571,32,794,32,256,33,293,513]

theorem envBound43990 : H12AffineFastState.Bounded env43990 := by
  intro p hp
  have h : env43990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43989_43990 : H12AffineEnvironment.transform 9 543 env43989 = env43990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env43989 == env43990) = true)

theorem identity43990 : scanCanonicalize (H12AffineFastState.compose env43990 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound43990 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43991 : List Nat := [2,4,8,16,32,17,8,256,271,272,261,309,269,292,1,263,308,33,272,0,293,32,17,3,269,16,261,308,308,32,21,32,256,33,293,270]

theorem envBound43991 : H12AffineFastState.Bounded env43991 := by
  intro p hp
  have h : env43991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43990_43991 : H12AffineEnvironment.transform 8 271 env43990 = env43991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env43990 == env43991) = true)

theorem identity43991 : scanCanonicalize (H12AffineFastState.compose env43991 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43991 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43992 : List Nat := [2,4,8,16,1,17,8,256,271,272,261,276,269,261,1,263,277,0,272,0,260,1,17,3,269,16,261,277,277,1,21,1,256,0,260,270]

theorem envBound43992 : H12AffineFastState.Bounded env43992 := by
  intro p hp
  have h : env43992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43991_43992 : H12AffineEnvironment.transform 4 1 env43991 = env43992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43991 == env43992) = true)

theorem identity43992 : scanCanonicalize (H12AffineFastState.compose env43992 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43992 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43993 : List Nat := [2,4,8,16,1,17,8,4,11,20,1,16,9,1,1,3,17,0,20,0,0,1,17,3,9,16,1,17,17,1,21,1,4,0,0,10]

theorem envBound43993 : H12AffineFastState.Bounded env43993 := by
  intro p hp
  have h : env43993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43992_43993 : H12AffineEnvironment.transform 7 4 env43992 = env43993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43992 == env43993) = true)

theorem identity43993 : scanCanonicalize (H12AffineFastState.compose env43993 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound43993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43994 : List Nat := [2,4,6,16,1,17,6,4,5,20,1,16,7,1,1,3,17,0,20,0,0,1,17,3,7,16,1,17,17,1,21,1,4,0,0,4]

theorem envBound43994 : H12AffineFastState.Bounded env43994 := by
  intro p hp
  have h : env43994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43993_43994 : H12AffineEnvironment.transform 2 6 env43993 = env43994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env43993 == env43994) = true)

theorem identity43994 : scanCanonicalize (H12AffineFastState.compose env43994 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound43994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43995 : List Nat := [2,4,6,2,1,3,6,4,5,6,1,2,7,1,1,3,3,0,6,0,0,1,3,3,7,2,1,3,3,1,7,1,4,0,0,4]

theorem envBound43995 : H12AffineFastState.Bounded env43995 := by
  intro p hp
  have h : env43995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43994_43995 : H12AffineEnvironment.transform 3 2 env43994 = env43995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env43994 == env43995) = true)

def env43996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513205,510137,8328,65,2409661,2509877,396389,2136372,2102685,2373705,256,21792,46212,2175562]

theorem envBound43996 : H12AffineFastState.Bounded env43996 := by
  intro p hp
  have h : env43996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43930_43996 : H12AffineEnvironment.transform 21 169265 env43930 = env43996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env43930 == env43996) = true)

def env43997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,510137,8328,65,316669,416885,396389,35188,1501,272393,256,21792,46212,74250]

theorem envBound43997 : H12AffineFastState.Bounded env43997 := by
  intro p hp
  have h : env43997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43996_43997 : H12AffineEnvironment.transform 20 4160 env43996 = env43997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43996 == env43997) = true)

theorem identity43997 : scanCanonicalize (H12AffineFastState.compose env43997 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound43997 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,156132,412021,474220,8328,65,270376,416885,396389,32161,1501,272393,256,21792,16465,74250]

theorem envBound43998 : H12AffineFastState.Bounded env43998 := by
  intro p hp
  have h : env43998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43997_43998 : H12AffineEnvironment.transform 14 29909 env43997 = env43998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env43997 == env43998) = true)

def env43999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4112,156084,411941,474172,8328,17,270376,416805,396341,32161,1421,272393,256,21792,16385,74250]

theorem envBound43999 : H12AffineFastState.Bounded env43999 := by
  intro p hp
  have h : env43999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43998_43999 : H12AffineEnvironment.transform 5 16 env43998 = env43999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43998 == env43999) = true)

theorem identity43999 : scanCanonicalize (H12AffineFastState.compose env43999 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215226) := by decide +kernel

theorem selectedBound43999 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,215226,1024,29828,4112,156084,65951,29830,8328,17,223378,70815,83087,32161,1421,221363,256,21792,16385,74250]

theorem envBound44000 : H12AffineFastState.Bounded env44000 := by
  intro p hp
  have h : env44000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43999_44000 : H12AffineEnvironment.transform 17 215226 env43999 = env44000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215226 env43999 == env44000) = true)

theorem identity44000 : scanCanonicalize (H12AffineFastState.compose env44000 (packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound44000 : packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env44001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,32160,1024,29828,4112,87214,65951,29830,8328,17,23944,70815,83087,32161,1421,21929,256,21792,16385,74250]

theorem envBound44001 : H12AffineFastState.Bounded env44001 := by
  intro p hp
  have h : env44001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44000_44001 : H12AffineEnvironment.transform 16 79130 env44000 = env44001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env44000 == env44001) = true)

theorem identity44001 : scanCanonicalize (H12AffineFastState.compose env44001 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound44001 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env44002 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,30082,16536,32160,1024,29828,4112,8492,29725,29830,8328,17,23944,24861,12557,32161,1421,21929,256,21792,16385,22408]

theorem envBound44002 : H12AffineFastState.Bounded env44002 := by
  intro p hp
  have h : env44002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44001_44002 : H12AffineEnvironment.transform 15 30082 env44001 = env44002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env44001 == env44002) = true)

theorem identity44002 : scanCanonicalize (H12AffineFastState.compose env44002 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound44002 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env44003 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,398,13460,2476,1024,136,4112,8492,17,138,8328,17,10628,5393,12557,2477,1421,8613,256,8492,13325,9092]

theorem envBound44003 : H12AffineFastState.Bounded env44003 := by
  intro p hp
  have h : env44003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44002_44003 : H12AffineEnvironment.transform 13 13324 env44002 = env44003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env44002 == env44003) = true)

def env44004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4113,156085,411940,474173,8328,16,270376,416804,396340,32161,1420,272393,256,21792,16384,74250]

theorem envBound44004 : H12AffineFastState.Bounded env44004 := by
  intro p hp
  have h : env44004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43998_44004 : H12AffineEnvironment.transform 5 17 env43998 = env44004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43998 == env44004) = true)

theorem identity44004 : scanCanonicalize (H12AffineFastState.compose env44004 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound44004 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,215091,1024,29829,4113,156085,65815,29710,8328,16,223259,70679,82951,32161,1420,221242,256,21792,16384,74250]

theorem envBound44005 : H12AffineFastState.Bounded env44005 := by
  intro p hp
  have h : env44005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44004_44005 : H12AffineEnvironment.transform 17 215091 env44004 = env44005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env44004 == env44005) = true)

theorem identity44005 : scanCanonicalize (H12AffineFastState.compose env44005 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound44005 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,29963,131072,146744,1024,29829,4113,156085,29724,29710,8328,16,138512,24860,12556,32161,1420,136497,256,21792,16384,22273]

theorem envBound44006 : H12AffineFastState.Bounded env44006 := by
  intro p hp
  have h : env44006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44005_44006 : H12AffineEnvironment.transform 15 29963 env44005 = env44006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env44005 == env44006) = true)

theorem identity44006 : scanCanonicalize (H12AffineFastState.compose env44006 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound44006 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env44007 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,29963,24981,23725,1024,29829,4113,32,29724,29710,8328,16,31877,24860,12556,32161,1420,29860,256,21792,16384,22273]

theorem envBound44007 : H12AffineFastState.Bounded env44007 := by
  intro p hp
  have h : env44007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44006_44007 : H12AffineEnvironment.transform 16 24981 env44006 = env44007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env44006 == env44007) = true)

theorem identity44007 : scanCanonicalize (H12AffineFastState.compose env44007 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44007 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env44008 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,8203,13461,2477,1024,8581,4113,32,8476,8462,8328,16,10629,13340,12556,10401,1420,8612,256,32,5376,513]

theorem envBound44008 : H12AffineFastState.Bounded env44008 := by
  intro p hp
  have h : env44008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44007_44008 : H12AffineEnvironment.transform 13 5376 env44007 = env44008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44007 == env44008) = true)

theorem identity44008 : scanCanonicalize (H12AffineFastState.compose env44008 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44009 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,13341,2341,1024,8461,4113,32,8476,8462,8192,16,10509,13340,12556,10281,1284,8492,256,32,5376,513]

theorem envBound44009 : H12AffineFastState.Bounded env44009 := by
  intro p hp
  have h : env44009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44008_44009 : H12AffineEnvironment.transform 6 8 env44008 = env44009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44008 == env44009) = true)

theorem identity44009 : scanCanonicalize (H12AffineFastState.compose env44009 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound44009 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44010 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,4381,5376,4113,4374,1280,2341,1024,4112,4113,32,4097,4115,4381,16,6160,1281,17,6452,1284,4145,256,32,5376,513]

theorem envBound44010 : H12AffineFastState.Bounded env44010 := by
  intro p hp
  have h : env44010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44009_44010 : H12AffineEnvironment.transform 12 4381 env44009 = env44010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env44009 == env44010) = true)

theorem identity44010 : scanCanonicalize (H12AffineFastState.compose env44010 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44010 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44011 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,4381,4404,4113,4374,308,2341,52,4112,4113,32,4097,4115,4381,16,6160,309,17,6452,304,4145,256,32,4404,513]

theorem envBound44011 : H12AffineFastState.Bounded env44011 := by
  intro p hp
  have h : env44011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44010_44011 : H12AffineEnvironment.transform 9 52 env44010 = env44011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44010 == env44011) = true)

theorem identity44011 : scanCanonicalize (H12AffineFastState.compose env44011 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44011 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44012 : List Nat := [2,4,8,16,32,17,8,256,512,52,1,4096,4381,4404,4113,4374,308,292,52,4112,4113,32,4097,4115,4381,16,4113,309,17,4405,304,4145,256,32,4404,513]

theorem envBound44012 : H12AffineFastState.Bounded env44012 := by
  intro p hp
  have h : env44012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44011_44012 : H12AffineEnvironment.transform 10 1 env44011 = env44012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44011 == env44012) = true)

theorem identity44012 : scanCanonicalize (H12AffineFastState.compose env44012 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound44012 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44013 : List Nat := [2,4,8,16,32,17,8,256,512,52,1,17,268,293,0,263,308,292,52,1,0,32,16,2,268,16,0,309,17,292,304,32,256,32,293,513]

theorem envBound44013 : H12AffineFastState.Bounded env44013 := by
  intro p hp
  have h : env44013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44012_44013 : H12AffineEnvironment.transform 11 17 env44012 = env44013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env44012 == env44013) = true)

theorem identity44013 : scanCanonicalize (H12AffineFastState.compose env44013 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44014 : List Nat := [2,4,8,16,32,17,8,4,512,52,1,17,8,33,0,3,48,32,52,1,0,32,16,2,8,16,0,49,17,32,52,32,4,32,33,513]

theorem envBound44014 : H12AffineFastState.Bounded env44014 := by
  intro p hp
  have h : env44014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44013_44014 : H12AffineEnvironment.transform 7 4 env44013 = env44014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44013 == env44014) = true)

theorem identity44014 : scanCanonicalize (H12AffineFastState.compose env44014 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44014 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44015 : List Nat := [2,4,8,16,32,17,8,4,42,52,1,17,8,33,0,3,48,32,52,1,0,32,16,2,8,16,0,49,17,32,52,32,4,32,33,43]

theorem envBound44015 : H12AffineFastState.Bounded env44015 := by
  intro p hp
  have h : env44015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44014_44015 : H12AffineEnvironment.transform 8 42 env44014 = env44015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44014 == env44015) = true)

theorem identity44015 : scanCanonicalize (H12AffineFastState.compose env44015 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44015 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44016 : List Nat := [2,4,3,16,32,17,3,4,33,52,1,17,3,33,0,3,48,32,52,1,0,32,16,2,3,16,0,49,17,32,52,32,4,32,33,32]

theorem envBound44016 : H12AffineFastState.Bounded env44016 := by
  intro p hp
  have h : env44016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44015_44016 : H12AffineEnvironment.transform 2 3 env44015 = env44016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44015 == env44016) = true)

theorem identity44016 : scanCanonicalize (H12AffineFastState.compose env44016 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44017 : List Nat := [2,0,3,16,32,17,3,0,33,48,1,17,3,33,0,3,48,32,48,1,0,32,16,2,3,16,0,49,17,32,48,32,0,32,33,32]

theorem envBound44017 : H12AffineFastState.Bounded env44017 := by
  intro p hp
  have h : env44017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44016_44017 : H12AffineEnvironment.transform 1 0 env44016 = env44017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44016 == env44017) = true)

theorem identity44017 : scanCanonicalize (H12AffineFastState.compose env44017 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44017 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44018 : List Nat := [2,0,3,16,16,17,3,0,17,0,1,17,3,17,0,3,0,16,0,1,0,16,16,2,3,16,0,1,17,16,0,16,0,16,17,16]

theorem envBound44018 : H12AffineFastState.Bounded env44018 := by
  intro p hp
  have h : env44018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44017_44018 : H12AffineEnvironment.transform 4 16 env44017 = env44018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44017 == env44018) = true)

theorem identity44018 : scanCanonicalize (H12AffineFastState.compose env44018 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound44018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44019 : List Nat := [2,0,3,2,2,3,3,0,3,0,1,3,3,3,0,3,0,2,0,1,0,2,2,2,3,2,0,1,3,2,0,2,0,2,3,2]

theorem envBound44019 : H12AffineFastState.Bounded env44019 := by
  intro p hp
  have h : env44019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44018_44019 : H12AffineEnvironment.transform 3 2 env44018 = env44019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env44018 == env44019) = true)

def env44020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,510137,8328,65,316668,416884,396389,35189,1500,272392,256,21792,46212,74251]

theorem envBound44020 : H12AffineFastState.Bounded env44020 := by
  intro p hp
  have h : env44020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43996_44020 : H12AffineEnvironment.transform 20 4161 env43996 = env44020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43996 == env44020) = true)

theorem identity44020 : scanCanonicalize (H12AffineFastState.compose env44020 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound44020 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,98781,8328,65,171416,5392,17665,35189,1500,156012,256,21792,46212,74251]

theorem envBound44021 : H12AffineFastState.Bounded env44021 := by
  intro p hp
  have h : env44021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44020_44021 : H12AffineEnvironment.transform 17 149860 env44020 = env44021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env44020 == env44021) = true)

def env44022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,98645,8192,65,171280,5392,17665,35189,1364,156012,256,21792,46092,74251]

theorem envBound44022 : H12AffineFastState.Bounded env44022 := by
  intro p hp
  have h : env44022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44021_44022 : H12AffineEnvironment.transform 6 8 env44021 = env44022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44021 == env44022) = true)

theorem identity44022 : scanCanonicalize (H12AffineFastState.compose env44022 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound44022 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1024,32769,4161,62588,16,98645,8192,65,64605,5392,17665,35189,1364,33,256,21792,46092,74251]

theorem envBound44023 : H12AffineFastState.Bounded env44023 := by
  intro p hp
  have h : env44023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44022_44023 : H12AffineEnvironment.transform 16 24909 env44022 = env44023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env44022 == env44023) = true)

theorem identity44023 : scanCanonicalize (H12AffineFastState.compose env44023 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound44023 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,10281,1024,32769,4161,62588,16,29790,8192,65,64605,5392,17665,35189,1364,33,256,21792,46092,55040]

theorem envBound44024 : H12AffineFastState.Bounded env44024 := by
  intro p hp
  have h : env44024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44023_44024 : H12AffineEnvironment.transform 15 62731 env44023 = env44024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env44023 == env44024) = true)

theorem identity44024 : scanCanonicalize (H12AffineFastState.compose env44024 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44024 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env44025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,33111,5393,10281,1024,32769,4161,32800,16,2,8192,65,34817,5392,12637,35189,1364,33,256,8572,46092,41820]

theorem envBound44025 : H12AffineFastState.Bounded env44025 := by
  intro p hp
  have h : env44025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44024_44025 : H12AffineEnvironment.transform 13 13404 env44024 = env44025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44024 == env44025) = true)

theorem identity44025 : scanCanonicalize (H12AffineFastState.compose env44025 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44025 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33111,5393,2421,1024,32769,4161,32800,16,2,348,65,34817,5392,4097,35189,1364,33,256,32,38224,33280]

theorem envBound44026 : H12AffineFastState.Bounded env44026 := by
  intro p hp
  have h : env44026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44025_44026 : H12AffineEnvironment.transform 12 348 env44025 = env44026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44025 == env44026) = true)

theorem identity44026 : scanCanonicalize (H12AffineFastState.compose env44026 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44026 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44027 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,32768,33031,5393,2341,1024,32769,4113,32800,16,2,268,17,34817,5392,4097,35109,1284,33,256,32,38144,33280]

theorem envBound44027 : H12AffineFastState.Bounded env44027 := by
  intro p hp
  have h : env44027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44026_44027 : H12AffineEnvironment.transform 5 16 env44026 = env44027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44026 == env44027) = true)

theorem identity44027 : scanCanonicalize (H12AffineFastState.compose env44027 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 4388) := by decide +kernel

theorem selectedBound44027 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44028 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,4388,4131,5393,2341,1024,4389,4113,4356,16,2,268,17,6437,5392,4097,6145,1284,33,256,32,1060,4900]

theorem envBound44028 : H12AffineFastState.Bounded env44028 := by
  intro p hp
  have h : env44028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44027_44028 : H12AffineEnvironment.transform 14 4388 env44027 = env44028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4388 env44027 == env44028) = true)

theorem identity44028 : scanCanonicalize (H12AffineFastState.compose env44028 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound44028 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env44029 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1556,268,788,1840,1591,773,2341,1024,1841,1541,1808,16,2,268,17,3889,772,1557,3605,1284,33,256,32,1060,1328]

theorem envBound44029 : H12AffineFastState.Bounded env44029 := by
  intro p hp
  have h : env44029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44028_44029 : H12AffineEnvironment.transform 11 1556 env44028 = env44029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env44028 == env44029) = true)

theorem identity44029 : scanCanonicalize (H12AffineFastState.compose env44029 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound44029 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env44030 : List Nat := [2,4,8,16,32,16,8,256,512,784,2048,260,268,788,32,295,773,2341,784,33,277,0,16,2,268,17,2081,772,261,2309,532,33,256,32,820,544]

theorem envBound44030 : H12AffineFastState.Bounded env44030 := by
  intro p hp
  have h : env44030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44029_44030 : H12AffineEnvironment.transform 9 784 env44029 = env44030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env44029 == env44030) = true)

theorem identity44030 : scanCanonicalize (H12AffineFastState.compose env44030 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44030 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44031 : List Nat := [2,4,8,16,1,16,8,256,512,784,2048,260,268,788,1,262,773,2308,784,0,277,0,16,2,268,17,2048,772,261,2309,532,0,256,1,789,513]

theorem envBound44031 : H12AffineFastState.Bounded env44031 := by
  intro p hp
  have h : env44031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44030_44031 : H12AffineEnvironment.transform 4 1 env44030 = env44031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44030 == env44031) = true)

theorem identity44031 : scanCanonicalize (H12AffineFastState.compose env44031 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44032 : List Nat := [2,4,8,16,1,16,8,256,17,257,2048,260,268,261,1,262,276,2308,257,0,277,0,16,2,268,17,2048,277,261,2309,5,0,256,1,260,16]

theorem envBound44032 : H12AffineFastState.Bounded env44032 := by
  intro p hp
  have h : env44032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44031_44032 : H12AffineEnvironment.transform 8 17 env44031 = env44032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44031 == env44032) = true)

theorem identity44032 : scanCanonicalize (H12AffineFastState.compose env44032 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44032 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44033 : List Nat := [2,4,8,16,1,16,8,20,17,21,2048,16,24,17,1,18,0,2064,21,0,1,0,16,2,24,17,2048,1,17,2065,5,0,20,1,16,16]

theorem envBound44033 : H12AffineFastState.Bounded env44033 := by
  intro p hp
  have h : env44033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44032_44033 : H12AffineEnvironment.transform 7 20 env44032 = env44033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44032 == env44033) = true)

theorem identity44033 : scanCanonicalize (H12AffineFastState.compose env44033 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound44033 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44034 : List Nat := [2,4,8,16,1,16,8,20,17,21,17,16,24,17,1,18,0,1,21,0,1,0,16,2,24,17,17,1,17,0,5,0,20,1,16,16]

theorem envBound44034 : H12AffineFastState.Bounded env44034 := by
  intro p hp
  have h : env44034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44033_44034 : H12AffineEnvironment.transform 10 17 env44033 = env44034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env44033 == env44034) = true)

theorem identity44034 : scanCanonicalize (H12AffineFastState.compose env44034 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44034 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env44035 : List Nat := [2,4,8,1,1,1,8,5,0,4,0,1,9,0,1,3,0,1,4,0,1,0,1,2,9,0,0,1,0,0,5,0,5,1,1,1]

theorem envBound44035 : H12AffineFastState.Bounded env44035 := by
  intro p hp
  have h : env44035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44034_44035 : H12AffineEnvironment.transform 3 1 env44034 = env44035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44034 == env44035) = true)

theorem identity44035 : scanCanonicalize (H12AffineFastState.compose env44035 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44036 : List Nat := [2,4,2,1,1,1,2,5,0,4,0,1,3,0,1,3,0,1,4,0,1,0,1,2,3,0,0,1,0,0,5,0,5,1,1,1]

theorem envBound44036 : H12AffineFastState.Bounded env44036 := by
  intro p hp
  have h : env44036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44035_44036 : H12AffineEnvironment.transform 2 2 env44035 = env44036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44035 == env44036) = true)

def env44037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,98644,8193,65,171281,5392,17665,35189,1365,156012,256,21792,46093,74251]

theorem envBound44037 : H12AffineFastState.Bounded env44037 := by
  intro p hp
  have h : env44037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44021_44037 : H12AffineEnvironment.transform 6 9 env44021 = env44037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44021 == env44037) = true)

theorem identity44037 : scanCanonicalize (H12AffineFastState.compose env44037 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound44037 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4161,21793,16,98644,8193,65,23809,5392,17665,35189,1365,41340,256,21792,46093,74251]

theorem envBound44038 : H12AffineFastState.Bounded env44038 := by
  intro p hp
  have h : env44038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44037_44038 : H12AffineEnvironment.transform 16 49168 env44037 = env44038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44037 == env44038) = true)

theorem identity44038 : scanCanonicalize (H12AffineFastState.compose env44038 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound44038 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62810,49168,35188,1024,32769,4161,21793,16,29710,8193,65,23809,5392,17665,35189,1365,41340,256,21792,46093,55121]

theorem envBound44039 : H12AffineFastState.Bounded env44039 := by
  intro p hp
  have h : env44039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44038_44039 : H12AffineEnvironment.transform 15 62810 env44038 = env44039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env44038 == env44039) = true)

theorem identity44039 : scanCanonicalize (H12AffineFastState.compose env44039 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44039 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44040 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,62731,49168,35109,1024,32769,4112,21793,16,29710,8193,16,23809,5392,17665,35108,1284,41261,256,21792,46093,55040]

theorem envBound44040 : H12AffineFastState.Bounded env44040 := by
  intro p hp
  have h : env44040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44039_44040 : H12AffineEnvironment.transform 5 17 env44039 = env44040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44039 == env44040) = true)

theorem identity44040 : scanCanonicalize (H12AffineFastState.compose env44040 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound44040 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44041 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,32768,41263,37940,35109,1024,32769,4112,261,16,8234,8193,16,2341,5392,4389,35108,1284,41261,256,260,46093,33572]

theorem envBound44041 : H12AffineFastState.Bounded env44041 := by
  intro p hp
  have h : env44041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44040_44041 : H12AffineEnvironment.transform 13 5156 env44040 = env44041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env44040 == env44041) = true)

theorem identity44041 : scanCanonicalize (H12AffineFastState.compose env44041 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound44041 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env44042 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5156,32768,33031,37940,35109,1024,32769,4112,261,16,2,41,16,2341,5392,4389,35108,1284,33029,256,260,37925,33572]

theorem envBound44042 : H12AffineFastState.Bounded env44042 := by
  intro p hp
  have h : env44042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44041_44042 : H12AffineEnvironment.transform 12 40 env44041 = env44042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env44041 == env44042) = true)

theorem identity44042 : scanCanonicalize (H12AffineFastState.compose env44042 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44042 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44043 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5156,1,262,5173,2340,1024,0,4112,261,16,2,41,16,2341,5392,4389,2341,1284,260,256,260,5156,805]

theorem envBound44043 : H12AffineFastState.Bounded env44043 := by
  intro p hp
  have h : env44043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44042_44043 : H12AffineEnvironment.transform 14 1 env44042 = env44043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44042 == env44043) = true)

theorem identity44043 : scanCanonicalize (H12AffineFastState.compose env44043 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound44043 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44044 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,773,40,1825,1,262,1840,2340,1024,0,789,261,16,2,41,16,2341,1557,544,2341,1284,260,256,260,1825,805]

theorem envBound44044 : H12AffineFastState.Bounded env44044 := by
  intro p hp
  have h : env44044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44043_44044 : H12AffineEnvironment.transform 11 773 env44043 = env44044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env44043 == env44044) = true)

theorem identity44044 : scanCanonicalize (H12AffineFastState.compose env44044 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound44044 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env44045 : List Nat := [2,4,8,16,32,17,9,256,512,1024,513,773,40,1825,1,262,1840,805,1024,0,789,261,16,2,41,16,804,1557,544,804,1284,260,256,260,1825,805]

theorem envBound44045 : H12AffineFastState.Bounded env44045 := by
  intro p hp
  have h : env44045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44044_44045 : H12AffineEnvironment.transform 10 513 env44044 = env44045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env44044 == env44045) = true)

theorem identity44045 : scanCanonicalize (H12AffineFastState.compose env44045 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound44045 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env44046 : List Nat := [2,4,8,16,32,17,9,256,512,549,513,773,40,260,1,262,277,805,549,0,789,261,16,2,41,16,804,48,544,804,801,260,256,260,260,805]

theorem envBound44046 : H12AffineFastState.Bounded env44046 := by
  intro p hp
  have h : env44046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44045_44046 : H12AffineEnvironment.transform 9 549 env44045 = env44046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env44045 == env44046) = true)

theorem identity44046 : scanCanonicalize (H12AffineFastState.compose env44046 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound44046 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44047 : List Nat := [2,4,8,16,32,17,9,256,276,305,277,17,40,260,1,262,277,49,305,0,1,261,16,2,41,16,48,48,308,48,53,260,256,260,260,49]

theorem envBound44047 : H12AffineFastState.Bounded env44047 := by
  intro p hp
  have h : env44047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44046_44047 : H12AffineEnvironment.transform 8 276 env44046 = env44047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env44046 == env44047) = true)

theorem identity44047 : scanCanonicalize (H12AffineFastState.compose env44047 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44047 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env44048 : List Nat := [2,4,8,16,32,17,9,4,16,53,17,17,40,0,1,2,17,49,53,0,1,1,16,2,41,16,48,48,48,48,53,0,4,0,0,49]

theorem envBound44048 : H12AffineFastState.Bounded env44048 := by
  intro p hp
  have h : env44048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44047_44048 : H12AffineEnvironment.transform 7 4 env44047 = env44048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44047 == env44048) = true)

theorem identity44048 : scanCanonicalize (H12AffineFastState.compose env44048 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44049 : List Nat := [2,4,8,16,0,17,9,4,16,21,17,17,8,0,1,2,17,17,21,0,1,1,16,2,9,16,16,16,16,16,21,0,4,0,0,17]

theorem envBound44049 : H12AffineFastState.Bounded env44049 := by
  intro p hp
  have h : env44049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44048_44049 : H12AffineEnvironment.transform 4 0 env44048 = env44049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44048 == env44049) = true)

theorem identity44049 : scanCanonicalize (H12AffineFastState.compose env44049 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44049 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44050 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,1,8,0,1,2,1,1,5,0,1,1,0,2,9,0,0,0,0,0,5,0,4,0,0,1]

theorem envBound44050 : H12AffineFastState.Bounded env44050 := by
  intro p hp
  have h : env44050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44049_44050 : H12AffineEnvironment.transform 3 0 env44049 = env44050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44049 == env44050) = true)

def env44051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound44051 : H12AffineFastState.Bounded env44051 := by
  intro p hp
  have h : env44051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43825_44051 : H12AffineEnvironment.transform 18 1025 env43825 = env44051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env43825 == env44051) = true)

theorem identity44051 : scanCanonicalize (H12AffineFastState.compose env44051 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272440) := by decide +kernel

theorem selectedBound44051 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8328,65,21227577,18973837,2391400,190520,17148969,23160257,257,19262613,19205424,17075199]

theorem envBound44052 : H12AffineFastState.Bounded env44052 := by
  intro p hp
  have h : env44052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44051_44052 : H12AffineEnvironment.transform 22 272440 env44051 = env44052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272440 env44051 == env44052) = true)

def env44053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227577,18973701,2391400,190520,17148969,23160137,257,19262493,19205424,17075063]

theorem envBound44053 : H12AffineFastState.Bounded env44053 := by
  intro p hp
  have h : env44053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44052_44053 : H12AffineEnvironment.transform 6 8 env44052 = env44053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44052 == env44053) = true)

theorem identity44053 : scanCanonicalize (H12AffineFastState.compose env44053 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44053 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1025,8540,2097152,4194304,272440,16777216,8192,65,21186916,18949464,2391400,149861,17108340,23160137,257,19221824,19205424,17050154]

theorem envBound44054 : H12AffineFastState.Bounded env44054 := by
  intro p hp
  have h : env44054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44053_44054 : H12AffineEnvironment.transform 14 8541 env44053 = env44054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44053 == env44054) = true)

def env44055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157752,1025,8540,2097152,4194304,147456,16777216,8192,65,21186916,18949464,2233680,149861,16999756,23160137,257,19080568,19096840,16925202]

theorem envBound44055 : H12AffineFastState.Bounded env44055 := by
  intro p hp
  have h : env44055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44054_44055 : H12AffineEnvironment.transform 17 157752 env44054 = env44055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env44054 == env44055) = true)

theorem identity44055 : scanCanonicalize (H12AffineFastState.compose env44055 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound44055 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157752,1025,8540,2097152,4194304,147456,147475,8192,65,4262263,2319691,2233680,149861,75103,6497626,257,2188651,2172187,513]

theorem envBound44056 : H12AffineFastState.Bounded env44056 := by
  intro p hp
  have h : env44056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44055_44056 : H12AffineEnvironment.transform 23 147475 env44055 = env44056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env44055 == env44056) = true)

theorem identity44056 : scanCanonicalize (H12AffineFastState.compose env44056 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound44056 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,67619,1025,8540,2097152,4194304,73755,73736,8192,65,4262263,2098512,2192715,76158,75103,6309185,257,2188651,2172187,513]

theorem envBound44057 : H12AffineFastState.Bounded env44057 := by
  intro p hp
  have h : env44057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44056_44057 : H12AffineEnvironment.transform 16 90139 env44056 = env44057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env44056 == env44057) = true)

theorem identity44057 : scanCanonicalize (H12AffineFastState.compose env44057 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound44057 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env44058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,67619,1025,8540,25677,4194304,73755,73736,8192,65,4262263,24861,69894,76158,75103,4202764,257,65830,82262,513]

theorem envBound44058 : H12AffineFastState.Bounded env44058 := by
  intro p hp
  have h : env44058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44057_44058 : H12AffineEnvironment.transform 20 25677 env44057 = env44058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env44057 == env44058) = true)

theorem identity44058 : scanCanonicalize (H12AffineFastState.compose env44058 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound44058 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env44059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,67619,1025,8540,25677,32,73755,73736,8192,65,67927,24861,69894,76158,75103,8492,257,65830,82262,513]

theorem envBound44059 : H12AffineFastState.Bounded env44059 := by
  intro p hp
  have h : env44059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44058_44059 : H12AffineEnvironment.transform 21 32 env44058 = env44059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44058 == env44059) = true)

theorem identity44059 : scanCanonicalize (H12AffineFastState.compose env44059 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44059 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env44060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8541,65536,78910,67619,1025,8540,12392,32,73755,73736,8192,65,67927,13624,69894,76158,75103,8492,257,65830,71027,513]

theorem envBound44060 : H12AffineFastState.Bounded env44060 := by
  intro p hp
  have h : env44060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44059_44060 : H12AffineEnvironment.transform 13 5157 env44059 = env44060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44059 == env44060) = true)

theorem identity44060 : scanCanonicalize (H12AffineFastState.compose env44060 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound44060 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env44061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,8192,3345,8541,65536,77066,67619,1025,8540,10588,32,73755,73736,8192,65,67927,11276,67634,76158,75103,8492,257,65830,68679,513]

theorem envBound44061 : H12AffineFastState.Bounded env44061 := by
  intro p hp
  have h : env44061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44060_44061 : H12AffineEnvironment.transform 11 2356 env44060 = env44061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env44060 == env44061) = true)

theorem identity44061 : scanCanonicalize (H12AffineFastState.compose env44061 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound44061 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,8192,3345,8541,1094,10572,3173,1025,8540,10588,32,9309,9294,8192,65,3345,11276,3188,11576,8473,8492,257,1376,2049,513]

theorem envBound44062 : H12AffineFastState.Bounded env44062 := by
  intro p hp
  have h : env44062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44061_44062 : H12AffineEnvironment.transform 15 1094 env44061 = env44062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env44061 == env44062) = true)

theorem identity44062 : scanCanonicalize (H12AffineFastState.compose env44062 (packedSelected [0,1,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

theorem selectedBound44062 : packedSelected [0,1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env44063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2356,3149,3345,3344,1094,1281,3173,1025,3345,1297,32,2064,2051,3149,65,3345,65,3188,373,3412,3425,257,1376,2049,513]

theorem envBound44063 : H12AffineFastState.Bounded env44063 := by
  intro p hp
  have h : env44063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44062_44063 : H12AffineEnvironment.transform 12 3149 env44062 = env44063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env44062 == env44063) = true)

theorem identity44063 : scanCanonicalize (H12AffineFastState.compose env44063 (packedSelected [0,2,3,4,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44063 : packedSelected [0,2,3,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env44064 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2064,3149,3125,3124,1094,1061,3173,1025,3125,1077,32,2064,2051,3149,65,3125,65,3188,81,3184,3141,37,1092,2049,513]

theorem envBound44064 : H12AffineFastState.Bounded env44064 := by
  intro p hp
  have h : env44064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44063_44064 : H12AffineEnvironment.transform 7 36 env44063 = env44064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44063 == env44064) = true)

theorem identity44064 : scanCanonicalize (H12AffineFastState.compose env44064 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound44064 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44065 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,1061,120,0,1,1094,1061,80,1025,0,1077,32,1061,1078,120,65,0,65,65,81,69,112,37,1092,1076,513]

theorem envBound44065 : H12AffineFastState.Bounded env44065 := by
  intro p hp
  have h : env44065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44064_44065 : H12AffineEnvironment.transform 10 1077 env44064 = env44065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env44064 == env44065) = true)

theorem identity44065 : scanCanonicalize (H12AffineFastState.compose env44065 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44066 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,1061,41,0,1,1047,1061,1,1025,0,1077,32,1061,1078,41,16,0,16,16,0,20,33,37,1045,1076,513]

theorem envBound44066 : H12AffineFastState.Bounded env44066 := by
  intro p hp
  have h : env44066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44065_44066 : H12AffineEnvironment.transform 5 17 env44065 = env44066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44065 == env44066) = true)

theorem identity44066 : scanCanonicalize (H12AffineFastState.compose env44066 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44066 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44067 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,0,1,34,16,1,52,0,0,32,16,3,41,16,0,16,16,0,20,33,37,32,1,513]

theorem envBound44067 : H12AffineFastState.Bounded env44067 := by
  intro p hp
  have h : env44067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44066_44067 : H12AffineEnvironment.transform 9 53 env44066 = env44067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44066 == env44067) = true)

theorem identity44067 : scanCanonicalize (H12AffineFastState.compose env44067 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44068 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,16,41,0,1,34,16,1,52,0,0,32,16,3,41,16,0,16,16,0,20,33,37,32,1,1]

theorem envBound44068 : H12AffineFastState.Bounded env44068 := by
  intro p hp
  have h : env44068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44067_44068 : H12AffineEnvironment.transform 8 0 env44067 = env44068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44067 == env44068) = true)

theorem identity44068 : scanCanonicalize (H12AffineFastState.compose env44068 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44069 : List Nat := [2,4,8,16,10,17,8,14,0,31,0,16,3,0,1,8,16,1,30,0,0,10,16,3,3,16,0,16,16,0,20,11,15,10,1,1]

theorem envBound44069 : H12AffineFastState.Bounded env44069 := by
  intro p hp
  have h : env44069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44068_44069 : H12AffineEnvironment.transform 4 10 env44068 = env44069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44068 == env44069) = true)

def env44070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157753,1025,8540,2097152,4194304,147457,16777216,8192,65,21186916,18949464,2233681,149861,16999757,23160137,257,19080569,19096841,16925203]

theorem envBound44070 : H12AffineFastState.Bounded env44070 := by
  intro p hp
  have h : env44070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44054_44070 : H12AffineEnvironment.transform 17 157753 env44054 = env44070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env44054 == env44070) = true)

theorem identity44070 : scanCanonicalize (H12AffineFastState.compose env44070 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound44070 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env44071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157753,1025,8540,2097152,147505,147457,16777216,8192,65,16845141,18949464,2233681,149861,16999757,19080568,257,19080569,19096841,16925203]

theorem envBound44071 : H12AffineFastState.Bounded env44071 := by
  intro p hp
  have h : env44071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44070_44071 : H12AffineEnvironment.transform 21 147505 env44070 = env44071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env44070 == env44071) = true)

theorem identity44071 : scanCanonicalize (H12AffineFastState.compose env44071 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound44071 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157753,1025,8540,2097152,147505,147457,3,8192,65,67926,2172251,2233681,149861,222542,2303355,257,2303354,2319626,147984]

theorem envBound44072 : H12AffineFastState.Bounded env44072 := by
  intro p hp
  have h : env44072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44071_44072 : H12AffineEnvironment.transform 23 3 env44071 = env44072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env44071 == env44072) = true)

theorem identity44072 : scanCanonicalize (H12AffineFastState.compose env44072 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound44072 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env44073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,65536,131072,138560,1025,8540,2097152,144712,144760,3,8192,65,67926,2172251,2233681,146460,200759,2303355,257,2303354,2297971,145257]

theorem envBound44073 : H12AffineFastState.Bounded env44073 := by
  intro p hp
  have h : env44073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44072_44073 : H12AffineEnvironment.transform 13 13689 env44072 = env44073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env44072 == env44073) = true)

theorem identity44073 : scanCanonicalize (H12AffineFastState.compose env44073 (packedSelected [2,4,6,11,16,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44073 : packedSelected [2,4,6,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env44074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8202,131072,138560,1025,8540,2097152,144712,144760,3,8192,65,10588,2098513,2233681,146460,143421,2229617,257,2229616,2240633,145257]

theorem envBound44074 : H12AffineFastState.Bounded env44074 := by
  intro p hp
  have h : env44074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44073_44074 : H12AffineEnvironment.transform 15 8202 env44073 = env44074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44073 == env44074) = true)

theorem identity44074 : scanCanonicalize (H12AffineFastState.compose env44074 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 12604) := by decide +kernel

theorem selectedBound44074 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env44075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8202,131072,138560,1025,8540,12604,144712,144760,3,8192,65,10588,13421,140397,146460,143421,144461,257,144460,131397,145257]

theorem envBound44075 : H12AffineFastState.Bounded env44075 := by
  intro p hp
  have h : env44075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44074_44075 : H12AffineEnvironment.transform 20 12604 env44074 = env44075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12604 env44074 == env44075) = true)

theorem identity44075 : scanCanonicalize (H12AffineFastState.compose env44075 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound44075 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8202,13673,10281,1025,8540,12604,33,17,3,8192,65,10588,13421,4356,2421,1364,292,257,293,13356,512]

theorem envBound44076 : H12AffineFastState.Bounded env44076 := by
  intro p hp
  have h : env44076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44075_44076 : H12AffineEnvironment.transform 16 13673 env44075 = env44076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env44075 == env44076) = true)

theorem identity44076 : scanCanonicalize (H12AffineFastState.compose env44076 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound44076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5204,112,295,5188,2308,1025,113,4113,33,17,3,301,65,2161,5440,4356,2421,1364,292,257,293,5377,512]

theorem envBound44077 : H12AffineFastState.Bounded env44077 := by
  intro p hp
  have h : env44077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44076_44077 : H12AffineEnvironment.transform 12 301 env44076 = env44077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env44076 == env44077) = true)

theorem identity44077 : scanCanonicalize (H12AffineFastState.compose env44077 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound44077 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44078 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,301,5156,0,295,5172,2308,1025,1,4113,33,17,3,301,49,2049,5424,4356,2309,1316,292,257,293,5377,512]

theorem envBound44078 : H12AffineFastState.Bounded env44078 := by
  intro p hp
  have h : env44078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44077_44078 : H12AffineEnvironment.transform 5 48 env44077 = env44078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env44077 == env44078) = true)

theorem identity44078 : scanCanonicalize (H12AffineFastState.compose env44078 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44078 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44079 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,9,5156,0,3,5172,2080,1025,1,4113,33,17,3,9,49,2049,5140,4128,2081,1024,0,37,1,5157,512]

theorem envBound44079 : H12AffineFastState.Bounded env44079 := by
  intro p hp
  have h : env44079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44078_44079 : H12AffineEnvironment.transform 7 36 env44078 = env44079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44078 == env44079) = true)

theorem identity44079 : scanCanonicalize (H12AffineFastState.compose env44079 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound44079 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44080 : List Nat := [2,4,8,16,32,48,8,36,512,21,2048,4096,9,4145,0,3,4129,2080,20,1,4113,33,17,3,9,49,2049,4097,4128,2081,21,0,37,1,4144,512]

theorem envBound44080 : H12AffineFastState.Bounded env44080 := by
  intro p hp
  have h : env44080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44079_44080 : H12AffineEnvironment.transform 9 21 env44079 = env44080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44079 == env44080) = true)

theorem identity44080 : scanCanonicalize (H12AffineFastState.compose env44080 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound44080 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44081 : List Nat := [2,4,8,16,32,48,8,36,512,21,2048,561,9,512,0,3,528,2080,20,1,544,33,17,3,9,49,2049,560,529,2081,21,0,37,1,513,512]

theorem envBound44081 : H12AffineFastState.Bounded env44081 := by
  intro p hp
  have h : env44081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44080_44081 : H12AffineEnvironment.transform 11 561 env44080 = env44081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env44080 == env44081) = true)

theorem identity44081 : scanCanonicalize (H12AffineFastState.compose env44081 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound44081 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44082 : List Nat := [2,4,8,16,32,48,8,36,512,21,561,561,9,512,0,3,528,529,20,1,544,33,17,3,9,49,560,560,529,528,21,0,37,1,513,512]

theorem envBound44082 : H12AffineFastState.Bounded env44082 := by
  intro p hp
  have h : env44082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44081_44082 : H12AffineEnvironment.transform 10 561 env44081 = env44082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env44081 == env44082) = true)

theorem identity44082 : scanCanonicalize (H12AffineFastState.compose env44082 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44082 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44083 : List Nat := [2,4,8,16,0,16,8,4,512,21,529,529,9,512,0,3,528,529,20,1,512,1,17,3,9,17,528,528,529,528,21,0,5,1,513,512]

theorem envBound44083 : H12AffineFastState.Bounded env44083 := by
  intro p hp
  have h : env44083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44082_44083 : H12AffineEnvironment.transform 4 0 env44082 = env44083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44082 == env44083) = true)

theorem identity44083 : scanCanonicalize (H12AffineFastState.compose env44083 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44084 : List Nat := [2,4,8,16,0,16,8,4,16,21,1,1,9,16,0,3,0,1,20,1,16,1,17,3,9,17,0,0,1,0,21,0,5,1,17,16]

theorem envBound44084 : H12AffineFastState.Bounded env44084 := by
  intro p hp
  have h : env44084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44083_44084 : H12AffineEnvironment.transform 8 16 env44083 = env44084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44083 == env44084) = true)

theorem identity44084 : scanCanonicalize (H12AffineFastState.compose env44084 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound44084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44085 : List Nat := [2,4,6,16,0,16,6,4,16,21,1,1,7,16,0,3,0,1,20,1,16,1,17,3,7,17,0,0,1,0,21,0,5,1,17,16]

theorem envBound44085 : H12AffineFastState.Bounded env44085 := by
  intro p hp
  have h : env44085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44084_44085 : H12AffineEnvironment.transform 2 6 env44084 = env44085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env44084 == env44085) = true)

def env44086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8193,65,21227577,18973700,2391400,190520,17148969,23160136,257,19262492,19205424,17075062]

theorem envBound44086 : H12AffineFastState.Bounded env44086 := by
  intro p hp
  have h : env44086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44052_44086 : H12AffineEnvironment.transform 6 9 env44052 = env44086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44052 == env44086) = true)

theorem identity44086 : scanCanonicalize (H12AffineFastState.compose env44086 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44086 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,16777216,8193,65,21227577,18973700,2118977,190520,16876544,23160136,257,18990133,18949401,16819039]

theorem envBound44087 : H12AffineFastState.Bounded env44087 := by
  intro p hp
  have h : env44087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44086_44087 : H12AffineEnvironment.transform 17 10281 env44086 = env44087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44086 == env44087) = true)

theorem identity44087 : scanCanonicalize (H12AffineFastState.compose env44087 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound44087 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env44088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,41310,8193,65,4409703,2172250,2118977,190520,75102,6407190,257,2188651,2196551,513]

theorem envBound44088 : H12AffineFastState.Bounded env44088 := by
  intro p hp
  have h : env44088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44087_44088 : H12AffineEnvironment.transform 23 41310 env44087 = env44088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env44087 == env44088) = true)

def env44089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41310,8193,65,4409703,115014,45405,190520,75102,4268042,257,98679,90203,513]

theorem envBound44089 : H12AffineFastState.Bounded env44089 := by
  intro p hp
  have h : env44089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44088_44089 : H12AffineEnvironment.transform 20 58396 env44088 = env44089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env44088 == env44089) = true)

def env44090 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41230,8193,17,4409655,114966,45325,190520,75022,4268042,257,98599,90123,513]

theorem envBound44090 : H12AffineFastState.Bounded env44090 := by
  intro p hp
  have h : env44090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44089_44090 : H12AffineEnvironment.transform 5 16 env44089 = env44090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44089 == env44090) = true)

theorem identity44090 : scanCanonicalize (H12AffineFastState.compose env44090 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound44090 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env44091 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1025,32769,58396,4194304,17,41230,8193,17,4385084,24861,45325,190520,34053,4227073,257,8492,49152,513]

theorem envBound44091 : H12AffineFastState.Bounded env44091 := by
  intro p hp
  have h : env44091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44090_44091 : H12AffineEnvironment.transform 15 40971 env44090 = env44091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env44090 == env44091) = true)

theorem identity44091 : scanCanonicalize (H12AffineFastState.compose env44091 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155964) := by decide +kernel

theorem selectedBound44091 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44092 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1025,32769,58396,155964,17,41230,8193,17,34816,24861,45325,190520,34053,188733,257,8492,49152,513]

theorem envBound44092 : H12AffineFastState.Bounded env44092 := by
  intro p hp
  have h : env44092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44091_44092 : H12AffineEnvironment.transform 21 155964 env44091 = env44092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155964 env44091 == env44092) = true)

theorem identity44092 : scanCanonicalize (H12AffineFastState.compose env44092 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound44092 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44093 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10281,1025,32769,58396,8492,17,41230,8193,17,34816,24861,45325,43048,34053,41261,257,8492,49152,513]

theorem envBound44093 : H12AffineFastState.Bounded env44093 := by
  intro p hp
  have h : env44093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44092_44093 : H12AffineEnvironment.transform 16 16400 env44092 = env44093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env44092 == env44093) = true)

def env44094 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41231,8193,16,4409654,114967,45324,190520,75023,4268042,257,98598,90122,513]

theorem envBound44094 : H12AffineFastState.Bounded env44094 := by
  intro p hp
  have h : env44094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44089_44094 : H12AffineEnvironment.transform 5 17 env44089 = env44094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44089 == env44094) = true)

theorem identity44094 : scanCanonicalize (H12AffineFastState.compose env44094 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound44094 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env44095 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,246070,17,41231,8193,16,34816,114967,45324,190520,75023,188732,257,98598,90122,513]

theorem envBound44095 : H12AffineFastState.Bounded env44095 := by
  intro p hp
  have h : env44095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44094_44095 : H12AffineEnvironment.transform 21 246070 env44094 = env44095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env44094 == env44095) = true)

theorem identity44095 : scanCanonicalize (H12AffineFastState.compose env44095 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44095 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env44096 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10281,1025,0,25629,213303,17,8462,8193,16,2049,82198,12557,157753,75023,155965,257,65831,90122,513]

theorem envBound44096 : H12AffineFastState.Bounded env44096 := by
  intro p hp
  have h : env44096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44095_44096 : H12AffineEnvironment.transform 14 1 env44095 = env44096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44095 == env44096) = true)

theorem identity44096 : scanCanonicalize (H12AffineFastState.compose env44096 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound44096 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44097 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,263,131072,10281,1025,0,25629,147504,17,8462,8193,16,2049,16401,12557,157753,9224,155965,257,32,24845,513]

theorem envBound44097 : H12AffineFastState.Bounded env44097 := by
  intro p hp
  have h : env44097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44096_44097 : H12AffineEnvironment.transform 15 263 env44096 = env44097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env44096 == env44097) = true)

theorem identity44097 : scanCanonicalize (H12AffineFastState.compose env44097 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound44097 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env44098 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,263,16400,10281,1025,0,25629,32,17,8462,8193,16,2049,16401,12557,10281,9224,8493,257,32,24845,513]

theorem envBound44098 : H12AffineFastState.Bounded env44098 := by
  intro p hp
  have h : env44098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44097_44098 : H12AffineEnvironment.transform 16 16400 env44097 = env44098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env44097 == env44098) = true)

theorem identity44098 : scanCanonicalize (H12AffineFastState.compose env44098 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44098 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env44099 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,263,16400,2341,1025,0,17681,32,17,2,269,16,2049,16401,4097,2341,1284,33,257,32,16385,513]

theorem envBound44099 : H12AffineFastState.Bounded env44099 := by
  intro p hp
  have h : env44099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44098_44099 : H12AffineEnvironment.transform 12 268 env44098 = env44099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44098 == env44099) = true)

theorem identity44099 : scanCanonicalize (H12AffineFastState.compose env44099 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound44099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44100 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4388,1,263,4404,2341,1025,0,5173,32,17,2,269,16,2049,4405,4097,2341,1284,33,257,32,4389,513]

theorem envBound44100 : H12AffineFastState.Bounded env44100 := by
  intro p hp
  have h : env44100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44099_44100 : H12AffineEnvironment.transform 13 4388 env44099 = env44100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env44099 == env44100) = true)

theorem identity44100 : scanCanonicalize (H12AffineFastState.compose env44100 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound44100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44101 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,268,804,1,263,820,2341,1025,0,1589,32,17,2,269,16,2049,821,513,2341,1284,33,257,32,805,513]

theorem envBound44101 : H12AffineFastState.Bounded env44101 := by
  intro p hp
  have h : env44101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44100_44101 : H12AffineEnvironment.transform 11 512 env44100 = env44101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env44100 == env44101) = true)

theorem identity44101 : scanCanonicalize (H12AffineFastState.compose env44101 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound44101 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44102 : List Nat := [2,4,8,16,32,17,9,256,512,769,2048,512,268,804,1,263,820,2341,768,0,308,32,17,2,269,16,2049,821,513,2341,517,33,257,32,805,513]

theorem envBound44102 : H12AffineFastState.Bounded env44102 := by
  intro p hp
  have h : env44102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44101_44102 : H12AffineEnvironment.transform 9 769 env44101 = env44102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env44101 == env44102) = true)

theorem identity44102 : scanCanonicalize (H12AffineFastState.compose env44102 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound44102 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44103 : List Nat := [2,4,8,16,32,17,9,52,512,565,2048,512,56,528,1,51,512,2065,564,0,0,32,17,2,57,16,2049,513,513,2065,517,33,53,32,529,513]

theorem envBound44103 : H12AffineFastState.Bounded env44103 := by
  intro p hp
  have h : env44103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44102_44103 : H12AffineEnvironment.transform 7 52 env44102 = env44103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env44102 == env44103) = true)

theorem identity44103 : scanCanonicalize (H12AffineFastState.compose env44103 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound44103 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44104 : List Nat := [2,4,8,16,32,17,9,52,512,565,17,512,56,528,1,51,512,0,564,0,0,32,17,2,57,16,16,513,513,0,517,33,53,32,529,513]

theorem envBound44104 : H12AffineFastState.Bounded env44104 := by
  intro p hp
  have h : env44104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44103_44104 : H12AffineEnvironment.transform 10 17 env44103 = env44104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env44103 == env44104) = true)

theorem identity44104 : scanCanonicalize (H12AffineFastState.compose env44104 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44105 : List Nat := [2,4,8,16,1,17,9,21,512,532,17,512,25,528,1,18,512,0,533,0,0,1,17,2,24,16,16,513,513,0,517,0,20,1,529,513]

theorem envBound44105 : H12AffineFastState.Bounded env44105 := by
  intro p hp
  have h : env44105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44104_44105 : H12AffineEnvironment.transform 4 1 env44104 = env44105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44104 == env44105) = true)

theorem identity44105 : scanCanonicalize (H12AffineFastState.compose env44105 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44106 : List Nat := [2,4,8,16,1,17,9,21,1,21,17,1,25,17,1,18,1,0,20,0,0,1,17,2,24,16,16,0,0,0,4,0,20,1,16,0]

theorem envBound44106 : H12AffineFastState.Bounded env44106 := by
  intro p hp
  have h : env44106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44105_44106 : H12AffineEnvironment.transform 8 1 env44105 = env44106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44105 == env44106) = true)

def env44107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41310,8193,65,4409703,115015,45404,190520,75102,4268043,257,98678,90202,513]

theorem envBound44107 : H12AffineFastState.Bounded env44107 := by
  intro p hp
  have h : env44107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44088_44107 : H12AffineEnvironment.transform 20 58397 env44088 = env44107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env44088 == env44107) = true)

theorem identity44107 : scanCanonicalize (H12AffineFastState.compose env44107 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44107 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58397,4194304,17,41310,8193,65,4352365,57677,45404,190520,1364,4194305,257,41340,16464,513]

theorem envBound44108 : H12AffineFastState.Bounded env44108 := by
  intro p hp
  have h : env44108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44107_44108 : H12AffineEnvironment.transform 15 8202 env44107 = env44108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44107 == env44108) = true)

theorem identity44108 : scanCanonicalize (H12AffineFastState.compose env44108 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 147552) := by decide +kernel

theorem selectedBound44108 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env44109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58397,147552,17,41310,8193,65,10509,57677,45404,190520,1364,147553,257,41340,16464,513]

theorem envBound44109 : H12AffineFastState.Bounded env44109 := by
  intro p hp
  have h : env44109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44108_44109 : H12AffineEnvironment.transform 21 147552 env44108 = env44109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147552 env44108 == env44109) = true)

theorem identity44109 : scanCanonicalize (H12AffineFastState.compose env44109 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound44109 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env44110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24860,10281,1025,32769,58397,8572,17,41310,8193,65,10509,57677,45404,35108,1364,8573,257,41340,16464,513]

theorem envBound44110 : H12AffineFastState.Bounded env44110 := by
  intro p hp
  have h : env44110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44109_44110 : H12AffineEnvironment.transform 16 24860 env44109 = env44110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env44109 == env44110) = true)

theorem identity44110 : scanCanonicalize (H12AffineFastState.compose env44110 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44110 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,2420,1025,32769,50496,33,17,32771,348,65,2128,49168,36865,35108,1364,32,257,32801,16464,513]

theorem envBound44111 : H12AffineFastState.Bounded env44111 := by
  intro p hp
  have h : env44111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44110_44111 : H12AffineEnvironment.transform 12 349 env44110 = env44111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44110 == env44111) = true)

theorem identity44111 : scanCanonicalize (H12AffineFastState.compose env44111 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44111 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44112 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,16401,2340,1025,32769,50448,33,17,32771,268,17,2048,49168,36865,35108,1284,32,257,32801,16384,513]

theorem envBound44112 : H12AffineFastState.Bounded env44112 := by
  intro p hp
  have h : env44112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44111_44112 : H12AffineEnvironment.transform 5 16 env44111 = env44112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44111 == env44112) = true)

theorem identity44112 : scanCanonicalize (H12AffineFastState.compose env44112 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44112 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env44113 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,32768,263,5172,2340,1025,32769,37173,33,17,32771,268,17,2048,37941,36865,35108,1284,32,257,32801,5157,513]

end H12CloudChart1