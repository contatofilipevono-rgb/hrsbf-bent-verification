import H12CloudChart1Data046

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity11763 : scanCanonicalize (H12AffineFastState.compose env11763 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound11763 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11764 : List Nat := [2,4,8,16,15,30,6,4,15,20,1,30,6,0,1,12,16,0,21,0,0,14,30,2,8,30,15,16,30,14,21,15,5,1,14,15]

theorem envBound11764 : H12AffineFastState.Bounded env11764 := by
  intro p hp
  have h : env11764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11763_11764 : H12AffineEnvironment.transform 8 15 env11763 = env11764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env11763 == env11764) = true)

theorem identity11764 : scanCanonicalize (H12AffineFastState.compose env11764 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11764 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11765 : List Nat := [2,4,6,16,1,16,6,4,1,20,1,16,6,0,1,2,16,0,21,0,0,0,16,2,6,16,1,16,16,0,21,1,5,1,0,1]

theorem envBound11765 : H12AffineFastState.Bounded env11765 := by
  intro p hp
  have h : env11765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11764_11765 : H12AffineEnvironment.transform 2 6 env11764 = env11765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11764 == env11765) = true)

def env11766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169401,156116,253977,8328,64,64605,160980,140484,35324,1501,33,257,21792,46213,74250]

theorem envBound11766 : H12AffineFastState.Bounded env11766 := by
  intro p hp
  have h : env11766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11736_11766 : H12AffineEnvironment.transform 17 10281 env11736 = env11766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11736 == env11766) = true)

def env11767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21929,41412,73737,8328,64,64605,46276,58580,35324,1501,33,257,21792,46213,74250]

theorem envBound11767 : H12AffineFastState.Bounded env11767 := by
  intro p hp
  have h : env11767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11766_11767 : H12AffineEnvironment.transform 16 49168 env11766 = env11767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env11766 == env11767) = true)

theorem identity11767 : scanCanonicalize (H12AffineFastState.compose env11767 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11767 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1025,32769,4160,21929,41412,2,8328,64,64605,46276,58580,35324,1501,33,257,21792,46213,513]

theorem envBound11768 : H12AffineFastState.Bounded env11768 := by
  intro p hp
  have h : env11768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11767_11768 : H12AffineEnvironment.transform 15 8203 env11767 = env11768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11767 == env11768) = true)

theorem identity11768 : scanCanonicalize (H12AffineFastState.compose env11768 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11768 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env11769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,16400,10281,1025,1,4160,21929,8644,2,8328,64,31837,13508,25812,2556,1501,33,257,21792,13445,513]

theorem envBound11769 : H12AffineFastState.Bounded env11769 := by
  intro p hp
  have h : env11769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11768_11769 : H12AffineEnvironment.transform 14 0 env11768 = env11769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11768 == env11769) = true)

def env11770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21928,41413,73736,8328,64,64605,46277,58581,35324,1501,33,257,21792,46213,74250]

theorem envBound11770 : H12AffineFastState.Bounded env11770 := by
  intro p hp
  have h : env11770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11766_11770 : H12AffineEnvironment.transform 16 49169 env11766 = env11770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env11766 == env11770) = true)

theorem identity11770 : scanCanonicalize (H12AffineFastState.compose env11770 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound11770 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1025,32769,4160,21928,41413,138,8328,64,64605,46277,58581,35324,1501,33,257,21792,46213,648]

theorem envBound11771 : H12AffineFastState.Bounded env11771 := by
  intro p hp
  have h : env11771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11770_11771 : H12AffineEnvironment.transform 15 8322 env11770 = env11771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env11770 == env11771) = true)

theorem identity11771 : scanCanonicalize (H12AffineFastState.compose env11771 (packedSelected [10,12,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound11771 : packedSelected [10,12,18,19,23] rootPS < 2^1333 := by decide +kernel

def env11772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8580,8322,24981,10281,1025,8581,4160,21928,65,138,8328,64,24025,5441,17745,10360,1501,33,257,21792,5377,648]

theorem envBound11772 : H12AffineFastState.Bounded env11772 := by
  intro p hp
  have h : env11772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11771_11772 : H12AffineEnvironment.transform 14 8580 env11771 = env11772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env11771 == env11772) = true)

theorem identity11772 : scanCanonicalize (H12AffineFastState.compose env11772 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11772 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,216,478,16585,2421,1025,217,4160,21928,65,138,468,64,24025,5441,17745,2340,1501,33,257,21792,5377,648]

theorem envBound11773 : H12AffineFastState.Bounded env11773 := by
  intro p hp
  have h : env11773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11772_11773 : H12AffineEnvironment.transform 12 348 env11772 = env11773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11772 == env11773) = true)

theorem identity11773 : scanCanonicalize (H12AffineFastState.compose env11773 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11773 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11774 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,136,398,16537,2341,1025,137,4112,21928,17,138,388,16,23945,5393,17665,2340,1421,33,257,21792,5377,648]

theorem envBound11774 : H12AffineFastState.Bounded env11774 := by
  intro p hp
  have h : env11774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11773_11774 : H12AffineEnvironment.transform 5 16 env11773 = env11774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11773 == env11774) = true)

theorem identity11774 : scanCanonicalize (H12AffineFastState.compose env11774 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11774 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env11775 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1025,1,4112,21792,17,2,268,16,23809,5393,17665,2340,1285,33,257,21792,5377,512]

theorem envBound11775 : H12AffineFastState.Bounded env11775 := by
  intro p hp
  have h : env11775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11774_11775 : H12AffineEnvironment.transform 6 8 env11774 = env11775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11774 == env11775) = true)

theorem identity11775 : scanCanonicalize (H12AffineFastState.compose env11775 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11775 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11776 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,16384,0,262,16401,2309,1025,1,4112,21760,17,2,268,16,23809,5393,17665,2308,1285,1,257,21760,5377,512]

theorem envBound11776 : H12AffineFastState.Bounded env11776 := by
  intro p hp
  have h : env11776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11775_11776 : H12AffineEnvironment.transform 4 0 env11775 = env11776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11775 == env11776) = true)

theorem identity11776 : scanCanonicalize (H12AffineFastState.compose env11776 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound11776 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11777 : List Nat := [2,4,8,16,0,16,8,256,512,1024,522,4096,268,16384,0,262,16401,783,1025,1,4112,21760,17,2,268,16,22283,5393,17665,782,1285,1,257,21760,5377,512]

theorem envBound11777 : H12AffineFastState.Bounded env11777 := by
  intro p hp
  have h : env11777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11776_11777 : H12AffineEnvironment.transform 10 522 env11776 = env11777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env11776 == env11777) = true)

theorem identity11777 : scanCanonicalize (H12AffineFastState.compose env11777 (packedSelected [1,3,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11777 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env11778 : List Nat := [2,4,8,16,0,16,8,256,512,1024,522,4096,268,5376,0,262,5393,783,1025,1,4112,0,17,2,268,16,523,5393,4097,782,1285,1,257,0,5377,512]

theorem envBound11778 : H12AffineFastState.Bounded env11778 := by
  intro p hp
  have h : env11778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11777_11778 : H12AffineEnvironment.transform 13 5376 env11777 = env11778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11777 == env11778) = true)

theorem identity11778 : scanCanonicalize (H12AffineFastState.compose env11778 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11778 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11779 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,4096,8,5124,0,2,5141,523,1025,1,4112,0,17,2,8,16,523,5141,4097,522,1025,1,5,0,5125,512]

theorem envBound11779 : H12AffineFastState.Bounded env11779 := by
  intro p hp
  have h : env11779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11778_11779 : H12AffineEnvironment.transform 7 4 env11778 = env11779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11778 == env11779) = true)

def env11780 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,16,8,1044,0,2,1029,523,1025,1,0,0,17,2,8,16,523,1029,17,522,1025,1,5,0,1045,512]

theorem envBound11780 : H12AffineFastState.Bounded env11780 := by
  intro p hp
  have h : env11780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11779_11780 : H12AffineEnvironment.transform 11 16 env11779 = env11780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11779 == env11780) = true)

theorem identity11780 : scanCanonicalize (H12AffineFastState.compose env11780 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound11780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11781 : List Nat := [2,4,8,16,0,16,8,4,31,1024,21,16,8,1044,0,2,1029,20,1025,1,0,0,17,2,8,16,20,1029,17,21,1025,1,5,0,1045,31]

theorem envBound11781 : H12AffineFastState.Bounded env11781 := by
  intro p hp
  have h : env11781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11780_11781 : H12AffineEnvironment.transform 8 31 env11780 = env11781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env11780 == env11781) = true)

def env11782 : List Nat := [2,4,8,16,0,16,8,4,31,0,21,16,8,20,0,2,5,20,1,1,0,0,17,2,8,16,20,5,17,21,1,1,5,0,21,31]

theorem envBound11782 : H12AffineFastState.Bounded env11782 := by
  intro p hp
  have h : env11782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11781_11782 : H12AffineEnvironment.transform 9 0 env11781 = env11782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env11781 == env11782) = true)

theorem identity11782 : scanCanonicalize (H12AffineFastState.compose env11782 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound11782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11783 : List Nat := [0,4,8,16,0,16,8,4,29,0,21,16,8,20,0,0,5,20,1,1,0,0,17,0,8,16,20,5,17,21,1,1,5,0,21,29]

theorem envBound11783 : H12AffineFastState.Bounded env11783 := by
  intro p hp
  have h : env11783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11782_11783 : H12AffineEnvironment.transform 0 0 env11782 = env11783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env11782 == env11783) = true)

def leafEnv11783 : List Nat := [0,4,8,16,0,16,8,4,29,0,21,16,8,20,0,0,5,20,1,1,0,0,17,0,1,8,1,16,20,5,17,21,1,1,5,0,4,0,21,29,1,1,0]

def active11783 : List Nat := [1,2,3]

def tree11783 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11783 : H12WitnessSearch.Good tree11783 := H12GlobalWitnessIndex.good

theorem leafIdentity11783 : H12AffineFastState.composeSystem env11783 rootObs = leafEnv11783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11783 rootObs == leafEnv11783) = true)

theorem terminalChecked11783 : H12PackedTerminal.terminalCheckFast leafEnv11783 active11783 tree11783 = true := by decide +kernel

def env11784 : List Nat := [2,4,8,16,0,16,8,4,31,1,21,16,8,21,0,2,4,20,0,1,0,0,17,2,8,16,20,4,17,21,0,1,5,0,20,31]

theorem envBound11784 : H12AffineFastState.Bounded env11784 := by
  intro p hp
  have h : env11784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11781_11784 : H12AffineEnvironment.transform 9 1 env11781 = env11784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env11781 == env11784) = true)

theorem identity11784 : scanCanonicalize (H12AffineFastState.compose env11784 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound11784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11785 : List Nat := [2,4,8,7,0,7,8,4,8,1,2,7,8,2,0,2,4,3,0,1,0,0,6,2,8,7,3,4,6,2,0,1,5,0,3,8]

theorem envBound11785 : H12AffineFastState.Bounded env11785 := by
  intro p hp
  have h : env11785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11784_11785 : H12AffineEnvironment.transform 3 7 env11784 = env11785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env11784 == env11785) = true)

def leafEnv11785 : List Nat := [2,4,8,7,0,7,8,4,8,1,2,7,8,2,0,2,4,3,0,1,0,0,6,2,0,8,1,7,3,4,6,2,0,1,5,0,4,2,3,8,1,1,0]

def active11785 : List Nat := [0,1,2]

def tree11785 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11785 : H12WitnessSearch.Good tree11785 := H12GlobalWitnessIndex.good

theorem leafIdentity11785 : H12AffineFastState.composeSystem env11785 rootObs = leafEnv11785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11785 rootObs == leafEnv11785) = true)

theorem terminalChecked11785 : H12PackedTerminal.terminalCheckFast leafEnv11785 active11785 tree11785 = true := by decide +kernel

def env11786 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,17,8,1045,0,2,1028,523,1025,1,1,0,17,2,8,16,523,1028,16,522,1025,1,5,0,1044,512]

theorem envBound11786 : H12AffineFastState.Bounded env11786 := by
  intro p hp
  have h : env11786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11779_11786 : H12AffineEnvironment.transform 11 17 env11779 = env11786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11779 == env11786) = true)

theorem identity11786 : scanCanonicalize (H12AffineFastState.compose env11786 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound11786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11787 : List Nat := [2,4,8,16,0,16,8,4,512,523,522,17,8,542,0,2,527,523,522,1,1,0,17,2,8,16,523,527,16,522,522,1,5,0,543,512]

theorem envBound11787 : H12AffineFastState.Bounded env11787 := by
  intro p hp
  have h : env11787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11786_11787 : H12AffineEnvironment.transform 9 523 env11786 = env11787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env11786 == env11787) = true)

def env11788 : List Nat := [2,4,8,4,0,4,8,4,512,523,522,5,8,522,0,2,527,523,522,1,1,0,5,2,8,4,523,527,4,522,522,1,5,0,523,512]

theorem envBound11788 : H12AffineFastState.Bounded env11788 := by
  intro p hp
  have h : env11788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11787_11788 : H12AffineEnvironment.transform 3 4 env11787 = env11788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11787 == env11788) = true)

theorem identity11788 : scanCanonicalize (H12AffineFastState.compose env11788 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound11788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11789 : List Nat := [2,4,8,4,0,4,8,4,9,2,3,5,8,3,0,2,6,2,3,1,1,0,5,2,8,4,2,6,4,3,3,1,5,0,2,9]

theorem envBound11789 : H12AffineFastState.Bounded env11789 := by
  intro p hp
  have h : env11789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11788_11789 : H12AffineEnvironment.transform 8 9 env11788 = env11789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env11788 == env11789) = true)

def leafEnv11789 : List Nat := [2,4,8,4,0,4,8,4,9,2,3,5,8,3,0,2,6,2,3,1,1,0,5,2,3,8,1,4,2,6,4,3,3,1,5,0,4,2,2,9,1,0,0]

def active11789 : List Nat := [0,1,2]

def tree11789 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11789 : H12WitnessSearch.Good tree11789 := H12GlobalWitnessIndex.good

theorem leafIdentity11789 : H12AffineFastState.composeSystem env11789 rootObs = leafEnv11789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11789 rootObs == leafEnv11789) = true)

theorem terminalChecked11789 : H12PackedTerminal.terminalCheckFast leafEnv11789 active11789 tree11789 = true := by decide +kernel

def env11790 : List Nat := [2,4,8,5,0,5,8,4,512,523,522,4,8,523,0,2,527,523,522,1,1,0,4,2,8,5,523,527,5,522,522,1,5,0,522,512]

theorem envBound11790 : H12AffineFastState.Bounded env11790 := by
  intro p hp
  have h : env11790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11787_11790 : H12AffineEnvironment.transform 3 5 env11787 = env11790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11787 == env11790) = true)

theorem identity11790 : scanCanonicalize (H12AffineFastState.compose env11790 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound11790 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11791 : List Nat := [0,4,8,5,0,5,8,4,512,521,520,4,8,521,0,0,525,521,520,1,1,0,4,0,8,5,521,525,5,520,520,1,5,0,520,512]

theorem envBound11791 : H12AffineFastState.Bounded env11791 := by
  intro p hp
  have h : env11791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11790_11791 : H12AffineEnvironment.transform 0 0 env11790 = env11791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env11790 == env11791) = true)

def leafEnv11791 : List Nat := [0,4,8,5,0,5,8,4,512,521,520,4,8,521,0,0,525,521,520,1,1,0,4,0,520,8,1,5,521,525,5,520,520,1,5,0,4,0,520,512,1,0,0]

def active11791 : List Nat := [1,2,8]

def tree11791 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11791 : H12WitnessSearch.Good tree11791 := H12GlobalWitnessIndex.good

theorem leafIdentity11791 : H12AffineFastState.composeSystem env11791 rootObs = leafEnv11791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11791 rootObs == leafEnv11791) = true)

theorem terminalChecked11791 : H12PackedTerminal.terminalCheckFast leafEnv11791 active11791 tree11791 = true := by decide +kernel

def env11792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,253977,8328,64,64604,160981,140484,303572,1500,272393,257,21792,46213,74251]

theorem envBound11792 : H12AffineFastState.Bounded env11792 := by
  intro p hp
  have h : env11792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11735_11792 : H12AffineEnvironment.transform 20 4161 env11735 = env11792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11735 == env11792) = true)

theorem identity11792 : scanCanonicalize (H12AffineFastState.compose env11792 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound11792 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272513,62660,95496,8328,64,64604,57796,45525,303572,1500,272393,257,21792,46213,74251]

theorem envBound11793 : H12AffineFastState.Bounded env11793 := by
  intro p hp
  have h : env11793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11792_11793 : H12AffineEnvironment.transform 16 38161 env11792 = env11793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11792 == env11793) = true)

theorem identity11793 : scanCanonicalize (H12AffineFastState.compose env11793 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11793 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env11794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,4161,272513,62660,21762,8328,64,64604,57796,45525,303572,1500,272393,257,21792,46213,513]

theorem envBound11794 : H12AffineFastState.Bounded env11794 := by
  intro p hp
  have h : env11794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11793_11794 : H12AffineEnvironment.transform 15 8202 env11793 = env11794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11793 == env11794) = true)

theorem identity11794 : scanCanonicalize (H12AffineFastState.compose env11794 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound11794 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env11795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,2421,1025,32769,4161,8692,62660,21762,8328,64,64604,57796,45525,43169,1500,8572,257,21792,46213,513]

theorem envBound11795 : H12AffineFastState.Bounded env11795 := by
  intro p hp
  have h : env11795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11794_11795 : H12AffineEnvironment.transform 17 2421 env11794 = env11795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env11794 == env11795) = true)

theorem identity11795 : scanCanonicalize (H12AffineFastState.compose env11795 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound11795 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8202,16401,2421,1025,21761,4161,8692,8644,21762,8328,64,10588,13508,25813,32161,1500,8572,257,21792,24965,513]

theorem envBound11796 : H12AffineFastState.Bounded env11796 := by
  intro p hp
  have h : env11796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11795_11796 : H12AffineEnvironment.transform 14 21760 env11795 = env11796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11795 == env11796) = true)

theorem identity11796 : scanCanonicalize (H12AffineFastState.compose env11796 (packedSelected [2,3,5,6,8,17,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11796 : packedSelected [2,3,5,6,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env11797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16401,2421,1025,21761,4161,8573,8525,21762,8193,64,10588,13389,25692,32040,1365,8572,257,21792,24844,513]

theorem envBound11797 : H12AffineFastState.Bounded env11797 := by
  intro p hp
  have h : env11797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11796_11797 : H12AffineEnvironment.transform 6 9 env11796 = env11797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11796 == env11797) = true)

theorem identity11797 : scanCanonicalize (H12AffineFastState.compose env11797 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound11797 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8461,8202,13340,2421,1025,8460,4161,8573,8525,8463,8193,64,10588,13389,4177,2341,1365,8572,257,8493,5377,513]

theorem envBound11798 : H12AffineFastState.Bounded env11798 := by
  intro p hp
  have h : env11798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11797_11798 : H12AffineEnvironment.transform 13 13325 env11797 = env11798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env11797 == env11798) = true)

theorem identity11798 : scanCanonicalize (H12AffineFastState.compose env11798 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11798 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,343,5441,2421,1025,81,4161,32,16,82,348,64,2049,5392,4177,2341,1365,33,257,112,5377,513]

theorem envBound11799 : H12AffineFastState.Bounded env11799 := by
  intro p hp
  have h : env11799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11798_11799 : H12AffineEnvironment.transform 12 349 env11798 = env11799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11798 == env11799) = true)

theorem identity11799 : scanCanonicalize (H12AffineFastState.compose env11799 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11800 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1025,0,4112,32,16,3,269,17,2049,5392,4096,2341,1284,33,257,33,5377,513]

theorem envBound11800 : H12AffineFastState.Bounded env11800 := by
  intro p hp
  have h : env11800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11799_11800 : H12AffineEnvironment.transform 5 17 env11799 = env11800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11799 == env11800) = true)

theorem identity11800 : scanCanonicalize (H12AffineFastState.compose env11800 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11801 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,268,4404,1,262,4389,2340,52,0,4112,32,16,3,269,17,2049,4389,4096,2341,305,33,257,33,4404,513]

theorem envBound11801 : H12AffineFastState.Bounded env11801 := by
  intro p hp
  have h : env11801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11800_11801 : H12AffineEnvironment.transform 9 53 env11800 = env11801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11800 == env11801) = true)

theorem identity11801 : scanCanonicalize (H12AffineFastState.compose env11801 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11801 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11802 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,1,35,4096,2049,52,0,4112,32,16,3,40,17,2049,4096,4096,2048,20,33,36,33,4113,513]

theorem envBound11802 : H12AffineFastState.Bounded env11802 := by
  intro p hp
  have h : env11802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11801_11802 : H12AffineEnvironment.transform 7 37 env11801 = env11802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11801 == env11802) = true)

theorem identity11802 : scanCanonicalize (H12AffineFastState.compose env11802 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound11802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11803 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2577,41,2560,1,35,2577,2049,52,0,2561,32,16,3,40,17,2049,2577,2577,2048,20,33,36,33,2560,513]

theorem envBound11803 : H12AffineFastState.Bounded env11803 := by
  intro p hp
  have h : env11803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11802_11803 : H12AffineEnvironment.transform 11 2577 env11802 = env11803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env11802 == env11803) = true)

theorem identity11803 : scanCanonicalize (H12AffineFastState.compose env11803 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound11803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11804 : List Nat := [2,4,8,16,32,17,9,37,512,53,59,554,41,571,1,35,554,58,52,0,570,32,16,3,40,17,58,554,554,59,20,33,36,33,571,513]

theorem envBound11804 : H12AffineFastState.Bounded env11804 := by
  intro p hp
  have h : env11804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11803_11804 : H12AffineEnvironment.transform 10 59 env11803 = env11804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env11803 == env11804) = true)

theorem identity11804 : scanCanonicalize (H12AffineFastState.compose env11804 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound11804 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11805 : List Nat := [2,4,8,16,26,17,9,31,512,15,1,528,19,513,1,25,528,0,14,0,512,26,16,3,18,17,0,528,528,1,20,27,30,27,513,513]

theorem envBound11805 : H12AffineFastState.Bounded env11805 := by
  intro p hp
  have h : env11805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11804_11805 : H12AffineEnvironment.transform 4 26 env11804 = env11805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env11804 == env11805) = true)

theorem identity11805 : scanCanonicalize (H12AffineFastState.compose env11805 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11805 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11806 : List Nat := [2,4,8,16,26,17,9,31,1,15,1,17,19,0,1,25,17,0,14,0,1,26,16,3,18,17,0,17,17,1,20,27,30,27,0,0]

theorem envBound11806 : H12AffineFastState.Bounded env11806 := by
  intro p hp
  have h : env11806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11805_11806 : H12AffineEnvironment.transform 8 1 env11805 = env11806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11805 == env11806) = true)

def env11807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257300,253977,8328,64,2157596,2253972,140484,2404757,2102685,2373705,257,21792,46213,2175562]

theorem envBound11807 : H12AffineFastState.Bounded env11807 := by
  intro p hp
  have h : env11807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11734_11807 : H12AffineEnvironment.transform 21 441745 env11734 = env11807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env11734 == env11807) = true)

def env11808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,253977,8328,64,64604,160980,140484,303573,1501,272393,257,21792,46213,74250]

theorem envBound11808 : H12AffineFastState.Bounded env11808 := by
  intro p hp
  have h : env11808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11807_11808 : H12AffineEnvironment.transform 20 4160 env11807 = env11808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11807 == env11808) = true)

theorem identity11808 : scanCanonicalize (H12AffineFastState.compose env11808 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound11808 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,318548,17,98780,8328,64,64604,5393,17665,303573,1501,272393,257,21792,46213,74250]

theorem envBound11809 : H12AffineFastState.Bounded env11809 := by
  intro p hp
  have h : env11809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11808_11809 : H12AffineEnvironment.transform 16 25029 env11808 = env11809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env11808 == env11809) = true)

def env11810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,318548,17,98644,8192,64,64604,5393,17665,303453,1365,272393,257,21792,46093,74250]

theorem envBound11810 : H12AffineFastState.Bounded env11810 := by
  intro p hp
  have h : env11810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11809_11810 : H12AffineEnvironment.transform 6 8 env11809 = env11810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11809 == env11810) = true)

theorem identity11810 : scanCanonicalize (H12AffineFastState.compose env11810 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound11810 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,108927,1025,32769,4160,95531,17,98644,8192,64,64604,5393,17665,67618,1365,98678,257,21792,46093,74250]

theorem envBound11811 : H12AffineFastState.Bounded env11811 := by
  intro p hp
  have h : env11811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11810_11811 : H12AffineEnvironment.transform 17 108927 env11810 = env11811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env11810 == env11811) = true)

theorem identity11811 : scanCanonicalize (H12AffineFastState.compose env11811 (packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11811 : packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env11812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,65536,16693,100615,1025,32769,4160,87379,17,98644,120,64,56356,5393,17665,67618,1365,98678,257,21792,38005,66162]

theorem envBound11812 : H12AffineFastState.Bounded env11812 := by
  intro p hp
  have h : env11812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11811_11812 : H12AffineEnvironment.transform 12 120 env11811 = env11812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11811 == env11812) = true)

theorem identity11812 : scanCanonicalize (H12AffineFastState.compose env11812 (packedSelected [1,2,3,5,6,7,8,9,10,11,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound11812 : packedSelected [1,2,3,5,6,7,8,9,10,11,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env11813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,35,16693,35108,1025,32769,4160,21872,17,33143,120,64,56356,5393,17665,2049,1365,33109,257,21792,38005,593]

theorem envBound11813 : H12AffineFastState.Bounded env11813 := by
  intro p hp
  have h : env11813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11812_11813 : H12AffineEnvironment.transform 15 35 env11812 = env11813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env11812 == env11813) = true)

theorem identity11813 : scanCanonicalize (H12AffineFastState.compose env11813 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound11813 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21840,35,16693,23668,1025,21841,4160,21872,17,21543,120,64,2420,5393,17665,2049,1365,21509,257,21792,16677,593]

theorem envBound11814 : H12AffineFastState.Bounded env11814 := by
  intro p hp
  have h : env11814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11813_11814 : H12AffineEnvironment.transform 14 21840 env11813 = env11814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env11813 == env11814) = true)

theorem identity11814 : scanCanonicalize (H12AffineFastState.compose env11814 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound11814 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env11815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,292,35,5441,2048,1025,293,4160,260,17,83,120,64,2420,5393,4469,2049,1365,113,257,340,5457,593]

theorem envBound11815 : H12AffineFastState.Bounded env11815 := by
  intro p hp
  have h : env11815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11814_11815 : H12AffineEnvironment.transform 13 5236 env11814 = env11815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env11814 == env11815) = true)

theorem identity11815 : scanCanonicalize (H12AffineFastState.compose env11815 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11815 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11816 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5236,81,35,5172,2048,1025,80,4160,113,17,83,120,64,2049,5220,4096,2049,1056,113,116,33,5156,593]

theorem envBound11816 : H12AffineFastState.Bounded env11816 := by
  intro p hp
  have h : env11816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11815_11816 : H12AffineEnvironment.transform 7 117 env11815 = env11816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11815 == env11816) = true)

theorem identity11816 : scanCanonicalize (H12AffineFastState.compose env11816 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11816 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11817 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4112,33,17,3,40,16,2049,5172,4096,2049,1056,33,36,33,5156,513]

theorem envBound11817 : H12AffineFastState.Bounded env11817 := by
  intro p hp
  have h : env11817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11816_11817 : H12AffineEnvironment.transform 5 16 env11816 = env11817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11816 == env11817) = true)

theorem identity11817 : scanCanonicalize (H12AffineFastState.compose env11817 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound11817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11818 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1044,1,35,1028,2048,1025,0,32,33,17,3,40,16,2049,1028,48,2049,1056,33,36,33,1044,513]

theorem envBound11818 : H12AffineFastState.Bounded env11818 := by
  intro p hp
  have h : env11818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11817_11818 : H12AffineEnvironment.transform 11 48 env11817 = env11818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env11817 == env11818) = true)

theorem identity11818 : scanCanonicalize (H12AffineFastState.compose env11818 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound11818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11819 : List Nat := [2,4,8,16,32,16,8,37,512,517,2048,48,40,529,1,35,513,2048,516,0,32,33,17,3,40,16,2049,513,48,2049,549,33,36,33,529,513]

theorem envBound11819 : H12AffineFastState.Bounded env11819 := by
  intro p hp
  have h : env11819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11818_11819 : H12AffineEnvironment.transform 9 517 env11818 = env11819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env11818 == env11819) = true)

theorem identity11819 : scanCanonicalize (H12AffineFastState.compose env11819 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound11819 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11820 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,48,40,32,1,35,48,2048,53,0,32,33,17,3,40,16,2049,48,48,2049,20,33,36,33,32,48]

theorem envBound11820 : H12AffineFastState.Bounded env11820 := by
  intro p hp
  have h : env11820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11819_11820 : H12AffineEnvironment.transform 8 49 env11819 = env11820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env11819 == env11820) = true)

theorem identity11820 : scanCanonicalize (H12AffineFastState.compose env11820 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11820 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11821 : List Nat := [2,4,8,16,17,16,8,20,0,5,2048,1,25,17,1,18,1,2048,4,0,17,16,17,3,25,16,2049,1,1,2049,20,16,21,16,17,1]

theorem envBound11821 : H12AffineFastState.Bounded env11821 := by
  intro p hp
  have h : env11821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11820_11821 : H12AffineEnvironment.transform 4 17 env11820 = env11821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11820 == env11821) = true)

theorem identity11821 : scanCanonicalize (H12AffineFastState.compose env11821 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11821 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11822 : List Nat := [2,4,8,16,17,16,8,20,0,5,1,1,25,17,1,18,1,1,4,0,17,16,17,3,25,16,0,1,1,0,20,16,21,16,17,1]

theorem envBound11822 : H12AffineFastState.Bounded env11822 := by
  intro p hp
  have h : env11822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11821_11822 : H12AffineEnvironment.transform 10 1 env11821 = env11822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11821 == env11822) = true)

theorem identity11822 : scanCanonicalize (H12AffineFastState.compose env11822 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11822 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11823 : List Nat := [2,4,8,1,0,1,8,5,0,5,1,1,8,0,1,3,1,1,4,0,0,1,0,3,8,1,0,1,1,0,5,1,4,1,0,1]

theorem envBound11823 : H12AffineFastState.Bounded env11823 := by
  intro p hp
  have h : env11823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11822_11823 : H12AffineEnvironment.transform 3 1 env11822 = env11823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11822 == env11823) = true)

def env11824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318548,17,98645,8193,64,64604,5393,17665,303452,1364,272393,257,21792,46092,74250]

theorem envBound11824 : H12AffineFastState.Bounded env11824 := by
  intro p hp
  have h : env11824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11809_11824 : H12AffineEnvironment.transform 6 9 env11809 = env11824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11809 == env11824) = true)

theorem identity11824 : scanCanonicalize (H12AffineFastState.compose env11824 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound11824 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67618,1025,32769,4160,119926,17,98645,8193,64,64604,5393,17665,108926,1364,73771,257,21792,46092,74250]

theorem envBound11825 : H12AffineFastState.Bounded env11825 := by
  intro p hp
  have h : env11825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11824_11825 : H12AffineEnvironment.transform 17 67618 env11824 = env11825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env11824 == env11825) = true)

theorem identity11825 : scanCanonicalize (H12AffineFastState.compose env11825 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound11825 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env11826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,64809,1025,32769,4160,8573,17,29790,8193,64,64604,5393,17665,23669,1364,54560,257,21792,46092,55041]

theorem envBound11826 : H12AffineFastState.Bounded env11826 := by
  intro p hp
  have h : env11826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11825_11826 : H12AffineEnvironment.transform 15 62731 env11825 = env11826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env11825 == env11826) = true)

theorem identity11826 : scanCanonicalize (H12AffineFastState.compose env11826 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11826 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,16400,56437,1025,32769,4160,33,17,21762,349,64,56576,5393,17665,23669,1364,54560,257,21792,38224,55041]

theorem envBound11827 : H12AffineFastState.Bounded env11827 := by
  intro p hp
  have h : env11827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11826_11827 : H12AffineEnvironment.transform 12 348 env11826 = env11827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11826 == env11827) = true)

theorem identity11827 : scanCanonicalize (H12AffineFastState.compose env11827 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11827 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env11828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21591,16400,23669,1025,1,4160,33,17,21762,349,64,23808,5393,17665,23669,1364,21792,257,21792,5456,22273]

theorem envBound11828 : H12AffineFastState.Bounded env11828 := by
  intro p hp
  have h : env11828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11827_11828 : H12AffineEnvironment.transform 14 0 env11827 = env11828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11827 == env11828) = true)

theorem identity11828 : scanCanonicalize (H12AffineFastState.compose env11828 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound11828 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env11829 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,9,16384,0,21591,16400,23669,1025,1,4160,33,17,21591,8,64,23637,5188,17492,23669,1025,21621,84,21621,5125,22100]

theorem envBound11829 : H12AffineFastState.Bounded env11829 := by
  intro p hp
  have h : env11829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11828_11829 : H12AffineEnvironment.transform 7 85 env11828 = env11829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env11828 == env11829) = true)

def env11830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,253977,8328,64,64605,160981,140484,303572,1500,272392,257,21792,46213,74251]

theorem envBound11830 : H12AffineFastState.Bounded env11830 := by
  intro p hp
  have h : env11830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11807_11830 : H12AffineEnvironment.transform 20 4161 env11807 = env11830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11807 == env11830) = true)

theorem identity11830 : scanCanonicalize (H12AffineFastState.compose env11830 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,411972,156117,201932,8328,64,2184,160981,140484,283905,1500,272392,257,21792,16464,74251]

theorem envBound11831 : H12AffineFastState.Bounded env11831 := by
  intro p hp
  have h : env11831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11830_11831 : H12AffineEnvironment.transform 14 29909 env11830 = env11831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11830 == env11831) = true)

def env11832 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,411924,156037,201884,8328,16,2184,160901,140436,283905,1420,272392,257,21792,16384,74251]

theorem envBound11832 : H12AffineFastState.Bounded env11832 := by
  intro p hp
  have h : env11832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11831_11832 : H12AffineEnvironment.transform 5 16 env11831 = env11832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11831 == env11832) = true)

theorem identity11832 : scanCanonicalize (H12AffineFastState.compose env11832 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound11832 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env11833 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,157753,1025,29828,4113,8493,156037,201884,8328,16,2184,160901,140436,146744,1420,147505,257,21792,16384,74251]

theorem envBound11833 : H12AffineFastState.Bounded env11833 := by
  intro p hp
  have h : env11833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11832_11833 : H12AffineEnvironment.transform 17 157753 env11832 = env11833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env11832 == env11833) = true)

theorem identity11833 : scanCanonicalize (H12AffineFastState.compose env11833 (packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound11833 : packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env11834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79250,89515,1025,29828,4113,8493,87063,8462,8328,16,2184,82199,69894,67754,1420,95651,257,21792,16384,74251]

theorem envBound11834 : H12AffineFastState.Bounded env11834 := by
  intro p hp
  have h : env11834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11833_11834 : H12AffineEnvironment.transform 16 79250 env11833 = env11834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env11833 == env11834) = true)

theorem identity11834 : scanCanonicalize (H12AffineFastState.compose env11834 (packedSelected [0,4,7,10,16,17,20,22,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11834 : packedSelected [0,4,7,10,16,17,20,22,31] rootPS < 2^1333 := by decide +kernel

def env11835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,79250,67755,1025,8580,4113,8493,65815,8462,8328,16,2184,70679,69894,67754,1420,73891,257,32,5376,74251]

theorem envBound11835 : H12AffineFastState.Bounded env11835 := by
  intro p hp
  have h : env11835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11834_11835 : H12AffineEnvironment.transform 13 5376 env11834 = env11835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11834 == env11835) = true)

theorem identity11835 : scanCanonicalize (H12AffineFastState.compose env11835 (packedSelected [0,2,4,6,7,9,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 5537) := by decide +kernel

theorem selectedBound11835 : packedSelected [0,2,4,6,7,9,12,16] rootPS < 2^1333 := by decide +kernel

def env11836 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5537,5376,5156,65536,65587,67755,1025,5157,4113,5260,65815,5295,5417,16,2184,70679,69894,67754,1420,70914,257,32,5376,71594]

theorem envBound11836 : H12AffineFastState.Bounded env11836 := by
  intro p hp
  have h : env11836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11835_11836 : H12AffineEnvironment.transform 12 5537 env11835 = env11836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5537 env11835 == env11836) = true)

theorem identity11836 : scanCanonicalize (H12AffineFastState.compose env11836 (packedSelected [1,2,6,8,10,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2311) := by decide +kernel

theorem selectedBound11836 : packedSelected [1,2,6,8,10,17,18] rootPS < 2^1333 := by decide +kernel

def env11837 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5537,5376,5156,2311,2356,428,1025,5157,4113,5260,2064,5295,5417,16,2184,7440,6145,429,1420,7173,257,32,5376,7853]

theorem envBound11837 : H12AffineFastState.Bounded env11837 := by
  intro p hp
  have h : env11837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11836_11837 : H12AffineEnvironment.transform 15 2311 env11836 = env11837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2311 env11836 == env11837) = true)

theorem identity11837 : scanCanonicalize (H12AffineFastState.compose env11837 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11837 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env11838 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,4501,4404,4112,2311,2356,428,53,4113,4113,4280,2064,4251,4381,16,2184,6436,6145,429,440,6193,257,32,4404,6809]

theorem envBound11838 : H12AffineFastState.Bounded env11838 := by
  intro p hp
  have h : env11838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11837_11838 : H12AffineEnvironment.transform 9 52 env11837 = env11838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11837 == env11838) = true)

theorem identity11838 : scanCanonicalize (H12AffineFastState.compose env11838 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound11838 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11839 : List Nat := [2,4,8,16,32,16,128,256,512,52,136,4096,4501,4404,4112,399,444,428,53,4113,4113,4280,152,4251,4381,16,0,4524,4233,429,440,4281,257,32,4404,4625]

theorem envBound11839 : H12AffineFastState.Bounded env11839 := by
  intro p hp
  have h : env11839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11838_11839 : H12AffineEnvironment.transform 10 136 env11838 = env11839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env11838 == env11839) = true)

def env11840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,411925,156036,201885,8328,17,2184,160900,140437,283905,1421,272392,257,21792,16385,74251]

theorem envBound11840 : H12AffineFastState.Bounded env11840 := by
  intro p hp
  have h : env11840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11831_11840 : H12AffineEnvironment.transform 5 17 env11831 = env11840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11831 == env11840) = true)

theorem identity11840 : scanCanonicalize (H12AffineFastState.compose env11840 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146865) := by decide +kernel

theorem selectedBound11840 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env11841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,146865,1025,29829,4112,29860,156036,201885,8328,17,2184,160900,140437,157872,1421,136633,257,21792,16385,74251]

theorem envBound11841 : H12AffineFastState.Bounded env11841 := by
  intro p hp
  have h : env11841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11840_11841 : H12AffineEnvironment.transform 17 146865 env11840 = env11841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env11840 == env11841) = true)

theorem identity11841 : scanCanonicalize (H12AffineFastState.compose env11841 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound11841 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env11842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,16401,32160,1025,29829,4112,29860,8597,87180,8328,17,2184,13461,25732,10401,1421,21928,257,21792,16385,74251]

theorem envBound11842 : H12AffineFastState.Bounded env11842 := by
  intro p hp
  have h : env11842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11841_11842 : H12AffineEnvironment.transform 16 16401 env11841 = env11842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env11841 == env11842) = true)

theorem identity11842 : scanCanonicalize (H12AffineFastState.compose env11842 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11842 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,16401,32160,1025,29829,4112,29860,8597,29830,8328,17,2184,13461,25732,10401,1421,21928,257,21792,16385,513]

theorem envBound11843 : H12AffineFastState.Bounded env11843 := by
  intro p hp
  have h : env11843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11842_11843 : H12AffineEnvironment.transform 15 8202 env11842 = env11843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11842 == env11843) = true)

theorem identity11843 : scanCanonicalize (H12AffineFastState.compose env11843 (packedSelected [0,4,7,9,10,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound11843 : packedSelected [0,4,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env11844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,8192,16384,28081,8202,16401,25749,1025,28080,2341,28049,8597,28083,8328,17,2184,11680,25732,10401,1421,19613,257,19477,16385,513]

theorem envBound11844 : H12AffineFastState.Bounded env11844 := by
  intro p hp
  have h : env11844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11843_11844 : H12AffineEnvironment.transform 11 2357 env11843 = env11844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env11843 == env11844) = true)

theorem identity11844 : scanCanonicalize (H12AffineFastState.compose env11844 (packedSelected [0,1,4,5,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound11844 : packedSelected [0,1,4,5,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env11845 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,8192,11577,136,8202,11560,2476,1025,137,2341,168,8597,138,8328,17,2184,11680,2493,10401,1421,8612,257,8492,11576,513]

theorem envBound11845 : H12AffineFastState.Bounded env11845 := by
  intro p hp
  have h : env11845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11844_11845 : H12AffineEnvironment.transform 13 11577 env11844 = env11845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env11844 == env11845) = true)

theorem identity11845 : scanCanonicalize (H12AffineFastState.compose env11845 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound11845 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env11846 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,389,3260,136,399,3245,2476,1025,137,2341,168,16,138,269,17,2184,3109,2493,2340,1421,33,257,169,3261,513]

theorem envBound11846 : H12AffineFastState.Bounded env11846 := by
  intro p hp
  have h : env11846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11845_11846 : H12AffineEnvironment.transform 12 389 env11845 = env11846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env11845 == env11846) = true)

theorem identity11846 : scanCanonicalize (H12AffineFastState.compose env11846 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11846 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11847 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2357,389,2476,136,399,2493,2476,273,137,2341,168,16,138,269,17,2184,2357,2493,2340,157,33,257,169,2477,513]

theorem envBound11847 : H12AffineFastState.Bounded env11847 := by
  intro p hp
  have h : env11847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11846_11847 : H12AffineEnvironment.transform 9 272 env11846 = env11847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11846 == env11847) = true)

theorem identity11847 : scanCanonicalize (H12AffineFastState.compose env11847 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound11847 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env11848 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,2200,40,2049,136,34,2064,2049,188,137,2184,168,16,138,160,17,2184,2200,2064,2185,157,33,172,169,2048,513]

theorem envBound11848 : H12AffineFastState.Bounded env11848 := by
  intro p hp
  have h : env11848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11847_11848 : H12AffineEnvironment.transform 7 173 env11847 = env11848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env11847 == env11848) = true)

theorem identity11848 : scanCanonicalize (H12AffineFastState.compose env11848 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11848 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11849 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,40,2049,0,34,2064,2049,52,1,2048,32,16,2,40,17,2048,2064,2064,2049,21,33,36,33,2048,513]

theorem envBound11849 : H12AffineFastState.Bounded env11849 := by
  intro p hp
  have h : env11849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11848_11849 : H12AffineEnvironment.transform 6 8 env11848 = env11849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11848 == env11849) = true)

theorem identity11849 : scanCanonicalize (H12AffineFastState.compose env11849 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11849 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11850 : List Nat := [2,4,8,16,32,17,8,37,1,53,2048,2064,40,2049,0,34,2064,2049,52,1,2048,32,16,2,40,17,2048,2064,2064,2049,21,33,36,33,2048,0]

theorem envBound11850 : H12AffineFastState.Bounded env11850 := by
  intro p hp
  have h : env11850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11849_11850 : H12AffineEnvironment.transform 8 1 env11849 = env11850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11849 == env11850) = true)

theorem identity11850 : scanCanonicalize (H12AffineFastState.compose env11850 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11851 : List Nat := [2,4,2,16,32,17,2,37,1,53,2048,2064,34,2049,0,34,2064,2049,52,1,2048,32,16,2,34,17,2048,2064,2064,2049,21,33,36,33,2048,0]

theorem envBound11851 : H12AffineFastState.Bounded env11851 := by
  intro p hp
  have h : env11851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11850_11851 : H12AffineEnvironment.transform 2 2 env11850 = env11851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11850 == env11851) = true)

theorem identity11851 : scanCanonicalize (H12AffineFastState.compose env11851 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11851 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11852 : List Nat := [2,4,2,16,32,17,2,37,1,53,0,16,34,1,0,34,16,1,52,1,0,32,16,2,34,17,0,16,16,1,21,33,36,33,0,0]

theorem envBound11852 : H12AffineFastState.Bounded env11852 := by
  intro p hp
  have h : env11852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11851_11852 : H12AffineEnvironment.transform 10 0 env11851 = env11852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11851 == env11852) = true)

def env11853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257301,253977,8328,64,6705548,2253972,140485,2404756,2102684,6456792,257,21793,46212,2175563]

theorem envBound11853 : H12AffineFastState.Bounded env11853 := by
  intro p hp
  have h : env11853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11733_11853 : H12AffineEnvironment.transform 22 2257301 env11733 = env11853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257301 env11733 == env11853) = true)

def env11854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257301,253977,8328,64,2157596,2253972,140485,2404756,2102684,2373704,257,21793,46212,2175563]

theorem envBound11854 : H12AffineFastState.Bounded env11854 := by
  intro p hp
  have h : env11854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11853_11854 : H12AffineEnvironment.transform 21 441744 env11853 = env11854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env11853 == env11854) = true)

def env11855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,253977,8328,64,64604,160980,140485,303572,1500,272392,257,21793,46212,74251]

theorem envBound11855 : H12AffineFastState.Bounded env11855 := by
  intro p hp
  have h : env11855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11854_11855 : H12AffineEnvironment.transform 20 4160 env11854 = env11855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11854 == env11855) = true)

theorem identity11855 : scanCanonicalize (H12AffineFastState.compose env11855 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound11855 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,441744,156117,144583,8328,64,64604,160980,140485,303572,1500,272392,257,21793,46212,63189]

theorem envBound11856 : H12AffineFastState.Bounded env11856 := by
  intro p hp
  have h : env11856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11855_11856 : H12AffineEnvironment.transform 15 54494 env11855 = env11856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env11855 == env11856) = true)

def env11857 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441744,156037,144535,8328,16,64524,160900,140437,303492,1420,272392,257,21793,46212,63109]

theorem envBound11857 : H12AffineFastState.Bounded env11857 := by
  intro p hp
  have h : env11857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11856_11857 : H12AffineEnvironment.transform 5 16 env11856 = env11857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11856 == env11857) = true)

theorem identity11857 : scanCanonicalize (H12AffineFastState.compose env11857 (packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 171197) := by decide +kernel

theorem selectedBound11857 : packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS < 2^1333 := by decide +kernel

def env11858 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,171197,1025,32769,4112,8493,156037,144535,8328,16,64524,160900,140437,146745,1420,177333,257,21793,46212,63109]

theorem envBound11858 : H12AffineFastState.Bounded env11858 := by
  intro p hp
  have h : env11858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11857_11858 : H12AffineEnvironment.transform 17 171197 env11857 = env11858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171197 env11857 == env11858) = true)

theorem identity11858 : scanCanonicalize (H12AffineFastState.compose env11858 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound11858 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env11859 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,5529,35108,1025,32769,4112,8493,29724,8462,8328,16,64524,24861,12556,10400,1420,41260,257,21793,46212,63109]

theorem envBound11859 : H12AffineFastState.Bounded env11859 := by
  intro p hp
  have h : env11859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11858_11859 : H12AffineEnvironment.transform 16 5529 env11858 = env11859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env11858 == env11859) = true)

theorem identity11859 : scanCanonicalize (H12AffineFastState.compose env11859 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound11859 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env11860 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8202,5529,32160,1025,29829,4112,8493,29724,8462,8328,16,2184,24861,12556,10400,1420,21928,257,21793,16384,513]

theorem envBound11860 : H12AffineFastState.Bounded env11860 := by
  intro p hp
  have h : env11860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11859_11860 : H12AffineEnvironment.transform 14 29828 env11859 = env11860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env11859 == env11860) = true)

theorem identity11860 : scanCanonicalize (H12AffineFastState.compose env11860 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11860 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11861 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,8202,5529,10400,1025,8581,4112,8493,8476,8462,8328,16,2184,13341,12556,10400,1420,168,257,33,5376,513]

theorem envBound11861 : H12AffineFastState.Bounded env11861 := by
  intro p hp
  have h : env11861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11860_11861 : H12AffineEnvironment.transform 13 5376 env11860 = env11861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11860 == env11861) = true)

theorem identity11861 : scanCanonicalize (H12AffineFastState.compose env11861 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound11861 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env11862 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3244,8192,2476,8580,8202,2357,10400,1025,8581,3260,8493,8476,8462,8328,16,2184,10417,11680,10400,1420,168,257,33,2476,513]

theorem envBound11862 : H12AffineFastState.Bounded env11862 := by
  intro p hp
  have h : env11862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11861_11862 : H12AffineEnvironment.transform 11 3244 env11861 = env11862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env11861 == env11862) = true)

theorem identity11862 : scanCanonicalize (H12AffineFastState.compose env11862 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11862 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env11863 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,8192,2340,8460,8202,2357,10280,1025,8461,3124,8493,8476,8462,8192,16,2048,10297,11560,10280,1284,32,257,33,2340,513]

theorem envBound11863 : H12AffineFastState.Bounded env11863 := by
  intro p hp
  have h : env11863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11862_11863 : H12AffineEnvironment.transform 6 8 env11862 = env11863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11862 == env11863) = true)

theorem identity11863 : scanCanonicalize (H12AffineFastState.compose env11863 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound11863 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11864 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,1052,2340,1296,1046,2357,3124,1025,1297,3124,1329,1280,1298,1052,16,2048,3109,2356,3124,1284,32,257,33,2340,513]

theorem envBound11864 : H12AffineFastState.Bounded env11864 := by
  intro p hp
  have h : env11864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11863_11864 : H12AffineEnvironment.transform 12 1052 env11863 = env11864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env11863 == env11864) = true)

theorem identity11864 : scanCanonicalize (H12AffineFastState.compose env11864 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11864 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11865 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2356,268,2340,0,262,2357,2340,273,1,2340,33,16,2,268,16,2048,2357,2356,2340,20,32,257,33,2340,513]

theorem envBound11865 : H12AffineFastState.Bounded env11865 := by
  intro p hp
  have h : env11865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11864_11865 : H12AffineEnvironment.transform 9 272 env11864 = env11865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11864 == env11865) = true)

theorem identity11865 : scanCanonicalize (H12AffineFastState.compose env11865 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11865 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11866 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,40,2048,0,34,2065,2048,53,1,2048,33,16,2,40,16,2048,2065,2064,2048,20,32,37,33,2048,513]

theorem envBound11866 : H12AffineFastState.Bounded env11866 := by
  intro p hp
  have h : env11866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11865_11866 : H12AffineEnvironment.transform 7 36 env11865 = env11866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11865 == env11866) = true)

theorem identity11866 : scanCanonicalize (H12AffineFastState.compose env11866 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound11866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11867 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,40,48,0,34,33,48,53,1,48,33,16,2,40,16,48,33,32,48,20,32,37,33,48,513]

theorem envBound11867 : H12AffineFastState.Bounded env11867 := by
  intro p hp
  have h : env11867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11866_11867 : H12AffineEnvironment.transform 10 48 env11866 = env11867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env11866 == env11867) = true)

theorem identity11867 : scanCanonicalize (H12AffineFastState.compose env11867 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound11867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11868 : List Nat := [2,4,8,16,32,16,8,36,48,52,48,32,40,48,0,34,33,48,53,1,48,33,16,2,40,16,48,33,32,48,20,32,37,33,48,49]

theorem envBound11868 : H12AffineFastState.Bounded env11868 := by
  intro p hp
  have h : env11868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11867_11868 : H12AffineEnvironment.transform 8 48 env11867 = env11868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env11867 == env11868) = true)

def env11869 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441744,156036,144534,8328,17,64525,160901,140436,303493,1421,272392,257,21793,46212,63108]

theorem envBound11869 : H12AffineFastState.Bounded env11869 := by
  intro p hp
  have h : env11869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11856_11869 : H12AffineEnvironment.transform 5 17 env11856 = env11869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11856 == env11869) = true)

theorem identity11869 : scanCanonicalize (H12AffineFastState.compose env11869 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11869 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env11870 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33031,131072,262144,1025,32769,4113,441744,144396,144534,8328,17,43397,139533,140436,303493,1421,272392,257,169,46212,41740]

theorem envBound11870 : H12AffineFastState.Bounded env11870 := by
  intro p hp
  have h : env11870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11869_11870 : H12AffineEnvironment.transform 13 5512 env11869 = env11870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11869 == env11870) = true)

theorem identity11870 : scanCanonicalize (H12AffineFastState.compose env11870 (packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound11870 : packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env11871 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33031,131072,35108,1025,32769,4113,144564,144396,144534,8328,17,43397,139533,140436,10401,1421,41260,257,169,46212,41740]

theorem envBound11871 : H12AffineFastState.Bounded env11871 := by
  intro p hp
  have h : env11871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11870_11871 : H12AffineEnvironment.transform 17 35108 env11870 = env11871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env11870 == env11871) = true)

theorem identity11871 : scanCanonicalize (H12AffineFastState.compose env11871 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11871 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env11872 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,33031,131072,35108,1025,32769,4113,144444,144396,144414,8192,17,43277,139533,140316,10281,1285,41260,257,33,46092,41740]

theorem envBound11872 : H12AffineFastState.Bounded env11872 := by
  intro p hp
  have h : env11872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11871_11872 : H12AffineEnvironment.transform 6 8 env11871 = env11872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11871 == env11872) = true)

theorem identity11872 : scanCanonicalize (H12AffineFastState.compose env11872 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 13609) := by decide +kernel

theorem selectedBound11872 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env11873 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,13609,13358,131072,15373,1025,13608,4113,144444,144396,144414,8192,17,7204,139533,140316,10281,1285,5125,257,33,293,5669]

theorem envBound11873 : H12AffineFastState.Bounded env11873 := by
  intro p hp
  have h : env11873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11872_11873 : H12AffineEnvironment.transform 14 13609 env11872 = env11873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13609 env11872 == env11873) = true)

theorem identity11873 : scanCanonicalize (H12AffineFastState.compose env11873 (packedSelected [0,2,3,4,5,6,7,9,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 10297) := by decide +kernel

theorem selectedBound11873 : packedSelected [0,2,3,4,5,6,7,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env11874 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,13609,13358,10297,15373,1025,13608,4113,7173,7221,7207,8192,17,7204,2356,3109,10281,1285,5125,257,33,293,5669]

theorem envBound11874 : H12AffineFastState.Bounded env11874 := by
  intro p hp
  have h : env11874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11873_11874 : H12AffineEnvironment.transform 16 10297 env11873 = env11874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10297 env11873 == env11874) = true)

theorem identity11874 : scanCanonicalize (H12AffineFastState.compose env11874 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11874 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env11875 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,8192,5376,13609,13358,8249,13325,1025,13608,4113,5125,5173,5159,8192,17,5156,308,1061,8233,1285,5125,257,33,293,5669]

theorem envBound11875 : H12AffineFastState.Bounded env11875 := by
  intro p hp
  have h : env11875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11874_11875 : H12AffineEnvironment.transform 10 0 env11874 = env11875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11874 == env11875) = true)

theorem identity11875 : scanCanonicalize (H12AffineFastState.compose env11875 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound11875 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env11876 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,276,8192,1044,9277,9530,8249,9497,1025,9276,261,1297,1313,1331,8192,17,1328,308,1061,8233,1285,1297,257,33,293,1841]

theorem envBound11876 : H12AffineFastState.Bounded env11876 := by
  intro p hp
  have h : env11876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11875_11876 : H12AffineEnvironment.transform 11 276 env11875 = env11876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env11875 == env11876) = true)

theorem identity11876 : scanCanonicalize (H12AffineFastState.compose env11876 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound11876 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env11877 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,276,1084,1044,1,262,1029,293,1025,0,261,1297,1313,1331,1084,17,1328,308,1061,1045,1285,1297,257,33,293,1841]

theorem envBound11877 : H12AffineFastState.Bounded env11877 := by
  intro p hp
  have h : env11877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11876_11877 : H12AffineEnvironment.transform 12 1084 env11876 = env11877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env11876 == env11877) = true)

theorem identity11877 : scanCanonicalize (H12AffineFastState.compose env11877 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound11877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11878 : List Nat := [2,4,8,16,32,17,8,256,512,4,0,276,56,16,1,262,1,293,5,0,261,277,293,311,56,17,308,308,33,17,257,277,257,33,293,821]

theorem envBound11878 : H12AffineFastState.Bounded env11878 := by
  intro p hp
  have h : env11878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11877_11878 : H12AffineEnvironment.transform 9 4 env11877 = env11878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env11877 == env11878) = true)

theorem identity11878 : scanCanonicalize (H12AffineFastState.compose env11878 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11878 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env11879 : List Nat := [2,4,8,16,16,17,8,256,512,4,0,276,8,16,1,262,1,277,5,0,261,277,277,263,8,17,260,260,17,17,257,277,257,17,277,773]

theorem envBound11879 : H12AffineFastState.Bounded env11879 := by
  intro p hp
  have h : env11879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11878_11879 : H12AffineEnvironment.transform 4 16 env11878 = env11879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11878 == env11879) = true)

theorem identity11879 : scanCanonicalize (H12AffineFastState.compose env11879 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound11879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11880 : List Nat := [2,4,8,16,16,17,8,256,17,4,0,276,8,16,1,262,1,277,5,0,261,277,277,263,8,17,260,260,17,17,257,277,257,17,277,276]

theorem envBound11880 : H12AffineFastState.Bounded env11880 := by
  intro p hp
  have h : env11880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11879_11880 : H12AffineEnvironment.transform 8 17 env11879 = env11880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env11879 == env11880) = true)

theorem identity11880 : scanCanonicalize (H12AffineFastState.compose env11880 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11881 : List Nat := [2,4,8,1,1,0,8,256,0,4,0,261,8,1,1,262,1,260,5,0,261,260,260,263,8,0,260,260,0,0,257,260,257,0,260,261]

theorem envBound11881 : H12AffineFastState.Bounded env11881 := by
  intro p hp
  have h : env11881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11880_11881 : H12AffineEnvironment.transform 3 1 env11880 = env11881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11880 == env11881) = true)

theorem identity11881 : scanCanonicalize (H12AffineFastState.compose env11881 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11881 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11882 : List Nat := [2,4,8,1,1,0,8,5,0,4,0,0,8,1,1,3,1,1,5,0,0,1,1,2,8,0,1,1,0,0,4,1,4,0,1,0]

theorem envBound11882 : H12AffineFastState.Bounded env11882 := by
  intro p hp
  have h : env11882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11881_11882 : H12AffineEnvironment.transform 7 5 env11881 = env11882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11881 == env11882) = true)

theorem identity11882 : scanCanonicalize (H12AffineFastState.compose env11882 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound11882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11883 : List Nat := [2,1,8,1,1,0,8,0,0,1,0,0,8,1,1,3,1,1,0,0,0,1,1,2,8,0,1,1,0,0,1,1,1,0,1,0]

theorem envBound11883 : H12AffineFastState.Bounded env11883 := by
  intro p hp
  have h : env11883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11882_11883 : H12AffineEnvironment.transform 1 1 env11882 = env11883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env11882 == env11883) = true)

def env11884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,253977,8328,64,64605,160981,140485,303573,1501,272393,257,21793,46212,74250]

theorem envBound11884 : H12AffineFastState.Bounded env11884 := by
  intro p hp
  have h : env11884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11854_11884 : H12AffineEnvironment.transform 20 4161 env11854 = env11884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11854 == env11884) = true)

theorem identity11884 : scanCanonicalize (H12AffineFastState.compose env11884 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound11884 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4161,392286,73754,41431,8328,64,64605,79131,91403,303573,1501,272393,257,21793,46212,74250]

theorem envBound11885 : H12AffineFastState.Bounded env11885 := by
  intro p hp
  have h : env11885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11884_11885 : H12AffineEnvironment.transform 16 82382 env11884 = env11885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env11884 == env11885) = true)

def env11886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4161,392286,73754,41311,8192,64,64605,79131,91403,303453,1365,272393,257,21793,46092,74250]

theorem envBound11886 : H12AffineFastState.Bounded env11886 := by
  intro p hp
  have h : env11886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11885_11886 : H12AffineEnvironment.transform 6 8 env11885 = env11886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11885 == env11886) = true)

theorem identity11886 : scanCanonicalize (H12AffineFastState.compose env11886 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound11886 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env11887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29743,13673,262144,1025,32769,4161,297073,21557,41311,8192,64,64605,16692,4388,303453,1365,272393,257,21793,46092,22053]

theorem envBound11887 : H12AffineFastState.Bounded env11887 := by
  intro p hp
  have h : env11887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11886_11887 : H12AffineEnvironment.transform 15 29743 env11886 = env11887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env11886 == env11887) = true)

theorem identity11887 : scanCanonicalize (H12AffineFastState.compose env11887 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound11887 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env11888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,29743,13673,262144,1025,21760,4161,286064,21557,29790,8192,64,10588,16692,4388,291932,1365,272393,257,21793,24845,22053]

theorem envBound11888 : H12AffineFastState.Bounded env11888 := by
  intro p hp
  have h : env11888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11887_11888 : H12AffineEnvironment.transform 14 21761 env11887 = env11888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11887 == env11888) = true)

theorem identity11888 : scanCanonicalize (H12AffineFastState.compose env11888 (packedSelected [2,3,4,6,8,11,12,15,16,18,19,22,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound11888 : packedSelected [2,3,4,6,8,11,12,15,16,18,19,22,24,28] rootPS < 2^1333 := by decide +kernel

def env11889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,29743,13673,2049,1025,21760,4161,21873,21557,29790,8192,64,10588,16692,4388,31837,1365,8200,257,21793,24845,22053]

theorem envBound11889 : H12AffineFastState.Bounded env11889 := by
  intro p hp
  have h : env11889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11888_11889 : H12AffineEnvironment.transform 17 2049 env11888 = env11889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env11888 == env11889) = true)

theorem identity11889 : scanCanonicalize (H12AffineFastState.compose env11889 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11889 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env11890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21761,21591,5393,2049,1025,21760,4161,21873,21557,21542,120,64,2340,16692,4388,23589,1365,112,257,21793,16757,22053]

theorem envBound11890 : H12AffineFastState.Bounded env11890 := by
  intro p hp
  have h : env11890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11889_11890 : H12AffineEnvironment.transform 12 120 env11889 = env11890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11889 == env11890) = true)

theorem identity11890 : scanCanonicalize (H12AffineFastState.compose env11890 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound11890 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env11891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5156,293,115,5393,2049,1025,292,4161,341,17,2,120,64,2340,5392,4388,2049,1365,112,257,261,5457,513]

theorem envBound11891 : H12AffineFastState.Bounded env11891 := by
  intro p hp
  have h : env11891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11890_11891 : H12AffineEnvironment.transform 13 5156 env11890 = env11891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env11890 == env11891) = true)

theorem identity11891 : scanCanonicalize (H12AffineFastState.compose env11891 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound11891 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11892 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,4161,293,115,4468,2049,100,292,4161,341,17,2,120,64,2340,4469,4388,2049,304,112,257,261,4404,513]

theorem envBound11892 : H12AffineFastState.Bounded env11892 := by
  intro p hp
  have h : env11892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11891_11892 : H12AffineEnvironment.transform 9 101 env11891 = env11892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env11891 == env11892) = true)

theorem identity11892 : scanCanonicalize (H12AffineFastState.compose env11892 (packedSelected [1,4,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound11892 : packedSelected [1,4,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env11893 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,112,120,49,293,115,260,2049,100,292,49,341,17,2,120,64,2340,261,340,2049,304,112,257,261,324,513]

theorem envBound11893 : H12AffineFastState.Bounded env11893 := by
  intro p hp
  have h : env11893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11892_11893 : H12AffineEnvironment.transform 11 112 env11892 = env11893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env11892 == env11893) = true)

theorem identity11893 : scanCanonicalize (H12AffineFastState.compose env11893 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound11893 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11894 : List Nat := [2,4,8,16,32,64,8,52,512,101,2048,112,120,49,17,115,48,2049,100,16,49,97,17,2,120,64,2064,49,96,2049,4,112,53,49,112,513]

theorem envBound11894 : H12AffineFastState.Bounded env11894 := by
  intro p hp
  have h : env11894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11893_11894 : H12AffineEnvironment.transform 7 52 env11893 = env11894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env11893 == env11894) = true)

theorem identity11894 : scanCanonicalize (H12AffineFastState.compose env11894 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound11894 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env11895 : List Nat := [2,4,8,16,32,64,8,52,512,101,16,112,120,49,17,115,48,17,100,16,49,97,17,2,120,64,0,49,96,17,4,112,53,49,112,513]

theorem envBound11895 : H12AffineFastState.Bounded env11895 := by
  intro p hp
  have h : env11895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11894_11895 : H12AffineEnvironment.transform 10 16 env11894 = env11895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env11894 == env11895) = true)

theorem identity11895 : scanCanonicalize (H12AffineFastState.compose env11895 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11895 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11896 : List Nat := [2,4,8,0,32,64,8,36,512,101,0,96,104,33,1,99,32,1,100,0,33,97,1,2,104,64,0,33,96,1,4,96,37,33,96,513]

theorem envBound11896 : H12AffineFastState.Bounded env11896 := by
  intro p hp
  have h : env11896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11895_11896 : H12AffineEnvironment.transform 3 0 env11895 = env11896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11895 == env11896) = true)

def env11897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,392286,73754,41310,8193,64,64605,79131,91403,303452,1364,272393,257,21793,46093,74250]

theorem envBound11897 : H12AffineFastState.Bounded env11897 := by
  intro p hp
  have h : env11897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11885_11897 : H12AffineEnvironment.transform 6 9 env11885 = env11897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11885 == env11897) = true)

theorem identity11897 : scanCanonicalize (H12AffineFastState.compose env11897 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound11897 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env11898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,79130,262144,1025,32769,4161,362499,73754,41310,8193,64,34816,79131,69974,303452,1364,272393,257,8572,46093,74250]

theorem envBound11898 : H12AffineFastState.Bounded env11898 := by
  intro p hp
  have h : env11898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11897_11898 : H12AffineEnvironment.transform 13 13405 env11897 = env11898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env11897 == env11898) = true)

theorem identity11898 : scanCanonicalize (H12AffineFastState.compose env11898 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11898 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env11899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,65536,70727,262144,1025,32769,4161,362499,65863,32771,348,64,34816,70726,69974,294913,1364,264532,257,33,38224,66391]

theorem envBound11899 : H12AffineFastState.Bounded env11899 := by
  intro p hp
  have h : env11899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11898_11899 : H12AffineEnvironment.transform 12 349 env11898 = env11899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11898 == env11899) = true)

theorem identity11899 : scanCanonicalize (H12AffineFastState.compose env11899 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound11899 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env11900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,65536,70727,67618,1025,32769,4161,32801,65863,32771,348,64,34816,70726,69974,100387,1364,65910,257,33,38224,66391]

theorem envBound11900 : H12AffineFastState.Bounded env11900 := by
  intro p hp
  have h : env11900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11899_11900 : H12AffineEnvironment.transform 17 67618 env11899 = env11900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env11899 == env11900) = true)

theorem identity11900 : scanCanonicalize (H12AffineFastState.compose env11900 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound11900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,342,5393,2420,1025,32769,4161,32801,17,32771,348,64,34816,5392,4096,35189,1364,32,257,33,38224,513]

theorem envBound11901 : H12AffineFastState.Bounded env11901 := by
  intro p hp
  have h : env11901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11900_11901 : H12AffineEnvironment.transform 15 342 env11900 = env11901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env11900 == env11901) = true)

theorem identity11901 : scanCanonicalize (H12AffineFastState.compose env11901 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11901 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1025,0,4161,32,17,2,348,64,2049,5392,4096,2420,1364,32,257,33,5457,513]

theorem envBound11902 : H12AffineFastState.Bounded env11902 := by
  intro p hp
  have h : env11902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11901_11902 : H12AffineEnvironment.transform 14 1 env11901 = env11902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11901 == env11902) = true)

theorem identity11902 : scanCanonicalize (H12AffineFastState.compose env11902 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound11902 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3118,349,2350,1,342,2367,2420,1025,0,3183,32,17,2,348,64,2049,2366,3118,2420,1364,32,257,33,2431,513]

theorem envBound11903 : H12AffineFastState.Bounded env11903 := by
  intro p hp
  have h : env11903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11902_11903 : H12AffineEnvironment.transform 11 3118 env11902 = env11903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env11902 == env11903) = true)

theorem identity11903 : scanCanonicalize (H12AffineFastState.compose env11903 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound11903 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11904 : List Nat := [2,4,8,16,32,64,9,256,512,46,2048,2048,349,2350,1,342,2367,2420,47,0,2113,32,17,2,348,64,2049,2366,2048,2420,378,32,257,33,2431,513]

theorem envBound11904 : H12AffineFastState.Bounded env11904 := by
  intro p hp
  have h : env11904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11903_11904 : H12AffineEnvironment.transform 9 46 env11903 = env11904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env11903 == env11904) = true)

def env11905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257301,253977,8328,64,2157597,2253972,140485,2404756,2102684,2373705,257,21793,46212,2175563]

theorem envBound11905 : H12AffineFastState.Bounded env11905 := by
  intro p hp
  have h : env11905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11853_11905 : H12AffineEnvironment.transform 21 441745 env11853 = env11905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env11853 == env11905) = true)

def env11906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,253977,8328,64,64605,160980,140485,303572,1500,272393,257,21793,46212,74251]

theorem envBound11906 : H12AffineFastState.Bounded env11906 := by
  intro p hp
  have h : env11906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11905_11906 : H12AffineEnvironment.transform 20 4160 env11905 = env11906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env11905 == env11906) = true)

theorem identity11906 : scanCanonicalize (H12AffineFastState.compose env11906 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound11906 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,4160,329867,120015,21763,8328,64,64605,115150,102879,303572,1500,272393,257,21793,46212,74251]

theorem envBound11907 : H12AffineFastState.Bounded env11907 := by
  intro p hp
  have h : env11907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11906_11907 : H12AffineEnvironment.transform 16 111898 env11906 = env11907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env11906 == env11907) = true)

def env11908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,4160,73771,120015,21763,8328,64,64605,115150,102879,35188,1500,169,257,21793,46212,74251]

theorem envBound11908 : H12AffineFastState.Bounded env11908 := by
  intro p hp
  have h : env11908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11907_11908 : H12AffineEnvironment.transform 17 10400 env11907 = env11908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11907 == env11908) = true)

def env11909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,73771,119879,21763,8192,64,64605,115014,102743,35188,1364,33,257,21793,46092,74251]

theorem envBound11909 : H12AffineFastState.Bounded env11909 := by
  intro p hp
  have h : env11909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11908_11909 : H12AffineEnvironment.transform 6 8 env11908 = env11909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11908 == env11909) = true)

theorem identity11909 : scanCanonicalize (H12AffineFastState.compose env11909 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound11909 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,13388,10280,1025,32769,4160,41341,21777,21763,8192,64,64605,16400,4097,35188,1364,33,257,21793,46092,41821]

theorem envBound11910 : H12AffineFastState.Bounded env11910 := by
  intro p hp
  have h : env11910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11909_11910 : H12AffineEnvironment.transform 15 33110 env11909 = env11910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env11909 == env11910) = true)

theorem identity11910 : scanCanonicalize (H12AffineFastState.compose env11910 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound11910 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env11911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,13388,10280,1025,8540,4160,32,21777,21763,8192,64,23808,16400,4097,10281,1364,33,257,21793,5457,512]

theorem envBound11911 : H12AffineFastState.Bounded env11911 := by
  intro p hp
  have h : env11911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11910_11911 : H12AffineEnvironment.transform 14 8541 env11910 = env11911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env11910 == env11911) = true)

theorem identity11911 : scanCanonicalize (H12AffineFastState.compose env11911 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 15405) := by decide +kernel

theorem selectedBound11911 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15405,8541,8203,13388,10280,1025,8540,4160,32,10556,10542,8192,64,8493,15421,4097,10281,1364,33,257,10508,5457,512]

theorem envBound11912 : H12AffineFastState.Bounded env11912 := by
  intro p hp
  have h : env11912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11911_11912 : H12AffineEnvironment.transform 13 15405 env11911 = env11912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15405 env11911 == env11912) = true)

theorem identity11912 : scanCanonicalize (H12AffineFastState.compose env11912 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6461) := by decide +kernel

theorem selectedBound11912 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6461,1296,6240,6454,3441,4373,1025,6241,4160,32,4097,4115,6461,64,6160,1280,4097,4372,1364,33,257,4145,5457,512]

theorem envBound11913 : H12AffineFastState.Bounded env11913 := by
  intro p hp
  have h : env11913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11912_11913 : H12AffineEnvironment.transform 12 6461 env11912 = env11913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6461 env11912 == env11913) = true)

theorem identity11913 : scanCanonicalize (H12AffineFastState.compose env11913 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound11913 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,4121,1296,4420,4114,1109,4373,1025,4421,4160,32,4097,4115,4121,64,4404,1280,4097,4372,1364,33,257,4145,5457,512]

theorem envBound11914 : H12AffineFastState.Bounded env11914 := by
  intro p hp
  have h : env11914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11913_11914 : H12AffineEnvironment.transform 10 292 env11913 = env11914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env11913 == env11914) = true)

theorem identity11914 : scanCanonicalize (H12AffineFastState.compose env11914 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound11914 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,356,381,1296,32,374,1109,113,1025,33,292,32,357,375,381,64,80,1280,357,112,1364,33,257,341,1077,512]

theorem envBound11915 : H12AffineFastState.Bounded env11915 := by
  intro p hp
  have h : env11915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11914_11915 : H12AffineEnvironment.transform 11 356 env11914 = env11915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env11914 == env11915) = true)

theorem identity11915 : scanCanonicalize (H12AffineFastState.compose env11915 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11915 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11916 : List Nat := [2,4,8,16,32,16,8,256,512,1024,292,308,301,1296,32,294,1029,33,1025,33,292,32,309,295,301,16,0,1280,309,32,1284,33,257,261,1077,512]

theorem envBound11916 : H12AffineFastState.Bounded env11916 := by
  intro p hp
  have h : env11916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11915_11916 : H12AffineEnvironment.transform 5 16 env11915 = env11916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11915 == env11916) = true)

def env11917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4160,73771,119878,21763,8193,64,64605,115015,102742,35188,1365,32,257,21793,46093,74251]

theorem envBound11917 : H12AffineFastState.Bounded env11917 := by
  intro p hp
  have h : env11917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11908_11917 : H12AffineEnvironment.transform 6 9 env11908 = env11917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11908 == env11917) = true)

theorem identity11917 : scanCanonicalize (H12AffineFastState.compose env11917 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11917 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4160,33,62540,21763,8193,64,64605,57677,45404,35188,1365,32,257,21793,46093,513]

theorem envBound11918 : H12AffineFastState.Bounded env11918 := by
  intro p hp
  have h : env11918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11917_11918 : H12AffineEnvironment.transform 15 8202 env11917 = env11918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11917 == env11918) = true)

theorem identity11918 : scanCanonicalize (H12AffineFastState.compose env11918 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11918 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env11919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,38160,2420,1025,32769,4160,33,54545,21763,348,64,56576,49168,36865,35188,1365,32,257,21793,38224,513]

theorem envBound11919 : H12AffineFastState.Bounded env11919 := by
  intro p hp
  have h : env11919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11918_11919 : H12AffineEnvironment.transform 12 349 env11918 = env11919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11918 == env11919) = true)

theorem identity11919 : scanCanonicalize (H12AffineFastState.compose env11919 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound11919 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16400,2420,1025,21761,4160,33,17,21763,348,64,2048,5392,17665,23668,1365,32,257,21793,16464,513]

theorem envBound11920 : H12AffineFastState.Bounded env11920 := by
  intro p hp
  have h : env11920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11919_11920 : H12AffineEnvironment.transform 14 21760 env11919 = env11920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11919 == env11920) = true)

theorem identity11920 : scanCanonicalize (H12AffineFastState.compose env11920 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11921 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,263,16400,2340,1025,21761,4112,33,17,21763,268,16,2048,5392,17665,23588,1285,32,257,21793,16384,513]

theorem envBound11921 : H12AffineFastState.Bounded env11921 := by
  intro p hp
  have h : env11921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11920_11921 : H12AffineEnvironment.transform 5 16 env11920 = env11921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11920 == env11921) = true)

theorem identity11921 : scanCanonicalize (H12AffineFastState.compose env11921 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound11921 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11922 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,2048,7424,263,2064,2340,1025,7425,4112,33,17,7427,268,16,2048,5392,3329,5156,1285,32,257,7457,2048,513]

theorem envBound11922 : H12AffineFastState.Bounded env11922 := by
  intro p hp
  have h : env11922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11921_11922 : H12AffineEnvironment.transform 13 2048 env11921 = env11922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env11921 == env11922) = true)

theorem identity11922 : scanCanonicalize (H12AffineFastState.compose env11922 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound11922 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env11923 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1818,4096,269,1818,4634,263,1802,1598,1025,4635,4112,33,17,4633,268,16,1818,5392,539,5156,1285,32,257,4667,1818,513]

theorem envBound11923 : H12AffineFastState.Bounded env11923 := by
  intro p hp
  have h : env11923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11922_11923 : H12AffineEnvironment.transform 10 1818 env11922 = env11923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env11922 == env11923) = true)

theorem identity11923 : scanCanonicalize (H12AffineFastState.compose env11923 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11923 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env11924 : List Nat := [2,4,8,16,32,16,9,256,512,52,814,4096,269,814,4634,263,830,522,53,4635,4112,33,17,4633,268,16,814,4388,539,4112,305,32,257,4667,814,513]

theorem envBound11924 : H12AffineFastState.Bounded env11924 := by
  intro p hp
  have h : env11924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11923_11924 : H12AffineEnvironment.transform 9 52 env11923 = env11924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11923 == env11924) = true)

theorem identity11924 : scanCanonicalize (H12AffineFastState.compose env11924 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 831) := by decide +kernel

theorem selectedBound11924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11925 : List Nat := [2,4,8,16,32,16,9,256,512,52,814,831,269,814,293,263,830,522,53,292,815,33,17,294,268,16,814,539,539,815,305,32,257,260,814,513]

theorem envBound11925 : H12AffineFastState.Bounded env11925 := by
  intro p hp
  have h : env11925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11924_11925 : H12AffineEnvironment.transform 11 831 env11924 = env11925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 831 env11924 == env11925) = true)

theorem identity11925 : scanCanonicalize (H12AffineFastState.compose env11925 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11925 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11926 : List Nat := [2,4,8,16,32,16,9,256,43,52,261,276,269,261,293,263,277,33,53,292,260,33,17,294,268,16,261,48,48,260,305,32,257,260,261,42]

theorem envBound11926 : H12AffineFastState.Bounded env11926 := by
  intro p hp
  have h : env11926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11925_11926 : H12AffineEnvironment.transform 8 43 env11925 = env11926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11925 == env11926) = true)

theorem identity11926 : scanCanonicalize (H12AffineFastState.compose env11926 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound11926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11927 : List Nat := [2,4,8,16,32,16,9,7,43,52,2,19,10,2,34,0,18,33,53,35,3,33,17,33,11,16,2,48,48,3,54,32,6,3,2,42]

theorem envBound11927 : H12AffineFastState.Bounded env11927 := by
  intro p hp
  have h : env11927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11926_11927 : H12AffineEnvironment.transform 7 7 env11926 = env11927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env11926 == env11927) = true)

theorem identity11927 : scanCanonicalize (H12AffineFastState.compose env11927 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound11927 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env11928 : List Nat := [2,4,8,16,3,16,9,7,8,23,2,19,10,2,1,0,18,2,22,0,3,2,17,2,11,16,2,19,19,3,21,3,6,3,2,9]

theorem envBound11928 : H12AffineFastState.Bounded env11928 := by
  intro p hp
  have h : env11928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11927_11928 : H12AffineEnvironment.transform 4 3 env11927 = env11928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env11927 == env11928) = true)

theorem identity11928 : scanCanonicalize (H12AffineFastState.compose env11928 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound11928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11929 : List Nat := [2,4,8,15,3,15,9,7,8,8,2,12,10,2,1,0,13,2,9,0,3,2,14,2,11,15,2,12,12,3,10,3,6,3,2,9]

theorem envBound11929 : H12AffineFastState.Bounded env11929 := by
  intro p hp
  have h : env11929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11928_11929 : H12AffineEnvironment.transform 3 15 env11928 = env11929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env11928 == env11929) = true)

theorem identity11929 : scanCanonicalize (H12AffineFastState.compose env11929 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11929 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11930 : List Nat := [1,4,8,12,0,12,9,4,8,8,1,12,9,1,1,0,13,1,9,0,0,1,13,1,8,12,1,12,12,0,9,0,5,0,1,9]

theorem envBound11930 : H12AffineFastState.Bounded env11930 := by
  intro p hp
  have h : env11930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11929_11930 : H12AffineEnvironment.transform 0 1 env11929 = env11930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11929 == env11930) = true)

def env11931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,4160,73770,120015,21763,8328,64,64605,115150,102879,35189,1500,168,257,21793,46212,74251]

theorem envBound11931 : H12AffineFastState.Bounded env11931 := by
  intro p hp
  have h : env11931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11907_11931 : H12AffineEnvironment.transform 17 10401 env11907 = env11931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11907 == env11931) = true)

def env11932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4160,73770,119879,21763,8192,64,64605,115014,102743,35189,1364,32,257,21793,46092,74251]

theorem envBound11932 : H12AffineFastState.Bounded env11932 := by
  intro p hp
  have h : env11932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11931_11932 : H12AffineEnvironment.transform 6 8 env11931 = env11932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11931 == env11932) = true)

theorem identity11932 : scanCanonicalize (H12AffineFastState.compose env11932 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11932 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111898,10281,1025,32769,4160,73770,98630,2,8192,64,43356,103495,102743,35189,1364,32,257,32,46092,74251]

theorem envBound11933 : H12AffineFastState.Bounded env11933 := by
  intro p hp
  have h : env11933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11932_11933 : H12AffineEnvironment.transform 13 5377 env11932 = env11933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11932 == env11933) = true)

theorem identity11933 : scanCanonicalize (H12AffineFastState.compose env11933 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11933 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,65536,103731,2048,1025,32769,4160,65539,98630,2,41,64,35189,103495,102743,35189,1364,32,257,32,37925,66082]

theorem envBound11934 : H12AffineFastState.Bounded env11934 := by
  intro p hp
  have h : env11934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11933_11934 : H12AffineEnvironment.transform 12 41 env11933 = env11934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11933 == env11934) = true)

theorem identity11934 : scanCanonicalize (H12AffineFastState.compose env11934 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11934 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env11935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,1,65536,70962,2048,1025,0,4160,65539,65863,2,41,64,2420,70726,69974,2420,1364,32,257,32,5156,66082]

theorem envBound11935 : H12AffineFastState.Bounded env11935 := by
  intro p hp
  have h : env11935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11934_11935 : H12AffineEnvironment.transform 14 1 env11934 = env11935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11934 == env11935) = true)

theorem identity11935 : scanCanonicalize (H12AffineFastState.compose env11935 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound11935 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,1,35,5393,2048,1025,0,4160,32,356,2,41,64,2420,5221,4469,2420,1364,32,257,32,5156,513]

theorem envBound11936 : H12AffineFastState.Bounded env11936 := by
  intro p hp
  have h : env11936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11935_11936 : H12AffineEnvironment.transform 15 35 env11935 = env11936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env11935 == env11936) = true)

theorem identity11936 : scanCanonicalize (H12AffineFastState.compose env11936 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11936 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11937 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1025,0,4160,32,64,2,41,64,2128,5221,4177,2128,1136,32,37,32,5156,513]

theorem envBound11937 : H12AffineFastState.Bounded env11937 := by
  intro p hp
  have h : env11937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11936_11937 : H12AffineEnvironment.transform 7 36 env11936 = env11937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11936 == env11937) = true)

theorem identity11937 : scanCanonicalize (H12AffineFastState.compose env11937 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11937 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11938 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1025,0,4112,32,16,2,41,16,2048,5173,4097,2048,1056,32,37,32,5156,513]

theorem envBound11938 : H12AffineFastState.Bounded env11938 := by
  intro p hp
  have h : env11938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11937_11938 : H12AffineEnvironment.transform 5 16 env11937 = env11938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11937 == env11938) = true)

theorem identity11938 : scanCanonicalize (H12AffineFastState.compose env11938 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound11938 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11939 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,0,41,1061,1,35,1077,2048,1025,0,16,32,16,2,41,16,2048,1077,1,2048,1056,32,37,32,1060,513]

theorem envBound11939 : H12AffineFastState.Bounded env11939 := by
  intro p hp
  have h : env11939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11938_11939 : H12AffineEnvironment.transform 11 0 env11938 = env11939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env11938 == env11939) = true)

theorem identity11939 : scanCanonicalize (H12AffineFastState.compose env11939 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound11939 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11940 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1087,0,41,1061,1,35,1077,1087,1025,0,16,32,16,2,41,16,1087,1077,1,1087,1056,32,37,32,1060,513]

theorem envBound11940 : H12AffineFastState.Bounded env11940 := by
  intro p hp
  have h : env11940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11939_11940 : H12AffineEnvironment.transform 10 1087 env11939 = env11940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env11939 == env11940) = true)

theorem identity11940 : scanCanonicalize (H12AffineFastState.compose env11940 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11941 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1055,0,9,1029,1,3,1045,1055,1025,0,16,0,16,2,9,16,1055,1045,1,1055,1024,0,5,0,1028,513]

theorem envBound11941 : H12AffineFastState.Bounded env11941 := by
  intro p hp
  have h : env11941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11940_11941 : H12AffineEnvironment.transform 4 0 env11940 = env11941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11940 == env11941) = true)

theorem identity11941 : scanCanonicalize (H12AffineFastState.compose env11941 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11941 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11942 : List Nat := [2,4,8,16,0,16,8,4,512,20,11,0,9,17,1,3,1,11,21,0,16,0,16,2,9,16,11,1,1,11,20,0,5,0,16,513]

theorem envBound11942 : H12AffineFastState.Bounded env11942 := by
  intro p hp
  have h : env11942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11941_11942 : H12AffineEnvironment.transform 9 20 env11941 = env11942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11941 == env11942) = true)

theorem identity11942 : scanCanonicalize (H12AffineFastState.compose env11942 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11943 : List Nat := [2,4,6,16,0,16,6,4,512,20,5,0,7,17,1,3,1,5,21,0,16,0,16,2,7,16,5,1,1,5,20,0,5,0,16,513]

theorem envBound11943 : H12AffineFastState.Bounded env11943 := by
  intro p hp
  have h : env11943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11942_11943 : H12AffineEnvironment.transform 2 6 env11942 = env11943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11942 == env11943) = true)

theorem identity11943 : scanCanonicalize (H12AffineFastState.compose env11943 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound11943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11944 : List Nat := [2,4,6,16,0,16,6,4,6,20,5,0,7,17,1,3,1,5,21,0,16,0,16,2,7,16,5,1,1,5,20,0,5,0,16,7]

theorem envBound11944 : H12AffineFastState.Bounded env11944 := by
  intro p hp
  have h : env11944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11943_11944 : H12AffineEnvironment.transform 8 6 env11943 = env11944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env11943 == env11944) = true)

theorem identity11944 : scanCanonicalize (H12AffineFastState.compose env11944 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11944 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11945 : List Nat := [2,4,6,1,0,1,6,4,6,5,5,0,7,0,1,3,1,5,4,0,1,0,1,2,7,1,5,1,1,5,5,0,5,0,1,7]

theorem envBound11945 : H12AffineFastState.Bounded env11945 := by
  intro p hp
  have h : env11945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11944_11945 : H12AffineEnvironment.transform 3 1 env11944 = env11945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11944 == env11945) = true)

theorem identity11945 : scanCanonicalize (H12AffineFastState.compose env11945 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11945 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env11946 : List Nat := [2,0,2,1,0,1,2,0,2,1,1,0,3,0,1,3,1,1,0,0,1,0,1,2,3,1,1,1,1,1,1,0,1,0,1,3]

theorem envBound11946 : H12AffineFastState.Bounded env11946 := by
  intro p hp
  have h : env11946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11945_11946 : H12AffineEnvironment.transform 1 0 env11945 = env11946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11945 == env11946) = true)

def env11947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,73770,119878,21763,8193,64,64605,115015,102742,35189,1365,33,257,21793,46093,74251]

theorem envBound11947 : H12AffineFastState.Bounded env11947 := by
  intro p hp
  have h : env11947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11931_11947 : H12AffineEnvironment.transform 6 9 env11931 = env11947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11931 == env11947) = true)

theorem identity11947 : scanCanonicalize (H12AffineFastState.compose env11947 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound11947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82246,10280,1025,29789,4160,73770,73754,21763,8193,64,2049,79131,91402,32041,1365,33,257,21793,16465,74251]

theorem envBound11948 : H12AffineFastState.Bounded env11948 := by
  intro p hp
  have h : env11948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11947_11948 : H12AffineEnvironment.transform 14 29788 env11947 = env11948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env11947 == env11948) = true)

theorem identity11948 : scanCanonicalize (H12AffineFastState.compose env11948 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11948 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,82246,2421,1025,21760,4160,65911,65863,21763,348,64,2049,70726,83031,23668,1365,33,257,21793,16465,66390]

theorem envBound11949 : H12AffineFastState.Bounded env11949 := by
  intro p hp
  have h : env11949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11948_11949 : H12AffineEnvironment.transform 12 349 env11948 = env11949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11948 == env11949) = true)

theorem identity11949 : scanCanonicalize (H12AffineFastState.compose env11949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1296,65536,69975,2421,1025,1297,4160,65911,65863,1298,348,64,2049,70726,70726,3173,1365,33,257,1328,4160,66390]

theorem envBound11950 : H12AffineFastState.Bounded env11950 := by
  intro p hp
  have h : env11950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11949_11950 : H12AffineEnvironment.transform 13 4113 env11949 = env11950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11949 == env11950) = true)

theorem identity11950 : scanCanonicalize (H12AffineFastState.compose env11950 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound11950 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env11951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1296,343,4096,2421,1025,1297,4160,32,16,1298,348,64,2049,5393,5393,3173,1365,33,257,1328,4160,513]

theorem envBound11951 : H12AffineFastState.Bounded env11951 := by
  intro p hp
  have h : env11951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11950_11951 : H12AffineEnvironment.transform 15 343 env11950 = env11951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env11950 == env11951) = true)

theorem identity11951 : scanCanonicalize (H12AffineFastState.compose env11951 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound11951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11952 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4113,1,343,4096,2421,272,0,4160,32,16,3,348,64,2049,4096,4096,2420,68,33,257,33,4160,513]

theorem envBound11952 : H12AffineFastState.Bounded env11952 := by
  intro p hp
  have h : env11952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11951_11952 : H12AffineEnvironment.transform 9 273 env11951 = env11952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env11951 == env11952) = true)

theorem identity11952 : scanCanonicalize (H12AffineFastState.compose env11952 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11953 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,121,4113,1,115,4096,2129,52,0,4160,32,16,3,120,64,2049,4096,4096,2128,68,33,37,33,4160,513]

theorem envBound11953 : H12AffineFastState.Bounded env11953 := by
  intro p hp
  have h : env11953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11952_11953 : H12AffineEnvironment.transform 7 36 env11952 = env11953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11952 == env11953) = true)

theorem identity11953 : scanCanonicalize (H12AffineFastState.compose env11953 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11953 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11954 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4113,1,34,4096,2048,52,0,4113,32,16,3,41,17,2049,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound11954 : H12AffineFastState.Bounded env11954 := by
  intro p hp
  have h : env11954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11953_11954 : H12AffineEnvironment.transform 5 17 env11953 = env11954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11953 == env11954) = true)

theorem identity11954 : scanCanonicalize (H12AffineFastState.compose env11954 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound11954 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11955 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,0,40,17,1,34,0,2048,52,0,17,32,16,3,41,17,2049,0,0,2049,21,33,37,33,17,513]

theorem envBound11955 : H12AffineFastState.Bounded env11955 := by
  intro p hp
  have h : env11955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11954_11955 : H12AffineEnvironment.transform 11 0 env11954 = env11955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env11954 == env11955) = true)

theorem identity11955 : scanCanonicalize (H12AffineFastState.compose env11955 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11955 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11956 : List Nat := [2,4,8,16,32,17,9,36,43,53,2048,0,40,17,1,34,0,2048,52,0,17,32,16,3,41,17,2049,0,0,2049,21,33,37,33,17,42]

theorem envBound11956 : H12AffineFastState.Bounded env11956 := by
  intro p hp
  have h : env11956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11955_11956 : H12AffineEnvironment.transform 8 43 env11955 = env11956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11955 == env11956) = true)

theorem identity11956 : scanCanonicalize (H12AffineFastState.compose env11956 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11956 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11957 : List Nat := [2,4,8,16,32,17,9,36,43,53,1,0,40,17,1,34,0,1,52,0,17,32,16,3,41,17,0,0,0,0,21,33,37,33,17,42]

theorem envBound11957 : H12AffineFastState.Bounded env11957 := by
  intro p hp
  have h : env11957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11956_11957 : H12AffineEnvironment.transform 10 1 env11956 = env11957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11956 == env11957) = true)

theorem identity11957 : scanCanonicalize (H12AffineFastState.compose env11957 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11957 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11958 : List Nat := [2,4,8,0,32,1,9,36,43,37,1,0,40,1,1,34,0,1,36,0,1,32,0,3,41,1,0,0,0,0,5,33,37,33,1,42]

theorem envBound11958 : H12AffineFastState.Bounded env11958 := by
  intro p hp
  have h : env11958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11957_11958 : H12AffineEnvironment.transform 3 0 env11957 = env11958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11957 == env11958) = true)

def env11959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,253977,8328,64,64604,160981,140485,303573,1501,272392,257,21793,46212,74250]

theorem envBound11959 : H12AffineFastState.Bounded env11959 := by
  intro p hp
  have h : env11959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11905_11959 : H12AffineEnvironment.transform 20 4161 env11905 = env11959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11905 == env11959) = true)

theorem identity11959 : scanCanonicalize (H12AffineFastState.compose env11959 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11959 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,441745,156116,180242,8328,64,64604,160981,140485,303573,1501,272392,257,21793,46212,513]

theorem envBound11960 : H12AffineFastState.Bounded env11960 := by
  intro p hp
  have h : env11960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11959_11960 : H12AffineEnvironment.transform 15 8203 env11959 = env11960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11959 == env11960) = true)

def env11961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,327041,8644,32770,8328,64,64604,13509,25813,303573,1501,272392,257,21793,46212,513]

theorem envBound11961 : H12AffineFastState.Bounded env11961 := by
  intro p hp
  have h : env11961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11960_11961 : H12AffineEnvironment.transform 16 16400 env11960 = env11961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11960 == env11961) = true)

def env11962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,326921,8524,32770,8192,64,64604,13389,25693,303453,1365,272392,257,21793,46092,513]

theorem envBound11962 : H12AffineFastState.Bounded env11962 := by
  intro p hp
  have h : env11962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11961_11962 : H12AffineEnvironment.transform 6 8 env11961 = env11962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11961 == env11962) = true)

theorem identity11962 : scanCanonicalize (H12AffineFastState.compose env11962 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound11962 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env11963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,8203,12636,262144,1025,32769,4161,298053,8524,32770,8192,64,36112,13389,5393,303453,1365,272392,257,9325,46092,513]

theorem envBound11963 : H12AffineFastState.Bounded env11963 := by
  intro p hp
  have h : env11963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11962_11963 : H12AffineEnvironment.transform 13 12620 env11962 = env11963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env11962 == env11963) = true)

theorem identity11963 : scanCanonicalize (H12AffineFastState.compose env11963 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11963 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env11964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8540,8203,12636,262144,1025,8541,4161,273689,8524,8542,8192,64,11340,13389,5393,262145,1365,272392,257,9325,5456,513]

theorem envBound11964 : H12AffineFastState.Bounded env11964 := by
  intro p hp
  have h : env11964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11963_11964 : H12AffineEnvironment.transform 14 8540 env11963 = env11964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11963 == env11964) = true)

theorem identity11964 : scanCanonicalize (H12AffineFastState.compose env11964 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound11964 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8540,8203,12636,10280,1025,8541,4161,1329,8524,8542,8192,64,11340,13389,5393,10281,1365,32,257,9325,5456,513]

theorem envBound11965 : H12AffineFastState.Bounded env11965 := by
  intro p hp
  have h : env11965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11964_11965 : H12AffineEnvironment.transform 17 10280 env11964 = env11965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11964 == env11965) = true)

theorem identity11965 : scanCanonicalize (H12AffineFastState.compose env11965 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound11965 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,2128,6208,6423,2112,4404,1025,6209,4161,1329,6224,6210,6428,64,5456,3409,5393,4405,1365,32,257,7537,5456,513]

theorem envBound11966 : H12AffineFastState.Bounded env11966 := by
  intro p hp
  have h : env11966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11965_11966 : H12AffineEnvironment.transform 12 6428 env11965 = env11966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env11965 == env11966) = true)

theorem identity11966 : scanCanonicalize (H12AffineFastState.compose env11966 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound11966 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1336,2128,1124,1331,2112,3344,1025,1125,3173,1329,1140,1126,1336,64,2420,3409,2357,3345,1365,32,257,341,2420,513]

theorem envBound11967 : H12AffineFastState.Bounded env11967 := by
  intro p hp
  have h : env11967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11966_11967 : H12AffineEnvironment.transform 11 3108 env11966 = env11967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env11966 == env11967) = true)

theorem identity11967 : scanCanonicalize (H12AffineFastState.compose env11967 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11967 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env11968 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3108,1052,2128,1124,1047,2112,3124,1025,1125,3173,1045,1140,1126,1052,64,2128,3189,2065,3125,1137,32,37,113,2128,513]

theorem envBound11968 : H12AffineFastState.Bounded env11968 := by
  intro p hp
  have h : env11968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11967_11968 : H12AffineEnvironment.transform 7 36 env11967 = env11968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11967 == env11968) = true)

theorem identity11968 : scanCanonicalize (H12AffineFastState.compose env11968 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11969 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1052,2048,1076,1047,2064,3124,1025,1077,3125,1045,1060,1078,1052,16,2048,3109,2065,3125,1057,32,37,33,2048,513]

theorem envBound11969 : H12AffineFastState.Bounded env11969 := by
  intro p hp
  have h : env11969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11968_11969 : H12AffineEnvironment.transform 5 16 env11968 = env11969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11968 == env11969) = true)

theorem identity11969 : scanCanonicalize (H12AffineFastState.compose env11969 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound11969 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11970 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1566,570,1052,1566,1076,1047,1550,554,1025,1077,555,1045,1060,1078,1052,16,1566,571,1551,555,1057,32,37,33,1566,513]

theorem envBound11970 : H12AffineFastState.Bounded env11970 := by
  intro p hp
  have h : env11970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11969_11970 : H12AffineEnvironment.transform 10 1566 env11969 = env11970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env11969 == env11970) = true)

theorem identity11970 : scanCanonicalize (H12AffineFastState.compose env11970 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11970 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11971 : List Nat := [2,4,8,16,32,16,8,36,512,52,554,570,40,554,0,35,570,554,53,1,555,33,16,2,40,16,554,571,571,555,21,32,37,33,554,513]

theorem envBound11971 : H12AffineFastState.Bounded env11971 := by
  intro p hp
  have h : env11971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11970_11971 : H12AffineEnvironment.transform 9 52 env11970 = env11971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11970 == env11971) = true)

theorem identity11971 : scanCanonicalize (H12AffineFastState.compose env11971 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11972 : List Nat := [2,4,8,16,32,16,8,36,43,52,1,17,40,1,0,35,17,1,53,1,0,33,16,2,40,16,1,16,16,0,21,32,37,33,1,42]

theorem envBound11972 : H12AffineFastState.Bounded env11972 := by
  intro p hp
  have h : env11972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11971_11972 : H12AffineEnvironment.transform 8 43 env11971 = env11972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11971 == env11972) = true)

theorem identity11972 : scanCanonicalize (H12AffineFastState.compose env11972 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11973 : List Nat := [2,4,8,16,16,16,8,20,27,4,1,17,24,1,0,19,17,1,5,1,0,17,16,2,24,16,1,16,16,0,21,16,21,17,1,26]

theorem envBound11973 : H12AffineFastState.Bounded env11973 := by
  intro p hp
  have h : env11973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11972_11973 : H12AffineEnvironment.transform 4 16 env11972 = env11973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11972 == env11973) = true)

theorem identity11973 : scanCanonicalize (H12AffineFastState.compose env11973 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11973 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11974 : List Nat := [2,4,8,11,11,11,8,15,0,4,1,10,3,1,0,8,10,1,5,1,0,10,11,2,3,11,1,11,11,0,14,11,14,10,1,1]

theorem envBound11974 : H12AffineFastState.Bounded env11974 := by
  intro p hp
  have h : env11974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11973_11974 : H12AffineEnvironment.transform 3 11 env11973 = env11974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11973 == env11974) = true)

theorem identity11974 : scanCanonicalize (H12AffineFastState.compose env11974 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11974 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11975 : List Nat := [2,4,2,1,1,1,2,5,0,4,1,0,3,1,0,2,0,1,5,1,0,0,1,2,3,1,1,1,1,0,4,1,4,0,1,1]

theorem envBound11975 : H12AffineFastState.Bounded env11975 := by
  intro p hp
  have h : env11975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11974_11975 : H12AffineEnvironment.transform 2 2 env11974 = env11975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11974 == env11975) = true)

def env11976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,326920,8525,32770,8193,64,64604,13388,25692,303452,1364,272392,257,21793,46093,513]

theorem envBound11976 : H12AffineFastState.Bounded env11976 := by
  intro p hp
  have h : env11976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11961_11976 : H12AffineEnvironment.transform 6 9 env11961 = env11976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11961 == env11976) = true)

def env11977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,327040,8645,32771,8328,64,64604,13508,25812,303573,1501,272392,257,21793,46212,513]

theorem envBound11977 : H12AffineFastState.Bounded env11977 := by
  intro p hp
  have h : env11977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11960_11977 : H12AffineEnvironment.transform 16 16401 env11960 = env11977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env11960 == env11977) = true)

theorem identity11977 : scanCanonicalize (H12AffineFastState.compose env11977 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound11977 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16401,262144,1025,32769,4161,318548,17,32771,348,64,56712,5392,17664,294913,1501,264668,257,21793,38224,513]

theorem envBound11978 : H12AffineFastState.Bounded env11978 := by
  intro p hp
  have h : env11978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11977_11978 : H12AffineEnvironment.transform 12 468 env11977 = env11978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env11977 == env11978) = true)

theorem identity11978 : scanCanonicalize (H12AffineFastState.compose env11978 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound11978 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16401,56573,1025,32769,4161,169,17,32771,348,64,56712,5392,17664,23804,1501,54561,257,21793,38224,513]

theorem envBound11979 : H12AffineFastState.Bounded env11979 := by
  intro p hp
  have h : env11979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11978_11979 : H12AffineEnvironment.transform 17 56573 env11978 = env11979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env11978 == env11979) = true)

theorem identity11979 : scanCanonicalize (H12AffineFastState.compose env11979 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11979 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env11980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,16401,56436,1025,32769,4161,32,17,32771,348,64,56577,5392,17664,23669,1364,54561,257,21793,38224,513]

theorem envBound11980 : H12AffineFastState.Bounded env11980 := by
  intro p hp
  have h : env11980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11979_11980 : H12AffineEnvironment.transform 6 9 env11979 = env11980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11979 == env11980) = true)

theorem identity11980 : scanCanonicalize (H12AffineFastState.compose env11980 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound11980 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16401,2420,1025,21761,4161,32,17,21763,348,64,2049,5392,17664,23669,1364,33,257,21793,16464,513]

theorem envBound11981 : H12AffineFastState.Bounded env11981 := by
  intro p hp
  have h : env11981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11980_11981 : H12AffineEnvironment.transform 14 21760 env11980 = env11981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11980 == env11981) = true)

theorem identity11981 : scanCanonicalize (H12AffineFastState.compose env11981 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound11981 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,342,5440,2420,1025,80,4161,32,17,82,348,64,2049,5392,4177,2340,1364,33,257,112,5377,513]

theorem envBound11982 : H12AffineFastState.Bounded env11982 := by
  intro p hp
  have h : env11982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11981_11982 : H12AffineEnvironment.transform 13 5457 env11981 = env11982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env11981 == env11982) = true)

theorem identity11982 : scanCanonicalize (H12AffineFastState.compose env11982 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1102) := by decide +kernel

theorem selectedBound11982 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env11983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1102,349,287,81,342,270,2420,1025,80,1039,32,17,82,348,64,2049,350,1055,2340,1364,33,257,112,335,513]

theorem envBound11983 : H12AffineFastState.Bounded env11983 := by
  intro p hp
  have h : env11983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11982_11983 : H12AffineEnvironment.transform 11 1102 env11982 = env11983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1102 env11982 == env11983) = true)

theorem identity11983 : scanCanonicalize (H12AffineFastState.compose env11983 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound11983 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env11984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,271,1102,349,287,81,342,270,123,1025,80,1039,32,17,82,348,64,270,350,1055,43,1364,33,257,112,335,513]

theorem envBound11984 : H12AffineFastState.Bounded env11984 := by
  intro p hp
  have h : env11984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11983_11984 : H12AffineEnvironment.transform 10 271 env11983 = env11984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env11983 == env11984) = true)

theorem identity11984 : scanCanonicalize (H12AffineFastState.compose env11984 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound11984 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env11985 : List Nat := [2,4,8,16,32,64,9,53,512,1024,58,1102,104,42,81,99,59,123,1025,80,1039,32,17,82,105,64,59,107,1055,43,1121,33,52,112,122,513]

theorem envBound11985 : H12AffineFastState.Bounded env11985 := by
  intro p hp
  have h : env11985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11984_11985 : H12AffineEnvironment.transform 7 53 env11984 = env11985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env11984 == env11985) = true)

theorem identity11985 : scanCanonicalize (H12AffineFastState.compose env11985 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound11985 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env11986 : List Nat := [2,4,8,16,32,64,9,53,512,100,58,42,104,42,81,99,59,123,101,80,107,32,17,82,105,64,59,107,123,43,5,33,52,112,122,513]

theorem envBound11986 : H12AffineFastState.Bounded env11986 := by
  intro p hp
  have h : env11986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11985_11986 : H12AffineEnvironment.transform 9 100 env11985 = env11986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env11985 == env11986) = true)

theorem identity11986 : scanCanonicalize (H12AffineFastState.compose env11986 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound11986 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11987 : List Nat := [2,4,8,16,32,27,9,53,512,63,58,42,51,42,10,56,59,32,62,11,48,32,17,9,50,27,59,48,32,43,5,33,52,43,33,513]

theorem envBound11987 : H12AffineFastState.Bounded env11987 := by
  intro p hp
  have h : env11987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11986_11987 : H12AffineEnvironment.transform 5 27 env11986 = env11987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env11986 == env11987) = true)

theorem identity11987 : scanCanonicalize (H12AffineFastState.compose env11987 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11987 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env11988 : List Nat := [2,4,2,16,32,17,3,53,512,53,48,32,51,32,0,50,49,32,52,1,48,32,17,3,50,17,49,48,32,33,5,33,52,33,33,513]

theorem envBound11988 : H12AffineFastState.Bounded env11988 := by
  intro p hp
  have h : env11988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11987_11988 : H12AffineEnvironment.transform 2 2 env11987 = env11988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11987 == env11988) = true)

theorem identity11988 : scanCanonicalize (H12AffineFastState.compose env11988 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 55) := by decide +kernel

theorem selectedBound11988 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11989 : List Nat := [2,4,2,16,32,17,3,53,55,53,48,32,51,32,0,50,49,32,52,1,48,32,17,3,50,17,49,48,32,33,5,33,52,33,33,54]

theorem envBound11989 : H12AffineFastState.Bounded env11989 := by
  intro p hp
  have h : env11989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11988_11989 : H12AffineEnvironment.transform 8 55 env11988 = env11989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 55 env11988 == env11989) = true)

theorem identity11989 : scanCanonicalize (H12AffineFastState.compose env11989 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11990 : List Nat := [2,4,2,0,32,1,3,37,39,37,32,32,35,32,0,34,33,32,36,1,32,32,1,3,34,1,33,32,32,33,5,33,36,33,33,38]

theorem envBound11990 : H12AffineFastState.Bounded env11990 := by
  intro p hp
  have h : env11990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11989_11990 : H12AffineEnvironment.transform 3 0 env11989 = env11990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11989 == env11990) = true)

theorem identity11990 : scanCanonicalize (H12AffineFastState.compose env11990 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound11990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11991 : List Nat := [2,4,2,0,5,1,3,0,2,0,5,5,6,5,0,7,4,5,1,1,5,5,1,3,7,1,4,5,5,4,5,4,1,4,4,3]

theorem envBound11991 : H12AffineFastState.Bounded env11991 := by
  intro p hp
  have h : env11991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11990_11991 : H12AffineEnvironment.transform 4 5 env11990 = env11991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env11990 == env11991) = true)

theorem identity11991 : scanCanonicalize (H12AffineFastState.compose env11991 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound11991 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11992 : List Nat := [2,1,2,0,0,1,3,0,2,0,0,0,3,0,0,2,1,0,1,1,0,0,1,3,2,1,1,0,0,1,0,1,1,1,1,3]

theorem envBound11992 : H12AffineFastState.Bounded env11992 := by
  intro p hp
  have h : env11992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11991_11992 : H12AffineEnvironment.transform 1 1 env11991 = env11992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env11991 == env11992) = true)

def env11993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound11993 : H12AffineFastState.Bounded env11993 := by
  intro p hp
  have h : env11993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11302_11993 : H12AffineEnvironment.transform 25 65 env11302 = env11993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env11302 == env11993) = true)

def env11994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound11994 : H12AffineFastState.Bounded env11994 := by
  intro p hp
  have h : env11994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11993_11994 : H12AffineEnvironment.transform 26 30393344 env11993 = env11994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env11993 == env11994) = true)

def env11995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound11995 : H12AffineFastState.Bounded env11995 := by
  intro p hp
  have h : env11995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11994_11995 : H12AffineEnvironment.transform 18 1024 env11994 = env11995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11994 == env11995) = true)

theorem identity11995 : scanCanonicalize (H12AffineFastState.compose env11995 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437625) := by decide +kernel

theorem selectedBound11995 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,8388608,16777216,8328,65,29868032,17246709,8845352,8830977,25265169,21481657,256,25651668,25659505,25207750]

theorem envBound11996 : H12AffineFastState.Bounded env11996 := by
  intro p hp
  have h : env11996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11995_11996 : H12AffineEnvironment.transform 20 437625 env11995 = env11996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env11995 == env11996) = true)

def env11997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,8388608,8862964,8328,65,4259060,8393985,8845352,8830977,440549,12645453,256,21792,46213,499506]

theorem envBound11997 : H12AffineFastState.Bounded env11997 := by
  intro p hp
  have h : env11997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11996_11997 : H12AffineEnvironment.transform 23 8862964 env11996 = env11997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862964 env11996 == env11997) = true)

def env11998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,4194304,441640,98780,8328,65,4259060,436265,17664,32041,440549,4606309,256,21792,46213,499506]

theorem envBound11998 : H12AffineFastState.Bounded env11998 := by
  intro p hp
  have h : env11998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11997_11998 : H12AffineEnvironment.transform 22 441640 env11997 = env11998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env11997 == env11998) = true)

def env11999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272512,441640,98780,8328,65,316532,436265,17664,32041,440549,156133,256,21792,46213,499506]

theorem envBound11999 : H12AffineFastState.Bounded env11999 := by
  intro p hp
  have h : env11999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11998_11999 : H12AffineEnvironment.transform 21 272512 env11998 = env11999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11998 == env11999) = true)

theorem identity11999 : scanCanonicalize (H12AffineFastState.compose env11999 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11999 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272512,441640,41431,8328,65,316532,436265,17664,32041,440549,156133,256,21792,46213,442169]

theorem envBound12000 : H12AffineFastState.Bounded env12000 := by
  intro p hp
  have h : env12000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11999_12000 : H12AffineEnvironment.transform 15 8203 env11999 = env12000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11999 == env12000) = true)

def env12001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272392,441640,41311,8192,65,316532,436265,17664,32041,440429,156013,256,21792,46093,442169]

theorem envBound12001 : H12AffineFastState.Bounded env12001 := by
  intro p hp
  have h : env12001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12000_12001 : H12AffineEnvironment.transform 6 8 env12000 = env12001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12000 == env12001) = true)

theorem identity12001 : scanCanonicalize (H12AffineFastState.compose env12001 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound12001 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,262144,1024,32769,301364,272392,297317,41311,8192,65,316532,302180,17664,32041,298016,21792,256,21792,46093,297844]

theorem envBound12002 : H12AffineFastState.Bounded env12002 := by
  intro p hp
  have h : env12002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12001_12002 : H12AffineEnvironment.transform 16 13389 env12001 = env12002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env12001 == env12002) = true)

theorem identity12002 : scanCanonicalize (H12AffineFastState.compose env12002 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound12002 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,8203,13389,262144,1024,373,268352,272392,264209,8235,8192,65,283904,269584,17664,32041,265556,21792,256,21792,13689,264704]

theorem envBound12003 : H12AffineFastState.Bounded env12003 := by
  intro p hp
  have h : env12003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12002_12003 : H12AffineEnvironment.transform 14 372 env12002 = env12003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env12002 == env12003) = true)

theorem identity12003 : scanCanonicalize (H12AffineFastState.compose env12003 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12003 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env12004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,372,8203,13389,262144,1024,373,268352,272392,264209,8235,8192,65,270685,269584,12637,2420,265556,8573,256,8573,13689,264704]

theorem envBound12004 : H12AffineFastState.Bounded env12004 := by
  intro p hp
  have h : env12004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12003_12004 : H12AffineEnvironment.transform 13 13405 env12003 = env12004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12003 == env12004) = true)

theorem identity12004 : scanCanonicalize (H12AffineFastState.compose env12004 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound12004 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env12005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,372,8203,13389,2048,1024,373,4160,8200,17,8235,8192,65,10589,5392,12637,2420,1364,8573,256,8573,13689,512]

theorem envBound12005 : H12AffineFastState.Bounded env12005 := by
  intro p hp
  have h : env12005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12004_12005 : H12AffineEnvironment.transform 17 2048 env12004 = env12005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env12004 == env12005) = true)

theorem identity12005 : scanCanonicalize (H12AffineFastState.compose env12005 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound12005 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,5125,372,83,5141,2048,1024,373,4160,80,17,115,88,65,2309,5392,4357,2420,1364,293,256,293,5409,512]

theorem envBound12006 : H12AffineFastState.Bounded env12006 := by
  intro p hp
  have h : env12006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12005_12006 : H12AffineEnvironment.transform 12 88 env12005 = env12006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env12005 == env12006) = true)

theorem identity12006 : scanCanonicalize (H12AffineFastState.compose env12006 (packedSelected [6,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12006 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env12007 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,88,5125,80,83,5141,2048,1024,81,4160,80,17,115,88,65,2081,5172,4129,2128,1136,1,36,1,5125,512]

theorem envBound12007 : H12AffineFastState.Bounded env12007 := by
  intro p hp
  have h : env12007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12006_12007 : H12AffineEnvironment.transform 7 36 env12006 = env12007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12006 == env12007) = true)

theorem identity12007 : scanCanonicalize (H12AffineFastState.compose env12007 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound12007 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env12008 : List Nat := [2,4,8,16,32,64,8,36,512,1024,561,4096,88,5125,80,83,5141,561,1024,81,4160,80,17,115,88,65,528,5172,4129,609,1136,1,36,1,5125,512]

theorem envBound12008 : H12AffineFastState.Bounded env12008 := by
  intro p hp
  have h : env12008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12007_12008 : H12AffineEnvironment.transform 10 561 env12007 = env12008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env12007 == env12008) = true)

theorem identity12008 : scanCanonicalize (H12AffineFastState.compose env12008 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound12008 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12009 : List Nat := [2,4,8,16,32,64,8,36,512,4,561,4096,88,4097,80,83,4113,561,4,81,4160,80,17,115,88,65,528,4144,4129,609,116,1,36,1,4097,512]

theorem envBound12009 : H12AffineFastState.Bounded env12009 := by
  intro p hp
  have h : env12009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12008_12009 : H12AffineEnvironment.transform 9 4 env12008 = env12009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env12008 == env12009) = true)

theorem identity12009 : scanCanonicalize (H12AffineFastState.compose env12009 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound12009 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12010 : List Nat := [2,4,8,16,32,64,8,36,512,4,561,113,88,112,80,83,96,561,4,81,49,80,17,115,88,65,528,65,80,609,116,1,36,1,112,512]

theorem envBound12010 : H12AffineFastState.Bounded env12010 := by
  intro p hp
  have h : env12010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12009_12010 : H12AffineEnvironment.transform 11 113 env12009 = env12010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env12009 == env12010) = true)

theorem identity12010 : scanCanonicalize (H12AffineFastState.compose env12010 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound12010 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env12011 : List Nat := [2,4,8,16,32,64,8,36,113,4,64,113,88,112,80,83,96,64,4,81,49,80,17,115,88,65,97,65,80,16,116,1,36,1,112,113]

theorem envBound12011 : H12AffineFastState.Bounded env12011 := by
  intro p hp
  have h : env12011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12010_12011 : H12AffineEnvironment.transform 8 113 env12010 = env12011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env12010 == env12011) = true)

def env12012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437625,272393,441640,41310,8193,65,316532,436265,17664,32041,440428,156012,256,21792,46092,442169]

theorem envBound12012 : H12AffineFastState.Bounded env12012 := by
  intro p hp
  have h : env12012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12000_12012 : H12AffineEnvironment.transform 6 9 env12000 = env12012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12000 == env12012) = true)

theorem identity12012 : scanCanonicalize (H12AffineFastState.compose env12012 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound12012 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env12013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1024,32769,276585,272393,272440,41310,8193,65,316532,277817,17664,32041,273788,62588,256,21792,46092,272937]

theorem envBound12013 : H12AffineFastState.Bounded env12013 := by
  intro p hp
  have h : env12013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12012_12013 : H12AffineEnvironment.transform 16 38160 env12012 = env12013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env12012 == env12013) = true)

def env12014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272513,441640,98780,8328,65,316533,436265,17664,32041,440549,156132,256,21792,46213,499506]

theorem envBound12014 : H12AffineFastState.Bounded env12014 := by
  intro p hp
  have h : env12014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11998_12014 : H12AffineEnvironment.transform 21 272513 env11998 = env12014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11998 == env12014) = true)

theorem identity12014 : scanCanonicalize (H12AffineFastState.compose env12014 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound12014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77898,243122,73755,98780,8328,65,215366,79130,17664,32041,75222,156132,256,21792,46213,513]

theorem envBound12015 : H12AffineFastState.Bounded env12015 := by
  intro p hp
  have h : env12015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12014_12015 : H12AffineEnvironment.transform 17 236851 env12014 = env12015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env12014 == env12015) = true)

def env12016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77898,243002,73755,98644,8192,65,215366,79130,17664,32041,75102,156012,256,21792,46093,513]

theorem envBound12016 : H12AffineFastState.Bounded env12016 := by
  intro p hp
  have h : env12016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12015_12016 : H12AffineEnvironment.transform 6 8 env12015 = env12016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12015 == env12016) = true)

theorem identity12016 : scanCanonicalize (H12AffineFastState.compose env12016 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12016 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,64809,1024,32769,77898,54560,73755,98644,8192,65,10588,79130,17664,32041,75102,65910,256,21792,46093,513]

theorem envBound12017 : H12AffineFastState.Bounded env12017 := by
  intro p hp
  have h : env12017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12016_12017 : H12AffineEnvironment.transform 16 90138 env12016 = env12017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12016 == env12017) = true)

theorem identity12017 : scanCanonicalize (H12AffineFastState.compose env12017 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 42315) := by decide +kernel

theorem selectedBound12017 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1