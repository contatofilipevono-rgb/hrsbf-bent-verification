import H12CloudChart1Data165

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound42097 : H12AffineFastState.Bounded env42097 := by
  intro p hp
  have h : env42097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42096_42097 : H12AffineEnvironment.transform 6 8 env42096 = env42097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42096 == env42097) = true)

def env42098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272393,16,98645,8192,64,64604,5392,17665,283904,1365,318548,257,21793,46093,74250]

theorem envBound42098 : H12AffineFastState.Bounded env42098 := by
  intro p hp
  have h : env42098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42097_42098 : H12AffineEnvironment.transform 20 4160 env42097 = env42098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42097 == env42098) = true)

theorem identity42098 : scanCanonicalize (H12AffineFastState.compose env42098 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42098 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4160,272393,16,41310,8192,64,64604,5392,17665,283904,1365,318548,257,21793,46093,513]

theorem envBound42099 : H12AffineFastState.Bounded env42099 := by
  intro p hp
  have h : env42099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42098_42099 : H12AffineEnvironment.transform 15 8203 env42098 = env42099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42098 == env42099) = true)

theorem identity42099 : scanCanonicalize (H12AffineFastState.compose env42099 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42099 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,16401,262144,1025,21760,4160,272393,16,29791,8192,64,10589,5392,17665,283904,1365,264533,257,21793,24844,513]

theorem envBound42100 : H12AffineFastState.Bounded env42100 := by
  intro p hp
  have h : env42100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42099_42100 : H12AffineEnvironment.transform 14 21761 env42099 = env42100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42099 == env42100) = true)

theorem identity42100 : scanCanonicalize (H12AffineFastState.compose env42100 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42100 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8203,13388,262144,1025,8541,4160,272393,16,2,8192,64,10589,5392,12636,270685,1365,264533,257,8572,5457,513]

theorem envBound42101 : H12AffineFastState.Bounded env42101 := by
  intro p hp
  have h : env42101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42100_42101 : H12AffineEnvironment.transform 13 13405 env42100 = env42101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42100 == env42101) = true)

theorem identity42101 : scanCanonicalize (H12AffineFastState.compose env42101 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42101 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,80,263,5440,262144,1025,81,4160,264453,16,2,268,64,2129,5392,4176,262225,1365,264533,257,112,5457,513]

theorem envBound42102 : H12AffineFastState.Bounded env42102 := by
  intro p hp
  have h : env42102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42101_42102 : H12AffineEnvironment.transform 12 268 env42101 = env42102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42101 == env42102) = true)

theorem identity42102 : scanCanonicalize (H12AffineFastState.compose env42102 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42102 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42103 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5237,80,35,5220,262144,1025,81,4160,264225,16,2,40,64,2129,5172,4176,262225,1137,264305,37,112,5237,513]

theorem envBound42103 : H12AffineFastState.Bounded env42103 := by
  intro p hp
  have h : env42103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42102_42103 : H12AffineEnvironment.transform 7 36 env42102 = env42103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42102 == env42103) = true)

theorem identity42103 : scanCanonicalize (H12AffineFastState.compose env42103 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42103 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42104 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5173,262144,1025,0,4113,264225,16,2,40,17,2048,5172,4097,262144,1056,264224,37,33,5156,513]

theorem envBound42104 : H12AffineFastState.Bounded env42104 := by
  intro p hp
  have h : env42104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42103_42104 : H12AffineEnvironment.transform 5 17 env42103 = env42104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42103 == env42104) = true)

theorem identity42104 : scanCanonicalize (H12AffineFastState.compose env42104 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound42104 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42105 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5173,2048,1025,0,4113,33,16,2,40,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound42105 : H12AffineFastState.Bounded env42105 := by
  intro p hp
  have h : env42105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42104_42105 : H12AffineEnvironment.transform 17 2048 env42104 = env42105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env42104 == env42105) = true)

def env42106 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1044,1,35,1029,2048,1025,0,33,33,16,2,40,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound42106 : H12AffineFastState.Bounded env42106 := by
  intro p hp
  have h : env42106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42105_42106 : H12AffineEnvironment.transform 11 48 env42105 = env42106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42105 == env42106) = true)

theorem identity42106 : scanCanonicalize (H12AffineFastState.compose env42106 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound42106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42107 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,40,1044,1,35,1029,1077,1025,0,33,33,16,2,40,17,1077,1028,49,1077,1056,32,37,33,1044,513]

theorem envBound42107 : H12AffineFastState.Bounded env42107 := by
  intro p hp
  have h : env42107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42106_42107 : H12AffineEnvironment.transform 10 1077 env42106 = env42107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env42106 == env42107) = true)

def env42108 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,40,32,1,35,49,1,53,0,33,33,16,2,40,17,1,48,49,1,20,32,37,33,32,513]

theorem envBound42108 : H12AffineFastState.Bounded env42108 := by
  intro p hp
  have h : env42108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42107_42108 : H12AffineEnvironment.transform 9 52 env42107 = env42108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42107 == env42108) = true)

theorem identity42108 : scanCanonicalize (H12AffineFastState.compose env42108 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42109 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,9,1,1,2,16,1,20,0,0,0,16,2,9,17,1,17,16,1,20,1,4,0,1,513]

theorem envBound42109 : H12AffineFastState.Bounded env42109 := by
  intro p hp
  have h : env42109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42108_42109 : H12AffineEnvironment.transform 4 1 env42108 = env42109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42108 == env42109) = true)

def leafEnv42109 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,9,1,1,2,16,1,20,0,0,0,16,2,21,9,1,17,1,17,16,1,20,1,4,0,5,2,1,513,1,0,0]

def active42109 : List Nat := [0,1,2,3,8]

def tree42109 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42109 : H12WitnessSearch.Good tree42109 := H12GlobalWitnessIndex.good

theorem leafIdentity42109 : H12AffineFastState.composeSystem env42109 rootObs = leafEnv42109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42109 rootObs == leafEnv42109) = true)

theorem terminalChecked42109 : H12PackedTerminal.terminalCheckFast leafEnv42109 active42109 tree42109 = true := by decide +kernel

def env42110 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,33,1,35,48,0,52,0,33,33,16,2,40,17,0,49,49,0,21,32,37,33,33,513]

theorem envBound42110 : H12AffineFastState.Bounded env42110 := by
  intro p hp
  have h : env42110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42107_42110 : H12AffineEnvironment.transform 9 53 env42107 = env42110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42107 == env42110) = true)

theorem identity42110 : scanCanonicalize (H12AffineFastState.compose env42110 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound42110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42111 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,40,33,1,35,48,0,52,0,33,33,16,2,40,17,0,49,49,0,21,32,37,33,33,10]

theorem envBound42111 : H12AffineFastState.Bounded env42111 := by
  intro p hp
  have h : env42111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42110_42111 : H12AffineEnvironment.transform 8 11 env42110 = env42111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env42110 == env42111) = true)

def leafEnv42111 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,40,33,1,35,48,0,52,0,33,33,16,2,20,40,1,17,0,49,49,0,21,32,37,33,5,35,33,10,1,33,0]

def active42111 : List Nat := [0,1,2,3,4]

def tree42111 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42111 : H12WitnessSearch.Good tree42111 := H12GlobalWitnessIndex.good

theorem leafIdentity42111 : H12AffineFastState.composeSystem env42111 rootObs = leafEnv42111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42111 rootObs == leafEnv42111) = true)

theorem terminalChecked42111 : H12PackedTerminal.terminalCheckFast leafEnv42111 active42111 tree42111 = true := by decide +kernel

def env42112 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1045,1,35,1028,2048,1025,0,32,33,16,2,40,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound42112 : H12AffineFastState.Bounded env42112 := by
  intro p hp
  have h : env42112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42105_42112 : H12AffineEnvironment.transform 11 49 env42105 = env42112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42105 == env42112) = true)

theorem identity42112 : scanCanonicalize (H12AffineFastState.compose env42112 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42113 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,40,1045,1,35,1028,0,1025,0,32,33,16,2,40,17,0,1029,48,0,1056,32,37,33,1045,513]

theorem envBound42113 : H12AffineFastState.Bounded env42113 := by
  intro p hp
  have h : env42113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42112_42113 : H12AffineEnvironment.transform 10 0 env42112 = env42113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42112 == env42113) = true)

def env42114 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,33,1,35,48,0,53,0,32,33,16,2,40,17,0,49,48,0,20,32,37,33,33,513]

theorem envBound42114 : H12AffineFastState.Bounded env42114 := by
  intro p hp
  have h : env42114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42113_42114 : H12AffineEnvironment.transform 9 52 env42113 = env42114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42113 == env42114) = true)

theorem identity42114 : scanCanonicalize (H12AffineFastState.compose env42114 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42114 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42115 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,9,0,1,2,17,0,20,0,1,0,16,2,9,17,0,16,17,0,20,1,4,0,0,513]

theorem envBound42115 : H12AffineFastState.Bounded env42115 := by
  intro p hp
  have h : env42115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42114_42115 : H12AffineEnvironment.transform 4 1 env42114 = env42115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42114 == env42115) = true)

def leafEnv42115 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,9,0,1,2,17,0,20,0,1,0,16,2,21,9,1,17,0,16,17,0,20,1,4,0,5,2,0,513,1,1,0]

def active42115 : List Nat := [0,1,2,3,8]

def tree42115 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42115 : H12WitnessSearch.Good tree42115 := H12GlobalWitnessIndex.good

theorem leafIdentity42115 : H12AffineFastState.composeSystem env42115 rootObs = leafEnv42115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42115 rootObs == leafEnv42115) = true)

theorem terminalChecked42115 : H12PackedTerminal.terminalCheckFast leafEnv42115 active42115 tree42115 = true := by decide +kernel

def env42116 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,40,32,1,35,49,0,52,0,32,33,16,2,40,17,0,48,48,0,21,32,37,33,32,513]

theorem envBound42116 : H12AffineFastState.Bounded env42116 := by
  intro p hp
  have h : env42116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42113_42116 : H12AffineEnvironment.transform 9 53 env42113 = env42116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42113 == env42116) = true)

theorem identity42116 : scanCanonicalize (H12AffineFastState.compose env42116 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound42116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42117 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,40,32,1,35,49,0,52,0,32,33,16,2,40,17,0,48,48,0,21,32,37,33,32,10]

theorem envBound42117 : H12AffineFastState.Bounded env42117 := by
  intro p hp
  have h : env42117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42116_42117 : H12AffineEnvironment.transform 8 11 env42116 = env42117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env42116 == env42117) = true)

def leafEnv42117 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,40,32,1,35,49,0,52,0,32,33,16,2,20,40,1,17,0,48,48,0,21,32,37,33,5,35,32,10,1,32,0]

def active42117 : List Nat := [0,1,2,3,4]

def tree42117 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42117 : H12WitnessSearch.Good tree42117 := H12GlobalWitnessIndex.good

theorem leafIdentity42117 : H12AffineFastState.composeSystem env42117 rootObs = leafEnv42117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42117 rootObs == leafEnv42117) = true)

theorem terminalChecked42117 : H12PackedTerminal.terminalCheckFast leafEnv42117 active42117 tree42117 = true := by decide +kernel

def env42118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272393,17,98645,8192,64,64605,5393,17665,283905,1364,318549,257,21793,46093,74251]

theorem envBound42118 : H12AffineFastState.Bounded env42118 := by
  intro p hp
  have h : env42118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42097_42118 : H12AffineEnvironment.transform 20 4161 env42097 = env42118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42097 == env42118) = true)

theorem identity42118 : scanCanonicalize (H12AffineFastState.compose env42118 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42118 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,33,17,98645,8192,64,64605,5393,17665,32041,1364,62589,257,21793,46093,74251]

theorem envBound42119 : H12AffineFastState.Bounded env42119 := by
  intro p hp
  have h : env42119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42118_42119 : H12AffineEnvironment.transform 17 10280 env42118 = env42119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42118 == env42119) = true)

theorem identity42119 : scanCanonicalize (H12AffineFastState.compose env42119 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42119 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env42120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10280,1025,32769,4161,33,17,98645,8192,64,43357,5393,4097,10281,1364,41341,257,33,46093,74251]

theorem envBound42120 : H12AffineFastState.Bounded env42120 := by
  intro p hp
  have h : env42120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42119_42120 : H12AffineEnvironment.transform 13 5376 env42119 = env42120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42119 == env42120) = true)

theorem identity42120 : scanCanonicalize (H12AffineFastState.compose env42120 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound42120 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env42121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40970,38160,10280,1025,32769,4161,33,17,8543,8192,64,43357,5393,4097,10281,1364,41341,257,33,46093,33281]

theorem envBound42121 : H12AffineFastState.Bounded env42121 := by
  intro p hp
  have h : env42121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42120_42121 : H12AffineEnvironment.transform 15 40970 env42120 = env42121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env42120 == env42121) = true)

theorem identity42121 : scanCanonicalize (H12AffineFastState.compose env42121 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42121 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,8202,5392,10280,1025,1,4161,33,17,8543,8192,64,10589,5393,4097,10281,1364,8573,257,33,13325,513]

theorem envBound42122 : H12AffineFastState.Bounded env42122 := by
  intro p hp
  have h : env42122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42121_42122 : H12AffineEnvironment.transform 14 0 env42121 = env42122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42121 == env42122) = true)

theorem identity42122 : scanCanonicalize (H12AffineFastState.compose env42122 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42122 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2420,1025,1,4161,33,17,3,348,64,2049,5393,4097,2421,1364,33,257,33,5457,513]

theorem envBound42123 : H12AffineFastState.Bounded env42123 := by
  intro p hp
  have h : env42123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42122_42123 : H12AffineEnvironment.transform 12 348 env42122 = env42123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42122 == env42123) = true)

theorem identity42123 : scanCanonicalize (H12AffineFastState.compose env42123 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42124 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4113,33,17,3,268,16,2049,5393,4097,2341,1284,33,257,33,5377,513]

theorem envBound42124 : H12AffineFastState.Bounded env42124 := by
  intro p hp
  have h : env42124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42123_42124 : H12AffineEnvironment.transform 5 16 env42123 = env42124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42123 == env42124) = true)

theorem identity42124 : scanCanonicalize (H12AffineFastState.compose env42124 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound42124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42125 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,48,268,1328,0,262,1312,2340,1025,1,33,33,17,3,268,16,2049,1313,49,2341,1284,33,257,33,1329,513]

theorem envBound42125 : H12AffineFastState.Bounded env42125 := by
  intro p hp
  have h : env42125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42124_42125 : H12AffineEnvironment.transform 11 48 env42124 = env42125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42124 == env42125) = true)

theorem identity42125 : scanCanonicalize (H12AffineFastState.compose env42125 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound42125 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42126 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1557,48,268,1328,0,262,1312,1841,1025,1,33,33,17,3,268,16,1556,1313,49,1840,1284,33,257,33,1329,513]

theorem envBound42126 : H12AffineFastState.Bounded env42126 := by
  intro p hp
  have h : env42126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42125_42126 : H12AffineEnvironment.transform 10 1557 env42125 = env42126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env42125 == env42126) = true)

theorem identity42126 : scanCanonicalize (H12AffineFastState.compose env42126 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound42126 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42127 : List Nat := [2,4,8,16,32,16,8,256,512,36,561,48,268,276,0,262,260,789,37,1,33,33,17,3,268,16,560,261,49,788,288,33,257,33,277,513]

theorem envBound42127 : H12AffineFastState.Bounded env42127 := by
  intro p hp
  have h : env42127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42126_42127 : H12AffineEnvironment.transform 9 36 env42126 = env42127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env42126 == env42127) = true)

theorem identity42127 : scanCanonicalize (H12AffineFastState.compose env42127 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound42127 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42128 : List Nat := [2,4,8,16,32,16,8,53,512,36,561,48,57,33,0,51,49,544,37,1,33,33,17,3,57,16,560,48,49,545,21,33,52,33,32,513]

theorem envBound42128 : H12AffineFastState.Bounded env42128 := by
  intro p hp
  have h : env42128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42127_42128 : H12AffineEnvironment.transform 7 53 env42127 = env42128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env42127 == env42128) = true)

theorem identity42128 : scanCanonicalize (H12AffineFastState.compose env42128 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42129 : List Nat := [2,4,2,16,32,16,2,53,512,36,561,48,51,33,0,51,49,544,37,1,33,33,17,3,51,16,560,48,49,545,21,33,52,33,32,513]

theorem envBound42129 : H12AffineFastState.Bounded env42129 := by
  intro p hp
  have h : env42129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42128_42129 : H12AffineEnvironment.transform 2 2 env42128 = env42129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42128 == env42129) = true)

theorem identity42129 : scanCanonicalize (H12AffineFastState.compose env42129 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42129 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42130 : List Nat := [2,4,2,16,32,16,2,53,33,36,16,48,51,33,0,51,49,1,37,1,33,33,17,3,51,16,17,48,49,0,21,33,52,33,32,32]

theorem envBound42130 : H12AffineFastState.Bounded env42130 := by
  intro p hp
  have h : env42130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42129_42130 : H12AffineEnvironment.transform 8 33 env42129 = env42130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42129 == env42130) = true)

theorem identity42130 : scanCanonicalize (H12AffineFastState.compose env42130 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42130 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env42131 : List Nat := [2,4,2,16,17,16,2,4,16,21,16,1,2,16,0,2,0,1,20,1,16,16,17,3,2,16,17,1,0,0,21,16,5,16,17,17]

theorem envBound42131 : H12AffineFastState.Bounded env42131 := by
  intro p hp
  have h : env42131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42130_42131 : H12AffineEnvironment.transform 4 17 env42130 = env42131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42130 == env42131) = true)

def env42132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272392,2101328,98644,8193,64,2157597,2098512,17665,2377025,2102548,2411541,257,21793,46092,2175562]

theorem envBound42132 : H12AffineFastState.Bounded env42132 := by
  intro p hp
  have h : env42132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42096_42132 : H12AffineEnvironment.transform 6 9 env42096 = env42132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42096 == env42132) = true)

theorem identity42132 : scanCanonicalize (H12AffineFastState.compose env42132 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 124235) := by decide +kernel

theorem selectedBound42132 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,124235,272392,128283,98644,8193,64,67926,122907,17665,368650,127071,338270,257,21793,46092,55041]

theorem envBound42133 : H12AffineFastState.Bounded env42133 := by
  intro p hp
  have h : env42133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42132_42133 : H12AffineEnvironment.transform 20 124235 env42132 = env42133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124235 env42132 == env42133) = true)

theorem identity42133 : scanCanonicalize (H12AffineFastState.compose env42133 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound42133 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,38161,262144,1025,32769,102679,272392,98631,98644,8193,64,67926,103495,12637,368650,99331,338270,257,8573,46092,41821]

theorem envBound42134 : H12AffineFastState.Bounded env42134 := by
  intro p hp
  have h : env42134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42133_42134 : H12AffineEnvironment.transform 13 13404 env42133 = env42134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env42133 == env42134) = true)

theorem identity42134 : scanCanonicalize (H12AffineFastState.compose env42134 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42134 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env42135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,65536,13389,262144,1025,8541,77899,272392,73755,73736,8193,64,67926,79131,12637,328022,75103,338270,257,8573,5456,513]

theorem envBound42135 : H12AffineFastState.Bounded env42135 := by
  intro p hp
  have h : env42135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42134_42135 : H12AffineEnvironment.transform 14 8540 env42134 = env42135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42134 == env42135) = true)

theorem identity42135 : scanCanonicalize (H12AffineFastState.compose env42135 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 68914) := by decide +kernel

theorem selectedBound42135 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,65536,13389,68914,1025,8541,77899,75066,73755,73736,8193,64,67926,79131,12637,3172,75103,9324,257,8573,5456,513]

theorem envBound42136 : H12AffineFastState.Bounded env42136 := by
  intro p hp
  have h : env42136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42135_42136 : H12AffineEnvironment.transform 17 68914 env42135 = env42136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68914 env42135 == env42136) = true)

theorem identity42136 : scanCanonicalize (H12AffineFastState.compose env42136 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound42136 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1296,65536,4097,68914,1025,1297,70663,65910,66647,66628,1101,64,67926,69975,5393,3172,65811,32,257,1329,5456,513]

theorem envBound42137 : H12AffineFastState.Bounded env42137 := by
  intro p hp
  have h : env42137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42136_42137 : H12AffineEnvironment.transform 12 1100 env42136 = env42137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env42136 == env42137) = true)

theorem identity42137 : scanCanonicalize (H12AffineFastState.compose env42137 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42137 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42138 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4112,1,65536,4097,67619,272,0,69910,65910,65862,65877,348,64,67926,69975,4096,2421,65811,32,257,32,4161,513]

theorem envBound42138 : H12AffineFastState.Bounded env42138 := by
  intro p hp
  have h : env42138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42137_42138 : H12AffineEnvironment.transform 9 273 env42137 = env42138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42137 == env42138) = true)

theorem identity42138 : scanCanonicalize (H12AffineFastState.compose env42138 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound42138 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42139 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,4112,1,342,4097,2421,272,0,4160,32,16,3,348,64,2048,4097,4096,2421,69,32,257,32,4161,513]

theorem envBound42139 : H12AffineFastState.Bounded env42139 := by
  intro p hp
  have h : env42139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42138_42139 : H12AffineEnvironment.transform 15 342 env42138 = env42139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env42138 == env42139) = true)

def env42140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603796,2098513,17664,2377160,2102685,6349852,257,21793,46213,2175562]

theorem envBound42140 : H12AffineFastState.Bounded env42140 := by
  intro p hp
  have h : env42140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42091_42140 : H12AffineEnvironment.transform 16 38297 env42091 = env42140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env42091 == env42140) = true)

def env42141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157716,2098513,17664,2377160,2102685,2411676,257,21793,46213,2175562]

theorem envBound42141 : H12AffineFastState.Bounded env42141 := by
  intro p hp
  have h : env42141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42140_42141 : H12AffineEnvironment.transform 21 272512 env42140 = env42141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42140 == env42141) = true)

theorem identity42141 : scanCanonicalize (H12AffineFastState.compose env42141 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound42141 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,58516,272512,62661,98780,8328,64,2048,57797,17664,303452,61705,272392,257,21793,46213,120542]

theorem envBound42142 : H12AffineFastState.Bounded env42142 := by
  intro p hp
  have h : env42142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42141_42142 : H12AffineEnvironment.transform 20 58516 env42141 = env42142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env42141 == env42142) = true)

def env42143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10280,1025,32769,58516,168,62661,98780,8328,64,2048,57797,17664,35188,61705,32,257,21793,46213,120542]

theorem envBound42143 : H12AffineFastState.Bounded env42143 := by
  intro p hp
  have h : env42143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42142_42143 : H12AffineEnvironment.transform 17 10280 env42142 = env42143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42142 == env42143) = true)

theorem identity42143 : scanCanonicalize (H12AffineFastState.compose env42143 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42143 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env42144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,5528,10280,1025,0,25749,168,29892,66013,8328,64,2048,25028,17664,2421,28936,32,257,21793,13444,87775]

theorem envBound42144 : H12AffineFastState.Bounded env42144 := by
  intro p hp
  have h : env42144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42143_42144 : H12AffineEnvironment.transform 14 1 env42143 = env42144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42143 == env42144) = true)

theorem identity42144 : scanCanonicalize (H12AffineFastState.compose env42144 (packedSelected [2,3,6,7,9,10,11,16,17,18,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42144 : packedSelected [2,3,6,7,9,10,11,16,17,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,5528,10280,1025,0,25749,168,29892,8662,8328,64,2048,25028,17664,2421,28936,32,257,21793,13444,30420]

theorem envBound42145 : H12AffineFastState.Bounded env42145 := by
  intro p hp
  have h : env42145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42144_42145 : H12AffineEnvironment.transform 15 8203 env42144 = env42145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42144 == env42145) = true)

theorem identity42145 : scanCanonicalize (H12AffineFastState.compose env42145 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound42145 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env42146 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,1,8203,5440,10280,1025,0,25677,112,29724,8462,8272,64,2048,24860,17664,2421,28936,32,257,21793,13404,30220]

theorem envBound42146 : H12AffineFastState.Bounded env42146 := by
  intro p hp
  have h : env42146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42145_42146 : H12AffineEnvironment.transform 6 88 env42145 = env42146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env42145 == env42146) = true)

theorem identity42146 : scanCanonicalize (H12AffineFastState.compose env42146 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42146 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env42147 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13325,1,8203,5440,10280,1025,0,4160,112,17,8462,8272,64,2048,5393,12557,2421,1285,32,257,8492,13404,513]

theorem envBound42147 : H12AffineFastState.Bounded env42147 := by
  intro p hp
  have h : env42147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42146_42147 : H12AffineEnvironment.transform 13 13325 env42146 = env42147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42146 == env42147) = true)

theorem identity42147 : scanCanonicalize (H12AffineFastState.compose env42147 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42147 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42148 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,8203,5392,10280,1025,0,4112,32,17,8462,8192,16,2048,5393,12557,2341,1285,32,257,8492,13324,513]

theorem envBound42148 : H12AffineFastState.Bounded env42148 := by
  intro p hp
  have h : env42148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42147_42148 : H12AffineEnvironment.transform 5 16 env42147 = env42148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42147 == env42148) = true)

theorem identity42148 : scanCanonicalize (H12AffineFastState.compose env42148 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound42148 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env42149 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,8192,8760,1,8203,805,10280,1025,0,1573,32,17,8462,8192,16,2048,804,10040,2341,1285,32,257,8492,8761,513]

theorem envBound42149 : H12AffineFastState.Bounded env42149 := by
  intro p hp
  have h : env42149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42148_42149 : H12AffineEnvironment.transform 11 1589 env42148 = env42149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env42148 == env42149) = true)

theorem identity42149 : scanCanonicalize (H12AffineFastState.compose env42149 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42149 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42150 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1589,269,821,1,262,805,2341,1025,0,1573,32,17,3,269,16,2048,804,1589,2341,1285,32,257,33,820,513]

theorem envBound42150 : H12AffineFastState.Bounded env42150 := by
  intro p hp
  have h : env42150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42149_42150 : H12AffineEnvironment.transform 12 269 env42149 = env42150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42149 == env42150) = true)

theorem identity42150 : scanCanonicalize (H12AffineFastState.compose env42150 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42151 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,545,269,821,1,262,805,2341,21,0,561,32,17,3,269,16,2048,804,545,2341,273,32,257,33,820,513]

theorem envBound42151 : H12AffineFastState.Bounded env42151 := by
  intro p hp
  have h : env42151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42150_42151 : H12AffineEnvironment.transform 9 20 env42150 = env42151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42150 == env42151) = true)

theorem identity42151 : scanCanonicalize (H12AffineFastState.compose env42151 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound42151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42152 : List Nat := [2,4,8,16,32,16,8,256,512,20,814,545,269,821,1,262,805,523,21,0,561,32,17,3,269,16,814,804,545,523,273,32,257,33,820,513]

theorem envBound42152 : H12AffineFastState.Bounded env42152 := by
  intro p hp
  have h : env42152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42151_42152 : H12AffineEnvironment.transform 10 814 env42151 = env42152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env42151 == env42152) = true)

theorem identity42152 : scanCanonicalize (H12AffineFastState.compose env42152 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound42152 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42153 : List Nat := [2,4,8,16,32,16,8,256,292,20,10,261,269,17,1,262,1,303,21,0,277,32,17,3,269,16,10,0,261,303,273,32,257,33,16,293]

theorem envBound42153 : H12AffineFastState.Bounded env42153 := by
  intro p hp
  have h : env42153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42152_42153 : H12AffineEnvironment.transform 8 292 env42152 = env42153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env42152 == env42153) = true)

theorem identity42153 : scanCanonicalize (H12AffineFastState.compose env42153 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42153 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42154 : List Nat := [2,4,8,16,1,16,8,256,261,20,10,261,269,17,1,262,1,270,21,0,277,1,17,3,269,16,10,0,261,270,273,1,257,0,16,260]

theorem envBound42154 : H12AffineFastState.Bounded env42154 := by
  intro p hp
  have h : env42154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42153_42154 : H12AffineEnvironment.transform 4 1 env42153 = env42154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42153 == env42154) = true)

theorem identity42154 : scanCanonicalize (H12AffineFastState.compose env42154 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound42154 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42155 : List Nat := [2,4,8,16,1,16,8,18,23,20,10,23,31,17,1,20,1,28,21,0,7,1,17,3,31,16,10,0,23,28,3,1,19,0,16,22]

theorem envBound42155 : H12AffineFastState.Bounded env42155 := by
  intro p hp
  have h : env42155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42154_42155 : H12AffineEnvironment.transform 7 18 env42154 = env42155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env42154 == env42155) = true)

def env42156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10281,1025,32769,58516,169,62661,98780,8328,64,2048,57797,17664,35189,61705,33,257,21793,46213,120542]

theorem envBound42156 : H12AffineFastState.Bounded env42156 := by
  intro p hp
  have h : env42156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42142_42156 : H12AffineEnvironment.transform 17 10281 env42142 = env42156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42142 == env42156) = true)

theorem identity42156 : scanCanonicalize (H12AffineFastState.compose env42156 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound42156 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env42157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1330,38297,10281,1025,32769,58516,169,62661,34030,8328,64,2048,57797,17664,35189,61705,33,257,21793,46213,54252]

theorem envBound42157 : H12AffineFastState.Bounded env42157 := by
  intro p hp
  have h : env42157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42156_42157 : H12AffineEnvironment.transform 15 1330 env42156 = env42157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env42156 == env42157) = true)

theorem identity42157 : scanCanonicalize (H12AffineFastState.compose env42157 (packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound42157 : packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS < 2^1333 := by decide +kernel

def env42158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,32768,1330,38297,10281,1025,32769,38280,169,34265,34030,8328,64,2048,37081,13340,35189,32789,33,257,9277,46213,41712]

theorem envBound42158 : H12AffineFastState.Bounded env42158 := by
  intro p hp
  have h : env42158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42157_42158 : H12AffineEnvironment.transform 13 12572 env42157 = env42158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env42157 == env42158) = true)

theorem identity42158 : scanCanonicalize (H12AffineFastState.compose env42158 (packedSelected [0,1,3,9,12,15,16,17,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound42158 : packedSelected [0,1,3,9,12,15,16,17,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env42159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,429,1330,5172,10281,1025,428,5157,169,1140,1347,8328,64,2048,4468,13340,2264,440,33,257,9277,13608,9053]

theorem envBound42159 : H12AffineFastState.Bounded env42159 := by
  intro p hp
  have h : env42159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42158_42159 : H12AffineEnvironment.transform 14 429 env42158 = env42159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env42158 == env42159) = true)

theorem identity42159 : scanCanonicalize (H12AffineFastState.compose env42159 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound42159 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,5236,429,1330,5172,3393,1025,428,5157,169,1140,1347,1504,64,2048,4468,4468,2264,440,33,257,341,4160,1589]

theorem envBound42160 : H12AffineFastState.Bounded env42160 := by
  intro p hp
  have h : env42160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42159_42160 : H12AffineEnvironment.transform 12 1384 env42159 = env42160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env42159 == env42160) = true)

theorem identity42160 : scanCanonicalize (H12AffineFastState.compose env42160 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42160 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5236,293,1330,5172,3393,1025,292,5157,33,1140,1347,1384,64,2048,4468,4468,2128,304,33,257,341,4160,1589]

theorem envBound42161 : H12AffineFastState.Bounded env42161 := by
  intro p hp
  have h : env42161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42160_42161 : H12AffineEnvironment.transform 6 8 env42160 = env42161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42160 == env42161) = true)

theorem identity42161 : scanCanonicalize (H12AffineFastState.compose env42161 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound42161 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42162 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,40,4404,293,114,4468,2049,321,292,4453,33,308,3,40,64,2048,4468,4468,2128,304,33,257,341,4160,885]

theorem envBound42162 : H12AffineFastState.Bounded env42162 := by
  intro p hp
  have h : env42162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42161_42162 : H12AffineEnvironment.transform 9 320 env42161 = env42162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42161 == env42162) = true)

def env42163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157717,2098513,17664,2377160,2102685,2411677,257,21793,46213,2175562]

theorem envBound42163 : H12AffineFastState.Bounded env42163 := by
  intro p hp
  have h : env42163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42140_42163 : H12AffineEnvironment.transform 21 272513 env42140 = env42163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42140 == env42163) = true)

theorem identity42163 : scanCanonicalize (H12AffineFastState.compose env42163 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound42163 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,262144,1025,29909,2097152,272513,2101329,95496,8328,64,2103361,2098513,17664,2377160,2102685,2373705,257,21793,16465,2175562]

theorem envBound42164 : H12AffineFastState.Bounded env42164 := by
  intro p hp
  have h : env42164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42163_42164 : H12AffineEnvironment.transform 14 29908 env42163 = env42164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env42163 == env42164) = true)

def env42165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,262144,1025,8661,2097152,272513,2101329,73736,8328,64,2103361,2098513,4096,2363592,2102685,2373705,257,33,5457,2175562]

theorem envBound42165 : H12AffineFastState.Bounded env42165 := by
  intro p hp
  have h : env42165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42164_42165 : H12AffineEnvironment.transform 13 5376 env42164 = env42165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42164 == env42165) = true)

theorem identity42165 : scanCanonicalize (H12AffineFastState.compose env42165 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 333923) := by decide +kernel

theorem selectedBound42165 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env42166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,262144,1025,8661,333923,272513,329778,73736,8328,64,327714,335154,4096,67755,331262,73770,257,33,5457,272937]

theorem envBound42166 : H12AffineFastState.Bounded env42166 := by
  intro p hp
  have h : env42166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42165_42166 : H12AffineEnvironment.transform 20 333923 env42165 = env42166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 333923 env42165 == env42166) = true)

theorem identity42166 : scanCanonicalize (H12AffineFastState.compose env42166 (packedSelected [0,1,2,5,6,8,11,14,17,18,19,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound42166 : packedSelected [0,1,2,5,6,8,11,14,17,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,2421,1025,8661,69910,8692,65863,73736,8328,64,67927,70727,4096,67755,66699,73770,257,33,5457,9052]

theorem envBound42167 : H12AffineFastState.Bounded env42167 := by
  intro p hp
  have h : env42167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42166_42167 : H12AffineEnvironment.transform 17 2421 env42166 = env42167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env42166 == env42167) = true)

theorem identity42167 : scanCanonicalize (H12AffineFastState.compose env42167 (packedSelected [0,2,3,4,5,6,7,8,9,11,14,17,18,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42167 : packedSelected [0,2,3,4,5,6,7,8,9,11,14,17,18,28] rootPS < 2^1333 := by decide +kernel

def env42168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,2421,1025,8541,69910,8572,65863,73736,8192,64,67927,70727,4096,67619,66563,73770,257,33,5457,9052]

theorem envBound42168 : H12AffineFastState.Bounded env42168 := by
  intro p hp
  have h : env42168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42167_42168 : H12AffineEnvironment.transform 6 8 env42167 = env42168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42167 == env42168) = true)

theorem identity42168 : scanCanonicalize (H12AffineFastState.compose env42168 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound42168 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,343,13389,2421,1025,8541,4161,8572,16,8543,8192,64,2048,5392,4096,2420,1364,8573,257,33,5457,9052]

theorem envBound42169 : H12AffineFastState.Bounded env42169 := by
  intro p hp
  have h : env42169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42168_42169 : H12AffineEnvironment.transform 15 343 env42168 = env42169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env42168 == env42169) = true)

theorem identity42169 : scanCanonicalize (H12AffineFastState.compose env42169 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound42169 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2341,8192,3109,8540,343,11624,2421,1025,8541,2404,8572,16,8543,8192,64,2048,3125,2341,2420,1364,8573,257,33,3188,9052]

theorem envBound42170 : H12AffineFastState.Bounded env42170 := by
  intro p hp
  have h : env42170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42169_42170 : H12AffineEnvironment.transform 11 2341 env42169 = env42170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env42169 == env42170) = true)

theorem identity42170 : scanCanonicalize (H12AffineFastState.compose env42170 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42170 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env42171 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2341,8192,3109,8493,294,11545,2308,1025,8492,2325,8461,16,8494,8192,49,2048,3125,2341,2309,1317,8460,257,33,3077,9005]

theorem envBound42171 : H12AffineFastState.Bounded env42171 := by
  intro p hp
  have h : env42171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42170_42171 : H12AffineEnvironment.transform 5 49 env42170 = env42171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42170 == env42171) = true)

theorem identity42171 : scanCanonicalize (H12AffineFastState.compose env42171 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42171 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42172 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2341,269,3109,32,294,3092,2308,1025,33,2325,0,16,35,269,49,2048,3125,2341,2309,1317,1,257,33,3077,544]

theorem envBound42172 : H12AffineFastState.Bounded env42172 := by
  intro p hp
  have h : env42172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42171_42172 : H12AffineEnvironment.transform 12 269 env42171 = env42172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42171 == env42172) = true)

theorem identity42172 : scanCanonicalize (H12AffineFastState.compose env42172 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42172 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42173 : List Nat := [2,4,8,16,32,49,8,256,512,20,2048,2341,269,2097,32,294,2048,2308,21,33,2325,0,16,35,269,49,2048,2081,2341,2309,305,1,257,33,2065,544]

theorem envBound42173 : H12AffineFastState.Bounded env42173 := by
  intro p hp
  have h : env42173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42172_42173 : H12AffineEnvironment.transform 9 20 env42172 = env42173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42172 == env42173) = true)

theorem identity42173 : scanCanonicalize (H12AffineFastState.compose env42173 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound42173 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42174 : List Nat := [2,4,8,16,32,49,8,256,512,20,277,48,269,292,32,294,277,17,21,33,0,0,16,35,269,49,277,308,48,16,305,1,257,33,260,544]

theorem envBound42174 : H12AffineFastState.Bounded env42174 := by
  intro p hp
  have h : env42174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42173_42174 : H12AffineEnvironment.transform 10 277 env42173 = env42174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env42173 == env42174) = true)

theorem identity42174 : scanCanonicalize (H12AffineFastState.compose env42174 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound42174 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42175 : List Nat := [2,4,8,16,32,49,8,52,512,20,33,48,57,16,32,18,33,17,21,33,0,0,16,35,57,49,33,0,48,16,5,1,53,33,48,544]

theorem envBound42175 : H12AffineFastState.Bounded env42175 := by
  intro p hp
  have h : env42175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42174_42175 : H12AffineEnvironment.transform 7 52 env42174 = env42175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env42174 == env42175) = true)

def env42176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13388,262144,1025,8660,2097152,272513,2101329,73737,8328,64,2103361,2098513,4097,2363593,2102685,2373705,257,32,5456,2175562]

theorem envBound42176 : H12AffineFastState.Bounded env42176 := by
  intro p hp
  have h : env42176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42164_42176 : H12AffineEnvironment.transform 13 5377 env42164 = env42176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42164 == env42176) = true)

theorem identity42176 : scanCanonicalize (H12AffineFastState.compose env42176 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound42176 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env42177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,478,13388,262144,1025,8660,2097152,272513,2101329,8663,8328,64,2103361,2098513,4097,2363593,2102685,2373705,257,32,5456,2110356]

theorem envBound42177 : H12AffineFastState.Bounded env42177 := by
  intro p hp
  have h : env42177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42176_42177 : H12AffineEnvironment.transform 15 478 env42176 = env42177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env42176 == env42177) = true)

theorem identity42177 : scanCanonicalize (H12AffineFastState.compose env42177 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound42177 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env42178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,478,13388,262144,1025,8660,276584,272513,272441,8663,8328,64,270377,277817,4097,10401,273909,33,257,32,5456,265212]

theorem envBound42178 : H12AffineFastState.Bounded env42178 := by
  intro p hp
  have h : env42178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42177_42178 : H12AffineEnvironment.transform 20 276584 env42177 = env42178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env42177 == env42178) = true)

theorem identity42178 : scanCanonicalize (H12AffineFastState.compose env42178 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42178 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env42179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,478,13388,10281,1025,8660,4161,168,16,8663,8328,64,2048,5392,4097,10401,1500,33,257,32,5456,9173]

theorem envBound42179 : H12AffineFastState.Bounded env42179 := by
  intro p hp
  have h : env42179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42178_42179 : H12AffineEnvironment.transform 17 10281 env42178 = env42179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42178 == env42179) = true)

theorem identity42179 : scanCanonicalize (H12AffineFastState.compose env42179 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound42179 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,5377,1296,478,4233,3308,1025,1297,4161,168,16,1298,1101,64,2048,5392,4097,3172,1500,33,257,32,5456,1808]

theorem envBound42180 : H12AffineFastState.Bounded env42180 := by
  intro p hp
  have h : env42180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42179_42180 : H12AffineEnvironment.transform 12 1221 env42179 = env42180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env42179 == env42180) = true)

theorem identity42180 : scanCanonicalize (H12AffineFastState.compose env42180 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42180 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env42181 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,241,4405,292,478,4233,2264,53,293,4161,168,16,294,121,64,2048,4388,4097,2128,488,33,257,32,4452,804]

theorem envBound42181 : H12AffineFastState.Bounded env42181 := by
  intro p hp
  have h : env42181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42180_42181 : H12AffineEnvironment.transform 9 52 env42180 = env42181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42180 == env42181) = true)

theorem identity42181 : scanCanonicalize (H12AffineFastState.compose env42181 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound42181 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42182 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,41,4405,292,262,4177,2048,53,293,4161,112,16,294,121,64,2048,4388,4097,2128,304,33,257,32,4452,804]

theorem envBound42182 : H12AffineFastState.Bounded env42182 := by
  intro p hp
  have h : env42182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42181_42182 : H12AffineEnvironment.transform 6 88 env42181 = env42182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env42181 == env42182) = true)

theorem identity42182 : scanCanonicalize (H12AffineFastState.compose env42182 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound42182 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42183 : List Nat := [2,4,8,16,32,48,40,256,512,52,2048,4096,41,4405,292,262,4129,2048,53,293,4145,0,16,294,9,48,2048,4388,4097,2080,304,33,257,32,4372,804]

theorem envBound42183 : H12AffineFastState.Bounded env42183 := by
  intro p hp
  have h : env42183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42182_42183 : H12AffineEnvironment.transform 5 48 env42182 = env42183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env42182 == env42183) = true)

theorem identity42183 : scanCanonicalize (H12AffineFastState.compose env42183 (packedSelected [0,2,4,7,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42183 : packedSelected [0,2,4,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env42184 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,4096,41,4113,0,34,4129,2048,53,1,4145,0,16,2,9,48,2048,4096,4097,2080,20,33,37,32,4144,512]

theorem envBound42184 : H12AffineFastState.Bounded env42184 := by
  intro p hp
  have h : env42184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42183_42184 : H12AffineEnvironment.transform 7 36 env42183 = env42184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42183 == env42184) = true)

theorem identity42184 : scanCanonicalize (H12AffineFastState.compose env42184 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound42184 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42185 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,2097,41,2080,0,34,2064,2048,53,1,2048,0,16,2,9,48,2048,2097,2096,2080,20,33,37,32,2049,512]

theorem envBound42185 : H12AffineFastState.Bounded env42185 := by
  intro p hp
  have h : env42185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42184_42185 : H12AffineEnvironment.transform 11 2097 env42184 = env42185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env42184 == env42185) = true)

theorem identity42185 : scanCanonicalize (H12AffineFastState.compose env42185 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42185 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env42186 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,0,2,2064,2048,21,1,2048,0,16,2,9,16,2048,2065,2064,2048,20,1,5,0,2049,512]

theorem envBound42186 : H12AffineFastState.Bounded env42186 := by
  intro p hp
  have h : env42186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42185_42186 : H12AffineEnvironment.transform 4 0 env42185 = env42186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42185 == env42186) = true)

def env42187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound42187 : H12AffineFastState.Bounded env42187 := by
  intro p hp
  have h : env42187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41284_42187 : H12AffineEnvironment.transform 25 65 env41284 = env42187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env41284 == env42187) = true)

def env42188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound42188 : H12AffineFastState.Bounded env42188 := by
  intro p hp
  have h : env42188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42187_42188 : H12AffineEnvironment.transform 26 30393344 env42187 = env42188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env42187 == env42188) = true)

def env42189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound42189 : H12AffineFastState.Bounded env42189 := by
  intro p hp
  have h : env42189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42188_42189 : H12AffineEnvironment.transform 18 1024 env42188 = env42189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42188 == env42189) = true)

theorem identity42189 : scanCanonicalize (H12AffineFastState.compose env42189 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898728) := by decide +kernel

theorem selectedBound42189 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898728,8328,65,4196520,10898468,10507600,8830976,412857,15117673,256,2493444,2551200,486254]

theorem envBound42190 : H12AffineFastState.Bounded env42190 := by
  intro p hp
  have h : env42190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42189_42190 : H12AffineEnvironment.transform 23 8898728 env42189 = env42190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898728 env42189 == env42190) = true)

def env42191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,8388608,8898728,8328,65,4196520,8393984,8785012,8830976,412857,12645453,256,21792,46212,486254]

theorem envBound42191 : H12AffineFastState.Bounded env42191 := by
  intro p hp
  have h : env42191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42190_42191 : H12AffineEnvironment.transform 20 416036 env42190 = env42191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416036 env42190 == env42191) = true)

def env42192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441760,95496,8328,65,4196520,436384,45524,32160,412857,4606445,256,21792,46212,486254]

theorem envBound42192 : H12AffineFastState.Bounded env42192 := by
  intro p hp
  have h : env42192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42191_42192 : H12AffineEnvironment.transform 22 441760 env42191 = env42192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env42191 == env42192) = true)

def env42193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441760,95496,8328,65,270376,436384,45524,32160,412857,156013,256,21792,46212,486254]

theorem envBound42193 : H12AffineFastState.Bounded env42193 := by
  intro p hp
  have h : env42193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42192_42193 : H12AffineEnvironment.transform 21 272512 env42192 = env42193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42192 == env42193) = true)

theorem identity42193 : scanCanonicalize (H12AffineFastState.compose env42193 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound42193 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,156133,62661,95496,8328,65,158029,57797,45524,32160,1500,156013,256,21792,46212,74251]

theorem envBound42194 : H12AffineFastState.Bounded env42194 := by
  intro p hp
  have h : env42194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42193_42194 : H12AffineEnvironment.transform 17 149861 env42193 = env42194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env42193 == env42194) = true)

theorem identity42194 : scanCanonicalize (H12AffineFastState.compose env42194 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42194 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,156133,62661,21762,8328,65,158029,57797,45524,32160,1500,156013,256,21792,46212,513]

theorem envBound42195 : H12AffineFastState.Bounded env42195 := by
  intro p hp
  have h : env42195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42194_42195 : H12AffineEnvironment.transform 15 8202 env42194 = env42195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42194 == env42195) = true)

theorem identity42195 : scanCanonicalize (H12AffineFastState.compose env42195 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound42195 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env42196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5528,23805,1024,32769,4161,29821,62661,21762,8328,65,31957,57797,45524,32160,1500,29941,256,21792,46212,513]

theorem envBound42196 : H12AffineFastState.Bounded env42196 := by
  intro p hp
  have h : env42196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42195_42196 : H12AffineEnvironment.transform 16 5528 env42195 = env42196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env42195 == env42196) = true)

theorem identity42196 : scanCanonicalize (H12AffineFastState.compose env42196 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42196 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env42197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8202,5528,23805,1024,21761,4161,29821,8645,21762,8328,65,31957,13509,25812,32160,1500,29941,256,21792,24964,513]

theorem envBound42197 : H12AffineFastState.Bounded env42197 := by
  intro p hp
  have h : env42197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42196_42197 : H12AffineEnvironment.transform 14 21760 env42196 = env42197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42196 == env42197) = true)

theorem identity42197 : scanCanonicalize (H12AffineFastState.compose env42197 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound42197 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env42198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,479,5528,23805,1024,21761,4161,21928,16,21762,349,65,23808,5392,17665,23669,1500,21792,256,21792,16465,513]

theorem envBound42198 : H12AffineFastState.Bounded env42198 := by
  intro p hp
  have h : env42198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42197_42198 : H12AffineEnvironment.transform 12 469 env42197 = env42198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env42197 == env42198) = true)

theorem identity42198 : scanCanonicalize (H12AffineFastState.compose env42198 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound42198 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env42199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,509,479,5528,2048,1024,508,4161,341,16,511,349,65,2557,5392,4604,2184,1500,477,256,477,5292,513]

theorem envBound42199 : H12AffineFastState.Bounded env42199 := by
  intro p hp
  have h : env42199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42198_42199 : H12AffineEnvironment.transform 13 5373 env42198 = env42199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env42198 == env42199) = true)

theorem identity42199 : scanCanonicalize (H12AffineFastState.compose env42199 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42199 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,373,343,5392,2048,1024,372,4161,341,16,375,349,65,2421,5392,4468,2048,1364,341,256,341,5156,513]

theorem envBound42200 : H12AffineFastState.Bounded env42200 := by
  intro p hp
  have h : env42200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42199_42200 : H12AffineEnvironment.transform 6 8 env42199 = env42200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42199 == env42200) = true)

theorem identity42200 : scanCanonicalize (H12AffineFastState.compose env42200 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42200 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env42201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,349,5237,373,343,5392,1,1024,372,4161,341,16,375,349,65,372,5392,4468,1,1364,341,256,341,5156,513]

theorem envBound42201 : H12AffineFastState.Bounded env42201 := by
  intro p hp
  have h : env42201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42200_42201 : H12AffineEnvironment.transform 10 1 env42200 = env42201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42200 == env42201) = true)

theorem identity42201 : scanCanonicalize (H12AffineFastState.compose env42201 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42201 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42202 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,41,5237,1,35,5220,1,1024,0,4161,33,16,3,41,65,0,5220,4096,1,1056,33,116,33,5156,513]

theorem envBound42202 : H12AffineFastState.Bounded env42202 := by
  intro p hp
  have h : env42202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42201_42202 : H12AffineEnvironment.transform 7 116 env42201 = env42202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42201 == env42202) = true)

theorem identity42202 : scanCanonicalize (H12AffineFastState.compose env42202 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound42202 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42203 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,1061,41,80,1,35,65,1,1024,0,1124,33,16,3,41,65,0,65,1061,1,1056,33,116,33,1,513]

theorem envBound42203 : H12AffineFastState.Bounded env42203 := by
  intro p hp
  have h : env42203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42202_42203 : H12AffineEnvironment.transform 11 1061 env42202 = env42203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env42202 == env42203) = true)

theorem identity42203 : scanCanonicalize (H12AffineFastState.compose env42203 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound42203 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42204 : List Nat := [2,4,8,16,32,64,8,116,512,101,1,64,41,80,1,35,65,1,101,0,1,33,16,3,41,65,0,65,64,1,69,33,116,33,1,513]

theorem envBound42204 : H12AffineFastState.Bounded env42204 := by
  intro p hp
  have h : env42204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42203_42204 : H12AffineEnvironment.transform 9 101 env42203 = env42204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env42203 == env42204) = true)

theorem identity42204 : scanCanonicalize (H12AffineFastState.compose env42204 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42205 : List Nat := [2,4,8,16,32,64,8,116,64,101,1,64,41,80,1,35,65,1,101,0,1,33,16,3,41,65,0,65,64,1,69,33,116,33,1,65]

theorem envBound42205 : H12AffineFastState.Bounded env42205 := by
  intro p hp
  have h : env42205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42204_42205 : H12AffineEnvironment.transform 8 64 env42204 = env42205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42204 == env42205) = true)

theorem identity42205 : scanCanonicalize (H12AffineFastState.compose env42205 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42205 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42206 : List Nat := [2,4,2,16,32,64,2,116,64,101,1,64,35,80,1,35,65,1,101,0,1,33,16,3,35,65,0,65,64,1,69,33,116,33,1,65]

theorem envBound42206 : H12AffineFastState.Bounded env42206 := by
  intro p hp
  have h : env42206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42205_42206 : H12AffineEnvironment.transform 2 2 env42205 = env42206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42205 == env42206) = true)

def env42207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441760,95496,8328,65,270377,436384,45524,32160,412857,156012,256,21792,46212,486254]

theorem envBound42207 : H12AffineFastState.Bounded env42207 := by
  intro p hp
  have h : env42207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42192_42207 : H12AffineEnvironment.transform 21 272513 env42192 = env42207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42192 == env42207) = true)

theorem identity42207 : scanCanonicalize (H12AffineFastState.compose env42207 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound42207 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416036,272513,412021,95496,8328,65,270377,416885,17665,32160,412857,156012,256,21792,16465,486254]

theorem envBound42208 : H12AffineFastState.Bounded env42208 := by
  intro p hp
  have h : env42208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42207_42208 : H12AffineEnvironment.transform 14 29909 env42207 = env42208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env42207 == env42208) = true)

def env42209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,160132,33,156117,95496,8328,65,2185,160981,17665,32160,156697,156012,256,21792,16465,213966]

theorem envBound42209 : H12AffineFastState.Bounded env42209 := by
  intro p hp
  have h : env42209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42208_42209 : H12AffineEnvironment.transform 17 10400 env42208 = env42209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env42208 == env42209) = true)

theorem identity42209 : scanCanonicalize (H12AffineFastState.compose env42209 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound42209 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env42210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,131072,10400,1024,29908,160132,33,156117,29910,8328,65,2185,160981,17665,32160,156697,156012,256,21792,16465,147984]

theorem envBound42210 : H12AffineFastState.Bounded env42210 := by
  intro p hp
  have h : env42210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42209_42210 : H12AffineEnvironment.transform 15 478 env42209 = env42210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env42209 == env42210) = true)

theorem identity42210 : scanCanonicalize (H12AffineFastState.compose env42210 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42210 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,131072,10280,1024,29788,160012,33,155997,29790,8192,65,2049,160861,17665,32040,156697,156012,256,21792,16465,147984]

theorem envBound42211 : H12AffineFastState.Bounded env42211 := by
  intro p hp
  have h : env42211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42210_42211 : H12AffineEnvironment.transform 6 8 env42210 = env42211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42210 == env42211) = true)

theorem identity42211 : scanCanonicalize (H12AffineFastState.compose env42211 (packedSelected [1,2,5,6,8,9,11,12,14,15,22,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42211 : packedSelected [1,2,5,6,8,9,11,12,14,15,22,23,24] rootPS < 2^1333 := by decide +kernel

def env42212 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,263,131072,10280,1024,29709,160012,33,155916,29711,8192,16,2049,160780,17665,32040,156697,155965,256,21792,16384,147984]

theorem envBound42212 : H12AffineFastState.Bounded env42212 := by
  intro p hp
  have h : env42212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42211_42212 : H12AffineEnvironment.transform 5 17 env42211 = env42212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42211 == env42212) = true)

def env42213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,160133,32,156116,95496,8328,65,2184,160980,17665,32160,156696,156012,256,21792,16465,213967]

theorem envBound42213 : H12AffineFastState.Bounded env42213 := by
  intro p hp
  have h : env42213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42208_42213 : H12AffineEnvironment.transform 17 10401 env42208 = env42213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env42208 == env42213) = true)

theorem identity42213 : scanCanonicalize (H12AffineFastState.compose env42213 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound42213 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env42214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21795,131072,10401,1024,29908,160133,32,156116,8235,8328,65,2184,160980,17665,32160,156696,156012,256,21792,16465,136940]

theorem envBound42214 : H12AffineFastState.Bounded env42214 := by
  intro p hp
  have h : env42214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42213_42214 : H12AffineEnvironment.transform 15 21795 env42213 = env42214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env42213 == env42214) = true)

theorem identity42214 : scanCanonicalize (H12AffineFastState.compose env42214 (packedSelected [1,4,9,11,14,18,19,20,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound42214 : packedSelected [1,4,9,11,14,18,19,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env42215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21795,25028,10401,1024,29908,4161,32,16,8235,8328,65,2184,5392,17665,32160,1500,168,256,21792,16465,30504]

theorem envBound42215 : H12AffineFastState.Bounded env42215 := by
  intro p hp
  have h : env42215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42214_42215 : H12AffineEnvironment.transform 16 25028 env42214 = env42215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env42214 == env42215) = true)

theorem identity42215 : scanCanonicalize (H12AffineFastState.compose env42215 (packedSelected [0,1,3,6,7,8,9,10,11,12,15,16,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 208) := by decide +kernel

theorem selectedBound42215 : packedSelected [0,1,3,6,7,8,9,10,11,12,15,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env42216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,208,16384,21509,21795,16660,2161,1024,21508,4161,32,16,251,88,65,2184,5392,17665,23920,1500,168,256,21792,16465,22520]

theorem envBound42216 : H12AffineFastState.Bounded env42216 := by
  intro p hp
  have h : env42216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42215_42216 : H12AffineEnvironment.transform 12 208 env42215 = env42216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env42215 == env42216) = true)

theorem identity42216 : scanCanonicalize (H12AffineFastState.compose env42216 (packedSelected [1,3,4,5,6,8,10,14,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5341) := by decide +kernel

theorem selectedBound42216 : packedSelected [1,3,4,5,6,8,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,208,5341,216,510,5577,2161,1024,217,4161,32,16,251,88,65,2184,5392,4572,2477,1500,168,256,509,5260,805]

theorem envBound42217 : H12AffineFastState.Bounded env42217 := by
  intro p hp
  have h : env42217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42216_42217 : H12AffineEnvironment.transform 13 5341 env42216 = env42217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5341 env42216 == env42217) = true)

theorem identity42217 : scanCanonicalize (H12AffineFastState.compose env42217 (packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound42217 : packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env42218 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,5341,216,3,5172,2161,1024,217,4161,32,16,251,88,65,2184,5357,4129,2128,1057,168,253,0,5260,728]

theorem envBound42218 : H12AffineFastState.Bounded env42218 := by
  intro p hp
  have h : env42218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42217_42218 : H12AffineEnvironment.transform 7 253 env42217 = env42218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env42217 == env42218) = true)

theorem identity42218 : scanCanonicalize (H12AffineFastState.compose env42218 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound42218 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42219 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,9,5124,1,3,5172,2161,1024,0,4161,32,16,34,88,65,2129,5172,4129,2128,1057,113,36,0,5205,513]

theorem envBound42219 : H12AffineFastState.Bounded env42219 := by
  intro p hp
  have h : env42219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42218_42219 : H12AffineEnvironment.transform 6 89 env42218 = env42219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env42218 == env42219) = true)

theorem identity42219 : scanCanonicalize (H12AffineFastState.compose env42219 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42219 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42220 : List Nat := [2,4,8,16,1,64,89,5,512,1024,2048,4096,9,5124,1,3,5141,2128,1024,0,4161,1,16,3,88,65,2129,5141,4096,2128,1024,80,5,0,5205,513]

theorem envBound42220 : H12AffineFastState.Bounded env42220 := by
  intro p hp
  have h : env42220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42219_42220 : H12AffineEnvironment.transform 4 1 env42219 = env42220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42219 == env42220) = true)

theorem identity42220 : scanCanonicalize (H12AffineFastState.compose env42220 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound42220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42221 : List Nat := [2,4,8,16,1,64,89,5,512,1024,2048,1029,9,1,1,3,16,2128,1024,0,1092,1,16,3,88,65,2129,16,1029,2128,1024,80,5,0,80,513]

theorem envBound42221 : H12AffineFastState.Bounded env42221 := by
  intro p hp
  have h : env42221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42220_42221 : H12AffineEnvironment.transform 11 1029 env42220 = env42221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env42220 == env42221) = true)

theorem identity42221 : scanCanonicalize (H12AffineFastState.compose env42221 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound42221 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42222 : List Nat := [2,4,8,16,1,64,89,5,512,68,2048,65,9,1,1,3,16,2128,68,0,0,1,16,3,88,65,2129,16,65,2128,68,80,5,0,80,513]

theorem envBound42222 : H12AffineFastState.Bounded env42222 := by
  intro p hp
  have h : env42222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42221_42222 : H12AffineEnvironment.transform 9 68 env42221 = env42222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env42221 == env42222) = true)

theorem identity42222 : scanCanonicalize (H12AffineFastState.compose env42222 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound42222 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42223 : List Nat := [2,4,8,16,1,64,89,5,81,68,2048,65,9,1,1,3,16,2128,68,0,0,1,16,3,88,65,2129,16,65,2128,68,80,5,0,80,80]

theorem envBound42223 : H12AffineFastState.Bounded env42223 := by
  intro p hp
  have h : env42223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42222_42223 : H12AffineEnvironment.transform 8 81 env42222 = env42223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env42222 == env42223) = true)

theorem identity42223 : scanCanonicalize (H12AffineFastState.compose env42223 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42223 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env42224 : List Nat := [2,4,8,16,1,64,89,5,81,68,0,65,9,1,1,3,16,80,68,0,0,1,16,3,88,65,81,16,65,80,68,80,5,0,80,80]

theorem envBound42224 : H12AffineFastState.Bounded env42224 := by
  intro p hp
  have h : env42224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42223_42224 : H12AffineEnvironment.transform 10 0 env42223 = env42224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42223 == env42224) = true)

theorem identity42224 : scanCanonicalize (H12AffineFastState.compose env42224 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42225 : List Nat := [2,4,8,16,1,0,25,5,17,4,0,1,9,1,1,3,16,16,4,0,0,1,16,3,24,1,17,16,1,16,4,16,5,0,16,16]

theorem envBound42225 : H12AffineFastState.Bounded env42225 := by
  intro p hp
  have h : env42225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42224_42225 : H12AffineEnvironment.transform 5 0 env42224 = env42225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42224 == env42225) = true)

theorem identity42225 : scanCanonicalize (H12AffineFastState.compose env42225 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42225 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env42226 : List Nat := [2,4,8,1,1,0,8,5,0,4,0,1,9,1,1,3,1,1,4,0,0,1,1,3,9,1,0,1,1,1,4,1,5,0,1,1]

theorem envBound42226 : H12AffineFastState.Bounded env42226 := by
  intro p hp
  have h : env42226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42225_42226 : H12AffineEnvironment.transform 3 1 env42225 = env42226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42225 == env42226) = true)

def env42227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441761,95497,8328,65,4196520,436385,45525,32161,412857,4606444,256,21792,46212,486254]

theorem envBound42227 : H12AffineFastState.Bounded env42227 := by
  intro p hp
  have h : env42227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42191_42227 : H12AffineEnvironment.transform 22 441761 env42191 = env42227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env42191 == env42227) = true)

def env42228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441761,95497,8328,65,270376,436385,45525,32161,412857,156012,256,21792,46212,486254]

theorem envBound42228 : H12AffineFastState.Bounded env42228 := by
  intro p hp
  have h : env42228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42227_42228 : H12AffineEnvironment.transform 21 272512 env42227 = env42228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42227 == env42228) = true)

theorem identity42228 : scanCanonicalize (H12AffineFastState.compose env42228 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound42228 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,58517,169265,16,95497,8328,65,171417,5392,45525,32161,61704,156012,256,21792,46212,120543]

theorem envBound42229 : H12AffineFastState.Bounded env42229 := by
  intro p hp
  have h : env42229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42228_42229 : H12AffineEnvironment.transform 17 179633 env42228 = env42229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env42228 == env42229) = true)

def env42230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169265,16,95497,8192,65,171281,5392,45405,32041,61704,156012,256,21792,46092,120407]

theorem envBound42230 : H12AffineFastState.Bounded env42230 := by
  intro p hp
  have h : env42230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42229_42230 : H12AffineEnvironment.transform 6 8 env42229 = env42230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42229 == env42230) = true)

theorem identity42230 : scanCanonicalize (H12AffineFastState.compose env42230 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound42230 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,58397,32,16,95497,8192,65,2048,5392,45405,32041,61704,62589,256,21792,46092,120407]

theorem envBound42231 : H12AffineFastState.Bounded env42231 := by
  intro p hp
  have h : env42231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42230_42231 : H12AffineEnvironment.transform 16 38161 env42230 = env42231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42230 == env42231) = true)

theorem identity42231 : scanCanonicalize (H12AffineFastState.compose env42231 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound42231 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,38161,10280,1024,32769,58397,32,16,8542,8192,65,2048,5392,45405,32041,61704,62589,256,21792,46092,33280]

theorem envBound42232 : H12AffineFastState.Bounded env42232 := by
  intro p hp
  have h : env42232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42231_42232 : H12AffineEnvironment.transform 15 21591 env42231 = env42232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env42231 == env42232) = true)

theorem identity42232 : scanCanonicalize (H12AffineFastState.compose env42232 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42232 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21591,16400,10280,1024,21760,12572,32,16,8542,8192,65,2048,5392,25692,32041,9225,8572,256,21792,24845,22273]

theorem envBound42233 : H12AffineFastState.Bounded env42233 := by
  intro p hp
  have h : env42233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42232_42233 : H12AffineEnvironment.transform 14 21761 env42232 = env42233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42232 == env42233) = true)

theorem identity42233 : scanCanonicalize (H12AffineFastState.compose env42233 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42233 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env42234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21591,16400,2420,1024,21760,4160,32,16,2,348,65,2048,5392,17664,23669,1365,32,256,21792,16465,22273]

theorem envBound42234 : H12AffineFastState.Bounded env42234 := by
  intro p hp
  have h : env42234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42233_42234 : H12AffineEnvironment.transform 12 348 env42233 = env42234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42233 == env42234) = true)

theorem identity42234 : scanCanonicalize (H12AffineFastState.compose env42234 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound42234 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env42235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5205,340,2,5189,2420,1024,341,4160,32,16,2,348,65,2048,5392,4437,2080,1365,32,256,373,5124,852]

theorem envBound42235 : H12AffineFastState.Bounded env42235 := by
  intro p hp
  have h : env42235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42234_42235 : H12AffineEnvironment.transform 13 5205 env42234 = env42235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env42234 == env42235) = true)

theorem identity42235 : scanCanonicalize (H12AffineFastState.compose env42235 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42235 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env42236 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8,5205,0,2,5189,2080,1024,1,4160,32,16,2,8,65,2048,5188,4097,2080,1025,32,84,33,5124,512]

theorem envBound42236 : H12AffineFastState.Bounded env42236 := by
  intro p hp
  have h : env42236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42235_42236 : H12AffineEnvironment.transform 7 84 env42235 = env42236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42235 == env42236) = true)

theorem identity42236 : scanCanonicalize (H12AffineFastState.compose env42236 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42236 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42237 : List Nat := [2,4,8,16,32,64,8,84,512,20,2048,4096,8,4161,0,2,4177,2080,20,1,4160,32,16,2,8,65,2048,4176,4097,2080,21,32,84,33,4112,512]

theorem envBound42237 : H12AffineFastState.Bounded env42237 := by
  intro p hp
  have h : env42237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42236_42237 : H12AffineEnvironment.transform 9 20 env42236 = env42237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42236 == env42237) = true)

theorem identity42237 : scanCanonicalize (H12AffineFastState.compose env42237 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound42237 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42238 : List Nat := [2,4,8,16,32,64,8,84,512,20,2048,49,8,112,0,2,96,2080,20,1,113,32,16,2,8,65,2048,97,48,2080,21,32,84,33,33,512]

theorem envBound42238 : H12AffineFastState.Bounded env42238 := by
  intro p hp
  have h : env42238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42237_42238 : H12AffineEnvironment.transform 11 49 env42237 = env42238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42237 == env42238) = true)

theorem identity42238 : scanCanonicalize (H12AffineFastState.compose env42238 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42238 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42239 : List Nat := [2,4,8,16,1,64,8,84,512,20,2048,16,8,81,0,2,65,2049,20,1,80,1,16,2,8,65,2048,64,17,2049,21,1,84,0,0,512]

theorem envBound42239 : H12AffineFastState.Bounded env42239 := by
  intro p hp
  have h : env42239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42238_42239 : H12AffineEnvironment.transform 4 1 env42238 = env42239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42238 == env42239) = true)

theorem identity42239 : scanCanonicalize (H12AffineFastState.compose env42239 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42239 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42240 : List Nat := [2,4,8,16,1,64,8,84,1,20,2048,16,8,81,0,2,65,2049,20,1,80,1,16,2,8,65,2048,64,17,2049,21,1,84,0,0,1]

theorem envBound42240 : H12AffineFastState.Bounded env42240 := by
  intro p hp
  have h : env42240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42239_42240 : H12AffineEnvironment.transform 8 1 env42239 = env42240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42239 == env42240) = true)

theorem identity42240 : scanCanonicalize (H12AffineFastState.compose env42240 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound42240 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42241 : List Nat := [2,4,8,16,1,64,8,84,1,20,81,16,8,81,0,2,65,80,20,1,80,1,16,2,8,65,81,64,17,80,21,1,84,0,0,1]

theorem envBound42241 : H12AffineFastState.Bounded env42241 := by
  intro p hp
  have h : env42241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42240_42241 : H12AffineEnvironment.transform 10 81 env42240 = env42241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env42240 == env42241) = true)

theorem identity42241 : scanCanonicalize (H12AffineFastState.compose env42241 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42241 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42242 : List Nat := [2,4,8,16,1,16,8,4,1,20,1,16,8,1,0,2,17,0,20,1,0,1,16,2,8,17,1,16,17,0,21,1,4,0,0,1]

theorem envBound42242 : H12AffineFastState.Bounded env42242 := by
  intro p hp
  have h : env42242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42241_42242 : H12AffineEnvironment.transform 5 16 env42241 = env42242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42241 == env42242) = true)

theorem identity42242 : scanCanonicalize (H12AffineFastState.compose env42242 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound42242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42243 : List Nat := [2,4,6,16,1,16,6,4,1,20,1,16,6,1,0,2,17,0,20,1,0,1,16,2,6,17,1,16,17,0,21,1,4,0,0,1]

theorem envBound42243 : H12AffineFastState.Bounded env42243 := by
  intro p hp
  have h : env42243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42242_42243 : H12AffineEnvironment.transform 2 6 env42242 = env42243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env42242 == env42243) = true)

def env42244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169265,16,95497,8193,65,171280,5392,45404,32040,61704,156012,256,21792,46093,120406]

theorem envBound42244 : H12AffineFastState.Bounded env42244 := by
  intro p hp
  have h : env42244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42229_42244 : H12AffineEnvironment.transform 6 9 env42229 = env42244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42229 == env42244) = true)

theorem identity42244 : scanCanonicalize (H12AffineFastState.compose env42244 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound42244 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35189,1024,32769,58396,41340,16,95497,8193,65,43357,5392,45404,32040,61704,21793,256,21792,46093,120406]

theorem envBound42245 : H12AffineFastState.Bounded env42245 := by
  intro p hp
  have h : env42245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42244_42245 : H12AffineEnvironment.transform 16 13389 env42244 = env42245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env42244 == env42245) = true)

def env42246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441761,95497,8328,65,270377,436385,45525,32161,412857,156013,256,21792,46212,486254]

theorem envBound42246 : H12AffineFastState.Bounded env42246 := by
  intro p hp
  have h : env42246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42227_42246 : H12AffineEnvironment.transform 21 272513 env42227 = env42246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42227 == env42246) = true)

def env42247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441641,95497,8192,65,270377,436265,45405,32041,412721,156013,256,21792,46092,486254]

theorem envBound42247 : H12AffineFastState.Bounded env42247 := by
  intro p hp
  have h : env42247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42246_42247 : H12AffineEnvironment.transform 6 8 env42246 = env42247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42246 == env42247) = true)

def env42248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272441,95497,8192,65,270377,277817,45405,32041,317729,62589,256,21792,46092,392830]

theorem envBound42248 : H12AffineFastState.Bounded env42248 := by
  intro p hp
  have h : env42248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42247_42248 : H12AffineEnvironment.transform 16 38160 env42247 = env42248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42247 == env42248) = true)

theorem identity42248 : scanCanonicalize (H12AffineFastState.compose env42248 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,58396,33,17,95497,8192,65,2049,5393,45405,32041,61705,62589,256,21792,46092,120406]

theorem envBound42249 : H12AffineFastState.Bounded env42249 := by
  intro p hp
  have h : env42249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42248_42249 : H12AffineEnvironment.transform 17 10280 env42248 = env42249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42248 == env42249) = true)

theorem identity42249 : scanCanonicalize (H12AffineFastState.compose env42249 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42249 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10280,1024,32769,45340,33,17,73737,8192,65,2049,5393,45405,10281,41993,41341,256,32,46092,99158]

theorem envBound42250 : H12AffineFastState.Bounded env42250 := by
  intro p hp
  have h : env42250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42249_42250 : H12AffineEnvironment.transform 13 5376 env42249 = env42250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42249 == env42250) = true)

theorem identity42250 : scanCanonicalize (H12AffineFastState.compose env42250 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42250 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env42251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13388,10280,1024,8541,4160,33,17,73737,8192,65,2049,5393,4097,10281,1365,33,256,32,5456,74250]

theorem envBound42251 : H12AffineFastState.Bounded env42251 := by
  intro p hp
  have h : env42251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42250_42251 : H12AffineEnvironment.transform 14 8540 env42250 = env42251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42250 == env42251) = true)

theorem identity42251 : scanCanonicalize (H12AffineFastState.compose env42251 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound42251 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8282,13388,10280,1024,8541,4160,33,17,83,8192,65,2049,5393,4097,10281,1365,33,256,32,5456,592]

theorem envBound42252 : H12AffineFastState.Bounded env42252 := by
  intro p hp
  have h : env42252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42251_42252 : H12AffineEnvironment.transform 15 8282 env42251 = env42252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env42251 == env42252) = true)

theorem identity42252 : scanCanonicalize (H12AffineFastState.compose env42252 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42252 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42253 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10280,1024,8461,4112,33,17,3,8192,17,2049,5393,4097,10281,1285,33,256,32,5376,512]

theorem envBound42253 : H12AffineFastState.Bounded env42253 := by
  intro p hp
  have h : env42253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42252_42253 : H12AffineEnvironment.transform 5 16 env42252 = env42253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42252 == env42253) = true)

theorem identity42253 : scanCanonicalize (H12AffineFastState.compose env42253 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound42253 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42254 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,5376,33,295,5425,2309,1024,32,4112,33,17,3,301,17,2049,5393,4097,2308,1285,33,256,32,5376,512]

theorem envBound42254 : H12AffineFastState.Bounded env42254 := by
  intro p hp
  have h : env42254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42253_42254 : H12AffineEnvironment.transform 12 301 env42253 = env42254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env42253 == env42254) = true)

theorem identity42254 : scanCanonicalize (H12AffineFastState.compose env42254 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound42254 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42255 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,301,0,33,295,49,2309,1024,32,1296,33,17,3,301,17,2049,17,1281,2308,1285,33,256,32,0,512]

theorem envBound42255 : H12AffineFastState.Bounded env42255 := by
  intro p hp
  have h : env42255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42254_42255 : H12AffineEnvironment.transform 11 1280 env42254 = env42255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env42254 == env42255) = true)

theorem identity42255 : scanCanonicalize (H12AffineFastState.compose env42255 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound42255 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42256 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1328,1280,301,0,33,295,49,1077,1024,32,1296,33,17,3,301,17,1329,17,1281,1076,1285,33,256,32,0,512]

theorem envBound42256 : H12AffineFastState.Bounded env42256 := by
  intro p hp
  have h : env42256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42255_42256 : H12AffineEnvironment.transform 10 1328 env42255 = env42256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env42255 == env42256) = true)

theorem identity42256 : scanCanonicalize (H12AffineFastState.compose env42256 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42256 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env42257 : List Nat := [2,4,8,16,32,16,8,256,512,52,260,308,301,0,33,295,49,1,52,32,292,33,17,3,301,17,261,17,309,0,305,33,256,32,0,512]

theorem envBound42257 : H12AffineFastState.Bounded env42257 := by
  intro p hp
  have h : env42257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42256_42257 : H12AffineEnvironment.transform 9 52 env42256 = env42257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42256 == env42257) = true)

theorem identity42257 : scanCanonicalize (H12AffineFastState.compose env42257 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42257 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42258 : List Nat := [2,4,8,1,32,1,8,256,512,37,260,293,301,0,33,295,32,1,37,32,292,33,0,3,301,0,261,0,292,0,288,33,256,32,0,512]

theorem envBound42258 : H12AffineFastState.Bounded env42258 := by
  intro p hp
  have h : env42258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42257_42258 : H12AffineEnvironment.transform 3 1 env42257 = env42258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42257 == env42258) = true)

theorem identity42258 : scanCanonicalize (H12AffineFastState.compose env42258 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42258 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42259 : List Nat := [2,4,8,1,32,1,8,256,33,37,260,293,301,0,33,295,32,1,37,32,292,33,0,3,301,0,261,0,292,0,288,33,256,32,0,33]

theorem envBound42259 : H12AffineFastState.Bounded env42259 := by
  intro p hp
  have h : env42259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42258_42259 : H12AffineEnvironment.transform 8 33 env42258 = env42259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42258 == env42259) = true)

theorem identity42259 : scanCanonicalize (H12AffineFastState.compose env42259 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42259 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42260 : List Nat := [2,4,8,1,1,1,8,256,0,4,260,260,268,0,0,262,1,1,4,1,261,0,0,3,268,0,261,0,261,0,257,0,256,1,0,0]

theorem envBound42260 : H12AffineFastState.Bounded env42260 := by
  intro p hp
  have h : env42260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42259_42260 : H12AffineEnvironment.transform 4 1 env42259 = env42260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42259 == env42260) = true)

def env42261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272440,95497,8192,65,270377,277816,45405,32041,317728,62588,256,21792,46092,392831]

theorem envBound42261 : H12AffineFastState.Bounded env42261 := by
  intro p hp
  have h : env42261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42247_42261 : H12AffineEnvironment.transform 16 38161 env42247 = env42261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42247 == env42261) = true)

theorem identity42261 : scanCanonicalize (H12AffineFastState.compose env42261 (packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42261 : packedSelected [0,5,7,9,11,12,14,18,20,22,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env42262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1024,32769,314421,272393,272440,21762,8192,65,270377,277816,45405,32041,317728,62588,256,21792,46092,319092]

theorem envBound42262 : H12AffineFastState.Bounded env42262 := by
  intro p hp
  have h : env42262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42261_42262 : H12AffineEnvironment.transform 15 8203 env42261 = env42262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42261 == env42262) = true)

theorem identity42262 : scanCanonicalize (H12AffineFastState.compose env42262 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound42262 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env42263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,43049,1024,32769,25628,32800,32785,21762,8192,65,34816,38161,45405,32041,28937,62588,256,21792,46092,30301]

theorem envBound42263 : H12AffineFastState.Bounded env42263 := by
  intro p hp
  have h : env42263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42262_42263 : H12AffineEnvironment.transform 17 43049 env42262 = env42263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env42262 == env42263) = true)

theorem identity42263 : scanCanonicalize (H12AffineFastState.compose env42263 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42263 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24908,23668,1024,29788,25628,29821,29772,21762,8192,65,31837,24908,17664,32041,28937,33,256,21792,16465,30301]

theorem envBound42264 : H12AffineFastState.Bounded env42264 := by
  intro p hp
  have h : env42264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42263_42264 : H12AffineEnvironment.transform 14 29789 env42263 = env42264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42263 == env42264) = true)

theorem identity42264 : scanCanonicalize (H12AffineFastState.compose env42264 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42264 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env42265 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,24860,23588,1024,29708,25628,29741,29724,21762,8192,17,31757,24860,17664,32041,28937,33,256,21792,16385,30221]

theorem envBound42265 : H12AffineFastState.Bounded env42265 := by
  intro p hp
  have h : env42265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42264_42265 : H12AffineEnvironment.transform 5 16 env42264 = env42265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42264 == env42265) = true)

theorem identity42265 : scanCanonicalize (H12AffineFastState.compose env42265 (packedSelected [0,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound42265 : packedSelected [0,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42266 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,12344,1077,8203,4388,11292,1024,1076,5156,1045,1060,9530,8192,17,3125,4388,13624,3345,305,33,256,9496,12345,1589]

theorem envBound42266 : H12AffineFastState.Bounded env42266 := by
  intro p hp
  have h : env42266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42265_42266 : H12AffineEnvironment.transform 13 12344 env42265 = env42266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env42265 == env42266) = true)

theorem identity42266 : scanCanonicalize (H12AffineFastState.compose env42266 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42266 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env42267 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,12344,0,8203,4388,10281,53,1,4113,32,17,8463,8192,17,2048,4388,12557,2340,305,33,256,8493,12345,512]

theorem envBound42267 : H12AffineFastState.Bounded env42267 := by
  intro p hp
  have h : env42267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42266_42267 : H12AffineEnvironment.transform 9 53 env42266 = env42267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42266 == env42267) = true)

theorem identity42267 : scanCanonicalize (H12AffineFastState.compose env42267 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound42267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42268 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,301,4373,0,294,4388,2308,53,1,4113,32,17,34,301,17,2048,4388,4128,2340,305,33,256,0,4372,512]

theorem envBound42268 : H12AffineFastState.Bounded env42268 := by
  intro p hp
  have h : env42268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42267_42268 : H12AffineEnvironment.transform 12 301 env42267 = env42268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env42267 == env42268) = true)

theorem identity42268 : scanCanonicalize (H12AffineFastState.compose env42268 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42268 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env42269 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,9,4145,0,2,4096,2080,53,1,4113,32,17,34,9,17,2048,4096,4128,2048,21,33,36,0,4144,512]

theorem envBound42269 : H12AffineFastState.Bounded env42269 := by
  intro p hp
  have h : env42269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42268_42269 : H12AffineEnvironment.transform 7 36 env42268 = env42269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42268 == env42269) = true)

theorem identity42269 : scanCanonicalize (H12AffineFastState.compose env42269 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound42269 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42270 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2096,9,2049,0,2,2096,2080,53,1,2081,32,17,34,9,17,2048,2096,2064,2048,21,33,36,0,2048,512]

theorem envBound42270 : H12AffineFastState.Bounded env42270 := by
  intro p hp
  have h : env42270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42269_42270 : H12AffineEnvironment.transform 11 2096 env42269 = env42270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env42269 == env42270) = true)

def env42271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272392,441640,95497,8193,65,270377,436264,45404,32040,412720,156013,256,21792,46093,486254]

theorem envBound42271 : H12AffineFastState.Bounded env42271 := by
  intro p hp
  have h : env42271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42246_42271 : H12AffineEnvironment.transform 6 9 env42246 = env42271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42246 == env42271) = true)

def env42272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272392,272440,95497,8193,65,270377,277816,45404,32040,317728,62589,256,21792,46093,392830]

theorem envBound42272 : H12AffineFastState.Bounded env42272 := by
  intro p hp
  have h : env42272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42271_42272 : H12AffineEnvironment.transform 16 38160 env42271 = env42272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42271 == env42272) = true)

theorem identity42272 : scanCanonicalize (H12AffineFastState.compose env42272 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound42272 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1024,32769,17729,41341,41293,95497,8193,65,43356,46157,45404,32040,20565,62589,256,21792,46093,96011]

theorem envBound42273 : H12AffineFastState.Bounded env42273 := by
  intro p hp
  have h : env42273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42272_42273 : H12AffineEnvironment.transform 17 35189 env42272 = env42273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env42272 == env42273) = true)

theorem identity42273 : scanCanonicalize (H12AffineFastState.compose env42273 (packedSelected [7,8,10,12,14,15,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound42273 : packedSelected [7,8,10,12,14,15,20,27,28] rootPS < 2^1333 := by decide +kernel

def env42274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,65536,38160,35189,1024,32769,12393,41341,41293,65569,8193,65,43356,46157,45404,2048,9597,33109,256,8200,46093,66083]

theorem envBound42274 : H12AffineFastState.Bounded env42274 := by
  intro p hp
  have h : env42274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42273_42274 : H12AffineEnvironment.transform 13 13608 env42273 = env42274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env42273 == env42274) = true)

theorem identity42274 : scanCanonicalize (H12AffineFastState.compose env42274 (packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42274 : packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,1,65536,5393,2420,1024,0,12393,8572,8524,65569,8193,65,10589,13388,12637,2048,9597,340,256,8200,13324,66083]

theorem envBound42275 : H12AffineFastState.Bounded env42275 := by
  intro p hp
  have h : env42275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42274_42275 : H12AffineEnvironment.transform 14 1 env42274 = env42275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42274 == env42275) = true)

theorem identity42275 : scanCanonicalize (H12AffineFastState.compose env42275 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42275 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,1,8203,5393,2420,1024,0,12393,8572,8524,8234,8193,65,10589,13388,12637,2048,9597,340,256,8200,13324,8744]

theorem envBound42276 : H12AffineFastState.Bounded env42276 := by
  intro p hp
  have h : env42276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42275_42276 : H12AffineEnvironment.transform 15 8203 env42275 = env42276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42275 == env42276) = true)

theorem identity42276 : scanCanonicalize (H12AffineFastState.compose env42276 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42276 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,1,262,5393,2420,1024,0,4452,113,65,295,268,65,2128,5441,4176,2048,1136,340,256,261,5377,805]

theorem envBound42277 : H12AffineFastState.Bounded env42277 := by
  intro p hp
  have h : env42277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42276_42277 : H12AffineEnvironment.transform 12 269 env42276 = env42277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42276 == env42277) = true)

theorem identity42277 : scanCanonicalize (H12AffineFastState.compose env42277 (packedSelected [4,6,7,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound42277 : packedSelected [4,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42278 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,269,4160,1,262,4468,2420,101,0,4452,113,65,295,268,65,2128,4388,4176,2048,21,340,256,261,4452,805]

theorem envBound42278 : H12AffineFastState.Bounded env42278 := by
  intro p hp
  have h : env42278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42277_42278 : H12AffineEnvironment.transform 9 101 env42277 = env42278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env42277 == env42278) = true)

theorem identity42278 : scanCanonicalize (H12AffineFastState.compose env42278 (packedSelected [3,4,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound42278 : packedSelected [3,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env42279 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2404,269,2340,1,262,2064,2420,101,0,2048,113,65,295,268,65,2128,2112,2356,2048,21,340,256,261,2048,805]

theorem envBound42279 : H12AffineFastState.Bounded env42279 := by
  intro p hp
  have h : env42279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42278_42279 : H12AffineEnvironment.transform 11 2404 env42278 = env42279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env42278 == env42279) = true)

theorem identity42279 : scanCanonicalize (H12AffineFastState.compose env42279 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42279 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42280 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,121,2128,1,114,2064,2048,101,0,2048,113,65,83,120,65,2128,2112,2112,2048,21,32,116,113,2048,593]

theorem envBound42280 : H12AffineFastState.Bounded env42280 := by
  intro p hp
  have h : env42280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42279_42280 : H12AffineEnvironment.transform 7 116 env42279 = env42280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42279 == env42280) = true)

theorem identity42280 : scanCanonicalize (H12AffineFastState.compose env42280 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound42280 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env42281 : List Nat := [2,4,8,16,32,64,9,116,80,101,2048,2064,121,2128,1,114,2064,2048,101,0,2048,113,65,83,120,65,2128,2112,2112,2048,21,32,116,113,2048,1]

theorem envBound42281 : H12AffineFastState.Bounded env42281 := by
  intro p hp
  have h : env42281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42280_42281 : H12AffineEnvironment.transform 8 80 env42280 = env42281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env42280 == env42281) = true)

theorem identity42281 : scanCanonicalize (H12AffineFastState.compose env42281 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42281 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env42282 : List Nat := [2,4,8,16,32,16,9,36,0,53,2048,2064,41,2048,1,34,2064,2048,53,0,2048,33,17,3,40,17,2048,2064,2064,2048,21,32,36,33,2048,1]

theorem envBound42282 : H12AffineFastState.Bounded env42282 := by
  intro p hp
  have h : env42282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42281_42282 : H12AffineEnvironment.transform 5 16 env42281 = env42282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42281 == env42282) = true)

def env42283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272392,272441,95497,8193,65,270377,277817,45404,32040,317729,62588,256,21792,46093,392831]

theorem envBound42283 : H12AffineFastState.Bounded env42283 := by
  intro p hp
  have h : env42283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42271_42283 : H12AffineEnvironment.transform 16 38161 env42271 = env42283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42271 == env42283) = true)

theorem identity42283 : scanCanonicalize (H12AffineFastState.compose env42283 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,13389,262144,1024,8541,290153,272392,272441,95497,8193,65,270377,277817,4096,32040,292989,21792,256,21792,5457,352035]

theorem envBound42284 : H12AffineFastState.Bounded env42284 := by
  intro p hp
  have h : env42284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42283_42284 : H12AffineEnvironment.transform 14 8540 env42283 = env42284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42283 == env42284) = true)

theorem identity42284 : scanCanonicalize (H12AffineFastState.compose env42284 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42284 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env42285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,13389,262144,1024,8541,290153,272392,272441,21763,8193,65,270377,277817,4096,32040,292989,21792,256,21792,5457,294697]

theorem envBound42285 : H12AffineFastState.Bounded env42285 := by
  intro p hp
  have h : env42285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42284_42285 : H12AffineEnvironment.transform 15 8202 env42284 = env42285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42284 == env42285) = true)

theorem identity42285 : scanCanonicalize (H12AffineFastState.compose env42285 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 31869) := by decide +kernel

theorem selectedBound42285 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env42286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,13389,31869,1024,8541,4372,21621,21572,21763,8193,65,23636,16708,4096,32040,1024,21792,256,21792,5457,852]

theorem envBound42286 : H12AffineFastState.Bounded env42286 := by
  intro p hp
  have h : env42286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42285_42286 : H12AffineEnvironment.transform 17 31869 env42285 = env42286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31869 env42285 == env42286) = true)

theorem identity42286 : scanCanonicalize (H12AffineFastState.compose env42286 (packedSelected [0,3,5,7,9,10,12,14,15,16,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound42286 : packedSelected [0,3,5,7,9,10,12,14,15,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env42287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5408,8540,8202,13389,10589,1024,8541,4372,341,356,35,8193,65,2420,5220,4096,10248,1024,0,256,0,5457,852]

theorem envBound42287 : H12AffineFastState.Bounded env42287 := by
  intro p hp
  have h : env42287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42286_42287 : H12AffineEnvironment.transform 13 5408 env42286 = env42287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env42286 == env42287) = true)

theorem identity42287 : scanCanonicalize (H12AffineFastState.compose env42287 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42287 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env42288 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5205,8233,8202,13389,10280,1024,8232,4193,32,17,35,8193,65,2049,5220,4096,10248,1024,0,117,0,5156,545]

theorem envBound42288 : H12AffineFastState.Bounded env42288 := by
  intro p hp
  have h : env42288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42287_42288 : H12AffineEnvironment.transform 7 117 env42287 = env42288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42287 == env42288) = true)

theorem identity42288 : scanCanonicalize (H12AffineFastState.compose env42288 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42288 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42289 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5124,8233,8202,13340,10280,1024,8232,4144,32,17,35,8193,16,2049,5173,4096,10248,1024,0,36,0,5156,545]

theorem envBound42289 : H12AffineFastState.Bounded env42289 := by
  intro p hp
  have h : env42289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42288_42289 : H12AffineEnvironment.transform 5 17 env42288 = env42289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42288 == env42289) = true)

theorem identity42289 : scanCanonicalize (H12AffineFastState.compose env42289 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42289 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42290 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5124,0,35,5173,2049,1024,1,4144,32,17,35,40,16,2049,5173,4096,2081,1024,0,36,0,5156,545]

theorem envBound42290 : H12AffineFastState.Bounded env42290 := by
  intro p hp
  have h : env42290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42289_42290 : H12AffineEnvironment.transform 12 41 env42289 = env42290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42289 == env42290) = true)

theorem identity42290 : scanCanonicalize (H12AffineFastState.compose env42290 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound42290 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env42291 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1045,41,17,0,35,32,2049,1024,1,1061,32,17,35,40,16,2049,32,1045,2081,1024,0,36,0,49,545]

theorem envBound42291 : H12AffineFastState.Bounded env42291 := by
  intro p hp
  have h : env42291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42290_42291 : H12AffineEnvironment.transform 11 1045 env42290 = env42291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env42290 == env42291) = true)

theorem identity42291 : scanCanonicalize (H12AffineFastState.compose env42291 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound42291 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env42292 : List Nat := [2,4,8,16,32,17,9,36,512,548,2048,561,41,17,0,35,32,2049,548,1,513,32,17,35,40,16,2049,32,561,2081,548,0,36,0,49,545]

theorem envBound42292 : H12AffineFastState.Bounded env42292 := by
  intro p hp
  have h : env42292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42291_42292 : H12AffineEnvironment.transform 9 548 env42291 = env42292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env42291 == env42292) = true)

theorem identity42292 : scanCanonicalize (H12AffineFastState.compose env42292 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound42292 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42293 : List Nat := [2,4,8,16,32,17,9,36,512,548,544,561,41,17,0,35,32,545,548,1,513,32,17,35,40,16,545,32,561,513,548,0,36,0,49,545]

theorem envBound42293 : H12AffineFastState.Bounded env42293 := by
  intro p hp
  have h : env42293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42292_42293 : H12AffineEnvironment.transform 10 544 env42292 = env42293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env42292 == env42293) = true)

theorem identity42293 : scanCanonicalize (H12AffineFastState.compose env42293 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound42293 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42294 : List Nat := [2,4,8,16,32,17,9,36,49,21,17,0,41,17,0,35,32,16,21,1,48,32,17,35,40,16,16,32,0,48,21,0,36,0,49,16]

theorem envBound42294 : H12AffineFastState.Bounded env42294 := by
  intro p hp
  have h : env42294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42293_42294 : H12AffineEnvironment.transform 8 49 env42293 = env42294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env42293 == env42294) = true)

theorem identity42294 : scanCanonicalize (H12AffineFastState.compose env42294 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42295 : List Nat := [2,4,8,1,32,0,9,36,32,4,0,0,41,0,0,35,32,1,4,1,33,32,0,35,40,1,1,32,0,33,4,0,36,0,32,1]

theorem envBound42295 : H12AffineFastState.Bounded env42295 := by
  intro p hp
  have h : env42295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42294_42295 : H12AffineEnvironment.transform 3 1 env42294 = env42295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42294 == env42295) = true)

theorem identity42295 : scanCanonicalize (H12AffineFastState.compose env42295 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42295 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42296 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,0,9,0,0,3,0,1,4,1,1,0,0,3,8,1,1,0,0,1,4,0,4,0,0,1]

theorem envBound42296 : H12AffineFastState.Bounded env42296 := by
  intro p hp
  have h : env42296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42295_42296 : H12AffineEnvironment.transform 4 0 env42295 = env42296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42295 == env42296) = true)

theorem identity42296 : scanCanonicalize (H12AffineFastState.compose env42296 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42297 : List Nat := [2,4,3,1,0,0,2,4,0,4,0,0,2,0,0,3,0,1,4,1,1,0,0,3,3,1,1,0,0,1,4,0,4,0,0,1]

theorem envBound42297 : H12AffineFastState.Bounded env42297 := by
  intro p hp
  have h : env42297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42296_42297 : H12AffineEnvironment.transform 2 3 env42296 = env42297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42296 == env42297) = true)

def env42298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,8388608,8898728,8328,65,4196520,8393985,8785013,8830976,412857,12645452,256,21793,46213,486254]

theorem envBound42298 : H12AffineFastState.Bounded env42298 := by
  intro p hp
  have h : env42298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42190_42298 : H12AffineEnvironment.transform 20 416037 env42190 = env42298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416037 env42190 == env42298) = true)

def env42299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441760,95496,8328,65,4196520,436385,45525,32160,412857,4606444,256,21793,46213,486254]

theorem envBound42299 : H12AffineFastState.Bounded env42299 := by
  intro p hp
  have h : env42299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42298_42299 : H12AffineEnvironment.transform 22 441760 env42298 = env42299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env42298 == env42299) = true)

def env42300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441760,95496,8328,65,270376,436385,45525,32160,412857,156012,256,21793,46213,486254]

theorem envBound42300 : H12AffineFastState.Bounded env42300 := by
  intro p hp
  have h : env42300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42299_42300 : H12AffineEnvironment.transform 21 272512 env42299 = env42300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42299 == env42300) = true)

theorem identity42300 : scanCanonicalize (H12AffineFastState.compose env42300 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound42300 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,416037,272512,441760,41431,8328,65,270376,436385,45525,32160,412857,156012,256,21793,46213,442289]

theorem envBound42301 : H12AffineFastState.Bounded env42301 := by
  intro p hp
  have h : env42301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42300_42301 : H12AffineEnvironment.transform 15 54495 env42300 = env42301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env42300 == env42301) = true)

def env42302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272392,441640,41311,8192,65,270376,436265,45405,32040,412721,156012,256,21793,46093,442169]

theorem envBound42302 : H12AffineFastState.Bounded env42302 := by
  intro p hp
  have h : env42302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42301_42302 : H12AffineEnvironment.transform 6 8 env42301 = env42302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42301 == env42302) = true)

theorem identity42302 : scanCanonicalize (H12AffineFastState.compose env42302 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound42302 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env42303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1024,32769,140301,21792,180224,41311,8192,65,23808,185601,45405,32040,143641,156012,256,21793,46093,180753]

theorem envBound42303 : H12AffineFastState.Bounded env42303 := by
  intro p hp
  have h : env42303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42302_42303 : H12AffineEnvironment.transform 17 32040 env42302 = env42303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env42302 == env42303) = true)

theorem identity42303 : scanCanonicalize (H12AffineFastState.compose env42303 (packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42303 : packedSelected [5,7,12,14,15,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env42304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,131072,32040,1024,8540,140301,21792,155997,2,8192,65,23808,160860,4096,32040,143641,156012,256,21793,5456,156492]

theorem envBound42304 : H12AffineFastState.Bounded env42304 := by
  intro p hp
  have h : env42304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42303_42304 : H12AffineEnvironment.transform 14 8541 env42303 = env42304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42303 == env42304) = true)

theorem identity42304 : scanCanonicalize (H12AffineFastState.compose env42304 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42304 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21590,131072,23668,1024,0,132433,21792,147457,2,348,65,23808,152832,4096,23668,135237,147504,256,21793,5456,147984]

theorem envBound42305 : H12AffineFastState.Bounded env42305 := by
  intro p hp
  have h : env42305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42304_42305 : H12AffineEnvironment.transform 12 348 env42304 = env42305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42304 == env42305) = true)

theorem identity42305 : scanCanonicalize (H12AffineFastState.compose env42305 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound42305 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21590,5393,23668,1024,0,4160,21792,21776,2,348,65,23808,16401,4096,23668,1364,21793,256,21793,5456,22273]

theorem envBound42306 : H12AffineFastState.Bounded env42306 := by
  intro p hp
  have h : env42306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42305_42306 : H12AffineEnvironment.transform 16 5393 env42305 = env42306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env42305 == env42306) = true)

theorem identity42306 : scanCanonicalize (H12AffineFastState.compose env42306 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42306 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42307 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,16384,1,21590,5221,23668,1024,0,4160,21588,21604,2,40,65,23668,16401,4096,23668,1056,21589,116,21589,5156,22133]

theorem envBound42307 : H12AffineFastState.Bounded env42307 := by
  intro p hp
  have h : env42307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42306_42307 : H12AffineEnvironment.transform 7 116 env42306 = env42307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42306 == env42307) = true)

theorem identity42307 : scanCanonicalize (H12AffineFastState.compose env42307 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 7205) := by decide +kernel

theorem selectedBound42307 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42308 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,7205,1,2163,5221,81,1024,0,4160,2161,2113,2,40,65,81,7220,4096,81,1056,2160,116,2160,5156,2640]

theorem envBound42308 : H12AffineFastState.Bounded env42308 := by
  intro p hp
  have h : env42308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42307_42308 : H12AffineEnvironment.transform 13 7205 env42307 = env42308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7205 env42307 == env42308) = true)

theorem identity42308 : scanCanonicalize (H12AffineFastState.compose env42308 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42308 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env42309 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,40,6161,1,2163,4177,81,52,0,4160,2161,2113,2,40,65,81,6144,4096,81,20,2160,116,2160,4112,2640]

theorem envBound42309 : H12AffineFastState.Bounded env42309 := by
  intro p hp
  have h : env42309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42308_42309 : H12AffineEnvironment.transform 9 52 env42308 = env42309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42308 == env42309) = true)

def env42310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272393,441641,41310,8193,65,270376,436264,45404,32041,412720,156012,256,21793,46092,442168]

theorem envBound42310 : H12AffineFastState.Bounded env42310 := by
  intro p hp
  have h : env42310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42301_42310 : H12AffineEnvironment.transform 6 9 env42301 = env42310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42301 == env42310) = true)

theorem identity42310 : scanCanonicalize (H12AffineFastState.compose env42310 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound42310 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env42311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,2049,1024,32769,151844,8200,177448,41310,8193,65,10281,172073,45404,32041,148529,156012,256,21793,46092,177977]

theorem envBound42311 : H12AffineFastState.Bounded env42311 := by
  intro p hp
  have h : env42311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42310_42311 : H12AffineEnvironment.transform 17 2049 env42310 = env42311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env42310 == env42311) = true)

theorem identity42311 : scanCanonicalize (H12AffineFastState.compose env42311 (packedSelected [1,2,3,4,6,7,10,14,16,19,20,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound42311 : packedSelected [1,2,3,4,6,7,10,14,16,19,20,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env42312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,2049,1024,32769,37172,8200,30008,41310,8193,65,10281,24633,45404,32041,33825,41340,256,21793,46092,30505]

theorem envBound42312 : H12AffineFastState.Bounded env42312 := by
  intro p hp
  have h : env42312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42311_42312 : H12AffineEnvironment.transform 16 49168 env42311 = env42312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env42311 == env42312) = true)

theorem identity42312 : scanCanonicalize (H12AffineFastState.compose env42312 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound42312 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env42313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,32768,41262,46440,2049,1024,32769,37172,8200,64,41310,8193,65,10281,5441,45404,2129,33825,41340,256,8281,46092,593]

theorem envBound42313 : H12AffineFastState.Bounded env42313 := by
  intro p hp
  have h : env42313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42312_42313 : H12AffineEnvironment.transform 13 13688 env42312 = env42313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env42312 == env42313) = true)

theorem identity42313 : scanCanonicalize (H12AffineFastState.compose env42313 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42313 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8540,114,5172,2049,1024,8541,12392,8200,64,2,8193,65,10281,5441,4096,2129,9597,32,256,8281,5456,593]

theorem envBound42314 : H12AffineFastState.Bounded env42314 := by
  intro p hp
  have h : env42314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42313_42314 : H12AffineEnvironment.transform 14 8540 env42313 = env42314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42313 == env42314) = true)

theorem identity42314 : scanCanonicalize (H12AffineFastState.compose env42314 (packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound42314 : packedSelected [0,1,3,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,8192,11292,8540,114,3408,2049,1024,8541,10508,8200,64,2,8193,65,10281,3109,2404,2129,9597,32,256,8281,3124,593]

theorem envBound42315 : H12AffineFastState.Bounded env42315 := by
  intro p hp
  have h : env42315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42314_42315 : H12AffineEnvironment.transform 11 2404 env42314 = env42315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env42314 == env42315) = true)

theorem identity42315 : scanCanonicalize (H12AffineFastState.compose env42315 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound42315 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42316 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2404,8192,10589,8540,114,2065,2049,321,8541,10508,8200,64,2,8193,65,10281,2404,2404,2129,8252,32,256,8281,2421,593]

theorem envBound42316 : H12AffineFastState.Bounded env42316 := by
  intro p hp
  have h : env42316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42315_42316 : H12AffineEnvironment.transform 9 321 env42315 = env42316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42315 == env42316) = true)

theorem identity42316 : scanCanonicalize (H12AffineFastState.compose env42316 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42316 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env42317 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,8192,10509,8460,34,2065,2049,273,8461,10508,8200,16,2,8193,17,10281,2356,2356,2049,8252,32,256,8201,2341,513]

theorem envBound42317 : H12AffineFastState.Bounded env42317 := by
  intro p hp
  have h : env42317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42316_42317 : H12AffineEnvironment.transform 5 16 env42316 = env42317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42316 == env42317) = true)

theorem identity42317 : scanCanonicalize (H12AffineFastState.compose env42317 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42317 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42318 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,40,2341,292,34,2065,2049,273,293,2340,32,16,2,41,17,2049,2356,2356,2049,20,32,256,33,2341,513]

theorem envBound42318 : H12AffineFastState.Bounded env42318 := by
  intro p hp
  have h : env42318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42317_42318 : H12AffineEnvironment.transform 12 40 env42317 = env42318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42317 == env42318) = true)

theorem identity42318 : scanCanonicalize (H12AffineFastState.compose env42318 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42318 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42319 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,40,2048,1,34,2065,2049,52,0,2049,32,16,2,41,17,2049,2065,2065,2049,20,32,37,33,2048,513]

theorem envBound42319 : H12AffineFastState.Bounded env42319 := by
  intro p hp
  have h : env42319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42318_42319 : H12AffineEnvironment.transform 7 37 env42318 = env42319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42318 == env42319) = true)

theorem identity42319 : scanCanonicalize (H12AffineFastState.compose env42319 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42320 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,2065,40,2048,1,34,2065,2049,52,0,2049,32,16,2,41,17,2049,2065,2065,2049,20,32,37,33,2048,32]

theorem envBound42320 : H12AffineFastState.Bounded env42320 := by
  intro p hp
  have h : env42320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42319_42320 : H12AffineEnvironment.transform 8 33 env42319 = env42320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42319 == env42320) = true)

def env42321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441760,95496,8328,65,270377,436385,45525,32160,412857,156013,256,21793,46213,486254]

theorem envBound42321 : H12AffineFastState.Bounded env42321 := by
  intro p hp
  have h : env42321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42299_42321 : H12AffineEnvironment.transform 21 272513 env42299 = env42321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42299 == env42321) = true)

theorem identity42321 : scanCanonicalize (H12AffineFastState.compose env42321 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound42321 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213486,120015,95496,8328,65,215366,115150,45525,32160,75222,156013,256,21793,46213,513]

theorem envBound42322 : H12AffineFastState.Bounded env42322 := by
  intro p hp
  have h : env42322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42321_42322 : H12AffineEnvironment.transform 17 223599 env42321 = env42322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env42321 == env42322) = true)

def env42323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213350,119879,95496,8192,65,215366,115014,45405,32040,75102,156013,256,21793,46093,513]

theorem envBound42323 : H12AffineFastState.Bounded env42323 := by
  intro p hp
  have h : env42323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42322_42323 : H12AffineEnvironment.transform 6 8 env42322 = env42323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42322 == env42323) = true)

theorem identity42323 : scanCanonicalize (H12AffineFastState.compose env42323 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound42323 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env42324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,77898,33,119879,95496,8192,65,2049,115014,45405,32040,75102,73770,256,21793,46093,513]

theorem envBound42324 : H12AffineFastState.Bounded env42324 := by
  intro p hp
  have h : env42324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42323_42324 : H12AffineEnvironment.transform 16 82247 env42323 = env42324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env42323 == env42324) = true)

theorem identity42324 : scanCanonicalize (H12AffineFastState.compose env42324 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42324 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env42325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,82247,10280,1024,1,77898,33,87111,95496,8192,65,2049,82246,12637,32040,75102,73770,256,21793,13325,513]

theorem envBound42325 : H12AffineFastState.Bounded env42325 := by
  intro p hp
  have h : env42325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42324_42325 : H12AffineEnvironment.transform 14 0 env42324 = env42325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42324 == env42325) = true)

theorem identity42325 : scanCanonicalize (H12AffineFastState.compose env42325 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42325 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env42326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,65536,82247,2421,1024,1,69911,33,87111,87125,349,65,2049,82246,4096,23669,66563,65911,256,21793,5456,513]

theorem envBound42326 : H12AffineFastState.Bounded env42326 := by
  intro p hp
  have h : env42326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42325_42326 : H12AffineEnvironment.transform 12 349 env42325 = env42326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42325 == env42326) = true)

theorem identity42326 : scanCanonicalize (H12AffineFastState.compose env42326 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound42326 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21510,5441,2421,1024,1,17681,33,65,83,349,65,2049,5440,4096,23669,20485,21873,256,21793,5456,513]

theorem envBound42327 : H12AffineFastState.Bounded env42327 := by
  intro p hp
  have h : env42327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42326_42327 : H12AffineEnvironment.transform 15 21510 env42326 = env42327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env42326 == env42327) = true)

theorem identity42327 : scanCanonicalize (H12AffineFastState.compose env42327 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42327 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,263,5441,2421,1024,1,4112,33,65,83,349,65,2049,5440,4096,2420,1284,112,256,32,5456,513]

theorem envBound42328 : H12AffineFastState.Bounded env42328 := by
  intro p hp
  have h : env42328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42327_42328 : H12AffineEnvironment.transform 13 5377 env42327 = env42328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42327 == env42328) = true)

theorem identity42328 : scanCanonicalize (H12AffineFastState.compose env42328 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42328 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42329 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5392,2340,1024,1,4112,33,16,2,268,16,2049,5393,4096,2341,1284,33,256,32,5377,513]

theorem envBound42329 : H12AffineFastState.Bounded env42329 := by
  intro p hp
  have h : env42329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42328_42329 : H12AffineEnvironment.transform 5 17 env42328 = env42329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42328 == env42329) = true)

theorem identity42329 : scanCanonicalize (H12AffineFastState.compose env42329 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42330 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,268,4405,0,263,4388,2340,52,1,4112,33,16,2,268,16,2049,4389,4096,2341,304,33,256,32,4405,513]

theorem envBound42330 : H12AffineFastState.Bounded env42330 := by
  intro p hp
  have h : env42330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42329_42330 : H12AffineEnvironment.transform 9 52 env42329 = env42330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42329 == env42330) = true)

theorem identity42330 : scanCanonicalize (H12AffineFastState.compose env42330 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound42330 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42331 : List Nat := [2,4,8,16,32,17,8,256,512,52,523,4096,268,4405,0,263,4388,815,52,1,4112,33,16,2,268,16,522,4389,4096,814,304,33,256,32,4405,513]

theorem envBound42331 : H12AffineFastState.Bounded env42331 := by
  intro p hp
  have h : env42331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42330_42331 : H12AffineEnvironment.transform 10 523 env42330 = env42331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env42330 == env42331) = true)

theorem identity42331 : scanCanonicalize (H12AffineFastState.compose env42331 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound42331 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42332 : List Nat := [2,4,8,16,32,17,8,256,512,52,523,798,268,555,0,263,570,815,52,1,782,33,16,2,268,16,522,571,798,814,304,33,256,32,555,513]

theorem envBound42332 : H12AffineFastState.Bounded env42332 := by
  intro p hp
  have h : env42332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42331_42332 : H12AffineEnvironment.transform 11 798 env42331 = env42332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env42331 == env42332) = true)

def env42333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,77898,213351,119878,95496,8193,65,215366,115015,45404,32041,75103,156013,256,21793,46092,513]

theorem envBound42333 : H12AffineFastState.Bounded env42333 := by
  intro p hp
  have h : env42333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42322_42333 : H12AffineEnvironment.transform 6 9 env42322 = env42333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42322 == env42333) = true)

theorem identity42333 : scanCanonicalize (H12AffineFastState.compose env42333 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42333 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2420,1024,32769,77898,8572,119878,95496,8193,65,10589,115015,45404,32041,75103,65910,256,21793,46092,513]

theorem envBound42334 : H12AffineFastState.Bounded env42334 := by
  intro p hp
  have h : env42334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42333_42334 : H12AffineEnvironment.transform 16 90139 env42333 = env42334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42333 == env42334) = true)

theorem identity42334 : scanCanonicalize (H12AffineFastState.compose env42334 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound42334 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env42335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,90139,2420,1024,21840,77898,8572,65815,95496,8193,65,10589,70678,25613,32041,75103,65910,256,21793,24925,513]

theorem envBound42335 : H12AffineFastState.Bounded env42335 := by
  intro p hp
  have h : env42335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42334_42335 : H12AffineEnvironment.transform 14 21841 env42334 = env42335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env42334 == env42335) = true)

theorem identity42335 : scanCanonicalize (H12AffineFastState.compose env42335 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound42335 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8312,65536,70962,2420,1024,8313,77898,8572,65815,65569,8193,65,10589,70678,4388,2048,75103,65910,256,8200,5236,513]

theorem envBound42336 : H12AffineFastState.Bounded env42336 := by
  intro p hp
  have h : env42336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42335_42336 : H12AffineEnvironment.transform 13 13609 env42335 = env42336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env42335 == env42336) = true)

theorem identity42336 : scanCanonicalize (H12AffineFastState.compose env42336 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound42336 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env42337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8312,114,5440,2420,1024,8313,12344,8572,357,83,8193,65,10589,5220,4388,2048,9517,260,256,8200,5236,513]

theorem envBound42337 : H12AffineFastState.Bounded env42337 := by
  intro p hp
  have h : env42337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42336_42337 : H12AffineEnvironment.transform 15 114 env42336 = env42337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env42336 == env42337) = true)

theorem identity42337 : scanCanonicalize (H12AffineFastState.compose env42337 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42337 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env42338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5156,373,114,5440,2420,1024,372,4405,113,357,83,268,65,2128,5220,4388,2048,1056,260,256,261,5236,513]

theorem envBound42338 : H12AffineFastState.Bounded env42338 := by
  intro p hp
  have h : env42338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42337_42338 : H12AffineEnvironment.transform 12 269 env42337 = env42338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42337 == env42338) = true)

theorem identity42338 : scanCanonicalize (H12AffineFastState.compose env42338 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42339 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,292,35,5393,2341,1024,293,4405,32,308,2,268,16,2049,5173,4388,2048,1056,260,256,261,5157,513]

theorem envBound42339 : H12AffineFastState.Bounded env42339 := by
  intro p hp
  have h : env42339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42338_42339 : H12AffineEnvironment.transform 5 17 env42338 = env42339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42338 == env42339) = true)

theorem identity42339 : scanCanonicalize (H12AffineFastState.compose env42339 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound42339 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42340 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1060,269,0,292,35,309,2341,1024,293,1297,32,308,2,268,16,2049,17,1280,2048,1056,260,256,261,1,513]

theorem envBound42340 : H12AffineFastState.Bounded env42340 := by
  intro p hp
  have h : env42340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42339_42340 : H12AffineEnvironment.transform 11 1060 env42339 = env42340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env42339 == env42340) = true)

theorem identity42340 : scanCanonicalize (H12AffineFastState.compose env42340 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound42340 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42341 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1060,269,0,292,35,309,1076,1024,293,1297,32,308,2,268,16,1296,17,1280,1297,1056,260,256,261,1,513]

theorem envBound42341 : H12AffineFastState.Bounded env42341 := by
  intro p hp
  have h : env42341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42340_42341 : H12AffineEnvironment.transform 10 1297 env42340 = env42341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env42340 == env42341) = true)

theorem identity42341 : scanCanonicalize (H12AffineFastState.compose env42341 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42341 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env42342 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,1060,41,0,0,35,17,1076,1024,1,1077,32,16,2,40,16,1076,17,1060,1077,1056,32,36,33,1,513]

theorem envBound42342 : H12AffineFastState.Bounded env42342 := by
  intro p hp
  have h : env42342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42341_42342 : H12AffineEnvironment.transform 7 36 env42341 = env42342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42341 == env42342) = true)

theorem identity42342 : scanCanonicalize (H12AffineFastState.compose env42342 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound42342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42343 : List Nat := [2,4,8,16,32,17,9,36,512,20,33,48,41,0,0,35,17,32,20,1,33,32,16,2,40,16,32,17,48,33,52,32,36,33,1,513]

theorem envBound42343 : H12AffineFastState.Bounded env42343 := by
  intro p hp
  have h : env42343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42342_42343 : H12AffineEnvironment.transform 9 20 env42342 = env42343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env42342 == env42343) = true)

theorem identity42343 : scanCanonicalize (H12AffineFastState.compose env42343 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42344 : List Nat := [2,4,8,16,32,17,9,36,1,20,33,48,41,0,0,35,17,32,20,1,33,32,16,2,40,16,32,17,48,33,52,32,36,33,1,0]

theorem envBound42344 : H12AffineFastState.Bounded env42344 := by
  intro p hp
  have h : env42344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42343_42344 : H12AffineEnvironment.transform 8 1 env42343 = env42344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42343 == env42344) = true)

theorem identity42344 : scanCanonicalize (H12AffineFastState.compose env42344 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42344 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42345 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,16,9,0,0,3,17,0,20,1,1,0,16,2,8,16,0,17,16,1,20,0,4,1,1,0]

theorem envBound42345 : H12AffineFastState.Bounded env42345 := by
  intro p hp
  have h : env42345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42344_42345 : H12AffineEnvironment.transform 4 0 env42344 = env42345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42344 == env42345) = true)

theorem identity42345 : scanCanonicalize (H12AffineFastState.compose env42345 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42346 : List Nat := [2,4,8,11,0,10,9,4,1,15,1,11,9,0,0,3,10,0,15,1,1,0,11,2,8,11,0,10,11,1,15,0,4,1,1,0]

theorem envBound42346 : H12AffineFastState.Bounded env42346 := by
  intro p hp
  have h : env42346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42345_42346 : H12AffineEnvironment.transform 3 11 env42345 = env42346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42345 == env42346) = true)

theorem identity42346 : scanCanonicalize (H12AffineFastState.compose env42346 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42346 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42347 : List Nat := [2,4,2,1,0,0,3,4,1,5,1,1,3,0,0,3,0,0,5,1,1,0,1,2,2,1,0,0,1,1,5,0,4,1,1,0]

theorem envBound42347 : H12AffineFastState.Bounded env42347 := by
  intro p hp
  have h : env42347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42346_42347 : H12AffineEnvironment.transform 2 2 env42346 = env42347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42346 == env42347) = true)

def env42348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441761,95497,8328,65,4196520,436384,45524,32161,412857,4606445,256,21793,46213,486254]

theorem envBound42348 : H12AffineFastState.Bounded env42348 := by
  intro p hp
  have h : env42348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42298_42348 : H12AffineEnvironment.transform 22 441761 env42298 = env42348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env42298 == env42348) = true)

def env42349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441761,95497,8328,65,270376,436384,45524,32161,412857,156013,256,21793,46213,486254]

theorem envBound42349 : H12AffineFastState.Bounded env42349 := by
  intro p hp
  have h : env42349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42348_42349 : H12AffineEnvironment.transform 21 272512 env42348 = env42349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42348 == env42349) = true)

theorem identity42349 : scanCanonicalize (H12AffineFastState.compose env42349 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42349 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272512,441761,21763,8328,65,270376,436384,45524,32161,412857,156013,256,21793,46213,412516]

theorem envBound42350 : H12AffineFastState.Bounded env42350 := by
  intro p hp
  have h : env42350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42349_42350 : H12AffineEnvironment.transform 15 8202 env42349 = env42350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42349 == env42350) = true)

def env42351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272392,441641,21763,8192,65,270376,436264,45404,32041,412721,156013,256,21793,46093,412516]

end H12CloudChart1