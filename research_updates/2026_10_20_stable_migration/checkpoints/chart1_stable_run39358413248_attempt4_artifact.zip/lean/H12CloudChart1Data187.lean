import H12CloudChart1Data186

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env47372 : List Nat := [2,0,8,0,0,0,9,0,512,1,1,1,9,1,0,2,0,0,1,1,0,1,1,3,8,1,1,0,1,0,0,1,0,1,1,512]

theorem envBound47372 : H12AffineFastState.Bounded env47372 := by
  intro p hp
  have h : env47372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47371_47372 : H12AffineEnvironment.transform 1 0 env47371 = env47372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47371 == env47372) = true)

theorem identity47372 : scanCanonicalize (H12AffineFastState.compose env47372 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47372 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47373 : List Nat := [2,0,8,0,0,0,9,0,1,1,1,1,9,1,0,2,0,0,1,1,0,1,1,3,8,1,1,0,1,0,0,1,0,1,1,1]

theorem envBound47373 : H12AffineFastState.Bounded env47373 := by
  intro p hp
  have h : env47373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47372_47373 : H12AffineEnvironment.transform 8 1 env47372 = env47373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47372 == env47373) = true)

def env47374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,2114883,8328,65,4292003,115150,17664,2111713,119043,4268162,256,2199998,2191387,63188]

theorem envBound47374 : H12AffineFastState.Bounded env47374 := by
  intro p hp
  have h : env47374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47316_47374 : H12AffineEnvironment.transform 22 2101329 env47316 = env47374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env47316 == env47374) = true)

def env47375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,21763,8328,65,4292003,115150,17664,10401,119043,4268162,256,98814,90203,63188]

theorem envBound47375 : H12AffineFastState.Bounded env47375 := by
  intro p hp
  have h : env47375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47374_47375 : H12AffineEnvironment.transform 20 4160 env47374 = env47375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47374 == env47375) = true)

theorem identity47375 : scanCanonicalize (H12AffineFastState.compose env47375 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound47375 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180273,17,21763,8328,65,245138,115150,17664,10401,119043,254131,256,98814,90203,63188]

theorem envBound47376 : H12AffineFastState.Bounded env47376 := by
  intro p hp
  have h : env47376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47375_47376 : H12AffineEnvironment.transform 21 180273 env47375 = env47376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env47375 == env47376) = true)

def env47377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180273,17,21763,8192,65,245018,115014,17664,10281,119043,254011,256,98678,90203,63068]

theorem envBound47377 : H12AffineFastState.Bounded env47377 := by
  intro p hp
  have h : env47377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47376_47377 : H12AffineEnvironment.transform 6 8 env47376 = env47377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47376 == env47377) = true)

theorem identity47377 : scanCanonicalize (H12AffineFastState.compose env47377 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47377 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4160,156013,17,21763,8192,65,203846,90138,17664,10281,94303,213351,256,73770,90203,22272]

theorem envBound47378 : H12AffineFastState.Bounded env47378 := by
  intro p hp
  have h : env47378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47377_47378 : H12AffineEnvironment.transform 14 8540 env47377 = env47378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47377 == env47378) = true)

theorem identity47378 : scanCanonicalize (H12AffineFastState.compose env47378 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound47378 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env47379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,76159,1024,8541,4160,65910,17,21763,8192,65,31837,90138,17664,10281,94303,8572,256,73770,90203,22272]

theorem envBound47379 : H12AffineFastState.Bounded env47379 := by
  intro p hp
  have h : env47379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47378_47379 : H12AffineEnvironment.transform 16 90139 env47378 = env47379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env47378 == env47379) = true)

theorem identity47379 : scanCanonicalize (H12AffineFastState.compose env47379 (packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound47379 : packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS < 2^1333 := by decide +kernel

def env47380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21875,13672,31756,1024,8541,4160,21509,17,21763,8192,65,31837,13673,17664,10281,9516,8572,256,30041,13608,22272]

theorem envBound47380 : H12AffineFastState.Bounded env47380 := by
  intro p hp
  have h : env47380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47379_47380 : H12AffineEnvironment.transform 15 21875 env47379 = env47380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env47379 == env47380) = true)

theorem identity47380 : scanCanonicalize (H12AffineFastState.compose env47380 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound47380 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env47381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8540,8202,13672,2421,1024,8541,4160,8572,17,8314,8192,65,2340,13673,12409,10281,9516,8572,256,32,13608,8825]

theorem envBound47381 : H12AffineFastState.Bounded env47381 := by
  intro p hp
  have h : env47381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47380_47381 : H12AffineEnvironment.transform 13 13689 env47380 = env47381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env47380 == env47381) = true)

theorem identity47381 : scanCanonicalize (H12AffineFastState.compose env47381 (packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47381 : packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env47382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,1,343,5173,2421,1024,0,4160,33,17,295,349,65,2340,5172,4388,2420,1137,33,256,32,5237,804]

theorem envBound47382 : H12AffineFastState.Bounded env47382 := by
  intro p hp
  have h : env47382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47381_47382 : H12AffineEnvironment.transform 12 349 env47381 = env47382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47381 == env47382) = true)

theorem identity47382 : scanCanonicalize (H12AffineFastState.compose env47382 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47382 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47383 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4404,1,343,4389,2421,272,0,4160,33,17,295,349,65,2340,4388,4388,2420,353,33,256,32,4453,804]

theorem envBound47383 : H12AffineFastState.Bounded env47383 := by
  intro p hp
  have h : env47383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47382_47383 : H12AffineEnvironment.transform 9 272 env47382 = env47383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47382 == env47383) = true)

theorem identity47383 : scanCanonicalize (H12AffineFastState.compose env47383 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound47383 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47384 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,349,2129,1,343,2112,2421,272,0,2341,33,17,295,349,65,2340,2113,2113,2420,353,33,256,32,2048,804]

theorem envBound47384 : H12AffineFastState.Bounded env47384 := by
  intro p hp
  have h : env47384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47383_47384 : H12AffineEnvironment.transform 11 2405 env47383 = env47384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env47383 == env47384) = true)

theorem identity47384 : scanCanonicalize (H12AffineFastState.compose env47384 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47384 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47385 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,41,2129,1,35,2112,2049,100,0,2129,33,17,83,41,65,2128,2113,2113,2048,21,33,116,32,2048,592]

theorem envBound47385 : H12AffineFastState.Bounded env47385 := by
  intro p hp
  have h : env47385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47384_47385 : H12AffineEnvironment.transform 7 116 env47384 = env47385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47384 == env47385) = true)

theorem identity47385 : scanCanonicalize (H12AffineFastState.compose env47385 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound47385 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47386 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,64,41,0,1,35,17,80,100,0,0,33,17,83,41,65,1,16,16,81,21,33,116,32,81,592]

theorem envBound47386 : H12AffineFastState.Bounded env47386 := by
  intro p hp
  have h : env47386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47385_47386 : H12AffineEnvironment.transform 10 81 env47385 = env47386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env47385 == env47386) = true)

theorem identity47386 : scanCanonicalize (H12AffineFastState.compose env47386 (packedSelected [2,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47386 : packedSelected [2,16] rootPS < 2^1333 := by decide +kernel

def env47387 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,41,0,1,35,17,1,53,0,0,33,17,2,41,16,1,16,16,0,21,33,37,32,0,513]

theorem envBound47387 : H12AffineFastState.Bounded env47387 := by
  intro p hp
  have h : env47387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47386_47387 : H12AffineEnvironment.transform 5 17 env47386 = env47387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47386 == env47387) = true)

theorem identity47387 : scanCanonicalize (H12AffineFastState.compose env47387 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound47387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47388 : List Nat := [2,4,8,16,27,17,8,30,512,14,0,17,18,0,1,24,17,1,14,0,0,26,17,2,18,16,1,16,16,0,21,26,30,27,0,513]

theorem envBound47388 : H12AffineFastState.Bounded env47388 := by
  intro p hp
  have h : env47388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47387_47388 : H12AffineEnvironment.transform 4 27 env47387 = env47388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env47387 == env47388) = true)

def env47389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180273,17,21763,8193,65,245019,115015,17664,10280,119043,254010,256,98679,90203,63069]

theorem envBound47389 : H12AffineFastState.Bounded env47389 := by
  intro p hp
  have h : env47389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47376_47389 : H12AffineEnvironment.transform 6 9 env47376 = env47389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47376 == env47389) = true)

theorem identity47389 : scanCanonicalize (H12AffineFastState.compose env47389 (packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound47389 : packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env47390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82198,108847,1024,32769,4160,98599,17,21763,8193,65,64525,115015,17664,10280,119043,41260,256,98679,90203,63069]

theorem envBound47390 : H12AffineFastState.Bounded env47390 := by
  intro p hp
  have h : env47390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47389_47390 : H12AffineEnvironment.transform 16 82198 env47389 = env47390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env47389 == env47390) = true)

theorem identity47390 : scanCanonicalize (H12AffineFastState.compose env47390 (packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound47390 : packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env47391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,13388,56437,1024,32769,4160,62589,17,21763,8193,65,64525,46109,17664,10280,42073,41260,256,62509,5377,63069]

theorem envBound47391 : H12AffineFastState.Bounded env47391 := by
  intro p hp
  have h : env47391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47390_47391 : H12AffineEnvironment.transform 15 30042 env47390 = env47391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env47390 == env47391) = true)

theorem identity47391 : scanCanonicalize (H12AffineFastState.compose env47391 (packedSelected [4,10,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound47391 : packedSelected [4,10,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env47392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,30042,13388,2420,1024,21760,4160,8572,17,21763,8193,65,10508,24860,17664,10280,29016,29741,256,8492,5377,9052]

theorem envBound47392 : H12AffineFastState.Bounded env47392 := by
  intro p hp
  have h : env47392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47391_47392 : H12AffineEnvironment.transform 14 21761 env47391 = env47392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env47391 == env47392) = true)

def env47393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,21762,8328,65,4292003,115150,17664,10400,119043,4268162,256,98815,90202,63188]

theorem envBound47393 : H12AffineFastState.Bounded env47393 := by
  intro p hp
  have h : env47393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47374_47393 : H12AffineEnvironment.transform 20 4161 env47374 = env47393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47374 == env47393) = true)

def env47394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21762,8192,65,4291883,115014,17664,10280,119043,4268042,256,98679,90202,63068]

theorem envBound47394 : H12AffineFastState.Bounded env47394 := by
  intro p hp
  have h : env47394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47393_47394 : H12AffineEnvironment.transform 6 8 env47393 = env47394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47393 == env47394) = true)

theorem identity47394 : scanCanonicalize (H12AffineFastState.compose env47394 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound47394 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4161,4194304,16,21762,8192,65,4291883,115014,17664,10280,119043,4268042,256,98679,90202,63068]

theorem envBound47395 : H12AffineFastState.Bounded env47395 := by
  intro p hp
  have h : env47395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47394_47395 : H12AffineEnvironment.transform 16 24908 env47394 = env47395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env47394 == env47395) = true)

theorem identity47395 : scanCanonicalize (H12AffineFastState.compose env47395 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound47395 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env47396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24908,35188,1024,32769,4161,4194304,16,21762,8192,65,4229153,13388,17664,10280,9225,4248832,256,29821,38224,63068]

theorem envBound47396 : H12AffineFastState.Bounded env47396 := by
  intro p hp
  have h : env47396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47395_47396 : H12AffineEnvironment.transform 15 62730 env47395 = env47396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env47395 == env47396) = true)

theorem identity47396 : scanCanonicalize (H12AffineFastState.compose env47396 (packedSelected [1,4,8,9,12,14,19,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound47396 : packedSelected [1,4,8,9,12,14,19,20,38] rootPS < 2^1333 := by decide +kernel

def env47397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,35,24908,31837,1024,29992,4161,4194304,16,21762,8192,65,4226312,13388,17664,10280,9225,4202537,256,29821,24697,885]

theorem envBound47397 : H12AffineFastState.Bounded env47397 := by
  intro p hp
  have h : env47397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47396_47397 : H12AffineEnvironment.transform 14 29993 env47396 = env47397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env47396 == env47397) = true)

theorem identity47397 : scanCanonicalize (H12AffineFastState.compose env47397 (packedSelected [3,4,5,8,9,10,14,16,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47397 : packedSelected [3,4,5,8,9,10,14,16,28,31] rootPS < 2^1333 := by decide +kernel

def env47398 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,35,24632,31837,1024,29788,4161,4194304,16,21622,8192,65,4226172,13388,17524,10280,9225,4202537,116,29821,24697,513]

theorem envBound47398 : H12AffineFastState.Bounded env47398 := by
  intro p hp
  have h : env47398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47397_47398 : H12AffineEnvironment.transform 7 116 env47397 = env47398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47397 == env47398) = true)

theorem identity47398 : scanCanonicalize (H12AffineFastState.compose env47398 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound47398 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47399 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4113,9292,35,12329,11340,1024,9293,4161,4194304,16,1127,8192,65,4205677,13388,5221,10280,9225,4202537,116,9324,12392,513]

theorem envBound47399 : H12AffineFastState.Bounded env47399 := by
  intro p hp
  have h : env47399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47398_47399 : H12AffineEnvironment.transform 13 4113 env47398 = env47399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env47398 == env47399) = true)

theorem identity47399 : scanCanonicalize (H12AffineFastState.compose env47399 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47399 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47400 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,8192,4113,8312,35,12329,10360,52,8313,4161,4194304,16,83,8192,65,4204633,12408,4177,10280,8253,4202537,116,8280,12392,513]

theorem envBound47400 : H12AffineFastState.Bounded env47400 := by
  intro p hp
  have h : env47400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47399_47400 : H12AffineEnvironment.transform 9 52 env47399 = env47400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47399 == env47400) = true)

theorem identity47400 : scanCanonicalize (H12AffineFastState.compose env47400 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound47400 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47401 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,8192,4113,8312,35,12329,10360,52,8313,4161,8201,16,83,8192,65,2128,12408,4177,10280,8253,32,116,8280,12392,513]

theorem envBound47401 : H12AffineFastState.Bounded env47401 := by
  intro p hp
  have h : env47401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47400_47401 : H12AffineEnvironment.transform 21 8201 env47400 = env47401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env47400 == env47401) = true)

theorem identity47401 : scanCanonicalize (H12AffineFastState.compose env47401 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound47401 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47402 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4113,1,35,4176,2049,52,0,4161,112,16,83,121,65,2128,4097,4177,2129,68,32,116,33,4113,513]

theorem envBound47402 : H12AffineFastState.Bounded env47402 := by
  intro p hp
  have h : env47402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47401_47402 : H12AffineEnvironment.transform 12 121 env47401 = env47402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env47401 == env47402) = true)

def env47403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21762,8193,65,4291882,115015,17664,10281,119043,4268043,256,98678,90202,63069]

theorem envBound47403 : H12AffineFastState.Bounded env47403 := by
  intro p hp
  have h : env47403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47393_47403 : H12AffineEnvironment.transform 6 9 env47393 = env47403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47393 == env47403) = true)

theorem identity47403 : scanCanonicalize (H12AffineFastState.compose env47403 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound47403 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,4194304,16,21762,8193,65,4291882,115015,17664,10281,119043,4268043,256,98678,90202,63069]

theorem envBound47404 : H12AffineFastState.Bounded env47404 := by
  intro p hp
  have h : env47404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47403_47404 : H12AffineEnvironment.transform 16 49168 env47403 = env47404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47403 == env47404) = true)

theorem identity47404 : scanCanonicalize (H12AffineFastState.compose env47404 (packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound47404 : packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS < 2^1333 := by decide +kernel

def env47405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1024,29789,4161,4194304,16,21762,8193,65,4291882,79131,17664,10281,75103,4268043,256,95530,90202,513]

theorem envBound47405 : H12AffineFastState.Bounded env47405 := by
  intro p hp
  have h : env47405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47404_47405 : H12AffineEnvironment.transform 14 29788 env47404 = env47405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env47404 == env47405) = true)

theorem identity47405 : scanCanonicalize (H12AffineFastState.compose env47405 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47405 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env47406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13388,10281,1024,29789,4161,4194304,16,21762,8193,65,4218144,5393,17664,10281,1365,4194305,256,21792,16464,513]

theorem envBound47406 : H12AffineFastState.Bounded env47406 := by
  intro p hp
  have h : env47406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47405_47406 : H12AffineEnvironment.transform 15 8202 env47405 = env47406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47405 == env47406) = true)

theorem identity47406 : scanCanonicalize (H12AffineFastState.compose env47406 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47406 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env47407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,262,5440,2341,1024,21841,4161,4194304,16,21762,269,65,4218144,5393,17664,2341,1365,4194305,256,21792,16464,513]

theorem envBound47407 : H12AffineFastState.Bounded env47407 := by
  intro p hp
  have h : env47407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47406_47407 : H12AffineEnvironment.transform 12 268 env47406 = env47407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47406 == env47407) = true)

theorem identity47407 : scanCanonicalize (H12AffineFastState.compose env47407 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound47407 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env47408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,262,5440,2341,1024,21841,4161,21792,16,21762,269,65,2048,5393,17664,2341,1365,21793,256,21792,16464,513]

theorem envBound47408 : H12AffineFastState.Bounded env47408 := by
  intro p hp
  have h : env47408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47407_47408 : H12AffineEnvironment.transform 21 21792 env47407 = env47408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env47407 == env47408) = true)

theorem identity47408 : scanCanonicalize (H12AffineFastState.compose env47408 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound47408 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,0,262,5440,2341,1024,1,4161,112,16,82,269,65,2048,5393,4176,2341,1365,113,256,112,5376,513]

theorem envBound47409 : H12AffineFastState.Bounded env47409 := by
  intro p hp
  have h : env47409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47408_47409 : H12AffineEnvironment.transform 13 5456 env47408 = env47409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env47408 == env47409) = true)

theorem identity47409 : scanCanonicalize (H12AffineFastState.compose env47409 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47409 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47410 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4112,33,16,3,269,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound47410 : H12AffineFastState.Bounded env47410 := by
  intro p hp
  have h : env47410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47409_47410 : H12AffineEnvironment.transform 5 17 env47409 = env47410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47409 == env47410) = true)

theorem identity47410 : scanCanonicalize (H12AffineFastState.compose env47410 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47411 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5173,2049,1024,1,4112,33,16,3,41,16,2048,5173,4097,2049,1056,32,36,33,5156,513]

theorem envBound47411 : H12AffineFastState.Bounded env47411 := by
  intro p hp
  have h : env47411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47410_47411 : H12AffineEnvironment.transform 7 36 env47410 = env47411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47410 == env47411) = true)

theorem identity47411 : scanCanonicalize (H12AffineFastState.compose env47411 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound47411 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47412 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5157,0,34,5173,522,1024,1,4112,33,16,3,41,16,523,5173,4097,522,1056,32,36,33,5156,513]

theorem envBound47412 : H12AffineFastState.Bounded env47412 := by
  intro p hp
  have h : env47412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47411_47412 : H12AffineEnvironment.transform 10 523 env47411 = env47412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env47411 == env47412) = true)

theorem identity47412 : scanCanonicalize (H12AffineFastState.compose env47412 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47412 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47413 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,9,5124,0,3,5140,522,1024,1,4112,0,16,3,8,16,523,5140,4097,522,1025,1,5,0,5125,513]

theorem envBound47413 : H12AffineFastState.Bounded env47413 := by
  intro p hp
  have h : env47413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47412_47413 : H12AffineEnvironment.transform 4 1 env47412 = env47413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47412 == env47413) = true)

def env47414 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,16,9,1044,0,3,1028,522,1024,1,0,0,16,3,8,16,523,1028,17,522,1025,1,5,0,1045,513]

theorem envBound47414 : H12AffineFastState.Bounded env47414 := by
  intro p hp
  have h : env47414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47413_47414 : H12AffineEnvironment.transform 11 16 env47413 = env47414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47413 == env47414) = true)

theorem identity47414 : scanCanonicalize (H12AffineFastState.compose env47414 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound47414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47415 : List Nat := [2,4,8,16,1,17,9,5,512,0,523,16,9,20,0,3,4,522,0,1,0,0,16,3,8,16,523,4,17,522,1,1,5,0,21,513]

theorem envBound47415 : H12AffineFastState.Bounded env47415 := by
  intro p hp
  have h : env47415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47414_47415 : H12AffineEnvironment.transform 9 0 env47414 = env47415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env47414 == env47415) = true)

def env47416 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,4,9,0,0,3,4,522,0,1,0,0,4,3,8,4,523,4,5,522,1,1,5,0,1,513]

theorem envBound47416 : H12AffineFastState.Bounded env47416 := by
  intro p hp
  have h : env47416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47415_47416 : H12AffineEnvironment.transform 3 4 env47415 = env47416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47415 == env47416) = true)

theorem identity47416 : scanCanonicalize (H12AffineFastState.compose env47416 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound47416 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47417 : List Nat := [2,4,8,4,1,5,9,5,9,0,2,4,9,0,0,3,4,3,0,1,0,0,4,3,8,4,2,4,5,3,1,1,5,0,1,8]

theorem envBound47417 : H12AffineFastState.Bounded env47417 := by
  intro p hp
  have h : env47417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47416_47417 : H12AffineEnvironment.transform 8 9 env47416 = env47417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env47416 == env47417) = true)

def leafEnv47417 : List Nat := [2,4,8,4,1,5,9,5,9,0,2,4,9,0,0,3,4,3,0,1,0,0,4,3,0,8,1,4,2,4,5,3,1,1,5,0,5,2,1,8,1,1,0]

def active47417 : List Nat := [0,1,2]

def tree47417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47417 : H12WitnessSearch.Good tree47417 := H12GlobalWitnessIndex.good

theorem leafIdentity47417 : H12AffineFastState.composeSystem env47417 rootObs = leafEnv47417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47417 rootObs == leafEnv47417) = true)

theorem terminalChecked47417 : H12PackedTerminal.terminalCheckFast leafEnv47417 active47417 tree47417 = true := by decide +kernel

def env47418 : List Nat := [2,4,8,5,1,4,9,5,512,0,523,5,9,1,0,3,4,522,0,1,0,0,5,3,8,5,523,4,4,522,1,1,5,0,0,513]

theorem envBound47418 : H12AffineFastState.Bounded env47418 := by
  intro p hp
  have h : env47418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47415_47418 : H12AffineEnvironment.transform 3 5 env47415 = env47418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env47415 == env47418) = true)

theorem identity47418 : scanCanonicalize (H12AffineFastState.compose env47418 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47419 : List Nat := [1,4,8,5,1,4,9,5,512,0,520,5,9,1,0,0,4,521,0,1,0,0,5,0,8,5,520,4,4,521,1,1,5,0,0,513]

theorem envBound47419 : H12AffineFastState.Bounded env47419 := by
  intro p hp
  have h : env47419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47418_47419 : H12AffineEnvironment.transform 0 1 env47418 = env47419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47418 == env47419) = true)

def leafEnv47419 : List Nat := [1,4,8,5,1,4,9,5,512,0,520,5,9,1,0,0,4,521,0,1,0,0,5,0,0,8,1,5,520,4,4,521,1,1,5,0,5,1,0,513,1,1,0]

def active47419 : List Nat := [1,2,8]

def tree47419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47419 : H12WitnessSearch.Good tree47419 := H12GlobalWitnessIndex.good

theorem leafIdentity47419 : H12AffineFastState.composeSystem env47419 rootObs = leafEnv47419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47419 rootObs == leafEnv47419) = true)

theorem terminalChecked47419 : H12PackedTerminal.terminalCheckFast leafEnv47419 active47419 tree47419 = true := by decide +kernel

def env47420 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,17,9,1045,0,3,1029,522,1024,1,1,0,16,3,8,16,523,1029,16,522,1025,1,5,0,1044,513]

theorem envBound47420 : H12AffineFastState.Bounded env47420 := by
  intro p hp
  have h : env47420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47413_47420 : H12AffineEnvironment.transform 11 17 env47413 = env47420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47413 == env47420) = true)

theorem identity47420 : scanCanonicalize (H12AffineFastState.compose env47420 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47421 : List Nat := [2,4,8,4,1,5,9,5,512,1024,523,5,9,1025,0,3,1029,522,1024,1,1,0,4,3,8,4,523,1029,4,522,1025,1,5,0,1024,513]

theorem envBound47421 : H12AffineFastState.Bounded env47421 := by
  intro p hp
  have h : env47421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47420_47421 : H12AffineEnvironment.transform 3 4 env47420 = env47421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47420 == env47421) = true)

def env47422 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,5,9,1,0,3,5,522,0,1,1,0,4,3,8,4,523,5,4,522,1,1,5,0,0,513]

theorem envBound47422 : H12AffineFastState.Bounded env47422 := by
  intro p hp
  have h : env47422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47421_47422 : H12AffineEnvironment.transform 9 0 env47421 = env47422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env47421 == env47422) = true)

theorem identity47422 : scanCanonicalize (H12AffineFastState.compose env47422 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound47422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47423 : List Nat := [2,4,8,4,1,5,9,5,8,0,3,5,9,1,0,3,5,2,0,1,1,0,4,3,8,4,3,5,4,2,1,1,5,0,0,9]

theorem envBound47423 : H12AffineFastState.Bounded env47423 := by
  intro p hp
  have h : env47423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47422_47423 : H12AffineEnvironment.transform 8 8 env47422 = env47423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env47422 == env47423) = true)

def leafEnv47423 : List Nat := [2,4,8,4,1,5,9,5,8,0,3,5,9,1,0,3,5,2,0,1,1,0,4,3,0,8,1,4,3,5,4,2,1,1,5,0,5,2,0,9,1,0,0]

def active47423 : List Nat := [0,1,2]

def tree47423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47423 : H12WitnessSearch.Good tree47423 := H12GlobalWitnessIndex.good

theorem leafIdentity47423 : H12AffineFastState.composeSystem env47423 rootObs = leafEnv47423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47423 rootObs == leafEnv47423) = true)

theorem terminalChecked47423 : H12PackedTerminal.terminalCheckFast leafEnv47423 active47423 tree47423 = true := by decide +kernel

def env47424 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,5,9,0,0,3,4,522,1,1,1,0,4,3,8,4,523,4,4,522,0,1,5,0,1,513]

theorem envBound47424 : H12AffineFastState.Bounded env47424 := by
  intro p hp
  have h : env47424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47421_47424 : H12AffineEnvironment.transform 9 1 env47421 = env47424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env47421 == env47424) = true)

theorem identity47424 : scanCanonicalize (H12AffineFastState.compose env47424 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47424 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47425 : List Nat := [0,4,8,4,1,5,9,5,512,1,521,5,9,0,0,1,4,520,1,1,1,0,4,1,8,4,521,4,4,520,0,1,5,0,1,513]

theorem envBound47425 : H12AffineFastState.Bounded env47425 := by
  intro p hp
  have h : env47425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47424_47425 : H12AffineEnvironment.transform 0 0 env47424 = env47425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47424 == env47425) = true)

def leafEnv47425 : List Nat := [0,4,8,4,1,5,9,5,512,1,521,5,9,0,0,1,4,520,1,1,1,0,4,1,1,8,1,4,521,4,4,520,0,1,5,0,5,0,1,513,1,0,0]

def active47425 : List Nat := [1,2,8]

def tree47425 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47425 : H12WitnessSearch.Good tree47425 := H12GlobalWitnessIndex.good

theorem leafIdentity47425 : H12AffineFastState.composeSystem env47425 rootObs = leafEnv47425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47425 rootObs == leafEnv47425) = true)

theorem terminalChecked47425 : H12PackedTerminal.terminalCheckFast leafEnv47425 active47425 tree47425 = true := by decide +kernel

def env47426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773746,115151,10507601,8399025,10600787,4268163,256,8487406,8478795,10544772]

theorem envBound47426 : H12AffineFastState.Bounded env47426 := by
  intro p hp
  have h : env47426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47315_47426 : H12AffineEnvironment.transform 17 190641 env47315 = env47426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env47315 == env47426) = true)

def env47427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,2114882,8328,65,4292002,115151,17665,2111713,119043,4268163,256,2199998,2191387,63188]

theorem envBound47427 : H12AffineFastState.Bounded env47427 := by
  intro p hp
  have h : env47427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47426_47427 : H12AffineEnvironment.transform 22 2101328 env47426 = env47427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env47426 == env47427) = true)

def env47428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,21762,8328,65,4292002,115151,17665,10401,119043,4268163,256,98814,90203,63188]

theorem envBound47428 : H12AffineFastState.Bounded env47428 := by
  intro p hp
  have h : env47428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47427_47428 : H12AffineEnvironment.transform 20 4160 env47427 = env47428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47427 == env47428) = true)

theorem identity47428 : scanCanonicalize (H12AffineFastState.compose env47428 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47428 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,4194304,16,21762,8328,65,4218281,57796,17665,10401,61704,4194440,256,41461,16464,63188]

theorem envBound47429 : H12AffineFastState.Bounded env47429 := by
  intro p hp
  have h : env47429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47428_47429 : H12AffineEnvironment.transform 15 8203 env47428 = env47429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47428 == env47429) = true)

theorem identity47429 : scanCanonicalize (H12AffineFastState.compose env47429 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47429 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env47430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,157872,1024,0,4160,4194304,16,21762,8328,65,4218281,25029,17665,10401,28937,4194440,256,8692,16464,30421]

theorem envBound47430 : H12AffineFastState.Bounded env47430 := by
  intro p hp
  have h : env47430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47429_47430 : H12AffineEnvironment.transform 14 1 env47429 = env47430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47429 == env47430) = true)

def env47431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,131072,157752,1024,0,4160,4194304,16,21762,8192,65,4218145,24909,17665,10281,28937,4194304,256,8572,16464,30301]

theorem envBound47431 : H12AffineFastState.Bounded env47431 := by
  intro p hp
  have h : env47431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47430_47431 : H12AffineEnvironment.transform 6 8 env47430 = env47431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47430 == env47431) = true)

theorem identity47431 : scanCanonicalize (H12AffineFastState.compose env47431 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound47431 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,24909,2421,1024,0,4160,4194304,16,21762,8192,65,4218145,24909,17665,10281,28937,4194304,256,8572,16464,30301]

theorem envBound47432 : H12AffineFastState.Bounded env47432 := by
  intro p hp
  have h : env47432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47431_47432 : H12AffineEnvironment.transform 16 24909 env47431 = env47432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env47431 == env47432) = true)

theorem identity47432 : scanCanonicalize (H12AffineFastState.compose env47432 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound47432 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,24909,2421,1024,0,4160,8572,16,21762,8192,65,31837,24909,17665,10281,28937,8572,256,8572,16464,30301]

theorem envBound47433 : H12AffineFastState.Bounded env47433 := by
  intro p hp
  have h : env47433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47432_47433 : H12AffineEnvironment.transform 21 8572 env47432 = env47433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env47432 == env47433) = true)

theorem identity47433 : scanCanonicalize (H12AffineFastState.compose env47433 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound47433 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env47434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13576,1,8203,5189,2421,1024,0,4160,8572,16,8202,8192,65,2389,5189,12297,10281,1025,8572,256,8572,13656,853]

theorem envBound47434 : H12AffineFastState.Bounded env47434 := by
  intro p hp
  have h : env47434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47433_47434 : H12AffineEnvironment.transform 13 13576 env47433 = env47434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env47433 == env47434) = true)

theorem identity47434 : scanCanonicalize (H12AffineFastState.compose env47434 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47434 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env47435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5205,1,342,5189,2421,1024,0,4160,33,16,343,349,65,2389,5189,4436,2420,1025,33,256,33,5125,853]

theorem envBound47435 : H12AffineFastState.Bounded env47435 := by
  intro p hp
  have h : env47435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47434_47435 : H12AffineEnvironment.transform 12 349 env47434 = env47435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47434 == env47435) = true)

theorem identity47435 : scanCanonicalize (H12AffineFastState.compose env47435 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47435 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47436 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5205,1,35,5189,2048,1024,0,4160,33,16,34,40,65,2080,5189,4129,2049,1025,33,117,33,5125,544]

theorem envBound47436 : H12AffineFastState.Bounded env47436 := by
  intro p hp
  have h : env47436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47435_47436 : H12AffineEnvironment.transform 7 117 env47435 = env47436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47435 == env47436) = true)

theorem identity47436 : scanCanonicalize (H12AffineFastState.compose env47436 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47436 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47437 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4145,1,35,4129,2048,100,0,4160,33,16,34,40,65,2080,4129,4129,2049,101,33,117,33,4193,544]

theorem envBound47437 : H12AffineFastState.Bounded env47437 := by
  intro p hp
  have h : env47437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47436_47437 : H12AffineEnvironment.transform 9 100 env47436 = env47437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47436 == env47437) = true)

theorem identity47437 : scanCanonicalize (H12AffineFastState.compose env47437 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound47437 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env47438 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,2113,40,2160,1,35,2144,2048,100,0,2049,33,16,34,40,65,2080,2144,2144,2049,101,33,117,33,2080,544]

theorem envBound47438 : H12AffineFastState.Bounded env47438 := by
  intro p hp
  have h : env47438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47437_47438 : H12AffineEnvironment.transform 11 2113 env47437 = env47438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env47437 == env47438) = true)

theorem identity47438 : scanCanonicalize (H12AffineFastState.compose env47438 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound47438 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47439 : List Nat := [2,4,8,16,32,64,8,117,512,100,561,624,40,577,1,35,593,561,100,0,560,33,16,34,40,65,529,593,593,560,101,33,117,33,529,544]

theorem envBound47439 : H12AffineFastState.Bounded env47439 := by
  intro p hp
  have h : env47439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47438_47439 : H12AffineEnvironment.transform 10 561 env47438 = env47439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env47438 == env47439) = true)

def env47440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,131072,157753,1024,0,4160,4194304,16,21762,8193,65,4218144,24908,17665,10280,28937,4194305,256,8573,16464,30300]

theorem envBound47440 : H12AffineFastState.Bounded env47440 := by
  intro p hp
  have h : env47440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47430_47440 : H12AffineEnvironment.transform 6 9 env47430 = env47440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47430 == env47440) = true)

theorem identity47440 : scanCanonicalize (H12AffineFastState.compose env47440 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound47440 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10281,1024,0,4160,4194304,16,21762,8193,65,4218144,24908,17665,10280,28937,4194305,256,8573,16464,30300]

theorem envBound47441 : H12AffineFastState.Bounded env47441 := by
  intro p hp
  have h : env47441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47440_47441 : H12AffineEnvironment.transform 16 16400 env47440 = env47441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env47440 == env47441) = true)

theorem identity47441 : scanCanonicalize (H12AffineFastState.compose env47441 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47441 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,13389,10281,1024,0,4160,4194304,16,8543,8193,65,4204925,5393,12636,10280,1364,4194305,256,8573,13325,513]

theorem envBound47442 : H12AffineFastState.Bounded env47442 := by
  intro p hp
  have h : env47442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47441_47442 : H12AffineEnvironment.transform 13 13405 env47441 = env47442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47441 == env47442) = true)

theorem identity47442 : scanCanonicalize (H12AffineFastState.compose env47442 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound47442 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,13389,10281,1024,0,4160,33,16,8543,8193,65,10588,5393,12636,10280,1364,32,256,8573,13325,513]

theorem envBound47443 : H12AffineFastState.Bounded env47443 := by
  intro p hp
  have h : env47443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47442_47443 : H12AffineEnvironment.transform 21 33 env47442 = env47443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47442 == env47443) = true)

theorem identity47443 : scanCanonicalize (H12AffineFastState.compose env47443 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47443 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4160,33,16,2,348,65,2049,5393,4097,2421,1364,32,256,32,5456,513]

theorem envBound47444 : H12AffineFastState.Bounded env47444 := by
  intro p hp
  have h : env47444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47443_47444 : H12AffineEnvironment.transform 12 349 env47443 = env47444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47443 == env47444) = true)

theorem identity47444 : scanCanonicalize (H12AffineFastState.compose env47444 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47444 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47445 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4113,33,16,2,269,16,2049,5393,4097,2340,1285,32,256,32,5377,513]

theorem envBound47445 : H12AffineFastState.Bounded env47445 := by
  intro p hp
  have h : env47445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47444_47445 : H12AffineEnvironment.transform 5 17 env47444 = env47445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47444 == env47445) = true)

theorem identity47445 : scanCanonicalize (H12AffineFastState.compose env47445 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47446 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,268,1328,1,263,1312,2341,1024,0,33,33,16,2,269,16,2049,1313,49,2340,1285,32,256,32,1329,513]

theorem envBound47446 : H12AffineFastState.Bounded env47446 := by
  intro p hp
  have h : env47446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47445_47446 : H12AffineEnvironment.transform 11 48 env47445 = env47446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47445 == env47446) = true)

theorem identity47446 : scanCanonicalize (H12AffineFastState.compose env47446 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound47446 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47447 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1557,48,268,1328,1,263,1312,1840,1024,0,33,33,16,2,269,16,1556,1313,49,1841,1285,32,256,32,1329,513]

theorem envBound47447 : H12AffineFastState.Bounded env47447 := by
  intro p hp
  have h : env47447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47446_47447 : H12AffineEnvironment.transform 10 1557 env47446 = env47447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env47446 == env47447) = true)

theorem identity47447 : scanCanonicalize (H12AffineFastState.compose env47447 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound47447 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47448 : List Nat := [2,4,8,16,32,17,9,256,512,37,560,48,268,277,1,263,261,789,37,0,33,33,16,2,269,16,561,260,49,788,288,32,256,32,276,513]

theorem envBound47448 : H12AffineFastState.Bounded env47448 := by
  intro p hp
  have h : env47448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47447_47448 : H12AffineEnvironment.transform 9 37 env47447 = env47448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env47447 == env47448) = true)

theorem identity47448 : scanCanonicalize (H12AffineFastState.compose env47448 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound47448 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47449 : List Nat := [2,4,8,16,32,17,9,52,512,37,560,48,56,33,1,51,49,545,37,0,33,33,16,2,57,16,561,48,49,544,20,32,52,32,32,513]

theorem envBound47449 : H12AffineFastState.Bounded env47449 := by
  intro p hp
  have h : env47449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47448_47449 : H12AffineEnvironment.transform 7 52 env47448 = env47449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env47448 == env47449) = true)

theorem identity47449 : scanCanonicalize (H12AffineFastState.compose env47449 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47450 : List Nat := [2,4,8,16,32,17,9,52,42,37,26,48,56,33,1,51,49,11,37,0,33,33,16,2,57,16,27,48,49,10,20,32,52,32,32,43]

theorem envBound47450 : H12AffineFastState.Bounded env47450 := by
  intro p hp
  have h : env47450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47449_47450 : H12AffineEnvironment.transform 8 42 env47449 = env47450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47449 == env47450) = true)

theorem identity47450 : scanCanonicalize (H12AffineFastState.compose env47450 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47450 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47451 : List Nat := [2,4,2,16,32,17,3,52,32,37,16,48,50,33,1,51,49,1,37,0,33,33,16,2,51,16,17,48,49,0,20,32,52,32,32,33]

theorem envBound47451 : H12AffineFastState.Bounded env47451 := by
  intro p hp
  have h : env47451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47450_47451 : H12AffineEnvironment.transform 2 2 env47450 = env47451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47450 == env47451) = true)

theorem identity47451 : scanCanonicalize (H12AffineFastState.compose env47451 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47451 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env47452 : List Nat := [2,4,2,16,17,17,3,5,17,20,16,1,3,16,1,2,0,1,20,0,16,16,16,2,2,16,17,1,0,0,20,17,5,17,17,16]

theorem envBound47452 : H12AffineFastState.Bounded env47452 := by
  intro p hp
  have h : env47452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47451_47452 : H12AffineEnvironment.transform 4 17 env47451 = env47452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47451 == env47452) = true)

def env47453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,21763,8328,65,4292002,115151,17665,10400,119043,4268163,256,98815,90202,63188]

theorem envBound47453 : H12AffineFastState.Bounded env47453 := by
  intro p hp
  have h : env47453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47427_47453 : H12AffineEnvironment.transform 20 4161 env47427 = env47453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47427 == env47453) = true)

theorem identity47453 : scanCanonicalize (H12AffineFastState.compose env47453 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound47453 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,254010,17,21763,8328,65,171416,115151,17665,10400,119043,180409,256,98815,90202,63188]

theorem envBound47454 : H12AffineFastState.Bounded env47454 := by
  intro p hp
  have h : env47454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47453_47454 : H12AffineEnvironment.transform 21 254010 env47453 = env47454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env47453 == env47454) = true)

def env47455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254010,17,21763,8192,65,171280,115015,17665,10280,119043,180273,256,98679,90202,63068]

theorem envBound47455 : H12AffineFastState.Bounded env47455 := by
  intro p hp
  have h : env47455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47454_47455 : H12AffineEnvironment.transform 6 8 env47454 = env47455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47454 == env47455) = true)

theorem identity47455 : scanCanonicalize (H12AffineFastState.compose env47455 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149861,1024,8541,4161,213350,17,21763,8192,65,146508,90139,17665,10280,94303,156013,256,73771,90202,22272]

theorem envBound47456 : H12AffineFastState.Bounded env47456 := by
  intro p hp
  have h : env47456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47455_47456 : H12AffineEnvironment.transform 14 8540 env47455 = env47456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47455 == env47456) = true)

theorem identity47456 : scanCanonicalize (H12AffineFastState.compose env47456 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound47456 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,76159,1024,8541,4161,8572,17,21763,8192,65,89174,90139,17665,10280,94303,65911,256,73771,90202,22272]

theorem envBound47457 : H12AffineFastState.Bounded env47457 := by
  intro p hp
  have h : env47457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47456_47457 : H12AffineEnvironment.transform 16 90138 env47456 = env47457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env47456 == env47457) = true)

theorem identity47457 : scanCanonicalize (H12AffineFastState.compose env47457 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound47457 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,24909,10280,1024,8541,4161,8572,17,21763,8192,65,23809,24908,17665,10280,28936,32,256,8572,24845,22272]

theorem envBound47458 : H12AffineFastState.Bounded env47458 := by
  intro p hp
  have h : env47458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47457_47458 : H12AffineEnvironment.transform 15 343 env47457 = env47458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env47457 == env47458) = true)

theorem identity47458 : scanCanonicalize (H12AffineFastState.compose env47458 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound47458 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1297,343,17664,3173,1024,1296,4161,1329,17,21763,1101,65,23809,17665,17665,3173,21829,32,256,1329,17728,22272]

theorem envBound47459 : H12AffineFastState.Bounded env47459 := by
  intro p hp
  have h : env47459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47458_47459 : H12AffineEnvironment.transform 12 1101 env47458 = env47459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env47458 == env47459) = true)

theorem identity47459 : scanCanonicalize (H12AffineFastState.compose env47459 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47459 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env47460 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,16384,1,343,16400,2421,272,0,4161,33,17,20499,349,65,22545,16401,16401,2421,20565,32,256,33,16464,21008]

theorem envBound47460 : H12AffineFastState.Bounded env47460 := by
  intro p hp
  have h : env47460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47459_47460 : H12AffineEnvironment.transform 9 272 env47459 = env47460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47459 == env47460) = true)

theorem identity47460 : scanCanonicalize (H12AffineFastState.compose env47460 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound47460 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47461 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4405,1,343,4389,2421,272,0,4161,33,17,294,349,65,2340,4388,4388,2421,352,32,256,33,4453,805]

theorem envBound47461 : H12AffineFastState.Bounded env47461 := by
  intro p hp
  have h : env47461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47460_47461 : H12AffineEnvironment.transform 13 4405 env47460 = env47461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env47460 == env47461) = true)

theorem identity47461 : scanCanonicalize (H12AffineFastState.compose env47461 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound47461 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47462 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,349,2128,1,343,2112,2421,272,0,2340,33,17,294,349,65,2340,2113,2113,2421,352,32,256,33,2048,805]

theorem envBound47462 : H12AffineFastState.Bounded env47462 := by
  intro p hp
  have h : env47462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47461_47462 : H12AffineEnvironment.transform 11 2405 env47461 = env47462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env47461 == env47462) = true)

theorem identity47462 : scanCanonicalize (H12AffineFastState.compose env47462 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47462 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47463 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2356,268,2049,1,262,2065,2340,272,0,2340,33,17,294,268,16,2340,2064,2064,2340,305,32,256,33,2048,805]

theorem envBound47463 : H12AffineFastState.Bounded env47463 := by
  intro p hp
  have h : env47463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47462_47463 : H12AffineEnvironment.transform 5 17 env47462 = env47463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47462 == env47463) = true)

theorem identity47463 : scanCanonicalize (H12AffineFastState.compose env47463 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47463 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47464 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,2324,268,2049,1,262,2065,2308,272,0,2308,1,17,262,268,16,2308,2064,2064,2308,273,0,256,1,2048,773]

theorem envBound47464 : H12AffineFastState.Bounded env47464 := by
  intro p hp
  have h : env47464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47463_47464 : H12AffineEnvironment.transform 4 0 env47463 = env47464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47463 == env47464) = true)

theorem identity47464 : scanCanonicalize (H12AffineFastState.compose env47464 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47464 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47465 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2065,9,2049,1,3,2065,2049,21,0,2049,1,17,3,9,16,2049,2064,2064,2049,20,0,5,1,2048,512]

theorem envBound47465 : H12AffineFastState.Bounded env47465 := by
  intro p hp
  have h : env47465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47464_47465 : H12AffineEnvironment.transform 7 5 env47464 = env47465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47464 == env47465) = true)

def env47466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254010,17,21763,8193,65,171281,115014,17665,10281,119043,180272,256,98678,90202,63069]

theorem envBound47466 : H12AffineFastState.Bounded env47466 := by
  intro p hp
  have h : env47466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47454_47466 : H12AffineEnvironment.transform 6 9 env47454 = env47466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47454 == env47466) = true)

theorem identity47466 : scanCanonicalize (H12AffineFastState.compose env47466 (packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 115015) := by decide +kernel

theorem selectedBound47466 : packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env47467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,115015,76159,1024,32769,4161,8573,17,21763,8193,65,89174,115014,17665,10281,119043,65911,256,98678,90202,63069]

theorem envBound47467 : H12AffineFastState.Bounded env47467 := by
  intro p hp
  have h : env47467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47466_47467 : H12AffineEnvironment.transform 16 115015 env47466 = env47467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115015 env47466 == env47467) = true)

theorem identity47467 : scanCanonicalize (H12AffineFastState.compose env47467 (packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound47467 : packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS < 2^1333 := by decide +kernel

def env47468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,5393,64809,1024,32769,4161,8573,17,21763,8193,65,34816,5392,17665,10281,1365,54561,256,21792,46092,63069]

theorem envBound47468 : H12AffineFastState.Bounded env47468 := by
  intro p hp
  have h : env47468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47467_47468 : H12AffineEnvironment.transform 15 54358 env47467 = env47468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env47467 == env47468) = true)

theorem identity47468 : scanCanonicalize (H12AffineFastState.compose env47468 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47468 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env47469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,5393,23669,1024,8541,4161,8573,17,21763,8193,65,10588,5392,17665,10281,1365,29821,256,21792,5456,22273]

theorem envBound47469 : H12AffineFastState.Bounded env47469 := by
  intro p hp
  have h : env47469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47468_47469 : H12AffineEnvironment.transform 14 8540 env47468 = env47469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47468 == env47469) = true)

theorem identity47469 : scanCanonicalize (H12AffineFastState.compose env47469 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47469 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5393,2421,1024,8541,4161,8573,17,3,8193,65,10588,5392,4097,10281,1365,8573,256,32,5456,513]

theorem envBound47470 : H12AffineFastState.Bounded env47470 := by
  intro p hp
  have h : env47470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47469_47470 : H12AffineEnvironment.transform 13 5376 env47469 = env47470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47469 == env47470) = true)

theorem identity47470 : scanCanonicalize (H12AffineFastState.compose env47470 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47470 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1024,1,4161,33,17,3,349,65,2048,5392,4097,2421,1365,33,256,32,5456,513]

theorem envBound47471 : H12AffineFastState.Bounded env47471 := by
  intro p hp
  have h : env47471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47470_47471 : H12AffineEnvironment.transform 12 348 env47470 = env47471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47470 == env47471) = true)

theorem identity47471 : scanCanonicalize (H12AffineFastState.compose env47471 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47472 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,35,5220,2048,1024,1,4161,33,17,3,40,65,2048,5221,4097,2048,1056,33,117,32,5157,513]

theorem envBound47472 : H12AffineFastState.Bounded env47472 := by
  intro p hp
  have h : env47472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47471_47472 : H12AffineEnvironment.transform 7 117 env47471 = env47472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47471 == env47472) = true)

theorem identity47472 : scanCanonicalize (H12AffineFastState.compose env47472 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47472 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47473 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5172,2048,1024,1,4113,33,17,3,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound47473 : H12AffineFastState.Bounded env47473 := by
  intro p hp
  have h : env47473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47472_47473 : H12AffineEnvironment.transform 5 16 env47472 = env47473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47472 == env47473) = true)

def env47474 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,0,35,1028,2048,1024,1,33,33,17,3,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound47474 : H12AffineFastState.Bounded env47474 := by
  intro p hp
  have h : env47474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47473_47474 : H12AffineEnvironment.transform 11 48 env47473 = env47474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47473 == env47474) = true)

theorem identity47474 : scanCanonicalize (H12AffineFastState.compose env47474 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound47474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47475 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,48,41,1045,0,35,1028,1541,1024,1,33,33,17,3,40,17,1541,1029,49,1541,1056,33,37,32,1045,513]

theorem envBound47475 : H12AffineFastState.Bounded env47475 := by
  intro p hp
  have h : env47475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47474_47475 : H12AffineEnvironment.transform 10 1541 env47474 = env47475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env47474 == env47475) = true)

def env47476 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,41,33,0,35,48,561,52,1,33,33,17,3,40,17,561,49,49,561,20,33,37,32,33,513]

theorem envBound47476 : H12AffineFastState.Bounded env47476 := by
  intro p hp
  have h : env47476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47475_47476 : H12AffineEnvironment.transform 9 52 env47475 = env47476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47475 == env47476) = true)

theorem identity47476 : scanCanonicalize (H12AffineFastState.compose env47476 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound47476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47477 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,11,18,26,0,24,11,522,15,1,26,26,17,3,19,17,522,10,10,522,20,26,30,27,26,513]

theorem envBound47477 : H12AffineFastState.Bounded env47477 := by
  intro p hp
  have h : env47477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47476_47477 : H12AffineEnvironment.transform 4 27 env47476 = env47477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env47476 == env47477) = true)

def leafEnv47477 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,11,18,26,0,24,11,522,15,1,26,26,17,3,20,19,1,17,522,10,10,522,20,26,30,27,4,25,26,513,1,26,0]

def active47477 : List Nat := [0,1,2,3,8]

def tree47477 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47477 : H12WitnessSearch.Good tree47477 := H12GlobalWitnessIndex.good

theorem leafIdentity47477 : H12AffineFastState.composeSystem env47477 rootObs = leafEnv47477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47477 rootObs == leafEnv47477) = true)

theorem terminalChecked47477 : H12PackedTerminal.terminalCheckFast leafEnv47477 active47477 tree47477 = true := by decide +kernel

def env47478 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,41,32,0,35,49,560,53,1,33,33,17,3,40,17,560,48,49,560,21,33,37,32,32,513]

theorem envBound47478 : H12AffineFastState.Bounded env47478 := by
  intro p hp
  have h : env47478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47475_47478 : H12AffineEnvironment.transform 9 53 env47475 = env47478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47475 == env47478) = true)

theorem identity47478 : scanCanonicalize (H12AffineFastState.compose env47478 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound47478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47479 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,48,41,32,0,35,49,32,53,1,33,33,17,3,40,17,32,48,49,32,21,33,37,32,32,17]

theorem envBound47479 : H12AffineFastState.Bounded env47479 := by
  intro p hp
  have h : env47479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47478_47479 : H12AffineEnvironment.transform 8 16 env47478 = env47479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env47478 == env47479) = true)

def leafEnv47479 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,48,41,32,0,35,49,32,53,1,33,33,17,3,21,40,1,17,32,48,49,32,21,33,37,32,4,34,32,17,1,33,0]

def active47479 : List Nat := [0,1,2,3,4]

def tree47479 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47479 : H12WitnessSearch.Good tree47479 := H12GlobalWitnessIndex.good

theorem leafIdentity47479 : H12AffineFastState.composeSystem env47479 rootObs = leafEnv47479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47479 rootObs == leafEnv47479) = true)

theorem terminalChecked47479 : H12PackedTerminal.terminalCheckFast leafEnv47479 active47479 tree47479 = true := by decide +kernel

def env47480 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,0,35,1029,2048,1024,1,32,33,17,3,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound47480 : H12AffineFastState.Bounded env47480 := by
  intro p hp
  have h : env47480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47473_47480 : H12AffineEnvironment.transform 11 49 env47473 = env47480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47473 == env47480) = true)

theorem identity47480 : scanCanonicalize (H12AffineFastState.compose env47480 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound47480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47481 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,49,41,1044,0,35,1029,560,1024,1,32,33,17,3,40,17,560,1028,48,560,1056,33,37,32,1044,513]

theorem envBound47481 : H12AffineFastState.Bounded env47481 := by
  intro p hp
  have h : env47481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47480_47481 : H12AffineEnvironment.transform 10 560 env47480 = env47481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env47480 == env47481) = true)

def env47482 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,41,32,0,35,49,560,52,1,32,33,17,3,40,17,560,48,48,560,20,33,37,32,32,513]

theorem envBound47482 : H12AffineFastState.Bounded env47482 := by
  intro p hp
  have h : env47482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47481_47482 : H12AffineEnvironment.transform 9 52 env47481 = env47482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47481 == env47482) = true)

theorem identity47482 : scanCanonicalize (H12AffineFastState.compose env47482 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound47482 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47483 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,11,19,26,0,25,11,522,14,1,26,27,17,3,18,17,522,10,10,522,20,27,31,26,26,513]

theorem envBound47483 : H12AffineFastState.Bounded env47483 := by
  intro p hp
  have h : env47483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47482_47483 : H12AffineEnvironment.transform 4 26 env47482 = env47483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env47482 == env47483) = true)

def leafEnv47483 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,11,19,26,0,25,11,522,14,1,26,27,17,3,20,18,1,17,522,10,10,522,20,27,31,26,4,24,26,513,1,26,0]

def active47483 : List Nat := [0,1,2,3,8]

def tree47483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47483 : H12WitnessSearch.Good tree47483 := H12GlobalWitnessIndex.good

theorem leafIdentity47483 : H12AffineFastState.composeSystem env47483 rootObs = leafEnv47483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47483 rootObs == leafEnv47483) = true)

theorem terminalChecked47483 : H12PackedTerminal.terminalCheckFast leafEnv47483 active47483 tree47483 = true := by decide +kernel

def env47484 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,41,33,0,35,48,560,53,1,32,33,17,3,40,17,560,49,48,560,21,33,37,32,33,513]

theorem envBound47484 : H12AffineFastState.Bounded env47484 := by
  intro p hp
  have h : env47484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47481_47484 : H12AffineEnvironment.transform 9 53 env47481 = env47484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47481 == env47484) = true)

theorem identity47484 : scanCanonicalize (H12AffineFastState.compose env47484 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound47484 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47485 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,49,41,33,0,35,48,33,53,1,32,33,17,3,40,17,33,49,48,33,21,33,37,32,33,16]

theorem envBound47485 : H12AffineFastState.Bounded env47485 := by
  intro p hp
  have h : env47485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47484_47485 : H12AffineEnvironment.transform 8 17 env47484 = env47485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env47484 == env47485) = true)

def leafEnv47485 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,49,41,33,0,35,48,33,53,1,32,33,17,3,21,40,1,17,33,49,48,33,21,33,37,32,4,34,33,16,1,32,0]

def active47485 : List Nat := [0,1,2,3,4]

def tree47485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47485 : H12WitnessSearch.Good tree47485 := H12GlobalWitnessIndex.good

theorem leafIdentity47485 : H12AffineFastState.composeSystem env47485 rootObs = leafEnv47485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47485 rootObs == leafEnv47485) = true)

theorem terminalChecked47485 : H12PackedTerminal.terminalCheckFast leafEnv47485 active47485 tree47485 = true := by decide +kernel

def env47486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,2114882,8328,65,4292003,115151,17664,2111712,119042,4268163,256,2199999,2191386,63189]

theorem envBound47486 : H12AffineFastState.Bounded env47486 := by
  intro p hp
  have h : env47486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47426_47486 : H12AffineEnvironment.transform 22 2101329 env47426 = env47486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env47426 == env47486) = true)

def env47487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,21762,8328,65,4292003,115151,17664,10400,119042,4268163,256,98815,90202,63189]

theorem envBound47487 : H12AffineFastState.Bounded env47487 := by
  intro p hp
  have h : env47487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47486_47487 : H12AffineEnvironment.transform 20 4160 env47486 = env47487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47486 == env47487) = true)

theorem identity47487 : scanCanonicalize (H12AffineFastState.compose env47487 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201966) := by decide +kernel

theorem selectedBound47487 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,201966,17,21762,8328,65,158029,115151,17664,10400,119042,144493,256,98815,90202,63189]

theorem envBound47488 : H12AffineFastState.Bounded env47488 := by
  intro p hp
  have h : env47488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47487_47488 : H12AffineEnvironment.transform 21 201966 env47487 = env47488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201966 env47487 == env47488) = true)

theorem identity47488 : scanCanonicalize (H12AffineFastState.compose env47488 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47488 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138341,1024,29909,4160,201966,17,21762,8328,65,158029,79131,17664,10400,75222,144493,256,95531,90202,513]

theorem envBound47489 : H12AffineFastState.Bounded env47489 := by
  intro p hp
  have h : env47489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47488_47489 : H12AffineEnvironment.transform 14 29908 env47488 = env47489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47488 == env47489) = true)

theorem identity47489 : scanCanonicalize (H12AffineFastState.compose env47489 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound47489 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,97406,1024,29909,4160,29941,17,21762,8328,65,67926,79131,17664,10400,75222,87158,256,95531,90202,513]

theorem envBound47490 : H12AffineFastState.Bounded env47490 := by
  intro p hp
  have h : env47490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47489_47490 : H12AffineEnvironment.transform 16 90139 env47489 = env47490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env47489 == env47490) = true)

def env47491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79131,76158,1024,8661,4160,8693,17,2,8328,65,67926,79131,4096,10400,75222,65910,256,73771,79194,513]

theorem envBound47491 : H12AffineFastState.Bounded env47491 := by
  intro p hp
  have h : env47491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47490_47491 : H12AffineEnvironment.transform 13 5376 env47490 = env47491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47490 == env47491) = true)

theorem identity47491 : scanCanonicalize (H12AffineFastState.compose env47491 (packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47491 : packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env47492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,70863,67754,1024,1,4160,33,17,2,348,65,67926,70863,4096,2420,66562,65910,256,66047,70798,513]

theorem envBound47492 : H12AffineFastState.Bounded env47492 := by
  intro p hp
  have h : env47492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47491_47492 : H12AffineEnvironment.transform 12 468 env47491 = env47492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47491 == env47492) = true)

theorem identity47492 : scanCanonicalize (H12AffineFastState.compose env47492 (packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47492 : packedSelected [3,4,5,6,9,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env47493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,114,5309,2264,1024,1,4160,33,17,2,348,65,2340,5309,4096,2420,1136,260,256,397,5372,513]

theorem envBound47493 : H12AffineFastState.Bounded env47493 := by
  intro p hp
  have h : env47493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47492_47493 : H12AffineEnvironment.transform 15 114 env47492 = env47493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47492 == env47493) = true)

def env47494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79130,76159,1024,8660,4160,8692,17,3,8328,65,67926,79131,4097,10400,75222,65911,256,73770,79195,513]

theorem envBound47494 : H12AffineFastState.Bounded env47494 := by
  intro p hp
  have h : env47494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47490_47494 : H12AffineEnvironment.transform 13 5377 env47490 = env47494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47490 == env47494) = true)

theorem identity47494 : scanCanonicalize (H12AffineFastState.compose env47494 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47494 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,76159,1024,8541,4160,8573,17,3,8193,65,67926,79131,4097,10281,75103,65911,256,73770,79195,513]

theorem envBound47495 : H12AffineFastState.Bounded env47495 := by
  intro p hp
  have h : env47495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47494_47495 : H12AffineEnvironment.transform 6 9 env47494 = env47495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47494 == env47495) = true)

theorem identity47495 : scanCanonicalize (H12AffineFastState.compose env47495 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47495 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5392,2421,1024,8541,4160,8573,17,3,8193,65,10588,5393,4097,10281,1365,8573,256,32,5457,513]

theorem envBound47496 : H12AffineFastState.Bounded env47496 := by
  intro p hp
  have h : env47496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47495_47496 : H12AffineEnvironment.transform 15 8202 env47495 = env47496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47495 == env47496) = true)

theorem identity47496 : scanCanonicalize (H12AffineFastState.compose env47496 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47496 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2421,1024,1,4160,33,17,3,349,65,2048,5393,4097,2421,1365,33,256,32,5457,513]

theorem envBound47497 : H12AffineFastState.Bounded env47497 := by
  intro p hp
  have h : env47497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47496_47497 : H12AffineEnvironment.transform 12 348 env47496 = env47497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47496 == env47497) = true)

theorem identity47497 : scanCanonicalize (H12AffineFastState.compose env47497 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47497 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47498 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,0,34,5220,2049,1024,1,4160,33,17,3,41,65,2048,5221,4097,2049,1057,33,116,32,5157,513]

theorem envBound47498 : H12AffineFastState.Bounded env47498 := by
  intro p hp
  have h : env47498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47497_47498 : H12AffineEnvironment.transform 7 116 env47497 = env47498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47497 == env47498) = true)

theorem identity47498 : scanCanonicalize (H12AffineFastState.compose env47498 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47498 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47499 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,0,34,5172,2049,1024,1,4112,33,17,3,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound47499 : H12AffineFastState.Bounded env47499 := by
  intro p hp
  have h : env47499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47498_47499 : H12AffineEnvironment.transform 5 16 env47498 = env47499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47498 == env47499) = true)

def env47500 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,0,34,1028,2049,1024,1,32,33,17,3,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound47500 : H12AffineFastState.Bounded env47500 := by
  intro p hp
  have h : env47500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47499_47500 : H12AffineEnvironment.transform 11 48 env47499 = env47500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47499 == env47500) = true)

theorem identity47500 : scanCanonicalize (H12AffineFastState.compose env47500 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47501 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,16,8,1045,0,2,1028,2049,1024,1,0,1,17,3,9,17,2048,1029,17,2049,1025,1,4,0,1045,513]

theorem envBound47501 : H12AffineFastState.Bounded env47501 := by
  intro p hp
  have h : env47501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47500_47501 : H12AffineEnvironment.transform 4 0 env47500 = env47501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47500 == env47501) = true)

def env47502 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,8,1,0,2,16,2049,20,1,0,1,17,3,9,17,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound47502 : H12AffineFastState.Bounded env47502 := by
  intro p hp
  have h : env47502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47501_47502 : H12AffineEnvironment.transform 9 20 env47501 = env47502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47501 == env47502) = true)

theorem identity47502 : scanCanonicalize (H12AffineFastState.compose env47502 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound47502 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47503 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,16,8,1,0,2,16,522,20,1,0,1,17,3,9,17,523,17,17,522,21,1,4,0,1,513]

theorem envBound47503 : H12AffineFastState.Bounded env47503 := by
  intro p hp
  have h : env47503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47502_47503 : H12AffineEnvironment.transform 10 523 env47502 = env47503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env47502 == env47503) = true)

def leafEnv47503 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,16,8,1,0,2,16,522,20,1,0,1,17,3,21,9,1,17,523,17,17,522,21,1,4,0,4,3,1,513,1,0,0]

def active47503 : List Nat := [0,1,2,3,8]

def tree47503 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47503 : H12WitnessSearch.Good tree47503 := H12GlobalWitnessIndex.good

theorem leafIdentity47503 : H12AffineFastState.composeSystem env47503 rootObs = leafEnv47503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47503 rootObs == leafEnv47503) = true)

theorem terminalChecked47503 : H12PackedTerminal.terminalCheckFast leafEnv47503 active47503 tree47503 = true := by decide +kernel

def env47504 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,8,0,0,2,17,2049,21,1,0,1,17,3,9,17,2048,16,17,2049,20,1,4,0,0,513]

theorem envBound47504 : H12AffineFastState.Bounded env47504 := by
  intro p hp
  have h : env47504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47501_47504 : H12AffineEnvironment.transform 9 21 env47501 = env47504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env47501 == env47504) = true)

theorem identity47504 : scanCanonicalize (H12AffineFastState.compose env47504 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47505 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,8,0,0,2,17,1,21,1,0,1,17,3,9,17,0,16,17,1,20,1,4,0,0,513]

theorem envBound47505 : H12AffineFastState.Bounded env47505 := by
  intro p hp
  have h : env47505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47504_47505 : H12AffineEnvironment.transform 10 0 env47504 = env47505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47504 == env47505) = true)

def leafEnv47505 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,8,0,0,2,17,1,21,1,0,1,17,3,20,9,1,17,0,16,17,1,20,1,4,0,4,3,0,513,1,0,0]

def active47505 : List Nat := [0,1,2,3,8]

def tree47505 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47505 : H12WitnessSearch.Good tree47505 := H12GlobalWitnessIndex.good

theorem leafIdentity47505 : H12AffineFastState.composeSystem env47505 rootObs = leafEnv47505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47505 rootObs == leafEnv47505) = true)

theorem terminalChecked47505 : H12PackedTerminal.terminalCheckFast leafEnv47505 active47505 tree47505 = true := by decide +kernel

def env47506 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,0,34,1029,2049,1024,1,33,33,17,3,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound47506 : H12AffineFastState.Bounded env47506 := by
  intro p hp
  have h : env47506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47499_47506 : H12AffineEnvironment.transform 11 49 env47499 = env47506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47499 == env47506) = true)

theorem identity47506 : scanCanonicalize (H12AffineFastState.compose env47506 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound47506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47507 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,49,40,1,0,34,16,2049,21,1,33,33,17,3,41,17,2048,17,48,2049,52,33,36,32,1,513]

theorem envBound47507 : H12AffineFastState.Bounded env47507 := by
  intro p hp
  have h : env47507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47506_47507 : H12AffineEnvironment.transform 9 21 env47506 = env47507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env47506 == env47507) = true)

def env47508 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,8,1,0,2,16,2049,21,1,1,1,17,3,9,17,2048,17,16,2049,20,1,4,0,1,513]

theorem envBound47508 : H12AffineFastState.Bounded env47508 := by
  intro p hp
  have h : env47508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47507_47508 : H12AffineEnvironment.transform 4 0 env47507 = env47508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47507 == env47508) = true)

theorem identity47508 : scanCanonicalize (H12AffineFastState.compose env47508 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47508 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47509 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,8,1,0,2,16,0,21,1,1,1,17,3,9,17,1,17,16,0,20,1,4,0,1,513]

theorem envBound47509 : H12AffineFastState.Bounded env47509 := by
  intro p hp
  have h : env47509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47508_47509 : H12AffineEnvironment.transform 10 1 env47508 = env47509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47508 == env47509) = true)

def leafEnv47509 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,8,1,0,2,16,0,21,1,1,1,17,3,20,9,1,17,1,17,16,0,20,1,4,0,4,3,1,513,1,1,0]

def active47509 : List Nat := [0,1,2,3,8]

def tree47509 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47509 : H12WitnessSearch.Good tree47509 := H12GlobalWitnessIndex.good

theorem leafIdentity47509 : H12AffineFastState.composeSystem env47509 rootObs = leafEnv47509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47509 rootObs == leafEnv47509) = true)

theorem terminalChecked47509 : H12PackedTerminal.terminalCheckFast leafEnv47509 active47509 tree47509 = true := by decide +kernel

def env47510 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,9,1,0,3,16,2049,21,1,0,0,17,3,8,17,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound47510 : H12AffineFastState.Bounded env47510 := by
  intro p hp
  have h : env47510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47507_47510 : H12AffineEnvironment.transform 4 1 env47507 = env47510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47507 == env47510) = true)

theorem identity47510 : scanCanonicalize (H12AffineFastState.compose env47510 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound47510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47511 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,16,9,1,0,3,16,522,21,1,0,0,17,3,8,17,523,17,17,522,21,0,5,1,1,513]

theorem envBound47511 : H12AffineFastState.Bounded env47511 := by
  intro p hp
  have h : env47511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47510_47511 : H12AffineEnvironment.transform 10 523 env47510 = env47511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env47510 == env47511) = true)

def leafEnv47511 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,16,9,1,0,3,16,522,21,1,0,0,17,3,21,8,1,17,523,17,17,522,21,0,5,1,4,2,1,513,1,0,0]

def active47511 : List Nat := [0,1,2,3,8]

def tree47511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47511 : H12WitnessSearch.Good tree47511 := H12GlobalWitnessIndex.good

theorem leafIdentity47511 : H12AffineFastState.composeSystem env47511 rootObs = leafEnv47511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47511 rootObs == leafEnv47511) = true)

theorem terminalChecked47511 : H12PackedTerminal.terminalCheckFast leafEnv47511 active47511 tree47511 = true := by decide +kernel

def env47512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,21763,8328,65,4292003,115151,17664,10401,119042,4268163,256,98814,90203,63189]

theorem envBound47512 : H12AffineFastState.Bounded env47512 := by
  intro p hp
  have h : env47512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47486_47512 : H12AffineEnvironment.transform 20 4161 env47486 = env47512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47486 == env47512) = true)

theorem identity47512 : scanCanonicalize (H12AffineFastState.compose env47512 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound47512 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190641,1024,32769,4161,4194304,16,21763,8328,65,4237692,5392,17664,10401,1501,4256860,256,21793,46212,63189]

theorem envBound47513 : H12AffineFastState.Bounded env47513 := by
  intro p hp
  have h : env47513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47512_47513 : H12AffineEnvironment.transform 15 54495 env47512 = env47513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env47512 == env47513) = true)

def env47514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4161,4194304,16,21763,8192,65,4237692,5392,17664,10281,1365,4256860,256,21793,46092,63069]

theorem envBound47514 : H12AffineFastState.Bounded env47514 := by
  intro p hp
  have h : env47514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47513_47514 : H12AffineEnvironment.transform 6 8 env47513 = env47514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47513 == env47514) = true)

theorem identity47514 : scanCanonicalize (H12AffineFastState.compose env47514 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound47514 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4161,4194304,16,21763,8192,65,4237692,5392,17664,10281,1365,4256860,256,21793,46092,63069]

theorem envBound47515 : H12AffineFastState.Bounded env47515 := by
  intro p hp
  have h : env47515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47514_47515 : H12AffineEnvironment.transform 16 24909 env47514 = env47515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env47514 == env47515) = true)

theorem identity47515 : scanCanonicalize (H12AffineFastState.compose env47515 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32880) := by decide +kernel

theorem selectedBound47515 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4161,32880,16,21763,8192,65,10508,5392,17664,10281,1365,29740,256,21793,46092,63069]

theorem envBound47516 : H12AffineFastState.Bounded env47516 := by
  intro p hp
  have h : env47516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47515_47516 : H12AffineEnvironment.transform 21 32880 env47515 = env47516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32880 env47515 == env47516) = true)

theorem identity47516 : scanCanonicalize (H12AffineFastState.compose env47516 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound47516 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env47517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,21875,24909,2128,1024,293,4161,340,16,21763,8192,65,10508,5392,17664,10281,1365,29740,256,21793,13608,30585]

theorem envBound47517 : H12AffineFastState.Bounded env47517 := by
  intro p hp
  have h : env47517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47516_47517 : H12AffineEnvironment.transform 14 292 env47516 = env47517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env47516 == env47517) = true)

theorem identity47517 : scanCanonicalize (H12AffineFastState.compose env47517 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47517 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env47518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,292,21875,16400,2128,1024,293,4161,340,16,21763,349,65,2129,5392,17664,2420,1365,21873,256,21793,5237,22052]

theorem envBound47518 : H12AffineFastState.Bounded env47518 := by
  intro p hp
  have h : env47518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47517_47518 : H12AffineEnvironment.transform 12 349 env47517 = env47518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47517 == env47518) = true)

theorem identity47518 : scanCanonicalize (H12AffineFastState.compose env47518 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47518 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env47519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,292,114,5393,2128,1024,293,4161,340,16,2,349,65,2129,5392,4097,2420,1365,112,256,32,5237,805]

theorem envBound47519 : H12AffineFastState.Bounded env47519 := by
  intro p hp
  have h : env47519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47518_47519 : H12AffineEnvironment.transform 13 5377 env47518 = env47519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47518 == env47519) = true)

theorem identity47519 : scanCanonicalize (H12AffineFastState.compose env47519 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound47519 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47520 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4404,292,114,4388,2128,53,293,4161,340,16,2,349,65,2129,4389,4097,2420,352,112,256,32,4160,805]

theorem envBound47520 : H12AffineFastState.Bounded env47520 := by
  intro p hp
  have h : env47520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47519_47520 : H12AffineEnvironment.transform 9 53 env47519 = env47520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47519 == env47520) = true)

theorem identity47520 : scanCanonicalize (H12AffineFastState.compose env47520 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47520 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47521 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,121,4112,0,114,4096,2128,53,1,4161,112,16,2,121,65,2129,4097,4097,2128,68,112,36,32,4160,513]

theorem envBound47521 : H12AffineFastState.Bounded env47521 := by
  intro p hp
  have h : env47521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47520_47521 : H12AffineEnvironment.transform 7 36 env47520 = env47521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47520 == env47521) = true)

theorem identity47521 : scanCanonicalize (H12AffineFastState.compose env47521 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47521 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env47522 : List Nat := [2,4,8,16,17,64,8,21,512,4,2048,4096,72,4112,0,67,4096,2128,4,1,4161,65,16,2,72,65,2129,4097,4097,2128,68,65,21,17,4160,513]

theorem envBound47522 : H12AffineFastState.Bounded env47522 := by
  intro p hp
  have h : env47522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47521_47522 : H12AffineEnvironment.transform 4 17 env47521 = env47522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47521 == env47522) = true)

theorem identity47522 : scanCanonicalize (H12AffineFastState.compose env47522 (packedSelected [0,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound47522 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env47523 : List Nat := [2,4,8,16,17,64,8,21,512,4,2048,576,72,592,0,67,576,2128,4,1,513,65,16,2,72,65,2129,577,577,2128,68,65,21,17,512,513]

theorem envBound47523 : H12AffineFastState.Bounded env47523 := by
  intro p hp
  have h : env47523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47522_47523 : H12AffineEnvironment.transform 11 576 env47522 = env47523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env47522 == env47523) = true)

theorem identity47523 : scanCanonicalize (H12AffineFastState.compose env47523 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47523 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47524 : List Nat := [2,4,8,16,17,64,8,21,1,4,2048,65,72,81,0,67,65,2128,4,1,0,65,16,2,72,65,2129,64,64,2128,68,65,21,17,1,0]

theorem envBound47524 : H12AffineFastState.Bounded env47524 := by
  intro p hp
  have h : env47524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47523_47524 : H12AffineEnvironment.transform 8 1 env47523 = env47524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47523 == env47524) = true)

def env47525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21763,8193,65,4237692,5392,17664,10280,1364,4256860,256,21793,46093,63068]

theorem envBound47525 : H12AffineFastState.Bounded env47525 := by
  intro p hp
  have h : env47525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47513_47525 : H12AffineEnvironment.transform 6 9 env47513 = env47525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47513 == env47525) = true)

theorem identity47525 : scanCanonicalize (H12AffineFastState.compose env47525 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound47525 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,10281,1024,32769,4161,4194304,16,21763,8193,65,4237692,5392,17664,10280,1364,4256860,256,21793,46093,63068]

theorem envBound47526 : H12AffineFastState.Bounded env47526 := by
  intro p hp
  have h : env47526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47525_47526 : H12AffineEnvironment.transform 16 49169 env47525 = env47526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47525 == env47526) = true)

theorem identity47526 : scanCanonicalize (H12AffineFastState.compose env47526 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound47526 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40970,46157,10281,1024,32769,4161,4194304,16,8543,8193,65,4237692,5392,12636,10280,1364,4227072,256,8573,46093,33280]

theorem envBound47527 : H12AffineFastState.Bounded env47527 := by
  intro p hp
  have h : env47527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47526_47527 : H12AffineEnvironment.transform 13 13404 env47526 = env47527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env47526 == env47527) = true)

theorem identity47527 : scanCanonicalize (H12AffineFastState.compose env47527 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47527 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env47528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,13388,10281,1024,0,4161,4194304,16,8543,8193,65,4204925,5392,12636,10280,1364,4194305,256,8573,13324,513]

theorem envBound47528 : H12AffineFastState.Bounded env47528 := by
  intro p hp
  have h : env47528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47527_47528 : H12AffineEnvironment.transform 14 1 env47527 = env47528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47527 == env47528) = true)

theorem identity47528 : scanCanonicalize (H12AffineFastState.compose env47528 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound47528 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,13388,10281,1024,0,4161,33,16,8543,8193,65,10588,5392,12636,10280,1364,32,256,8573,13324,513]

theorem envBound47529 : H12AffineFastState.Bounded env47529 := by
  intro p hp
  have h : env47529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47528_47529 : H12AffineEnvironment.transform 21 33 env47528 = env47529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47528 == env47529) = true)

theorem identity47529 : scanCanonicalize (H12AffineFastState.compose env47529 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47529 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5393,2420,1024,0,4161,33,16,2,348,65,2049,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound47530 : H12AffineFastState.Bounded env47530 := by
  intro p hp
  have h : env47530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47529_47530 : H12AffineEnvironment.transform 12 349 env47529 = env47530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47529 == env47530) = true)

theorem identity47530 : scanCanonicalize (H12AffineFastState.compose env47530 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47531 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,263,5393,2341,1024,0,4112,33,16,2,269,16,2049,5392,4097,2340,1285,32,256,32,5376,513]

theorem envBound47531 : H12AffineFastState.Bounded env47531 := by
  intro p hp
  have h : env47531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47530_47531 : H12AffineEnvironment.transform 5 17 env47530 = env47531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47530 == env47531) = true)

theorem identity47531 : scanCanonicalize (H12AffineFastState.compose env47531 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47532 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,268,1329,1,263,1313,2341,1024,0,32,33,16,2,269,16,2049,1312,49,2340,1285,32,256,32,1328,513]

theorem envBound47532 : H12AffineFastState.Bounded env47532 := by
  intro p hp
  have h : env47532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47531_47532 : H12AffineEnvironment.transform 11 48 env47531 = env47532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47531 == env47532) = true)

theorem identity47532 : scanCanonicalize (H12AffineFastState.compose env47532 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound47532 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47533 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1556,48,268,1329,1,263,1313,1841,1024,0,32,33,16,2,269,16,1557,1312,49,1840,1285,32,256,32,1328,513]

theorem envBound47533 : H12AffineFastState.Bounded env47533 := by
  intro p hp
  have h : env47533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47532_47533 : H12AffineEnvironment.transform 10 1556 env47532 = env47533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env47532 == env47533) = true)

theorem identity47533 : scanCanonicalize (H12AffineFastState.compose env47533 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound47533 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47534 : List Nat := [2,4,8,16,32,17,9,256,512,36,560,48,268,277,1,263,261,789,36,0,32,33,16,2,269,16,561,260,49,788,289,32,256,32,276,513]

theorem envBound47534 : H12AffineFastState.Bounded env47534 := by
  intro p hp
  have h : env47534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47533_47534 : H12AffineEnvironment.transform 9 36 env47533 = env47534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env47533 == env47534) = true)

theorem identity47534 : scanCanonicalize (H12AffineFastState.compose env47534 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound47534 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47535 : List Nat := [2,4,8,16,32,17,9,52,512,36,560,48,56,33,1,51,49,545,36,0,32,33,16,2,57,16,561,48,49,544,21,32,52,32,32,513]

theorem envBound47535 : H12AffineFastState.Bounded env47535 := by
  intro p hp
  have h : env47535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47534_47535 : H12AffineEnvironment.transform 7 52 env47534 = env47535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env47534 == env47535) = true)

theorem identity47535 : scanCanonicalize (H12AffineFastState.compose env47535 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound47535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47536 : List Nat := [2,4,8,16,32,17,9,52,27,36,43,48,56,33,1,51,49,58,36,0,32,33,16,2,57,16,42,48,49,59,21,32,52,32,32,26]

theorem envBound47536 : H12AffineFastState.Bounded env47536 := by
  intro p hp
  have h : env47536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47535_47536 : H12AffineEnvironment.transform 8 27 env47535 = env47536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env47535 == env47536) = true)

theorem identity47536 : scanCanonicalize (H12AffineFastState.compose env47536 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound47536 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47537 : List Nat := [2,4,8,16,26,17,9,14,27,30,17,10,2,27,1,9,11,0,30,0,26,27,16,2,3,16,16,10,11,1,21,26,14,26,26,26]

theorem envBound47537 : H12AffineFastState.Bounded env47537 := by
  intro p hp
  have h : env47537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47536_47537 : H12AffineEnvironment.transform 4 26 env47536 = env47537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env47536 == env47537) = true)

theorem identity47537 : scanCanonicalize (H12AffineFastState.compose env47537 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47537 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env47538 : List Nat := [2,4,2,16,16,17,3,4,17,20,17,0,2,17,1,3,1,0,20,0,16,17,16,2,3,16,16,0,1,1,21,16,4,16,16,16]

theorem envBound47538 : H12AffineFastState.Bounded env47538 := by
  intro p hp
  have h : env47538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47537_47538 : H12AffineEnvironment.transform 2 2 env47537 = env47538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47537 == env47538) = true)

def env47539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound47539 : H12AffineFastState.Bounded env47539 := by
  intro p hp
  have h : env47539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47313_47539 : H12AffineEnvironment.transform 18 1025 env47313 = env47539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env47313 == env47539) = true)

theorem identity47539 : scanCanonicalize (H12AffineFastState.compose env47539 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444659) := by decide +kernel

theorem selectedBound47539 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444659,16777216,8328,65,23235955,18973836,333858,2329970,19188066,23160257,257,17074654,17066106,19263156]

theorem envBound47540 : H12AffineFastState.Bounded env47540 := by
  intro p hp
  have h : env47540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47539_47540 : H12AffineEnvironment.transform 22 2444659 env47539 = env47540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444659 env47539 == env47540) = true)

def env47541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,16777216,8328,65,16959643,18973836,333858,2329970,19188066,16850985,257,17074654,17066106,19263156]

theorem envBound47541 : H12AffineFastState.Bounded env47541 := by
  intro p hp
  have h : env47541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47540_47541 : H12AffineEnvironment.transform 21 2115048 env47540 = env47541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env47540 == env47541) = true)

def env47542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431072,8328,65,2609403,302316,333858,2329970,119042,2373705,257,2199998,2191386,63188]

theorem envBound47542 : H12AffineFastState.Bounded env47542 := by
  intro p hp
  have h : env47542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47541_47542 : H12AffineEnvironment.transform 23 2431072 env47541 = env47542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env47541 == env47542) = true)

def env47543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329760,8328,65,508091,302316,333858,236850,119042,272393,257,98814,90202,63188]

theorem envBound47543 : H12AffineFastState.Bounded env47543 := by
  intro p hp
  have h : env47543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47542_47543 : H12AffineEnvironment.transform 20 4160 env47542 = env47543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47542 == env47543) = true)

theorem identity47543 : scanCanonicalize (H12AffineFastState.compose env47543 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound47543 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,4160,21928,120015,98780,8328,65,215367,5392,102878,236850,119042,41461,257,98814,90202,63188]

theorem envBound47544 : H12AffineFastState.Bounded env47544 := by
  intro p hp
  have h : env47544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47543_47544 : H12AffineEnvironment.transform 17 35324 env47543 = env47544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env47543 == env47544) = true)

def env47545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1025,8541,4160,21928,95635,73856,8328,65,215367,5392,77954,212078,94302,169,257,73890,90202,22408]

theorem envBound47545 : H12AffineFastState.Bounded env47545 := by
  intro p hp
  have h : env47545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47544_47545 : H12AffineEnvironment.transform 14 8540 env47544 = env47545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47544 == env47545) = true)

theorem identity47545 : scanCanonicalize (H12AffineFastState.compose env47545 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound47545 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10400,1025,8541,4160,21928,153,21898,8328,65,146509,5392,17800,149860,1364,169,257,21928,5456,22408]

theorem envBound47546 : H12AffineFastState.Bounded env47546 := by
  intro p hp
  have h : env47546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47545_47546 : H12AffineEnvironment.transform 15 29962 env47545 = env47546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env47545 == env47546) = true)

theorem identity47546 : scanCanonicalize (H12AffineFastState.compose env47546 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound47546 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,5529,10400,1025,8541,4160,21928,153,21898,8328,65,10708,5392,17800,23805,1364,169,257,21928,5456,22408]

theorem envBound47547 : H12AffineFastState.Bounded env47547 := by
  intro p hp
  have h : env47547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47546_47547 : H12AffineEnvironment.transform 16 5529 env47546 = env47547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env47546 == env47547) = true)

theorem identity47547 : scanCanonicalize (H12AffineFastState.compose env47547 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound47547 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,8540,171,5529,10400,1025,8541,4160,8201,153,8235,8328,65,10708,5392,12329,10588,1364,169,257,8201,5456,8745]

theorem envBound47548 : H12AffineFastState.Bounded env47548 := by
  intro p hp
  have h : env47548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47547_47548 : H12AffineEnvironment.transform 13 13729 env47547 = env47548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env47547 == env47548) = true)

theorem identity47548 : scanCanonicalize (H12AffineFastState.compose env47548 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47548 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env47549 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13525,8232,171,5357,10400,1025,8233,4160,8201,153,8235,8328,65,10400,5220,12329,10280,1056,169,117,8201,5156,8745]

theorem envBound47549 : H12AffineFastState.Bounded env47549 := by
  intro p hp
  have h : env47549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47548_47549 : H12AffineEnvironment.transform 7 116 env47548 = env47549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47548 == env47549) = true)

theorem identity47549 : scanCanonicalize (H12AffineFastState.compose env47549 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47549 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env47550 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8232,35,5221,10280,1025,8233,4160,8201,17,8235,8192,65,10280,5220,12329,10280,1056,33,117,8201,5156,8745]

theorem envBound47550 : H12AffineFastState.Bounded env47550 := by
  intro p hp
  have h : env47550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47549_47550 : H12AffineEnvironment.transform 6 8 env47549 = env47550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47549 == env47550) = true)

theorem identity47550 : scanCanonicalize (H12AffineFastState.compose env47550 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound47550 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47551 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,4112,1125,35,5221,3173,1025,1124,4160,1092,17,1126,1101,65,3173,5220,5220,3173,1056,33,117,1092,5156,1636]

theorem envBound47551 : H12AffineFastState.Bounded env47551 := by
  intro p hp
  have h : env47551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47550_47551 : H12AffineEnvironment.transform 12 1101 env47550 = env47551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env47550 == env47551) = true)

def env47552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1025,8540,4160,21928,95634,73857,8328,65,215367,5392,77955,212079,94303,168,257,73891,90202,22409]

theorem envBound47552 : H12AffineFastState.Bounded env47552 := by
  intro p hp
  have h : env47552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47544_47552 : H12AffineEnvironment.transform 14 8541 env47544 = env47552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47544 == env47552) = true)

def env47553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1025,8540,4160,32,73754,73857,8328,65,203983,5392,77955,212079,75223,168,257,73891,79314,513]

theorem envBound47553 : H12AffineFastState.Bounded env47553 := by
  intro p hp
  have h : env47553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47552_47553 : H12AffineEnvironment.transform 13 5512 env47552 = env47553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47552 == env47553) = true)

theorem identity47553 : scanCanonicalize (H12AffineFastState.compose env47553 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 70814) := by decide +kernel

theorem selectedBound47553 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,70814,10401,1025,8540,4160,32,73754,73857,8328,65,2129,5392,77955,10481,75223,168,257,73891,79314,513]

theorem envBound47554 : H12AffineFastState.Bounded env47554 := by
  intro p hp
  have h : env47554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47553_47554 : H12AffineEnvironment.transform 16 70814 env47553 = env47554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70814 env47553 == env47554) = true)

def env47555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1025,8540,4160,33,73755,73857,8328,65,203982,5392,77955,212079,75222,168,257,73891,79315,512]

theorem envBound47555 : H12AffineFastState.Bounded env47555 := by
  intro p hp
  have h : env47555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47552_47555 : H12AffineEnvironment.transform 13 5513 env47552 = env47555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47552 == env47555) = true)

theorem identity47555 : scanCanonicalize (H12AffineFastState.compose env47555 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound47555 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,79130,10401,1025,8540,4160,33,73755,73857,8328,65,10708,5392,77955,2421,75222,168,257,73891,79315,512]

theorem envBound47556 : H12AffineFastState.Bounded env47556 := by
  intro p hp
  have h : env47556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47555_47556 : H12AffineEnvironment.transform 16 79130 env47555 = env47556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env47555 == env47556) = true)

theorem identity47556 : scanCanonicalize (H12AffineFastState.compose env47556 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound47556 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8323,5529,10401,1025,8540,4160,33,152,2,8328,65,10708,5392,4096,2421,1365,168,257,32,5456,512]

theorem envBound47557 : H12AffineFastState.Bounded env47557 := by
  intro p hp
  have h : env47557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47556_47557 : H12AffineEnvironment.transform 15 8323 env47556 = env47557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env47556 == env47557) = true)

theorem identity47557 : scanCanonicalize (H12AffineFastState.compose env47557 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47557 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47558 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,4588,8541,8323,4604,10401,100,8540,4160,33,152,2,8328,65,10708,4469,4096,2421,304,168,257,32,4405,512]

theorem envBound47558 : H12AffineFastState.Bounded env47558 := by
  intro p hp
  have h : env47558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47557_47558 : H12AffineEnvironment.transform 9 101 env47557 = env47558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47557 == env47558) = true)

theorem identity47558 : scanCanonicalize (H12AffineFastState.compose env47558 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound47558 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env47559 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,6429,4588,6208,6558,4604,4540,100,6209,4160,33,152,2,6549,65,4297,4469,4096,2421,304,168,257,32,4405,512]

theorem envBound47559 : H12AffineFastState.Bounded env47559 := by
  intro p hp
  have h : env47559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47558_47559 : H12AffineEnvironment.transform 12 6429 env47558 = env47559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env47558 == env47559) = true)

theorem identity47559 : scanCanonicalize (H12AffineFastState.compose env47559 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound47559 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env47560 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,152,2437,372,2264,2310,356,292,100,2265,216,33,152,2,2317,65,81,493,152,2421,304,168,257,32,429,512]

theorem envBound47560 : H12AffineFastState.Bounded env47560 := by
  intro p hp
  have h : env47560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47559_47560 : H12AffineEnvironment.transform 11 152 env47559 = env47560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env47559 == env47560) = true)

theorem identity47560 : scanCanonicalize (H12AffineFastState.compose env47560 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound47560 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env47561 : List Nat := [2,4,8,16,32,64,128,256,512,101,428,152,41,372,372,170,356,292,100,373,216,33,152,2,161,65,81,493,152,217,304,168,257,32,429,512]

theorem envBound47561 : H12AffineFastState.Bounded env47561 := by
  intro p hp
  have h : env47561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47560_47561 : H12AffineEnvironment.transform 10 428 env47560 = env47561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env47560 == env47561) = true)

theorem identity47561 : scanCanonicalize (H12AffineFastState.compose env47561 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47561 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47562 : List Nat := [2,4,8,16,32,64,128,36,512,101,136,152,41,80,80,170,64,0,100,81,216,33,152,2,161,65,81,201,152,217,20,168,37,32,137,512]

theorem envBound47562 : H12AffineFastState.Bounded env47562 := by
  intro p hp
  have h : env47562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47561_47562 : H12AffineEnvironment.transform 7 36 env47561 = env47562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47561 == env47562) = true)

theorem identity47562 : scanCanonicalize (H12AffineFastState.compose env47562 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound47562 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env47563 : List Nat := [2,4,8,16,32,64,120,36,512,101,112,96,41,80,80,82,64,0,100,81,32,33,96,2,89,65,81,49,96,33,20,80,37,32,113,512]

theorem envBound47563 : H12AffineFastState.Bounded env47563 := by
  intro p hp
  have h : env47563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47562_47563 : H12AffineEnvironment.transform 6 120 env47562 = env47563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env47562 == env47563) = true)

theorem identity47563 : scanCanonicalize (H12AffineFastState.compose env47563 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47563 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env47564 : List Nat := [2,4,8,16,1,64,89,5,512,68,81,65,8,80,80,82,64,0,69,81,1,0,65,2,89,65,81,16,65,0,20,80,4,1,80,512]

theorem envBound47564 : H12AffineFastState.Bounded env47564 := by
  intro p hp
  have h : env47564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47563_47564 : H12AffineEnvironment.transform 4 1 env47563 = env47564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47563 == env47564) = true)

theorem identity47564 : scanCanonicalize (H12AffineFastState.compose env47564 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47564 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47565 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,17,8,0,0,2,16,0,21,1,1,0,17,2,9,17,1,16,17,0,20,0,4,1,0,512]

theorem envBound47565 : H12AffineFastState.Bounded env47565 := by
  intro p hp
  have h : env47565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47564_47565 : H12AffineEnvironment.transform 5 16 env47564 = env47565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47564 == env47565) = true)

theorem identity47565 : scanCanonicalize (H12AffineFastState.compose env47565 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound47565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47566 : List Nat := [2,4,8,16,1,16,9,5,15,20,1,17,8,0,0,2,16,0,21,1,1,0,17,2,9,17,1,16,17,0,20,0,4,1,0,15]

theorem envBound47566 : H12AffineFastState.Bounded env47566 := by
  intro p hp
  have h : env47566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47565_47566 : H12AffineEnvironment.transform 8 15 env47565 = env47566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env47565 == env47566) = true)

theorem identity47566 : scanCanonicalize (H12AffineFastState.compose env47566 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47567 : List Nat := [2,4,8,1,1,1,9,5,15,5,1,0,8,0,0,2,1,0,4,1,1,0,0,2,9,0,1,1,0,0,5,0,4,1,0,15]

theorem envBound47567 : H12AffineFastState.Bounded env47567 := by
  intro p hp
  have h : env47567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47566_47567 : H12AffineEnvironment.transform 3 1 env47566 = env47567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47566 == env47567) = true)

theorem identity47567 : scanCanonicalize (H12AffineFastState.compose env47567 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound47567 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47568 : List Nat := [2,4,7,1,1,1,6,5,0,5,1,0,7,0,0,2,1,0,4,1,1,0,0,2,6,0,1,1,0,0,5,0,4,1,0,0]

theorem envBound47568 : H12AffineFastState.Bounded env47568 := by
  intro p hp
  have h : env47568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47567_47568 : H12AffineEnvironment.transform 2 7 env47567 = env47568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env47567 == env47568) = true)

def env47569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329761,8328,65,508090,302316,333858,236851,119042,272392,257,98815,90203,63188]

theorem envBound47569 : H12AffineFastState.Bounded env47569 := by
  intro p hp
  have h : env47569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47542_47569 : H12AffineEnvironment.transform 20 4161 env47542 = env47569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47542 == env47569) = true)

theorem identity47569 : scanCanonicalize (H12AffineFastState.compose env47569 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound47569 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,21929,351538,329761,8328,65,472175,288825,333858,223718,75223,272392,257,95530,90203,513]

theorem envBound47570 : H12AffineFastState.Bounded env47570 := by
  intro p hp
  have h : env47570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47569_47570 : H12AffineEnvironment.transform 14 29909 env47569 = env47570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env47569 == env47570) = true)

def env47571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,21793,351538,329761,8192,65,472175,288825,333858,223598,75103,272392,257,95530,90203,513]

theorem envBound47571 : H12AffineFastState.Bounded env47571 := by
  intro p hp
  have h : env47571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47570_47571 : H12AffineEnvironment.transform 6 8 env47570 = env47571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47570 == env47571) = true)

theorem identity47571 : scanCanonicalize (H12AffineFastState.compose env47571 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound47571 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env47572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,2341,1025,29788,4161,21793,87063,65796,8192,65,212298,24860,69895,223598,75103,8493,257,95530,90203,513]

theorem envBound47572 : H12AffineFastState.Bounded env47572 := by
  intro p hp
  have h : env47572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47571_47572 : H12AffineEnvironment.transform 17 2341 env47571 = env47572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env47571 == env47572) = true)

theorem identity47572 : scanCanonicalize (H12AffineFastState.compose env47572 (packedSelected [0,2,3,6,7,10,16,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound47572 : packedSelected [0,2,3,6,7,10,16,19,24] rootPS < 2^1333 := by decide +kernel

def env47573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,16401,2341,1025,29788,4161,21793,87063,65796,8192,65,97627,24860,69895,76159,75103,8493,257,95530,90203,513]

theorem envBound47573 : H12AffineFastState.Bounded env47573 := by
  intro p hp
  have h : env47573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47572_47573 : H12AffineEnvironment.transform 16 16401 env47572 = env47573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env47572 == env47573) = true)

theorem identity47573 : scanCanonicalize (H12AffineFastState.compose env47573 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47573 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env47574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,16401,2341,1025,21761,4161,21793,87063,65796,349,65,89094,16449,69895,67618,66562,112,257,87159,82182,513]

theorem envBound47574 : H12AffineFastState.Bounded env47574 := by
  intro p hp
  have h : env47574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47573_47574 : H12AffineEnvironment.transform 12 349 env47573 = env47574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47573 == env47574) = true)

theorem identity47574 : scanCanonicalize (H12AffineFastState.compose env47574 (packedSelected [2,3,4,5,6,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound47574 : packedSelected [2,3,4,5,6,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env47575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16401,2341,1025,21761,4161,21793,21824,83,349,65,23889,16449,4176,2421,1365,112,257,21792,16465,513]

theorem envBound47575 : H12AffineFastState.Bounded env47575 := by
  intro p hp
  have h : env47575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47574_47575 : H12AffineEnvironment.transform 15 343 env47574 = env47575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env47574 == env47575) = true)

theorem identity47575 : scanCanonicalize (H12AffineFastState.compose env47575 (packedSelected [0,1,5,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47575 : packedSelected [0,1,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47576 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21621,34,16401,2128,1025,21620,4161,21588,21557,83,40,65,23588,16449,4176,2048,1056,112,116,21589,16465,513]

theorem envBound47576 : H12AffineFastState.Bounded env47576 := by
  intro p hp
  have h : env47576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47575_47576 : H12AffineEnvironment.transform 7 117 env47575 = env47576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47575 == env47576) = true)

theorem identity47576 : scanCanonicalize (H12AffineFastState.compose env47576 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound47576 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47577 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,34,5221,2128,1025,0,4161,32,65,83,40,65,2128,5173,4176,2048,1056,112,116,33,5157,513]

theorem envBound47577 : H12AffineFastState.Bounded env47577 := by
  intro p hp
  have h : env47577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47576_47577 : H12AffineEnvironment.transform 13 5236 env47576 = env47577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env47576 == env47577) = true)

theorem identity47577 : scanCanonicalize (H12AffineFastState.compose env47577 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound47577 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47578 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,40,5236,1,34,5221,1076,1025,0,4161,32,65,83,40,65,1076,5173,4176,1124,1056,112,116,33,5157,513]

theorem envBound47578 : H12AffineFastState.Bounded env47578 := by
  intro p hp
  have h : env47578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47577_47578 : H12AffineEnvironment.transform 10 1124 env47577 = env47578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env47577 == env47578) = true)

theorem identity47578 : scanCanonicalize (H12AffineFastState.compose env47578 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound47578 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env47579 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,16,40,1124,1,34,1141,1076,1025,0,81,32,65,83,40,65,1076,1061,64,1124,1056,112,116,33,1077,513]

theorem envBound47579 : H12AffineFastState.Bounded env47579 := by
  intro p hp
  have h : env47579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47578_47579 : H12AffineEnvironment.transform 11 16 env47578 = env47579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47578 == env47579) = true)

def env47580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,21792,351538,329761,8193,65,472175,288825,333858,223599,75102,272392,257,95530,90203,513]

theorem envBound47580 : H12AffineFastState.Bounded env47580 := by
  intro p hp
  have h : env47580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47570_47580 : H12AffineEnvironment.transform 6 9 env47570 = env47580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47570 == env47580) = true)

theorem identity47580 : scanCanonicalize (H12AffineFastState.compose env47580 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound47580 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,4161,21792,351538,329761,8193,65,283764,288825,333858,2420,75102,272392,257,95530,90203,513]

theorem envBound47581 : H12AffineFastState.Bounded env47581 := by
  intro p hp
  have h : env47581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47580_47581 : H12AffineEnvironment.transform 16 90139 env47580 = env47581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env47580 == env47581) = true)

theorem identity47581 : scanCanonicalize (H12AffineFastState.compose env47581 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 3344) := by decide +kernel

theorem selectedBound47581 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env47582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,3344,1025,29789,4161,21792,86050,66865,8193,65,22884,25897,70962,2420,75102,9496,257,95530,90203,513]

theorem envBound47582 : H12AffineFastState.Bounded env47582 := by
  intro p hp
  have h : env47582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47581_47582 : H12AffineEnvironment.transform 17 3344 env47581 = env47582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3344 env47581 == env47582) = true)

theorem identity47582 : scanCanonicalize (H12AffineFastState.compose env47582 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound47582 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env47583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,65536,78911,3344,1025,8313,4161,260,66566,66865,8193,65,3392,12557,70962,2420,75102,9496,257,73998,78975,513]

theorem envBound47583 : H12AffineFastState.Bounded env47583 := by
  intro p hp
  have h : env47583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47582_47583 : H12AffineEnvironment.transform 13 5156 env47582 = env47583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env47582 == env47583) = true)

theorem identity47583 : scanCanonicalize (H12AffineFastState.compose env47583 (packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound47583 : packedSelected [1,3,4,9,12,14,15,20,24,28] rootPS < 2^1333 := by decide +kernel

def env47584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8312,34,13341,3344,1025,8313,4161,260,1060,1299,8193,65,3392,12557,5392,2420,9596,9496,257,8492,13405,513]

theorem envBound47584 : H12AffineFastState.Bounded env47584 := by
  intro p hp
  have h : env47584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47583_47584 : H12AffineEnvironment.transform 15 34 env47583 = env47584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env47583 == env47584) = true)

theorem identity47584 : scanCanonicalize (H12AffineFastState.compose env47584 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound47584 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env47585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5156,1344,34,4389,3344,1025,1345,4161,260,1060,1299,1337,65,3392,5173,5392,2420,68,32,257,1044,4453,513]

theorem envBound47585 : H12AffineFastState.Bounded env47585 := by
  intro p hp
  have h : env47585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47584_47585 : H12AffineEnvironment.transform 12 1336 env47584 = env47585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env47584 == env47585) = true)

theorem identity47585 : scanCanonicalize (H12AffineFastState.compose env47585 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47585 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47586 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,5156,1125,34,4096,3125,1025,1124,4161,33,1060,1078,1052,65,3173,5173,5173,2129,68,32,36,1044,4160,513]

theorem envBound47586 : H12AffineFastState.Bounded env47586 := by
  intro p hp
  have h : env47586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47585_47586 : H12AffineEnvironment.transform 7 37 env47585 = env47586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47585 == env47586) = true)

theorem identity47586 : scanCanonicalize (H12AffineFastState.compose env47586 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound47586 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env47587 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,1573,1053,513,1125,34,1573,3125,1025,1124,1636,33,1060,1078,1052,65,3173,528,528,2129,68,32,36,1044,1637,513]

theorem envBound47587 : H12AffineFastState.Bounded env47587 := by
  intro p hp
  have h : env47587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47586_47587 : H12AffineEnvironment.transform 11 1573 env47586 = env47587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env47586 == env47587) = true)

theorem identity47587 : scanCanonicalize (H12AffineFastState.compose env47587 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound47587 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47588 : List Nat := [2,4,8,16,32,64,9,37,512,1024,576,1573,1053,513,1125,34,1573,1653,1025,1124,1636,33,1060,1078,1052,65,1573,528,528,529,68,32,36,1044,1637,513]

theorem envBound47588 : H12AffineFastState.Bounded env47588 := by
  intro p hp
  have h : env47588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47587_47588 : H12AffineEnvironment.transform 10 576 env47587 = env47588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env47587 == env47588) = true)

theorem identity47588 : scanCanonicalize (H12AffineFastState.compose env47588 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound47588 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env47589 : List Nat := [2,4,8,16,32,64,9,37,512,36,576,513,57,513,65,34,513,593,37,64,576,33,0,18,56,65,513,528,528,529,68,32,36,48,577,513]

theorem envBound47589 : H12AffineFastState.Bounded env47589 := by
  intro p hp
  have h : env47589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47588_47589 : H12AffineEnvironment.transform 9 36 env47588 = env47589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env47588 == env47589) = true)

theorem identity47589 : scanCanonicalize (H12AffineFastState.compose env47589 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound47589 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47590 : List Nat := [2,4,8,16,32,64,9,37,80,36,16,81,57,81,65,34,81,1,37,64,16,33,0,18,56,65,81,64,64,65,68,32,36,48,17,81]

theorem envBound47590 : H12AffineFastState.Bounded env47590 := by
  intro p hp
  have h : env47590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47589_47590 : H12AffineEnvironment.transform 8 80 env47589 = env47590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env47589 == env47590) = true)

theorem identity47590 : scanCanonicalize (H12AffineFastState.compose env47590 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47590 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env47591 : List Nat := [2,4,8,16,32,1,9,37,17,36,16,16,57,16,0,34,16,1,37,1,16,33,0,18,56,0,16,1,1,0,5,32,36,48,17,16]

theorem envBound47591 : H12AffineFastState.Bounded env47591 := by
  intro p hp
  have h : env47591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47590_47591 : H12AffineEnvironment.transform 5 1 env47590 = env47591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47590 == env47591) = true)

theorem identity47591 : scanCanonicalize (H12AffineFastState.compose env47591 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47591 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47592 : List Nat := [2,4,8,0,32,1,9,37,1,36,0,0,41,0,0,34,0,1,37,1,0,33,0,2,40,0,0,1,1,0,5,32,36,32,1,0]

theorem envBound47592 : H12AffineFastState.Bounded env47592 := by
  intro p hp
  have h : env47592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47591_47592 : H12AffineEnvironment.transform 3 0 env47591 = env47592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47591 == env47592) = true)

def env47593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431073,8328,65,2609402,302317,333858,2329970,119043,2373704,257,2199999,2191387,63189]

theorem envBound47593 : H12AffineFastState.Bounded env47593 := by
  intro p hp
  have h : env47593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47541_47593 : H12AffineEnvironment.transform 23 2431073 env47541 = env47593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env47541 == env47593) = true)

def env47594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329761,8328,65,508090,302317,333858,236850,119043,272392,257,98815,90203,63189]

theorem envBound47594 : H12AffineFastState.Bounded env47594 := by
  intro p hp
  have h : env47594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47593_47594 : H12AffineEnvironment.transform 20 4160 env47593 = env47594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47593 == env47594) = true)

def env47595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,21928,95635,73857,8328,65,256026,46157,77954,236850,119043,168,257,98815,90203,63189]

theorem envBound47595 : H12AffineFastState.Bounded env47595 := by
  intro p hp
  have h : env47595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47594_47595 : H12AffineEnvironment.transform 17 10400 env47594 = env47595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47594 == env47595) = true)

theorem identity47595 : scanCanonicalize (H12AffineFastState.compose env47595 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound47595 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,10400,1025,32769,4160,21928,16,21762,8328,65,171417,46157,17665,190641,42112,168,257,62588,5592,63189]

theorem envBound47596 : H12AffineFastState.Bounded env47596 := by
  intro p hp
  have h : env47596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47595_47596 : H12AffineEnvironment.transform 15 30083 env47595 = env47596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env47595 == env47596) = true)

theorem identity47596 : scanCanonicalize (H12AffineFastState.compose env47596 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 16876) := by decide +kernel

theorem selectedBound47596 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env47597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,16876,10400,1025,32769,4160,21928,16,21762,8328,65,56437,46157,17665,43357,42112,168,257,62588,5592,63189]

theorem envBound47597 : H12AffineFastState.Bounded env47597 := by
  intro p hp
  have h : env47597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47596_47597 : H12AffineEnvironment.transform 16 16876 env47596 = env47597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16876 env47596 == env47597) = true)

theorem identity47597 : scanCanonicalize (H12AffineFastState.compose env47597 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound47597 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env47598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,5220,10400,1025,32769,4160,32,16,138,8328,65,35325,46157,4233,43357,42112,168,257,41460,5592,41821]

theorem envBound47598 : H12AffineFastState.Bounded env47598 := by
  intro p hp
  have h : env47598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47597_47598 : H12AffineEnvironment.transform 13 5512 env47597 = env47598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47597 == env47598) = true)

theorem identity47598 : scanCanonicalize (H12AffineFastState.compose env47598 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47598 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,32768,263,5220,2476,1025,32769,4160,32,16,138,388,65,35325,38209,4233,34897,34188,168,257,33016,5592,33361]

theorem envBound47599 : H12AffineFastState.Bounded env47599 := by
  intro p hp
  have h : env47599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47598_47599 : H12AffineEnvironment.transform 12 268 env47598 = env47599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47598 == env47599) = true)

theorem identity47599 : scanCanonicalize (H12AffineFastState.compose env47599 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47599 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env47600 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5373,32768,114,5220,2265,1025,32769,4160,32,16,138,241,65,34952,37940,4233,34897,34041,168,116,33016,5293,33361]

theorem envBound47600 : H12AffineFastState.Bounded env47600 := by
  intro p hp
  have h : env47600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47599_47600 : H12AffineEnvironment.transform 7 117 env47599 = env47600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47599 == env47600) = true)

theorem identity47600 : scanCanonicalize (H12AffineFastState.compose env47600 (packedSelected [1,2,4,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound47600 : packedSelected [1,2,4,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env47601 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5373,1125,114,5220,2265,1025,1124,4160,32,16,138,241,65,3309,4177,4233,3124,156,168,116,1181,5293,1588]

theorem envBound47601 : H12AffineFastState.Bounded env47601 := by
  intro p hp
  have h : env47601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47600_47601 : H12AffineEnvironment.transform 14 1125 env47600 = env47601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env47600 == env47601) = true)

theorem identity47601 : scanCanonicalize (H12AffineFastState.compose env47601 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47601 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env47602 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,1125,114,5220,2128,1025,1124,4160,32,16,3,120,65,3172,4177,4096,3124,21,33,116,1044,5156,1588]

theorem envBound47602 : H12AffineFastState.Bounded env47602 := by
  intro p hp
  have h : env47602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47601_47602 : H12AffineEnvironment.transform 6 9 env47601 = env47602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47601 == env47602) = true)

theorem identity47602 : scanCanonicalize (H12AffineFastState.compose env47602 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47602 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env47603 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,121,4112,1,114,4096,2128,101,0,4160,32,16,3,120,65,2048,4177,4096,2128,21,33,116,112,4160,592]

theorem envBound47603 : H12AffineFastState.Bounded env47603 := by
  intro p hp
  have h : env47603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47602_47603 : H12AffineEnvironment.transform 9 100 env47602 = env47603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47602 == env47603) = true)

theorem identity47603 : scanCanonicalize (H12AffineFastState.compose env47603 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47603 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47604 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4112,1,35,4096,2049,52,0,4113,32,16,3,41,16,2048,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound47604 : H12AffineFastState.Bounded env47604 := by
  intro p hp
  have h : env47604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47603_47604 : H12AffineEnvironment.transform 5 17 env47603 = env47604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47603 == env47604) = true)

theorem identity47604 : scanCanonicalize (H12AffineFastState.compose env47604 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound47604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47605 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,0,40,16,1,35,0,2049,52,0,17,32,16,3,41,16,2048,0,0,2049,21,33,37,33,17,513]

theorem envBound47605 : H12AffineFastState.Bounded env47605 := by
  intro p hp
  have h : env47605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47604_47605 : H12AffineEnvironment.transform 11 0 env47604 = env47605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47604 == env47605) = true)

theorem identity47605 : scanCanonicalize (H12AffineFastState.compose env47605 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound47605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47606 : List Nat := [2,4,8,16,32,17,9,36,512,53,538,0,40,16,1,35,0,539,52,0,17,32,16,3,41,16,538,0,0,539,21,33,37,33,17,513]

theorem envBound47606 : H12AffineFastState.Bounded env47606 := by
  intro p hp
  have h : env47606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47605_47606 : H12AffineEnvironment.transform 10 538 env47605 = env47606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env47605 == env47606) = true)

theorem identity47606 : scanCanonicalize (H12AffineFastState.compose env47606 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47606 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47607 : List Nat := [2,4,8,16,32,17,9,36,1,53,27,0,40,16,1,35,0,26,52,0,17,32,16,3,41,16,27,0,0,26,21,33,37,33,17,0]

theorem envBound47607 : H12AffineFastState.Bounded env47607 := by
  intro p hp
  have h : env47607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47606_47607 : H12AffineEnvironment.transform 8 1 env47606 = env47607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47606 == env47607) = true)

theorem identity47607 : scanCanonicalize (H12AffineFastState.compose env47607 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47607 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47608 : List Nat := [2,4,8,0,32,1,9,36,1,37,11,0,40,0,1,35,0,10,36,0,1,32,0,3,41,0,11,0,0,10,5,33,37,33,1,0]

theorem envBound47608 : H12AffineFastState.Bounded env47608 := by
  intro p hp
  have h : env47608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47607_47608 : H12AffineEnvironment.transform 3 0 env47607 = env47608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47607 == env47608) = true)

theorem identity47608 : scanCanonicalize (H12AffineFastState.compose env47608 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47608 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47609 : List Nat := [2,4,2,0,32,1,3,36,1,37,1,0,34,0,1,35,0,0,36,0,1,32,0,3,35,0,1,0,0,0,5,33,37,33,1,0]

theorem envBound47609 : H12AffineFastState.Bounded env47609 := by
  intro p hp
  have h : env47609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47608_47609 : H12AffineEnvironment.transform 2 2 env47608 = env47609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47608 == env47609) = true)

def env47610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,21928,95634,73856,8328,65,256027,46156,77955,236850,119043,169,257,98815,90203,63189]

theorem envBound47610 : H12AffineFastState.Bounded env47610 := by
  intro p hp
  have h : env47610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47594_47610 : H12AffineEnvironment.transform 17 10401 env47594 = env47610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47594 == env47610) = true)

theorem identity47610 : scanCanonicalize (H12AffineFastState.compose env47610 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47610 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env47611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1025,29909,4160,21928,95634,73856,8328,65,203983,16536,77955,223718,75223,169,257,95531,90203,513]

theorem envBound47611 : H12AffineFastState.Bounded env47611 := by
  intro p hp
  have h : env47611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47610_47611 : H12AffineEnvironment.transform 14 29908 env47610 = env47611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47610 == env47611) = true)

def env47612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1025,8661,4160,168,73874,73856,8328,65,203983,5528,77955,212198,75223,169,257,73771,79195,513]

theorem envBound47612 : H12AffineFastState.Bounded env47612 := by
  intro p hp
  have h : env47612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47611_47612 : H12AffineEnvironment.transform 13 5376 env47611 = env47612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47611 == env47612) = true)

theorem identity47612 : scanCanonicalize (H12AffineFastState.compose env47612 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound47612 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79131,10401,1025,8661,4160,168,73874,73856,8328,65,10708,5528,77955,2557,75223,169,257,73771,79195,513]

theorem envBound47613 : H12AffineFastState.Bounded env47613 := by
  intro p hp
  have h : env47613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47612_47613 : H12AffineEnvironment.transform 16 79131 env47612 = env47613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env47612 == env47613) = true)

theorem identity47613 : scanCanonicalize (H12AffineFastState.compose env47613 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound47613 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env47614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,343,13388,10401,1025,8661,4160,168,8645,8663,8328,65,10708,5528,12756,2557,9344,169,257,8572,13324,513]

theorem envBound47614 : H12AffineFastState.Bounded env47614 := by
  intro p hp
  have h : env47614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47613_47614 : H12AffineEnvironment.transform 15 343 env47613 = env47614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env47613 == env47614) = true)

theorem identity47614 : scanCanonicalize (H12AffineFastState.compose env47614 (packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47614 : packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env47615 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,263,13340,10401,1025,8581,4112,168,8597,8583,8328,17,10628,5528,12676,2477,9344,169,257,8492,13324,513]

theorem envBound47615 : H12AffineFastState.Bounded env47615 := by
  intro p hp
  have h : env47615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47614_47615 : H12AffineEnvironment.transform 5 16 env47614 = env47615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47614 == env47615) = true)

def env47616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1025,8660,4160,169,73875,73856,8328,65,203983,5529,77955,212199,75223,169,257,73770,79194,513]

theorem envBound47616 : H12AffineFastState.Bounded env47616 := by
  intro p hp
  have h : env47616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47611_47616 : H12AffineEnvironment.transform 13 5377 env47611 = env47616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47611 == env47616) = true)

theorem identity47616 : scanCanonicalize (H12AffineFastState.compose env47616 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47616 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1025,8540,4160,33,73755,73736,8192,65,203847,5393,77835,212079,75103,33,257,73770,79194,513]

theorem envBound47617 : H12AffineFastState.Bounded env47617 := by
  intro p hp
  have h : env47617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47616_47617 : H12AffineEnvironment.transform 6 8 env47616 = env47617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47616 == env47617) = true)

theorem identity47617 : scanCanonicalize (H12AffineFastState.compose env47617 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47617 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env47618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10281,1025,8540,4160,33,16,3,8192,65,146508,5393,4096,138340,1364,33,257,33,5457,513]

theorem envBound47618 : H12AffineFastState.Bounded env47618 := by
  intro p hp
  have h : env47618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47617_47618 : H12AffineEnvironment.transform 15 8203 env47617 = env47618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47617 == env47618) = true)

theorem identity47618 : scanCanonicalize (H12AffineFastState.compose env47618 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound47618 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13388,10281,1025,8540,4160,33,16,3,8192,65,2048,5393,4096,10280,1364,33,257,33,5457,513]

theorem envBound47619 : H12AffineFastState.Bounded env47619 := by
  intro p hp
  have h : env47619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47618_47619 : H12AffineEnvironment.transform 16 13388 env47618 = env47619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env47618 == env47619) = true)

theorem identity47619 : scanCanonicalize (H12AffineFastState.compose env47619 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47619 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47620 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5157,8313,8203,13388,10281,1025,8312,4160,33,16,3,8192,65,2048,5173,4096,10280,1136,33,37,33,5237,513]

theorem envBound47620 : H12AffineFastState.Bounded env47620 := by
  intro p hp
  have h : env47620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1