import H12CloudChart1Data018

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity4689 : scanCanonicalize (H12AffineFastState.compose env4689 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound4689 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4690 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8323,4264,2184,1025,13884,4097,5821,185,5654,8329,184,7733,4097,4264,2081,1192,1,5,0,4265,512]

theorem envBound4690 : H12AffineFastState.Bounded env4690 := by
  intro p hp
  have h : env4690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4689_4690 : H12AffineEnvironment.transform 17 2184 env4689 = env4690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env4689 == env4690) = true)

theorem identity4690 : scanCanonicalize (H12AffineFastState.compose env4690 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4690 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4691 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,8192,1692,8353,8323,1589,2184,1025,8353,1692,32,185,139,8329,184,2216,1692,1589,2081,1192,1,5,0,1588,512]

theorem envBound4691 : H12AffineFastState.Bounded env4691 := by
  intro p hp
  have h : env4691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4690_4691 : H12AffineEnvironment.transform 11 1693 env4690 = env4691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4690 == env4691) = true)

theorem identity4691 : scanCanonicalize (H12AffineFastState.compose env4691 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound4691 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4692 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1693,18,1692,179,145,1589,2184,1025,179,1692,32,185,139,155,184,2216,1692,1589,2081,1192,1,5,0,1588,512]

theorem envBound4692 : H12AffineFastState.Bounded env4692 := by
  intro p hp
  have h : env4692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4691_4692 : H12AffineEnvironment.transform 12 18 env4691 = env4692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env4691 == env4692) = true)

theorem identity4692 : scanCanonicalize (H12AffineFastState.compose env4692 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 690) := by decide +kernel

theorem selectedBound4692 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4693 : List Nat := [2,4,8,16,32,16,128,4,512,1024,690,1693,18,1692,179,145,1589,570,1025,179,1692,32,185,139,155,184,538,1692,1589,659,1192,1,5,0,1588,512]

theorem envBound4693 : H12AffineFastState.Bounded env4693 := by
  intro p hp
  have h : env4693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4692_4693 : H12AffineEnvironment.transform 10 690 env4692 = env4693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 690 env4692 == env4693) = true)

theorem identity4693 : scanCanonicalize (H12AffineFastState.compose env4693 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4693 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4694 : List Nat := [2,4,8,16,32,16,18,4,512,1024,544,1551,18,1550,33,3,1589,570,1025,33,1550,32,43,25,9,42,538,1550,1589,513,1082,1,5,0,1588,512]

theorem envBound4694 : H12AffineFastState.Bounded env4694 := by
  intro p hp
  have h : env4694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4693_4694 : H12AffineEnvironment.transform 6 18 env4693 = env4694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4693 == env4694) = true)

theorem identity4694 : scanCanonicalize (H12AffineFastState.compose env4694 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4694 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env4695 : List Nat := [2,4,8,10,32,10,8,4,512,1024,544,1551,8,1550,33,3,1583,544,1025,33,1550,32,43,3,9,42,512,1550,1583,513,1056,1,5,0,1582,512]

theorem envBound4695 : H12AffineFastState.Bounded env4695 := by
  intro p hp
  have h : env4695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4694_4695 : H12AffineEnvironment.transform 3 10 env4694 = env4695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4694 == env4695) = true)

theorem identity4695 : scanCanonicalize (H12AffineFastState.compose env4695 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4695 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4696 : List Nat := [2,4,8,10,32,10,8,4,32,1024,0,1071,8,1070,33,3,1039,0,1025,33,1070,32,43,3,9,42,32,1070,1039,33,1056,1,5,0,1038,32]

theorem envBound4696 : H12AffineFastState.Bounded env4696 := by
  intro p hp
  have h : env4696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4695_4696 : H12AffineEnvironment.transform 8 32 env4695 = env4696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4695 == env4696) = true)

theorem identity4696 : scanCanonicalize (H12AffineFastState.compose env4696 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4696 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env4697 : List Nat := [2,4,8,10,0,10,8,4,0,1024,0,1039,8,1038,1,3,1039,0,1025,1,1038,0,11,3,9,10,0,1038,1039,1,1024,1,5,0,1038,0]

theorem envBound4697 : H12AffineFastState.Bounded env4697 := by
  intro p hp
  have h : env4697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4696_4697 : H12AffineEnvironment.transform 4 0 env4696 = env4697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4696 == env4697) = true)

theorem identity4697 : scanCanonicalize (H12AffineFastState.compose env4697 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4697 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4698 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1028,3,1029,1,3,1028,0,1025,1,1029,0,0,3,2,1,0,1029,1028,1,1024,1,5,0,1029,0]

theorem envBound4698 : H12AffineFastState.Bounded env4698 := by
  intro p hp
  have h : env4698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4697_4698 : H12AffineEnvironment.transform 2 3 env4697 = env4698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4697 == env4698) = true)

def leafEnv4698 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1028,3,1029,1,3,1028,0,1025,1,1029,0,0,3,1025,2,1,1,0,1029,1028,1,1024,1,5,0,5,3,1029,0,1,1028,0]

def active4698 : List Nat := [0,1,9]

def tree4698 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4698 : H12WitnessSearch.Good tree4698 := H12GlobalWitnessIndex.good

theorem leafIdentity4698 : H12AffineFastState.composeSystem env4698 rootObs = leafEnv4698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4698 rootObs == leafEnv4698) = true)

theorem terminalChecked4698 : H12PackedTerminal.terminalCheckFast leafEnv4698 active4698 tree4698 = true := by decide +kernel

def env4699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,73786,41002,8329,73786,323713,16384,16812,22561,74795,4313350,257,20480,16812,74630]

theorem envBound4699 : H12AffineFastState.Bounded env4699 := by
  intro p hp
  have h : env4699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4683_4699 : H12AffineEnvironment.transform 5 17 env4683 = env4699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4683 == env4699) = true)

def env4700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,41088,73786,41002,8329,73786,323713,16384,16812,22561,74795,94598,257,20480,16812,74630]

theorem envBound4700 : H12AffineFastState.Bounded env4700 := by
  intro p hp
  have h : env4700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4699_4700 : H12AffineEnvironment.transform 21 41088 env4699 = env4700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4699 == env4700) = true)

theorem identity4700 : scanCanonicalize (H12AffineFastState.compose env4700 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4700 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4701 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1025,32768,4097,41088,73786,41002,8329,73786,323713,16384,16553,22561,74795,94339,4,20480,16553,74371]

theorem envBound4701 : H12AffineFastState.Bounded env4701 := by
  intro p hp
  have h : env4701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4700_4701 : H12AffineEnvironment.transform 7 5 env4700 = env4701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4700 == env4701) = true)

theorem identity4701 : scanCanonicalize (H12AffineFastState.compose env4701 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 75938) := by decide +kernel

theorem selectedBound4701 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4702 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4264,75938,1025,32768,4097,41088,73786,41002,8329,73786,120867,16384,16553,22561,74795,94339,4,20480,16553,74371]

theorem envBound4702 : H12AffineFastState.Bounded env4702 := by
  intro p hp
  have h : env4702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4701_4702 : H12AffineEnvironment.transform 17 75938 env4701 = env4702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75938 env4701 == env4702) = true)

theorem identity4702 : scanCanonicalize (H12AffineFastState.compose env4702 (packedSelected [3,4,5,8,9,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 53387) := by decide +kernel

theorem selectedBound4702 : packedSelected [3,4,5,8,9,20,28] rootPS < 2^1333 := by decide +kernel

def env4703 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,53387,4264,63529,1025,32768,4097,41088,61617,41002,8329,61617,2216,16384,16553,22561,62624,40968,4,20480,16553,61960]

theorem envBound4703 : H12AffineFastState.Bounded env4703 := by
  intro p hp
  have h : env4703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4702_4703 : H12AffineEnvironment.transform 15 53387 env4702 = env4703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53387 env4702 == env4703) = true)

theorem identity4703 : scanCanonicalize (H12AffineFastState.compose env4703 (packedSelected [1,4,8,9,10,12,13,18,21] rootPS)) = affineNative (2^(13+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4703 : packedSelected [1,4,8,9,10,12,13,18,21] rootPS < 2^1333 := by decide +kernel

def env4704 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,1589,32768,38590,4264,48668,1025,32768,4097,41088,46724,41002,8329,46724,2216,1589,1692,7700,45717,40968,4,5685,1692,46141]

theorem envBound4704 : H12AffineFastState.Bounded env4704 := by
  intro p hp
  have h : env4704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4703_4704 : H12AffineEnvironment.transform 13 1589 env4703 = env4704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1589 env4703 == env4704) = true)

theorem identity4704 : scanCanonicalize (H12AffineFastState.compose env4704 (packedSelected [0,5,7,10,12,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4704 : packedSelected [0,5,7,10,12,18,24] rootPS < 2^1333 := by decide +kernel

def env4705 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,1589,13885,8323,4264,2081,1025,13885,4097,5821,185,5655,8329,185,2216,1589,1692,7700,1192,5685,4,5685,1692,512]

theorem envBound4705 : H12AffineFastState.Bounded env4705 := by
  intro p hp
  have h : env4705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4704_4705 : H12AffineEnvironment.transform 14 13885 env4704 = env4705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4704 == env4705) = true)

theorem identity4705 : scanCanonicalize (H12AffineFastState.compose env4705 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4705 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4706 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1589,8192,1589,8200,8323,1693,2081,1025,8200,1588,136,185,34,8329,185,2216,1589,1692,2081,1192,0,4,0,1692,512]

theorem envBound4706 : H12AffineFastState.Bounded env4706 := by
  intro p hp
  have h : env4706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4705_4706 : H12AffineEnvironment.transform 11 1589 env4705 = env4706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4705 == env4706) = true)

def env4707 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,41089,73786,41002,8329,73786,323713,16384,16812,22561,74795,94599,257,20480,16812,74630]

theorem envBound4707 : H12AffineFastState.Bounded env4707 := by
  intro p hp
  have h : env4707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4699_4707 : H12AffineEnvironment.transform 21 41089 env4699 = env4707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4699 == env4707) = true)

theorem identity4707 : scanCanonicalize (H12AffineFastState.compose env4707 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound4707 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4708 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,4525,262144,1025,32768,4097,41089,184,41002,8329,184,323713,16384,16812,22561,1193,20741,257,20480,16812,772]

theorem envBound4708 : H12AffineFastState.Bounded env4708 := by
  intro p hp
  have h : env4708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4707_4708 : H12AffineEnvironment.transform 15 8322 env4707 = env4708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env4707 == env4708) = true)

theorem identity4708 : scanCanonicalize (H12AffineFastState.compose env4708 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound4708 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4709 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,4525,7869,1025,32768,4097,41089,184,41002,8329,184,60988,16384,16812,22561,1193,20741,257,20480,16812,772]

theorem envBound4709 : H12AffineFastState.Bounded env4709 := by
  intro p hp
  have h : env4709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4708_4709 : H12AffineEnvironment.transform 17 7869 env4708 = env4709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env4708 == env4709) = true)

theorem identity4709 : scanCanonicalize (H12AffineFastState.compose env4709 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4709 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4710 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1589,32768,8322,4525,7869,1025,32768,4097,41089,184,41002,8329,184,43017,1589,1945,7700,1193,5936,257,5685,1945,772]

theorem envBound4710 : H12AffineFastState.Bounded env4710 := by
  intro p hp
  have h : env4710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4709_4710 : H12AffineEnvironment.transform 13 1589 env4709 = env4710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1589 env4709 == env4710) = true)

theorem identity4710 : scanCanonicalize (H12AffineFastState.compose env4710 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4710 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4711 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1692,8192,1589,32768,8322,1841,2081,1025,32768,1693,41089,184,41002,8329,184,43017,1589,1945,2184,1193,428,257,169,1945,772]

theorem envBound4711 : H12AffineFastState.Bounded env4711 := by
  intro p hp
  have h : env4711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4710_4711 : H12AffineEnvironment.transform 11 1692 env4710 = env4711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4710 == env4711) = true)

theorem identity4711 : scanCanonicalize (H12AffineFastState.compose env4711 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound4711 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4712 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1692,8192,1589,8216,8322,1841,2081,1025,8216,1693,153,184,50,8329,184,2065,1589,1945,2184,1193,428,257,169,1945,772]

theorem envBound4712 : H12AffineFastState.Bounded env4712 := by
  intro p hp
  have h : env4712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4711_4712 : H12AffineEnvironment.transform 14 8216 env4711 = env4712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env4711 == env4712) = true)

theorem identity4712 : scanCanonicalize (H12AffineFastState.compose env4712 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4712 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4713 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,8192,1573,8200,8322,1825,2081,1025,8200,1677,137,168,34,8329,168,2049,1573,1929,2184,1193,428,257,169,1929,772]

theorem envBound4713 : H12AffineFastState.Bounded env4713 := by
  intro p hp
  have h : env4713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4712_4713 : H12AffineEnvironment.transform 3 0 env4712 = env4713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4712 == env4713) = true)

theorem identity4713 : scanCanonicalize (H12AffineFastState.compose env4713 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound4713 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4714 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,2949,1573,2957,2823,1825,2081,1025,2957,1677,137,168,34,2828,168,2049,1573,1929,2184,1193,428,257,169,1929,772]

theorem envBound4714 : H12AffineFastState.Bounded env4714 := by
  intro p hp
  have h : env4714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4713_4714 : H12AffineEnvironment.transform 12 2949 env4713 = env4714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env4713 == env4714) = true)

theorem identity4714 : scanCanonicalize (H12AffineFastState.compose env4714 (packedSelected [0,4,6,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4714 : packedSelected [0,4,6,11,15] rootPS < 2^1333 := by decide +kernel

def env4715 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1676,2600,1573,2592,2730,1676,2081,1025,2592,1677,137,168,34,2721,168,2049,1573,1572,2184,1193,1,172,169,1572,681]

theorem envBound4715 : H12AffineFastState.Bounded env4715 := by
  intro p hp
  have h : env4715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4714_4715 : H12AffineEnvironment.transform 7 173 env4714 = env4715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4714 == env4715) = true)

theorem identity4715 : scanCanonicalize (H12AffineFastState.compose env4715 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4715 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4716 : List Nat := [2,4,3,0,32,1,128,166,512,1024,2048,1671,2595,1573,2592,2721,1671,2081,1025,2592,1670,130,163,34,2721,163,2049,1573,1572,2179,1186,1,167,162,1572,674]

theorem envBound4716 : H12AffineFastState.Bounded env4716 := by
  intro p hp
  have h : env4716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4715_4716 : H12AffineEnvironment.transform 2 3 env4715 = env4716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4715 == env4716) = true)

def env4717 : List Nat := [2,4,3,0,32,1,128,166,512,1024,1540,1671,1063,1573,1060,1189,1671,1573,1025,1060,1670,130,163,34,1189,163,1541,1573,1572,1671,1186,1,167,162,1572,674]

theorem envBound4717 : H12AffineFastState.Bounded env4717 := by
  intro p hp
  have h : env4717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4716_4717 : H12AffineEnvironment.transform 10 1540 env4716 = env4717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env4716 == env4717) = true)

def env4718 : List Nat := [2,4,3,0,32,1,128,166,0,1024,1028,1159,1063,1061,1060,1189,1159,1061,1025,1060,1158,130,163,34,1189,163,1029,1061,1060,1159,1186,1,167,162,1060,162]

theorem envBound4718 : H12AffineFastState.Bounded env4718 := by
  intro p hp
  have h : env4718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4717_4718 : H12AffineEnvironment.transform 8 0 env4717 = env4718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4717 == env4718) = true)

theorem identity4718 : scanCanonicalize (H12AffineFastState.compose env4718 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound4718 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4719 : List Nat := [2,4,3,0,32,1,128,166,0,135,131,0,160,162,163,34,0,162,134,163,1,130,163,34,34,163,130,162,163,0,37,1,167,162,163,162]

theorem envBound4719 : H12AffineFastState.Bounded env4719 := by
  intro p hp
  have h : env4719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4718_4719 : H12AffineEnvironment.transform 9 135 env4718 = env4719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env4718 == env4719) = true)

def env4720 : List Nat := [2,4,3,0,4,1,128,130,0,135,131,0,132,134,135,6,0,134,134,135,1,130,135,6,6,135,130,134,135,0,1,1,131,134,135,134]

theorem envBound4720 : H12AffineFastState.Bounded env4720 := by
  intro p hp
  have h : env4720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4719_4720 : H12AffineEnvironment.transform 4 4 env4719 = env4720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env4719 == env4720) = true)

theorem identity4720 : scanCanonicalize (H12AffineFastState.compose env4720 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4720 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4721 : List Nat := [2,0,3,0,0,1,128,130,0,131,131,0,128,130,131,2,0,130,130,131,1,130,131,2,2,131,130,130,131,0,1,1,131,130,131,130]

theorem envBound4721 : H12AffineFastState.Bounded env4721 := by
  intro p hp
  have h : env4721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4720_4721 : H12AffineEnvironment.transform 1 0 env4720 = env4721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4720 == env4721) = true)

def leafEnv4721 : List Nat := [2,0,3,0,0,1,128,130,0,131,131,0,128,130,131,2,0,130,130,131,1,130,131,2,0,2,1,131,130,130,131,0,1,1,131,130,1,3,131,130,1,131,0]

def active4721 : List Nat := [0,6]

def tree4721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4721 : H12WitnessSearch.Good tree4721 := H12GlobalWitnessIndex.good

theorem leafIdentity4721 : H12AffineFastState.composeSystem env4721 rootObs = leafEnv4721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4721 rootObs == leafEnv4721) = true)

theorem terminalChecked4721 : H12PackedTerminal.terminalCheckFast leafEnv4721 active4721 tree4721 = true := by decide +kernel

def env4722 : List Nat := [2,4,3,0,5,1,128,131,0,135,131,0,133,135,134,7,0,135,134,134,1,130,134,7,7,134,130,135,134,0,0,1,130,135,134,135]

theorem envBound4722 : H12AffineFastState.Bounded env4722 := by
  intro p hp
  have h : env4722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4719_4722 : H12AffineEnvironment.transform 4 5 env4719 = env4722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env4719 == env4722) = true)

theorem identity4722 : scanCanonicalize (H12AffineFastState.compose env4722 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound4722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4723 : List Nat := [2,4,3,0,5,1,2,1,0,5,1,0,7,5,4,7,0,5,4,4,1,0,4,7,7,4,0,5,4,0,0,1,0,5,4,5]

theorem envBound4723 : H12AffineFastState.Bounded env4723 := by
  intro p hp
  have h : env4723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4722_4723 : H12AffineEnvironment.transform 6 2 env4722 = env4723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env4722 == env4723) = true)

def leafEnv4723 : List Nat := [2,4,3,0,5,1,2,1,0,5,1,0,7,5,4,7,0,5,4,4,1,0,4,7,1,7,1,4,0,5,4,0,0,1,0,5,5,3,4,5,1,4,0]

def active4723 : List Nat := [0,1]

def tree4723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4723 : H12WitnessSearch.Good tree4723 := H12GlobalWitnessIndex.good

theorem leafIdentity4723 : H12AffineFastState.composeSystem env4723 rootObs = leafEnv4723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4723 rootObs == leafEnv4723) = true)

theorem terminalChecked4723 : H12PackedTerminal.terminalCheckFast leafEnv4723 active4723 tree4723 = true := by decide +kernel

def env4724 : List Nat := [2,4,3,0,32,1,128,166,1,1024,1029,1158,1063,1060,1060,1189,1158,1060,1025,1060,1159,130,163,34,1189,163,1028,1060,1061,1158,1186,1,167,162,1061,163]

theorem envBound4724 : H12AffineFastState.Bounded env4724 := by
  intro p hp
  have h : env4724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4717_4724 : H12AffineEnvironment.transform 8 1 env4717 = env4724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4717 == env4724) = true)

theorem identity4724 : scanCanonicalize (H12AffineFastState.compose env4724 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4724 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4725 : List Nat := [2,4,3,0,32,1,128,166,1,4,1,130,35,32,32,161,130,32,5,32,131,130,163,34,161,163,0,32,33,130,166,1,167,162,33,163]

theorem envBound4725 : H12AffineFastState.Bounded env4725 := by
  intro p hp
  have h : env4725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4724_4725 : H12AffineEnvironment.transform 9 4 env4724 = env4725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4724 == env4725) = true)

theorem identity4725 : scanCanonicalize (H12AffineFastState.compose env4725 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4725 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env4726 : List Nat := [2,4,3,0,32,1,35,5,1,4,1,33,35,32,32,2,33,32,5,32,32,33,0,34,2,0,0,32,33,33,5,1,4,1,33,0]

theorem envBound4726 : H12AffineFastState.Bounded env4726 := by
  intro p hp
  have h : env4726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4725_4726 : H12AffineEnvironment.transform 6 35 env4725 = env4726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4725 == env4726) = true)

theorem identity4726 : scanCanonicalize (H12AffineFastState.compose env4726 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4726 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4727 : List Nat := [2,0,3,0,32,1,35,1,1,0,1,33,35,32,32,2,33,32,1,32,32,33,0,34,2,0,0,32,33,33,1,1,0,1,33,0]

theorem envBound4727 : H12AffineFastState.Bounded env4727 := by
  intro p hp
  have h : env4727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4726_4727 : H12AffineEnvironment.transform 1 0 env4726 = env4727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4726 == env4727) = true)

def env4728 : List Nat := [2,4,3,0,32,1,128,166,512,1024,1541,1671,1062,1573,1061,1188,1671,1572,1025,1061,1670,130,163,34,1188,163,1540,1573,1572,1670,1186,1,167,162,1572,674]

theorem envBound4728 : H12AffineFastState.Bounded env4728 := by
  intro p hp
  have h : env4728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4716_4728 : H12AffineEnvironment.transform 10 1541 env4716 = env4728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env4716 == env4728) = true)

theorem identity4728 : scanCanonicalize (H12AffineFastState.compose env4728 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound4728 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4729 : List Nat := [2,4,3,0,32,1,34,4,512,1024,1541,1573,1062,1573,1061,1030,1573,1572,1025,1061,1572,32,1,34,1030,1,1540,1573,1572,1572,1024,1,5,0,1572,512]

theorem envBound4729 : H12AffineFastState.Bounded env4729 := by
  intro p hp
  have h : env4729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4728_4729 : H12AffineEnvironment.transform 6 34 env4728 = env4729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env4728 == env4729) = true)

theorem identity4729 : scanCanonicalize (H12AffineFastState.compose env4729 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4729 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4730 : List Nat := [2,4,3,0,0,1,2,4,512,1024,1541,1541,1030,1541,1029,1030,1541,1540,1025,1029,1540,0,1,2,1030,1,1540,1541,1540,1540,1024,1,5,0,1540,512]

theorem envBound4730 : H12AffineFastState.Bounded env4730 := by
  intro p hp
  have h : env4730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4729_4730 : H12AffineEnvironment.transform 4 0 env4729 = env4730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4729 == env4730) = true)

theorem identity4730 : scanCanonicalize (H12AffineFastState.compose env4730 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4731 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1029,1029,1030,1029,1029,1030,1029,1028,1025,1029,1028,0,1,2,1030,1,1028,1029,1028,1028,1024,1,5,0,1028,0]

theorem envBound4731 : H12AffineFastState.Bounded env4731 := by
  intro p hp
  have h : env4731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4730_4731 : H12AffineEnvironment.transform 8 0 env4730 = env4731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4730 == env4731) = true)

theorem identity4731 : scanCanonicalize (H12AffineFastState.compose env4731 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4731 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4732 : List Nat := [2,4,3,0,0,1,2,4,0,4,1,1,2,1,1,2,1,0,5,1,0,0,1,2,2,1,0,1,0,0,4,1,5,0,0,0]

theorem envBound4732 : H12AffineFastState.Bounded env4732 := by
  intro p hp
  have h : env4732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4731_4732 : H12AffineEnvironment.transform 9 4 env4731 = env4732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4731 == env4732) = true)

def leafEnv4732 : List Nat := [2,4,3,0,0,1,2,4,0,4,1,1,2,1,1,2,1,0,5,1,0,0,1,2,5,2,1,1,0,1,0,0,4,1,5,0,5,3,0,0,1,0,0]

def active4732 : List Nat := [0,1]

def tree4732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4732 : H12WitnessSearch.Good tree4732 := H12GlobalWitnessIndex.good

theorem leafIdentity4732 : H12AffineFastState.composeSystem env4732 rootObs = leafEnv4732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4732 rootObs == leafEnv4732) = true)

theorem terminalChecked4732 : H12PackedTerminal.terminalCheckFast leafEnv4732 active4732 tree4732 = true := by decide +kernel

def env4733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849105,16385,16892,547953,598058,12644668,525568,545872,8479126,8914924]

theorem envBound4733 : H12AffineFastState.Bounded env4733 := by
  intro p hp
  have h : env4733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4606_4733 : H12AffineEnvironment.transform 27 16385 env4606 = env4733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4606 == env4733) = true)

def env4734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,12644668,256,20560,8479126,8389612]

theorem envBound4734 : H12AffineFastState.Bounded env4734 := by
  intro p hp
  have h : env4734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4733_4734 : H12AffineEnvironment.transform 18 1024 env4733 = env4734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4733 == env4734) = true)

theorem identity4734 : scanCanonicalize (H12AffineFastState.compose env4734 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310443) := by decide +kernel

theorem selectedBound4734 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,4310443,41002,8329,4310523,323793,16385,16892,22641,74794,78999,256,20560,4236349,4310599]

theorem envBound4735 : H12AffineFastState.Bounded env4735 := by
  intro p hp
  have h : env4735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4734_4735 : H12AffineEnvironment.transform 22 4310443 env4734 = env4735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310443 env4734 == env4735) = true)

def env4736 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4310443,41002,8329,4310443,323713,16385,16812,22561,74794,78999,256,20480,4236349,4310551]

theorem envBound4736 : H12AffineFastState.Bounded env4736 := by
  intro p hp
  have h : env4736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4735_4736 : H12AffineEnvironment.transform 5 16 env4735 = env4736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4735 == env4736) = true)

theorem identity4736 : scanCanonicalize (H12AffineFastState.compose env4736 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115735) := by decide +kernel

theorem selectedBound4736 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4737 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115735,444,41002,8329,444,323713,16385,16812,22561,74794,78999,256,20480,90154,512]

theorem envBound4737 : H12AffineFastState.Bounded env4737 := by
  intro p hp
  have h : env4737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4736_4737 : H12AffineEnvironment.transform 21 115735 env4736 = env4737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115735 env4736 == env4737) = true)

theorem identity4737 : scanCanonicalize (H12AffineFastState.compose env4737 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound4737 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4738 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4097,41349,444,41002,8329,444,323713,16385,16812,22561,16824,20741,256,20480,1464,512]

theorem envBound4738 : H12AffineFastState.Bounded env4738 := by
  intro p hp
  have h : env4738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4737_4738 : H12AffineEnvironment.transform 15 26002 env4737 = env4738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env4737 == env4738) = true)

theorem identity4738 : scanCanonicalize (H12AffineFastState.compose env4738 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4738 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4739 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26002,4524,262144,1024,29225,4097,21420,444,20995,8329,444,262824,16385,16812,22561,16824,20741,256,20480,1464,512]

theorem envBound4739 : H12AffineFastState.Bounded env4739 := by
  intro p hp
  have h : env4739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4738_4739 : H12AffineEnvironment.transform 14 29225 env4738 = env4739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4738 == env4739) = true)

theorem identity4739 : scanCanonicalize (H12AffineFastState.compose env4739 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4739 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4740 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26002,1213,262144,1024,26424,1296,18109,444,18194,8329,444,262824,16385,16812,19760,16824,17428,256,17681,1464,512]

theorem envBound4740 : H12AffineFastState.Bounded env4740 := by
  intro p hp
  have h : env4740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4739_4740 : H12AffineEnvironment.transform 11 1297 env4739 = env4740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4739 == env4740) = true)

theorem identity4740 : scanCanonicalize (H12AffineFastState.compose env4740 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4740 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4741 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,26424,25915,1044,262144,1024,26424,1296,17940,277,18194,8224,277,262657,16385,16645,19760,16657,17428,256,17681,1297,512]

theorem envBound4741 : H12AffineFastState.Bounded env4741 := by
  intro p hp
  have h : env4741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4740_4741 : H12AffineEnvironment.transform 6 41 env4740 = env4741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4740 == env4741) = true)

def env4742 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4310443,41002,8329,4310442,323712,16385,16813,22560,74794,78999,256,20481,4236349,4310550]

theorem envBound4742 : H12AffineFastState.Bounded env4742 := by
  intro p hp
  have h : env4742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4735_4742 : H12AffineEnvironment.transform 5 17 env4735 = env4742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4735 == env4742) = true)

def env4743 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,65536,1197,262144,1024,32768,1281,4194304,4310443,41002,8329,4310442,320896,16385,16813,19744,74794,74135,256,17665,4236349,4310550]

theorem envBound4743 : H12AffineFastState.Bounded env4743 := by
  intro p hp
  have h : env4743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4742_4743 : H12AffineEnvironment.transform 11 1280 env4742 = env4743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4742 == env4743) = true)

theorem identity4743 : scanCanonicalize (H12AffineFastState.compose env4743 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50586) := by decide +kernel

theorem selectedBound4743 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4744 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,50586,1197,262144,1024,32768,1281,4194304,4194353,41002,8329,4194352,320896,16385,16813,19744,57776,58381,256,17665,4236349,4195212]

theorem envBound4744 : H12AffineFastState.Bounded env4744 := by
  intro p hp
  have h : env4744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4743_4744 : H12AffineEnvironment.transform 15 50586 env4743 = env4744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50586 env4743 == env4744) = true)

def env4745 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50570,1197,262144,1024,32768,1281,4194304,4194337,41002,8329,4194336,320896,16385,16813,19744,57760,58381,256,17665,4236333,4195212]

theorem envBound4745 : H12AffineFastState.Bounded env4745 := by
  intro p hp
  have h : env4745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4744_4745 : H12AffineEnvironment.transform 3 0 env4744 = env4745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4744 == env4745) = true)

def env4746 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50570,1197,262144,1024,32768,1281,41088,41121,41002,8329,41120,320896,16385,16813,19744,57760,58381,256,17665,1197,41740]

theorem envBound4746 : H12AffineFastState.Bounded env4746 := by
  intro p hp
  have h : env4746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4745_4746 : H12AffineEnvironment.transform 21 41088 env4745 = env4746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4745 == env4746) = true)

theorem identity4746 : scanCanonicalize (H12AffineFastState.compose env4746 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4746 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4747 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,32768,50319,1197,262144,1024,32768,1028,41088,41121,41002,8329,41120,320645,16385,16552,19493,57509,58381,5,17412,1197,41481]

theorem envBound4747 : H12AffineFastState.Bounded env4747 := by
  intro p hp
  have h : env4747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4746_4747 : H12AffineEnvironment.transform 7 5 env4746 = env4747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4746 == env4747) = true)

theorem identity4747 : scanCanonicalize (H12AffineFastState.compose env4747 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 60461) := by decide +kernel

theorem selectedBound4747 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4748 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,32768,50319,1197,60461,1024,32768,1028,41088,41121,41002,8329,41120,2216,16385,16552,19493,57509,58381,5,17412,1197,41481]

theorem envBound4748 : H12AffineFastState.Bounded env4748 := by
  intro p hp
  have h : env4748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4747_4748 : H12AffineEnvironment.transform 17 60461 env4747 = env4748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60461 env4747 == env4748) = true)

theorem identity4748 : scanCanonicalize (H12AffineFastState.compose env4748 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 26244) := by decide +kernel

theorem selectedBound4748 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4749 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,26244,8715,1197,2729,1024,26244,1028,17924,17957,18094,8329,17956,2216,16385,16552,19493,1569,649,5,17412,1197,17549]

theorem envBound4749 : H12AffineFastState.Bounded env4749 := by
  intro p hp
  have h : env4749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4748_4749 : H12AffineEnvironment.transform 14 26244 env4748 = env4749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26244 env4748 == env4749) = true)

theorem identity4749 : scanCanonicalize (H12AffineFastState.compose env4749 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound4749 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env4750 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,1676,8200,8715,1197,2729,1024,8200,1028,136,169,34,8329,168,2216,1677,1572,2729,1569,649,5,648,1197,513]

theorem envBound4750 : H12AffineFastState.Bounded env4750 := by
  intro p hp
  have h : env4750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4749_4750 : H12AffineEnvironment.transform 13 1676 env4749 = env4750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env4749 == env4750) = true)

theorem identity4750 : scanCanonicalize (H12AffineFastState.compose env4750 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4750 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4751 : List Nat := [2,4,8,0,1,1,128,5,512,1024,2048,1029,8192,1676,8200,8715,1164,2696,1024,8200,1028,136,136,3,8329,137,2185,1677,1541,2696,1536,649,5,648,1164,513]

theorem envBound4751 : H12AffineFastState.Bounded env4751 := by
  intro p hp
  have h : env4751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4750_4751 : H12AffineEnvironment.transform 4 1 env4750 = env4751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4750 == env4751) = true)

theorem identity4751 : scanCanonicalize (H12AffineFastState.compose env4751 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1536) := by decide +kernel

theorem selectedBound4751 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env4752 : List Nat := [2,4,8,0,1,1,128,5,512,1024,1536,1029,8192,1676,8200,8715,1164,1160,1024,8200,1028,136,136,3,8329,137,1673,1677,1541,1160,1536,649,5,648,1164,513]

theorem envBound4752 : H12AffineFastState.Bounded env4752 := by
  intro p hp
  have h : env4752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4751_4752 : H12AffineEnvironment.transform 10 1536 env4751 = env4752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1536 env4751 == env4752) = true)

theorem identity4752 : scanCanonicalize (H12AffineFastState.compose env4752 (packedSelected [4,11] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound4752 : packedSelected [4,11] rootPS < 2^1333 := by decide +kernel

def env4753 : List Nat := [2,4,8,0,1,1,128,5,512,1024,1536,1029,8,1676,0,515,1164,1160,1024,0,1028,136,136,3,129,137,1673,1677,1541,1160,1536,649,5,648,1164,513]

theorem envBound4753 : H12AffineFastState.Bounded env4753 := by
  intro p hp
  have h : env4753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4752_4753 : H12AffineEnvironment.transform 12 8 env4752 = env4753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env4752 == env4753) = true)

theorem identity4753 : scanCanonicalize (H12AffineFastState.compose env4753 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound4753 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env4754 : List Nat := [2,4,8,0,1,1,128,5,131,1024,1155,1029,8,1039,0,128,1164,1160,1024,0,1028,136,136,3,129,137,1034,1038,1158,1160,1155,10,5,11,1164,130]

theorem envBound4754 : H12AffineFastState.Bounded env4754 := by
  intro p hp
  have h : env4754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4753_4754 : H12AffineEnvironment.transform 8 131 env4753 = env4754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env4753 == env4754) = true)

theorem identity4754 : scanCanonicalize (H12AffineFastState.compose env4754 (packedSelected [0,2,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4754 : packedSelected [0,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env4755 : List Nat := [2,4,8,0,1,1,128,5,131,4,135,1,8,11,0,128,136,140,4,0,0,136,136,3,129,137,14,10,130,140,135,10,5,11,136,130]

theorem envBound4755 : H12AffineFastState.Bounded env4755 := by
  intro p hp
  have h : env4755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4754_4755 : H12AffineEnvironment.transform 9 4 env4754 = env4755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4754 == env4755) = true)

theorem identity4755 : scanCanonicalize (H12AffineFastState.compose env4755 (packedSelected [0,1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4755 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env4756 : List Nat := [2,4,3,0,1,1,128,5,131,4,135,1,3,0,0,128,131,135,4,0,0,131,131,3,129,130,5,1,130,135,135,1,5,0,131,130]

theorem envBound4756 : H12AffineFastState.Bounded env4756 := by
  intro p hp
  have h : env4756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4755_4756 : H12AffineEnvironment.transform 2 3 env4755 = env4756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4755 == env4756) = true)

theorem identity4756 : scanCanonicalize (H12AffineFastState.compose env4756 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4757 : List Nat := [2,0,3,0,1,1,128,1,131,0,131,1,3,0,0,128,131,131,0,0,0,131,131,3,129,130,1,1,130,131,131,1,1,0,131,130]

theorem envBound4757 : H12AffineFastState.Bounded env4757 := by
  intro p hp
  have h : env4757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4756_4757 : H12AffineEnvironment.transform 1 0 env4756 = env4757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4756 == env4757) = true)

theorem identity4757 : scanCanonicalize (H12AffineFastState.compose env4757 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound4757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4758 : List Nat := [2,0,3,0,1,1,2,1,1,0,1,1,3,0,0,2,1,1,0,0,0,1,1,3,3,0,1,1,0,1,1,1,1,0,1,0]

theorem envBound4758 : H12AffineFastState.Bounded env4758 := by
  intro p hp
  have h : env4758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4757_4758 : H12AffineEnvironment.transform 6 2 env4757 = env4758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env4757 == env4758) = true)

def env4759 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50570,1197,262144,1024,32768,1281,41089,41120,41002,8329,41121,320896,16385,16813,19744,57760,58381,256,17665,1196,41741]

theorem envBound4759 : H12AffineFastState.Bounded env4759 := by
  intro p hp
  have h : env4759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4745_4759 : H12AffineEnvironment.transform 21 41089 env4745 = env4759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4745 == env4759) = true)

theorem identity4759 : scanCanonicalize (H12AffineFastState.compose env4759 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4759 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4760 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8201,25987,1197,262144,1024,8201,1281,136,169,35,8329,168,279945,16385,16813,19744,16809,17412,256,17665,1196,772]

theorem envBound4760 : H12AffineFastState.Bounded env4760 := by
  intro p hp
  have h : env4760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4759_4760 : H12AffineEnvironment.transform 14 8201 env4759 = env4760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4759 == env4760) = true)

theorem identity4760 : scanCanonicalize (H12AffineFastState.compose env4760 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20392) := by decide +kernel

theorem selectedBound4760 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4761 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8201,25987,1197,20392,1024,8201,1281,136,169,35,8329,168,2593,16385,16813,19744,16809,17412,256,17665,1196,772]

theorem envBound4761 : H12AffineFastState.Bounded env4761 := by
  intro p hp
  have h : env4761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4760_4761 : H12AffineEnvironment.transform 17 20392 env4760 = env4761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20392 env4760 == env4761) = true)

theorem identity4761 : scanCanonicalize (H12AffineFastState.compose env4761 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4761 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env4762 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,8201,25734,1197,20141,1024,8201,1028,136,169,35,8329,168,2593,16385,16552,19493,16556,17412,5,17412,1196,513]

theorem envBound4762 : H12AffineFastState.Bounded env4762 := by
  intro p hp
  have h : env4762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4761_4762 : H12AffineEnvironment.transform 7 5 env4761 = env4762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4761 == env4762) = true)

theorem identity4762 : scanCanonicalize (H12AffineFastState.compose env4762 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2734) := by decide +kernel

theorem selectedBound4762 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4763 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,2734,16384,2727,20008,1197,20141,1024,2727,1028,136,169,35,2599,168,2593,16385,16552,19493,16556,17412,5,17412,1196,513]

theorem envBound4763 : H12AffineFastState.Bounded env4763 := by
  intro p hp
  have h : env4763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4762_4763 : H12AffineEnvironment.transform 12 2734 env4762 = env4763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2734 env4762 == env4763) = true)

theorem identity4763 : scanCanonicalize (H12AffineFastState.compose env4763 (packedSelected [13,17] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4763 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4764 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,2191,16384,2182,19465,1197,19596,1024,2182,1028,136,169,35,2054,168,2048,16385,16552,19493,16556,17412,5,17412,1196,32]

theorem envBound4764 : H12AffineFastState.Bounded env4764 := by
  intro p hp
  have h : env4764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4763_4764 : H12AffineEnvironment.transform 8 33 env4763 = env4764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4763 == env4764) = true)

theorem identity4764 : scanCanonicalize (H12AffineFastState.compose env4764 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 2062) := by decide +kernel

theorem selectedBound4764 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4765 : List Nat := [2,4,8,0,32,1,128,5,33,1024,2048,1029,2191,2062,2182,1031,1197,1154,1024,2182,1028,136,169,35,2054,168,2048,2063,2214,1067,2210,3082,5,3082,1196,32]

theorem envBound4765 : H12AffineFastState.Bounded env4765 := by
  intro p hp
  have h : env4765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4764_4765 : H12AffineEnvironment.transform 13 2062 env4764 = env4765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2062 env4764 == env4765) = true)

theorem identity4765 : scanCanonicalize (H12AffineFastState.compose env4765 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4765 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4766 : List Nat := [2,4,8,0,10,1,128,5,11,1024,2048,1029,2191,2062,2182,1031,1159,1154,1024,2182,1028,136,131,9,2054,130,2048,2063,2188,1025,2184,3082,5,3082,1158,10]

theorem envBound4766 : H12AffineFastState.Bounded env4766 := by
  intro p hp
  have h : env4766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4765_4766 : H12AffineEnvironment.transform 4 10 env4765 = env4766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4765 == env4766) = true)

theorem identity4766 : scanCanonicalize (H12AffineFastState.compose env4766 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4766 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4767 : List Nat := [2,4,8,0,10,1,3,5,11,1024,2048,1029,2060,2062,2053,1031,1028,1025,1024,2053,1028,11,0,9,2054,1,2048,2063,2063,1025,2059,3082,5,3082,1029,10]

theorem envBound4767 : H12AffineFastState.Bounded env4767 := by
  intro p hp
  have h : env4767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4766_4767 : H12AffineEnvironment.transform 6 3 env4766 = env4767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4766 == env4767) = true)

theorem identity4767 : scanCanonicalize (H12AffineFastState.compose env4767 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1025) := by decide +kernel

theorem selectedBound4767 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4768 : List Nat := [2,4,8,0,10,1,3,5,11,1024,1025,1029,1037,1039,1028,1031,1028,1025,1024,1028,1028,11,0,9,1031,1,1025,1038,1038,1025,1034,11,5,11,1029,10]

theorem envBound4768 : H12AffineFastState.Bounded env4768 := by
  intro p hp
  have h : env4768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4767_4768 : H12AffineEnvironment.transform 10 1025 env4767 = env4768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1025 env4767 == env4768) = true)

theorem identity4768 : scanCanonicalize (H12AffineFastState.compose env4768 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4769 : List Nat := [2,4,7,0,5,1,3,5,4,1024,1025,1029,1026,1024,1028,1031,1028,1025,1024,1028,1028,4,0,6,1031,1,1025,1025,1025,1025,1029,4,5,4,1029,5]

theorem envBound4769 : H12AffineFastState.Bounded env4769 := by
  intro p hp
  have h : env4769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4768_4769 : H12AffineEnvironment.transform 2 7 env4768 = env4769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4768 == env4769) = true)

theorem identity4769 : scanCanonicalize (H12AffineFastState.compose env4769 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound4769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4770 : List Nat := [2,4,7,0,5,1,3,5,4,5,4,0,7,5,1,2,1,4,5,1,1,4,0,6,2,1,4,4,4,4,0,4,5,4,0,5]

theorem envBound4770 : H12AffineFastState.Bounded env4770 := by
  intro p hp
  have h : env4770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4769_4770 : H12AffineEnvironment.transform 9 5 env4769 = env4770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env4769 == env4770) = true)

def env4771 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,32768,50571,1197,262144,1024,32768,1281,4194304,4194336,41002,8329,4194337,320896,16385,16813,19744,57761,58381,256,17665,4236332,4195212]

theorem envBound4771 : H12AffineFastState.Bounded env4771 := by
  intro p hp
  have h : env4771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4744_4771 : H12AffineEnvironment.transform 3 1 env4744 = env4771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4744 == env4771) = true)

theorem identity4771 : scanCanonicalize (H12AffineFastState.compose env4771 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound4771 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4772 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,8460,25735,1197,262144,1024,8460,1281,4194304,4194336,294,8329,4194337,279692,16385,16813,19744,16557,17665,256,17665,4195616,4195212]

theorem envBound4772 : H12AffineFastState.Bounded env4772 := by
  intro p hp
  have h : env4772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4771_4772 : H12AffineEnvironment.transform 14 8460 env4771 = env4772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env4771 == env4772) = true)

theorem identity4772 : scanCanonicalize (H12AffineFastState.compose env4772 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4772 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4773 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1029,8192,16384,8201,25735,1197,262144,1024,8201,1028,4194304,4194336,35,8329,4194337,279692,16385,16552,19493,16557,17412,5,17412,4195365,4194953]

theorem envBound4773 : H12AffineFastState.Bounded env4773 := by
  intro p hp
  have h : env4773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4772_4773 : H12AffineEnvironment.transform 7 5 env4772 = env4773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4772 == env4773) = true)

def env4774 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,65536,1196,262144,1024,32768,1280,4194304,4310443,41002,8329,4310442,320897,16385,16813,19745,74794,74134,256,17664,4236349,4310550]

theorem envBound4774 : H12AffineFastState.Bounded env4774 := by
  intro p hp
  have h : env4774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4742_4774 : H12AffineEnvironment.transform 11 1281 env4742 = env4774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4742 == env4774) = true)

theorem identity4774 : scanCanonicalize (H12AffineFastState.compose env4774 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50215) := by decide +kernel

theorem selectedBound4774 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,50215,1196,262144,1024,32768,1280,4194304,4194700,41002,8329,4194701,320897,16385,16813,19745,57357,58801,256,17664,4236349,4194865]

theorem envBound4775 : H12AffineFastState.Bounded env4775 := by
  intro p hp
  have h : env4775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4774_4775 : H12AffineEnvironment.transform 15 50215 env4774 = env4775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50215 env4774 == env4775) = true)

def env4776 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50215,1196,262144,1024,32768,1280,4194304,4194700,41002,8329,4194701,320897,16385,16813,19745,57357,58785,256,17664,4236333,4194849]

theorem envBound4776 : H12AffineFastState.Bounded env4776 := by
  intro p hp
  have h : env4776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4775_4776 : H12AffineEnvironment.transform 3 0 env4775 = env4776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4775 == env4776) = true)

theorem identity4776 : scanCanonicalize (H12AffineFastState.compose env4776 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound4776 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4777 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8613,25986,1196,262144,1024,8613,1280,4194304,4194700,399,8329,4194701,279588,16385,16813,19745,16808,17412,256,17664,4195720,4194849]

theorem envBound4777 : H12AffineFastState.Bounded env4777 := by
  intro p hp
  have h : env4777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4776_4777 : H12AffineEnvironment.transform 14 8613 env4776 = env4777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env4776 == env4777) = true)

theorem identity4777 : scanCanonicalize (H12AffineFastState.compose env4777 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 17549) := by decide +kernel

theorem selectedBound4777 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4778 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8613,25986,1196,262144,1024,8613,1280,17549,17665,399,8329,17664,279588,16385,16813,19745,16808,17412,256,17664,16645,18092]

theorem envBound4778 : H12AffineFastState.Bounded env4778 := by
  intro p hp
  have h : env4778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4777_4778 : H12AffineEnvironment.transform 21 17549 env4777 = env4778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17549 env4777 == env4778) = true)

theorem identity4778 : scanCanonicalize (H12AffineFastState.compose env4778 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4778 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4779 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8613,25986,1196,2081,1024,8613,1280,17549,17665,399,8329,17664,19461,16385,16813,19745,16808,17412,256,17664,16645,18092]

theorem envBound4779 : H12AffineFastState.Bounded env4779 := by
  intro p hp
  have h : env4779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4778_4779 : H12AffineEnvironment.transform 17 2081 env4778 = env4779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4778 == env4779) = true)

theorem identity4779 : scanCanonicalize (H12AffineFastState.compose env4779 (packedSelected [0,1,6,7,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 11815) := by decide +kernel

theorem selectedBound4779 : packedSelected [0,1,6,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env4780 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,11815,8613,2981,1196,2081,1024,8613,1280,10922,11046,399,8329,11047,8738,11814,12170,8966,12175,10787,256,11047,12066,10379]

theorem envBound4780 : H12AffineFastState.Bounded env4780 := by
  intro p hp
  have h : env4780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4779_4780 : H12AffineEnvironment.transform 13 11815 env4779 = env4780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11815 env4779 == env4780) = true)

theorem identity4780 : scanCanonicalize (H12AffineFastState.compose env4780 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2311) := by decide +kernel

theorem selectedBound4780 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4781 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,2311,1824,2210,2981,1196,2081,1024,2210,1280,941,545,399,2446,544,2853,1825,1677,2561,1672,804,256,544,1573,396]

theorem envBound4781 : H12AffineFastState.Bounded env4781 := by
  intro p hp
  have h : env4781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4780_4781 : H12AffineEnvironment.transform 12 2311 env4780 = env4781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2311 env4780 == env4781) = true)

theorem identity4781 : scanCanonicalize (H12AffineFastState.compose env4781 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4781 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env4782 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1196,2218,1677,2210,2568,1196,2081,1024,2210,1197,512,545,34,2083,544,2696,1676,1677,2561,1672,649,173,544,1573,33]

theorem envBound4782 : H12AffineFastState.Bounded env4782 := by
  intro p hp
  have h : env4782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4781_4782 : H12AffineEnvironment.transform 7 173 env4781 = env4782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4781 == env4782) = true)

theorem identity4782 : scanCanonicalize (H12AffineFastState.compose env4782 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1158) := by decide +kernel

theorem selectedBound4782 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4783 : List Nat := [2,4,8,0,32,1,128,173,512,1024,1158,1196,1068,1677,1060,1678,1196,1191,1024,1060,1197,512,545,34,1189,544,1550,1676,1677,1671,1672,649,173,544,1573,33]

theorem envBound4783 : H12AffineFastState.Bounded env4783 := by
  intro p hp
  have h : env4783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4782_4783 : H12AffineEnvironment.transform 10 1158 env4782 = env4783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1158 env4782 == env4783) = true)

theorem identity4783 : scanCanonicalize (H12AffineFastState.compose env4783 (packedSelected [7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4783 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env4784 : List Nat := [2,4,8,0,32,1,41,4,512,1024,1071,1029,1068,1572,1060,1575,1029,1038,1024,1060,1028,512,545,34,1036,544,1550,1573,1572,1582,1569,544,4,544,1573,33]

theorem envBound4784 : H12AffineFastState.Bounded env4784 := by
  intro p hp
  have h : env4784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4783_4784 : H12AffineEnvironment.transform 6 41 env4783 = env4784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4783 == env4784) = true)

theorem identity4784 : scanCanonicalize (H12AffineFastState.compose env4784 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4785 : List Nat := [2,4,2,0,32,1,35,4,512,1024,1061,1029,1062,1572,1060,1575,1029,1028,1024,1060,1028,512,545,34,1030,544,1540,1573,1572,1572,1569,544,4,544,1573,33]

theorem envBound4785 : H12AffineFastState.Bounded env4785 := by
  intro p hp
  have h : env4785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4784_4785 : H12AffineEnvironment.transform 2 2 env4784 = env4785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4784 == env4785) = true)

theorem identity4785 : scanCanonicalize (H12AffineFastState.compose env4785 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound4785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4786 : List Nat := [2,4,2,0,32,1,35,4,512,517,544,512,547,33,545,34,512,513,517,545,513,512,545,34,515,544,1,32,33,33,36,544,4,544,32,33]

theorem envBound4786 : H12AffineFastState.Bounded env4786 := by
  intro p hp
  have h : env4786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4785_4786 : H12AffineEnvironment.transform 9 517 env4785 = env4786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env4785 == env4786) = true)

theorem identity4786 : scanCanonicalize (H12AffineFastState.compose env4786 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4786 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env4787 : List Nat := [2,4,2,0,32,1,35,4,0,5,32,0,35,33,33,34,0,1,5,33,1,0,33,34,3,32,1,32,33,33,36,32,4,32,32,33]

theorem envBound4787 : H12AffineFastState.Bounded env4787 := by
  intro p hp
  have h : env4787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4786_4787 : H12AffineEnvironment.transform 8 0 env4786 = env4787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4786 == env4787) = true)

def env4788 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,32768,50215,1196,262144,1024,32768,1280,4194304,4194700,41002,8329,4194701,320897,16385,16813,19745,57357,58784,256,17664,4236332,4194848]

theorem envBound4788 : H12AffineFastState.Bounded env4788 := by
  intro p hp
  have h : env4788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4775_4788 : H12AffineEnvironment.transform 3 1 env4775 = env4788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4775 == env4788) = true)

theorem identity4788 : scanCanonicalize (H12AffineFastState.compose env4788 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4788 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4789 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50215,1029,262144,1024,32768,1280,4194304,4194597,41002,8224,4194596,320808,16385,16644,19745,57357,58633,256,17664,4236332,4194848]

theorem envBound4789 : H12AffineFastState.Bounded env4789 := by
  intro p hp
  have h : env4789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4788_4789 : H12AffineEnvironment.transform 6 41 env4788 = env4789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4788 == env4789) = true)

theorem identity4789 : scanCanonicalize (H12AffineFastState.compose env4789 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound4789 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4790 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50215,1029,19493,1024,32768,1280,4194304,4194597,41002,8224,4194596,43277,16385,16644,19745,57357,58633,256,17664,4236332,4194848]

theorem envBound4790 : H12AffineFastState.Bounded env4790 := by
  intro p hp
  have h : env4790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4789_4790 : H12AffineEnvironment.transform 17 19493 env4789 = env4790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env4789 == env4790) = true)

theorem identity4790 : scanCanonicalize (H12AffineFastState.compose env4790 (packedSelected [0,3,4,5,7,10,13,17,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound4790 : packedSelected [0,3,4,5,7,10,13,17,22] rootPS < 2^1333 := by decide +kernel

def env4791 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50215,1029,19493,1024,32768,1280,41001,41228,41002,8224,41229,43277,16385,16644,19745,57357,58633,256,17664,1029,41481]

theorem envBound4791 : H12AffineFastState.Bounded env4791 := by
  intro p hp
  have h : env4791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4790_4791 : H12AffineEnvironment.transform 21 41001 env4790 = env4791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env4790 == env4791) = true)

theorem identity4791 : scanCanonicalize (H12AffineFastState.compose env4791 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4791 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4792 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,1573,32768,33282,1029,2560,1024,32768,1280,41001,41228,41002,8224,41229,43277,1572,1825,2820,42536,41772,256,805,1029,41481]

theorem envBound4792 : H12AffineFastState.Bounded env4792 := by
  intro p hp
  have h : env4792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4791_4792 : H12AffineEnvironment.transform 13 1573 env4791 = env4792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env4791 == env4792) = true)

theorem identity4792 : scanCanonicalize (H12AffineFastState.compose env4792 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4792 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4793 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,1573,8200,8714,1029,2560,1024,8200,1280,33,260,34,8224,261,2309,1572,1825,2820,1568,804,256,805,1029,513]

theorem envBound4793 : H12AffineFastState.Bounded env4793 := by
  intro p hp
  have h : env4793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4792_4793 : H12AffineEnvironment.transform 14 8200 env4792 = env4793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4792 == env4793) = true)

theorem identity4793 : scanCanonicalize (H12AffineFastState.compose env4793 (packedSelected [4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 266) := by decide +kernel

theorem selectedBound4793 : packedSelected [4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env4794 : List Nat := [2,4,8,1,32,0,41,256,266,1024,2048,1281,8192,1327,8200,8448,1029,2314,1024,8200,1280,33,260,34,8224,261,2309,1326,1067,2062,1322,46,256,47,1029,267]

theorem envBound4794 : H12AffineFastState.Bounded env4794 := by
  intro p hp
  have h : env4794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4793_4794 : H12AffineEnvironment.transform 8 266 env4793 = env4794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 266 env4793 == env4794) = true)

theorem identity4794 : scanCanonicalize (H12AffineFastState.compose env4794 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4794 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4795 : List Nat := [2,4,8,1,14,0,7,256,266,1024,2048,1281,8192,1281,8200,8448,1029,2314,1024,8200,1280,15,260,12,8206,261,2309,1280,1029,2062,1284,0,256,1,1029,267]

theorem envBound4795 : H12AffineFastState.Bounded env4795 := by
  intro p hp
  have h : env4795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4794_4795 : H12AffineEnvironment.transform 4 14 env4794 = env4795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4794 == env4795) = true)

theorem identity4795 : scanCanonicalize (H12AffineFastState.compose env4795 (packedSelected [0,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound4795 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env4796 : List Nat := [2,4,8,1,14,0,7,256,266,1024,2048,1281,1289,1281,1281,1033,1029,2314,1024,1281,1280,15,260,12,1287,261,2309,1280,1029,2062,1284,0,256,1,1029,267]

theorem envBound4796 : H12AffineFastState.Bounded env4796 := by
  intro p hp
  have h : env4796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4795_4796 : H12AffineEnvironment.transform 12 1289 env4795 = env4796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env4795 == env4796) = true)

def env4797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,12644668,257,20561,8479126,8389613]

theorem envBound4797 : H12AffineFastState.Bounded env4797 := by
  intro p hp
  have h : env4797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4733_4797 : H12AffineEnvironment.transform 18 1025 env4733 = env4797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4733 == env4797) = true)

theorem identity4797 : scanCanonicalize (H12AffineFastState.compose env4797 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98474) := by decide +kernel

theorem selectedBound4797 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,98474,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,8483222,257,20561,8479126,8389613]

theorem envBound4798 : H12AffineFastState.Bounded env4798 := by
  intro p hp
  have h : env4798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4797_4798 : H12AffineEnvironment.transform 21 98474 env4797 = env4798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98474 env4797 == env4798) = true)

def env4799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98474,8388608,41002,8329,8388609,323712,16385,16812,22560,74795,8483222,257,20481,8479126,8389565]

theorem envBound4799 : H12AffineFastState.Bounded env4799 := by
  intro p hp
  have h : env4799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4798_4799 : H12AffineEnvironment.transform 5 16 env4798 = env4799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4798 == env4799) = true)

def env4800 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98306,8388608,41002,8225,8388609,323624,16385,16644,22560,74795,8483134,257,20481,8479038,8389397]

theorem envBound4800 : H12AffineFastState.Bounded env4800 := by
  intro p hp
  have h : env4800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4799_4800 : H12AffineEnvironment.transform 6 40 env4799 = env4800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4799 == env4800) = true)

theorem identity4800 : scanCanonicalize (H12AffineFastState.compose env4800 (packedSelected [0,7,9,11,20,22,32] rootPS)) = affineNative (2^(22+1) ^^^ 325949) := by decide +kernel

theorem selectedBound4800 : packedSelected [0,7,9,11,20,22,32] rootPS < 2^1333 := by decide +kernel

def env4801 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98306,325949,41002,8225,325948,323624,16385,16644,22560,74795,362499,257,20481,366595,326184]

theorem envBound4801 : H12AffineFastState.Bounded env4801 := by
  intro p hp
  have h : env4801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4800_4801 : H12AffineEnvironment.transform 22 325949 env4800 = env4801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 325949 env4800 == env4801) = true)

theorem identity4801 : scanCanonicalize (H12AffineFastState.compose env4801 (packedSelected [0,1,3,5,7,8,9,10,13,17,20,22,26] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound4801 : packedSelected [0,1,3,5,7,8,9,10,13,17,20,22,26] rootPS < 2^1333 := by decide +kernel

def env4802 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,43048,1025,32768,4097,98306,20757,41002,8225,20756,22528,16385,16644,22560,74795,73771,257,20481,77867,20992]

theorem envBound4802 : H12AffineFastState.Bounded env4802 := by
  intro p hp
  have h : env4802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4801_4802 : H12AffineEnvironment.transform 17 43048 env4801 = env4802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env4801 == env4802) = true)

theorem identity4802 : scanCanonicalize (H12AffineFastState.compose env4802 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound4802 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4803 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8460,65536,4356,2340,1025,8460,4097,73998,20757,294,8225,20756,22528,16385,16644,22560,74795,73771,257,20481,77867,20992]

theorem envBound4803 : H12AffineFastState.Bounded env4803 := by
  intro p hp
  have h : env4803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4802_4803 : H12AffineEnvironment.transform 14 8460 env4802 = env4803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env4802 == env4803) = true)

theorem identity4803 : scanCanonicalize (H12AffineFastState.compose env4803 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 19478) := by decide +kernel

theorem selectedBound4803 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4804 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8460,19478,4356,2340,1025,8460,4097,27928,20757,294,8225,20756,22528,16385,16644,22560,26685,27709,257,20481,31805,20992]

theorem envBound4804 : H12AffineFastState.Bounded env4804 := by
  intro p hp
  have h : env4804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4803_4804 : H12AffineEnvironment.transform 15 19478 env4803 = env4804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19478 env4803 == env4804) = true)

theorem identity4804 : scanCanonicalize (H12AffineFastState.compose env4804 (packedSelected [3,5,11] rootPS)) = affineNative (2^(13+1) ^^^ 4608) := by decide +kernel

theorem selectedBound4804 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env4805 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4608,8460,7702,4356,2340,1025,8460,4097,16152,789,294,8225,788,2560,4609,4868,2592,14909,15933,257,513,11837,0]

theorem envBound4805 : H12AffineFastState.Bounded env4805 := by
  intro p hp
  have h : env4805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4804_4805 : H12AffineEnvironment.transform 13 4608 env4804 = env4805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4608 env4804 == env4805) = true)

theorem identity4805 : scanCanonicalize (H12AffineFastState.compose env4805 (packedSelected [1,2,3,4,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4805 : packedSelected [1,2,3,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env4806 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1841,8192,1329,8460,2343,1589,2340,1025,8460,1840,10281,789,294,8225,788,2560,1328,1077,2592,11532,10508,257,513,11837,0]

theorem envBound4806 : H12AffineFastState.Bounded env4806 := by
  intro p hp
  have h : env4806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4805_4806 : H12AffineEnvironment.transform 11 1841 env4805 = env4806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4805 == env4806) = true)

theorem identity4806 : scanCanonicalize (H12AffineFastState.compose env4806 (packedSelected [0,1,3,6,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4806 : packedSelected [0,1,3,6,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4807 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1589,8192,1077,8200,2083,1589,2080,1025,8200,1588,10281,529,34,8225,528,2560,1076,1077,2592,11272,10248,5,513,11837,0]

theorem envBound4807 : H12AffineFastState.Bounded env4807 := by
  intro p hp
  have h : env4807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4806_4807 : H12AffineEnvironment.transform 7 4 env4806 = env4807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4806 == env4807) = true)

theorem identity4807 : scanCanonicalize (H12AffineFastState.compose env4807 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4808 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1588,1589,8192,1077,8200,1559,1589,1556,1025,8200,1588,9757,529,34,8225,528,1076,1076,1077,1044,8764,9788,5,513,8201,0]

theorem envBound4808 : H12AffineFastState.Bounded env4808 := by
  intro p hp
  have h : env4808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4807_4808 : H12AffineEnvironment.transform 10 1588 env4807 = env4808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env4807 == env4808) = true)

theorem identity4808 : scanCanonicalize (H12AffineFastState.compose env4808 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound4808 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4809 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1588,1589,1085,1077,1077,1559,1589,1556,1025,1077,1588,544,529,34,1052,528,1076,1076,1077,1044,1537,513,5,513,1076,0]

theorem envBound4809 : H12AffineFastState.Bounded env4809 := by
  intro p hp
  have h : env4809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4808_4809 : H12AffineEnvironment.transform 12 1085 env4808 = env4809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env4808 == env4809) = true)

theorem identity4809 : scanCanonicalize (H12AffineFastState.compose env4809 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound4809 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4810 : List Nat := [2,4,8,16,32,16,40,4,512,526,58,59,563,571,571,25,59,26,527,571,58,544,529,34,530,528,570,570,571,538,15,513,5,513,570,0]

theorem envBound4810 : H12AffineFastState.Bounded env4810 := by
  intro p hp
  have h : env4810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4809_4810 : H12AffineEnvironment.transform 9 526 env4809 = env4810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env4809 == env4810) = true)

theorem identity4810 : scanCanonicalize (H12AffineFastState.compose env4810 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound4810 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4811 : List Nat := [2,4,8,16,32,16,40,4,58,52,58,59,9,1,1,25,59,26,53,1,58,26,43,34,40,42,0,0,1,32,15,59,5,59,0,0]

theorem envBound4811 : H12AffineFastState.Bounded env4811 := by
  intro p hp
  have h : env4811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4810_4811 : H12AffineEnvironment.transform 8 58 env4810 = env4811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env4810 == env4811) = true)

def env4812 : List Nat := [2,4,8,4,32,4,40,4,46,32,46,47,9,1,1,13,47,14,33,1,46,14,43,34,40,42,0,0,1,32,15,47,5,47,0,0]

theorem envBound4812 : H12AffineFastState.Bounded env4812 := by
  intro p hp
  have h : env4812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4811_4812 : H12AffineEnvironment.transform 3 4 env4811 = env4812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4811 == env4812) = true)

def env4813 : List Nat := [2,0,8,0,32,0,40,0,42,32,42,43,9,1,1,9,43,10,33,1,42,10,43,34,40,42,0,0,1,32,11,43,1,43,0,0]

theorem envBound4813 : H12AffineFastState.Bounded env4813 := by
  intro p hp
  have h : env4813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4812_4813 : H12AffineEnvironment.transform 1 0 env4812 = env4813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4812 == env4813) = true)

def env4814 : List Nat := [2,1,8,1,32,1,40,1,43,32,43,42,9,1,1,8,42,11,33,1,43,11,43,34,40,42,0,0,1,32,10,42,0,42,0,0]

theorem envBound4814 : H12AffineFastState.Bounded env4814 := by
  intro p hp
  have h : env4814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4812_4814 : H12AffineEnvironment.transform 1 1 env4812 = env4814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4812 == env4814) = true)

theorem identity4814 : scanCanonicalize (H12AffineFastState.compose env4814 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4814 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4815 : List Nat := [2,1,8,1,10,1,2,1,1,10,1,0,9,1,1,8,0,11,11,1,1,11,1,8,2,0,0,0,1,10,10,0,0,0,0,0]

theorem envBound4815 : H12AffineFastState.Bounded env4815 := by
  intro p hp
  have h : env4815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4814_4815 : H12AffineEnvironment.transform 4 10 env4814 = env4815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4814 == env4815) = true)

def leafEnv4815 : List Nat := [2,1,8,1,10,1,2,1,1,10,1,0,9,1,1,8,0,11,11,1,1,11,1,8,11,2,1,0,0,0,1,10,10,0,0,0,0,3,0,0,1,0,0]

def active4815 : List Nat := [0,2]

def tree4815 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4815 : H12WitnessSearch.Good tree4815 := H12GlobalWitnessIndex.good

theorem leafIdentity4815 : H12AffineFastState.composeSystem env4815 rootObs = leafEnv4815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4815 rootObs == leafEnv4815) = true)

theorem terminalChecked4815 : H12PackedTerminal.terminalCheckFast leafEnv4815 active4815 tree4815 = true := by decide +kernel

def env4816 : List Nat := [2,4,8,5,32,5,40,4,47,33,47,46,9,1,1,12,46,15,32,1,47,15,43,34,40,42,0,0,1,32,15,46,5,46,0,0]

theorem envBound4816 : H12AffineFastState.Bounded env4816 := by
  intro p hp
  have h : env4816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4811_4816 : H12AffineEnvironment.transform 3 5 env4811 = env4816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4811 == env4816) = true)

theorem identity4816 : scanCanonicalize (H12AffineFastState.compose env4816 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound4816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4817 : List Nat := [2,4,8,5,15,5,7,4,0,14,0,1,9,1,1,12,1,15,15,1,0,15,4,13,7,5,0,0,1,15,15,1,5,1,0,0]

theorem envBound4817 : H12AffineFastState.Bounded env4817 := by
  intro p hp
  have h : env4817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4816_4817 : H12AffineEnvironment.transform 4 15 env4816 = env4817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env4816 == env4817) = true)

def env4818 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98307,8388608,41002,8224,8388609,323625,16385,16645,22560,74795,8483135,257,20481,8479039,8389396]

theorem envBound4818 : H12AffineFastState.Bounded env4818 := by
  intro p hp
  have h : env4818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4799_4818 : H12AffineEnvironment.transform 6 41 env4799 = env4818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4799 == env4818) = true)

theorem identity4818 : scanCanonicalize (H12AffineFastState.compose env4818 (packedSelected [0,7,9,11,20,22,32] rootPS)) = affineNative (2^(22+1) ^^^ 74046) := by decide +kernel

theorem selectedBound4818 : packedSelected [0,7,9,11,20,22,32] rootPS < 2^1333 := by decide +kernel

def env4819 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98307,74046,41002,8224,74047,323625,16385,16645,22560,74795,20481,257,20481,16385,74282]

theorem envBound4819 : H12AffineFastState.Bounded env4819 := by
  intro p hp
  have h : env4819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4818_4819 : H12AffineEnvironment.transform 22 74046 env4818 = env4819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 74046 env4818 == env4819) = true)

theorem identity4819 : scanCanonicalize (H12AffineFastState.compose env4819 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4819 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4820 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,98307,73786,41002,8224,73787,323625,16385,16385,22560,74795,20481,5,20481,16385,74282]

theorem envBound4820 : H12AffineFastState.Bounded env4820 := by
  intro p hp
  have h : env4820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4819_4820 : H12AffineEnvironment.transform 7 4 env4819 = env4820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4819 == env4820) = true)

theorem identity4820 : scanCanonicalize (H12AffineFastState.compose env4820 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4820 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4821 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,2080,1025,32768,4097,98307,73786,41002,8224,73787,63497,16385,16385,22560,74795,20481,5,20481,16385,74282]

theorem envBound4821 : H12AffineFastState.Bounded env4821 := by
  intro p hp
  have h : env4821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4820_4821 : H12AffineEnvironment.transform 17 2080 env4820 = env4821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4820 == env4821) = true)

theorem identity4821 : scanCanonicalize (H12AffineFastState.compose env4821 (packedSelected [3,4,5,9,10,12,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 38422) := by decide +kernel

theorem selectedBound4821 : packedSelected [3,4,5,9,10,12,18,20] rootPS < 2^1333 := by decide +kernel

def env4822 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,38422,4097,2080,1025,32768,4097,5653,46636,41002,8224,46637,63497,16385,16385,22560,45629,20481,5,20481,16385,46140]

theorem envBound4822 : H12AffineFastState.Bounded env4822 := by
  intro p hp
  have h : env4822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4821_4822 : H12AffineEnvironment.transform 15 38422 env4821 = env4822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38422 env4821 == env4822) = true)

theorem identity4822 : scanCanonicalize (H12AffineFastState.compose env4822 (packedSelected [3,5,10,12,13,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4822 : packedSelected [3,5,10,12,13,18,21] rootPS < 2^1333 := by decide +kernel

def env4823 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,8201,13855,4097,2080,1025,8201,4097,5653,5669,35,8224,5668,22528,16385,16385,22560,4660,20481,5,20481,16385,5173]

theorem envBound4823 : H12AffineFastState.Bounded env4823 := by
  intro p hp
  have h : env4823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4822_4823 : H12AffineEnvironment.transform 14 8201 env4822 = env4823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4822 == env4823) = true)

theorem identity4823 : scanCanonicalize (H12AffineFastState.compose env4823 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4823 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env4824 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,1582,8201,13855,4097,2080,1025,8201,4097,5653,5669,35,8224,5668,7726,1583,1583,7694,4660,5679,5,5679,1583,5173]

theorem envBound4824 : H12AffineFastState.Bounded env4824 := by
  intro p hp
  have h : env4824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4823_4824 : H12AffineEnvironment.transform 13 1582 env4823 = env4824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1582 env4823 == env4824) = true)

theorem identity4824 : scanCanonicalize (H12AffineFastState.compose env4824 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4824 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4825 : List Nat := [2,4,8,11,32,11,41,4,512,1024,2048,4096,8192,1582,8201,13828,4097,2080,1025,8201,4097,5646,5669,35,8224,5668,7726,1583,1583,7694,4655,5679,5,5679,1583,5166]

theorem envBound4825 : H12AffineFastState.Bounded env4825 := by
  intro p hp
  have h : env4825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4824_4825 : H12AffineEnvironment.transform 3 11 env4824 = env4825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4824 == env4825) = true)

theorem identity4825 : scanCanonicalize (H12AffineFastState.compose env4825 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4826 : List Nat := [2,4,8,11,32,11,41,4,512,1024,2048,2081,8192,1582,8201,11813,2080,2080,1025,8201,2080,3631,3588,35,8224,3589,1551,1583,1583,1583,2574,3598,5,3598,1583,3087]

theorem envBound4826 : H12AffineFastState.Bounded env4826 := by
  intro p hp
  have h : env4826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4825_4826 : H12AffineEnvironment.transform 11 2081 env4825 = env4826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env4825 == env4826) = true)

theorem identity4826 : scanCanonicalize (H12AffineFastState.compose env4826 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4826 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4827 : List Nat := [2,4,8,11,32,11,41,4,512,1024,1550,1583,8192,1582,8201,8235,1582,1582,1025,8201,1582,33,10,35,8224,11,1551,1583,1583,1583,1024,0,5,0,1583,513]

theorem envBound4827 : H12AffineFastState.Bounded env4827 := by
  intro p hp
  have h : env4827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4826_4827 : H12AffineEnvironment.transform 10 1550 env4826 = env4827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4826 == env4827) = true)

theorem identity4827 : scanCanonicalize (H12AffineFastState.compose env4827 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound4827 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4828 : List Nat := [2,4,8,11,32,11,41,4,512,1024,1550,1583,1062,1582,1071,1037,1582,1582,1025,1071,1582,33,10,35,1030,11,1551,1583,1583,1583,1024,0,5,0,1583,513]

theorem envBound4828 : H12AffineFastState.Bounded env4828 := by
  intro p hp
  have h : env4828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4827_4828 : H12AffineEnvironment.transform 12 1062 env4827 = env4828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env4827 == env4828) = true)

theorem identity4828 : scanCanonicalize (H12AffineFastState.compose env4828 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4828 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4829 : List Nat := [2,4,6,5,32,5,39,4,512,1024,1536,1569,1062,1568,1057,1027,1568,1568,1025,1057,1568,33,4,35,1030,5,1537,1569,1569,1569,1024,0,5,0,1569,513]

theorem envBound4829 : H12AffineFastState.Bounded env4829 := by
  intro p hp
  have h : env4829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4828_4829 : H12AffineEnvironment.transform 2 6 env4828 = env4829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4828 == env4829) = true)

def env4830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98474,8388608,41002,8329,8388608,323713,16385,16813,22561,74795,8483222,257,20480,8479126,8389564]

theorem envBound4830 : H12AffineFastState.Bounded env4830 := by
  intro p hp
  have h : env4830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4798_4830 : H12AffineEnvironment.transform 5 17 env4798 = env4830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4798 == env4830) = true)

theorem identity4830 : scanCanonicalize (H12AffineFastState.compose env4830 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4830 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4831 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98474,444,41002,8329,444,323713,16385,16813,22561,74795,94250,257,20480,90154,512]

theorem envBound4831 : H12AffineFastState.Bounded env4831 := by
  intro p hp
  have h : env4831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4830_4831 : H12AffineEnvironment.transform 22 444 env4830 = env4831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4830 == env4831) = true)

theorem identity4831 : scanCanonicalize (H12AffineFastState.compose env4831 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4831 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4832 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1025,32768,4097,41348,444,41002,8329,444,323713,16385,16813,22561,1285,20740,257,20480,16644,512]

theorem envBound4832 : H12AffineFastState.Bounded env4832 := by
  intro p hp
  have h : env4832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4831_4832 : H12AffineEnvironment.transform 15 8494 env4831 = env4832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4831 == env4832) = true)

theorem identity4832 : scanCanonicalize (H12AffineFastState.compose env4832 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4832 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4833 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13973,8494,4525,262144,1025,13973,4097,5905,444,5823,8329,444,280084,16385,16813,22561,1285,20740,257,20480,16644,512]

theorem envBound4833 : H12AffineFastState.Bounded env4833 := by
  intro p hp
  have h : env4833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4832_4833 : H12AffineEnvironment.transform 14 13973 env4832 = env4833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4832 == env4833) = true)

theorem identity4833 : scanCanonicalize (H12AffineFastState.compose env4833 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound4833 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4834 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,262144,1025,13973,4097,5905,444,5823,8329,444,268217,4524,4096,2444,1285,169,257,429,4265,512]

theorem envBound4834 : H12AffineFastState.Bounded env4834 := by
  intro p hp
  have h : env4834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4833_4834 : H12AffineEnvironment.transform 13 4525 env4833 = env4834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env4833 == env4834) = true)

theorem identity4834 : scanCanonicalize (H12AffineFastState.compose env4834 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound4834 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4835 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,7869,1025,13973,4097,5905,444,5823,8329,444,2308,4524,4096,2444,1285,169,257,429,4265,512]

theorem envBound4835 : H12AffineFastState.Bounded env4835 := by
  intro p hp
  have h : env4835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4834_4835 : H12AffineEnvironment.transform 17 7869 env4834 = env4835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env4834 == env4835) = true)

theorem identity4835 : scanCanonicalize (H12AffineFastState.compose env4835 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4835 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1840,8192,1693,8613,8494,1693,2445,1025,8613,1841,33,444,399,8329,444,2308,1692,1840,2444,1285,169,257,429,1945,512]

theorem envBound4836 : H12AffineFastState.Bounded env4836 := by
  intro p hp
  have h : env4836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4835_4836 : H12AffineEnvironment.transform 11 1840 env4835 = env4836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env4835 == env4836) = true)

theorem identity4836 : scanCanonicalize (H12AffineFastState.compose env4836 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4836 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4837 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1588,8192,1693,8353,8234,1693,2185,1025,8353,1589,33,184,139,8329,184,2048,1692,1588,2184,1025,169,5,169,1693,512]

theorem envBound4837 : H12AffineFastState.Bounded env4837 := by
  intro p hp
  have h : env4837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4836_4837 : H12AffineEnvironment.transform 7 4 env4836 = env4837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4836 == env4837) = true)

theorem identity4837 : scanCanonicalize (H12AffineFastState.compose env4837 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2746) := by decide +kernel

theorem selectedBound4837 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4838 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1588,2746,1693,2587,2704,1693,2185,1025,2587,1589,33,184,139,2611,184,2048,1692,1588,2184,1025,169,5,169,1693,512]

theorem envBound4838 : H12AffineFastState.Bounded env4838 := by
  intro p hp
  have h : env4838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4837_4838 : H12AffineEnvironment.transform 12 2746 env4837 = env4838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2746 env4837 == env4838) = true)

theorem identity4838 : scanCanonicalize (H12AffineFastState.compose env4838 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound4838 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4839 : List Nat := [2,4,8,16,32,17,128,4,512,21,2048,545,2746,648,2587,2704,648,2185,20,2587,544,33,184,139,2611,184,2048,649,545,2184,20,169,5,169,648,512]

theorem envBound4839 : H12AffineFastState.Bounded env4839 := by
  intro p hp
  have h : env4839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4838_4839 : H12AffineEnvironment.transform 9 21 env4838 = env4839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env4838 == env4839) = true)

def env4840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,268435456,268435964,134523041,75572347,147588588,525568,134520960,34359738368,8914925]

theorem envBound4840 : H12AffineFastState.Bounded env4840 := by
  intro p hp
  have h : env4840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2952_4840 : H12AffineEnvironment.transform 16 4605 env2952 = env4840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4605 env2952 == env4840) = true)

theorem identity4840 : scanCanonicalize (H12AffineFastState.compose env4840 (packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 82355409) := by decide +kernel

theorem selectedBound4840 : packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env4841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,268435456,268435964,134523041,75572347,147588588,525568,134520960,82355409,8914925]

theorem envBound4841 : H12AffineFastState.Bounded env4841 := by
  intro p hp
  have h : env4841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4840_4841 : H12AffineEnvironment.transform 34 82355409 env4840 = env4841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 82355409 env4840 == env4841) = true)

def env4842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,76039248,76039596,134523041,75572347,147588588,525568,134520960,82355409,8914925]

theorem envBound4842 : H12AffineFastState.Bounded env4842 := by
  intro p hp
  have h : env4842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4841_4842 : H12AffineEnvironment.transform 27 76039248 env4841 = env4842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 76039248 env4841 == env4842) = true)

def env4843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,77914240,76039248,76039596,77613089,75572347,73983340,525568,77611008,82355409,8914925]

theorem envBound4843 : H12AffineFastState.Bounded env4843 := by
  intro p hp
  have h : env4843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4842_4843 : H12AffineEnvironment.transform 26 77914240 env4842 = env4843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914240 env4842 == env4843) = true)

def env4844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914000,2942160,16384,16892,2641009,598059,14737724,525568,2638928,6332545,8914925]

theorem envBound4844 : H12AffineFastState.Bounded env4844 := by
  intro p hp
  have h : env4844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4843_4844 : H12AffineEnvironment.transform 25 8914000 env4843 = env4844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env4843 == env4844) = true)

def env4845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849104,16384,16892,547953,598059,12644668,525568,545872,4239489,8914925]

theorem envBound4845 : H12AffineFastState.Bounded env4845 := by
  intro p hp
  have h : env4845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4844_4845 : H12AffineEnvironment.transform 20 4096 env4844 = env4845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env4844 == env4845) = true)

def env4846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323792,16384,16892,22641,74795,12644668,256,20560,4239489,8389613]

theorem envBound4846 : H12AffineFastState.Bounded env4846 := by
  intro p hp
  have h : env4846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4845_4846 : H12AffineEnvironment.transform 18 1024 env4845 = env4846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4845 == env4846) = true)

theorem identity4846 : scanCanonicalize (H12AffineFastState.compose env4846 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5456) := by decide +kernel

theorem selectedBound4846 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,5456,41003,8329,5376,323792,16384,16892,22641,74795,4252780,256,20560,4239489,5821]

theorem envBound4847 : H12AffineFastState.Bounded env4847 := by
  intro p hp
  have h : env4847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4846_4847 : H12AffineEnvironment.transform 22 5456 env4846 = env4847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5456 env4846 == env4847) = true)

def env4848 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,5376,41003,8329,5376,323712,16384,16812,22561,74795,4252732,256,20480,4239489,5821]

theorem envBound4848 : H12AffineFastState.Bounded env4848 := by
  intro p hp
  have h : env4848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4847_4848 : H12AffineEnvironment.transform 5 16 env4847 = env4848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4847 == env4848) = true)

theorem identity4848 : scanCanonicalize (H12AffineFastState.compose env4848 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound4848 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4849 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,445,41003,8329,445,320573,16384,16812,19612,74795,4252732,256,17597,4236348,512]

theorem envBound4849 : H12AffineFastState.Bounded env4849 := by
  intro p hp
  have h : env4849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4848_4849 : H12AffineEnvironment.transform 11 1213 env4848 = env4849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env4848 == env4849) = true)

theorem identity4849 : scanCanonicalize (H12AffineFastState.compose env4849 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4849 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4850 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,41349,445,41003,8329,445,320573,16384,16812,19612,74795,17849,256,17597,1465,512]

theorem envBound4850 : H12AffineFastState.Bounded env4850 := by
  intro p hp
  have h : env4850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4849_4850 : H12AffineEnvironment.transform 21 41349 env4849 = env4850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4849 == env4850) = true)

theorem identity4850 : scanCanonicalize (H12AffineFastState.compose env4850 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound4850 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4851 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1024,26261,1213,18192,445,18110,8329,445,262824,16384,16812,19612,74795,17849,256,17597,1465,512]

theorem envBound4851 : H12AffineFastState.Bounded env4851 := by
  intro p hp
  have h : env4851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4850_4851 : H12AffineEnvironment.transform 14 26261 env4850 = env4851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env4850 == env4851) = true)

theorem identity4851 : scanCanonicalize (H12AffineFastState.compose env4851 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound4851 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25662,1296,262144,1024,26261,1213,18192,445,18110,8329,445,262824,16384,16812,19612,16405,17849,256,17597,1465,512]

theorem envBound4852 : H12AffineFastState.Bounded env4852 := by
  intro p hp
  have h : env4852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4851_4852 : H12AffineEnvironment.transform 15 25662 env4851 = env4852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env4851 == env4852) = true)

theorem identity4852 : scanCanonicalize (H12AffineFastState.compose env4852 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4852 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,1840,8613,8974,1296,262144,1024,8613,1213,32,445,398,8329,445,262824,1840,1692,2988,1829,649,256,909,1465,512]

theorem envBound4853 : H12AffineFastState.Bounded env4853 := by
  intro p hp
  have h : env4853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4852_4853 : H12AffineEnvironment.transform 13 1840 env4852 = env4853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env4852 == env4853) = true)

theorem identity4853 : scanCanonicalize (H12AffineFastState.compose env4853 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4853 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4854 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8200,8867,1213,262144,1024,8200,1213,32,16,35,8329,16,262824,1693,1692,2561,1672,649,173,544,1044,512]

theorem envBound4854 : H12AffineFastState.Bounded env4854 := by
  intro p hp
  have h : env4854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4853_4854 : H12AffineEnvironment.transform 7 173 env4853 = env4854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4853 == env4854) = true)

theorem identity4854 : scanCanonicalize (H12AffineFastState.compose env4854 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4854 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4855 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8200,8867,1213,1582,1024,8200,1213,32,16,35,8329,16,1158,1693,1692,2561,1672,649,173,544,1044,512]

theorem envBound4855 : H12AffineFastState.Bounded env4855 := by
  intro p hp
  have h : env4855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4854_4855 : H12AffineEnvironment.transform 17 1582 env4854 = env4855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env4854 == env4855) = true)

def env4856 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,5377,41003,8329,5376,323713,16384,16813,22560,74795,4252733,256,20481,4239489,5821]

theorem envBound4856 : H12AffineFastState.Bounded env4856 := by
  intro p hp
  have h : env4856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4847_4856 : H12AffineEnvironment.transform 5 17 env4847 = env4856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4847 == env4856) = true)

def env4857 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41260,5377,41003,8329,5376,323713,16384,16813,22560,74795,17681,256,20481,4525,5821]

theorem envBound4857 : H12AffineFastState.Bounded env4857 := by
  intro p hp
  have h : env4857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4856_4857 : H12AffineEnvironment.transform 21 41260 env4856 = env4857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env4856 == env4857) = true)

theorem identity4857 : scanCanonicalize (H12AffineFastState.compose env4857 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound4857 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env4858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4096,41260,5377,41003,8329,5376,323713,16384,16813,22560,16825,17681,256,20481,4525,5821]

theorem envBound4858 : H12AffineFastState.Bounded env4858 := by
  intro p hp
  have h : env4858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4857_4858 : H12AffineEnvironment.transform 15 26002 env4857 = env4858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env4857 == env4858) = true)

def env4859 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,16384,32768,26002,1212,262144,1024,32768,1296,41260,17,41003,8329,16,320913,16384,16813,19760,16825,17681,256,17681,1213,941]

theorem envBound4859 : H12AffineFastState.Bounded env4859 := by
  intro p hp
  have h : env4859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4858_4859 : H12AffineEnvironment.transform 11 1296 env4858 = env4859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env4858 == env4859) = true)

theorem identity4859 : scanCanonicalize (H12AffineFastState.compose env4859 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4859 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4860 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,16384,32768,25750,1212,262144,1024,32768,1044,41000,17,41003,8329,16,320661,16384,16553,19508,16573,17429,4,17429,1213,681]

theorem envBound4860 : H12AffineFastState.Bounded env4860 := by
  intro p hp
  have h : env4860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4859_4860 : H12AffineEnvironment.transform 7 4 env4859 = env4860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4859 == env4860) = true)

theorem identity4860 : scanCanonicalize (H12AffineFastState.compose env4860 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4860 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env4861 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1589,32768,8867,1212,262144,1024,32768,1044,41000,17,41003,8329,16,303776,1589,1692,2561,1672,544,4,544,1213,681]

theorem envBound4861 : H12AffineFastState.Bounded env4861 := by
  intro p hp
  have h : env4861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4860_4861 : H12AffineEnvironment.transform 13 1589 env4860 = env4861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1589 env4860 == env4861) = true)

theorem identity4861 : scanCanonicalize (H12AffineFastState.compose env4861 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound4861 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env4862 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1589,8353,8867,1212,262144,1024,8353,1044,137,17,138,8329,16,262657,1589,1692,2561,1672,544,4,544,1213,681]

theorem envBound4862 : H12AffineFastState.Bounded env4862 := by
  intro p hp
  have h : env4862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4861_4862 : H12AffineEnvironment.transform 14 8353 env4861 = env4862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env4861 == env4862) = true)

theorem identity4862 : scanCanonicalize (H12AffineFastState.compose env4862 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound4862 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4863 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,8192,1589,8353,8867,1212,2560,1024,8353,1044,137,17,138,8329,16,2049,1589,1692,2561,1672,544,4,544,1213,681]

theorem envBound4863 : H12AffineFastState.Bounded env4863 := by
  intro p hp
  have h : env4863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4862_4863 : H12AffineEnvironment.transform 17 2560 env4862 = env4863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env4862 == env4863) = true)

theorem identity4863 : scanCanonicalize (H12AffineFastState.compose env4863 (packedSelected [0,2,7,13] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound4863 : packedSelected [0,2,7,13] rootPS < 2^1333 := by decide +kernel

def env4864 : List Nat := [2,4,8,16,32,17,128,4,512,701,2048,681,8192,136,8353,8867,513,2560,701,8353,681,137,17,138,8329,16,2049,136,33,2561,53,544,4,544,512,681]

theorem envBound4864 : H12AffineFastState.Bounded env4864 := by
  intro p hp
  have h : env4864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4863_4864 : H12AffineEnvironment.transform 9 701 env4863 = env4864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env4863 == env4864) = true)

theorem identity4864 : scanCanonicalize (H12AffineFastState.compose env4864 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound4864 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4865 : List Nat := [2,4,8,16,32,17,128,4,512,701,2048,681,553,136,648,138,513,2560,701,648,681,137,17,138,672,16,2049,136,33,2561,53,544,4,544,512,681]

theorem envBound4865 : H12AffineFastState.Bounded env4865 := by
  intro p hp
  have h : env4865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4864_4865 : H12AffineEnvironment.transform 12 553 env4864 = env4865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env4864 == env4865) = true)

def env4866 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,16384,32768,26002,1213,262144,1024,32768,1297,41260,16,41003,8329,17,320912,16384,16813,19761,16825,17681,256,17680,1212,940]

theorem envBound4866 : H12AffineFastState.Bounded env4866 := by
  intro p hp
  have h : env4866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4858_4866 : H12AffineEnvironment.transform 11 1297 env4858 = env4866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4858 == env4866) = true)

theorem identity4866 : scanCanonicalize (H12AffineFastState.compose env4866 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4866 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4867 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,25915,1044,262144,1024,32768,1297,41260,16,41003,8224,17,320825,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound4867 : H12AffineFastState.Bounded env4867 := by
  intro p hp
  have h : env4867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4866_4867 : H12AffineEnvironment.transform 6 41 env4866 = env4867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4866 == env4867) = true)

theorem identity4867 : scanCanonicalize (H12AffineFastState.compose env4867 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 57622) := by decide +kernel

theorem selectedBound4867 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4868 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,25915,1044,57622,1024,32768,1297,41260,16,41003,8224,17,1071,16384,16644,19761,16656,17681,256,17680,1045,773]

theorem envBound4868 : H12AffineFastState.Bounded env4868 := by
  intro p hp
  have h : env4868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4867_4868 : H12AffineEnvironment.transform 17 57622 env4867 = env4868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 57622 env4867 == env4868) = true)

theorem identity4868 : scanCanonicalize (H12AffineFastState.compose env4868 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8210) := by decide +kernel

theorem selectedBound4868 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env4869 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,8210,32768,1321,1044,33028,1024,32768,1297,41260,16,41003,8224,17,1071,8210,8470,11555,8450,9475,256,9474,1045,773]

theorem envBound4869 : H12AffineFastState.Bounded env4869 := by
  intro p hp
  have h : env4869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4868_4869 : H12AffineEnvironment.transform 13 8210 env4868 = env4869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8210 env4868 == env4869) = true)

theorem identity4869 : scanCanonicalize (H12AffineFastState.compose env4869 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4869 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4870 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,8192,8210,32768,1068,1044,32769,1024,32768,1044,41001,16,41003,8224,17,1071,8210,8211,11302,8199,9222,5,9223,1045,512]

theorem envBound4870 : H12AffineFastState.Bounded env4870 := by
  intro p hp
  have h : env4870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4869_4870 : H12AffineEnvironment.transform 7 5 env4869 = env4870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4869 == env4870) = true)

theorem identity4870 : scanCanonicalize (H12AffineFastState.compose env4870 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4870 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env4871 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,8192,8210,1071,1068,1044,1070,1024,1071,1044,9222,16,9220,8224,17,1071,8210,8211,11302,8199,9222,5,9223,1045,512]

theorem envBound4871 : H12AffineFastState.Bounded env4871 := by
  intro p hp
  have h : env4871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4870_4871 : H12AffineEnvironment.transform 14 1071 env4870 = env4871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env4870 == env4871) = true)

theorem identity4871 : scanCanonicalize (H12AffineFastState.compose env4871 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound4871 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4872 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1044,2088,2106,1071,1068,1044,1070,1024,1071,1044,3118,16,3116,2056,17,1071,2106,2107,1038,2095,3118,5,3119,1045,512]

theorem envBound4872 : H12AffineFastState.Bounded env4872 := by
  intro p hp
  have h : env4872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4871_4872 : H12AffineEnvironment.transform 12 2088 env4871 = env4872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env4871 == env4872) = true)

theorem identity4872 : scanCanonicalize (H12AffineFastState.compose env4872 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound4872 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env4873 : List Nat := [2,4,8,16,32,17,41,5,512,21,2048,1,2088,2106,58,57,1,59,21,58,1,2107,16,2105,2056,17,58,2106,2107,27,2095,2107,5,2106,0,512]

theorem envBound4873 : H12AffineFastState.Bounded env4873 := by
  intro p hp
  have h : env4873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4872_4873 : H12AffineEnvironment.transform 9 21 env4872 = env4873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env4872 == env4873) = true)

theorem identity4873 : scanCanonicalize (H12AffineFastState.compose env4873 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4873 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4874 : List Nat := [2,4,8,10,32,11,41,5,512,15,2048,1,2088,2080,32,35,1,33,15,32,1,2081,10,2083,2056,11,32,2080,2081,1,2095,2081,5,2080,0,512]

theorem envBound4874 : H12AffineFastState.Bounded env4874 := by
  intro p hp
  have h : env4874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4873_4874 : H12AffineEnvironment.transform 3 10 env4873 = env4874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4873 == env4874) = true)

theorem identity4874 : scanCanonicalize (H12AffineFastState.compose env4874 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound4874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4875 : List Nat := [2,4,8,10,32,11,41,5,512,15,0,1,40,32,32,35,1,33,15,32,1,33,10,35,8,11,32,32,33,1,47,33,5,32,0,512]

theorem envBound4875 : H12AffineFastState.Bounded env4875 := by
  intro p hp
  have h : env4875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4874_4875 : H12AffineEnvironment.transform 10 0 env4874 = env4875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env4874 == env4875) = true)

theorem identity4875 : scanCanonicalize (H12AffineFastState.compose env4875 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4876 : List Nat := [2,4,8,10,0,11,9,5,512,15,0,1,8,0,0,3,1,1,15,0,1,1,10,3,8,11,0,0,1,1,15,1,5,0,0,512]

theorem envBound4876 : H12AffineFastState.Bounded env4876 := by
  intro p hp
  have h : env4876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4875_4876 : H12AffineEnvironment.transform 4 0 env4875 = env4876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4875 == env4876) = true)

theorem identity4876 : scanCanonicalize (H12AffineFastState.compose env4876 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4876 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env4877 : List Nat := [2,4,8,10,0,11,9,5,1,15,0,1,8,0,0,3,1,1,15,0,1,1,10,3,8,11,0,0,1,1,15,1,5,0,0,1]

theorem envBound4877 : H12AffineFastState.Bounded env4877 := by
  intro p hp
  have h : env4877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4876_4877 : H12AffineEnvironment.transform 8 1 env4876 = env4877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4876 == env4877) = true)

def env4878 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41261,5377,41003,8329,5376,323713,16384,16813,22560,74795,17680,256,20481,4524,5821]

theorem envBound4878 : H12AffineFastState.Bounded env4878 := by
  intro p hp
  have h : env4878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4856_4878 : H12AffineEnvironment.transform 21 41261 env4856 = env4878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env4856 == env4878) = true)

theorem identity4878 : scanCanonicalize (H12AffineFastState.compose env4878 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4878 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env4879 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,41261,5377,41003,8224,5376,323624,16384,16644,22560,74795,17680,256,20481,4357,5652]

theorem envBound4879 : H12AffineFastState.Bounded env4879 := by
  intro p hp
  have h : env4879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4878_4879 : H12AffineEnvironment.transform 6 41 env4878 = env4879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4878 == env4879) = true)

def env4880 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,65536,1045,262144,1024,32768,1296,41261,17,41003,8224,16,320824,16384,16644,19760,74795,17680,256,17681,1045,772]

theorem envBound4880 : H12AffineFastState.Bounded env4880 := by
  intro p hp
  have h : env4880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4879_4880 : H12AffineEnvironment.transform 11 1296 env4879 = env4880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env4879 == env4880) = true)

def env4881 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1297,8192,16384,32768,65536,1044,262144,1024,32768,1297,41261,16,41003,8224,17,320825,16384,16644,19761,74795,17680,256,17680,1044,773]

theorem envBound4881 : H12AffineFastState.Bounded env4881 := by
  intro p hp
  have h : env4881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4879_4881 : H12AffineEnvironment.transform 11 1297 env4879 = env4881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4879 == env4881) = true)

theorem identity4881 : scanCanonicalize (H12AffineFastState.compose env4881 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4881 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4882 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41001,16,41003,8224,17,320573,16384,16384,19509,74795,17428,4,17428,1044,513]

theorem envBound4882 : H12AffineFastState.Bounded env4882 := by
  intro p hp
  have h : env4882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4881_4882 : H12AffineEnvironment.transform 7 4 env4881 = env4882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4881 == env4882) = true)

theorem identity4882 : scanCanonicalize (H12AffineFastState.compose env4882 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4882 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4883 : List Nat := [2,4,8,16,32,17,41,4,33,1024,2048,1045,8192,16384,32768,65536,1044,262144,1024,32768,1045,41001,16,41003,8224,17,320573,16384,16384,19509,74795,17428,4,17428,1044,32]

theorem envBound4883 : H12AffineFastState.Bounded env4883 := by
  intro p hp
  have h : env4883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4882_4883 : H12AffineEnvironment.transform 8 33 env4882 = env4883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4882 == env4883) = true)

theorem identity4883 : scanCanonicalize (H12AffineFastState.compose env4883 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25647) := by decide +kernel

theorem selectedBound4883 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4884 : List Nat := [2,4,8,16,32,17,41,4,33,1024,2048,1045,8192,16384,32768,25647,1044,262144,1024,32768,1045,41001,16,41003,8224,17,320573,16384,16384,19509,16388,17428,4,17428,1044,32]

theorem envBound4884 : H12AffineFastState.Bounded env4884 := by
  intro p hp
  have h : env4884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4883_4884 : H12AffineEnvironment.transform 15 25647 env4883 = env4884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25647 env4883 == env4884) = true)

theorem identity4884 : scanCanonicalize (H12AffineFastState.compose env4884 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound4884 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4885 : List Nat := [2,4,8,16,32,17,41,4,33,1024,2048,1045,8192,16384,8216,25647,1044,262144,1024,8216,1045,49,16,51,8224,17,279589,16384,16384,19509,16388,17428,4,17428,1044,32]

theorem envBound4885 : H12AffineFastState.Bounded env4885 := by
  intro p hp
  have h : env4885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4884_4885 : H12AffineEnvironment.transform 14 8216 env4884 = env4885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env4884 == env4885) = true)

theorem identity4885 : scanCanonicalize (H12AffineFastState.compose env4885 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 63) := by decide +kernel

theorem selectedBound4885 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4886 : List Nat := [2,4,8,16,32,17,41,4,33,1024,2048,1045,8192,16384,8216,25647,1044,63,1024,8216,1045,49,16,51,8224,17,17434,16384,16384,19509,16388,17428,4,17428,1044,32]

theorem envBound4886 : H12AffineFastState.Bounded env4886 := by
  intro p hp
  have h : env4886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4885_4886 : H12AffineEnvironment.transform 17 63 env4885 = env4886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63 env4885 == env4886) = true)

theorem identity4886 : scanCanonicalize (H12AffineFastState.compose env4886 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound4886 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4887 : List Nat := [2,4,8,16,32,17,41,4,33,1024,31,1045,8192,16384,8216,25647,1044,63,1024,8216,1045,49,16,51,8224,17,17434,16384,16384,17450,16388,17428,4,17428,1044,32]

theorem envBound4887 : H12AffineFastState.Bounded env4887 := by
  intro p hp
  have h : env4887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4886_4887 : H12AffineEnvironment.transform 10 31 env4886 = env4887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env4886 == env4887) = true)

theorem identity4887 : scanCanonicalize (H12AffineFastState.compose env4887 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound4887 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env4888 : List Nat := [2,4,8,16,32,17,41,4,33,0,31,21,8192,16384,8216,24623,20,63,0,8216,21,49,16,51,8224,17,16410,16384,16384,16426,16388,16404,4,16404,20,32]

theorem envBound4888 : H12AffineFastState.Bounded env4888 := by
  intro p hp
  have h : env4888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4887_4888 : H12AffineEnvironment.transform 9 0 env4887 = env4888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env4887 == env4888) = true)

theorem identity4888 : scanCanonicalize (H12AffineFastState.compose env4888 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4888 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4889 : List Nat := [2,4,8,1,32,0,41,4,33,0,14,4,8192,16384,8201,24623,5,46,0,8201,4,32,1,34,8224,0,16395,16384,16384,16426,16388,16389,4,16389,5,32]

theorem envBound4889 : H12AffineFastState.Bounded env4889 := by
  intro p hp
  have h : env4889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4888_4889 : H12AffineEnvironment.transform 3 1 env4888 = env4889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4888 == env4889) = true)

theorem identity4889 : scanCanonicalize (H12AffineFastState.compose env4889 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 8195) := by decide +kernel

theorem selectedBound4889 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4890 : List Nat := [2,4,8,1,32,0,41,4,33,0,14,4,8192,8195,8201,44,5,46,0,8201,4,32,1,34,8224,0,8200,8195,8195,8233,8199,8198,4,8198,5,32]

theorem envBound4890 : H12AffineFastState.Bounded env4890 := by
  intro p hp
  have h : env4890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4889_4890 : H12AffineEnvironment.transform 13 8195 env4889 = env4890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8195 env4889 == env4890) = true)

theorem identity4890 : scanCanonicalize (H12AffineFastState.compose env4890 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4891 : List Nat := [2,4,8,1,32,0,41,4,33,0,14,4,9,10,0,44,5,46,0,0,4,32,1,34,41,0,1,10,10,32,14,15,4,15,5,32]

theorem envBound4891 : H12AffineFastState.Bounded env4891 := by
  intro p hp
  have h : env4891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4890_4891 : H12AffineEnvironment.transform 12 9 env4890 = env4891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4890 == env4891) = true)

theorem identity4891 : scanCanonicalize (H12AffineFastState.compose env4891 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4891 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4892 : List Nat := [2,4,3,1,32,0,34,4,33,0,5,4,2,1,0,39,5,37,0,0,4,32,1,34,34,0,1,1,1,32,5,4,4,4,5,32]

theorem envBound4892 : H12AffineFastState.Bounded env4892 := by
  intro p hp
  have h : env4892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4891_4892 : H12AffineEnvironment.transform 2 3 env4891 = env4892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4891 == env4892) = true)

theorem identity4892 : scanCanonicalize (H12AffineFastState.compose env4892 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound4892 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4893 : List Nat := [2,4,3,1,5,0,7,4,4,0,5,4,2,1,0,2,5,0,0,0,4,5,1,7,7,0,1,1,1,5,5,4,4,4,5,5]

theorem envBound4893 : H12AffineFastState.Bounded env4893 := by
  intro p hp
  have h : env4893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4892_4893 : H12AffineEnvironment.transform 4 5 env4892 = env4893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env4892 == env4893) = true)

def leafEnv4893 : List Nat := [2,4,3,1,5,0,7,4,4,0,5,4,2,1,0,2,5,0,0,0,4,5,1,7,4,7,1,0,1,1,1,5,5,4,4,4,5,6,5,5,1,1,0]

def active4893 : List Nat := [0,1]

def tree4893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4893 : H12WitnessSearch.Good tree4893 := H12GlobalWitnessIndex.good

theorem leafIdentity4893 : H12AffineFastState.composeSystem env4893 rootObs = leafEnv4893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4893 rootObs == leafEnv4893) = true)

theorem terminalChecked4893 : H12PackedTerminal.terminalCheckFast leafEnv4893 active4893 tree4893 = true := by decide +kernel

def env4894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,12644668,257,20561,4239489,8389612]

theorem envBound4894 : H12AffineFastState.Bounded env4894 := by
  intro p hp
  have h : env4894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4845_4894 : H12AffineEnvironment.transform 18 1025 env4845 = env4894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4845 == env4894) = true)

theorem identity4894 : scanCanonicalize (H12AffineFastState.compose env4894 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound4894 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,303233,4176,4524,2080,74794,12624236,257,1,4239489,8389612]

theorem envBound4895 : H12AffineFastState.Bounded env4895 := by
  intro p hp
  have h : env4895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4894_4895 : H12AffineEnvironment.transform 13 4176 env4894 = env4895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env4894 == env4895) = true)

def env4896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,4194304,8388608,41003,8329,8388609,303233,4096,4524,2080,74794,12624188,257,1,4239489,8389564]

theorem envBound4896 : H12AffineFastState.Bounded env4896 := by
  intro p hp
  have h : env4896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4895_4896 : H12AffineEnvironment.transform 5 16 env4895 = env4896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4895 == env4896) = true)

def env4897 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,43136,1025,32768,4096,4194304,8388608,41003,8329,8388609,2049,4096,4524,2080,74794,12624188,257,1,4239489,8389564]

theorem envBound4897 : H12AffineFastState.Bounded env4897 := by
  intro p hp
  have h : env4897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4896_4897 : H12AffineEnvironment.transform 17 43136 env4896 = env4897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env4896 == env4897) = true)

theorem identity4897 : scanCanonicalize (H12AffineFastState.compose env4897 (packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound4897 : packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env4898 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8353,65536,4525,2081,1025,8353,4096,4194304,8388608,138,8329,8388609,2049,4096,4524,2080,74794,12583325,257,1,4198432,8389564]

theorem envBound4898 : H12AffineFastState.Bounded env4898 := by
  intro p hp
  have h : env4898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4897_4898 : H12AffineEnvironment.transform 14 8353 env4897 = env4898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env4897 == env4898) = true)

theorem identity4898 : scanCanonicalize (H12AffineFastState.compose env4898 (packedSelected [0,1,5,7,8,9,10,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound4898 : packedSelected [0,1,5,7,8,9,10,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env4899 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8353,8235,4525,2081,1025,8353,4096,4194304,8388608,138,8329,8388609,2049,4096,4524,2080,1025,12583325,257,1,4198432,8389564]

theorem envBound4899 : H12AffineFastState.Bounded env4899 := by
  intro p hp
  have h : env4899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4898_4899 : H12AffineEnvironment.transform 15 8235 env4898 = env4899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env4898 == env4899) = true)

theorem identity4899 : scanCanonicalize (H12AffineFastState.compose env4899 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 4194457) := by decide +kernel

theorem selectedBound4899 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4900 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8353,8235,4525,2081,1025,8353,4096,4194304,4194457,138,8329,4194456,2049,4096,4524,2080,1025,260,257,1,4198432,4195109]

theorem envBound4900 : H12AffineFastState.Bounded env4900 := by
  intro p hp
  have h : env4900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4899_4900 : H12AffineEnvironment.transform 22 4194457 env4899 = env4900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194457 env4899 == env4900) = true)

theorem identity4900 : scanCanonicalize (H12AffineFastState.compose env4900 (packedSelected [2,3,4,5,6,9,10,13,20] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound4900 : packedSelected [2,3,4,5,6,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env4901 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2367,8192,2367,8353,8235,2194,2081,1025,8353,2367,4194304,4194457,138,8329,4194456,2049,2367,2195,2080,1025,260,257,1,4196639,4195109]

theorem envBound4901 : H12AffineFastState.Bounded env4901 := by
  intro p hp
  have h : env4901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4900_4901 : H12AffineEnvironment.transform 11 2367 env4900 = env4901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env4900 == env4901) = true)

theorem identity4901 : scanCanonicalize (H12AffineFastState.compose env4901 (packedSelected [0,1,7,8,10,12,13,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4901 : packedSelected [0,1,7,8,10,12,13,17,23] rootPS < 2^1333 := by decide +kernel

def env4902 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,2106,8192,2106,8353,8235,2194,2081,1025,8353,2106,4194304,4194457,138,8329,4194456,2049,2106,2195,2080,1025,1,4,1,4196378,4194848]

theorem envBound4902 : H12AffineFastState.Bounded env4902 := by
  intro p hp
  have h : env4902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4901_4902 : H12AffineEnvironment.transform 7 5 env4901 = env4902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4901 == env4902) = true)

theorem identity4902 : scanCanonicalize (H12AffineFastState.compose env4902 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4902 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4903 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,2106,8192,2106,8200,8235,2107,2081,1025,8200,2106,4194304,4194352,35,8224,4194353,2049,2106,2106,2080,1025,1,4,1,4196378,4194848]

theorem envBound4903 : H12AffineFastState.Bounded env4903 := by
  intro p hp
  have h : env4903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4902_4903 : H12AffineEnvironment.transform 6 41 env4902 = env4903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4902 == env4903) = true)

theorem identity4903 : scanCanonicalize (H12AffineFastState.compose env4903 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound4903 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4904 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,2106,2601,2106,2593,2562,2107,2081,1025,2593,2106,4194304,4194352,35,2569,4194353,2049,2106,2106,2080,1025,1,4,1,4196378,4194848]

theorem envBound4904 : H12AffineFastState.Bounded env4904 := by
  intro p hp
  have h : env4904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4903_4904 : H12AffineEnvironment.transform 12 2601 env4903 = env4904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env4903 == env4904) = true)

theorem identity4904 : scanCanonicalize (H12AffineFastState.compose env4904 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4904 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env4905 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1588,1063,1588,1071,1036,1589,1583,1025,1071,1588,4194304,4194352,35,1031,4194353,1551,1588,1588,1582,1025,1,4,1,4195860,4194848]

theorem envBound4905 : H12AffineFastState.Bounded env4905 := by
  intro p hp
  have h : env4905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4904_4905 : H12AffineEnvironment.transform 10 1550 env4904 = env4905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4904 == env4905) = true)

theorem identity4905 : scanCanonicalize (H12AffineFastState.compose env4905 (packedSelected [2,11] rootPS)) = affineNative (2^(21+1) ^^^ 544) := by decide +kernel

theorem selectedBound4905 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env4906 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1550,1588,1063,1588,1071,1036,1589,1583,1025,1071,1588,544,528,35,1031,529,1551,1588,1588,1582,1025,1,4,1,1076,0]

theorem envBound4906 : H12AffineFastState.Bounded env4906 := by
  intro p hp
  have h : env4906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4905_4906 : H12AffineEnvironment.transform 21 544 env4905 = env4906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 544 env4905 == env4906) = true)

theorem identity4906 : scanCanonicalize (H12AffineFastState.compose env4906 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound4906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4907 : List Nat := [2,4,8,16,32,16,41,5,512,53,571,513,18,513,26,57,512,538,52,26,513,544,528,35,50,529,570,513,513,539,52,1,4,1,1,0]

theorem envBound4907 : H12AffineFastState.Bounded env4907 := by
  intro p hp
  have h : env4907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4906_4907 : H12AffineEnvironment.transform 9 53 env4906 = env4907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env4906 == env4907) = true)

def env4908 : List Nat := [2,4,8,16,32,16,41,5,0,53,59,1,18,1,26,57,0,26,52,26,1,32,16,35,50,17,58,1,1,27,52,1,4,1,1,0]

theorem envBound4908 : H12AffineFastState.Bounded env4908 := by
  intro p hp
  have h : env4908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4907_4908 : H12AffineEnvironment.transform 8 0 env4907 = env4908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4907 == env4908) = true)

theorem identity4908 : scanCanonicalize (H12AffineFastState.compose env4908 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4909 : List Nat := [2,4,8,16,26,16,19,5,0,15,1,1,18,1,26,3,0,26,14,26,1,26,16,25,8,17,0,1,1,27,14,1,4,1,1,0]

theorem envBound4909 : H12AffineFastState.Bounded env4909 := by
  intro p hp
  have h : env4909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4908_4909 : H12AffineEnvironment.transform 4 26 env4908 = env4909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4908 == env4909) = true)

def env4910 : List Nat := [2,4,8,16,32,16,41,5,1,53,58,0,18,0,26,57,1,27,52,26,0,33,17,35,50,16,59,0,0,26,52,1,4,1,1,0]

theorem envBound4910 : H12AffineFastState.Bounded env4910 := by
  intro p hp
  have h : env4910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4907_4910 : H12AffineEnvironment.transform 8 1 env4907 = env4910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4907 == env4910) = true)

theorem identity4910 : scanCanonicalize (H12AffineFastState.compose env4910 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4911 : List Nat := [2,4,6,16,32,16,39,5,1,53,52,0,18,0,20,55,1,21,52,20,0,33,17,35,50,16,53,0,0,20,52,1,4,1,1,0]

theorem envBound4911 : H12AffineFastState.Bounded env4911 := by
  intro p hp
  have h : env4911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4910_4911 : H12AffineEnvironment.transform 2 6 env4910 = env4911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4910 == env4911) = true)

theorem identity4911 : scanCanonicalize (H12AffineFastState.compose env4911 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound4911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4912 : List Nat := [2,4,6,4,32,4,39,5,1,33,32,0,6,0,0,35,1,1,32,0,0,33,5,35,38,4,33,0,0,0,32,1,4,1,1,0]

theorem envBound4912 : H12AffineFastState.Bounded env4912 := by
  intro p hp
  have h : env4912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4911_4912 : H12AffineEnvironment.transform 3 4 env4911 = env4912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4911 == env4912) = true)

theorem identity4912 : scanCanonicalize (H12AffineFastState.compose env4912 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4912 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4913 : List Nat := [2,0,2,0,32,0,35,1,1,33,32,0,2,0,0,35,1,1,32,0,0,33,1,35,34,0,33,0,0,0,32,1,0,1,1,0]

theorem envBound4913 : H12AffineFastState.Bounded env4913 := by
  intro p hp
  have h : env4913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4912_4913 : H12AffineEnvironment.transform 1 0 env4912 = env4913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4912 == env4913) = true)

def leafEnv4913 : List Nat := [2,0,2,0,32,0,35,1,1,33,32,0,2,0,0,35,1,1,32,0,0,33,1,35,33,34,1,0,33,0,0,0,32,1,0,1,1,3,1,0,1,1,0]

def active4913 : List Nat := [0,4]

def tree4913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4913 : H12WitnessSearch.Good tree4913 := H12GlobalWitnessIndex.good

theorem leafIdentity4913 : H12AffineFastState.composeSystem env4913 rootObs = leafEnv4913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4913 rootObs == leafEnv4913) = true)

theorem terminalChecked4913 : H12PackedTerminal.terminalCheckFast leafEnv4913 active4913 tree4913 = true := by decide +kernel

def env4914 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,43137,1025,32768,4096,4194304,8388608,41003,8329,8388609,2048,4096,4524,2080,74794,12624188,257,1,4239489,8389564]

theorem envBound4914 : H12AffineFastState.Bounded env4914 := by
  intro p hp
  have h : env4914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4896_4914 : H12AffineEnvironment.transform 17 43137 env4896 = env4914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env4896 == env4914) = true)

theorem identity4914 : scanCanonicalize (H12AffineFastState.compose env4914 (packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound4914 : packedSelected [0,1,4,5,8,13,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env4915 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4525,43137,1025,32768,4096,4194304,8388608,41003,8329,8388609,2048,4096,4524,2080,1193,12624188,257,1,4239489,8389564]

theorem envBound4915 : H12AffineFastState.Bounded env4915 := by
  intro p hp
  have h : env4915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4914_4915 : H12AffineEnvironment.transform 15 8323 env4914 = env4915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env4914 == env4915) = true)

theorem identity4915 : scanCanonicalize (H12AffineFastState.compose env4915 (packedSelected [0,1,4,5,7,8,9,18,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 46873) := by decide +kernel

theorem selectedBound4915 : packedSelected [0,1,4,5,7,8,9,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4916 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,8323,4525,43137,1025,32768,4096,46873,8388608,41003,8329,8388609,2048,4096,4524,2080,1193,8394277,257,1,1944,8389564]

theorem envBound4916 : H12AffineFastState.Bounded env4916 := by
  intro p hp
  have h : env4916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4915_4916 : H12AffineEnvironment.transform 21 46873 env4915 = env4916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46873 env4915 == env4916) = true)

theorem identity4916 : scanCanonicalize (H12AffineFastState.compose env4916 (packedSelected [3,4,5,8,20,22,28] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4916 : packedSelected [3,4,5,8,20,22,28] rootPS < 2^1333 := by decide +kernel

def env4917 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1841,32768,8323,1692,43137,1025,32768,1841,41000,8388608,41003,8329,8388609,2048,1841,1693,2080,1193,8388884,257,1,1944,8389564]

theorem envBound4917 : H12AffineFastState.Bounded env4917 := by
  intro p hp
  have h : env4917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4916_4917 : H12AffineEnvironment.transform 11 1841 env4916 = env4917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4916 == env4917) = true)

theorem identity4917 : scanCanonicalize (H12AffineFastState.compose env4917 (packedSelected [0,4,7,9,17,21] rootPS)) = affineNative (2^(22+1) ^^^ 276) := by decide +kernel

theorem selectedBound4917 : packedSelected [0,4,7,9,17,21] rootPS < 2^1333 := by decide +kernel

def env4918 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1841,32768,8323,1692,43137,1025,32768,1841,41000,276,41003,8329,277,2048,1841,1693,2080,1193,0,257,1,1944,680]

theorem envBound4918 : H12AffineFastState.Bounded env4918 := by
  intro p hp
  have h : env4918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4917_4918 : H12AffineEnvironment.transform 22 276 env4917 = env4918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 276 env4917 == env4918) = true)

theorem identity4918 : scanCanonicalize (H12AffineFastState.compose env4918 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4918 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4919 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1588,8192,1588,32768,8323,1692,43137,1025,32768,1588,41000,17,41003,8329,16,2048,1588,1693,2080,1193,0,4,1,1693,680]

theorem envBound4919 : H12AffineFastState.Bounded env4919 := by
  intro p hp
  have h : env4919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4918_4919 : H12AffineEnvironment.transform 7 5 env4918 = env4919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4918 == env4919) = true)

theorem identity4919 : scanCanonicalize (H12AffineFastState.compose env4919 (packedSelected [3,8,10,15] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound4919 : packedSelected [3,8,10,15] rootPS < 2^1333 := by decide +kernel

def env4920 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1588,8192,1588,33,8323,1692,10400,1025,33,1588,8201,17,8202,8329,16,2048,1588,1693,2080,1193,0,4,1,1693,680]

theorem envBound4920 : H12AffineFastState.Bounded env4920 := by
  intro p hp
  have h : env4920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4919_4920 : H12AffineEnvironment.transform 14 33 env4919 = env4920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env4919 == env4920) = true)

theorem identity4920 : scanCanonicalize (H12AffineFastState.compose env4920 (packedSelected [2,6,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 3590) := by decide +kernel

theorem selectedBound4920 : packedSelected [2,6,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4921 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1588,3590,1588,33,3717,1692,1702,1025,33,1588,3599,17,3596,3727,16,2048,1588,1693,2080,1193,0,4,1,1693,680]

theorem envBound4921 : H12AffineFastState.Bounded env4921 := by
  intro p hp
  have h : env4921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4920_4921 : H12AffineEnvironment.transform 12 3590 env4920 = env4921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3590 env4920 == env4921) = true)

theorem identity4921 : scanCanonicalize (H12AffineFastState.compose env4921 (packedSelected [2,5,6,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4921 : packedSelected [2,5,6,8,12,17] rootPS < 2^1333 := by decide +kernel

def env4922 : List Nat := [2,4,8,16,32,16,128,5,512,1024,1693,1588,155,1588,33,24,1692,1702,1025,33,1588,146,17,145,18,16,1693,1588,1693,1725,1193,0,4,1,1693,680]

theorem envBound4922 : H12AffineFastState.Bounded env4922 := by
  intro p hp
  have h : env4922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4921_4922 : H12AffineEnvironment.transform 10 1693 env4921 = env4922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1693 env4921 == env4922) = true)

theorem identity4922 : scanCanonicalize (H12AffineFastState.compose env4922 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4922 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4923 : List Nat := [2,4,8,10,32,10,128,5,512,1024,1671,1582,129,1582,33,2,1670,1702,1025,33,1582,136,11,139,8,10,1671,1582,1671,1703,1193,0,4,1,1671,680]

theorem envBound4923 : H12AffineFastState.Bounded env4923 := by
  intro p hp
  have h : env4923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4922_4923 : H12AffineEnvironment.transform 3 10 env4922 = env4923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4922 == env4923) = true)

theorem identity4923 : scanCanonicalize (H12AffineFastState.compose env4923 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4923 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env4924 : List Nat := [2,4,8,10,32,10,128,5,32,1024,1191,1038,129,1038,33,2,1190,1158,1025,33,1038,136,11,139,8,10,1191,1038,1191,1159,1193,0,4,1,1191,136]

theorem envBound4924 : H12AffineFastState.Bounded env4924 := by
  intro p hp
  have h : env4924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4923_4924 : H12AffineEnvironment.transform 8 32 env4923 = env4924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4923 == env4924) = true)

theorem identity4924 : scanCanonicalize (H12AffineFastState.compose env4924 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound4924 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4925 : List Nat := [2,4,8,10,32,10,128,5,32,14,169,0,129,0,33,2,168,136,15,33,0,136,11,139,8,10,169,0,169,137,167,0,4,1,169,136]

theorem envBound4925 : H12AffineFastState.Bounded env4925 := by
  intro p hp
  have h : env4925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4924_4925 : H12AffineEnvironment.transform 9 14 env4924 = env4925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env4924 == env4925) = true)

theorem identity4925 : scanCanonicalize (H12AffineFastState.compose env4925 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound4925 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4926 : List Nat := [2,4,8,10,32,10,2,5,32,14,43,0,3,0,33,2,42,10,15,33,0,10,11,9,8,10,43,0,43,11,37,0,4,1,43,10]

theorem envBound4926 : H12AffineFastState.Bounded env4926 := by
  intro p hp
  have h : env4926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4925_4926 : H12AffineEnvironment.transform 6 2 env4925 = env4926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env4925 == env4926) = true)

theorem identity4926 : scanCanonicalize (H12AffineFastState.compose env4926 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4927 : List Nat := [2,4,2,0,32,0,2,5,32,4,33,0,3,0,33,2,32,0,5,33,0,0,1,3,2,0,33,0,33,1,37,0,4,1,33,0]

theorem envBound4927 : H12AffineFastState.Bounded env4927 := by
  intro p hp
  have h : env4927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4926_4927 : H12AffineEnvironment.transform 2 2 env4926 = env4927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4926 == env4927) = true)

def env4928 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,4194304,8388608,41003,8329,8388608,303233,4097,4524,2080,74794,12624189,257,1,4239489,8389565]

theorem envBound4928 : H12AffineFastState.Bounded env4928 := by
  intro p hp
  have h : env4928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4895_4928 : H12AffineEnvironment.transform 5 17 env4895 = env4928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4895 == env4928) = true)

theorem identity4928 : scanCanonicalize (H12AffineFastState.compose env4928 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4928 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4929 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,4194304,445,41003,8329,445,303233,4097,4524,2080,74794,4235392,257,1,4239489,512]

theorem envBound4929 : H12AffineFastState.Bounded env4929 := by
  intro p hp
  have h : env4929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4928_4929 : H12AffineEnvironment.transform 22 445 env4928 = env4929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4928 == env4929) = true)

theorem identity4929 : scanCanonicalize (H12AffineFastState.compose env4929 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4929 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4930 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4096,41348,445,41003,8329,445,303233,4097,4524,2080,74794,260,257,1,4357,512]

theorem envBound4930 : H12AffineFastState.Bounded env4930 := by
  intro p hp
  have h : env4930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4929_4930 : H12AffineEnvironment.transform 21 41348 env4929 = env4930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4929 == env4930) = true)

theorem identity4930 : scanCanonicalize (H12AffineFastState.compose env4930 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4930 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4931 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13973,65536,4524,262144,1025,13973,4096,5905,445,5822,8329,445,267796,4097,4524,2080,74794,260,257,1,4357,512]

theorem envBound4931 : H12AffineFastState.Bounded env4931 := by
  intro p hp
  have h : env4931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4930_4931 : H12AffineEnvironment.transform 14 13973 env4930 = env4931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4930 == env4931) = true)

theorem identity4931 : scanCanonicalize (H12AffineFastState.compose env4931 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound4931 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4932 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13973,8322,4524,262144,1025,13973,4096,5905,445,5822,8329,445,267796,4097,4524,2080,1192,260,257,1,4357,512]

theorem envBound4932 : H12AffineFastState.Bounded env4932 := by
  intro p hp
  have h : env4932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4931_4932 : H12AffineEnvironment.transform 15 8322 env4931 = env4932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env4931 == env4932) = true)

def env4933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849105,16384,16892,547952,598059,12644669,525568,545873,4239488,8914925]

theorem envBound4933 : H12AffineFastState.Bounded env4933 := by
  intro p hp
  have h : env4933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4844_4933 : H12AffineEnvironment.transform 20 4097 env4844 = env4933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env4844 == env4933) = true)

def env4934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,12644669,256,20561,4239488,8389613]

theorem envBound4934 : H12AffineFastState.Bounded env4934 := by
  intro p hp
  have h : env4934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4933_4934 : H12AffineEnvironment.transform 18 1024 env4933 = env4934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4933 == env4934) = true)

theorem identity4934 : scanCanonicalize (H12AffineFastState.compose env4934 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46528) := by decide +kernel

theorem selectedBound4934 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46528,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,8406269,256,20561,1344,8389613]

theorem envBound4935 : H12AffineFastState.Bounded env4935 := by
  intro p hp
  have h : env4935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4934_4935 : H12AffineEnvironment.transform 21 46528 env4934 = env4935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env4934 == env4935) = true)

def env4936 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,46480,8388608,41003,8329,8388608,323713,16384,16812,22560,74795,8406189,256,20481,1296,8389565]

theorem envBound4936 : H12AffineFastState.Bounded env4936 := by
  intro p hp
  have h : env4936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4935_4936 : H12AffineEnvironment.transform 5 16 env4935 = env4936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4935 == env4936) = true)

def env4937 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1024,32768,4097,46124,8388608,41003,8329,8388608,323713,16384,16400,22560,74795,8406189,188,20481,1196,8389121]

theorem envBound4937 : H12AffineFastState.Bounded env4937 := by
  intro p hp
  have h : env4937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4936_4937 : H12AffineEnvironment.transform 7 188 env4936 = env4937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env4936 == env4937) = true)

theorem identity4937 : scanCanonicalize (H12AffineFastState.compose env4937 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound4937 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env4938 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,4096,8192,16384,32768,53403,4113,262144,1024,32768,4097,46124,8388608,41003,8329,8388608,323713,16384,16400,22560,62640,8406189,188,20481,1196,8389121]

theorem envBound4938 : H12AffineFastState.Bounded env4938 := by
  intro p hp
  have h : env4938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4937_4938 : H12AffineEnvironment.transform 15 53403 env4937 = env4938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env4937 == env4938) = true)

def env4939 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1024,32768,4097,46124,8388608,41003,8329,8388608,323713,16384,16384,22560,62624,8406189,172,20481,1196,8389121]

theorem envBound4939 : H12AffineFastState.Bounded env4939 := by
  intro p hp
  have h : env4939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4938_4939 : H12AffineEnvironment.transform 3 0 env4938 = env4939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4938 == env4939) = true)

theorem identity4939 : scanCanonicalize (H12AffineFastState.compose env4939 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5292) := by decide +kernel

theorem selectedBound4939 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4940 : List Nat := [2,4,8,0,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1024,32768,4097,46124,5292,41003,8329,5292,323713,16384,16384,22560,62624,20481,172,20481,1196,5805]

theorem envBound4940 : H12AffineFastState.Bounded env4940 := by
  intro p hp
  have h : env4940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4939_4940 : H12AffineEnvironment.transform 22 5292 env4939 = env4940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5292 env4939 == env4940) = true)

theorem identity4940 : scanCanonicalize (H12AffineFastState.compose env4940 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4940 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4941 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53282,4097,262144,1024,32768,4097,46124,5125,41003,8224,5125,323624,16384,16384,22560,62473,20481,5,20481,1029,5636]

theorem envBound4941 : H12AffineFastState.Bounded env4941 := by
  intro p hp
  have h : env4941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4940_4941 : H12AffineEnvironment.transform 6 41 env4940 = env4941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4940 == env4941) = true)

theorem identity4941 : scanCanonicalize (H12AffineFastState.compose env4941 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4941 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4942 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,8200,28714,4097,262144,1024,8200,4097,5156,5125,35,8224,5125,282656,16384,16384,22560,21505,20481,5,20481,1029,5636]

theorem envBound4942 : H12AffineFastState.Bounded env4942 := by
  intro p hp
  have h : env4942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4941_4942 : H12AffineEnvironment.transform 14 8200 env4941 = env4942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4941 == env4942) = true)

theorem identity4942 : scanCanonicalize (H12AffineFastState.compose env4942 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8712) := by decide +kernel

theorem selectedBound4942 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4943 : List Nat := [2,4,8,0,32,0,41,5,512,1024,2048,4096,8192,16384,8200,28714,4097,8712,1024,8200,4097,5156,5125,35,8224,5125,29224,16384,16384,22560,21505,20481,5,20481,1029,5636]

theorem envBound4943 : H12AffineFastState.Bounded env4943 := by
  intro p hp
  have h : env4943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4942_4943 : H12AffineEnvironment.transform 17 8712 env4942 = env4943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8712 env4942 == env4943) = true)

end H12CloudChart1