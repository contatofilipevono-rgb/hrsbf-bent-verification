import H12CloudChart1Data125

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans31969_31970 : H12AffineEnvironment.transform 17 10280 env31969 = env31970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31969 == env31970) = true)

def env31971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302891,2196486,2159645,43049,75103,6382922,256,2188650,2196550,513]

theorem envBound31971 : H12AffineFastState.Bounded env31971 := by
  intro p hp
  have h : env31971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31970_31971 : H12AffineEnvironment.transform 6 8 env31970 = env31971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31970 == env31971) = true)

theorem identity31971 : scanCanonicalize (H12AffineFastState.compose env31971 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound31971 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4204924,2098513,2159645,43049,41992,6349853,256,2155581,2098449,513]

theorem envBound31972 : H12AffineFastState.Bounded env31972 := by
  intro p hp
  have h : env31972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31971_31972 : H12AffineEnvironment.transform 15 33111 env31971 = env31972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env31971 == env31972) = true)

theorem identity31972 : scanCanonicalize (H12AffineFastState.compose env31972 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31972 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env31973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,5457,4194304,41293,2,8192,64,4204924,4096,57676,43049,41992,4256076,256,61804,4160,513]

theorem envBound31973 : H12AffineFastState.Bounded env31973 := by
  intro p hp
  have h : env31973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31972_31973 : H12AffineEnvironment.transform 20 5457 env31972 = env31973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env31972 == env31973) = true)

theorem identity31973 : scanCanonicalize (H12AffineFastState.compose env31973 (packedSelected [11,17,23] rootPS)) = affineNative (2^(21+1) ^^^ 9325) := by decide +kernel

theorem selectedBound31973 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env31974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,10280,1024,32769,5457,9325,41293,2,8192,64,3345,4096,57676,43049,41992,54561,256,61804,4160,513]

theorem envBound31974 : H12AffineFastState.Bounded env31974 := by
  intro p hp
  have h : env31974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31973_31974 : H12AffineEnvironment.transform 21 9325 env31973 = env31974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9325 env31973 == env31974) = true)

theorem identity31974 : scanCanonicalize (H12AffineFastState.compose env31974 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 28956) := by decide +kernel

theorem selectedBound31974 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env31975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,28956,28747,4176,10280,1024,28957,5457,9325,20561,2,8192,64,3345,4096,4176,22837,21780,9277,256,112,4160,513]

theorem envBound31975 : H12AffineFastState.Bounded env31975 := by
  intro p hp
  have h : env31975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31974_31975 : H12AffineEnvironment.transform 14 28956 env31974 = env31975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28956 env31974 == env31975) = true)

theorem identity31975 : scanCanonicalize (H12AffineFastState.compose env31975 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 6209) := by decide +kernel

theorem selectedBound31975 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env31976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,6209,10589,10250,4176,10280,1024,10588,5457,9325,2064,2,8192,64,3345,4096,4176,372,3413,9277,256,112,4160,513]

theorem envBound31976 : H12AffineFastState.Bounded env31976 := by
  intro p hp
  have h : env31976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31975_31976 : H12AffineEnvironment.transform 13 6209 env31975 = env31976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6209 env31975 == env31976) = true)

theorem identity31976 : scanCanonicalize (H12AffineFastState.compose env31976 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 4152) := by decide +kernel

theorem selectedBound31976 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env31977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4152,6209,6501,6194,4176,6160,1024,6500,5457,5205,2064,2,4152,64,3345,4096,4176,372,3413,5125,256,112,4160,513]

theorem envBound31977 : H12AffineFastState.Bounded env31977 := by
  intro p hp
  have h : env31977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31976_31977 : H12AffineEnvironment.transform 12 4152 env31976 = env31977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env31976 == env31977) = true)

theorem identity31977 : scanCanonicalize (H12AffineFastState.compose env31977 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound31977 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1101,3124,3344,3143,1061,3173,1024,3345,292,32,2064,2,1101,64,3345,1141,1061,372,3413,112,256,112,1077,513]

theorem envBound31978 : H12AffineFastState.Bounded env31978 := by
  intro p hp
  have h : env31978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31977_31978 : H12AffineEnvironment.transform 11 1141 env31977 = env31978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env31977 == env31978) = true)

theorem identity31978 : scanCanonicalize (H12AffineFastState.compose env31978 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31978 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env31979 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,1101,3124,3173,3143,1061,3173,1024,3172,81,32,2064,2,1101,64,3172,1141,1061,1,3104,112,117,112,1077,513]

theorem envBound31979 : H12AffineFastState.Bounded env31979 := by
  intro p hp
  have h : env31979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31978_31979 : H12AffineEnvironment.transform 7 117 env31978 = env31979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31978 == env31979) = true)

theorem identity31979 : scanCanonicalize (H12AffineFastState.compose env31979 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound31979 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env31980 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1125,1141,1101,81,0,34,1061,0,1024,1,81,32,1141,2,1101,64,1,1141,1061,1,69,112,117,112,1077,513]

theorem envBound31980 : H12AffineFastState.Bounded env31980 := by
  intro p hp
  have h : env31980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31979_31980 : H12AffineEnvironment.transform 10 1125 env31979 = env31980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env31979 == env31980) = true)

def env31981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,3,8193,64,4302890,2196486,2159645,43049,75102,6382922,256,2188650,2196551,513]

theorem envBound31981 : H12AffineFastState.Bounded env31981 := by
  intro p hp
  have h : env31981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31970_31981 : H12AffineEnvironment.transform 6 9 env31970 = env31981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31970 == env31981) = true)

theorem identity31981 : scanCanonicalize (H12AffineFastState.compose env31981 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31981 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env31982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,2097152,4194304,16,3,8193,64,4262263,2172251,2118976,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound31982 : H12AffineFastState.Bounded env31982 := by
  intro p hp
  have h : env31982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31981_31982 : H12AffineEnvironment.transform 14 8541 env31981 = env31982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31981 == env31982) = true)

theorem identity31982 : scanCanonicalize (H12AffineFastState.compose env31982 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound31982 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91467,4194304,16,3,8193,64,4262263,16400,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound31983 : H12AffineFastState.Bounded env31983 := by
  intro p hp
  have h : env31983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31982_31983 : H12AffineEnvironment.transform 20 91467 env31982 = env31983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env31982 == env31983) = true)

theorem identity31983 : scanCanonicalize (H12AffineFastState.compose env31983 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31983 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16401,10280,1024,8540,25629,4194304,16,3,8193,64,4196385,16400,12637,2420,9224,4194305,256,33,16465,513]

theorem envBound31984 : H12AffineFastState.Bounded env31984 := by
  intro p hp
  have h : env31984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31983_31984 : H12AffineEnvironment.transform 15 342 env31983 = env31984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31983 == env31984) = true)

theorem identity31984 : scanCanonicalize (H12AffineFastState.compose env31984 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31984 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16401,2420,1024,0,17729,4194304,16,3,349,64,4196385,16400,4097,2420,1364,4194305,256,33,16465,513]

theorem envBound31985 : H12AffineFastState.Bounded env31985 := by
  intro p hp
  have h : env31985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31984_31985 : H12AffineEnvironment.transform 12 348 env31984 = env31985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31984 == env31985) = true)

theorem identity31985 : scanCanonicalize (H12AffineFastState.compose env31985 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31985 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31986 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1024,0,17680,4194304,16,3,268,17,4196385,16400,4097,2341,1285,4194305,256,33,16384,513]

theorem envBound31986 : H12AffineFastState.Bounded env31986 := by
  intro p hp
  have h : env31986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31985_31986 : H12AffineEnvironment.transform 5 17 env31985 = env31986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31985 == env31986) = true)

theorem identity31986 : scanCanonicalize (H12AffineFastState.compose env31986 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound31986 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31987 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1024,0,17680,21508,16,3,268,17,23589,16400,4097,2341,1285,21509,256,33,16384,513]

theorem envBound31987 : H12AffineFastState.Bounded env31987 := by
  intro p hp
  have h : env31987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31986_31987 : H12AffineEnvironment.transform 21 21508 env31986 = env31987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env31986 == env31987) = true)

theorem identity31987 : scanCanonicalize (H12AffineFastState.compose env31987 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound31987 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31988 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5157,1,263,5172,2341,1024,0,4405,33,16,3,268,17,2048,5173,4097,2341,1285,32,256,33,5157,513]

theorem envBound31988 : H12AffineFastState.Bounded env31988 := by
  intro p hp
  have h : env31988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31987_31988 : H12AffineEnvironment.transform 13 5157 env31987 = env31988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env31987 == env31988) = true)

def env31989 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2837,1,263,2820,2341,1024,0,3589,33,16,3,268,17,2048,2821,3889,2341,1285,32,256,33,2837,513]

theorem envBound31989 : H12AffineFastState.Bounded env31989 := by
  intro p hp
  have h : env31989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31988_31989 : H12AffineEnvironment.transform 11 3888 env31988 = env31989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env31988 == env31989) = true)

def env31990 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1045,1,263,1028,1573,1024,0,261,33,16,3,268,17,1792,1029,49,1573,1285,32,256,33,1045,513]

theorem envBound31990 : H12AffineFastState.Bounded env31990 := by
  intro p hp
  have h : env31990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31989_31990 : H12AffineEnvironment.transform 10 1792 env31989 = env31990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env31989 == env31990) = true)

theorem identity31990 : scanCanonicalize (H12AffineFastState.compose env31990 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31991 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,48,269,33,1,263,48,529,52,0,261,33,16,3,268,17,820,49,49,529,305,32,256,33,33,513]

theorem envBound31991 : H12AffineFastState.Bounded env31991 := by
  intro p hp
  have h : env31991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31990_31991 : H12AffineEnvironment.transform 9 52 env31990 = env31991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31990 == env31991) = true)

def env31992 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1044,1,263,1029,1572,1024,0,260,33,16,3,268,17,1793,1028,48,1572,1285,32,256,33,1044,513]

theorem envBound31992 : H12AffineFastState.Bounded env31992 := by
  intro p hp
  have h : env31992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31989_31992 : H12AffineEnvironment.transform 10 1793 env31989 = env31992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env31989 == env31992) = true)

theorem identity31992 : scanCanonicalize (H12AffineFastState.compose env31992 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31993 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,49,40,1044,1,34,1029,1572,1024,0,33,33,16,3,41,17,1572,1028,48,1572,1056,32,37,33,1044,513]

theorem envBound31993 : H12AffineFastState.Bounded env31993 := by
  intro p hp
  have h : env31993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31992_31993 : H12AffineEnvironment.transform 7 37 env31992 = env31993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31992 == env31993) = true)

def env31994 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,49,40,32,1,34,49,528,52,0,33,33,16,3,41,17,528,48,48,528,20,32,37,33,32,513]

theorem envBound31994 : H12AffineFastState.Bounded env31994 := by
  intro p hp
  have h : env31994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31993_31994 : H12AffineEnvironment.transform 9 52 env31993 = env31994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31993 == env31994) = true)

def env31995 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,49,40,33,1,34,48,529,53,0,33,33,16,3,41,17,529,49,48,529,21,32,37,33,33,513]

theorem envBound31995 : H12AffineFastState.Bounded env31995 := by
  intro p hp
  have h : env31995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31993_31995 : H12AffineEnvironment.transform 9 53 env31993 = env31995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31993 == env31995) = true)

theorem identity31995 : scanCanonicalize (H12AffineFastState.compose env31995 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound31995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31996 : List Nat := [2,4,8,16,32,17,9,37,43,53,58,49,40,33,1,34,48,58,53,0,33,33,16,3,41,17,58,49,48,58,21,32,37,33,33,42]

theorem envBound31996 : H12AffineFastState.Bounded env31996 := by
  intro p hp
  have h : env31996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31995_31996 : H12AffineEnvironment.transform 8 43 env31995 = env31996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env31995 == env31996) = true)

def leafEnv31996 : List Nat := [2,4,8,16,32,17,9,37,43,53,58,49,40,33,1,34,48,58,53,0,33,33,16,3,21,41,1,17,58,49,48,58,21,32,37,33,4,35,33,42,1,33,0]

def active31996 : List Nat := [0,1,2,3,4]

def tree31996 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31996 : H12WitnessSearch.Good tree31996 := H12GlobalWitnessIndex.good

theorem leafIdentity31996 : H12AffineFastState.composeSystem env31996 rootObs = leafEnv31996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31996 rootObs == leafEnv31996) = true)

theorem terminalChecked31996 : H12PackedTerminal.terminalCheckFast leafEnv31996 active31996 tree31996 = true := by decide +kernel

def env31997 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2836,1,263,2821,2341,1024,0,3588,33,16,3,268,17,2048,2820,3888,2341,1285,32,256,33,2836,513]

theorem envBound31997 : H12AffineFastState.Bounded env31997 := by
  intro p hp
  have h : env31997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31988_31997 : H12AffineEnvironment.transform 11 3889 env31988 = env31997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env31988 == env31997) = true)

def env31998 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1044,1,263,1029,1573,1024,0,260,33,16,3,268,17,1792,1028,48,1573,1285,32,256,33,1044,513]

theorem envBound31998 : H12AffineFastState.Bounded env31998 := by
  intro p hp
  have h : env31998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31997_31998 : H12AffineEnvironment.transform 10 1792 env31997 = env31998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env31997 == env31998) = true)

def env31999 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1045,1,263,1028,1572,1024,0,261,33,16,3,268,17,1793,1029,49,1572,1285,32,256,33,1045,513]

theorem envBound31999 : H12AffineFastState.Bounded env31999 := by
  intro p hp
  have h : env31999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31997_31999 : H12AffineEnvironment.transform 10 1793 env31997 = env31999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env31997 == env31999) = true)

theorem identity31999 : scanCanonicalize (H12AffineFastState.compose env31999 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32000 : List Nat := [2,4,8,16,32,17,9,256,512,272,529,48,269,261,1,263,276,820,272,0,261,33,16,3,268,17,529,277,49,820,21,32,256,33,261,513]

theorem envBound32000 : H12AffineFastState.Bounded env32000 := by
  intro p hp
  have h : env32000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31999_32000 : H12AffineEnvironment.transform 9 272 env31999 = env32000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31999 == env32000) = true)

def env32001 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,33,1,35,48,528,52,0,33,33,16,3,40,17,529,49,49,528,21,32,36,33,33,513]

theorem envBound32001 : H12AffineFastState.Bounded env32001 := by
  intro p hp
  have h : env32001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32000_32001 : H12AffineEnvironment.transform 7 36 env32000 = env32001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32000 == env32001) = true)

def env32002 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,48,40,32,1,34,49,529,53,0,32,33,16,3,41,17,529,48,49,529,21,32,37,33,32,513]

theorem envBound32002 : H12AffineFastState.Bounded env32002 := by
  intro p hp
  have h : env32002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32000_32002 : H12AffineEnvironment.transform 7 37 env32000 = env32002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32000 == env32002) = true)

theorem identity32002 : scanCanonicalize (H12AffineFastState.compose env32002 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32003 : List Nat := [2,4,8,16,32,17,9,37,42,53,59,48,40,32,1,34,49,59,53,0,32,33,16,3,41,17,59,48,49,59,21,32,37,33,32,43]

theorem envBound32003 : H12AffineFastState.Bounded env32003 := by
  intro p hp
  have h : env32003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32002_32003 : H12AffineEnvironment.transform 8 42 env32002 = env32003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32002 == env32003) = true)

def leafEnv32003 : List Nat := [2,4,8,16,32,17,9,37,42,53,59,48,40,32,1,34,49,59,53,0,32,33,16,3,21,41,1,17,59,48,49,59,21,32,37,33,4,35,32,43,1,32,0]

def active32003 : List Nat := [0,1,2,3,4]

def tree32003 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32003 : H12WitnessSearch.Good tree32003 := H12GlobalWitnessIndex.good

theorem leafIdentity32003 : H12AffineFastState.composeSystem env32003 rootObs = leafEnv32003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32003 rootObs == leafEnv32003) = true)

theorem terminalChecked32003 : H12PackedTerminal.terminalCheckFast leafEnv32003 active32003 tree32003 = true := by decide +kernel

def env32004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41293,138,8328,64,4303010,2196486,2159645,43048,75223,6382922,256,2188650,2196686,513]

theorem envBound32004 : H12AffineFastState.Bounded env32004 := by
  intro p hp
  have h : env32004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31969_32004 : H12AffineEnvironment.transform 17 10281 env31969 = env32004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31969 == env32004) = true)

theorem identity32004 : scanCanonicalize (H12AffineFastState.compose env32004 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32004 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,2097152,4194304,16,138,8328,64,4262399,2172251,2118976,2421,75223,6382922,256,2188650,2172307,513]

theorem envBound32005 : H12AffineFastState.Bounded env32005 := by
  intro p hp
  have h : env32005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32004_32005 : H12AffineEnvironment.transform 14 8541 env32004 = env32005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32004 == env32005) = true)

theorem identity32005 : scanCanonicalize (H12AffineFastState.compose env32005 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32005 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env32006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1024,8540,2097152,4194304,16,138,8328,64,4205045,2098513,2118976,2421,1501,6309184,256,2114912,2098585,513]

theorem envBound32006 : H12AffineFastState.Bounded env32006 := by
  intro p hp
  have h : env32006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32005_32006 : H12AffineEnvironment.transform 15 8202 env32005 = env32006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32005 == env32006) = true)

theorem identity32006 : scanCanonicalize (H12AffineFastState.compose env32006 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound32006 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8202,4096,10281,1024,8540,2097152,4194304,16,138,8328,64,4205045,2098513,2098513,2421,1501,6296913,256,2102641,2098585,513]

theorem envBound32007 : H12AffineFastState.Bounded env32007 := by
  intro p hp
  have h : env32007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32006_32007 : H12AffineEnvironment.transform 13 4113 env32006 = env32007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env32006 == env32007) = true)

theorem identity32007 : scanCanonicalize (H12AffineFastState.compose env32007 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound32007 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8202,4096,10281,1024,8540,5593,4194304,16,138,8328,64,4205045,4232,4232,2421,1501,4194440,256,168,4160,513]

theorem envBound32008 : H12AffineFastState.Bounded env32008 := by
  intro p hp
  have h : env32008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32007_32008 : H12AffineEnvironment.transform 20 5593 env32007 = env32008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env32007 == env32008) = true)

theorem identity32008 : scanCanonicalize (H12AffineFastState.compose env32008 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound32008 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env32009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8202,4096,10281,1024,8540,5593,113,16,138,8328,64,10628,4232,4232,2421,1501,249,256,168,4160,513]

theorem envBound32009 : H12AffineFastState.Bounded env32009 := by
  intro p hp
  have h : env32009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32008_32009 : H12AffineEnvironment.transform 21 113 env32008 = env32009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env32008 == env32009) = true)

theorem identity32009 : scanCanonicalize (H12AffineFastState.compose env32009 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound32009 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env32010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,4113,216,399,4096,2476,1024,217,5593,113,16,138,269,64,2049,4232,4232,2421,1501,249,256,168,4160,513]

theorem envBound32010 : H12AffineFastState.Bounded env32010 := by
  intro p hp
  have h : env32010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32009_32010 : H12AffineEnvironment.transform 12 389 env32009 = env32010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env32009 == env32010) = true)

theorem identity32010 : scanCanonicalize (H12AffineFastState.compose env32010 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32010 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32011 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,4113,0,343,4096,2420,1024,1,5377,113,16,82,269,64,2049,4176,4176,2421,1285,33,256,112,4160,513]

theorem envBound32011 : H12AffineFastState.Bounded env32011 := by
  intro p hp
  have h : env32011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32010_32011 : H12AffineEnvironment.transform 6 88 env32010 = env32011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32010 == env32011) = true)

theorem identity32011 : scanCanonicalize (H12AffineFastState.compose env32011 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32011 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32012 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,349,4113,0,343,4096,2420,273,1,4112,113,16,82,269,64,2049,4176,4176,2421,20,33,256,112,4160,513]

theorem envBound32012 : H12AffineFastState.Bounded env32012 := by
  intro p hp
  have h : env32012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32011_32012 : H12AffineEnvironment.transform 9 273 env32011 = env32012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32011 == env32012) = true)

theorem identity32012 : scanCanonicalize (H12AffineFastState.compose env32012 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32012 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32013 : List Nat := [2,4,8,16,32,64,88,117,512,100,2048,4096,40,4113,0,34,4096,2049,100,1,4112,113,16,82,120,64,2049,4176,4176,2048,20,33,117,112,4160,513]

theorem envBound32013 : H12AffineFastState.Bounded env32013 := by
  intro p hp
  have h : env32013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32012_32013 : H12AffineEnvironment.transform 7 117 env32012 = env32013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32012 == env32013) = true)

theorem identity32013 : scanCanonicalize (H12AffineFastState.compose env32013 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32014 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,0,34,4096,2049,52,1,4112,33,16,2,40,16,2049,4096,4096,2048,20,33,37,32,4112,513]

theorem envBound32014 : H12AffineFastState.Bounded env32014 := by
  intro p hp
  have h : env32014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32013_32014 : H12AffineEnvironment.transform 5 16 env32013 = env32014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32013 == env32014) = true)

theorem identity32014 : scanCanonicalize (H12AffineFastState.compose env32014 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound32014 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32015 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,4096,40,4113,0,34,4096,48,52,1,4112,33,16,2,40,16,48,4096,4096,49,20,33,37,32,4112,513]

theorem envBound32015 : H12AffineFastState.Bounded env32015 := by
  intro p hp
  have h : env32015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32014_32015 : H12AffineEnvironment.transform 10 49 env32014 = env32015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env32014 == env32015) = true)

theorem identity32015 : scanCanonicalize (H12AffineFastState.compose env32015 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound32015 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32016 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,40,49,0,34,32,48,52,1,48,33,16,2,40,16,48,32,32,49,20,33,37,32,48,513]

theorem envBound32016 : H12AffineFastState.Bounded env32016 := by
  intro p hp
  have h : env32016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32015_32016 : H12AffineEnvironment.transform 11 32 env32015 = env32016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env32015 == env32016) = true)

def leafEnv32016 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,40,49,0,34,32,48,52,1,48,33,16,2,20,40,1,16,48,32,32,49,20,33,37,32,4,34,48,513,1,49,0]

def active32016 : List Nat := [0,1,2,3,4,8]

def tree32016 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32016 : H12WitnessSearch.Good tree32016 := H12GlobalWitnessIndex.good

theorem leafIdentity32016 : H12AffineFastState.composeSystem env32016 rootObs = leafEnv32016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32016 rootObs == leafEnv32016) = true)

theorem terminalChecked32016 : H12PackedTerminal.terminalCheckFast leafEnv32016 active32016 tree32016 = true := by decide +kernel

def env32017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21331968,18973836,2159645,294912,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound32017 : H12AffineFastState.Bounded env32017 := by
  intro p hp
  have h : env32017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31967_32017 : H12AffineEnvironment.transform 16 57677 env31967 = env32017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env31967 == env32017) = true)

def env32018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,16777216,8328,64,21080104,18973836,2159645,43048,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound32018 : H12AffineFastState.Bounded env32018 := by
  intro p hp
  have h : env32018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32017_32018 : H12AffineEnvironment.transform 17 10280 env32017 = env32018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32017 == env32018) = true)

def env32019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,16777216,8192,64,21080104,18973700,2159645,43048,16852317,23160136,256,18965864,18973764,16777731]

theorem envBound32019 : H12AffineFastState.Bounded env32019 := by
  intro p hp
  have h : env32019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32018_32019 : H12AffineEnvironment.transform 6 8 env32018 = env32019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32018 == env32019) = true)

theorem identity32019 : scanCanonicalize (H12AffineFastState.compose env32019 (packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound32019 : packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env32020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,73770,41293,16777216,8192,64,16812034,18973700,2159645,43048,16852317,18892130,256,18965864,18973764,16777731]

theorem envBound32020 : H12AffineFastState.Bounded env32020 := by
  intro p hp
  have h : env32020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32019_32020 : H12AffineEnvironment.transform 21 73770 env32019 = env32020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env32019 == env32020) = true)

theorem identity32020 : scanCanonicalize (H12AffineFastState.compose env32020 (packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2155883) := by decide +kernel

theorem selectedBound32020 : packedSelected [0,1,5,7,9,10,11,12,14,15,18,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env32021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,73770,41293,2155883,8192,64,2125161,90479,2159645,43048,2211894,40969,256,98307,90415,2156392]

theorem envBound32021 : H12AffineFastState.Bounded env32021 := by
  intro p hp
  have h : env32021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32020_32021 : H12AffineEnvironment.transform 23 2155883 env32020 = env32021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155883 env32020 == env32021) = true)

theorem identity32021 : scanCanonicalize (H12AffineFastState.compose env32021 (packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound32021 : packedSelected [0,2,3,4,7,8,11,12,14,15,16,17,18,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env32022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,58396,73770,41293,375,8192,64,35189,90479,4097,43048,74794,40969,256,98307,90415,884]

theorem envBound32022 : H12AffineFastState.Bounded env32022 := by
  intro p hp
  have h : env32022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32021_32022 : H12AffineEnvironment.transform 20 58396 env32021 = env32022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env32021 == env32022) = true)

theorem identity32022 : scanCanonicalize (H12AffineFastState.compose env32022 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound32022 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env32023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8575,57677,10280,1024,32769,58396,341,41293,375,8192,64,35189,16400,4097,43048,1365,40969,256,41340,16464,884]

theorem envBound32023 : H12AffineFastState.Bounded env32023 := by
  intro p hp
  have h : env32023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32022_32023 : H12AffineEnvironment.transform 15 8575 env32022 = env32023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env32022 == env32023) = true)

theorem identity32023 : scanCanonicalize (H12AffineFastState.compose env32023 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32023 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env32024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,8575,38208,10280,1024,32769,36881,341,41293,375,8192,64,35189,13341,4097,43048,1365,40969,256,41340,13405,884]

theorem envBound32024 : H12AffineFastState.Bounded env32024 := by
  intro p hp
  have h : env32024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32023_32024 : H12AffineEnvironment.transform 13 13325 env32023 = env32024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32023 == env32024) = true)

def env32025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,16777216,8193,64,21080104,18973701,2159645,43048,16852317,23160137,256,18965865,18973764,16777730]

theorem envBound32025 : H12AffineFastState.Bounded env32025 := by
  intro p hp
  have h : env32025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32018_32025 : H12AffineEnvironment.transform 6 9 env32018 = env32025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32018 == env32025) = true)

theorem identity32025 : scanCanonicalize (H12AffineFastState.compose env32025 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound32025 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,3,8193,64,4302891,2196486,2159645,43048,75102,6382922,256,2188650,2196551,513]

theorem envBound32026 : H12AffineFastState.Bounded env32026 := by
  intro p hp
  have h : env32026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32025_32026 : H12AffineEnvironment.transform 23 3 env32025 = env32026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env32025 == env32026) = true)

theorem identity32026 : scanCanonicalize (H12AffineFastState.compose env32026 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound32026 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env32027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,10280,1024,32769,2097152,4194304,41293,3,8193,64,4196384,2106381,2159645,43048,34133,6341953,256,2147681,2106444,513]

theorem envBound32027 : H12AffineFastState.Bounded env32027 := by
  intro p hp
  have h : env32027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32026_32027 : H12AffineEnvironment.transform 15 40971 env32026 = env32027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env32026 == env32027) = true)

theorem identity32027 : scanCanonicalize (H12AffineFastState.compose env32027 (packedSelected [1,2,5,6,8,11,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32027 : packedSelected [1,2,5,6,8,11,17,18,24] rootPS < 2^1333 := by decide +kernel

def env32028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,343,16401,10280,1024,8541,2097152,4194304,17,3,8193,64,4196384,2106381,2118977,2420,9225,6317085,256,2122813,2106444,513]

theorem envBound32028 : H12AffineFastState.Bounded env32028 := by
  intro p hp
  have h : env32028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32027_32028 : H12AffineEnvironment.transform 14 8540 env32027 = env32028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32027 == env32028) = true)

theorem identity32028 : scanCanonicalize (H12AffineFastState.compose env32028 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound32028 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,343,16401,10280,1024,8541,2097152,2114913,17,3,8193,64,2116929,2106381,2118977,2420,9225,8572,256,2122813,2106444,513]

theorem envBound32029 : H12AffineFastState.Bounded env32029 := by
  intro p hp
  have h : env32029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32028_32029 : H12AffineEnvironment.transform 21 2114913 env32028 = env32029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env32028 == env32029) = true)

theorem identity32029 : scanCanonicalize (H12AffineFastState.compose env32029 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound32029 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env32030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,343,16401,10280,1024,8541,17729,32,17,3,8193,64,2048,24908,4096,2420,9225,8572,256,8572,24845,513]

theorem envBound32030 : H12AffineFastState.Bounded env32030 := by
  intro p hp
  have h : env32030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32029_32030 : H12AffineEnvironment.transform 20 17729 env32029 = env32030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env32029 == env32030) = true)

def env32031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41293,16777216,8328,64,21080105,18973836,2159645,43049,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound32031 : H12AffineFastState.Bounded env32031 := by
  intro p hp
  have h : env32031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32017_32031 : H12AffineEnvironment.transform 17 10281 env32017 = env32031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32017 == env32031) = true)

theorem identity32031 : scanCanonicalize (H12AffineFastState.compose env32031 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32031 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,2097152,4194304,16,16777216,8328,64,21039476,18949585,2118976,2420,16852317,23160256,256,18965984,18949401,16777867]

theorem envBound32032 : H12AffineFastState.Bounded env32032 := by
  intro p hp
  have h : env32032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32031_32032 : H12AffineEnvironment.transform 14 8541 env32031 = env32032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32031 == env32032) = true)

def env32033 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,2097152,4194304,16,16777216,8328,64,21039104,18949285,2118708,2048,16852009,23159988,116,18965652,18949229,16777867]

theorem envBound32033 : H12AffineFastState.Bounded env32033 := by
  intro p hp
  have h : env32033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32032_32033 : H12AffineEnvironment.transform 7 116 env32032 = env32033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32032 == env32033) = true)

theorem identity32033 : scanCanonicalize (H12AffineFastState.compose env32033 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound32033 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env32034 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,17597,4194304,16,16777216,8328,64,21039104,16867352,4233,2048,16852009,21045257,116,16850985,16867536,16777867]

theorem envBound32034 : H12AffineFastState.Bounded env32034 := by
  intro p hp
  have h : env32034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32033_32034 : H12AffineEnvironment.transform 20 17597 env32033 = env32034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env32033 == env32034) = true)

theorem identity32034 : scanCanonicalize (H12AffineFastState.compose env32034 (packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(23+1) ^^^ 4194475) := by decide +kernel

theorem selectedBound32034 : packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env32035 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,17597,4194304,16,4194475,8328,64,67755,4284595,4233,2048,4269186,73890,116,4268162,4284539,4194848]

theorem envBound32035 : H12AffineFastState.Bounded env32035 := by
  intro p hp
  have h : env32035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32034_32035 : H12AffineEnvironment.transform 23 4194475 env32034 = env32035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4194475 env32034 == env32035) = true)

theorem identity32035 : scanCanonicalize (H12AffineFastState.compose env32035 (packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound32035 : packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env32036 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,17597,33,16,138,8328,64,67755,90258,4233,2048,74915,73890,116,73891,90202,513]

theorem envBound32036 : H12AffineFastState.Bounded env32036 := by
  intro p hp
  have h : env32036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32035_32036 : H12AffineEnvironment.transform 21 33 env32035 = env32036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32035 == env32036) = true)

theorem identity32036 : scanCanonicalize (H12AffineFastState.compose env32036 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29863) := by decide +kernel

theorem selectedBound32036 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env32037 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8233,29863,16400,10281,1024,8232,17597,33,16,138,8328,64,31756,5173,4233,2048,20484,21509,116,21508,5373,513]

theorem envBound32037 : H12AffineFastState.Bounded env32037 := by
  intro p hp
  have h : env32037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32036_32037 : H12AffineEnvironment.transform 15 29863 env32036 = env32037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29863 env32036 == env32037) = true)

theorem identity32037 : scanCanonicalize (H12AffineFastState.compose env32037 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound32037 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32038 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5293,8233,8202,5309,10281,1024,8232,4112,33,16,138,8328,64,10401,5173,4233,2048,1193,168,116,169,5373,513]

theorem envBound32038 : H12AffineFastState.Bounded env32038 := by
  intro p hp
  have h : env32038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32037_32038 : H12AffineEnvironment.transform 13 5293 env32037 = env32038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env32037 == env32038) = true)

theorem identity32038 : scanCanonicalize (H12AffineFastState.compose env32038 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32038 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32039 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,5293,8233,8202,5309,10281,1024,8232,4112,33,16,138,8328,17,10401,5173,4233,2048,1193,168,37,169,5292,513]

theorem envBound32039 : H12AffineFastState.Bounded env32039 := by
  intro p hp
  have h : env32039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32038_32039 : H12AffineEnvironment.transform 5 17 env32038 = env32039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32038 == env32039) = true)

theorem identity32039 : scanCanonicalize (H12AffineFastState.compose env32039 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound32039 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32040 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,1053,5293,1076,1047,5309,3124,1024,1077,4112,33,16,138,1173,17,3260,5173,4233,2048,1193,168,37,169,5292,513]

theorem envBound32040 : H12AffineFastState.Bounded env32040 := by
  intro p hp
  have h : env32040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32039_32040 : H12AffineEnvironment.transform 12 1053 env32039 = env32040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env32039 == env32040) = true)

theorem identity32040 : scanCanonicalize (H12AffineFastState.compose env32040 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound32040 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32041 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,2058,1053,3239,1076,1047,3255,3124,1024,1077,2074,33,16,138,1173,17,3260,3135,2179,2048,1193,168,37,169,3238,513]

theorem envBound32041 : H12AffineFastState.Bounded env32041 := by
  intro p hp
  have h : env32041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32040_32041 : H12AffineEnvironment.transform 11 2058 env32040 = env32041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env32040 == env32041) = true)

theorem identity32041 : scanCanonicalize (H12AffineFastState.compose env32041 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound32041 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32042 : List Nat := [2,4,8,16,32,17,128,37,512,1024,152,146,1053,1087,1076,1047,1071,1196,1024,1077,130,33,16,138,1173,17,1060,1191,27,152,1193,168,37,169,1086,513]

theorem envBound32042 : H12AffineFastState.Bounded env32042 := by
  intro p hp
  have h : env32042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32041_32042 : H12AffineEnvironment.transform 10 152 env32041 = env32042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env32041 == env32042) = true)

theorem identity32042 : scanCanonicalize (H12AffineFastState.compose env32042 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound32042 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env32043 : List Nat := [2,4,8,16,32,17,128,37,512,189,152,146,160,130,137,170,146,17,189,136,130,33,16,138,40,17,153,26,27,152,20,168,37,169,131,513]

theorem envBound32043 : H12AffineFastState.Bounded env32043 := by
  intro p hp
  have h : env32043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32042_32043 : H12AffineEnvironment.transform 9 189 env32042 = env32043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env32042 == env32043) = true)

theorem identity32043 : scanCanonicalize (H12AffineFastState.compose env32043 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound32043 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32044 : List Nat := [2,4,8,16,32,17,128,37,2,189,152,146,160,130,137,170,146,17,189,136,130,33,16,138,40,17,153,26,27,152,20,168,37,169,131,3]

theorem envBound32044 : H12AffineFastState.Bounded env32044 := by
  intro p hp
  have h : env32044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32043_32044 : H12AffineEnvironment.transform 8 2 env32043 = env32044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env32043 == env32044) = true)

theorem identity32044 : scanCanonicalize (H12AffineFastState.compose env32044 (packedSelected [0,1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32044 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env32045 : List Nat := [2,0,8,16,32,17,128,33,2,185,152,146,160,130,137,170,146,17,185,136,130,33,16,138,40,17,153,26,27,152,16,168,33,169,131,3]

theorem envBound32045 : H12AffineFastState.Bounded env32045 := by
  intro p hp
  have h : env32045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32044_32045 : H12AffineEnvironment.transform 1 0 env32044 = env32045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32044 == env32045) = true)

theorem identity32045 : scanCanonicalize (H12AffineFastState.compose env32045 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound32045 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32046 : List Nat := [2,0,8,16,32,17,34,33,2,27,58,48,2,32,43,8,48,17,27,42,32,33,16,40,40,17,59,26,27,58,16,10,33,11,33,3]

theorem envBound32046 : H12AffineFastState.Bounded env32046 := by
  intro p hp
  have h : env32046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32045_32046 : H12AffineEnvironment.transform 6 34 env32045 = env32046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env32045 == env32046) = true)

theorem identity32046 : scanCanonicalize (H12AffineFastState.compose env32046 (packedSelected [0,1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32046 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env32047 : List Nat := [2,0,8,16,17,17,19,16,2,27,11,1,2,17,26,8,1,17,27,27,17,16,16,25,25,17,10,26,27,11,16,10,16,11,16,3]

theorem envBound32047 : H12AffineFastState.Bounded env32047 := by
  intro p hp
  have h : env32047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32046_32047 : H12AffineEnvironment.transform 4 17 env32046 = env32047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32046 == env32047) = true)

theorem identity32047 : scanCanonicalize (H12AffineFastState.compose env32047 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32047 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32048 : List Nat := [2,0,8,10,11,11,9,10,2,1,11,1,2,11,0,8,1,11,1,1,11,10,10,3,3,11,10,0,1,11,10,10,10,11,10,3]

theorem envBound32048 : H12AffineFastState.Bounded env32048 := by
  intro p hp
  have h : env32048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32047_32048 : H12AffineEnvironment.transform 3 10 env32047 = env32048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32047 == env32048) = true)

theorem identity32048 : scanCanonicalize (H12AffineFastState.compose env32048 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32049 : List Nat := [2,0,2,0,1,1,3,0,2,1,1,1,2,1,0,2,1,1,1,1,1,0,0,3,3,1,0,0,1,1,0,0,0,1,0,3]

theorem envBound32049 : H12AffineFastState.Bounded env32049 := by
  intro p hp
  have h : env32049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32048_32049 : H12AffineEnvironment.transform 2 2 env32048 = env32049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32048 == env32049) = true)

theorem identity32049 : scanCanonicalize (H12AffineFastState.compose env32049 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32049 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32050 : List Nat := [1,0,1,0,1,1,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,1,0,0,1,1,0,0,0,1,0,0]

theorem envBound32050 : H12AffineFastState.Bounded env32050 := by
  intro p hp
  have h : env32050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32049_32050 : H12AffineEnvironment.transform 0 1 env32049 = env32050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32049 == env32050) = true)

def env32051 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,2097152,4194304,16,16777216,8328,64,21039105,18949284,2118709,2049,16852008,23159989,117,18965653,18949228,16777867]

theorem envBound32051 : H12AffineFastState.Bounded env32051 := by
  intro p hp
  have h : env32051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32032_32051 : H12AffineEnvironment.transform 7 117 env32032 = env32051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32032 == env32051) = true)

theorem identity32051 : scanCanonicalize (H12AffineFastState.compose env32051 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(23+1) ^^^ 2114614) := by decide +kernel

theorem selectedBound32051 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env32052 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,2097152,4194304,16,2114614,8328,64,6376503,90258,2118709,2049,2187294,4268163,117,73891,90202,2115261]

theorem envBound32052 : H12AffineFastState.Bounded env32052 := by
  intro p hp
  have h : env32052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32051_32052 : H12AffineEnvironment.transform 23 2114614 env32051 = env32052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2114614 env32051 == env32052) = true)

theorem identity32052 : scanCanonicalize (H12AffineFastState.compose env32052 (packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 2114717) := by decide +kernel

theorem selectedBound32052 : packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env32053 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,2097152,2114717,16,2114614,8328,64,67754,90258,2118709,2049,2187294,2188318,117,73891,90202,2115261]

theorem envBound32053 : H12AffineFastState.Bounded env32053 := by
  intro p hp
  have h : env32053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32052_32053 : H12AffineEnvironment.transform 21 2114717 env32052 = env32053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114717 env32052 == env32053) = true)

theorem identity32053 : scanCanonicalize (H12AffineFastState.compose env32053 (packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound32053 : packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env32054 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,17596,33,16,138,8328,64,67754,90258,4233,2049,74914,73890,117,73891,90202,513]

theorem envBound32054 : H12AffineFastState.Bounded env32054 := by
  intro p hp
  have h : env32054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32053_32054 : H12AffineEnvironment.transform 20 17596 env32053 = env32054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env32053 == env32054) = true)

theorem identity32054 : scanCanonicalize (H12AffineFastState.compose env32054 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound32054 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env32055 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8232,29743,16400,10281,1024,8233,17596,33,16,138,8328,64,31877,5309,4233,2049,20621,21645,117,21644,5237,513]

theorem envBound32055 : H12AffineFastState.Bounded env32055 := by
  intro p hp
  have h : env32055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32054_32055 : H12AffineEnvironment.transform 15 29743 env32054 = env32055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env32054 == env32055) = true)

theorem identity32055 : scanCanonicalize (H12AffineFastState.compose env32055 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound32055 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32056 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5293,8232,8322,5309,10281,1024,8233,4113,33,16,138,8328,64,10280,5309,4233,2049,1056,32,117,33,5237,513]

theorem envBound32056 : H12AffineFastState.Bounded env32056 := by
  intro p hp
  have h : env32056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32055_32056 : H12AffineEnvironment.transform 13 5293 env32055 = env32056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env32055 == env32056) = true)

theorem identity32056 : scanCanonicalize (H12AffineFastState.compose env32056 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound32056 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32057 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,136,8192,1061,8232,8322,1077,10281,1024,8233,153,33,16,138,8328,64,10280,1077,1,2049,1056,32,117,33,1277,513]

theorem envBound32057 : H12AffineFastState.Bounded env32057 := by
  intro p hp
  have h : env32057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32056_32057 : H12AffineEnvironment.transform 11 136 env32056 = env32057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env32056 == env32057) = true)

theorem identity32057 : scanCanonicalize (H12AffineFastState.compose env32057 (packedSelected [2,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound32057 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32058 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,136,240,1061,216,114,1077,2265,1024,217,153,33,16,138,120,64,2264,1077,1,2049,1056,32,117,33,1277,513]

theorem envBound32058 : H12AffineFastState.Bounded env32058 := by
  intro p hp
  have h : env32058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32057_32058 : H12AffineEnvironment.transform 12 240 env32057 = env32058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env32057 == env32058) = true)

theorem identity32058 : scanCanonicalize (H12AffineFastState.compose env32058 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound32058 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32059 : List Nat := [2,4,8,16,32,64,128,117,512,189,2048,136,240,152,216,114,136,2265,189,217,153,33,16,138,120,64,2264,136,1,2049,157,32,117,33,64,513]

theorem envBound32059 : H12AffineFastState.Bounded env32059 := by
  intro p hp
  have h : env32059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32058_32059 : H12AffineEnvironment.transform 9 189 env32058 = env32059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env32058 == env32059) = true)

theorem identity32059 : scanCanonicalize (H12AffineFastState.compose env32059 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound32059 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32060 : List Nat := [2,4,8,16,32,64,128,117,512,189,65,136,240,152,216,114,136,152,189,217,153,33,16,138,120,64,153,136,1,64,157,32,117,33,64,513]

theorem envBound32060 : H12AffineFastState.Bounded env32060 := by
  intro p hp
  have h : env32060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32059_32060 : H12AffineEnvironment.transform 10 65 env32059 = env32060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env32059 == env32060) = true)

theorem identity32060 : scanCanonicalize (H12AffineFastState.compose env32060 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32060 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env32061 : List Nat := [2,4,8,16,32,16,128,37,512,189,17,136,160,152,136,34,136,152,189,137,153,33,16,138,40,16,153,136,1,16,157,32,37,33,16,513]

theorem envBound32061 : H12AffineFastState.Bounded env32061 := by
  intro p hp
  have h : env32061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32060_32061 : H12AffineEnvironment.transform 5 16 env32060 = env32061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32060 == env32061) = true)

theorem identity32061 : scanCanonicalize (H12AffineFastState.compose env32061 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32061 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32062 : List Nat := [2,4,8,16,32,16,9,37,512,52,17,1,41,17,1,34,1,17,52,0,16,33,16,3,40,16,16,1,1,16,20,32,37,33,16,513]

theorem envBound32062 : H12AffineFastState.Bounded env32062 := by
  intro p hp
  have h : env32062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32061_32062 : H12AffineEnvironment.transform 6 9 env32061 = env32062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32061 == env32062) = true)

theorem identity32062 : scanCanonicalize (H12AffineFastState.compose env32062 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32062 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32063 : List Nat := [2,4,8,16,17,16,9,20,512,5,17,1,24,17,1,19,1,17,5,0,16,16,16,3,25,16,16,1,1,16,20,17,20,16,16,513]

theorem envBound32063 : H12AffineFastState.Bounded env32063 := by
  intro p hp
  have h : env32063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32062_32063 : H12AffineEnvironment.transform 4 17 env32062 = env32063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32062 == env32063) = true)

theorem identity32063 : scanCanonicalize (H12AffineFastState.compose env32063 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32063 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32064 : List Nat := [2,4,8,16,17,16,9,20,1,5,17,1,24,17,1,19,1,17,5,0,16,16,16,3,25,16,16,1,1,16,20,17,20,16,16,0]

theorem envBound32064 : H12AffineFastState.Bounded env32064 := by
  intro p hp
  have h : env32064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32063_32064 : H12AffineEnvironment.transform 8 1 env32063 = env32064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32063 == env32064) = true)

theorem identity32064 : scanCanonicalize (H12AffineFastState.compose env32064 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32065 : List Nat := [2,4,8,0,1,0,9,4,1,5,1,1,8,1,1,3,1,1,5,0,0,0,0,3,9,0,0,1,1,0,4,1,4,0,0,0]

theorem envBound32065 : H12AffineFastState.Bounded env32065 := by
  intro p hp
  have h : env32065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32064_32065 : H12AffineEnvironment.transform 3 0 env32064 = env32065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32064 == env32065) = true)

def env32066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound32066 : H12AffineFastState.Bounded env32066 := by
  intro p hp
  have h : env32066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31965_32066 : H12AffineEnvironment.transform 18 1025 env31965 = env32066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31965 == env32066) = true)

theorem identity32066 : scanCanonicalize (H12AffineFastState.compose env32066 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213453) := by decide +kernel

theorem selectedBound32066 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213453,8328,64,12878284,2278720,10507600,8830977,8570333,6431757,257,10650977,10642628,8643082]

theorem envBound32067 : H12AffineFastState.Bounded env32067 := by
  intro p hp
  have h : env32067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32066_32067 : H12AffineEnvironment.transform 23 213453 env32066 = env32067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213453 env32066 == env32067) = true)

def env32068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281536,213453,8328,64,6705548,2278720,165136,2363457,2102685,6431757,257,21793,46212,2175562]

theorem envBound32068 : H12AffineFastState.Bounded env32068 := by
  intro p hp
  have h : env32068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32067_32068 : H12AffineEnvironment.transform 22 2281536 env32067 = env32068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281536 env32067 == env32068) = true)

def env32069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590876,2098512,17664,2363457,2102685,6349853,257,21793,46212,2175562]

theorem envBound32069 : H12AffineFastState.Bounded env32069 := by
  intro p hp
  have h : env32069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32068_32069 : H12AffineEnvironment.transform 16 49168 env32068 = env32069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32068 == env32069) = true)

def env32070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144540,2098512,17664,2363457,2102685,2411677,257,21793,46212,2175562]

theorem envBound32070 : H12AffineFastState.Bounded env32070 := by
  intro p hp
  have h : env32070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32069_32070 : H12AffineEnvironment.transform 21 272512 env32069 = env32070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32069 == env32070) = true)

theorem identity32070 : scanCanonicalize (H12AffineFastState.compose env32070 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound32070 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272512,17,98781,8328,64,43357,5393,17664,262144,1500,318684,257,21793,46212,74251]

theorem envBound32071 : H12AffineFastState.Bounded env32071 := by
  intro p hp
  have h : env32071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32070_32071 : H12AffineEnvironment.transform 20 4161 env32070 = env32071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32070 == env32071) = true)

theorem identity32071 : scanCanonicalize (H12AffineFastState.compose env32071 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32071 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272512,17,41431,8328,64,43357,5393,17664,262144,1500,318684,257,21793,46212,513]

theorem envBound32072 : H12AffineFastState.Bounded env32072 := by
  intro p hp
  have h : env32072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32071_32072 : H12AffineEnvironment.transform 15 8202 env32071 = env32072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32071 == env32072) = true)

theorem identity32072 : scanCanonicalize (H12AffineFastState.compose env32072 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound32072 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35325,1025,32769,4161,41341,17,41431,8328,64,43357,5393,17664,35325,1500,21793,257,21793,46212,513]

theorem envBound32073 : H12AffineFastState.Bounded env32073 := by
  intro p hp
  have h : env32073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32072_32073 : H12AffineEnvironment.transform 17 35325 env32072 = env32073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env32072 == env32073) = true)

theorem identity32073 : scanCanonicalize (H12AffineFastState.compose env32073 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32073 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,342,49168,35325,1025,32769,4161,32801,17,32907,468,64,34817,5393,17664,35325,1500,21793,257,21793,38360,513]

theorem envBound32074 : H12AffineFastState.Bounded env32074 := by
  intro p hp
  have h : env32074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32073_32074 : H12AffineEnvironment.transform 12 348 env32073 = env32074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32073 == env32074) = true)

theorem identity32074 : scanCanonicalize (H12AffineFastState.compose env32074 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32074 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,35189,1025,32769,4161,32801,17,32771,348,64,34817,5393,17664,35189,1364,21793,257,21793,38224,513]

theorem envBound32075 : H12AffineFastState.Bounded env32075 := by
  intro p hp
  have h : env32075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32074_32075 : H12AffineEnvironment.transform 6 8 env32074 = env32075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32074 == env32075) = true)

theorem identity32075 : scanCanonicalize (H12AffineFastState.compose env32075 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound32075 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,5392,23669,1025,21761,4161,21793,17,21763,348,64,23809,5393,17664,23669,1364,21793,257,21793,16464,513]

theorem envBound32076 : H12AffineFastState.Bounded env32076 := by
  intro p hp
  have h : env32076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32075_32076 : H12AffineEnvironment.transform 14 21760 env32075 = env32076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env32075 == env32076) = true)

theorem identity32076 : scanCanonicalize (H12AffineFastState.compose env32076 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1025,0,4161,32,17,2,348,64,2048,5393,4097,2420,1364,32,257,32,5457,513]

theorem envBound32077 : H12AffineFastState.Bounded env32077 := by
  intro p hp
  have h : env32077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32076_32077 : H12AffineEnvironment.transform 13 5377 env32076 = env32077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32076 == env32077) = true)

theorem identity32077 : scanCanonicalize (H12AffineFastState.compose env32077 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32077 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32078 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4113,1,342,4096,2420,273,0,4161,32,17,2,348,64,2048,4097,4097,2420,68,32,257,32,4161,513]

theorem envBound32078 : H12AffineFastState.Bounded env32078 := by
  intro p hp
  have h : env32078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32077_32078 : H12AffineEnvironment.transform 9 272 env32077 = env32078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32077 == env32078) = true)

theorem identity32078 : scanCanonicalize (H12AffineFastState.compose env32078 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound32078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32079 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,64,348,81,1,342,64,2420,273,0,1,32,17,2,348,64,2048,65,65,2420,68,32,257,32,1,513]

theorem envBound32079 : H12AffineFastState.Bounded env32079 := by
  intro p hp
  have h : env32079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32078_32079 : H12AffineEnvironment.transform 11 64 env32078 = env32079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env32078 == env32079) = true)

theorem identity32079 : scanCanonicalize (H12AffineFastState.compose env32079 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32079 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32080 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,64,121,81,1,115,64,2129,52,0,1,32,17,2,121,64,2048,65,65,2129,68,32,36,32,1,513]

theorem envBound32080 : H12AffineFastState.Bounded env32080 := by
  intro p hp
  have h : env32080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32079_32080 : H12AffineEnvironment.transform 7 37 env32079 = env32080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32079 == env32080) = true)

theorem identity32080 : scanCanonicalize (H12AffineFastState.compose env32080 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32080 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32081 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,17,40,0,1,34,17,2048,52,0,1,32,17,2,40,17,2048,16,16,2048,21,32,36,32,1,513]

theorem envBound32081 : H12AffineFastState.Bounded env32081 := by
  intro p hp
  have h : env32081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32080_32081 : H12AffineEnvironment.transform 5 17 env32080 = env32081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32080 == env32081) = true)

theorem identity32081 : scanCanonicalize (H12AffineFastState.compose env32081 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound32081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32082 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,17,40,0,1,34,17,33,52,0,1,32,17,2,40,17,33,16,16,33,21,32,36,32,1,513]

theorem envBound32082 : H12AffineFastState.Bounded env32082 := by
  intro p hp
  have h : env32082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32081_32082 : H12AffineEnvironment.transform 10 33 env32081 = env32082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env32081 == env32082) = true)

theorem identity32082 : scanCanonicalize (H12AffineFastState.compose env32082 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32083 : List Nat := [2,4,8,16,16,17,8,21,512,5,17,17,24,0,1,18,17,17,4,0,1,16,17,2,24,17,17,16,16,17,21,16,20,16,1,513]

theorem envBound32083 : H12AffineFastState.Bounded env32083 := by
  intro p hp
  have h : env32083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32082_32083 : H12AffineEnvironment.transform 4 16 env32082 = env32083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32082 == env32083) = true)

theorem identity32083 : scanCanonicalize (H12AffineFastState.compose env32083 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32083 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32084 : List Nat := [2,4,8,0,0,1,8,5,512,5,1,1,8,0,1,2,1,1,4,0,1,0,1,2,8,1,1,0,0,1,5,0,4,0,1,513]

theorem envBound32084 : H12AffineFastState.Bounded env32084 := by
  intro p hp
  have h : env32084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32083_32084 : H12AffineEnvironment.transform 3 0 env32083 = env32084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32083 == env32084) = true)

def env32085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144541,2098512,17664,2363457,2102685,2411676,257,21793,46212,2175562]

theorem envBound32085 : H12AffineFastState.Bounded env32085 := by
  intro p hp
  have h : env32085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32069_32085 : H12AffineEnvironment.transform 21 272513 env32069 = env32085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32069 == env32085) = true)

def env32086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101328,98645,8192,64,2144541,2098512,17664,2363457,2102549,2411540,257,21793,46092,2175562]

theorem envBound32086 : H12AffineFastState.Bounded env32086 := by
  intro p hp
  have h : env32086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32085_32086 : H12AffineEnvironment.transform 6 8 env32085 = env32086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32085 == env32086) = true)

def env32087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,16,98645,8192,64,43357,5392,17664,262145,1365,318548,257,21793,46092,74250]

theorem envBound32087 : H12AffineFastState.Bounded env32087 := by
  intro p hp
  have h : env32087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32086_32087 : H12AffineEnvironment.transform 20 4160 env32086 = env32087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32086 == env32087) = true)

theorem identity32087 : scanCanonicalize (H12AffineFastState.compose env32087 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound32087 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130094,1025,32769,4160,119847,16,98645,8192,64,43357,5392,17664,130095,1365,73850,257,21793,46092,74250]

theorem envBound32088 : H12AffineFastState.Bounded env32088 := by
  intro p hp
  have h : env32088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32087_32088 : H12AffineEnvironment.transform 17 130094 env32087 = env32088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env32087 == env32088) = true)

theorem identity32088 : scanCanonicalize (H12AffineFastState.compose env32088 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32088 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,65536,46108,100386,1025,32769,4160,106539,16,98645,8192,64,43357,5392,12556,100387,1365,73850,257,8493,46092,74250]

theorem envBound32089 : H12AffineFastState.Bounded env32089 := by
  intro p hp
  have h : env32089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32088_32089 : H12AffineEnvironment.transform 13 13324 env32088 = env32089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32088 == env32089) = true)

theorem identity32089 : scanCanonicalize (H12AffineFastState.compose env32089 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32089 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env32090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,8203,46108,43049,1025,32769,4160,32800,16,41310,8192,64,43357,5392,12556,43048,1365,113,257,8493,46092,513]

theorem envBound32090 : H12AffineFastState.Bounded env32090 := by
  intro p hp
  have h : env32090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32089_32090 : H12AffineEnvironment.transform 15 8203 env32089 = env32090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32089 == env32090) = true)

theorem identity32090 : scanCanonicalize (H12AffineFastState.compose env32090 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32090 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,0,8203,13340,10281,1025,1,4160,32,16,8542,8192,64,10589,5392,12556,10280,1365,113,257,8493,13324,513]

theorem envBound32091 : H12AffineFastState.Bounded env32091 := by
  intro p hp
  have h : env32091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32090_32091 : H12AffineEnvironment.transform 14 0 env32090 = env32091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32090 == env32091) = true)

theorem identity32091 : scanCanonicalize (H12AffineFastState.compose env32091 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound32091 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,8192,13324,0,8203,13340,8460,1025,1,4160,32,16,8542,8192,64,8312,5392,12556,8461,1365,113,257,8493,13324,513]

theorem envBound32092 : H12AffineFastState.Bounded env32092 := by
  intro p hp
  have h : env32092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32091_32092 : H12AffineEnvironment.transform 10 293 env32091 = env32092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env32091 == env32092) = true)

theorem identity32092 : scanCanonicalize (H12AffineFastState.compose env32092 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound32092 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env32093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,5133,1,0,5126,17,5377,1025,1,4160,32,16,5459,5133,64,5237,5392,1281,5376,1365,113,257,5408,1,513]

theorem envBound32093 : H12AffineFastState.Bounded env32093 := by
  intro p hp
  have h : env32093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32092_32093 : H12AffineEnvironment.transform 12 5133 env32092 = env32093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env32092 == env32093) = true)

theorem identity32093 : scanCanonicalize (H12AffineFastState.compose env32093 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound32093 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env32094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,17,1052,1,0,1047,17,1296,1025,1,81,32,16,1346,1052,64,1124,1281,1281,1297,1365,113,257,1329,1,513]

theorem envBound32094 : H12AffineFastState.Bounded env32094 := by
  intro p hp
  have h : env32094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32093_32094 : H12AffineEnvironment.transform 11 17 env32093 = env32094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32093 == env32094) = true)

theorem identity32094 : scanCanonicalize (H12AffineFastState.compose env32094 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32094 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32095 : List Nat := [2,4,8,16,32,64,8,256,512,272,293,17,268,1,0,263,17,0,273,1,81,32,16,82,268,64,372,17,17,1,69,113,257,33,1,513]

theorem envBound32095 : H12AffineFastState.Bounded env32095 := by
  intro p hp
  have h : env32095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32094_32095 : H12AffineEnvironment.transform 9 272 env32094 = env32095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32094 == env32095) = true)

theorem identity32095 : scanCanonicalize (H12AffineFastState.compose env32095 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32095 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32096 : List Nat := [2,4,8,16,32,17,8,256,512,272,293,17,268,1,0,263,17,0,273,1,0,32,16,3,268,17,293,17,17,1,20,32,257,33,1,513]

theorem envBound32096 : H12AffineFastState.Bounded env32096 := by
  intro p hp
  have h : env32096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32095_32096 : H12AffineEnvironment.transform 5 17 env32095 = env32096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32095 == env32096) = true)

def env32097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,98645,8192,64,43356,5393,17664,262144,1364,318549,257,21793,46092,74251]

theorem envBound32097 : H12AffineFastState.Bounded env32097 := by
  intro p hp
  have h : env32097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32086_32097 : H12AffineEnvironment.transform 20 4161 env32086 = env32097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32086 == env32097) = true)

theorem identity32097 : scanCanonicalize (H12AffineFastState.compose env32097 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32097 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,33,17,98645,8192,64,43356,5393,17664,10280,1364,62589,257,21793,46092,74251]

theorem envBound32098 : H12AffineFastState.Bounded env32098 := by
  intro p hp
  have h : env32098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32097_32098 : H12AffineEnvironment.transform 17 10280 env32097 = env32098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32097 == env32098) = true)

theorem identity32098 : scanCanonicalize (H12AffineFastState.compose env32098 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32098 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env32099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10280,1025,8540,4161,33,17,73736,8192,64,2049,5393,17664,10280,1364,21792,257,21793,5457,74251]

theorem envBound32099 : H12AffineFastState.Bounded env32099 := by
  intro p hp
  have h : env32099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32098_32099 : H12AffineEnvironment.transform 14 8541 env32098 = env32099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32098 == env32099) = true)

theorem identity32099 : scanCanonicalize (H12AffineFastState.compose env32099 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound32099 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8283,24909,10280,1025,8540,4161,33,17,83,8192,64,2049,5393,17664,10280,1364,21792,257,21793,5457,592]

theorem envBound32100 : H12AffineFastState.Bounded env32100 := by
  intro p hp
  have h : env32100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32099_32100 : H12AffineEnvironment.transform 15 8283 env32099 = env32100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env32099 == env32100) = true)

theorem identity32100 : scanCanonicalize (H12AffineFastState.compose env32100 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32100 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,262,16400,2421,1025,1,4161,33,17,83,349,64,2049,5393,17664,2421,1364,21792,257,21793,5457,592]

theorem envBound32101 : H12AffineFastState.Bounded env32101 := by
  intro p hp
  have h : env32101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32100_32101 : H12AffineEnvironment.transform 12 349 env32100 = env32101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32100 == env32101) = true)

theorem identity32101 : scanCanonicalize (H12AffineFastState.compose env32101 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32101 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32102 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,16384,0,262,16400,2388,1025,1,4161,0,17,83,349,64,2049,5393,17664,2388,1364,21761,257,21760,5457,592]

theorem envBound32102 : H12AffineFastState.Bounded env32102 := by
  intro p hp
  have h : env32102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32101_32102 : H12AffineEnvironment.transform 4 1 env32101 = env32102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32101 == env32102) = true)

theorem identity32102 : scanCanonicalize (H12AffineFastState.compose env32102 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32102 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32103 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,268,16384,0,262,16400,2309,1025,1,4112,0,17,2,268,17,2049,5393,17664,2309,1285,21761,257,21760,5376,513]

theorem envBound32103 : H12AffineFastState.Bounded env32103 := by
  intro p hp
  have h : env32103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32102_32103 : H12AffineEnvironment.transform 5 17 env32102 = env32103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32102 == env32103) = true)

theorem identity32103 : scanCanonicalize (H12AffineFastState.compose env32103 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32103 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32104 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,2048,268,16384,0,262,16400,2309,1025,1,2064,0,17,2,268,17,2049,3345,17664,2309,1285,19713,257,19712,3328,513]

theorem envBound32104 : H12AffineFastState.Bounded env32104 := by
  intro p hp
  have h : env32104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32103_32104 : H12AffineEnvironment.transform 11 2048 env32103 = env32104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env32103 == env32104) = true)

theorem identity32104 : scanCanonicalize (H12AffineFastState.compose env32104 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound32104 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32105 : List Nat := [2,4,8,16,1,17,8,256,512,31,2048,2048,268,16384,0,262,16400,2309,30,1,2064,0,17,2,268,17,2049,2318,16671,2309,282,18718,257,18719,2335,513]

theorem envBound32105 : H12AffineFastState.Bounded env32105 := by
  intro p hp
  have h : env32105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32104_32105 : H12AffineEnvironment.transform 9 31 env32104 = env32105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env32104 == env32105) = true)

theorem identity32105 : scanCanonicalize (H12AffineFastState.compose env32105 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 2334) := by decide +kernel

theorem selectedBound32105 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32106 : List Nat := [2,4,8,16,1,17,8,256,512,31,2048,2048,268,2334,0,262,2318,2309,30,1,2064,0,17,2,268,17,2049,2318,2049,2309,282,0,257,1,2335,513]

theorem envBound32106 : H12AffineFastState.Bounded env32106 := by
  intro p hp
  have h : env32106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32105_32106 : H12AffineEnvironment.transform 13 2334 env32105 = env32106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2334 env32105 == env32106) = true)

theorem identity32106 : scanCanonicalize (H12AffineFastState.compose env32106 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32107 : List Nat := [2,4,8,10,1,11,8,256,512,5,2048,2048,268,2308,0,262,2318,2309,4,1,2058,0,11,2,268,11,2049,2318,2049,2309,256,0,257,1,2309,513]

theorem envBound32107 : H12AffineFastState.Bounded env32107 := by
  intro p hp
  have h : env32107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32106_32107 : H12AffineEnvironment.transform 3 10 env32106 = env32107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32106 == env32107) = true)

theorem identity32107 : scanCanonicalize (H12AffineFastState.compose env32107 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound32107 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32108 : List Nat := [2,4,8,10,1,11,8,14,512,5,2048,2048,2,2058,0,8,2048,2059,4,1,2058,0,11,2,2,11,2049,2048,2049,2059,14,0,15,1,2059,513]

theorem envBound32108 : H12AffineFastState.Bounded env32108 := by
  intro p hp
  have h : env32108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32107_32108 : H12AffineEnvironment.transform 7 14 env32107 = env32108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env32107 == env32108) = true)

theorem identity32108 : scanCanonicalize (H12AffineFastState.compose env32108 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 514) := by decide +kernel

theorem selectedBound32108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32109 : List Nat := [2,4,8,10,1,11,8,14,512,5,514,514,2,520,0,8,514,521,4,1,520,0,11,2,2,11,515,514,515,521,14,0,15,1,521,513]

theorem envBound32109 : H12AffineFastState.Bounded env32109 := by
  intro p hp
  have h : env32109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32108_32109 : H12AffineEnvironment.transform 10 514 env32108 = env32109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 514 env32108 == env32109) = true)

theorem identity32109 : scanCanonicalize (H12AffineFastState.compose env32109 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound32109 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32110 : List Nat := [2,4,8,10,1,11,8,14,11,5,9,9,2,3,0,8,9,2,4,1,3,0,11,2,2,11,8,9,8,2,14,0,15,1,2,10]

theorem envBound32110 : H12AffineFastState.Bounded env32110 := by
  intro p hp
  have h : env32110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32109_32110 : H12AffineEnvironment.transform 8 11 env32109 = env32110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env32109 == env32110) = true)

theorem identity32110 : scanCanonicalize (H12AffineFastState.compose env32110 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32110 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32111 : List Nat := [0,4,8,8,1,9,8,12,9,5,9,9,0,1,0,8,9,0,4,1,1,0,9,0,0,9,8,9,8,0,12,0,13,1,0,8]

theorem envBound32111 : H12AffineFastState.Bounded env32111 := by
  intro p hp
  have h : env32111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32110_32111 : H12AffineEnvironment.transform 0 0 env32110 = env32111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32110 == env32111) = true)

theorem identity32111 : scanCanonicalize (H12AffineFastState.compose env32111 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32112 : List Nat := [0,4,5,5,1,4,5,1,4,5,4,4,0,1,0,5,4,0,4,1,1,0,4,0,0,4,5,4,5,0,1,0,0,1,0,5]

theorem envBound32112 : H12AffineFastState.Bounded env32112 := by
  intro p hp
  have h : env32112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32111_32112 : H12AffineEnvironment.transform 2 5 env32111 = env32112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32111 == env32112) = true)

def env32113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101328,98644,8193,64,2144541,2098512,17664,2363457,2102548,2411541,257,21793,46093,2175562]

theorem envBound32113 : H12AffineFastState.Bounded env32113 := by
  intro p hp
  have h : env32113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32085_32113 : H12AffineEnvironment.transform 6 9 env32085 = env32113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32085 == env32113) = true)

theorem identity32113 : scanCanonicalize (H12AffineFastState.compose env32113 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 110667) := by decide +kernel

theorem selectedBound32113 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env32114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,110667,272392,106523,98644,8193,64,67926,111899,17664,368650,107871,359518,257,21793,46093,33281]

theorem envBound32114 : H12AffineFastState.Bounded env32114 := by
  intro p hp
  have h : env32114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32113_32114 : H12AffineEnvironment.transform 20 110667 env32113 = env32114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110667 env32113 == env32114) = true)

theorem identity32114 : scanCanonicalize (H12AffineFastState.compose env32114 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32114 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,49168,262144,1025,32769,102679,264532,98631,98644,349,64,67926,103495,17664,360790,99331,351490,257,21793,38225,33281]

theorem envBound32115 : H12AffineFastState.Bounded env32115 := by
  intro p hp
  have h : env32115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32114_32115 : H12AffineEnvironment.transform 12 348 env32114 = env32115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32114 == env32115) = true)

theorem identity32115 : scanCanonicalize (H12AffineFastState.compose env32115 (packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound32115 : packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54279,49168,262144,1025,32769,17680,264532,21824,21843,349,64,56657,16448,17664,283985,20484,297221,257,21793,38225,33281]

theorem envBound32116 : H12AffineFastState.Bounded env32116 := by
  intro p hp
  have h : env32116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32115_32116 : H12AffineEnvironment.transform 15 54279 env32115 = env32116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env32115 == env32116) = true)

theorem identity32116 : scanCanonicalize (H12AffineFastState.compose env32116 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound32116 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env32117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,33111,38208,262144,1025,32769,4160,264532,16,3,349,64,34817,5392,4176,262145,1364,297221,257,113,38225,33281]

theorem envBound32117 : H12AffineFastState.Bounded env32117 := by
  intro p hp
  have h : env32117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32116_32117 : H12AffineEnvironment.transform 13 5456 env32116 = env32117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env32116 == env32117) = true)

theorem identity32117 : scanCanonicalize (H12AffineFastState.compose env32117 (packedSelected [0,1,2,4,6,7,8,9,10,12,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 36113) := by decide +kernel

theorem selectedBound32117 : packedSelected [0,1,2,4,6,7,8,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,33111,38208,36113,1025,32769,4160,33861,16,3,349,64,34817,5392,4176,36112,1364,1044,257,113,38225,33281]

theorem envBound32118 : H12AffineFastState.Bounded env32118 := by
  intro p hp
  have h : env32118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32117_32118 : H12AffineEnvironment.transform 17 36113 env32117 = env32118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 36113 env32117 == env32118) = true)

theorem identity32118 : scanCanonicalize (H12AffineFastState.compose env32118 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32118 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,0,343,5440,3345,1025,1,4160,1093,16,3,349,64,2049,5392,4176,3344,1364,1044,257,113,5457,513]

theorem envBound32119 : H12AffineFastState.Bounded env32119 := by
  intro p hp
  have h : env32119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32118_32119 : H12AffineEnvironment.transform 14 0 env32118 = env32119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32118 == env32119) = true)

theorem identity32119 : scanCanonicalize (H12AffineFastState.compose env32119 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32119 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env32120 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,348,4112,0,343,4096,2129,321,1,4160,261,16,3,349,64,2049,4176,4176,2128,20,340,257,113,4113,513]

theorem envBound32120 : H12AffineFastState.Bounded env32120 := by
  intro p hp
  have h : env32120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32119_32120 : H12AffineEnvironment.transform 9 320 env32119 = env32120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32119 == env32120) = true)

theorem identity32120 : scanCanonicalize (H12AffineFastState.compose env32120 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32120 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32121 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4112,0,262,4096,2048,272,1,4113,261,16,3,268,17,2049,4097,4097,2049,20,261,257,32,4113,513]

theorem envBound32121 : H12AffineFastState.Bounded env32121 := by
  intro p hp
  have h : env32121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32120_32121 : H12AffineEnvironment.transform 5 17 env32120 = env32121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32120 == env32121) = true)

theorem identity32121 : scanCanonicalize (H12AffineFastState.compose env32121 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32122 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,269,16,0,262,0,2048,272,1,17,261,16,3,268,17,2049,1,1,2049,20,261,257,32,17,513]

theorem envBound32122 : H12AffineFastState.Bounded env32122 := by
  intro p hp
  have h : env32122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32121_32122 : H12AffineEnvironment.transform 11 0 env32121 = env32122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32121 == env32122) = true)

theorem identity32122 : scanCanonicalize (H12AffineFastState.compose env32122 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound32122 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32123 : List Nat := [2,4,8,16,32,17,9,256,512,273,555,0,269,16,0,262,0,555,272,1,17,261,16,3,268,17,554,1,1,554,20,261,257,32,17,513]

theorem envBound32123 : H12AffineFastState.Bounded env32123 := by
  intro p hp
  have h : env32123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32122_32123 : H12AffineEnvironment.transform 10 555 env32122 = env32123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env32122 == env32123) = true)

def env32124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590877,2098513,17665,2363457,2102685,6349852,257,21793,46212,2175562]

theorem envBound32124 : H12AffineFastState.Bounded env32124 := by
  intro p hp
  have h : env32124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32068_32124 : H12AffineEnvironment.transform 16 49169 env32068 = env32124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32068 == env32124) = true)

def env32125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144541,2098513,17665,2363457,2102685,2411676,257,21793,46212,2175562]

theorem envBound32125 : H12AffineFastState.Bounded env32125 := by
  intro p hp
  have h : env32125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32124_32125 : H12AffineEnvironment.transform 21 272512 env32124 = env32125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32124 == env32125) = true)

theorem identity32125 : scanCanonicalize (H12AffineFastState.compose env32125 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound32125 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272512,62661,98780,8328,64,23945,57797,17665,324821,61705,272392,257,21793,46212,120542]

theorem envBound32126 : H12AffineFastState.Bounded env32126 := by
  intro p hp
  have h : env32126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32125_32126 : H12AffineEnvironment.transform 20 58516 env32125 = env32126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env32125 == env32126) = true)

def env32127 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272512,62613,98700,8328,16,23945,57749,17665,324741,61705,272392,257,21793,46212,120462]

theorem envBound32127 : H12AffineFastState.Bounded env32127 := by
  intro p hp
  have h : env32127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32126_32127 : H12AffineEnvironment.transform 5 16 env32126 = env32127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32126 == env32127) = true)

theorem identity32127 : scanCanonicalize (H12AffineFastState.compose env32127 (packedSelected [10,15,17,19,26,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32127 : packedSelected [10,15,17,19,26,31,38] rootPS < 2^1333 := by decide +kernel

def env32128 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58516,168,62613,98700,8328,16,23945,57749,17665,56493,61705,32,257,21793,46212,120462]

theorem envBound32128 : H12AffineFastState.Bounded env32128 := by
  intro p hp
  have h : env32128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32127_32128 : H12AffineEnvironment.transform 17 10280 env32127 = env32128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32127 == env32128) = true)

theorem identity32128 : scanCanonicalize (H12AffineFastState.compose env32128 (packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound32128 : packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env32129 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10280,1025,32769,58516,168,62613,8582,8328,16,23945,57749,17665,56493,61705,32,257,21793,46212,30340]

theorem envBound32129 : H12AffineFastState.Bounded env32129 := by
  intro p hp
  have h : env32129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32128_32129 : H12AffineEnvironment.transform 15 40970 env32128 = env32129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env32128 == env32129) = true)

theorem identity32129 : scanCanonicalize (H12AffineFastState.compose env32129 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32129 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32130 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,32768,40970,46108,10280,1025,32769,37017,168,32920,8582,8328,16,10628,38296,12556,43168,34052,32,257,8492,46212,649]

theorem envBound32130 : H12AffineFastState.Bounded env32130 := by
  intro p hp
  have h : env32130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32129_32130 : H12AffineEnvironment.transform 13 13325 env32129 = env32130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32129 == env32130) = true)

theorem identity32130 : scanCanonicalize (H12AffineFastState.compose env32130 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32130 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32131 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,1,8203,13341,10280,1025,0,4248,168,153,8582,8328,16,10628,5529,12556,10401,1285,32,257,8492,13445,649]

theorem envBound32131 : H12AffineFastState.Bounded env32131 := by
  intro p hp
  have h : env32131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32130_32131 : H12AffineEnvironment.transform 14 1 env32130 = env32131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32130 == env32131) = true)

theorem identity32131 : scanCanonicalize (H12AffineFastState.compose env32131 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32131 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32132 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,8203,13341,10280,1025,0,4112,32,17,8462,8192,16,10508,5393,12556,10281,1285,32,257,8492,13325,513]

theorem envBound32132 : H12AffineFastState.Bounded env32132 := by
  intro p hp
  have h : env32132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32131_32132 : H12AffineEnvironment.transform 6 8 env32131 = env32132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32131 == env32132) = true)

theorem identity32132 : scanCanonicalize (H12AffineFastState.compose env32132 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound32132 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32133 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,8192,11069,1,8203,11053,10280,1025,0,3872,32,17,8462,8192,16,10508,2593,11836,10281,1285,32,257,8492,11069,513]

theorem envBound32133 : H12AffineFastState.Bounded env32133 := by
  intro p hp
  have h : env32133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32132_32133 : H12AffineEnvironment.transform 11 3888 env32132 = env32133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env32132 == env32133) = true)

theorem identity32133 : scanCanonicalize (H12AffineFastState.compose env32133 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32134 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2608,1,262,2592,2341,1025,0,3872,32,17,3,269,16,2049,2593,3889,2340,1285,32,257,33,2608,513]

theorem envBound32134 : H12AffineFastState.Bounded env32134 := by
  intro p hp
  have h : env32134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32133_32134 : H12AffineEnvironment.transform 12 269 env32133 = env32134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32133 == env32134) = true)

theorem identity32134 : scanCanonicalize (H12AffineFastState.compose env32134 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound32134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32135 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1589,261,269,1029,1,262,1045,1808,1025,0,277,32,17,3,269,16,1588,1044,260,1809,1285,32,257,33,1029,513]

theorem envBound32135 : H12AffineFastState.Bounded env32135 := by
  intro p hp
  have h : env32135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32134_32135 : H12AffineEnvironment.transform 10 1589 env32134 = env32135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env32134 == env32135) = true)

theorem identity32135 : scanCanonicalize (H12AffineFastState.compose env32135 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound32135 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32136 : List Nat := [2,4,8,16,32,16,8,256,512,785,292,261,269,788,1,262,772,1,784,0,277,32,17,3,269,16,293,773,260,0,532,32,257,33,788,513]

theorem envBound32136 : H12AffineFastState.Bounded env32136 := by
  intro p hp
  have h : env32136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32135_32136 : H12AffineEnvironment.transform 9 785 env32135 = env32136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env32135 == env32136) = true)

theorem identity32136 : scanCanonicalize (H12AffineFastState.compose env32136 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32136 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32137 : List Nat := [2,4,8,0,32,0,8,256,512,769,292,261,269,772,1,262,772,1,768,0,261,32,1,3,269,0,293,773,260,0,516,32,257,33,772,513]

theorem envBound32137 : H12AffineFastState.Bounded env32137 := by
  intro p hp
  have h : env32137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32136_32137 : H12AffineEnvironment.transform 3 0 env32136 = env32137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32136 == env32137) = true)

theorem identity32137 : scanCanonicalize (H12AffineFastState.compose env32137 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound32137 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32138 : List Nat := [2,4,8,0,32,0,8,256,260,5,292,261,269,0,1,262,0,1,4,0,261,32,1,3,269,0,293,1,260,0,256,32,257,33,0,261]

theorem envBound32138 : H12AffineFastState.Bounded env32138 := by
  intro p hp
  have h : env32138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32137_32138 : H12AffineEnvironment.transform 8 260 env32137 = env32138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env32137 == env32138) = true)

def env32139 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58516,272512,62612,98701,8328,17,23945,57748,17665,324740,61705,272392,257,21793,46212,120463]

theorem envBound32139 : H12AffineFastState.Bounded env32139 := by
  intro p hp
  have h : env32139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32126_32139 : H12AffineEnvironment.transform 5 17 env32126 = env32139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32126 == env32139) = true)

def env32140 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,62492,98565,8192,17,23809,57628,17665,324620,61705,272392,257,21793,46092,120327]

theorem envBound32140 : H12AffineFastState.Bounded env32140 := by
  intro p hp
  have h : env32140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32139_32140 : H12AffineEnvironment.transform 6 8 env32139 = env32140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32139 == env32140) = true)

theorem identity32140 : scanCanonicalize (H12AffineFastState.compose env32140 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound32140 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env32141 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,58396,21792,62492,98565,8192,17,23809,57628,17665,35108,61705,21792,257,21793,46092,120327]

theorem envBound32141 : H12AffineFastState.Bounded env32141 := by
  intro p hp
  have h : env32141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32140_32141 : H12AffineEnvironment.transform 17 32040 env32140 = env32141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env32140 == env32141) = true)

theorem identity32141 : scanCanonicalize (H12AffineFastState.compose env32141 (packedSelected [0,4,7,17,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound32141 : packedSelected [0,4,7,17,19,22,26] rootPS < 2^1333 := by decide +kernel

def env32142 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,62730,49169,32040,1025,32769,58396,21792,62492,29711,8192,17,23809,57628,17665,35108,61705,21792,257,21793,46092,8973]

theorem envBound32142 : H12AffineFastState.Bounded env32142 := by
  intro p hp
  have h : env32142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32141_32142 : H12AffineEnvironment.transform 15 62730 env32141 = env32142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env32141 == env32142) = true)

theorem identity32142 : scanCanonicalize (H12AffineFastState.compose env32142 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32142 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env32143 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,33030,46109,2340,1025,32769,36880,8492,32784,3,8192,17,10509,38160,12557,35108,34053,8492,257,8493,46092,8973]

theorem envBound32143 : H12AffineFastState.Bounded env32143 := by
  intro p hp
  have h : env32143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32142_32143 : H12AffineEnvironment.transform 13 13324 env32142 = env32143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32142 == env32143) = true)

theorem identity32143 : scanCanonicalize (H12AffineFastState.compose env32143 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32143 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env32144 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,32768,33030,38161,2340,1025,32769,36880,32,32784,3,268,17,2049,38160,4097,35108,34053,32,257,33,38144,513]

theorem envBound32144 : H12AffineFastState.Bounded env32144 := by
  intro p hp
  have h : env32144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32143_32144 : H12AffineEnvironment.transform 12 268 env32143 = env32144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32143 == env32144) = true)

theorem identity32144 : scanCanonicalize (H12AffineFastState.compose env32144 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32144 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32145 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1025,1,4112,32,16,3,268,17,2049,5392,4097,2340,1285,32,257,33,5376,513]

theorem envBound32145 : H12AffineFastState.Bounded env32145 := by
  intro p hp
  have h : env32145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32144_32145 : H12AffineEnvironment.transform 14 0 env32144 = env32145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32144 == env32145) = true)

theorem identity32145 : scanCanonicalize (H12AffineFastState.compose env32145 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound32145 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32146 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,4096,56,5172,0,50,5157,2064,1025,1,4112,32,16,3,56,17,2049,5156,4097,2064,1073,32,53,33,5172,513]

theorem envBound32146 : H12AffineFastState.Bounded env32146 := by
  intro p hp
  have h : env32146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32145_32146 : H12AffineEnvironment.transform 7 52 env32145 = env32146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env32145 == env32146) = true)

theorem identity32146 : scanCanonicalize (H12AffineFastState.compose env32146 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound32146 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32147 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,1573,56,529,0,50,512,2064,1025,1,1589,32,16,3,56,17,2049,513,1572,2064,1073,32,53,33,529,513]

theorem envBound32147 : H12AffineFastState.Bounded env32147 := by
  intro p hp
  have h : env32147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32146_32147 : H12AffineEnvironment.transform 11 1573 env32146 = env32147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env32146 == env32147) = true)

theorem identity32147 : scanCanonicalize (H12AffineFastState.compose env32147 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound32147 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32148 : List Nat := [2,4,8,16,32,17,8,52,512,1024,1588,1573,56,529,0,50,512,1572,1025,1,1589,32,16,3,56,17,1589,513,1572,1572,1073,32,53,33,529,513]

theorem envBound32148 : H12AffineFastState.Bounded env32148 := by
  intro p hp
  have h : env32148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32147_32148 : H12AffineEnvironment.transform 10 1588 env32147 = env32148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env32147 == env32148) = true)

theorem identity32148 : scanCanonicalize (H12AffineFastState.compose env32148 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32148 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32149 : List Nat := [2,4,8,16,32,17,8,52,512,52,512,529,56,529,0,50,512,528,53,1,513,32,16,3,56,17,513,513,528,528,5,32,53,33,529,513]

theorem envBound32149 : H12AffineFastState.Bounded env32149 := by
  intro p hp
  have h : env32149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32148_32149 : H12AffineEnvironment.transform 9 52 env32148 = env32149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32148 == env32149) = true)

theorem identity32149 : scanCanonicalize (H12AffineFastState.compose env32149 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32149 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32150 : List Nat := [2,4,8,0,32,1,8,36,512,36,512,513,40,513,0,34,512,512,37,1,513,32,0,3,40,1,513,513,512,512,5,32,37,33,513,513]

theorem envBound32150 : H12AffineFastState.Bounded env32150 := by
  intro p hp
  have h : env32150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32149_32150 : H12AffineEnvironment.transform 3 0 env32149 = env32150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32149 == env32150) = true)

theorem identity32150 : scanCanonicalize (H12AffineFastState.compose env32150 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32151 : List Nat := [2,4,8,0,0,1,8,4,512,4,512,513,8,513,0,2,512,512,5,1,513,0,0,3,8,1,513,513,512,512,5,0,5,1,513,513]

theorem envBound32151 : H12AffineFastState.Bounded env32151 := by
  intro p hp
  have h : env32151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32150_32151 : H12AffineEnvironment.transform 4 0 env32150 = env32151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32150 == env32151) = true)

def env32152 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,62493,98564,8193,17,23808,57629,17665,324621,61705,272392,257,21793,46093,120326]

theorem envBound32152 : H12AffineFastState.Bounded env32152 := by
  intro p hp
  have h : env32152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32139_32152 : H12AffineEnvironment.transform 6 9 env32139 = env32152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32139 == env32152) = true)

theorem identity32152 : scanCanonicalize (H12AffineFastState.compose env32152 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound32152 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env32153 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,97326,1025,32769,58397,87079,62493,98564,8193,17,23808,57629,17665,100387,61705,87078,257,21793,46093,120326]

theorem envBound32153 : H12AffineFastState.Bounded env32153 := by
  intro p hp
  have h : env32153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32152_32153 : H12AffineEnvironment.transform 17 97326 env32152 = env32153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env32152 == env32153) = true)

theorem identity32153 : scanCanonicalize (H12AffineFastState.compose env32153 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32153 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32154 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,65536,49169,89379,1025,32769,50448,87079,54544,98564,268,17,23808,49168,17665,100387,53252,87078,257,21793,38144,120326]

theorem envBound32154 : H12AffineFastState.Bounded env32154 := by
  intro p hp
  have h : env32154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32153_32154 : H12AffineEnvironment.transform 12 269 env32153 = env32154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32153 == env32154) = true)

theorem identity32154 : scanCanonicalize (H12AffineFastState.compose env32154 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound32154 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32155 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21540,65536,5173,89379,1025,21541,4404,87079,308,87328,268,17,23808,5172,17665,89095,1056,87078,257,21793,16676,66082]

theorem envBound32155 : H12AffineFastState.Bounded env32155 := by
  intro p hp
  have h : env32155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32154_32155 : H12AffineEnvironment.transform 14 21540 env32154 = env32155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env32154 == env32155) = true)

theorem identity32155 : scanCanonicalize (H12AffineFastState.compose env32155 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound32155 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env32156 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21540,21510,5173,2341,1025,21541,4404,33,308,294,268,17,23808,5172,17665,2049,1056,32,257,21793,16676,22052]

theorem envBound32156 : H12AffineFastState.Bounded env32156 := by
  intro p hp
  have h : env32156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32155_32156 : H12AffineEnvironment.transform 15 21510 env32155 = env32156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env32155 == env32156) = true)

theorem identity32156 : scanCanonicalize (H12AffineFastState.compose env32156 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32156 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32157 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,292,262,5173,2341,1025,293,4404,33,308,294,268,17,2048,5172,4097,2049,1056,32,257,33,5156,804]

theorem envBound32157 : H12AffineFastState.Bounded env32157 := by
  intro p hp
  have h : env32157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32156_32157 : H12AffineEnvironment.transform 13 5376 env32156 = env32157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32156 == env32157) = true)

theorem identity32157 : scanCanonicalize (H12AffineFastState.compose env32157 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound32157 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32158 : List Nat := [2,4,8,16,32,17,9,256,512,1024,789,4096,269,5376,292,262,5173,560,1025,293,4404,33,308,294,268,17,789,5172,4097,788,1056,32,257,33,5156,804]

theorem envBound32158 : H12AffineFastState.Bounded env32158 := by
  intro p hp
  have h : env32158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32157_32158 : H12AffineEnvironment.transform 10 789 env32157 = env32158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env32157 == env32158) = true)

theorem identity32158 : scanCanonicalize (H12AffineFastState.compose env32158 (packedSelected [3,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound32158 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env32159 : List Nat := [2,4,8,16,32,17,9,256,512,36,789,4096,269,4388,292,262,4113,560,37,293,4404,33,308,294,268,17,789,4112,4097,788,4,32,257,33,4096,804]

theorem envBound32159 : H12AffineFastState.Bounded env32159 := by
  intro p hp
  have h : env32159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32158_32159 : H12AffineEnvironment.transform 9 36 env32158 = env32159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env32158 == env32159) = true)

theorem identity32159 : scanCanonicalize (H12AffineFastState.compose env32159 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32159 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32160 : List Nat := [2,4,8,16,32,17,9,5,512,36,528,4096,8,4129,33,3,4113,560,37,32,4145,33,49,35,9,17,528,4112,4097,529,4,32,4,33,4096,545]

theorem envBound32160 : H12AffineFastState.Bounded env32160 := by
  intro p hp
  have h : env32160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32159_32160 : H12AffineEnvironment.transform 7 5 env32159 = env32160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32159 == env32160) = true)

theorem identity32160 : scanCanonicalize (H12AffineFastState.compose env32160 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32160 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32161 : List Nat := [2,4,8,16,0,17,9,5,512,4,528,4096,8,4097,1,3,4113,528,5,0,4113,1,17,3,9,17,528,4112,4097,529,4,0,4,1,4096,513]

theorem envBound32161 : H12AffineFastState.Bounded env32161 := by
  intro p hp
  have h : env32161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32160_32161 : H12AffineEnvironment.transform 4 0 env32160 = env32161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32160 == env32161) = true)

theorem identity32161 : scanCanonicalize (H12AffineFastState.compose env32161 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32161 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32162 : List Nat := [2,4,8,16,0,17,9,5,512,4,528,0,8,1,1,3,17,528,5,0,17,1,17,3,9,17,528,16,1,529,4,0,4,1,0,513]

theorem envBound32162 : H12AffineFastState.Bounded env32162 := by
  intro p hp
  have h : env32162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32161_32162 : H12AffineEnvironment.transform 11 0 env32161 = env32162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32161 == env32162) = true)

theorem identity32162 : scanCanonicalize (H12AffineFastState.compose env32162 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound32162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32163 : List Nat := [2,4,8,16,0,17,9,5,17,4,1,0,8,1,1,3,17,1,5,0,17,1,17,3,9,17,1,16,1,0,4,0,4,1,0,16]

theorem envBound32163 : H12AffineFastState.Bounded env32163 := by
  intro p hp
  have h : env32163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32162_32163 : H12AffineEnvironment.transform 8 17 env32162 = env32163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env32162 == env32163) = true)

def env32164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144540,2098513,17665,2363457,2102685,2411677,257,21793,46212,2175562]

theorem envBound32164 : H12AffineFastState.Bounded env32164 := by
  intro p hp
  have h : env32164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32124_32164 : H12AffineEnvironment.transform 21 272513 env32124 = env32164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32124 == env32164) = true)

theorem identity32164 : scanCanonicalize (H12AffineFastState.compose env32164 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32164 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,262144,1025,29909,2097152,272513,2101329,95496,8328,64,2117064,2098513,17665,2363457,2102685,2373705,257,21793,16464,2175562]

theorem envBound32165 : H12AffineFastState.Bounded env32165 := by
  intro p hp
  have h : env32165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32164_32165 : H12AffineEnvironment.transform 14 29908 env32164 = env32165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32164 == env32165) = true)

def env32166 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,262144,1025,29789,2097152,272393,2101329,95496,8192,64,2116928,2098513,17665,2363457,2102549,2373705,257,21793,16464,2175562]

theorem envBound32166 : H12AffineFastState.Bounded env32166 := by
  intro p hp
  have h : env32166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32165_32166 : H12AffineEnvironment.transform 6 8 env32165 = env32166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32165 == env32166) = true)

theorem identity32166 : scanCanonicalize (H12AffineFastState.compose env32166 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound32166 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env32167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,2420,1025,29789,2097152,8573,2101329,95496,8192,64,2116928,2098513,17665,2103605,2102549,2109757,257,21793,16464,2175562]

theorem envBound32167 : H12AffineFastState.Bounded env32167 := by
  intro p hp
  have h : env32167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32166_32167 : H12AffineEnvironment.transform 17 2420 env32166 = env32167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env32166 == env32167) = true)

theorem identity32167 : scanCanonicalize (H12AffineFastState.compose env32167 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound32167 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env32168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,2420,1025,29789,12572,8573,8525,95496,8192,64,31836,13389,17665,10281,9225,33,257,21793,16464,66390]

theorem envBound32168 : H12AffineFastState.Bounded env32168 := by
  intro p hp
  have h : env32168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32167_32168 : H12AffineEnvironment.transform 20 12572 env32167 = env32168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env32167 == env32168) = true)

theorem identity32168 : scanCanonicalize (H12AffineFastState.compose env32168 (packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound32168 : packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env32169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,65536,13389,2420,1025,8461,12572,8573,8525,73816,8192,64,10508,13389,4177,10281,9225,33,257,113,5376,66390]

theorem envBound32169 : H12AffineFastState.Bounded env32169 := by
  intro p hp
  have h : env32169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32168_32169 : H12AffineEnvironment.transform 13 5456 env32168 = env32169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env32168 == env32169) = true)

theorem identity32169 : scanCanonicalize (H12AffineFastState.compose env32169 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound32169 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env32170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8282,13389,2420,1025,8461,12572,8573,8525,2,8192,64,10508,13389,4177,10281,9225,33,257,113,5376,8972]

theorem envBound32170 : H12AffineFastState.Bounded env32170 := by
  intro p hp
  have h : env32170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32169_32170 : H12AffineEnvironment.transform 15 8282 env32169 = env32170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env32169 == env32170) = true)

theorem identity32170 : scanCanonicalize (H12AffineFastState.compose env32170 (packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32170 : packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env32171 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,8233,8282,13389,2129,1025,8232,12345,8280,8296,2,8192,64,10281,13389,4177,10281,9225,33,36,113,5157,8745]

theorem envBound32171 : H12AffineFastState.Bounded env32171 := by
  intro p hp
  have h : env32171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32170_32171 : H12AffineEnvironment.transform 7 37 env32170 = env32171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32170 == env32171) = true)

theorem identity32171 : scanCanonicalize (H12AffineFastState.compose env32171 (packedSelected [2,3,4,5,6,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound32171 : packedSelected [2,3,4,5,6,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32172 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1053,5237,1076,1095,4176,2129,1025,1077,5156,1093,1141,2,1053,64,3124,4176,4177,3124,20,33,36,113,5157,1588]

theorem envBound32172 : H12AffineFastState.Bounded env32172 := by
  intro p hp
  have h : env32172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32171_32172 : H12AffineEnvironment.transform 12 1053 env32171 = env32172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env32171 == env32172) = true)

theorem identity32172 : scanCanonicalize (H12AffineFastState.compose env32172 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32172 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env32173 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,1053,5156,1076,1046,4097,2048,1025,1077,5156,1044,1060,2,1053,17,3124,4097,4096,3124,20,33,36,32,5157,1588]

theorem envBound32173 : H12AffineFastState.Bounded env32173 := by
  intro p hp
  have h : env32173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32172_32173 : H12AffineEnvironment.transform 5 17 env32172 = env32173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32172 == env32173) = true)

theorem identity32173 : scanCanonicalize (H12AffineFastState.compose env32173 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound32173 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32174 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,1053,3125,1076,1046,2064,2048,1025,1077,3125,1044,1060,2,1053,17,3124,2064,2065,3124,20,33,36,32,3124,1588]

theorem envBound32174 : H12AffineFastState.Bounded env32174 := by
  intro p hp
  have h : env32174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32173_32174 : H12AffineEnvironment.transform 11 2065 env32173 = env32174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env32173 == env32174) = true)

theorem identity32174 : scanCanonicalize (H12AffineFastState.compose env32174 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32174 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env32175 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2049,0,34,2064,2048,53,1,2049,32,16,2,41,17,2048,2064,2065,2048,20,33,36,32,2048,512]

theorem envBound32175 : H12AffineFastState.Bounded env32175 := by
  intro p hp
  have h : env32175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32174_32175 : H12AffineEnvironment.transform 9 52 env32174 = env32175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32174 == env32175) = true)

theorem identity32175 : scanCanonicalize (H12AffineFastState.compose env32175 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32176 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,2065,9,2049,0,2,2064,2048,21,1,2049,0,16,2,9,17,2048,2064,2065,2048,20,1,4,0,2048,512]

theorem envBound32176 : H12AffineFastState.Bounded env32176 := by
  intro p hp
  have h : env32176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32175_32176 : H12AffineEnvironment.transform 4 0 env32175 = env32176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32175 == env32176) = true)

theorem identity32176 : scanCanonicalize (H12AffineFastState.compose env32176 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound32176 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32177 : List Nat := [2,4,8,16,0,17,8,5,512,20,5,20,9,4,0,2,21,5,21,1,4,0,16,2,9,17,5,21,20,5,20,1,4,0,5,512]

theorem envBound32177 : H12AffineFastState.Bounded env32177 := by
  intro p hp
  have h : env32177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32176_32177 : H12AffineEnvironment.transform 10 5 env32176 = env32177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env32176 == env32177) = true)

def env32178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,2097152,272392,2101329,95496,8193,64,2116929,2098513,17665,2363457,2102548,2373705,257,21793,16464,2175562]

theorem envBound32178 : H12AffineFastState.Bounded env32178 := by
  intro p hp
  have h : env32178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32165_32178 : H12AffineEnvironment.transform 6 9 env32165 = env32178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32165 == env32178) = true)

theorem identity32178 : scanCanonicalize (H12AffineFastState.compose env32178 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(20+1) ^^^ 347159) := by decide +kernel

theorem selectedBound32178 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env32179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,347159,272392,351302,95496,8193,64,328022,346438,17665,89174,350467,95326,257,21793,16464,294493]

theorem envBound32179 : H12AffineFastState.Bounded env32179 := by
  intro p hp
  have h : env32179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32178_32179 : H12AffineEnvironment.transform 20 347159 env32178 = env32179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347159 env32178 == env32179) = true)

theorem identity32179 : scanCanonicalize (H12AffineFastState.compose env32179 (packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound32179 : packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,13388,262144,1025,29788,276764,272392,272717,3,8193,64,291933,277581,17665,10589,273416,341,257,21793,16464,294493]

theorem envBound32180 : H12AffineFastState.Bounded env32180 := by
  intro p hp
  have h : env32180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32179_32180 : H12AffineEnvironment.transform 15 29963 env32179 = env32180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env32179 == env32180) = true)

theorem identity32180 : scanCanonicalize (H12AffineFastState.compose env32180 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound32180 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env32181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8233,8575,13388,262144,1025,8232,276764,272392,272717,3,8193,64,270377,277581,4469,10589,273416,341,257,341,5156,272937]

theorem envBound32181 : H12AffineFastState.Bounded env32181 := by
  intro p hp
  have h : env32181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32180_32181 : H12AffineEnvironment.transform 13 5236 env32180 = env32181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env32180 == env32181) = true)

theorem identity32181 : scanCanonicalize (H12AffineFastState.compose env32181 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 4453) := by decide +kernel

theorem selectedBound32181 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env32182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8233,8575,13388,4453,1025,8232,10361,14701,14376,3,8193,64,12620,11560,4469,10589,15725,341,257,341,5156,15180]

theorem envBound32182 : H12AffineFastState.Bounded env32182 := by
  intro p hp
  have h : env32182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32181_32182 : H12AffineEnvironment.transform 17 4453 env32181 = env32182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4453 env32181 == env32182) = true)

theorem identity32182 : scanCanonicalize (H12AffineFastState.compose env32182 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound32182 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15,17] rootPS < 2^1333 := by decide +kernel

def env32183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,5236,5156,5490,65,4453,1025,5157,7284,3424,3109,3,5132,64,1345,6437,4469,7504,2400,341,257,341,5156,3905]

theorem envBound32183 : H12AffineFastState.Bounded env32183 := by
  intro p hp
  have h : env32183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32182_32183 : H12AffineEnvironment.transform 12 5133 env32182 = env32183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env32182 == env32183) = true)

theorem identity32183 : scanCanonicalize (H12AffineFastState.compose env32183 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound32183 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env32184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,309,1336,1345,1297,1095,65,80,1025,1296,3393,3424,3109,3,1337,64,1345,2064,64,3173,2400,341,257,341,1297,3905]

theorem envBound32184 : H12AffineFastState.Bounded env32184 := by
  intro p hp
  have h : env32184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32183_32184 : H12AffineEnvironment.transform 11 309 env32183 = env32184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env32183 == env32184) = true)

theorem identity32184 : scanCanonicalize (H12AffineFastState.compose env32184 (packedSelected [0,2,6,7,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound32184 : packedSelected [0,2,6,7,12,14] rootPS < 2^1333 := by decide +kernel

def env32185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,309,1336,1345,1297,1095,65,80,1025,1296,292,261,64,3,1337,64,1345,1141,64,0,1285,341,257,341,1297,804]

theorem envBound32185 : H12AffineFastState.Bounded env32185 := by
  intro p hp
  have h : env32185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32184_32185 : H12AffineEnvironment.transform 10 1125 env32184 = env32185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env32184 == env32185) = true)

theorem identity32185 : scanCanonicalize (H12AffineFastState.compose env32185 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32185 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env32186 : List Nat := [2,4,8,16,32,64,9,256,512,101,0,309,349,292,372,34,65,80,100,373,292,261,64,3,348,64,292,16,64,0,352,341,257,341,372,804]

theorem envBound32186 : H12AffineFastState.Bounded env32186 := by
  intro p hp
  have h : env32186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32185_32186 : H12AffineEnvironment.transform 9 101 env32185 = env32186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32185 == env32186) = true)

theorem identity32186 : scanCanonicalize (H12AffineFastState.compose env32186 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32186 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32187 : List Nat := [2,4,8,16,32,16,9,256,512,53,0,309,269,292,292,34,17,0,52,293,292,261,16,3,268,16,292,16,16,0,304,261,257,261,292,804]

theorem envBound32187 : H12AffineFastState.Bounded env32187 := by
  intro p hp
  have h : env32187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32186_32187 : H12AffineEnvironment.transform 5 16 env32186 = env32187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32186 == env32187) = true)

theorem identity32187 : scanCanonicalize (H12AffineFastState.compose env32187 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32188 : List Nat := [2,4,8,16,0,16,9,256,512,21,0,277,269,260,260,2,17,0,20,261,260,261,16,3,268,16,260,16,16,0,272,261,257,261,260,772]

theorem envBound32188 : H12AffineFastState.Bounded env32188 := by
  intro p hp
  have h : env32188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32187_32188 : H12AffineEnvironment.transform 4 0 env32187 = env32188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32187 == env32188) = true)

theorem identity32188 : scanCanonicalize (H12AffineFastState.compose env32188 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32188 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32189 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,17,9,0,0,2,17,0,20,1,0,1,16,3,8,16,0,16,16,0,20,1,5,1,0,512]

theorem envBound32189 : H12AffineFastState.Bounded env32189 := by
  intro p hp
  have h : env32189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32188_32189 : H12AffineEnvironment.transform 7 4 env32188 = env32189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32188 == env32189) = true)

theorem identity32189 : scanCanonicalize (H12AffineFastState.compose env32189 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound32189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32190 : List Nat := [2,4,8,16,0,16,9,4,16,21,0,17,9,0,0,2,17,0,20,1,0,1,16,3,8,16,0,16,16,0,20,1,5,1,0,16]

theorem envBound32190 : H12AffineFastState.Bounded env32190 := by
  intro p hp
  have h : env32190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32189_32190 : H12AffineEnvironment.transform 8 16 env32189 = env32190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env32189 == env32190) = true)

theorem identity32190 : scanCanonicalize (H12AffineFastState.compose env32190 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound32190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32191 : List Nat := [2,4,8,14,0,14,9,4,14,11,0,15,9,0,0,2,15,0,10,1,0,1,14,3,8,14,0,14,14,0,10,1,5,1,0,14]

theorem envBound32191 : H12AffineFastState.Bounded env32191 := by
  intro p hp
  have h : env32191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32190_32191 : H12AffineEnvironment.transform 3 14 env32190 = env32191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env32190 == env32191) = true)

def env32192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281537,213453,8328,64,6705549,2278720,165137,2363456,2102684,6431757,257,21792,46213,2175563]

theorem envBound32192 : H12AffineFastState.Bounded env32192 := by
  intro p hp
  have h : env32192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32067_32192 : H12AffineEnvironment.transform 22 2281537 env32067 = env32192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281537 env32067 == env32192) = true)

def env32193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590877,2098512,17665,2363456,2102684,6349853,257,21792,46213,2175563]

theorem envBound32193 : H12AffineFastState.Bounded env32193 := by
  intro p hp
  have h : env32193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32192_32193 : H12AffineEnvironment.transform 16 49168 env32192 = env32193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32192 == env32193) = true)

def env32194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144541,2098512,17665,2363456,2102684,2411677,257,21792,46213,2175563]

theorem envBound32194 : H12AffineFastState.Bounded env32194 := by
  intro p hp
  have h : env32194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32193_32194 : H12AffineEnvironment.transform 21 272512 env32193 = env32194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32193 == env32194) = true)

theorem identity32194 : scanCanonicalize (H12AffineFastState.compose env32194 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272512,2101329,41431,8328,64,2144541,2098512,17665,2363456,2102684,2411677,257,21792,46213,2101825]

theorem envBound32195 : H12AffineFastState.Bounded env32195 := by
  intro p hp
  have h : env32195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32194_32195 : H12AffineEnvironment.transform 15 8202 env32194 = env32195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32194 == env32195) = true)

theorem identity32195 : scanCanonicalize (H12AffineFastState.compose env32195 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound32195 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,268733,272512,264684,41431,8328,64,303264,269549,17665,2557,265249,54560,257,21792,46213,265212]

theorem envBound32196 : H12AffineFastState.Bounded env32196 := by
  intro p hp
  have h : env32196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32195_32196 : H12AffineEnvironment.transform 20 268733 env32195 = env32196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env32195 == env32196) = true)

theorem identity32196 : scanCanonicalize (H12AffineFastState.compose env32196 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32196 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env32197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16400,262144,1025,1,268733,272512,264684,8663,8328,64,270496,269549,17665,2557,265249,21792,257,21792,13445,265212]

theorem envBound32197 : H12AffineFastState.Bounded env32197 := by
  intro p hp
  have h : env32197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32196_32197 : H12AffineEnvironment.transform 14 0 env32196 = env32197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32196 == env32197) = true)

theorem identity32197 : scanCanonicalize (H12AffineFastState.compose env32197 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32197 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,0,8202,5392,262144,1025,1,268733,272512,264684,8663,8328,64,270496,269549,4097,2557,265249,32,257,32,13445,265212]

theorem envBound32198 : H12AffineFastState.Bounded env32198 := by
  intro p hp
  have h : env32198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32197_32198 : H12AffineEnvironment.transform 13 5376 env32197 = env32198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32197 == env32198) = true)

theorem identity32198 : scanCanonicalize (H12AffineFastState.compose env32198 (packedSelected [0,2,7,9,11,16,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32198 : packedSelected [0,2,7,9,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env32199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5376,0,34,5392,262144,1025,1,268733,264360,264684,511,160,64,262280,269549,4097,2557,265249,32,257,32,5293,265212]

theorem envBound32199 : H12AffineFastState.Bounded env32199 := by
  intro p hp
  have h : env32199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32198_32199 : H12AffineEnvironment.transform 12 40 env32198 = env32199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32198 == env32199) = true)

theorem identity32199 : scanCanonicalize (H12AffineFastState.compose env32199 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32199 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env32200 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5237,0,34,5221,262144,1025,1,268488,264360,264345,138,160,64,262280,269549,4097,2184,265249,32,116,32,5293,264841]

theorem envBound32200 : H12AffineFastState.Bounded env32200 := by
  intro p hp
  have h : env32200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32199_32200 : H12AffineEnvironment.transform 7 117 env32199 = env32200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32199 == env32200) = true)

theorem identity32200 : scanCanonicalize (H12AffineFastState.compose env32200 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound32200 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32201 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5237,0,34,5221,2049,1025,1,4297,169,152,138,160,64,2185,5356,4097,2184,1056,32,116,32,5293,648]

theorem envBound32201 : H12AffineFastState.Bounded env32201 := by
  intro p hp
  have h : env32201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32200_32201 : H12AffineEnvironment.transform 17 2049 env32200 = env32201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env32200 == env32201) = true)

theorem identity32201 : scanCanonicalize (H12AffineFastState.compose env32201 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32201 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32202 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,40,4113,0,34,4097,2049,101,1,4297,169,152,138,160,64,2185,4232,4097,2184,68,32,116,32,4297,648]

theorem envBound32202 : H12AffineFastState.Bounded env32202 := by
  intro p hp
  have h : env32202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32201_32202 : H12AffineEnvironment.transform 9 100 env32201 = env32202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32201 == env32202) = true)

theorem identity32202 : scanCanonicalize (H12AffineFastState.compose env32202 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound32202 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env32203 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,201,40,216,0,34,200,2049,101,1,0,169,152,138,160,64,2185,65,200,2184,68,32,116,32,0,648]

theorem envBound32203 : H12AffineFastState.Bounded env32203 := by
  intro p hp
  have h : env32203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32202_32203 : H12AffineEnvironment.transform 11 201 env32202 = env32203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env32202 == env32203) = true)

theorem identity32203 : scanCanonicalize (H12AffineFastState.compose env32203 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound32203 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32204 : List Nat := [2,4,8,16,32,64,40,117,512,100,2048,97,40,112,0,34,96,2049,101,1,0,1,48,34,8,64,2081,65,96,2080,68,32,116,32,0,544]

theorem envBound32204 : H12AffineFastState.Bounded env32204 := by
  intro p hp
  have h : env32204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32203_32204 : H12AffineEnvironment.transform 6 40 env32203 = env32204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env32203 == env32204) = true)

theorem identity32204 : scanCanonicalize (H12AffineFastState.compose env32204 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32205 : List Nat := [2,4,8,16,32,0,40,53,512,36,2048,33,40,48,0,34,32,2049,37,1,0,1,48,34,8,0,2081,1,32,2080,4,32,52,32,0,544]

theorem envBound32205 : H12AffineFastState.Bounded env32205 := by
  intro p hp
  have h : env32205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32204_32205 : H12AffineEnvironment.transform 5 0 env32204 = env32205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32204 == env32205) = true)

theorem identity32205 : scanCanonicalize (H12AffineFastState.compose env32205 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32205 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env32206 : List Nat := [2,4,8,16,32,0,40,53,512,36,48,33,40,48,0,34,32,49,37,1,0,1,48,34,8,0,17,1,32,16,4,32,52,32,0,544]

theorem envBound32206 : H12AffineFastState.Bounded env32206 := by
  intro p hp
  have h : env32206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32205_32206 : H12AffineEnvironment.transform 10 48 env32205 = env32206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32205 == env32206) = true)

theorem identity32206 : scanCanonicalize (H12AffineFastState.compose env32206 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32206 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32207 : List Nat := [2,4,8,0,32,0,40,37,512,36,32,33,40,32,0,34,32,33,37,1,0,1,32,34,8,0,1,1,32,0,4,32,36,32,0,544]

theorem envBound32207 : H12AffineFastState.Bounded env32207 := by
  intro p hp
  have h : env32207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32206_32207 : H12AffineEnvironment.transform 3 0 env32206 = env32207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32206 == env32207) = true)

def env32208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144540,2098512,17665,2363456,2102684,2411676,257,21792,46213,2175563]

theorem envBound32208 : H12AffineFastState.Bounded env32208 := by
  intro p hp
  have h : env32208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32193_32208 : H12AffineEnvironment.transform 21 272513 env32193 = env32208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32193 == env32208) = true)

theorem identity32208 : scanCanonicalize (H12AffineFastState.compose env32208 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound32208 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272513,73755,98781,8328,64,100694,79130,17665,335882,75222,392406,257,21792,46213,513]

theorem envBound32209 : H12AffineFastState.Bounded env32209 := by
  intro p hp
  have h : env32209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32208_32209 : H12AffineEnvironment.transform 20 77898 env32208 = env32209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env32208 == env32209) = true)

def env32210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272393,73755,98645,8192,64,100694,79130,17665,335882,75102,392286,257,21792,46093,513]

theorem envBound32210 : H12AffineFastState.Bounded env32210 := by
  intro p hp
  have h : env32210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32209_32210 : H12AffineEnvironment.transform 6 8 env32209 = env32210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32209 == env32210) = true)

theorem identity32210 : scanCanonicalize (H12AffineFastState.compose env32210 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32210 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,77898,41341,73755,98645,8192,64,100694,79130,17665,108926,75102,95530,257,21792,46093,513]

theorem envBound32211 : H12AffineFastState.Bounded env32211 := by
  intro p hp
  have h : env32211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32210_32211 : H12AffineEnvironment.transform 17 35188 env32210 = env32211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32210 == env32211) = true)

theorem identity32211 : scanCanonicalize (H12AffineFastState.compose env32211 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32211 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env32212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35188,1025,32769,4160,41341,17,41311,8192,64,43356,5392,17665,35188,1364,21792,257,21792,46093,513]

theorem envBound32212 : H12AffineFastState.Bounded env32212 := by
  intro p hp
  have h : env32212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32211_32212 : H12AffineEnvironment.transform 15 8202 env32211 = env32212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32211 == env32212) = true)

theorem identity32212 : scanCanonicalize (H12AffineFastState.compose env32212 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32212 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,46157,35188,1025,32769,4160,41341,17,41311,8192,64,43356,5392,12636,35188,1364,8573,257,8573,46093,513]

theorem envBound32213 : H12AffineFastState.Bounded env32213 := by
  intro p hp
  have h : env32213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32212_32213 : H12AffineEnvironment.transform 13 13405 env32212 = env32213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32212 == env32213) = true)

theorem identity32213 : scanCanonicalize (H12AffineFastState.compose env32213 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32213 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,343,38160,35188,1025,32769,4160,32800,17,32770,349,64,34817,5392,4097,35188,1364,32,257,32,38224,513]

theorem envBound32214 : H12AffineFastState.Bounded env32214 := by
  intro p hp
  have h : env32214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32213_32214 : H12AffineEnvironment.transform 12 349 env32213 = env32214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32213 == env32214) = true)

theorem identity32214 : scanCanonicalize (H12AffineFastState.compose env32214 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32214 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2421,1025,0,4160,33,17,3,349,64,2048,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound32215 : H12AffineFastState.Bounded env32215 := by
  intro p hp
  have h : env32215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32214_32215 : H12AffineEnvironment.transform 14 1 env32214 = env32215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32214 == env32215) = true)

theorem identity32215 : scanCanonicalize (H12AffineFastState.compose env32215 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32215 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32216 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4112,1,343,4097,2421,273,0,4160,33,17,3,349,64,2048,4096,4097,2421,68,32,257,32,4161,513]

theorem envBound32216 : H12AffineFastState.Bounded env32216 := by
  intro p hp
  have h : env32216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32215_32216 : H12AffineEnvironment.transform 9 272 env32215 = env32216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32215 == env32216) = true)

theorem identity32216 : scanCanonicalize (H12AffineFastState.compose env32216 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound32216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32217 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,48,349,32,1,343,49,2421,273,0,112,33,17,3,349,64,2048,48,49,2421,68,32,257,32,113,513]

theorem envBound32217 : H12AffineFastState.Bounded env32217 := by
  intro p hp
  have h : env32217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32216_32217 : H12AffineEnvironment.transform 11 48 env32216 = env32217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32216 == env32217) = true)

theorem identity32217 : scanCanonicalize (H12AffineFastState.compose env32217 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32217 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32218 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,48,40,32,1,34,49,2048,100,0,112,33,17,3,40,64,2048,48,49,2048,68,32,116,32,113,513]

theorem envBound32218 : H12AffineFastState.Bounded env32218 := by
  intro p hp
  have h : env32218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32217_32218 : H12AffineEnvironment.transform 7 117 env32217 = env32218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32217 == env32218) = true)

theorem identity32218 : scanCanonicalize (H12AffineFastState.compose env32218 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound32218 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32219 : List Nat := [2,4,8,16,32,64,8,117,512,101,576,48,40,32,1,34,49,576,100,0,112,33,17,3,40,64,576,48,49,576,68,32,116,32,113,513]

theorem envBound32219 : H12AffineFastState.Bounded env32219 := by
  intro p hp
  have h : env32219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32218_32219 : H12AffineEnvironment.transform 10 576 env32218 = env32219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env32218 == env32219) = true)

theorem identity32219 : scanCanonicalize (H12AffineFastState.compose env32219 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound32219 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32220 : List Nat := [2,4,8,16,32,42,8,31,512,15,554,48,40,32,1,34,49,554,14,0,26,33,17,3,40,42,554,48,49,554,46,32,30,32,27,513]

theorem envBound32220 : H12AffineFastState.Bounded env32220 := by
  intro p hp
  have h : env32220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32219_32220 : H12AffineEnvironment.transform 5 42 env32219 = env32220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env32219 == env32220) = true)

theorem identity32220 : scanCanonicalize (H12AffineFastState.compose env32220 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32220 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32221 : List Nat := [2,4,8,16,32,42,8,31,43,15,1,48,40,32,1,34,49,1,14,0,26,33,17,3,40,42,1,48,49,1,46,32,30,32,27,42]

theorem envBound32221 : H12AffineFastState.Bounded env32221 := by
  intro p hp
  have h : env32221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32220_32221 : H12AffineEnvironment.transform 8 43 env32220 = env32221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32220 == env32221) = true)

theorem identity32221 : scanCanonicalize (H12AffineFastState.compose env32221 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32222 : List Nat := [2,4,3,16,32,33,3,20,32,4,1,48,35,32,1,34,49,1,5,0,17,33,17,3,35,33,1,48,49,1,37,32,21,32,16,33]

theorem envBound32222 : H12AffineFastState.Bounded env32222 := by
  intro p hp
  have h : env32222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32221_32222 : H12AffineEnvironment.transform 2 3 env32221 = env32222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32221 == env32222) = true)

theorem identity32222 : scanCanonicalize (H12AffineFastState.compose env32222 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32222 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env32223 : List Nat := [2,4,3,16,0,1,3,20,0,4,1,16,3,0,1,2,17,1,5,0,17,1,17,3,3,1,1,16,17,1,5,0,21,0,16,1]

theorem envBound32223 : H12AffineFastState.Bounded env32223 := by
  intro p hp
  have h : env32223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32222_32223 : H12AffineEnvironment.transform 4 0 env32222 = env32223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32222 == env32223) = true)

theorem identity32223 : scanCanonicalize (H12AffineFastState.compose env32223 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1