import H12CloudChart1Data223

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound56720 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56721 : List Nat := [2,4,8,0,1,64,8,4,1,4,0,65,9,0,64,66,65,1,5,65,1,0,1,2,9,65,65,1,1,0,4,0,5,1,65,0]

theorem envBound56721 : H12AffineFastState.Bounded env56721 := by
  intro p hp
  have h : env56721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56720_56721 : H12AffineEnvironment.transform 4 1 env56720 = env56721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56720 == env56721) = true)

theorem identity56721 : scanCanonicalize (H12AffineFastState.compose env56721 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound56721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56722 : List Nat := [2,4,8,0,1,1,8,4,1,4,0,0,9,0,1,3,0,1,5,0,1,0,1,2,9,0,0,1,1,0,4,0,5,1,0,0]

theorem envBound56722 : H12AffineFastState.Bounded env56722 := by
  intro p hp
  have h : env56722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56721_56722 : H12AffineEnvironment.transform 5 1 env56721 = env56722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env56721 == env56722) = true)

def env56723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,4194304,17,41310,8193,65,4365616,57677,17665,190521,61704,4194305,257,41340,16465,513]

theorem envBound56723 : H12AffineFastState.Bounded env56723 := by
  intro p hp
  have h : env56723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56708_56723 : H12AffineEnvironment.transform 6 9 env56708 = env56723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56708 == env56723) = true)

def env56724 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,4194304,17,41230,8193,17,4365616,57629,17665,190521,61704,4194305,257,41260,16385,513]

theorem envBound56724 : H12AffineFastState.Bounded env56724 := by
  intro p hp
  have h : env56724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56723_56724 : H12AffineEnvironment.transform 5 16 env56723 = env56724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56723 == env56724) = true)

theorem identity56724 : scanCanonicalize (H12AffineFastState.compose env56724 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound56724 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env56725 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,8493,17,41230,8193,17,179229,57629,17665,190521,61704,8492,257,41260,16385,513]

theorem envBound56725 : H12AffineFastState.Bounded env56725 := by
  intro p hp
  have h : env56725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56724_56725 : H12AffineEnvironment.transform 21 8493 env56724 = env56725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env56724 == env56725) = true)

theorem identity56725 : scanCanonicalize (H12AffineFastState.compose env56725 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound56725 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env56726 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,131072,10281,1025,29709,4112,8493,17,21762,8193,17,149521,5393,17665,138293,1284,8492,257,21792,16385,513]

theorem envBound56726 : H12AffineFastState.Bounded env56726 := by
  intro p hp
  have h : env56726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56725_56726 : H12AffineEnvironment.transform 14 29708 env56725 = env56726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env56725 == env56726) = true)

theorem identity56726 : scanCanonicalize (H12AffineFastState.compose env56726 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56726 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56727 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10281,1025,8461,4112,8493,17,2,8193,17,138513,5393,4097,138293,1284,8492,257,32,5377,513]

theorem envBound56727 : H12AffineFastState.Bounded env56727 := by
  intro p hp
  have h : env56727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56726_56727 : H12AffineEnvironment.transform 13 5376 env56726 = env56727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56726 == env56727) = true)

theorem identity56727 : scanCanonicalize (H12AffineFastState.compose env56727 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound56727 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56728 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,13341,10281,1025,8461,4112,8493,17,2,8193,17,10508,5393,4097,10280,1284,8492,257,32,5377,513]

theorem envBound56728 : H12AffineFastState.Bounded env56728 := by
  intro p hp
  have h : env56728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56727_56728 : H12AffineEnvironment.transform 16 13341 env56727 = env56728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env56727 == env56728) = true)

theorem identity56728 : scanCanonicalize (H12AffineFastState.compose env56728 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56728 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56729 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,263,5392,2340,1025,0,4112,32,17,2,268,17,2049,5393,4097,2341,1284,33,257,32,5377,513]

theorem envBound56729 : H12AffineFastState.Bounded env56729 := by
  intro p hp
  have h : env56729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56728_56729 : H12AffineEnvironment.transform 12 269 env56728 = env56729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56728 == env56729) = true)

theorem identity56729 : scanCanonicalize (H12AffineFastState.compose env56729 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56729 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56730 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5124,1,3,5140,2080,1025,0,4112,32,17,2,8,17,2049,5141,4097,2081,1024,33,5,32,5125,513]

theorem envBound56730 : H12AffineFastState.Bounded env56730 := by
  intro p hp
  have h : env56730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56729_56730 : H12AffineEnvironment.transform 7 4 env56729 = env56730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56729 == env56730) = true)

theorem identity56730 : scanCanonicalize (H12AffineFastState.compose env56730 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56730 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56731 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,4096,9,4145,1,3,4129,2080,52,0,4112,32,17,2,8,17,2049,4128,4097,2081,53,33,5,32,4144,513]

theorem envBound56731 : H12AffineFastState.Bounded env56731 := by
  intro p hp
  have h : env56731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56730_56731 : H12AffineEnvironment.transform 9 53 env56730 = env56731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56730 == env56731) = true)

theorem identity56731 : scanCanonicalize (H12AffineFastState.compose env56731 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound56731 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56732 : List Nat := [2,4,8,16,32,16,9,4,512,53,2048,2608,9,2561,1,3,2577,2080,52,0,2592,32,17,2,8,17,2049,2576,2609,2081,53,33,5,32,2560,513]

theorem envBound56732 : H12AffineFastState.Bounded env56732 := by
  intro p hp
  have h : env56732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56731_56732 : H12AffineEnvironment.transform 11 2608 env56731 = env56732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env56731 == env56732) = true)

theorem identity56732 : scanCanonicalize (H12AffineFastState.compose env56732 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound56732 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56733 : List Nat := [2,4,8,16,32,16,9,4,512,53,560,0,9,49,1,3,33,528,52,0,16,32,17,2,8,17,561,32,1,529,53,33,5,32,48,513]

theorem envBound56733 : H12AffineFastState.Bounded env56733 := by
  intro p hp
  have h : env56733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56732_56733 : H12AffineEnvironment.transform 10 560 env56732 = env56733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env56732 == env56733) = true)

theorem identity56733 : scanCanonicalize (H12AffineFastState.compose env56733 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56733 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56734 : List Nat := [2,4,8,16,32,16,9,4,1,53,49,0,9,49,1,3,33,17,52,0,16,32,17,2,8,17,48,32,1,16,53,33,5,32,48,0]

theorem envBound56734 : H12AffineFastState.Bounded env56734 := by
  intro p hp
  have h : env56734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56733_56734 : H12AffineEnvironment.transform 8 1 env56733 = env56734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56733 == env56734) = true)

theorem identity56734 : scanCanonicalize (H12AffineFastState.compose env56734 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56734 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56735 : List Nat := [2,4,8,16,1,16,9,4,1,20,16,0,9,16,1,3,0,17,21,0,16,1,17,2,8,17,17,1,1,16,20,0,5,1,17,0]

theorem envBound56735 : H12AffineFastState.Bounded env56735 := by
  intro p hp
  have h : env56735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56734_56735 : H12AffineEnvironment.transform 4 1 env56734 = env56735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56734 == env56735) = true)

theorem identity56735 : scanCanonicalize (H12AffineFastState.compose env56735 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56736 : List Nat := [2,4,8,1,1,1,9,4,1,5,1,0,9,1,1,3,0,0,4,0,1,1,0,2,8,0,0,1,1,1,5,0,5,1,0,0]

theorem envBound56736 : H12AffineFastState.Bounded env56736 := by
  intro p hp
  have h : env56736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56735_56736 : H12AffineEnvironment.transform 3 1 env56735 = env56736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56735 == env56736) = true)

def env56737 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,4194304,17,41231,8193,16,4365616,57628,17665,190521,61704,4194305,257,41261,16384,513]

theorem envBound56737 : H12AffineFastState.Bounded env56737 := by
  intro p hp
  have h : env56737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56723_56737 : H12AffineEnvironment.transform 5 17 env56723 = env56737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56723 == env56737) = true)

theorem identity56737 : scanCanonicalize (H12AffineFastState.compose env56737 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56737 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env56738 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,131072,10281,1025,1,4113,4194304,17,8463,8193,16,4332848,24860,17665,157753,28936,4194305,257,8493,16384,513]

theorem envBound56738 : H12AffineFastState.Bounded env56738 := by
  intro p hp
  have h : env56738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56737_56738 : H12AffineEnvironment.transform 14 0 env56737 = env56738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56737 == env56738) = true)

theorem identity56738 : scanCanonicalize (H12AffineFastState.compose env56738 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound56738 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56739 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,131072,10281,1025,1,4113,136496,17,8463,8193,16,2048,24860,17665,157753,28936,136497,257,8493,16384,513]

theorem envBound56739 : H12AffineFastState.Bounded env56739 := by
  intro p hp
  have h : env56739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56738_56739 : H12AffineEnvironment.transform 21 136496 env56738 = env56739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env56738 == env56739) = true)

theorem identity56739 : scanCanonicalize (H12AffineFastState.compose env56739 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound56739 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env56740 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,13341,10281,1025,1,4113,8493,17,8463,8193,16,2048,24860,17665,23588,28936,8492,257,8493,16384,513]

theorem envBound56740 : H12AffineFastState.Bounded env56740 := by
  intro p hp
  have h : env56740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56739_56740 : H12AffineEnvironment.transform 16 13341 env56739 = env56740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env56739 == env56740) = true)

theorem identity56740 : scanCanonicalize (H12AffineFastState.compose env56740 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56740 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env56741 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,21511,5393,2341,1025,1,4113,33,17,3,269,16,2048,16400,17665,23588,20484,32,257,33,16384,513]

theorem envBound56741 : H12AffineFastState.Bounded env56741 := by
  intro p hp
  have h : env56741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56740_56741 : H12AffineEnvironment.transform 12 268 env56740 = env56741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56740 == env56741) = true)

theorem identity56741 : scanCanonicalize (H12AffineFastState.compose env56741 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56741 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56742 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,16384,0,21511,5173,2049,1025,1,4113,33,17,3,41,16,2048,16400,17445,23588,20484,32,37,33,16384,513]

theorem envBound56742 : H12AffineFastState.Bounded env56742 := by
  intro p hp
  have h : env56742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56741_56742 : H12AffineEnvironment.transform 7 36 env56741 = env56742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56741 == env56742) = true)

theorem identity56742 : scanCanonicalize (H12AffineFastState.compose env56742 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound56742 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env56743 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5173,2049,1025,1,4113,33,17,3,41,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound56743 : H12AffineFastState.Bounded env56743 := by
  intro p hp
  have h : env56743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56742_56743 : H12AffineEnvironment.transform 13 5157 env56742 = env56743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env56742 == env56743) = true)

def env56744 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,0,34,1029,2049,1025,1,33,33,17,3,41,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound56744 : H12AffineFastState.Bounded env56744 := by
  intro p hp
  have h : env56744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56743_56744 : H12AffineEnvironment.transform 11 48 env56743 = env56744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56743 == env56744) = true)

theorem identity56744 : scanCanonicalize (H12AffineFastState.compose env56744 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56745 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,0,3,1029,2049,1025,1,0,0,17,3,8,16,2048,1029,17,2049,1024,1,4,0,1045,513]

theorem envBound56745 : H12AffineFastState.Bounded env56745 := by
  intro p hp
  have h : env56745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56744_56745 : H12AffineEnvironment.transform 4 1 env56744 = env56745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56744 == env56745) = true)

def env56746 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,1,0,3,17,2049,21,1,0,0,17,3,8,16,2048,17,17,2049,20,1,4,0,1,513]

theorem envBound56746 : H12AffineFastState.Bounded env56746 := by
  intro p hp
  have h : env56746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56745_56746 : H12AffineEnvironment.transform 9 20 env56745 = env56746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56745 == env56746) = true)

theorem identity56746 : scanCanonicalize (H12AffineFastState.compose env56746 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56747 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,1,0,3,17,1,21,1,0,0,17,3,8,16,0,17,17,1,20,1,4,0,1,513]

theorem envBound56747 : H12AffineFastState.Bounded env56747 := by
  intro p hp
  have h : env56747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56746_56747 : H12AffineEnvironment.transform 10 0 env56746 = env56747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56746 == env56747) = true)

def leafEnv56747 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,1,0,3,17,1,21,1,0,0,17,3,21,8,1,16,0,17,17,1,20,1,4,0,5,2,1,513,1,0,0]

def active56747 : List Nat := [0,1,2,3,8]

def tree56747 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56747 : H12WitnessSearch.Good tree56747 := H12GlobalWitnessIndex.good

theorem leafIdentity56747 : H12AffineFastState.composeSystem env56747 rootObs = leafEnv56747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56747 rootObs == leafEnv56747) = true)

theorem terminalChecked56747 : H12PackedTerminal.terminalCheckFast leafEnv56747 active56747 tree56747 = true := by decide +kernel

def env56748 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,0,0,3,16,2049,20,1,0,0,17,3,8,16,2048,16,17,2049,21,1,4,0,0,513]

theorem envBound56748 : H12AffineFastState.Bounded env56748 := by
  intro p hp
  have h : env56748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56745_56748 : H12AffineEnvironment.transform 9 21 env56745 = env56748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env56745 == env56748) = true)

theorem identity56748 : scanCanonicalize (H12AffineFastState.compose env56748 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound56748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56749 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,17,9,0,0,3,16,523,20,1,0,0,17,3,8,16,522,16,17,523,21,1,4,0,0,513]

theorem envBound56749 : H12AffineFastState.Bounded env56749 := by
  intro p hp
  have h : env56749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56748_56749 : H12AffineEnvironment.transform 10 522 env56748 = env56749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env56748 == env56749) = true)

def leafEnv56749 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,17,9,0,0,3,16,523,20,1,0,0,17,3,20,8,1,16,522,16,17,523,21,1,4,0,5,2,0,513,1,0,0]

def active56749 : List Nat := [0,1,2,3,8]

def tree56749 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56749 : H12WitnessSearch.Good tree56749 := H12GlobalWitnessIndex.good

theorem leafIdentity56749 : H12AffineFastState.composeSystem env56749 rootObs = leafEnv56749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56749 rootObs == leafEnv56749) = true)

theorem terminalChecked56749 : H12PackedTerminal.terminalCheckFast leafEnv56749 active56749 tree56749 = true := by decide +kernel

def env56750 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,0,34,1028,2049,1025,1,32,33,17,3,41,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound56750 : H12AffineFastState.Bounded env56750 := by
  intro p hp
  have h : env56750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56743_56750 : H12AffineEnvironment.transform 11 49 env56743 = env56750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56743 == env56750) = true)

theorem identity56750 : scanCanonicalize (H12AffineFastState.compose env56750 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56751 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,49,40,0,0,34,16,2049,21,1,32,33,17,3,41,16,2048,16,49,2049,53,32,37,33,0,513]

theorem envBound56751 : H12AffineFastState.Bounded env56751 := by
  intro p hp
  have h : env56751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56750_56751 : H12AffineEnvironment.transform 9 20 env56750 = env56751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56750 == env56751) = true)

def env56752 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,8,0,0,2,16,2049,21,1,0,1,17,3,9,16,2048,16,17,2049,21,0,5,1,0,513]

theorem envBound56752 : H12AffineFastState.Bounded env56752 := by
  intro p hp
  have h : env56752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56751_56752 : H12AffineEnvironment.transform 4 0 env56751 = env56752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56751 == env56752) = true)

theorem identity56752 : scanCanonicalize (H12AffineFastState.compose env56752 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound56752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56753 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,17,8,0,0,2,16,522,21,1,0,1,17,3,9,16,523,16,17,522,21,0,5,1,0,513]

theorem envBound56753 : H12AffineFastState.Bounded env56753 := by
  intro p hp
  have h : env56753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56752_56753 : H12AffineEnvironment.transform 10 523 env56752 = env56753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env56752 == env56753) = true)

def leafEnv56753 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,17,8,0,0,2,16,522,21,1,0,1,17,3,20,9,1,16,523,16,17,522,21,0,5,1,5,3,0,513,1,0,0]

def active56753 : List Nat := [0,1,2,3,8]

def tree56753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56753 : H12WitnessSearch.Good tree56753 := H12GlobalWitnessIndex.good

theorem leafIdentity56753 : H12AffineFastState.composeSystem env56753 rootObs = leafEnv56753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56753 rootObs == leafEnv56753) = true)

theorem terminalChecked56753 : H12PackedTerminal.terminalCheckFast leafEnv56753 active56753 tree56753 = true := by decide +kernel

def env56754 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,0,0,3,16,2049,21,1,1,0,17,3,8,16,2048,16,16,2049,20,1,4,0,0,513]

theorem envBound56754 : H12AffineFastState.Bounded env56754 := by
  intro p hp
  have h : env56754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56751_56754 : H12AffineEnvironment.transform 4 1 env56751 = env56754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56751 == env56754) = true)

theorem identity56754 : scanCanonicalize (H12AffineFastState.compose env56754 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56755 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,0,0,3,16,0,21,1,1,0,17,3,8,16,1,16,16,0,20,1,4,0,0,513]

theorem envBound56755 : H12AffineFastState.Bounded env56755 := by
  intro p hp
  have h : env56755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56754_56755 : H12AffineEnvironment.transform 10 1 env56754 = env56755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56754 == env56755) = true)

def leafEnv56755 : List Nat := [2,4,8,16,1,17,9,5,512,20,1,16,9,0,0,3,16,0,21,1,1,0,17,3,21,8,1,16,1,16,16,0,20,1,4,0,5,2,0,513,1,1,0]

def active56755 : List Nat := [0,1,2,3,8]

def tree56755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56755 : H12WitnessSearch.Good tree56755 := H12GlobalWitnessIndex.good

theorem leafIdentity56755 : H12AffineFastState.composeSystem env56755 rootObs = leafEnv56755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56755 rootObs == leafEnv56755) = true)

theorem terminalChecked56755 : H12PackedTerminal.terminalCheckFast leafEnv56755 active56755 tree56755 = true := by decide +kernel

def env56756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525569,6532211005,34359738368,60294991]

theorem envBound56756 : H12AffineFastState.Bounded env56756 := by
  intro p hp
  have h : env56756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2_56756 : H12AffineEnvironment.transform 32 525569 env2 = env56756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 525569 env2 == env56756) = true)

def env56757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,525569,6531129661,34359738368,59279183]

theorem envBound56757 : H12AffineFastState.Bounded env56757 := by
  intro p hp
  have h : env56757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56756_56757 : H12AffineEnvironment.transform 19 32768 env56756 = env56757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32768 env56756 == env56757) = true)

theorem identity56757 : scanCanonicalize (H12AffineFastState.compose env56757 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(30+1) ^^^ 897815633) := by decide +kernel

theorem selectedBound56757 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env56758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,525569,5113558380,34359738368,59279183]

theorem envBound56758 : H12AffineFastState.Bounded env56758 := by
  intro p hp
  have h : env56758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56757_56758 : H12AffineEnvironment.transform 30 897815633 env56757 = env56758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 897815633 env56757 == env56758) = true)

theorem identity56758 : scanCanonicalize (H12AffineFastState.compose env56758 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(23+1) ^^^ 8955334) := by decide +kernel

theorem selectedBound56758 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env56759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,67108864,134217728,268435456,536870912,1073741824,873148823,4294967296,525569,5113558380,34359738368,33563273]

theorem envBound56759 : H12AffineFastState.Bounded env56759 := by
  intro p hp
  have h : env56759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56758_56759 : H12AffineEnvironment.transform 23 8955334 env56758 = env56759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8955334 env56758 == env56759) = true)

theorem identity56759 : scanCanonicalize (H12AffineFastState.compose env56759 (packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS)) = affineNative (2^(29+1) ^^^ 809736331) := by decide +kernel

theorem selectedBound56759 : packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS < 2^1333 := by decide +kernel

def env56760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,67108864,134217728,268435456,536870912,809736331,873148823,4294967296,525569,5113558380,34359738368,33563273]

theorem envBound56760 : H12AffineFastState.Bounded env56760 := by
  intro p hp
  have h : env56760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56759_56760 : H12AffineEnvironment.transform 29 809736331 env56759 = env56760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 809736331 env56759 == env56760) = true)

def env56761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,67108864,134217728,268435456,76174416,348769499,276915655,4294967296,525569,4634763580,34359738368,33563273]

theorem envBound56761 : H12AffineFastState.Bounded env56761 := by
  intro p hp
  have h : env56761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56760_56761 : H12AffineEnvironment.transform 28 76174416 env56760 = env56761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 76174416 env56760 == env56761) = true)

def env56762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,67108864,134217728,16384,76174416,80317659,8463815,4294967296,525569,4366311740,34359738368,33563273]

theorem envBound56762 : H12AffineFastState.Bounded env56762 := by
  intro p hp
  have h : env56762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56761_56762 : H12AffineEnvironment.transform 27 16384 env56761 = env56762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env56761 == env56762) = true)

def env56763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,8409088,134217728,16384,656464,4840667,8463815,4294967296,525569,4307611964,34359738368,33563273]

theorem envBound56763 : H12AffineFastState.Bounded env56763 := by
  intro p hp
  have h : env56763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56762_56763 : H12AffineEnvironment.transform 25 8409088 env56762 = env56763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409088 env56762 == env56763) = true)

def env56764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131152,4315355,8463815,4294967296,257,4307611964,34359738368,33563273]

theorem envBound56764 : H12AffineFastState.Bounded env56764 := by
  intro p hp
  have h : env56764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56763_56764 : H12AffineEnvironment.transform 18 1024 env56763 = env56764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env56763 == env56764) = true)

def env56765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131152,4315355,8463815,4294967296,257,4307611964,131072,33563273]

theorem envBound56765 : H12AffineFastState.Bounded env56765 := by
  intro p hp
  have h : env56765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56764_56765 : H12AffineEnvironment.transform 34 131072 env56764 = env56765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env56764 == env56765) = true)

theorem identity56765 : scanCanonicalize (H12AffineFastState.compose env56765 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 8462791) := by decide +kernel

theorem selectedBound56765 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131152,4315355,8463815,8462791,257,4313339,131072,33563273]

theorem envBound56766 : H12AffineFastState.Bounded env56766 := by
  intro p hp
  have h : env56766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56765_56766 : H12AffineEnvironment.transform 31 8462791 env56765 = env56766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8462791 env56765 == env56766) = true)

theorem identity56766 : scanCanonicalize (H12AffineFastState.compose env56766 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound56766 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env56767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,12992837,16384,131152,4315355,8463815,8462791,257,4313339,131072,33563273]

theorem envBound56767 : H12AffineFastState.Bounded env56767 := by
  intro p hp
  have h : env56767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56766_56767 : H12AffineEnvironment.transform 26 12992837 env56766 = env56767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env56766 == env56767) = true)

def env56768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8388688,12980501,4176,131152,4294795,8463815,8462791,257,4292779,131072,33563273]

theorem envBound56768 : H12AffineFastState.Bounded env56768 := by
  intro p hp
  have h : env56768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56767_56768 : H12AffineEnvironment.transform 13 4176 env56767 = env56768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env56767 == env56768) = true)

theorem identity56768 : scanCanonicalize (H12AffineFastState.compose env56768 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound56768 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env56769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388688,12980501,4176,131152,4294795,8463815,8462791,257,4292779,131072,513]

theorem envBound56769 : H12AffineFastState.Bounded env56769 := by
  intro p hp
  have h : env56769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56768_56769 : H12AffineEnvironment.transform 24 8328 env56768 = env56769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env56768 == env56769) = true)

theorem identity56769 : scanCanonicalize (H12AffineFastState.compose env56769 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 209246) := by decide +kernel

theorem selectedBound56769 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,209246,8388608,8430022,8328,8388688,8724555,4176,131152,178645,8463815,8462791,257,176629,131072,513]

theorem envBound56770 : H12AffineFastState.Bounded env56770 := by
  intro p hp
  have h : env56770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56769_56770 : H12AffineEnvironment.transform 21 209246 env56769 = env56770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 209246 env56769 == env56770) = true)

theorem identity56770 : scanCanonicalize (H12AffineFastState.compose env56770 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound56770 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,209246,8388608,8430022,8328,8388688,8724555,4176,131152,178645,8463815,8462791,257,176629,131072,513]

theorem envBound56771 : H12AffineFastState.Bounded env56771 := by
  intro p hp
  have h : env56771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56770_56771 : H12AffineEnvironment.transform 20 4096 env56770 = env56771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env56770 == env56771) = true)

theorem identity56771 : scanCanonicalize (H12AffineFastState.compose env56771 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound56771 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,209246,98767,73737,8328,98719,303492,4176,131152,178645,41992,40968,257,176629,131072,513]

theorem envBound56772 : H12AffineFastState.Bounded env56772 := by
  intro p hp
  have h : env56772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56771_56772 : H12AffineEnvironment.transform 22 98767 env56771 = env56772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env56771 == env56772) = true)

theorem identity56772 : scanCanonicalize (H12AffineFastState.compose env56772 (packedSelected [6,25] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound56772 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env56773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,4096,397,98767,73737,8328,98719,303492,4176,77955,100614,41992,40968,257,98598,78035,513]

theorem envBound56773 : H12AffineFastState.Bounded env56773 := by
  intro p hp
  have h : env56773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56772_56773 : H12AffineEnvironment.transform 16 78035 env56772 = env56773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env56772 == env56773) = true)

theorem identity56773 : scanCanonicalize (H12AffineFastState.compose env56773 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound56773 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56774 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,32768,65536,77835,262144,1024,32768,4096,341,98583,73737,8272,98631,303452,4176,77915,100614,41992,40968,257,98598,77835,513]

theorem envBound56774 : H12AffineFastState.Bounded env56774 := by
  intro p hp
  have h : env56774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56773_56774 : H12AffineEnvironment.transform 6 88 env56773 = env56774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env56773 == env56774) = true)

theorem identity56774 : scanCanonicalize (H12AffineFastState.compose env56774 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound56774 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env56775 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,32768,8282,4177,262144,1024,32768,4096,341,41293,83,8272,41245,303452,4176,4097,43356,41992,40968,257,41340,4177,513]

theorem envBound56775 : H12AffineFastState.Bounded env56775 := by
  intro p hp
  have h : env56775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56774_56775 : H12AffineEnvironment.transform 15 8282 env56774 = env56775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env56774 == env56775) = true)

theorem identity56775 : scanCanonicalize (H12AffineFastState.compose env56775 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound56775 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56776 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,112,8282,4177,262144,1024,112,4096,341,8509,83,8272,8557,270636,4176,4097,10540,9336,8312,257,8460,4177,513]

theorem envBound56776 : H12AffineFastState.Bounded env56776 := by
  intro p hp
  have h : env56776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56775_56776 : H12AffineEnvironment.transform 14 112 env56775 = env56776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env56775 == env56776) = true)

theorem identity56776 : scanCanonicalize (H12AffineFastState.compose env56776 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound56776 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56777 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4176,112,8282,4177,2049,1024,112,4096,341,8509,83,8272,8557,10541,4176,4097,10540,9336,8312,257,8460,4177,513]

theorem envBound56777 : H12AffineFastState.Bounded env56777 := by
  intro p hp
  have h : env56777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56776_56777 : H12AffineEnvironment.transform 17 2049 env56776 = env56777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env56776 == env56777) = true)

theorem identity56777 : scanCanonicalize (H12AffineFastState.compose env56777 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56777 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56778 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,8192,4176,112,8282,4177,2049,1024,112,4096,33,8265,83,8272,8217,10329,4176,4097,10328,9336,8312,117,8312,4177,513]

theorem envBound56778 : H12AffineFastState.Bounded env56778 := by
  intro p hp
  have h : env56778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56777_56778 : H12AffineEnvironment.transform 7 116 env56777 = env56778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56777 == env56778) = true)

theorem identity56778 : scanCanonicalize (H12AffineFastState.compose env56778 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56778 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56779 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,4096,32,8202,4097,2049,1024,32,4096,33,8217,3,8192,8217,10249,4096,4097,10248,9256,8232,37,8232,4097,513]

theorem envBound56779 : H12AffineFastState.Bounded env56779 := by
  intro p hp
  have h : env56779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56778_56779 : H12AffineEnvironment.transform 5 16 env56778 = env56779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56778 == env56779) = true)

theorem identity56779 : scanCanonicalize (H12AffineFastState.compose env56779 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound56779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56780 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8,4096,32,2,4097,2049,1024,32,4096,33,17,3,8,17,2049,4096,4097,2048,1056,32,37,32,4097,513]

theorem envBound56780 : H12AffineFastState.Bounded env56780 := by
  intro p hp
  have h : env56780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56779_56780 : H12AffineEnvironment.transform 12 8 env56779 = env56780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env56779 == env56780) = true)

theorem identity56780 : scanCanonicalize (H12AffineFastState.compose env56780 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 3094) := by decide +kernel

theorem selectedBound56780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56781 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3094,8,3094,32,2,3095,2049,1024,32,3094,33,17,3,8,17,2049,3094,3095,2048,1056,32,37,32,3095,513]

theorem envBound56781 : H12AffineFastState.Bounded env56781 := by
  intro p hp
  have h : env56781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56780_56781 : H12AffineEnvironment.transform 11 3094 env56780 = env56781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3094 env56780 == env56781) = true)

theorem identity56781 : scanCanonicalize (H12AffineFastState.compose env56781 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 550) := by decide +kernel

theorem selectedBound56781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56782 : List Nat := [2,4,8,16,32,16,8,36,512,550,2048,2608,8,2608,32,2,2609,2049,550,32,2608,33,17,3,8,17,2049,2608,2609,2048,518,32,37,32,2609,513]

theorem envBound56782 : H12AffineFastState.Bounded env56782 := by
  intro p hp
  have h : env56782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56781_56782 : H12AffineEnvironment.transform 9 550 env56781 = env56782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 550 env56781 == env56782) = true)

theorem identity56782 : scanCanonicalize (H12AffineFastState.compose env56782 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound56782 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56783 : List Nat := [2,4,8,9,32,9,8,36,512,550,2048,2601,8,2601,32,2,2600,2049,550,32,2601,33,8,3,8,8,2049,2601,2600,2048,518,32,37,32,2600,513]

theorem envBound56783 : H12AffineFastState.Bounded env56783 := by
  intro p hp
  have h : env56783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56782_56783 : H12AffineEnvironment.transform 3 9 env56782 = env56783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env56782 == env56783) = true)

theorem identity56783 : scanCanonicalize (H12AffineFastState.compose env56783 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56783 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56784 : List Nat := [0,4,8,9,32,9,8,36,512,548,2048,2601,8,2601,32,0,2600,2049,548,32,2601,33,8,1,8,8,2049,2601,2600,2048,516,32,37,32,2600,513]

theorem envBound56784 : H12AffineFastState.Bounded env56784 := by
  intro p hp
  have h : env56784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56783_56784 : H12AffineEnvironment.transform 0 0 env56783 = env56784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56783 == env56784) = true)

theorem identity56784 : scanCanonicalize (H12AffineFastState.compose env56784 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound56784 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env56785 : List Nat := [0,4,8,9,32,9,8,36,512,548,32,521,8,521,32,0,520,33,548,32,521,33,8,1,8,8,33,521,520,32,516,32,37,32,520,513]

theorem envBound56785 : H12AffineFastState.Bounded env56785 := by
  intro p hp
  have h : env56785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56784_56785 : H12AffineEnvironment.transform 10 32 env56784 = env56785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env56784 == env56785) = true)

theorem identity56785 : scanCanonicalize (H12AffineFastState.compose env56785 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound56785 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56786 : List Nat := [0,4,8,9,32,9,8,36,40,12,32,33,8,33,32,0,32,33,12,32,33,33,8,1,8,8,33,33,32,32,44,32,37,32,32,41]

theorem envBound56786 : H12AffineFastState.Bounded env56786 := by
  intro p hp
  have h : env56786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56785_56786 : H12AffineEnvironment.transform 8 40 env56785 = env56786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env56785 == env56786) = true)

theorem identity56786 : scanCanonicalize (H12AffineFastState.compose env56786 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound56786 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56787 : List Nat := [0,4,8,9,9,9,8,13,1,12,9,8,8,8,9,0,9,8,12,9,8,8,8,1,8,8,8,8,9,9,5,9,12,9,9,0]

theorem envBound56787 : H12AffineFastState.Bounded env56787 := by
  intro p hp
  have h : env56787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56786_56787 : H12AffineEnvironment.transform 4 9 env56786 = env56787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env56786 == env56787) = true)

def env56788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8388689,12980500,4177,131152,4294794,8463815,8462791,257,4292778,131072,33563273]

theorem envBound56788 : H12AffineFastState.Bounded env56788 := by
  intro p hp
  have h : env56788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56767_56788 : H12AffineEnvironment.transform 13 4177 env56767 = env56788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56767 == env56788) = true)

def env56789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,33554432,6329801,2524300,4177,131152,4294794,6402143,6403167,257,4292778,131072,33563273]

theorem envBound56789 : H12AffineFastState.Bounded env56789 := by
  intro p hp
  have h : env56789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56788_56789 : H12AffineEnvironment.transform 22 6329752 env56788 = env56789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env56788 == env56789) = true)

def env56790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,4227080,6329801,2524300,4177,131152,4294794,6402143,6403167,257,4292778,131072,4235905]

theorem envBound56790 : H12AffineFastState.Bounded env56790 := by
  intro p hp
  have h : env56790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56789_56790 : H12AffineEnvironment.transform 24 4227080 env56789 = env56790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env56789 == env56790) = true)

theorem identity56790 : scanCanonicalize (H12AffineFastState.compose env56790 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound56790 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,41088,2110744,2135262,8328,2110793,2524300,4177,131152,75786,2167007,2168031,257,73770,131072,513]

theorem envBound56791 : H12AffineFastState.Bounded env56791 := by
  intro p hp
  have h : env56791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56790_56791 : H12AffineEnvironment.transform 21 41088 env56790 = env56791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56790 == env56791) = true)

theorem identity56791 : scanCanonicalize (H12AffineFastState.compose env56791 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111831) := by decide +kernel

theorem selectedBound56791 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,111831,41088,98767,73737,8328,98718,471131,4177,131152,75786,41992,40968,257,73770,131072,513]

theorem envBound56792 : H12AffineFastState.Bounded env56792 := by
  intro p hp
  have h : env56792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56791_56792 : H12AffineEnvironment.transform 20 111831 env56791 = env56792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111831 env56791 == env56792) = true)

theorem identity56792 : scanCanonicalize (H12AffineFastState.compose env56792 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13576) := by decide +kernel

theorem selectedBound56792 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13576,262144,1024,32768,111831,41088,98767,73737,8328,98718,329043,4177,13656,75786,41992,40968,257,73770,13576,513]

theorem envBound56793 : H12AffineFastState.Bounded env56793 := by
  intro p hp
  have h : env56793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56792_56793 : H12AffineEnvironment.transform 16 13576 env56792 = env56793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13576 env56792 == env56793) = true)

theorem identity56793 : scanCanonicalize (H12AffineFastState.compose env56793 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound56793 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env56794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,32803,13576,262144,1024,32768,13556,41088,492,41002,8328,445,296304,4177,13656,43049,41992,40968,257,40969,13576,513]

theorem envBound56794 : H12AffineFastState.Bounded env56794 := by
  intro p hp
  have h : env56794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56793_56794 : H12AffineEnvironment.transform 15 32803 env56793 = env56794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env56793 == env56794) = true)

theorem identity56794 : scanCanonicalize (H12AffineFastState.compose env56794 (packedSelected [0,1,4,5,6,7,8,9,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound56794 : packedSelected [0,1,4,5,6,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env56795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,8494,13576,262144,1024,8461,13556,397,492,295,8328,445,271485,4177,13656,2340,1285,261,257,260,13576,513]

theorem envBound56795 : H12AffineFastState.Bounded env56795 := by
  intro p hp
  have h : env56795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56794_56795 : H12AffineEnvironment.transform 14 8461 env56794 = env56795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env56794 == env56795) = true)

theorem identity56795 : scanCanonicalize (H12AffineFastState.compose env56795 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound56795 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env56796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,8494,13576,8001,1024,8461,13556,397,492,295,8328,445,15164,4177,13656,2340,1285,261,257,260,13576,513]

theorem envBound56796 : H12AffineFastState.Bounded env56796 := by
  intro p hp
  have h : env56796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56795_56796 : H12AffineEnvironment.transform 17 8001 env56795 = env56796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env56795 == env56796) = true)

theorem identity56796 : scanCanonicalize (H12AffineFastState.compose env56796 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound56796 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env56797 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,8461,8494,12929,6344,905,8461,13181,397,492,295,8328,445,15164,4177,13009,2340,652,261,257,260,12929,513]

theorem envBound56797 : H12AffineFastState.Bounded env56797 := by
  intro p hp
  have h : env56797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56796_56797 : H12AffineEnvironment.transform 9 905 env56796 = env56797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env56796 == env56797) = true)

theorem identity56797 : scanCanonicalize (H12AffineFastState.compose env56797 (packedSelected [6,25] rootPS)) = affineNative (2^(12+1) ^^^ 892) := by decide +kernel

theorem selectedBound56797 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env56798 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,892,4177,625,594,4605,6344,905,625,4097,397,492,295,1012,445,6208,4177,4525,2340,652,261,257,260,4605,513]

theorem envBound56798 : H12AffineFastState.Bounded env56798 := by
  intro p hp
  have h : env56798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56797_56798 : H12AffineEnvironment.transform 12 892 env56797 = env56798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 892 env56797 == env56798) = true)

theorem identity56798 : scanCanonicalize (H12AffineFastState.compose env56798 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56798 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56799 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,493,892,444,625,594,16,2341,905,625,492,397,492,295,1012,445,2477,444,64,2340,652,261,257,260,16,513]

theorem envBound56799 : H12AffineFastState.Bounded env56799 := by
  intro p hp
  have h : env56799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56798_56799 : H12AffineEnvironment.transform 11 493 env56798 = env56799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56798 == env56799) = true)

theorem identity56799 : scanCanonicalize (H12AffineFastState.compose env56799 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound56799 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56800 : List Nat := [2,4,8,16,32,64,128,256,217,336,2048,493,421,444,168,139,16,2341,336,168,492,397,492,295,301,445,2477,444,64,2340,85,261,257,260,16,216]

theorem envBound56800 : H12AffineFastState.Bounded env56800 := by
  intro p hp
  have h : env56800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56799_56800 : H12AffineEnvironment.transform 8 217 env56799 = env56800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env56799 == env56800) = true)

theorem identity56800 : scanCanonicalize (H12AffineFastState.compose env56800 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound56800 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56801 : List Nat := [2,4,8,16,32,27,128,256,130,267,2048,438,421,444,168,139,16,2341,267,168,439,397,439,295,301,445,2477,444,27,2340,14,261,257,260,16,131]

theorem envBound56801 : H12AffineFastState.Bounded env56801 := by
  intro p hp
  have h : env56801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56800_56801 : H12AffineEnvironment.transform 5 27 env56800 = env56801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env56800 == env56801) = true)

def env56802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,4227081,6329801,2524300,4177,131152,4294794,6402143,6403167,257,4292778,131072,4235904]

theorem envBound56802 : H12AffineFastState.Bounded env56802 := by
  intro p hp
  have h : env56802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56789_56802 : H12AffineEnvironment.transform 24 4227081 env56789 = env56802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env56789 == env56802) = true)

def env56803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,33554432,6329800,2524301,4177,131152,4294794,6402142,6403166,257,4292778,131072,33563273]

theorem envBound56803 : H12AffineFastState.Bounded env56803 := by
  intro p hp
  have h : env56803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56788_56803 : H12AffineEnvironment.transform 22 6329753 env56788 = env56803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env56788 == env56803) = true)

def env56804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,4227080,6329800,2524301,4177,131152,4294794,6402142,6403166,257,4292778,131072,4235905]

theorem envBound56804 : H12AffineFastState.Bounded env56804 := by
  intro p hp
  have h : env56804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56803_56804 : H12AffineEnvironment.transform 24 4227080 env56803 = env56804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env56803 == env56804) = true)

theorem identity56804 : scanCanonicalize (H12AffineFastState.compose env56804 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41088) := by decide +kernel

theorem selectedBound56804 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,41088,2110745,2135263,8328,2110792,2524301,4177,131152,75786,2167006,2168030,257,73770,131072,513]

theorem envBound56805 : H12AffineFastState.Bounded env56805 := by
  intro p hp
  have h : env56805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56804_56805 : H12AffineEnvironment.transform 21 41088 env56804 = env56805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56804 == env56805) = true)

theorem identity56805 : scanCanonicalize (H12AffineFastState.compose env56805 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111830) := by decide +kernel

theorem selectedBound56805 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,111830,41088,98767,73737,8328,98718,471131,4177,131152,75786,41992,40968,257,73770,131072,513]

theorem envBound56806 : H12AffineFastState.Bounded env56806 := by
  intro p hp
  have h : env56806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56805_56806 : H12AffineEnvironment.transform 20 111830 env56805 = env56806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111830 env56805 == env56806) = true)

theorem identity56806 : scanCanonicalize (H12AffineFastState.compose env56806 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13577) := by decide +kernel

theorem selectedBound56806 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13577,262144,1024,32768,111830,41088,98767,73737,8328,98718,329042,4177,13657,75786,41992,40968,257,73770,13577,513]

theorem envBound56807 : H12AffineFastState.Bounded env56807 := by
  intro p hp
  have h : env56807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56806_56807 : H12AffineEnvironment.transform 16 13577 env56806 = env56807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13577 env56806 == env56807) = true)

theorem identity56807 : scanCanonicalize (H12AffineFastState.compose env56807 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 1529) := by decide +kernel

theorem selectedBound56807 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env56808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,1529,65536,13577,262144,1024,1529,78127,9593,66614,73737,8328,66663,329042,4177,13657,75786,8689,9713,257,73770,13577,513]

theorem envBound56808 : H12AffineFastState.Bounded env56808 := by
  intro p hp
  have h : env56808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56807_56808 : H12AffineEnvironment.transform 14 1529 env56807 = env56808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1529 env56807 == env56808) = true)

theorem identity56808 : scanCanonicalize (H12AffineFastState.compose env56808 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound56808 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env56809 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,624,65536,12928,262144,905,624,78127,8944,66495,73737,8328,66542,328411,4177,13008,75786,8689,8824,257,73770,12928,513]

theorem envBound56809 : H12AffineFastState.Bounded env56809 := by
  intro p hp
  have h : env56809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56808_56809 : H12AffineEnvironment.transform 9 905 env56808 = env56809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env56808 == env56809) = true)

theorem identity56809 : scanCanonicalize (H12AffineFastState.compose env56809 (packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound56809 : packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env56810 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,4096,8192,4177,624,65536,12928,2341,905,624,78127,8944,66495,73737,8328,66542,68606,4177,13008,75786,8689,8824,257,73770,12928,513]

theorem envBound56810 : H12AffineFastState.Bounded env56810 := by
  intro p hp
  have h : env56810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56809_56810 : H12AffineEnvironment.transform 17 2341 env56809 = env56810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env56809 == env56810) = true)

theorem identity56810 : scanCanonicalize (H12AffineFastState.compose env56810 (packedSelected [0,3,4,5,7,9,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound56810 : packedSelected [0,3,4,5,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env56811 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,493,8192,444,624,65536,9069,2341,905,624,73922,8944,66495,73737,8328,66542,68606,444,9021,75786,8689,8824,257,73770,9069,513]

theorem envBound56811 : H12AffineFastState.Bounded env56811 := by
  intro p hp
  have h : env56811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56810_56811 : H12AffineEnvironment.transform 11 493 env56810 = env56811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env56810 == env56811) = true)

theorem identity56811 : scanCanonicalize (H12AffineFastState.compose env56811 (packedSelected [1,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 893) := by decide +kernel

theorem selectedBound56811 : packedSelected [1,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env56812 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,493,893,444,624,65536,16,2341,905,624,66495,397,66495,66420,1013,66542,68606,444,64,68471,652,261,257,66391,16,513]

theorem envBound56812 : H12AffineFastState.Bounded env56812 := by
  intro p hp
  have h : env56812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56811_56812 : H12AffineEnvironment.transform 12 893 env56811 = env56812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 893 env56811 == env56812) = true)

theorem identity56812 : scanCanonicalize (H12AffineFastState.compose env56812 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 594) := by decide +kernel

theorem selectedBound56812 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56813 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,493,893,444,624,594,16,2341,905,624,493,397,493,294,1013,444,2476,444,64,2341,652,261,257,261,16,513]

theorem envBound56813 : H12AffineFastState.Bounded env56813 := by
  intro p hp
  have h : env56813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56812_56813 : H12AffineEnvironment.transform 15 594 env56812 = env56813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 594 env56812 == env56813) = true)

theorem identity56813 : scanCanonicalize (H12AffineFastState.compose env56813 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound56813 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56814 : List Nat := [2,4,8,16,32,64,128,173,512,548,2048,64,720,17,624,594,16,2184,548,624,64,32,64,139,600,17,2049,17,64,2184,652,168,172,168,16,513]

theorem envBound56814 : H12AffineFastState.Bounded env56814 := by
  intro p hp
  have h : env56814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56813_56814 : H12AffineEnvironment.transform 7 173 env56813 = env56814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env56813 == env56814) = true)

theorem identity56814 : scanCanonicalize (H12AffineFastState.compose env56814 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56814 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56815 : List Nat := [2,4,8,16,32,64,128,173,48,20,2048,64,224,17,64,98,16,2184,20,64,64,32,64,139,104,17,2049,17,64,2184,188,168,172,168,16,49]

theorem envBound56815 : H12AffineFastState.Bounded env56815 := by
  intro p hp
  have h : env56815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56814_56815 : H12AffineEnvironment.transform 8 48 env56814 = env56815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56814 == env56815) = true)

theorem identity56815 : scanCanonicalize (H12AffineFastState.compose env56815 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound56815 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56816 : List Nat := [2,4,8,16,32,64,128,173,48,20,64,64,224,17,64,98,16,200,20,64,64,32,64,139,104,17,65,17,64,200,188,168,172,168,16,49]

theorem envBound56816 : H12AffineFastState.Bounded env56816 := by
  intro p hp
  have h : env56816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56815_56816 : H12AffineEnvironment.transform 10 64 env56815 = env56816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env56815 == env56816) = true)

theorem identity56816 : scanCanonicalize (H12AffineFastState.compose env56816 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound56816 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56817 : List Nat := [2,4,8,16,32,27,128,173,48,20,27,27,187,17,27,57,16,147,20,27,27,32,27,139,51,17,26,17,27,147,188,168,172,168,16,49]

theorem envBound56817 : H12AffineFastState.Bounded env56817 := by
  intro p hp
  have h : env56817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56816_56817 : H12AffineEnvironment.transform 5 27 env56816 = env56817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env56816 == env56817) = true)

theorem identity56817 : scanCanonicalize (H12AffineFastState.compose env56817 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56817 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56818 : List Nat := [2,4,8,16,32,27,3,46,48,20,27,27,56,17,27,57,16,16,20,27,27,32,27,8,51,17,26,17,27,16,63,43,47,43,16,49]

theorem envBound56818 : H12AffineFastState.Bounded env56818 := by
  intro p hp
  have h : env56818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56817_56818 : H12AffineEnvironment.transform 6 3 env56817 = env56818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56817 == env56818) = true)

theorem identity56818 : scanCanonicalize (H12AffineFastState.compose env56818 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound56818 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56819 : List Nat := [2,4,8,16,26,27,3,20,10,20,27,27,2,17,27,3,16,16,20,27,27,26,27,8,9,17,26,17,27,16,5,17,21,17,16,11]

theorem envBound56819 : H12AffineFastState.Bounded env56819 := by
  intro p hp
  have h : env56819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56818_56819 : H12AffineEnvironment.transform 4 26 env56818 = env56819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env56818 == env56819) = true)

theorem identity56819 : scanCanonicalize (H12AffineFastState.compose env56819 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56820 : List Nat := [0,4,8,16,24,25,1,20,8,20,25,25,0,17,25,1,16,16,20,25,25,24,25,8,9,17,24,17,25,16,5,17,21,17,16,9]

theorem envBound56820 : H12AffineFastState.Bounded env56820 := by
  intro p hp
  have h : env56820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56819_56820 : H12AffineEnvironment.transform 0 0 env56819 = env56820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56819 == env56820) = true)

theorem identity56820 : scanCanonicalize (H12AffineFastState.compose env56820 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56820 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env56821 : List Nat := [0,4,0,16,16,17,1,20,0,20,17,17,0,17,17,1,16,16,20,17,17,16,17,0,1,17,16,17,17,16,5,17,21,17,16,1]

theorem envBound56821 : H12AffineFastState.Bounded env56821 := by
  intro p hp
  have h : env56821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56820_56821 : H12AffineEnvironment.transform 2 0 env56820 = env56821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56820 == env56821) = true)

def env56822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,4227081,6329800,2524301,4177,131152,4294794,6402142,6403166,257,4292778,131072,4235904]

theorem envBound56822 : H12AffineFastState.Bounded env56822 := by
  intro p hp
  have h : env56822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56803_56822 : H12AffineEnvironment.transform 24 4227081 env56803 = env56822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env56803 == env56822) = true)

def env56823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131152,4315355,8463815,4294967296,257,4307611964,131073,33563273]

theorem envBound56823 : H12AffineFastState.Bounded env56823 := by
  intro p hp
  have h : env56823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56764_56823 : H12AffineEnvironment.transform 34 131073 env56764 = env56823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env56764 == env56823) = true)

theorem identity56823 : scanCanonicalize (H12AffineFastState.compose env56823 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 10564039) := by decide +kernel

theorem selectedBound56823 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env56824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,131152,4315355,8463815,10564039,257,6406395,131073,33563273]

theorem envBound56824 : H12AffineFastState.Bounded env56824 := by
  intro p hp
  have h : env56824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56823_56824 : H12AffineEnvironment.transform 31 10564039 env56823 = env56824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10564039 env56823 == env56824) = true)

theorem identity56824 : scanCanonicalize (H12AffineFastState.compose env56824 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound56824 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env56825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16384,77954,4315355,8463815,10564039,257,6406395,78035,33563273]

theorem envBound56825 : H12AffineFastState.Bounded env56825 := by
  intro p hp
  have h : env56825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56824_56825 : H12AffineEnvironment.transform 16 78034 env56824 = env56825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env56824 == env56825) = true)

def env56826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,10798236,16384,77954,4315355,8463815,10564039,257,6406395,78035,33563273]

theorem envBound56826 : H12AffineFastState.Bounded env56826 := by
  intro p hp
  have h : env56826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56825_56826 : H12AffineEnvironment.transform 26 10798236 env56825 = env56826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10798236 env56825 == env56826) = true)

def env56827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,4247640,8409088,10798236,16384,77954,4315355,8463815,10564039,257,6406395,78035,4256465]

theorem envBound56827 : H12AffineFastState.Bounded env56827 := by
  intro p hp
  have h : env56827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56826_56827 : H12AffineEnvironment.transform 24 4247640 env56826 = env56827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env56826 == env56827) = true)

def env56828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4486236,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound56828 : H12AffineFastState.Bounded env56828 := by
  intro p hp
  have h : env56828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56827_56828 : H12AffineEnvironment.transform 22 6336704 env56827 = env56828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env56827 == env56828) = true)

def env56829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4273308,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound56829 : H12AffineFastState.Bounded env56829 := by
  intro p hp
  have h : env56829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56828_56829 : H12AffineEnvironment.transform 17 82112 env56828 = env56829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env56828 == env56829) = true)

def env56830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142598,28888,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound56830 : H12AffineFastState.Bounded env56830 := by
  intro p hp
  have h : env56830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56829_56830 : H12AffineEnvironment.transform 21 41088 env56829 = env56830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56829 == env56830) = true)

theorem identity56830 : scanCanonicalize (H12AffineFastState.compose env56830 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 110715) := by decide +kernel

theorem selectedBound56830 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,110715,41088,106555,66045,28888,127035,103452,16384,77954,96347,34300,74119,257,53248,78035,21073]

theorem envBound56831 : H12AffineFastState.Bounded env56831 := by
  intro p hp
  have h : env56831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56830_56831 : H12AffineEnvironment.transform 20 110715 env56830 = env56831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110715 env56830 == env56831) = true)

theorem identity56831 : scanCanonicalize (H12AffineFastState.compose env56831 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound56831 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,78034,82112,1024,30112,83419,21792,87451,66045,28888,66971,90556,16384,77954,96347,28764,74119,257,9632,78035,21073]

theorem envBound56832 : H12AffineFastState.Bounded env56832 := by
  intro p hp
  have h : env56832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56831_56832 : H12AffineEnvironment.transform 14 30112 env56831 = env56832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env56831 == env56832) = true)

theorem identity56832 : scanCanonicalize (H12AffineFastState.compose env56832 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56832 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,65536,78034,69777,1024,9713,71050,1393,67018,66045,8329,66971,78317,4177,77954,75786,8205,74119,257,9632,78035,512]

theorem envBound56833 : H12AffineFastState.Bounded env56833 := by
  intro p hp
  have h : env56833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56832_56833 : H12AffineEnvironment.transform 13 4177 env56832 = env56833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56832 == env56833) = true)

theorem identity56833 : scanCanonicalize (H12AffineFastState.compose env56833 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound56833 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,9342,5292,13551,1024,9713,12788,1393,8628,9603,8329,8677,5523,4177,5372,3188,8205,1529,257,9632,5293,512]

theorem envBound56834 : H12AffineFastState.Bounded env56834 := by
  intro p hp
  have h : env56834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56833_56834 : H12AffineEnvironment.transform 15 9342 env56833 = env56834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env56833 == env56834) = true)

theorem identity56834 : scanCanonicalize (H12AffineFastState.compose env56834 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound56834 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,2830,2689,5292,6672,1024,2830,7947,1393,3915,2940,3702,3866,5523,4177,5372,3188,3826,1529,257,2911,5293,512]

theorem envBound56835 : H12AffineFastState.Bounded env56835 := by
  intro p hp
  have h : env56835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56834_56835 : H12AffineEnvironment.transform 12 3839 env56834 = env56835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env56834 == env56835) = true)

theorem identity56835 : scanCanonicalize (H12AffineFastState.compose env56835 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound56835 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56836 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,4096,2990,4177,2830,2689,4605,6672,337,2830,6746,32,2586,2940,2855,2635,4290,4177,4525,2341,2979,168,257,2911,4604,512]

theorem envBound56836 : H12AffineFastState.Bounded env56836 := by
  intro p hp
  have h : env56836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56835_56836 : H12AffineEnvironment.transform 9 337 env56835 = env56836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env56835 == env56836) = true)

def env56837 : List Nat := [2,4,8,16,32,64,128,4,512,85,2048,4096,2730,4177,2570,2689,4345,6672,85,2570,6746,32,2586,2680,2595,2635,4290,4177,4265,2081,2727,168,5,2651,4344,512]

theorem envBound56837 : H12AffineFastState.Bounded env56837 := by
  intro p hp
  have h : env56837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56836_56837 : H12AffineEnvironment.transform 7 4 env56836 = env56837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56836 == env56837) = true)

def env56838 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,4096,2730,4129,2570,2689,4233,6672,37,2570,6698,32,2586,2568,2595,2619,4274,4129,4265,2081,2727,168,5,2603,4232,512]

theorem envBound56838 : H12AffineFastState.Bounded env56838 := by
  intro p hp
  have h : env56838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56837_56838 : H12AffineEnvironment.transform 5 48 env56837 = env56838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56837 == env56838) = true)

theorem identity56838 : scanCanonicalize (H12AffineFastState.compose env56838 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound56838 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56839 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,554,2730,523,2570,2689,675,2106,37,2570,2048,32,2586,2568,2595,2619,664,523,643,2081,2727,168,5,2603,674,512]

theorem envBound56839 : H12AffineFastState.Bounded env56839 := by
  intro p hp
  have h : env56839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56838_56839 : H12AffineEnvironment.transform 11 554 env56838 = env56839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env56838 == env56839) = true)

def env56840 : List Nat := [2,4,8,16,16,0,128,4,512,21,2048,538,2714,523,2570,2689,659,2058,21,2570,2048,16,2586,2568,2579,2571,664,523,643,2065,2711,152,5,2587,658,512]

theorem envBound56840 : H12AffineFastState.Bounded env56840 := by
  intro p hp
  have h : env56840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56839_56840 : H12AffineEnvironment.transform 4 16 env56839 = env56840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56839 == env56840) = true)

theorem identity56840 : scanCanonicalize (H12AffineFastState.compose env56840 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56840 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56841 : List Nat := [2,4,8,16,16,0,2,4,512,21,2048,538,2584,523,2570,2563,529,2058,21,2570,2048,16,2586,2568,2579,2571,538,523,513,2065,2581,26,5,2587,528,512]

theorem envBound56841 : H12AffineFastState.Bounded env56841 := by
  intro p hp
  have h : env56841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56840_56841 : H12AffineEnvironment.transform 6 2 env56840 = env56841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56840 == env56841) = true)

theorem identity56841 : scanCanonicalize (H12AffineFastState.compose env56841 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound56841 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56842 : List Nat := [2,4,8,16,16,0,2,4,512,21,16,538,520,523,538,531,529,26,21,538,16,16,522,536,515,539,538,523,513,1,517,26,5,523,528,512]

theorem envBound56842 : H12AffineFastState.Bounded env56842 := by
  intro p hp
  have h : env56842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56841_56842 : H12AffineEnvironment.transform 10 16 env56841 = env56842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env56841 == env56842) = true)

theorem identity56842 : scanCanonicalize (H12AffineFastState.compose env56842 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56842 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56843 : List Nat := [2,4,8,10,10,0,2,4,512,15,10,512,520,523,512,521,523,0,15,512,10,10,522,514,515,513,512,523,513,1,517,0,5,523,522,512]

theorem envBound56843 : H12AffineFastState.Bounded env56843 := by
  intro p hp
  have h : env56843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56842_56843 : H12AffineEnvironment.transform 3 10 env56842 = env56843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56842 == env56843) = true)

theorem identity56843 : scanCanonicalize (H12AffineFastState.compose env56843 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound56843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56844 : List Nat := [2,4,8,10,10,0,2,4,10,15,10,10,2,1,10,3,1,0,15,10,10,10,0,8,9,11,10,1,11,1,15,0,5,1,0,10]

theorem envBound56844 : H12AffineFastState.Bounded env56844 := by
  intro p hp
  have h : env56844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56843_56844 : H12AffineEnvironment.transform 8 10 env56843 = env56844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env56843 == env56844) = true)

def env56845 : List Nat := [2,4,8,16,17,1,128,4,512,20,2048,539,2715,523,2570,2689,658,2059,20,2570,2048,17,2586,2568,2578,2570,664,523,643,2064,2710,153,5,2586,659,512]

theorem envBound56845 : H12AffineFastState.Bounded env56845 := by
  intro p hp
  have h : env56845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56839_56845 : H12AffineEnvironment.transform 4 17 env56839 = env56845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56839 == env56845) = true)

theorem identity56845 : scanCanonicalize (H12AffineFastState.compose env56845 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound56845 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56846 : List Nat := [2,4,8,16,17,1,128,4,512,20,648,539,19,523,130,9,658,643,20,130,648,17,146,128,154,130,664,523,643,664,30,153,5,146,659,512]

theorem envBound56846 : H12AffineFastState.Bounded env56846 := by
  intro p hp
  have h : env56846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56845_56846 : H12AffineEnvironment.transform 10 648 env56845 = env56846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env56845 == env56846) = true)

theorem identity56846 : scanCanonicalize (H12AffineFastState.compose env56846 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56846 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56847 : List Nat := [2,4,8,16,17,1,2,4,512,20,522,539,19,523,0,9,528,513,20,0,522,17,16,2,24,0,538,523,513,538,30,27,5,16,529,512]

theorem envBound56847 : H12AffineFastState.Bounded env56847 := by
  intro p hp
  have h : env56847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56846_56847 : H12AffineEnvironment.transform 6 2 env56846 = env56847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56846 == env56847) = true)

theorem identity56847 : scanCanonicalize (H12AffineFastState.compose env56847 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56847 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56848 : List Nat := [2,4,3,16,17,1,2,4,512,20,513,528,19,512,0,2,528,513,20,0,513,17,16,2,19,0,529,512,513,529,21,16,5,16,529,512]

theorem envBound56848 : H12AffineFastState.Bounded env56848 := by
  intro p hp
  have h : env56848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56847_56848 : H12AffineEnvironment.transform 2 3 env56847 = env56848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56847 == env56848) = true)

theorem identity56848 : scanCanonicalize (H12AffineFastState.compose env56848 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56848 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56849 : List Nat := [2,4,3,16,17,1,2,4,1,20,0,17,19,1,0,2,17,0,20,0,0,17,16,2,19,0,16,1,0,16,21,16,5,16,16,1]

theorem envBound56849 : H12AffineFastState.Bounded env56849 := by
  intro p hp
  have h : env56849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56848_56849 : H12AffineEnvironment.transform 8 1 env56848 = env56849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56848 == env56849) = true)

def env56850 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,4096,2730,4128,2570,2689,4232,6672,36,2570,6699,32,2586,2569,2595,2618,4275,4128,4265,2081,2727,168,5,2602,4233,512]

theorem envBound56850 : H12AffineFastState.Bounded env56850 := by
  intro p hp
  have h : env56850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56837_56850 : H12AffineEnvironment.transform 5 49 env56837 = env56850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56837 == env56850) = true)

theorem identity56850 : scanCanonicalize (H12AffineFastState.compose env56850 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound56850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56851 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,643,2730,675,2570,2689,523,2195,36,2570,2216,32,2586,2569,2595,2618,560,675,554,2081,2727,168,5,2602,522,512]

theorem envBound56851 : H12AffineFastState.Bounded env56851 := by
  intro p hp
  have h : env56851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56850_56851 : H12AffineEnvironment.transform 11 643 env56850 = env56851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env56850 == env56851) = true)

def env56852 : List Nat := [2,4,8,0,32,33,128,4,512,36,2048,643,2730,675,2570,2689,523,2179,36,2570,2216,32,2570,2569,2595,2602,544,675,554,2081,2727,168,5,2602,522,512]

theorem envBound56852 : H12AffineFastState.Bounded env56852 := by
  intro p hp
  have h : env56852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56852 : H12AffineEnvironment.transform 3 0 env56851 = env56852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56851 == env56852) = true)

theorem identity56852 : scanCanonicalize (H12AffineFastState.compose env56852 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound56852 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56853 : List Nat := [2,4,8,0,32,33,128,4,512,36,642,643,40,675,136,3,523,513,36,136,554,32,136,139,161,168,544,675,554,675,37,168,5,168,522,512]

theorem envBound56853 : H12AffineFastState.Bounded env56853 := by
  intro p hp
  have h : env56853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56852_56853 : H12AffineEnvironment.transform 10 642 env56852 = env56853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env56852 == env56853) = true)

theorem identity56853 : scanCanonicalize (H12AffineFastState.compose env56853 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56853 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56854 : List Nat := [2,4,8,0,32,33,3,4,512,36,513,512,40,544,11,3,523,513,36,11,554,32,11,8,34,43,544,544,554,544,37,43,5,43,522,512]

theorem envBound56854 : H12AffineFastState.Bounded env56854 := by
  intro p hp
  have h : env56854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56853_56854 : H12AffineEnvironment.transform 6 3 env56853 = env56854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56853 == env56854) = true)

theorem identity56854 : scanCanonicalize (H12AffineFastState.compose env56854 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56854 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env56855 : List Nat := [2,4,8,0,32,33,3,4,0,36,1,0,40,32,11,3,11,1,36,11,42,32,11,8,34,43,32,32,42,32,37,43,5,43,10,0]

theorem envBound56855 : H12AffineFastState.Bounded env56855 := by
  intro p hp
  have h : env56855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56854_56855 : H12AffineEnvironment.transform 8 0 env56854 = env56855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56854 == env56855) = true)

theorem identity56855 : scanCanonicalize (H12AffineFastState.compose env56855 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56855 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56856 : List Nat := [2,4,8,0,0,1,3,4,0,4,1,0,8,0,11,3,11,1,4,11,10,0,11,8,2,11,0,0,10,0,5,11,5,11,10,0]

theorem envBound56856 : H12AffineFastState.Bounded env56856 := by
  intro p hp
  have h : env56856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56855_56856 : H12AffineEnvironment.transform 4 0 env56855 = env56856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56855 == env56856) = true)

def env56857 : List Nat := [2,4,8,1,32,32,128,4,512,36,2048,643,2730,675,2570,2689,523,2178,36,2570,2216,32,2571,2569,2595,2603,545,675,554,2081,2727,168,5,2602,522,512]

theorem envBound56857 : H12AffineFastState.Bounded env56857 := by
  intro p hp
  have h : env56857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56857 : H12AffineEnvironment.transform 3 1 env56851 = env56857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56851 == env56857) = true)

theorem identity56857 : scanCanonicalize (H12AffineFastState.compose env56857 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56857 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56858 : List Nat := [2,4,8,1,32,32,8,4,512,36,2048,523,2594,555,2570,2569,523,2058,36,2570,2080,32,2571,2569,2595,2603,545,555,554,2081,2607,32,5,2602,522,512]

theorem envBound56858 : H12AffineFastState.Bounded env56858 := by
  intro p hp
  have h : env56858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56857_56858 : H12AffineEnvironment.transform 6 8 env56857 = env56858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56857 == env56858) = true)

theorem identity56858 : scanCanonicalize (H12AffineFastState.compose env56858 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound56858 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env56859 : List Nat := [2,4,8,1,32,32,8,4,512,36,512,523,34,555,10,9,523,522,36,10,544,32,11,9,35,43,545,555,554,545,47,32,5,42,522,512]

theorem envBound56859 : H12AffineFastState.Bounded env56859 := by
  intro p hp
  have h : env56859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56858_56859 : H12AffineEnvironment.transform 10 512 env56858 = env56859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env56858 == env56859) = true)

theorem identity56859 : scanCanonicalize (H12AffineFastState.compose env56859 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56859 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56860 : List Nat := [2,4,2,1,32,32,2,4,512,36,512,513,34,545,0,3,513,512,36,0,544,32,1,3,35,33,545,545,544,545,37,32,5,32,512,512]

theorem envBound56860 : H12AffineFastState.Bounded env56860 := by
  intro p hp
  have h : env56860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56859_56860 : H12AffineEnvironment.transform 2 2 env56859 = env56860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56859 == env56860) = true)

theorem identity56860 : scanCanonicalize (H12AffineFastState.compose env56860 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56860 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56861 : List Nat := [2,4,2,1,32,32,2,4,1,36,1,0,34,32,0,3,0,1,36,0,33,32,1,3,35,33,32,32,33,32,37,32,5,32,1,1]

theorem envBound56861 : H12AffineFastState.Bounded env56861 := by
  intro p hp
  have h : env56861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56860_56861 : H12AffineEnvironment.transform 8 1 env56860 = env56861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56860 == env56861) = true)

def env56862 : List Nat := [2,4,8,16,32,64,128,5,512,84,2048,4096,2731,4177,2571,2689,4344,6672,84,2571,6746,32,2586,2681,2594,2635,4290,4177,4264,2080,2726,168,4,2650,4345,512]

theorem envBound56862 : H12AffineFastState.Bounded env56862 := by
  intro p hp
  have h : env56862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56836_56862 : H12AffineEnvironment.transform 7 5 env56836 = env56862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56836 == env56862) = true)

def env56863 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,4096,2731,4129,2571,2689,4232,6672,36,2571,6698,32,2586,2569,2594,2619,4274,4129,4264,2080,2726,168,4,2602,4233,512]

theorem envBound56863 : H12AffineFastState.Bounded env56863 := by
  intro p hp
  have h : env56863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56862_56863 : H12AffineEnvironment.transform 5 48 env56862 = env56863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56862 == env56863) = true)

theorem identity56863 : scanCanonicalize (H12AffineFastState.compose env56863 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound56863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56864 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,2048,2731,2081,2571,2689,2184,528,36,2571,554,32,2586,2569,2594,2619,2226,2081,2216,2080,2726,168,4,2602,2185,512]

theorem envBound56864 : H12AffineFastState.Bounded env56864 := by
  intro p hp
  have h : env56864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56863_56864 : H12AffineEnvironment.transform 11 2048 env56863 = env56864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env56863 == env56864) = true)

def env56865 : List Nat := [2,4,8,16,0,16,128,5,512,4,2048,2048,2699,2049,2571,2689,2184,528,4,2571,522,0,2586,2569,2562,2587,2194,2049,2184,2048,2694,136,4,2570,2185,512]

theorem envBound56865 : H12AffineFastState.Bounded env56865 := by
  intro p hp
  have h : env56865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56864_56865 : H12AffineEnvironment.transform 4 0 env56864 = env56865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56864 == env56865) = true)

theorem identity56865 : scanCanonicalize (H12AffineFastState.compose env56865 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound56865 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56866 : List Nat := [2,4,8,16,0,16,128,5,512,4,658,658,25,659,153,19,538,528,4,153,522,0,136,155,144,137,512,659,538,658,20,136,4,152,539,512]

theorem envBound56866 : H12AffineFastState.Bounded env56866 := by
  intro p hp
  have h : env56866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56865_56866 : H12AffineEnvironment.transform 10 658 env56865 = env56866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env56865 == env56866) = true)

theorem identity56866 : scanCanonicalize (H12AffineFastState.compose env56866 (packedSelected [3,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56866 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env56867 : List Nat := [2,4,8,11,0,11,128,5,512,4,649,649,2,648,130,8,513,523,4,130,522,0,136,128,139,137,512,648,513,649,15,136,4,131,512,512]

theorem envBound56867 : H12AffineFastState.Bounded env56867 := by
  intro p hp
  have h : env56867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56866_56867 : H12AffineEnvironment.transform 3 11 env56866 = env56867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56866 == env56867) = true)

theorem identity56867 : scanCanonicalize (H12AffineFastState.compose env56867 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56867 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env56868 : List Nat := [2,4,8,11,0,11,128,5,1,4,136,136,2,137,130,8,0,10,4,130,11,0,136,128,139,137,1,137,0,136,15,136,4,131,1,1]

theorem envBound56868 : H12AffineFastState.Bounded env56868 := by
  intro p hp
  have h : env56868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56867_56868 : H12AffineEnvironment.transform 8 1 env56867 = env56868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56867 == env56868) = true)

def env56869 : List Nat := [2,4,8,16,1,17,128,5,512,5,2048,2048,2698,2048,2571,2689,2184,528,5,2571,523,1,2586,2569,2563,2586,2195,2048,2185,2049,2695,137,4,2571,2185,512]

theorem envBound56869 : H12AffineFastState.Bounded env56869 := by
  intro p hp
  have h : env56869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56864_56869 : H12AffineEnvironment.transform 4 1 env56864 = env56869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56864 == env56869) = true)

theorem identity56869 : scanCanonicalize (H12AffineFastState.compose env56869 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound56869 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56870 : List Nat := [2,4,8,16,1,17,128,5,512,5,664,664,18,664,147,25,528,528,5,147,523,1,130,145,155,130,523,664,529,665,31,137,4,147,529,512]

theorem envBound56870 : H12AffineFastState.Bounded env56870 := by
  intro p hp
  have h : env56870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56869_56870 : H12AffineEnvironment.transform 10 664 env56869 = env56870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env56869 == env56870) = true)

theorem identity56870 : scanCanonicalize (H12AffineFastState.compose env56870 (packedSelected [4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56870 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env56871 : List Nat := [2,4,8,16,1,17,128,5,1,5,153,153,18,153,147,25,17,17,5,147,10,1,130,145,155,130,10,153,16,152,31,137,4,147,16,1]

theorem envBound56871 : H12AffineFastState.Bounded env56871 := by
  intro p hp
  have h : env56871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56870_56871 : H12AffineEnvironment.transform 8 1 env56870 = env56871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56870 == env56871) = true)

theorem identity56871 : scanCanonicalize (H12AffineFastState.compose env56871 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56871 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56872 : List Nat := [2,4,8,16,1,17,3,5,1,5,26,26,18,26,16,25,17,17,5,16,10,1,1,18,24,1,10,26,16,27,31,10,4,16,16,1]

theorem envBound56872 : H12AffineFastState.Bounded env56872 := by
  intro p hp
  have h : env56872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56871_56872 : H12AffineEnvironment.transform 6 3 env56871 = env56872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56871 == env56872) = true)

theorem identity56872 : scanCanonicalize (H12AffineFastState.compose env56872 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56872 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56873 : List Nat := [2,4,8,1,1,0,3,5,1,5,11,11,3,11,1,8,0,0,5,1,10,1,1,3,9,1,10,11,1,10,14,10,4,1,1,1]

theorem envBound56873 : H12AffineFastState.Bounded env56873 := by
  intro p hp
  have h : env56873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56872_56873 : H12AffineEnvironment.transform 3 1 env56872 = env56873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56872 == env56873) = true)

theorem identity56873 : scanCanonicalize (H12AffineFastState.compose env56873 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56873 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56874 : List Nat := [2,4,3,1,1,0,3,5,1,5,0,0,3,0,1,3,0,0,5,1,1,1,1,3,2,1,1,0,1,1,5,1,4,1,1,1]

theorem envBound56874 : H12AffineFastState.Bounded env56874 := by
  intro p hp
  have h : env56874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56873_56874 : H12AffineEnvironment.transform 2 3 env56873 = env56874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56873 == env56874) = true)

def env56875 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,4096,2731,4128,2571,2689,4233,6672,37,2571,6699,32,2586,2568,2594,2618,4275,4128,4264,2080,2726,168,4,2603,4232,512]

theorem envBound56875 : H12AffineFastState.Bounded env56875 := by
  intro p hp
  have h : env56875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56862_56875 : H12AffineEnvironment.transform 5 49 env56862 = env56875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56862 == env56875) = true)

theorem identity56875 : scanCanonicalize (H12AffineFastState.compose env56875 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound56875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56876 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,2217,2731,2185,2571,2689,2080,697,37,2571,642,32,2586,2568,2594,2618,2074,2185,2049,2080,2726,168,4,2603,2081,512]

theorem envBound56876 : H12AffineFastState.Bounded env56876 := by
  intro p hp
  have h : env56876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56875_56876 : H12AffineEnvironment.transform 11 2217 env56875 = env56876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env56875 == env56876) = true)

def env56877 : List Nat := [2,4,8,16,32,49,128,5,512,37,648,545,35,513,131,9,680,697,37,131,642,32,146,128,170,178,658,513,649,680,46,168,4,163,681,512]

theorem envBound56877 : H12AffineFastState.Bounded env56877 := by
  intro p hp
  have h : env56877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56876_56877 : H12AffineEnvironment.transform 10 648 env56876 = env56877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env56876 == env56877) = true)

theorem identity56877 : scanCanonicalize (H12AffineFastState.compose env56877 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56877 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56878 : List Nat := [2,4,2,16,32,49,128,5,512,37,642,545,35,513,131,3,674,691,37,131,642,32,146,128,160,178,658,513,643,674,36,162,4,163,675,512]

theorem envBound56878 : H12AffineFastState.Bounded env56878 := by
  intro p hp
  have h : env56878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56877_56878 : H12AffineEnvironment.transform 2 2 env56877 = env56878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56877 == env56878) = true)

theorem identity56878 : scanCanonicalize (H12AffineFastState.compose env56878 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound56878 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56879 : List Nat := [2,4,2,16,32,49,50,5,512,37,560,545,35,513,49,3,528,513,37,49,560,32,32,50,18,0,544,513,561,528,36,16,4,17,529,512]

theorem envBound56879 : H12AffineFastState.Bounded env56879 := by
  intro p hp
  have h : env56879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56878_56879 : H12AffineEnvironment.transform 6 50 env56878 = env56879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env56878 == env56879) = true)

theorem identity56879 : scanCanonicalize (H12AffineFastState.compose env56879 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56879 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56880 : List Nat := [2,4,2,16,0,17,18,5,512,5,528,513,3,513,17,3,528,513,5,17,528,0,0,18,18,0,512,513,529,528,4,16,4,17,529,512]

theorem envBound56880 : H12AffineFastState.Bounded env56880 := by
  intro p hp
  have h : env56880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56879_56880 : H12AffineEnvironment.transform 4 0 env56879 = env56880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56879 == env56880) = true)

def env56881 : List Nat := [2,4,8,16,32,49,128,5,512,37,649,544,34,512,130,8,681,697,37,130,642,32,147,129,171,179,659,512,648,681,47,168,4,162,680,512]

theorem envBound56881 : H12AffineFastState.Bounded env56881 := by
  intro p hp
  have h : env56881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56876_56881 : H12AffineEnvironment.transform 10 649 env56876 = env56881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env56876 == env56881) = true)

theorem identity56881 : scanCanonicalize (H12AffineFastState.compose env56881 (packedSelected [1,3,4,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56881 : packedSelected [1,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env56882 : List Nat := [2,4,8,16,32,49,3,5,512,37,522,544,34,512,1,8,554,570,37,1,513,32,16,2,40,48,528,512,523,554,47,43,4,33,555,512]

theorem envBound56882 : H12AffineFastState.Bounded env56882 := by
  intro p hp
  have h : env56882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56881_56882 : H12AffineEnvironment.transform 6 3 env56881 = env56882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56881 == env56882) = true)

theorem identity56882 : scanCanonicalize (H12AffineFastState.compose env56882 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56882 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56883 : List Nat := [2,4,8,16,17,0,3,5,512,20,522,529,19,512,1,8,539,523,20,1,513,17,16,2,25,1,528,512,523,539,30,26,4,16,538,512]

theorem envBound56883 : H12AffineFastState.Bounded env56883 := by
  intro p hp
  have h : env56883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56882_56883 : H12AffineEnvironment.transform 4 17 env56882 = env56883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56882 == env56883) = true)

theorem identity56883 : scanCanonicalize (H12AffineFastState.compose env56883 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56883 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56884 : List Nat := [2,4,3,16,17,0,3,5,512,20,513,529,19,512,1,3,528,512,20,1,513,17,16,2,18,1,528,512,512,528,21,17,4,16,529,512]

theorem envBound56884 : H12AffineFastState.Bounded env56884 := by
  intro p hp
  have h : env56884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56883_56884 : H12AffineEnvironment.transform 2 3 env56883 = env56884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56883 == env56884) = true)

def env56885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142599,28889,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound56885 : H12AffineFastState.Bounded env56885 := by
  intro p hp
  have h : env56885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56829_56885 : H12AffineEnvironment.transform 21 41089 env56829 = env56885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56829 == env56885) = true)

theorem identity56885 : scanCanonicalize (H12AffineFastState.compose env56885 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 128314) := by decide +kernel

theorem selectedBound56885 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,128314,41089,124283,83133,28889,111995,103453,16384,77954,96346,49340,74118,257,38208,78035,21072]

theorem envBound56886 : H12AffineFastState.Bounded env56886 := by
  intro p hp
  have h : env56886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56885_56886 : H12AffineEnvironment.transform 20 128314 env56885 = env56886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 128314 env56885 == env56886) = true)

theorem identity56886 : scanCanonicalize (H12AffineFastState.compose env56886 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound56886 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,32768,65536,78034,79257,1024,32768,98403,41089,102434,78308,1408,111995,103453,13657,77954,68867,46565,74118,257,38208,78035,9993]

theorem envBound56887 : H12AffineFastState.Bounded env56887 := by
  intro p hp
  have h : env56887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56886_56887 : H12AffineEnvironment.transform 13 13657 env56886 = env56887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env56886 == env56887) = true)

theorem identity56887 : scanCanonicalize (H12AffineFastState.compose env56887 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5608) := by decide +kernel

theorem selectedBound56887 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5608,65536,78034,79257,1024,5608,71051,13673,67018,78308,1408,73875,66037,13657,77954,68867,8205,74118,257,168,78035,9993]

theorem envBound56888 : H12AffineFastState.Bounded env56888 := by
  intro p hp
  have h : env56888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56887_56888 : H12AffineEnvironment.transform 14 5608 env56887 = env56888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5608 env56887 == env56888) = true)

theorem identity56888 : scanCanonicalize (H12AffineFastState.compose env56888 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1418) := by decide +kernel

theorem selectedBound56888 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env56889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5608,1418,13656,12307,1024,5608,4097,13673,64,13422,1408,9497,1151,13657,13576,2185,8205,9228,257,168,13657,9993]

theorem envBound56889 : H12AffineFastState.Bounded env56889 := by
  intro p hp
  have h : env56889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56888_56889 : H12AffineEnvironment.transform 15 1418 env56888 = env56889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1418 env56888 == env56889) = true)

theorem identity56889 : scanCanonicalize (H12AffineFastState.compose env56889 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56889 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,1418,4176,5403,1024,5608,4097,4193,64,4454,1408,17,1151,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound56890 : H12AffineFastState.Bounded env56890 := by
  intro p hp
  have h : env56890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56889_56890 : H12AffineEnvironment.transform 12 1288 env56889 = env56890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56889 == env56890) = true)

theorem identity56890 : scanCanonicalize (H12AffineFastState.compose env56890 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3814) := by decide +kernel

theorem selectedBound56890 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,1288,3767,2830,1418,3766,3069,1024,2830,3815,3719,64,3968,1408,17,1151,3767,3814,2185,1285,260,257,168,3767,513]

theorem envBound56891 : H12AffineFastState.Bounded env56891 := by
  intro p hp
  have h : env56891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56890_56891 : H12AffineEnvironment.transform 11 3814 env56890 = env56891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3814 env56890 == env56891) = true)

theorem identity56891 : scanCanonicalize (H12AffineFastState.compose env56891 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound56891 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56892 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,2415,641,2366,2830,515,2367,3069,905,2830,2414,2318,64,2057,521,17,1014,2366,2415,2185,652,260,257,168,2366,513]

theorem envBound56892 : H12AffineFastState.Bounded env56892 := by
  intro p hp
  have h : env56892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56891_56892 : H12AffineEnvironment.transform 9 905 env56891 = env56892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env56891 == env56892) = true)

theorem identity56892 : scanCanonicalize (H12AffineFastState.compose env56892 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound56892 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56893 : List Nat := [2,4,8,16,32,64,128,256,372,253,2048,2415,501,2366,2170,375,2367,2185,253,2170,2414,2318,64,2057,381,17,130,2366,2415,2185,504,260,257,168,2366,373]

theorem envBound56893 : H12AffineFastState.Bounded env56893 := by
  intro p hp
  have h : env56893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56892_56893 : H12AffineEnvironment.transform 8 372 env56892 = env56893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env56892 == env56893) = true)

theorem identity56893 : scanCanonicalize (H12AffineFastState.compose env56893 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound56893 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56894 : List Nat := [2,4,8,16,32,64,128,256,372,253,130,493,501,444,248,375,445,11,253,248,492,396,64,139,381,17,130,444,493,11,504,260,257,168,444,373]

theorem envBound56894 : H12AffineFastState.Bounded env56894 := by
  intro p hp
  have h : env56894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56893_56894 : H12AffineEnvironment.transform 10 130 env56893 = env56894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env56893 == env56894) = true)

theorem identity56894 : scanCanonicalize (H12AffineFastState.compose env56894 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 199) := by decide +kernel

theorem selectedBound56894 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56895 : List Nat := [2,4,8,16,32,64,128,199,179,253,130,42,50,123,248,176,122,11,253,248,43,75,64,139,186,17,130,123,42,11,63,195,198,168,123,178]

theorem envBound56895 : H12AffineFastState.Bounded env56895 := by
  intro p hp
  have h : env56895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56894_56895 : H12AffineEnvironment.transform 7 199 env56894 = env56895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 199 env56894 == env56895) = true)

def env56896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4273309,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound56896 : H12AffineFastState.Bounded env56896 := by
  intro p hp
  have h : env56896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56828_56896 : H12AffineEnvironment.transform 17 82113 env56828 = env56896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env56828 == env56896) = true)

def env56897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142598,28888,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound56897 : H12AffineFastState.Bounded env56897 := by
  intro p hp
  have h : env56897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56896_56897 : H12AffineEnvironment.transform 21 41088 env56896 = env56897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56896 == env56897) = true)

theorem identity56897 : scanCanonicalize (H12AffineFastState.compose env56897 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 122923) := by decide +kernel

theorem selectedBound56897 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,122923,41088,127083,86445,28888,106603,103453,16384,77954,96347,54700,74119,257,32848,78035,21073]

theorem envBound56898 : H12AffineFastState.Bounded env56898 := by
  intro p hp
  have h : env56898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56897_56898 : H12AffineEnvironment.transform 20 122923 env56897 = env56898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122923 env56897 == env56898) = true)

theorem identity56898 : scanCanonicalize (H12AffineFastState.compose env56898 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound56898 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9712,65536,78034,82113,1024,9712,83419,1392,87451,86445,28888,66971,78317,16384,77954,96347,28764,74119,257,9632,78035,21073]

theorem envBound56899 : H12AffineFastState.Bounded env56899 := by
  intro p hp
  have h : env56899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56898_56899 : H12AffineEnvironment.transform 14 9712 env56898 = env56899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env56898 == env56899) = true)

theorem identity56899 : scanCanonicalize (H12AffineFastState.compose env56899 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56899 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,65536,78034,69776,1024,9712,71050,1392,67018,66044,8329,66971,78317,4177,77954,75786,8205,74119,257,9632,78035,512]

theorem envBound56900 : H12AffineFastState.Bounded env56900 := by
  intro p hp
  have h : env56900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56899_56900 : H12AffineEnvironment.transform 13 4177 env56899 = env56900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56899 == env56900) = true)

theorem identity56900 : scanCanonicalize (H12AffineFastState.compose env56900 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9343) := by decide +kernel

theorem selectedBound56900 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,9343,5293,13551,1024,9712,12789,1392,8629,9603,8329,8676,5522,4177,5373,3189,8205,1528,257,9632,5292,512]

theorem envBound56901 : H12AffineFastState.Bounded env56901 := by
  intro p hp
  have h : env56901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56900_56901 : H12AffineEnvironment.transform 15 9343 env56900 = env56901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9343 env56900 == env56901) = true)

theorem identity56901 : scanCanonicalize (H12AffineFastState.compose env56901 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound56901 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,2830,2689,5293,6673,1024,2830,7947,1392,3915,2941,3703,3866,5522,4177,5373,3189,3827,1528,257,2910,5292,512]

theorem envBound56902 : H12AffineFastState.Bounded env56902 := by
  intro p hp
  have h : env56902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56901_56902 : H12AffineEnvironment.transform 12 3838 env56901 = env56902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env56901 == env56902) = true)

theorem identity56902 : scanCanonicalize (H12AffineFastState.compose env56902 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound56902 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56903 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,4096,2990,4177,2830,2689,4605,6673,336,2830,6747,32,2587,2941,2855,2634,4290,4177,4525,2341,2979,168,257,2910,4604,512]

theorem envBound56903 : H12AffineFastState.Bounded env56903 := by
  intro p hp
  have h : env56903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56902_56903 : H12AffineEnvironment.transform 9 336 env56902 = env56903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env56902 == env56903) = true)

def env56904 : List Nat := [2,4,8,16,32,64,128,4,512,84,2048,4096,2730,4177,2570,2689,4345,6673,84,2570,6747,32,2587,2681,2595,2634,4290,4177,4265,2081,2727,168,5,2650,4344,512]

theorem envBound56904 : H12AffineFastState.Bounded env56904 := by
  intro p hp
  have h : env56904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56903_56904 : H12AffineEnvironment.transform 7 4 env56903 = env56904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56903 == env56904) = true)

def env56905 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,4096,2730,4129,2570,2689,4233,6673,36,2570,6699,32,2587,2569,2595,2618,4274,4129,4265,2081,2727,168,5,2602,4232,512]

theorem envBound56905 : H12AffineFastState.Bounded env56905 := by
  intro p hp
  have h : env56905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56904_56905 : H12AffineEnvironment.transform 5 48 env56904 = env56905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56904 == env56905) = true)

theorem identity56905 : scanCanonicalize (H12AffineFastState.compose env56905 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound56905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56906 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,2216,2730,2185,2570,2689,2081,697,36,2570,643,32,2587,2569,2595,2618,2074,2185,2049,2081,2727,168,5,2602,2080,512]

theorem envBound56906 : H12AffineFastState.Bounded env56906 := by
  intro p hp
  have h : env56906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56905_56906 : H12AffineEnvironment.transform 11 2216 env56905 = env56906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env56905 == env56906) = true)

def env56907 : List Nat := [2,4,8,16,32,48,128,4,512,36,648,544,34,513,130,9,681,697,36,130,643,32,147,129,171,178,658,513,649,681,47,168,5,162,680,512]

theorem envBound56907 : H12AffineFastState.Bounded env56907 := by
  intro p hp
  have h : env56907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56906_56907 : H12AffineEnvironment.transform 10 648 env56906 = env56907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env56906 == env56907) = true)

theorem identity56907 : scanCanonicalize (H12AffineFastState.compose env56907 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56907 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56908 : List Nat := [2,4,3,16,32,48,128,4,512,36,643,544,34,513,130,2,674,690,36,130,643,32,147,129,160,178,658,513,642,674,36,163,5,162,675,512]

theorem envBound56908 : H12AffineFastState.Bounded env56908 := by
  intro p hp
  have h : env56908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56907_56908 : H12AffineEnvironment.transform 2 3 env56907 = env56908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56907 == env56908) = true)

theorem identity56908 : scanCanonicalize (H12AffineFastState.compose env56908 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound56908 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56909 : List Nat := [2,4,3,16,32,48,51,4,512,36,560,544,34,513,49,2,529,513,36,49,560,32,32,50,19,1,545,513,561,529,36,16,5,17,528,512]

theorem envBound56909 : H12AffineFastState.Bounded env56909 := by
  intro p hp
  have h : env56909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56908_56909 : H12AffineEnvironment.transform 6 51 env56908 = env56909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env56908 == env56909) = true)

theorem identity56909 : scanCanonicalize (H12AffineFastState.compose env56909 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56909 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56910 : List Nat := [2,4,3,16,1,17,18,4,512,5,529,513,3,513,16,2,529,513,5,16,529,1,1,19,19,1,512,513,528,529,5,16,5,17,528,512]

theorem envBound56910 : H12AffineFastState.Bounded env56910 := by
  intro p hp
  have h : env56910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56909_56910 : H12AffineEnvironment.transform 4 1 env56909 = env56910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56909 == env56910) = true)

def env56911 : List Nat := [2,4,8,16,32,48,128,4,512,36,649,545,35,512,131,8,680,697,36,131,643,32,146,128,170,179,659,512,648,680,46,168,5,163,681,512]

theorem envBound56911 : H12AffineFastState.Bounded env56911 := by
  intro p hp
  have h : env56911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56906_56911 : H12AffineEnvironment.transform 10 649 env56906 = env56911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env56906 == env56911) = true)

theorem identity56911 : scanCanonicalize (H12AffineFastState.compose env56911 (packedSelected [1,3,4,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56911 : packedSelected [1,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env56912 : List Nat := [2,4,8,16,32,48,2,4,512,36,523,545,35,512,1,8,554,571,36,1,513,32,16,2,40,49,529,512,522,554,46,42,5,33,555,512]

theorem envBound56912 : H12AffineFastState.Bounded env56912 := by
  intro p hp
  have h : env56912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56911_56912 : H12AffineEnvironment.transform 6 2 env56911 = env56912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56911 == env56912) = true)

theorem identity56912 : scanCanonicalize (H12AffineFastState.compose env56912 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56912 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56913 : List Nat := [2,4,8,16,17,1,2,4,512,21,523,528,18,512,1,8,539,522,21,1,513,17,16,2,25,0,529,512,522,539,31,27,5,16,538,512]

theorem envBound56913 : H12AffineFastState.Bounded env56913 := by
  intro p hp
  have h : env56913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56912_56913 : H12AffineEnvironment.transform 4 17 env56912 = env56913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56912 == env56913) = true)

theorem identity56913 : scanCanonicalize (H12AffineFastState.compose env56913 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56913 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56914 : List Nat := [2,4,2,16,17,1,2,4,512,21,513,528,18,512,1,2,529,512,21,1,513,17,16,2,19,0,529,512,512,529,21,17,5,16,528,512]

theorem envBound56914 : H12AffineFastState.Bounded env56914 := by
  intro p hp
  have h : env56914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56913_56914 : H12AffineEnvironment.transform 2 2 env56913 = env56914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56913 == env56914) = true)

def env56915 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,4096,2730,4128,2570,2689,4232,6673,37,2570,6698,32,2587,2568,2595,2619,4275,4128,4265,2081,2727,168,5,2603,4233,512]

theorem envBound56915 : H12AffineFastState.Bounded env56915 := by
  intro p hp
  have h : env56915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56904_56915 : H12AffineEnvironment.transform 5 49 env56904 = env56915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56904 == env56915) = true)

theorem identity56915 : scanCanonicalize (H12AffineFastState.compose env56915 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound56915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56916 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,2048,2730,2080,2570,2689,2184,529,37,2570,554,32,2587,2568,2595,2619,2227,2080,2217,2081,2727,168,5,2603,2185,512]

theorem envBound56916 : H12AffineFastState.Bounded env56916 := by
  intro p hp
  have h : env56916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56915_56916 : H12AffineEnvironment.transform 11 2048 env56915 = env56916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env56915 == env56916) = true)

def env56917 : List Nat := [2,4,8,16,0,17,128,4,512,5,2048,2048,2698,2048,2570,2689,2184,529,5,2570,522,0,2587,2568,2563,2587,2195,2048,2185,2049,2695,136,5,2571,2185,512]

theorem envBound56917 : H12AffineFastState.Bounded env56917 := by
  intro p hp
  have h : env56917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56916_56917 : H12AffineEnvironment.transform 4 0 env56916 = env56917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56916 == env56917) = true)

theorem identity56917 : scanCanonicalize (H12AffineFastState.compose env56917 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound56917 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56918 : List Nat := [2,4,8,16,0,17,128,4,512,5,665,665,19,665,147,24,529,529,5,147,522,0,130,145,154,130,522,665,528,664,30,136,5,146,528,512]

theorem envBound56918 : H12AffineFastState.Bounded env56918 := by
  intro p hp
  have h : env56918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56917_56918 : H12AffineEnvironment.transform 10 665 env56917 = env56918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env56917 == env56918) = true)

theorem identity56918 : scanCanonicalize (H12AffineFastState.compose env56918 (packedSelected [4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56918 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env56919 : List Nat := [2,4,8,16,0,17,128,4,1,5,152,152,19,152,147,24,16,16,5,147,11,0,130,145,154,130,11,152,17,153,30,136,5,146,17,1]

theorem envBound56919 : H12AffineFastState.Bounded env56919 := by
  intro p hp
  have h : env56919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56918_56919 : H12AffineEnvironment.transform 8 1 env56918 = env56919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56918 == env56919) = true)

theorem identity56919 : scanCanonicalize (H12AffineFastState.compose env56919 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56919 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56920 : List Nat := [2,4,8,16,0,17,2,4,1,5,26,26,19,26,17,24,16,16,5,17,11,0,0,19,24,0,11,26,17,27,30,10,5,16,17,1]

theorem envBound56920 : H12AffineFastState.Bounded env56920 := by
  intro p hp
  have h : env56920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56919_56920 : H12AffineEnvironment.transform 6 2 env56919 = env56920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56919 == env56920) = true)

theorem identity56920 : scanCanonicalize (H12AffineFastState.compose env56920 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56920 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56921 : List Nat := [2,4,8,0,0,1,2,4,1,5,10,10,3,10,1,8,0,0,5,1,11,0,0,3,8,0,11,10,1,11,14,10,5,0,1,1]

theorem envBound56921 : H12AffineFastState.Bounded env56921 := by
  intro p hp
  have h : env56921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56920_56921 : H12AffineEnvironment.transform 3 0 env56920 = env56921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56920 == env56921) = true)

theorem identity56921 : scanCanonicalize (H12AffineFastState.compose env56921 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56922 : List Nat := [2,4,2,0,0,1,2,4,1,5,0,0,3,0,1,2,0,0,5,1,1,0,0,3,2,0,1,0,1,1,4,0,5,0,1,1]

theorem envBound56922 : H12AffineFastState.Bounded env56922 := by
  intro p hp
  have h : env56922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56921_56922 : H12AffineEnvironment.transform 2 2 env56921 = env56922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56921 == env56922) = true)

def env56923 : List Nat := [2,4,8,16,1,16,128,4,512,4,2048,2048,2699,2049,2570,2689,2184,529,4,2570,523,1,2587,2568,2562,2586,2194,2049,2184,2048,2694,137,5,2570,2185,512]

theorem envBound56923 : H12AffineFastState.Bounded env56923 := by
  intro p hp
  have h : env56923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56916_56923 : H12AffineEnvironment.transform 4 1 env56916 = env56923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56916 == env56923) = true)

theorem identity56923 : scanCanonicalize (H12AffineFastState.compose env56923 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound56923 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56924 : List Nat := [2,4,8,16,1,16,128,4,512,4,658,658,25,659,152,19,538,529,4,152,523,1,137,154,144,136,512,659,538,658,20,137,5,152,539,512]

theorem envBound56924 : H12AffineFastState.Bounded env56924 := by
  intro p hp
  have h : env56924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56923_56924 : H12AffineEnvironment.transform 10 658 env56923 = env56924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env56923 == env56924) = true)

theorem identity56924 : scanCanonicalize (H12AffineFastState.compose env56924 (packedSelected [3,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56924 : packedSelected [3,9] rootPS < 2^1333 := by decide +kernel

def env56925 : List Nat := [2,4,8,11,1,11,128,4,512,4,649,649,2,648,131,8,513,522,4,131,523,1,137,129,139,136,512,648,513,649,15,137,5,131,512,512]

theorem envBound56925 : H12AffineFastState.Bounded env56925 := by
  intro p hp
  have h : env56925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56924_56925 : H12AffineEnvironment.transform 3 11 env56924 = env56925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56924 == env56925) = true)

theorem identity56925 : scanCanonicalize (H12AffineFastState.compose env56925 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56925 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env56926 : List Nat := [2,4,8,11,1,11,128,4,1,4,136,136,2,137,131,8,0,11,4,131,10,1,137,129,139,136,1,137,0,136,15,137,5,131,1,1]

theorem envBound56926 : H12AffineFastState.Bounded env56926 := by
  intro p hp
  have h : env56926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56925_56926 : H12AffineEnvironment.transform 8 1 env56925 = env56926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56925 == env56926) = true)

def env56927 : List Nat := [2,4,8,16,32,64,128,5,512,85,2048,4096,2731,4177,2571,2689,4344,6673,85,2571,6747,32,2587,2680,2594,2634,4290,4177,4264,2080,2726,168,4,2651,4345,512]

theorem envBound56927 : H12AffineFastState.Bounded env56927 := by
  intro p hp
  have h : env56927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56903_56927 : H12AffineEnvironment.transform 7 5 env56903 = env56927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56903 == env56927) = true)

def env56928 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,4096,2731,4129,2571,2689,4232,6673,37,2571,6699,32,2587,2568,2594,2618,4274,4129,4264,2080,2726,168,4,2603,4233,512]

theorem envBound56928 : H12AffineFastState.Bounded env56928 := by
  intro p hp
  have h : env56928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56927_56928 : H12AffineEnvironment.transform 5 48 env56927 = env56928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56927 == env56928) = true)

theorem identity56928 : scanCanonicalize (H12AffineFastState.compose env56928 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound56928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56929 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,642,2731,675,2571,2689,522,2195,37,2571,2217,32,2587,2568,2594,2618,560,675,554,2080,2726,168,4,2603,523,512]

theorem envBound56929 : H12AffineFastState.Bounded env56929 := by
  intro p hp
  have h : env56929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56928_56929 : H12AffineEnvironment.transform 11 642 env56928 = env56929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env56928 == env56929) = true)

def env56930 : List Nat := [2,4,8,0,32,32,128,5,512,37,2048,642,2731,675,2571,2689,522,2179,37,2571,2217,32,2571,2568,2594,2602,544,675,554,2080,2726,168,4,2603,523,512]

theorem envBound56930 : H12AffineFastState.Bounded env56930 := by
  intro p hp
  have h : env56930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56929_56930 : H12AffineEnvironment.transform 3 0 env56929 = env56930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56929 == env56930) = true)

theorem identity56930 : scanCanonicalize (H12AffineFastState.compose env56930 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56930 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56931 : List Nat := [2,4,8,0,32,32,8,5,512,37,2048,522,2595,555,2571,2569,522,2059,37,2571,2081,32,2571,2568,2594,2602,544,555,554,2080,2606,32,4,2603,523,512]

theorem envBound56931 : H12AffineFastState.Bounded env56931 := by
  intro p hp
  have h : env56931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56930_56931 : H12AffineEnvironment.transform 6 8 env56930 = env56931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56930 == env56931) = true)

theorem identity56931 : scanCanonicalize (H12AffineFastState.compose env56931 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound56931 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env56932 : List Nat := [2,4,8,0,32,32,8,5,512,37,512,522,35,555,11,9,522,523,37,11,545,32,11,8,34,42,544,555,554,544,46,32,4,43,523,512]

theorem envBound56932 : H12AffineFastState.Bounded env56932 := by
  intro p hp
  have h : env56932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56931_56932 : H12AffineEnvironment.transform 10 512 env56931 = env56932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env56931 == env56932) = true)

theorem identity56932 : scanCanonicalize (H12AffineFastState.compose env56932 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56932 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56933 : List Nat := [2,4,3,0,32,32,3,5,512,37,512,513,35,544,0,2,513,512,37,0,545,32,0,3,34,33,544,544,545,544,37,32,4,32,512,512]

theorem envBound56933 : H12AffineFastState.Bounded env56933 := by
  intro p hp
  have h : env56933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56932_56933 : H12AffineEnvironment.transform 2 3 env56932 = env56933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56932 == env56933) = true)

theorem identity56933 : scanCanonicalize (H12AffineFastState.compose env56933 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56933 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56934 : List Nat := [2,4,3,0,32,32,3,5,1,37,1,0,35,33,0,2,0,1,37,0,32,32,0,3,34,33,33,33,32,33,37,32,4,32,1,1]

theorem envBound56934 : H12AffineFastState.Bounded env56934 := by
  intro p hp
  have h : env56934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56933_56934 : H12AffineEnvironment.transform 8 1 env56933 = env56934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56933 == env56934) = true)

def env56935 : List Nat := [2,4,8,1,32,33,128,5,512,37,2048,642,2731,675,2571,2689,522,2178,37,2571,2217,32,2570,2568,2594,2603,545,675,554,2080,2726,168,4,2603,523,512]

theorem envBound56935 : H12AffineFastState.Bounded env56935 := by
  intro p hp
  have h : env56935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56929_56935 : H12AffineEnvironment.transform 3 1 env56929 = env56935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56929 == env56935) = true)

theorem identity56935 : scanCanonicalize (H12AffineFastState.compose env56935 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound56935 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56936 : List Nat := [2,4,8,1,32,33,128,5,512,37,643,642,40,675,136,2,522,513,37,136,554,32,137,139,161,168,545,675,554,675,37,168,4,168,523,512]

theorem envBound56936 : H12AffineFastState.Bounded env56936 := by
  intro p hp
  have h : env56936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56935_56936 : H12AffineEnvironment.transform 10 643 env56935 = env56936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env56935 == env56936) = true)

theorem identity56936 : scanCanonicalize (H12AffineFastState.compose env56936 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56936 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56937 : List Nat := [2,4,8,1,32,33,2,5,512,37,513,512,40,545,10,2,522,513,37,10,554,32,11,9,35,42,545,545,554,545,37,42,4,42,523,512]

theorem envBound56937 : H12AffineFastState.Bounded env56937 := by
  intro p hp
  have h : env56937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56936_56937 : H12AffineEnvironment.transform 6 2 env56936 = env56937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56936 == env56937) = true)

theorem identity56937 : scanCanonicalize (H12AffineFastState.compose env56937 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56937 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env56938 : List Nat := [2,4,8,1,32,33,2,5,0,37,1,0,40,33,10,2,10,1,37,10,42,32,11,9,35,42,33,33,42,33,37,42,4,42,11,0]

theorem envBound56938 : H12AffineFastState.Bounded env56938 := by
  intro p hp
  have h : env56938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56937_56938 : H12AffineEnvironment.transform 8 0 env56937 = env56938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56937 == env56938) = true)

theorem identity56938 : scanCanonicalize (H12AffineFastState.compose env56938 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56938 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56939 : List Nat := [2,4,8,1,1,0,2,5,0,4,1,0,9,0,10,2,10,1,4,10,11,1,11,9,2,11,0,0,11,0,4,11,4,11,11,0]

theorem envBound56939 : H12AffineFastState.Bounded env56939 := by
  intro p hp
  have h : env56939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56938_56939 : H12AffineEnvironment.transform 4 1 env56938 = env56939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56938 == env56939) = true)

def env56940 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,4096,2731,4128,2571,2689,4233,6673,36,2571,6698,32,2587,2569,2594,2619,4275,4128,4264,2080,2726,168,4,2602,4232,512]

theorem envBound56940 : H12AffineFastState.Bounded env56940 := by
  intro p hp
  have h : env56940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56927_56940 : H12AffineEnvironment.transform 5 49 env56927 = env56940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56927 == env56940) = true)

theorem identity56940 : scanCanonicalize (H12AffineFastState.compose env56940 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound56940 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56941 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,554,2731,522,2571,2689,675,2107,36,2571,2048,32,2587,2569,2594,2619,665,522,642,2080,2726,168,4,2602,674,512]

theorem envBound56941 : H12AffineFastState.Bounded env56941 := by
  intro p hp
  have h : env56941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56940_56941 : H12AffineEnvironment.transform 11 554 env56940 = env56941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env56940 == env56941) = true)

def env56942 : List Nat := [2,4,8,16,16,1,128,5,512,20,2048,538,2715,522,2571,2689,659,2059,20,2571,2048,16,2587,2569,2578,2571,665,522,642,2064,2710,152,4,2586,658,512]

theorem envBound56942 : H12AffineFastState.Bounded env56942 := by
  intro p hp
  have h : env56942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56941_56942 : H12AffineEnvironment.transform 4 16 env56941 = env56942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56941 == env56942) = true)

theorem identity56942 : scanCanonicalize (H12AffineFastState.compose env56942 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56942 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56943 : List Nat := [2,4,8,16,16,1,3,5,512,20,2048,538,2584,522,2571,2562,528,2059,20,2571,2048,16,2587,2569,2578,2571,538,522,513,2064,2581,27,4,2586,529,512]

theorem envBound56943 : H12AffineFastState.Bounded env56943 := by
  intro p hp
  have h : env56943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56942_56943 : H12AffineEnvironment.transform 6 3 env56942 = env56943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56942 == env56943) = true)

theorem identity56943 : scanCanonicalize (H12AffineFastState.compose env56943 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound56943 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56944 : List Nat := [2,4,8,16,16,1,3,5,512,20,17,538,521,522,538,531,528,26,20,538,17,16,522,536,515,538,538,522,513,1,516,27,4,523,529,512]

theorem envBound56944 : H12AffineFastState.Bounded env56944 := by
  intro p hp
  have h : env56944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56943_56944 : H12AffineEnvironment.transform 10 17 env56943 = env56944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env56943 == env56944) = true)

theorem identity56944 : scanCanonicalize (H12AffineFastState.compose env56944 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56944 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56945 : List Nat := [2,4,8,10,10,1,3,5,512,14,11,512,521,522,512,521,522,0,14,512,11,10,522,514,515,512,512,522,513,1,516,1,4,523,523,512]

theorem envBound56945 : H12AffineFastState.Bounded env56945 := by
  intro p hp
  have h : env56945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56944_56945 : H12AffineEnvironment.transform 3 10 env56944 = env56945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56944 == env56945) = true)

theorem identity56945 : scanCanonicalize (H12AffineFastState.compose env56945 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound56945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56946 : List Nat := [2,4,8,10,10,1,3,5,11,14,11,11,2,1,11,2,1,0,14,11,11,10,1,9,8,11,11,1,10,1,15,1,4,0,0,11]

theorem envBound56946 : H12AffineFastState.Bounded env56946 := by
  intro p hp
  have h : env56946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56945_56946 : H12AffineEnvironment.transform 8 11 env56945 = env56946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env56945 == env56946) = true)

def env56947 : List Nat := [2,4,8,16,17,0,128,5,512,21,2048,539,2714,522,2571,2689,658,2058,21,2571,2048,17,2587,2569,2579,2570,665,522,642,2065,2711,153,4,2587,659,512]

theorem envBound56947 : H12AffineFastState.Bounded env56947 := by
  intro p hp
  have h : env56947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56941_56947 : H12AffineEnvironment.transform 4 17 env56941 = env56947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56941 == env56947) = true)

theorem identity56947 : scanCanonicalize (H12AffineFastState.compose env56947 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound56947 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56948 : List Nat := [2,4,8,16,17,0,128,5,512,21,648,539,18,522,131,9,658,642,21,131,648,17,147,129,155,130,665,522,642,665,31,153,4,147,659,512]

theorem envBound56948 : H12AffineFastState.Bounded env56948 := by
  intro p hp
  have h : env56948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56947_56948 : H12AffineEnvironment.transform 10 648 env56947 = env56948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env56947 == env56948) = true)

theorem identity56948 : scanCanonicalize (H12AffineFastState.compose env56948 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56948 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56949 : List Nat := [2,4,8,16,17,0,3,5,512,21,523,539,18,522,0,9,529,513,21,0,523,17,16,2,24,1,538,522,513,538,31,26,4,16,528,512]

theorem envBound56949 : H12AffineFastState.Bounded env56949 := by
  intro p hp
  have h : env56949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56948_56949 : H12AffineEnvironment.transform 6 3 env56948 = env56949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56948 == env56949) = true)

theorem identity56949 : scanCanonicalize (H12AffineFastState.compose env56949 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56949 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56950 : List Nat := [2,4,2,16,17,0,3,5,512,21,513,529,18,512,0,3,529,513,21,0,513,17,16,2,18,1,528,512,513,528,21,16,4,16,528,512]

theorem envBound56950 : H12AffineFastState.Bounded env56950 := by
  intro p hp
  have h : env56950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56949_56950 : H12AffineEnvironment.transform 2 2 env56949 = env56950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56949 == env56950) = true)

theorem identity56950 : scanCanonicalize (H12AffineFastState.compose env56950 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56950 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env56951 : List Nat := [2,4,2,16,17,0,3,5,1,21,0,16,18,1,0,3,16,0,21,0,0,17,16,2,18,1,17,1,0,17,21,16,4,16,17,1]

theorem envBound56951 : H12AffineFastState.Bounded env56951 := by
  intro p hp
  have h : env56951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56950_56951 : H12AffineEnvironment.transform 8 1 env56950 = env56951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56950 == env56951) = true)

def env56952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142599,28889,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound56952 : H12AffineFastState.Bounded env56952 := by
  intro p hp
  have h : env56952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56896_56952 : H12AffineEnvironment.transform 21 41089 env56896 = env56952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env56896 == env56952) = true)

theorem identity56952 : scanCanonicalize (H12AffineFastState.compose env56952 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 107883) := by decide +kernel

theorem selectedBound56952 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,107883,41089,111914,70892,28889,124202,103452,16384,77954,96346,37101,74118,257,50449,78035,21072]

theorem envBound56953 : H12AffineFastState.Bounded env56953 := by
  intro p hp
  have h : env56953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56952_56953 : H12AffineEnvironment.transform 20 107883 env56952 = env56953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 107883 env56952 == env56953) = true)

theorem identity56953 : scanCanonicalize (H12AffineFastState.compose env56953 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound56953 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,32768,65536,78034,79256,1024,32768,107883,41089,111914,70892,1408,102515,103452,13657,77954,68867,37101,74118,257,45128,78035,9993]

theorem envBound56954 : H12AffineFastState.Bounded env56954 := by
  intro p hp
  have h : env56954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56953_56954 : H12AffineEnvironment.transform 13 13657 env56953 = env56954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env56953 == env56954) = true)

theorem identity56954 : scanCanonicalize (H12AffineFastState.compose env56954 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound56954 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env56955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12512,65536,78034,79256,1024,12512,71051,4193,67018,70892,1408,73875,75004,13657,77954,68867,8205,74118,257,168,78035,9993]

theorem envBound56955 : H12AffineFastState.Bounded env56955 := by
  intro p hp
  have h : env56955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56954_56955 : H12AffineEnvironment.transform 14 12512 env56954 = env56955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env56954 == env56955) = true)

theorem identity56955 : scanCanonicalize (H12AffineFastState.compose env56955 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1418) := by decide +kernel

theorem selectedBound56955 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env56956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12512,1418,13656,12306,1024,12512,4097,4193,64,4454,1408,9497,8566,13657,13576,2185,8205,9228,257,168,13657,9993]

theorem envBound56956 : H12AffineFastState.Bounded env56956 := by
  intro p hp
  have h : env56956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56955_56956 : H12AffineEnvironment.transform 15 1418 env56955 = env56956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1418 env56955 == env56956) = true)

theorem identity56956 : scanCanonicalize (H12AffineFastState.compose env56956 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound56956 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5608,1418,4176,5402,1024,5608,4097,4193,64,4454,1408,17,1150,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound56957 : H12AffineFastState.Bounded env56957 := by
  intro p hp
  have h : env56957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56956_56957 : H12AffineEnvironment.transform 12 1288 env56956 = env56957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env56956 == env56957) = true)

theorem identity56957 : scanCanonicalize (H12AffineFastState.compose env56957 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3815) := by decide +kernel

theorem selectedBound56957 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3815,1288,3766,2831,1418,3767,3069,1024,2831,3814,3718,64,3969,1408,17,1150,3766,3815,2185,1285,260,257,168,3766,513]

theorem envBound56958 : H12AffineFastState.Bounded env56958 := by
  intro p hp
  have h : env56958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56957_56958 : H12AffineEnvironment.transform 11 3815 env56957 = env56958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3815 env56957 == env56958) = true)

theorem identity56958 : scanCanonicalize (H12AffineFastState.compose env56958 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound56958 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56959 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,2414,641,2367,2831,515,2366,3069,905,2831,2415,2319,64,2056,521,17,1015,2367,2414,2185,652,260,257,168,2367,513]

theorem envBound56959 : H12AffineFastState.Bounded env56959 := by
  intro p hp
  have h : env56959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56958_56959 : H12AffineEnvironment.transform 9 905 env56958 = env56959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env56958 == env56959) = true)

theorem identity56959 : scanCanonicalize (H12AffineFastState.compose env56959 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound56959 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56960 : List Nat := [2,4,8,16,32,64,128,256,372,253,2048,2414,501,2367,2171,375,2366,2185,253,2171,2415,2319,64,2056,381,17,131,2367,2414,2185,504,260,257,168,2367,373]

theorem envBound56960 : H12AffineFastState.Bounded env56960 := by
  intro p hp
  have h : env56960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56959_56960 : H12AffineEnvironment.transform 8 372 env56959 = env56960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env56959 == env56960) = true)

theorem identity56960 : scanCanonicalize (H12AffineFastState.compose env56960 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound56960 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56961 : List Nat := [2,4,8,16,32,64,128,256,372,253,131,493,501,444,248,375,445,10,253,248,492,396,64,139,381,17,131,444,493,10,504,260,257,168,444,373]

theorem envBound56961 : H12AffineFastState.Bounded env56961 := by
  intro p hp
  have h : env56961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56960_56961 : H12AffineEnvironment.transform 10 131 env56960 = env56961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env56960 == env56961) = true)

theorem identity56961 : scanCanonicalize (H12AffineFastState.compose env56961 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 198) := by decide +kernel

theorem selectedBound56961 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56962 : List Nat := [2,4,8,16,32,64,128,198,178,253,131,43,51,122,248,177,123,10,253,248,42,74,64,139,187,17,131,122,43,10,62,194,199,168,122,179]

theorem envBound56962 : H12AffineFastState.Bounded env56962 := by
  intro p hp
  have h : env56962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56961_56962 : H12AffineEnvironment.transform 7 198 env56961 = env56962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 198 env56961 == env56962) = true)

def env56963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4486237,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound56963 : H12AffineFastState.Bounded env56963 := by
  intro p hp
  have h : env56963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56827_56963 : H12AffineEnvironment.transform 22 6336705 env56827 = env56963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env56827 == env56963) = true)

def env56964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4273309,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound56964 : H12AffineFastState.Bounded env56964 := by
  intro p hp
  have h : env56964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56963_56964 : H12AffineEnvironment.transform 17 82112 env56963 = env56964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env56963 == env56964) = true)

def env56965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142599,28888,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound56965 : H12AffineFastState.Bounded env56965 := by
  intro p hp
  have h : env56965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56964_56965 : H12AffineEnvironment.transform 21 41088 env56964 = env56965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env56964 == env56965) = true)

theorem identity56965 : scanCanonicalize (H12AffineFastState.compose env56965 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 116002) := by decide +kernel

theorem selectedBound56965 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,116002,41088,120163,95397,28888,99683,103453,16384,77954,96347,61604,74118,257,42329,78035,21073]

theorem envBound56966 : H12AffineFastState.Bounded env56966 := by
  intro p hp
  have h : env56966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56965_56966 : H12AffineEnvironment.transform 20 116002 env56965 = env56966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116002 env56965 == env56966) = true)

theorem identity56966 : scanCanonicalize (H12AffineFastState.compose env56966 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 249) := by decide +kernel

theorem selectedBound56966 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,249,65536,78034,82112,1024,249,83419,8313,87450,95397,28888,66970,70884,16384,77954,96347,28765,74118,257,9632,78035,21073]

theorem envBound56967 : H12AffineFastState.Bounded env56967 := by
  intro p hp
  have h : env56967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56966_56967 : H12AffineEnvironment.transform 14 249 env56966 = env56967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 249 env56966 == env56967) = true)

theorem identity56967 : scanCanonicalize (H12AffineFastState.compose env56967 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound56967 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env56968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,65536,78034,69777,1024,249,71050,8313,67019,74996,8329,66970,70884,4177,77954,75786,8204,74118,257,9632,78035,512]

theorem envBound56968 : H12AffineFastState.Bounded env56968 := by
  intro p hp
  have h : env56968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56967_56968 : H12AffineEnvironment.transform 13 4177 env56967 = env56968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env56967 == env56968) = true)

theorem identity56968 : scanCanonicalize (H12AffineFastState.compose env56968 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound56968 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,374,12708,4583,1024,249,5372,8313,1213,9602,8329,1260,5522,4177,12788,10620,8204,8432,257,9632,12709,512]

theorem envBound56969 : H12AffineFastState.Bounded env56969 := by
  intro p hp
  have h : env56969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56968_56969 : H12AffineEnvironment.transform 15 374 env56968 = env56969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env56968 == env56969) = true)

theorem identity56969 : scanCanonicalize (H12AffineFastState.compose env56969 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound56969 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,249,374,8027,4583,1024,249,5372,3718,1213,2941,3702,1260,5522,4177,7947,1923,3827,3599,257,2911,8026,512]

theorem envBound56970 : H12AffineFastState.Bounded env56970 := by
  intro p hp
  have h : env56970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56969_56970 : H12AffineEnvironment.transform 12 3839 env56969 = env56970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env56969 == env56970) = true)

theorem identity56970 : scanCanonicalize (H12AffineFastState.compose env56970 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound56970 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env56971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1702,4096,89,4177,249,374,4605,4583,1024,249,5372,32,1213,1499,208,1260,5522,4177,4525,1923,85,169,257,1529,4604,512]

theorem envBound56971 : H12AffineFastState.Bounded env56971 := by
  intro p hp
  have h : env56971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56970_56971 : H12AffineEnvironment.transform 10 1702 env56970 = env56971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env56970 == env56971) = true)

def env56972 : List Nat := [2,4,8,16,32,64,128,256,512,392,814,4096,89,4177,249,374,4605,4583,392,249,4468,32,309,83,208,356,4122,4177,4525,523,85,169,257,113,4604,512]

theorem envBound56972 : H12AffineFastState.Bounded env56972 := by
  intro p hp
  have h : env56972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56971_56972 : H12AffineEnvironment.transform 9 392 env56971 = env56972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env56971 == env56972) = true)

def env56973 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,4096,41,4129,137,262,4493,4503,392,137,4356,32,309,35,160,276,4122,4129,4525,523,37,169,257,1,4492,512]

theorem envBound56973 : H12AffineFastState.Bounded env56973 := by
  intro p hp
  have h : env56973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56972_56973 : H12AffineEnvironment.transform 5 48 env56972 = env56973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56972 == env56973) = true)

theorem identity56973 : scanCanonicalize (H12AffineFastState.compose env56973 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound56973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56974 : List Nat := [2,4,8,16,32,48,128,256,512,392,814,554,41,523,137,262,935,957,392,137,814,32,309,35,160,276,560,523,903,523,37,169,257,1,934,512]

theorem envBound56974 : H12AffineFastState.Bounded env56974 := by
  intro p hp
  have h : env56974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56973_56974 : H12AffineEnvironment.transform 11 554 env56973 = env56974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env56973 == env56974) = true)

theorem identity56974 : scanCanonicalize (H12AffineFastState.compose env56974 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound56974 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56975 : List Nat := [2,4,8,16,32,48,128,166,512,46,648,554,41,523,137,160,513,539,46,137,648,32,147,35,160,178,560,523,545,523,37,169,167,1,512,512]

theorem envBound56975 : H12AffineFastState.Bounded env56975 := by
  intro p hp
  have h : env56975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56974_56975 : H12AffineEnvironment.transform 7 166 env56974 = env56975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env56974 == env56975) = true)

theorem identity56975 : scanCanonicalize (H12AffineFastState.compose env56975 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56975 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56976 : List Nat := [2,4,8,16,32,48,41,15,512,46,545,554,41,523,32,9,513,539,46,32,545,32,58,35,9,27,560,523,545,523,37,0,14,1,512,512]

theorem envBound56976 : H12AffineFastState.Bounded env56976 := by
  intro p hp
  have h : env56976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56975_56976 : H12AffineEnvironment.transform 6 41 env56975 = env56976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56975 == env56976) = true)

theorem identity56976 : scanCanonicalize (H12AffineFastState.compose env56976 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56976 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56977 : List Nat := [2,4,8,10,32,42,41,15,512,46,545,554,41,523,32,9,513,513,46,32,545,32,32,35,9,1,554,523,545,523,37,0,14,1,512,512]

theorem envBound56977 : H12AffineFastState.Bounded env56977 := by
  intro p hp
  have h : env56977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56976_56977 : H12AffineEnvironment.transform 3 10 env56976 = env56977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56976 == env56977) = true)

theorem identity56977 : scanCanonicalize (H12AffineFastState.compose env56977 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56978 : List Nat := [2,4,8,10,10,0,3,15,512,4,523,512,3,523,10,9,513,513,4,10,523,10,10,9,9,1,512,523,523,523,15,0,14,1,512,512]

theorem envBound56978 : H12AffineFastState.Bounded env56978 := by
  intro p hp
  have h : env56978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56977_56978 : H12AffineEnvironment.transform 4 10 env56977 = env56978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56977 == env56978) = true)

def env56979 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,4096,40,4128,136,263,4492,4502,392,136,4357,32,309,34,161,277,4122,4128,4525,523,36,169,257,0,4493,512]

theorem envBound56979 : H12AffineFastState.Bounded env56979 := by
  intro p hp
  have h : env56979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56972_56979 : H12AffineEnvironment.transform 5 49 env56972 = env56979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56972 == env56979) = true)

theorem identity56979 : scanCanonicalize (H12AffineFastState.compose env56979 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound56979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56980 : List Nat := [2,4,8,16,32,49,128,256,512,392,814,643,40,675,136,263,783,789,392,136,902,32,309,34,161,277,665,675,814,523,36,169,257,0,782,512]

theorem envBound56980 : H12AffineFastState.Bounded env56980 := by
  intro p hp
  have h : env56980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56979_56980 : H12AffineEnvironment.transform 11 643 env56979 = env56980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env56979 == env56980) = true)

theorem identity56980 : scanCanonicalize (H12AffineFastState.compose env56980 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound56980 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56981 : List Nat := [2,4,8,16,32,49,128,188,512,52,658,643,40,675,136,187,691,681,52,136,570,32,137,34,161,169,665,675,658,523,36,169,189,0,690,512]

theorem envBound56981 : H12AffineFastState.Bounded env56981 := by
  intro p hp
  have h : env56981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56980_56981 : H12AffineEnvironment.transform 7 188 env56980 = env56981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env56980 == env56981) = true)

theorem identity56981 : scanCanonicalize (H12AffineFastState.compose env56981 (packedSelected [0,3,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56981 : packedSelected [0,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env56982 : List Nat := [2,4,8,11,32,42,128,167,512,47,649,643,40,675,136,160,680,681,47,136,545,32,137,34,161,169,642,675,649,523,36,169,166,0,681,512]

theorem envBound56982 : H12AffineFastState.Bounded env56982 := by
  intro p hp
  have h : env56982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56981_56982 : H12AffineEnvironment.transform 3 11 env56981 = env56982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56981 == env56982) = true)

theorem identity56982 : scanCanonicalize (H12AffineFastState.compose env56982 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound56982 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env56983 : List Nat := [2,4,8,11,32,42,128,167,42,47,163,169,40,137,136,160,130,131,47,136,11,32,137,34,161,169,168,137,163,33,36,169,166,0,131,42]

end H12CloudChart1