import H12CloudChart1Data083

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound21247 : H12AffineFastState.Bounded env21247 := by
  intro p hp
  have h : env21247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21246_21247 : H12AffineEnvironment.transform 5 49 env21246 = env21247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21246 == env21247) = true)

theorem identity21247 : scanCanonicalize (H12AffineFastState.compose env21247 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21247 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21248 : List Nat := [2,4,8,16,0,17,8,256,512,1024,782,4096,268,5376,1,262,5392,522,1025,0,4113,0,17,2,268,17,783,5392,4097,523,1284,0,257,1,5376,512]

theorem envBound21248 : H12AffineFastState.Bounded env21248 := by
  intro p hp
  have h : env21248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21247_21248 : H12AffineEnvironment.transform 4 0 env21247 = env21248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21247 == env21248) = true)

theorem identity21248 : scanCanonicalize (H12AffineFastState.compose env21248 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21249 : List Nat := [2,4,8,16,0,17,8,256,512,273,782,4096,268,4113,1,262,4097,522,272,0,4113,0,17,2,268,17,783,4097,4097,523,21,0,257,1,4113,512]

theorem envBound21249 : H12AffineFastState.Bounded env21249 := by
  intro p hp
  have h : env21249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21248_21249 : H12AffineEnvironment.transform 9 273 env21248 = env21249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21248 == env21249) = true)

theorem identity21249 : scanCanonicalize (H12AffineFastState.compose env21249 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21249 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21250 : List Nat := [2,4,8,16,0,17,8,256,512,273,782,17,268,0,1,262,16,522,272,0,0,0,17,2,268,17,783,16,16,523,21,0,257,1,0,512]

theorem envBound21250 : H12AffineFastState.Bounded env21250 := by
  intro p hp
  have h : env21250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21249_21250 : H12AffineEnvironment.transform 11 17 env21249 = env21250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21249 == env21250) = true)

theorem identity21250 : scanCanonicalize (H12AffineFastState.compose env21250 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound21250 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21251 : List Nat := [2,4,8,16,0,17,8,256,10,273,260,17,268,0,1,262,16,0,272,0,0,0,17,2,268,17,261,16,16,1,21,0,257,1,0,10]

theorem envBound21251 : H12AffineFastState.Bounded env21251 := by
  intro p hp
  have h : env21251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21250_21251 : H12AffineEnvironment.transform 8 10 env21250 = env21251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env21250 == env21251) = true)

def env21252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272392,16,21763,8192,64,121943,115014,17665,303452,119043,329730,257,98678,90202,63068]

theorem envBound21252 : H12AffineFastState.Bounded env21252 := by
  intro p hp
  have h : env21252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21239_21252 : H12AffineEnvironment.transform 20 4161 env21239 = env21252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21239 == env21252) = true)

theorem identity21252 : scanCanonicalize (H12AffineFastState.compose env21252 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,262144,1025,32769,4161,272392,16,2,8192,64,100694,103495,4096,303452,99330,329730,257,98678,79195,41821]

theorem envBound21253 : H12AffineFastState.Bounded env21253 := by
  intro p hp
  have h : env21253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21252_21253 : H12AffineEnvironment.transform 13 5377 env21252 = env21253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21252 == env21253) = true)

theorem identity21253 : scanCanonicalize (H12AffineFastState.compose env21253 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound21253 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env21254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13388,35109,1025,32769,4161,41261,16,2,8192,64,100694,103495,4096,10361,99330,98599,257,98678,79195,41821]

theorem envBound21254 : H12AffineFastState.Bounded env21254 := by
  intro p hp
  have h : env21254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21253_21254 : H12AffineEnvironment.transform 17 35109 env21253 = env21254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env21253 == env21254) = true)

theorem identity21254 : scanCanonicalize (H12AffineFastState.compose env21254 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound21254 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env21255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41343,13388,35109,1025,32769,4161,41261,16,2,8192,64,10281,13624,4096,10361,9597,8280,257,8201,37924,41821]

theorem envBound21255 : H12AffineFastState.Bounded env21255 := by
  intro p hp
  have h : env21255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21254_21255 : H12AffineEnvironment.transform 15 41343 env21254 = env21255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env21254 == env21255) = true)

theorem identity21255 : scanCanonicalize (H12AffineFastState.compose env21255 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21255 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env21256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8574,13388,2340,1025,0,4161,8492,16,2,8192,64,10281,13624,4096,10361,9597,8280,257,8201,5157,9052]

theorem envBound21256 : H12AffineFastState.Bounded env21256 := by
  intro p hp
  have h : env21256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21255_21256 : H12AffineEnvironment.transform 14 1 env21255 = env21256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21255 == env21256) = true)

theorem identity21256 : scanCanonicalize (H12AffineFastState.compose env21256 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21256 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env21257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,1,262,5172,2340,1025,0,4161,340,16,2,120,64,2129,5440,4096,2049,1285,32,257,113,5157,804]

theorem envBound21257 : H12AffineFastState.Bounded env21257 := by
  intro p hp
  have h : env21257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21256_21257 : H12AffineEnvironment.transform 12 120 env21256 = env21257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21256 == env21257) = true)

theorem identity21257 : scanCanonicalize (H12AffineFastState.compose env21257 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21257 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env21258 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,1,114,5172,2128,1025,0,4161,32,16,2,120,64,2129,5172,4096,2049,1137,32,117,113,5157,592]

theorem envBound21258 : H12AffineFastState.Bounded env21258 := by
  intro p hp
  have h : env21258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21257_21258 : H12AffineEnvironment.transform 7 116 env21257 = env21258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21257 == env21258) = true)

theorem identity21258 : scanCanonicalize (H12AffineFastState.compose env21258 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21258 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21259 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,34,5172,2048,1025,0,4113,32,16,2,40,16,2049,5172,4096,2049,1057,32,37,33,5157,512]

theorem envBound21259 : H12AffineFastState.Bounded env21259 := by
  intro p hp
  have h : env21259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21258_21259 : H12AffineEnvironment.transform 5 16 env21258 = env21259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21258 == env21259) = true)

theorem identity21259 : scanCanonicalize (H12AffineFastState.compose env21259 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21260 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5124,1,3,5141,2048,1025,0,4113,1,16,2,9,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound21260 : H12AffineFastState.Bounded env21260 := by
  intro p hp
  have h : env21260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21259_21260 : H12AffineEnvironment.transform 4 1 env21259 = env21260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21259 == env21260) = true)

def env21261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,121943,115015,17665,2404636,119043,329730,257,2199862,2191387,63069]

theorem envBound21261 : H12AffineFastState.Bounded env21261 := by
  intro p hp
  have h : env21261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21238_21261 : H12AffineEnvironment.transform 6 9 env21238 = env21261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21238 == env21261) = true)

def env21262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272393,17,21762,8193,64,121943,115015,17665,303452,119043,329730,257,98678,90203,63069]

theorem envBound21262 : H12AffineFastState.Bounded env21262 := by
  intro p hp
  have h : env21262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21261_21262 : H12AffineEnvironment.transform 20 4160 env21261 = env21262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21261 == env21262) = true)

theorem identity21262 : scanCanonicalize (H12AffineFastState.compose env21262 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound21262 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56436,1025,32769,4160,62589,17,21762,8193,64,121943,115015,17665,32040,119043,119926,257,98678,90203,63069]

theorem envBound21263 : H12AffineFastState.Bounded env21263 := by
  intro p hp
  have h : env21263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21262_21263 : H12AffineEnvironment.transform 17 56436 env21262 = env21263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env21262 == env21263) = true)

theorem identity21263 : scanCanonicalize (H12AffineFastState.compose env21263 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21263 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env21264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13389,35189,1025,32769,4160,41340,17,3,8193,64,100694,103494,4096,10281,99330,98679,257,98678,79194,41820]

theorem envBound21264 : H12AffineFastState.Bounded env21264 := by
  intro p hp
  have h : env21264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21263_21264 : H12AffineEnvironment.transform 13 5377 env21263 = env21264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21263 == env21264) = true)

theorem identity21264 : scanCanonicalize (H12AffineFastState.compose env21264 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound21264 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40970,13389,35189,1025,32769,4160,41340,17,3,8193,64,10588,13388,4096,10281,9224,8573,257,8572,38224,41820]

theorem envBound21265 : H12AffineFastState.Bounded env21265 := by
  intro p hp
  have h : env21265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21264_21265 : H12AffineEnvironment.transform 15 40970 env21264 = env21265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env21264 == env21265) = true)

theorem identity21265 : scanCanonicalize (H12AffineFastState.compose env21265 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21265 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env21266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8202,13389,2421,1025,1,4160,8572,17,3,8193,64,10588,13388,4096,10281,9224,8573,257,8572,5456,9052]

theorem envBound21266 : H12AffineFastState.Bounded env21266 := by
  intro p hp
  have h : env21266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21265_21266 : H12AffineEnvironment.transform 14 0 env21265 = env21266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21265 == env21266) = true)

theorem identity21266 : scanCanonicalize (H12AffineFastState.compose env21266 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 895) := by decide +kernel

theorem selectedBound21266 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env21267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,895,4096,8192,5377,0,8202,13389,522,1025,1,4160,8572,17,3,8193,64,8739,13388,4096,9046,9224,8573,257,8572,5456,9052]

theorem envBound21267 : H12AffineFastState.Bounded env21267 := by
  intro p hp
  have h : env21267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21266_21267 : H12AffineEnvironment.transform 10 895 env21266 = env21267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 895 env21266 == env21267) = true)

theorem identity21267 : scanCanonicalize (H12AffineFastState.compose env21267 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound21267 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env21268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,895,4096,1052,5377,0,1046,4177,522,1025,1,4160,1376,17,3,1053,64,1599,4176,4096,1866,20,1377,257,1376,5456,1856]

theorem envBound21268 : H12AffineFastState.Bounded env21268 := by
  intro p hp
  have h : env21268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21267_21268 : H12AffineEnvironment.transform 12 1052 env21267 = env21268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env21267 == env21268) = true)

theorem identity21268 : scanCanonicalize (H12AffineFastState.compose env21268 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21268 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21269 : List Nat := [2,4,8,16,32,64,9,256,512,101,895,4096,121,4452,0,115,4177,522,100,1,4160,261,17,3,120,64,602,4176,4096,815,20,260,257,261,4405,805]

theorem envBound21269 : H12AffineFastState.Bounded env21269 := by
  intro p hp
  have h : env21269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21268_21269 : H12AffineEnvironment.transform 9 101 env21268 = env21269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21268 == env21269) = true)

theorem identity21269 : scanCanonicalize (H12AffineFastState.compose env21269 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21269 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21270 : List Nat := [2,4,8,16,32,17,9,256,512,52,814,4096,40,4405,0,34,4096,522,53,1,4113,261,17,3,41,17,523,4097,4096,815,20,260,257,261,4405,805]

theorem envBound21270 : H12AffineFastState.Bounded env21270 := by
  intro p hp
  have h : env21270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21269_21270 : H12AffineEnvironment.transform 5 17 env21269 = env21270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21269 == env21270) = true)

theorem identity21270 : scanCanonicalize (H12AffineFastState.compose env21270 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound21270 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21271 : List Nat := [2,4,8,16,32,17,9,256,512,52,814,799,40,554,0,34,799,522,53,1,782,261,17,3,41,17,523,798,799,815,20,260,257,261,554,805]

theorem envBound21271 : H12AffineFastState.Bounded env21271 := by
  intro p hp
  have h : env21271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21270_21271 : H12AffineEnvironment.transform 11 799 env21270 = env21271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env21270 == env21271) = true)

theorem identity21271 : scanCanonicalize (H12AffineFastState.compose env21271 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21271 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env21272 : List Nat := [2,4,8,16,32,17,9,36,512,52,522,571,40,554,0,34,571,522,53,1,554,33,17,3,41,17,523,570,571,523,20,32,37,33,554,513]

theorem envBound21272 : H12AffineFastState.Bounded env21272 := by
  intro p hp
  have h : env21272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21271_21272 : H12AffineEnvironment.transform 7 36 env21271 = env21272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21271 == env21272) = true)

theorem identity21272 : scanCanonicalize (H12AffineFastState.compose env21272 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound21272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21273 : List Nat := [2,4,8,16,32,17,9,36,14,52,4,53,40,36,0,34,53,4,53,1,36,33,17,3,41,17,5,52,53,5,20,32,37,33,36,15]

theorem envBound21273 : H12AffineFastState.Bounded env21273 := by
  intro p hp
  have h : env21273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21272_21273 : H12AffineEnvironment.transform 8 14 env21272 = env21273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env21272 == env21273) = true)

theorem identity21273 : scanCanonicalize (H12AffineFastState.compose env21273 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound21273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21274 : List Nat := [2,3,8,16,32,17,9,35,9,51,3,50,40,35,0,34,50,3,50,1,35,33,17,3,41,17,2,51,50,2,19,32,34,33,35,8]

theorem envBound21274 : H12AffineFastState.Bounded env21274 := by
  intro p hp
  have h : env21274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21273_21274 : H12AffineEnvironment.transform 1 3 env21273 = env21274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env21273 == env21274) = true)

def env21275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272393,16,21763,8193,64,121943,115015,17665,303453,119043,329730,257,98679,90202,63069]

theorem envBound21275 : H12AffineFastState.Bounded env21275 := by
  intro p hp
  have h : env21275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21261_21275 : H12AffineEnvironment.transform 20 4161 env21261 = env21275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21261 == env21275) = true)

theorem identity21275 : scanCanonicalize (H12AffineFastState.compose env21275 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21275 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,24908,262144,1025,29789,4161,272393,16,21763,8193,64,75787,79131,17665,283905,75103,329730,257,95531,90202,513]

theorem envBound21276 : H12AffineFastState.Bounded env21276 := by
  intro p hp
  have h : env21276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21275_21276 : H12AffineEnvironment.transform 14 29788 env21275 = env21276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21275 == env21276) = true)

theorem identity21276 : scanCanonicalize (H12AffineFastState.compose env21276 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21276 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24908,262144,1025,29789,4161,272393,16,21763,8193,64,10589,13389,17665,283905,9225,264532,257,29821,24844,513]

theorem envBound21277 : H12AffineFastState.Bounded env21277 := by
  intro p hp
  have h : env21277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21276_21277 : H12AffineEnvironment.transform 15 342 env21276 = env21277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21276 == env21277) = true)

theorem identity21277 : scanCanonicalize (H12AffineFastState.compose env21277 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound21277 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24908,23668,1025,29789,4161,29821,16,21763,8193,64,10589,13389,17665,2421,9225,21792,257,29821,24844,513]

theorem envBound21278 : H12AffineFastState.Bounded env21278 := by
  intro p hp
  have h : env21278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21277_21278 : H12AffineEnvironment.transform 17 23668 env21277 = env21278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env21277 == env21278) = true)

theorem identity21278 : scanCanonicalize (H12AffineFastState.compose env21278 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21278 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,342,13388,2420,1025,8541,4161,8573,16,3,8193,64,10589,13389,4097,2421,9225,32,257,8573,13324,513]

theorem envBound21279 : H12AffineFastState.Bounded env21279 := by
  intro p hp
  have h : env21279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21278_21279 : H12AffineEnvironment.transform 13 5376 env21278 = env21279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21278 == env21279) = true)

theorem identity21279 : scanCanonicalize (H12AffineFastState.compose env21279 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21279 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1025,0,4161,32,16,3,348,64,2048,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound21280 : H12AffineFastState.Bounded env21280 := by
  intro p hp
  have h : env21280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21279_21280 : H12AffineEnvironment.transform 12 349 env21279 = env21280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21279 == env21280) = true)

theorem identity21280 : scanCanonicalize (H12AffineFastState.compose env21280 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound21280 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,869,349,1637,1,342,1652,2420,1025,0,804,32,16,3,348,64,2048,1653,868,2421,1364,32,257,32,1588,513]

theorem envBound21281 : H12AffineFastState.Bounded env21281 := by
  intro p hp
  have h : env21281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21280_21281 : H12AffineEnvironment.transform 11 869 env21280 = env21281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env21280 == env21281) = true)

theorem identity21281 : scanCanonicalize (H12AffineFastState.compose env21281 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21281 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21282 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,821,269,1589,1,262,1572,2340,1025,0,804,32,16,3,268,16,2048,1573,820,2341,1284,32,257,32,1588,513]

theorem envBound21282 : H12AffineFastState.Bounded env21282 := by
  intro p hp
  have h : env21282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21281_21282 : H12AffineEnvironment.transform 5 16 env21281 = env21282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21281 == env21282) = true)

theorem identity21282 : scanCanonicalize (H12AffineFastState.compose env21282 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21283 : List Nat := [2,4,8,16,32,16,9,256,512,4,2048,821,269,561,1,262,544,2340,5,0,804,32,16,3,268,16,2048,545,820,2341,256,32,257,32,560,513]

theorem envBound21283 : H12AffineFastState.Bounded env21283 := by
  intro p hp
  have h : env21283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21282_21283 : H12AffineEnvironment.transform 9 4 env21282 = env21283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21282 == env21283) = true)

theorem identity21283 : scanCanonicalize (H12AffineFastState.compose env21283 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound21283 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21284 : List Nat := [2,4,8,16,32,16,9,256,512,4,277,821,269,561,1,262,544,49,5,0,804,32,16,3,268,16,277,545,820,48,256,32,257,32,560,513]

theorem envBound21284 : H12AffineFastState.Bounded env21284 := by
  intro p hp
  have h : env21284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21283_21284 : H12AffineEnvironment.transform 10 277 env21283 = env21284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env21283 == env21284) = true)

theorem identity21284 : scanCanonicalize (H12AffineFastState.compose env21284 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21284 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21285 : List Nat := [2,4,8,16,32,16,9,256,33,4,277,276,269,16,1,262,1,49,5,0,261,32,16,3,268,16,277,0,277,48,256,32,257,32,17,32]

theorem envBound21285 : H12AffineFastState.Bounded env21285 := by
  intro p hp
  have h : env21285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21284_21285 : H12AffineEnvironment.transform 8 33 env21284 = env21285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21284 == env21285) = true)

theorem identity21285 : scanCanonicalize (H12AffineFastState.compose env21285 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21285 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21286 : List Nat := [2,4,8,16,16,16,9,256,17,4,277,276,269,16,1,262,1,1,5,0,261,16,16,3,268,16,277,0,277,0,256,16,257,16,17,16]

theorem envBound21286 : H12AffineFastState.Bounded env21286 := by
  intro p hp
  have h : env21286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21285_21286 : H12AffineEnvironment.transform 4 16 env21285 = env21286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21285 == env21286) = true)

theorem identity21286 : scanCanonicalize (H12AffineFastState.compose env21286 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21286 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21287 : List Nat := [2,4,8,1,1,1,9,256,0,4,260,261,269,1,1,262,1,1,5,0,261,1,1,3,268,1,260,0,260,0,256,1,257,1,0,1]

theorem envBound21287 : H12AffineFastState.Bounded env21287 := by
  intro p hp
  have h : env21287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21286_21287 : H12AffineEnvironment.transform 3 1 env21286 = env21287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21286 == env21287) = true)

theorem identity21287 : scanCanonicalize (H12AffineFastState.compose env21287 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21287 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env21288 : List Nat := [2,4,8,1,1,1,9,5,0,4,1,0,8,1,1,3,1,1,5,0,0,1,1,3,9,1,1,0,1,0,5,1,4,1,0,1]

theorem envBound21288 : H12AffineFastState.Bounded env21288 := by
  intro p hp
  have h : env21288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21287_21288 : H12AffineEnvironment.transform 7 5 env21287 = env21288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21287 == env21288) = true)

def env21289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,121942,115150,17665,2404757,119043,329731,257,2199999,2191387,63188]

theorem envBound21289 : H12AffineFastState.Bounded env21289 := by
  intro p hp
  have h : env21289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21237_21289 : H12AffineEnvironment.transform 21 272513 env21237 = env21289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21237 == env21289) = true)

theorem identity21289 : scanCanonicalize (H12AffineFastState.compose env21289 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound21289 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,272513,17,21762,8328,64,121942,115150,17665,303573,119043,329731,257,98815,90203,63188]

theorem envBound21290 : H12AffineFastState.Bounded env21290 := by
  intro p hp
  have h : env21290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21289_21290 : H12AffineEnvironment.transform 20 4160 env21289 = env21290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21289 == env21290) = true)

def env21291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272393,17,21762,8192,64,121942,115014,17665,303453,119043,329731,257,98679,90203,63068]

theorem envBound21291 : H12AffineFastState.Bounded env21291 := by
  intro p hp
  have h : env21291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21290_21291 : H12AffineEnvironment.transform 6 8 env21290 = env21291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21290 == env21291) = true)

theorem identity21291 : scanCanonicalize (H12AffineFastState.compose env21291 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound21291 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4160,21793,17,21762,8192,64,121942,115014,17665,56437,119043,95531,257,98679,90203,63068]

theorem envBound21292 : H12AffineFastState.Bounded env21292 := by
  intro p hp
  have h : env21292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21291_21292 : H12AffineEnvironment.transform 17 32040 env21291 = env21292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env21291 == env21292) = true)

theorem identity21292 : scanCanonicalize (H12AffineFastState.compose env21292 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21292 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,24909,32040,1025,32769,4160,21793,17,21762,8192,64,56576,49168,17665,56437,53333,29821,257,32801,24845,63068]

theorem envBound21293 : H12AffineFastState.Bounded env21293 := by
  intro p hp
  have h : env21293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21292_21293 : H12AffineEnvironment.transform 15 342 env21292 = env21293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21292 == env21293) = true)

theorem identity21293 : scanCanonicalize (H12AffineFastState.compose env21293 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21293 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,24909,32040,1025,0,4160,21793,17,21762,8192,64,23809,16401,17665,23668,20564,29821,257,32,24845,30301]

theorem envBound21294 : H12AffineFastState.Bounded env21294 := by
  intro p hp
  have h : env21294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21293_21294 : H12AffineEnvironment.transform 14 1 env21293 = env21294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21293 == env21294) = true)

def env21295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272392,17,21762,8193,64,121942,115015,17665,303452,119043,329731,257,98678,90203,63069]

theorem envBound21295 : H12AffineFastState.Bounded env21295 := by
  intro p hp
  have h : env21295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21290_21295 : H12AffineEnvironment.transform 6 9 env21290 = env21295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21290 == env21295) = true)

theorem identity21295 : scanCanonicalize (H12AffineFastState.compose env21295 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound21295 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56436,1025,32769,4160,62588,17,21762,8193,64,121942,115015,17665,32040,119043,119927,257,98678,90203,63069]

theorem envBound21296 : H12AffineFastState.Bounded env21296 := by
  intro p hp
  have h : env21296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21295_21296 : H12AffineEnvironment.transform 17 56436 env21295 = env21296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env21295 == env21296) = true)

def env21297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound21297 : H12AffineFastState.Bounded env21297 := by
  intro p hp
  have h : env21297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21011_21297 : H12AffineEnvironment.transform 26 30393345 env21011 = env21297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env21011 == env21297) = true)

def env21298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound21298 : H12AffineFastState.Bounded env21298 := by
  intro p hp
  have h : env21298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21297_21298 : H12AffineEnvironment.transform 18 1024 env21297 = env21298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21297 == env21298) = true)

theorem identity21298 : scanCanonicalize (H12AffineFastState.compose env21298 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8430023) := by decide +kernel

theorem selectedBound21298 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8430023,8328,64,4678086,10560842,10507600,8830977,75223,14795782,256,2188651,2196687,513]

theorem envBound21299 : H12AffineFastState.Bounded env21299 := by
  intro p hp
  have h : env21299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21298_21299 : H12AffineEnvironment.transform 23 8430023 env21298 = env21299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8430023 env21298 == env21299) = true)

def env21300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4677966,10560842,10507600,8830977,75103,14795782,256,2188651,2196551,513]

theorem envBound21300 : H12AffineFastState.Bounded env21300 := by
  intro p hp
  have h : env21300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21299_21300 : H12AffineEnvironment.transform 6 8 env21299 = env21300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21299 == env21300) = true)

theorem identity21300 : scanCanonicalize (H12AffineFastState.compose env21300 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21300 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4456788,10560842,10507600,8757275,75103,14795782,256,2188651,2196551,513]

theorem envBound21301 : H12AffineFastState.Bounded env21301 := by
  intro p hp
  have h : env21301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21300_21301 : H12AffineEnvironment.transform 16 90138 env21300 = env21301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21300 == env21301) = true)

def env21302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,16,41311,8192,64,4456788,2172250,2118976,368651,75103,6407190,256,2188651,2196551,513]

theorem envBound21302 : H12AffineFastState.Bounded env21302 := by
  intro p hp
  have h : env21302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21301_21302 : H12AffineEnvironment.transform 22 16 env21301 = env21302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env21301 == env21302) = true)

theorem identity21302 : scanCanonicalize (H12AffineFastState.compose env21302 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46092) := by decide +kernel

theorem selectedBound21302 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,46092,4194304,16,41311,8192,64,4456788,102742,57676,368651,75103,4288538,256,119143,77899,513]

theorem envBound21303 : H12AffineFastState.Bounded env21303 := by
  intro p hp
  have h : env21303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21302_21303 : H12AffineEnvironment.transform 20 46092 env21302 = env21303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46092 env21302 == env21303) = true)

theorem identity21303 : scanCanonicalize (H12AffineFastState.compose env21303 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21303 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,77835,16401,328022,75103,4288538,256,94266,77899,513]

theorem envBound21304 : H12AffineFastState.Bounded env21304 := by
  intro p hp
  have h : env21304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21303_21304 : H12AffineEnvironment.transform 14 8541 env21303 = env21304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21303 == env21304) = true)

def env21305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77834,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,77835,4097,328022,75103,4268042,256,73770,77899,513]

theorem envBound21305 : H12AffineFastState.Bounded env21305 := by
  intro p hp
  have h : env21305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21304_21305 : H12AffineEnvironment.transform 13 4112 env21304 = env21305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env21304 == env21305) = true)

theorem identity21305 : scanCanonicalize (H12AffineFastState.compose env21305 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,8202,4096,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,4097,4097,270684,1365,4194304,256,32,4161,513]

theorem envBound21306 : H12AffineFastState.Bounded env21306 := by
  intro p hp
  have h : env21306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21305_21306 : H12AffineEnvironment.transform 15 8202 env21305 = env21306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21305 == env21306) = true)

theorem identity21306 : scanCanonicalize (H12AffineFastState.compose env21306 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound21306 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,8202,4096,262144,1024,8540,5457,112,16,2,8192,64,262436,4097,4097,270684,1365,112,256,32,4161,513]

theorem envBound21307 : H12AffineFastState.Bounded env21307 := by
  intro p hp
  have h : env21307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21306_21307 : H12AffineEnvironment.transform 21 112 env21306 = env21307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env21306 == env21307) = true)

theorem identity21307 : scanCanonicalize (H12AffineFastState.compose env21307 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21307 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env21308 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8461,8202,4096,262144,1024,8460,5377,32,16,2,8192,16,262436,4097,4097,270604,1285,32,256,32,4113,513]

theorem envBound21308 : H12AffineFastState.Bounded env21308 := by
  intro p hp
  have h : env21308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21307_21308 : H12AffineEnvironment.transform 5 16 env21307 = env21308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21307 == env21308) = true)

theorem identity21308 : scanCanonicalize (H12AffineFastState.compose env21308 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound21308 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21309 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,8461,8202,4096,11576,1024,8460,5377,32,16,2,8192,16,11292,4097,4097,3124,1285,32,256,32,4113,513]

theorem envBound21309 : H12AffineFastState.Bounded env21309 := by
  intro p hp
  have h : env21309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21308_21309 : H12AffineEnvironment.transform 17 11576 env21308 = env21309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env21308 == env21309) = true)

theorem identity21309 : scanCanonicalize (H12AffineFastState.compose env21309 (packedSelected [0,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound21309 : packedSelected [0,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env21310 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,4112,8461,8202,4096,8461,1024,8460,5377,32,16,2,8192,16,8233,4097,4097,1,1285,32,256,32,4113,513]

theorem envBound21310 : H12AffineFastState.Bounded env21310 := by
  intro p hp
  have h : env21310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21309_21310 : H12AffineEnvironment.transform 10 1077 env21309 = env21310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env21309 == env21310) = true)

theorem identity21310 : scanCanonicalize (H12AffineFastState.compose env21310 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21310 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env21311 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,4096,8192,4112,8461,8202,4096,8461,52,8460,4405,32,16,2,8192,16,8233,4097,4097,1,305,32,256,32,4113,513]

theorem envBound21311 : H12AffineFastState.Bounded env21311 := by
  intro p hp
  have h : env21311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21310_21311 : H12AffineEnvironment.transform 9 52 env21310 = env21311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21310 == env21311) = true)

theorem identity21311 : scanCanonicalize (H12AffineFastState.compose env21311 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound21311 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env21312 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,4096,25,4112,276,19,4096,276,52,277,4405,32,16,2,25,16,48,4097,4097,1,305,32,256,32,4113,513]

theorem envBound21312 : H12AffineFastState.Bounded env21312 := by
  intro p hp
  have h : env21312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21311_21312 : H12AffineEnvironment.transform 12 25 env21311 = env21312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env21311 == env21312) = true)

theorem identity21312 : scanCanonicalize (H12AffineFastState.compose env21312 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound21312 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env21313 : List Nat := [2,4,8,16,32,16,8,52,512,52,1,4096,25,4112,32,19,4096,32,52,33,4097,32,16,2,25,16,48,4097,4097,1,5,32,52,32,4113,513]

theorem envBound21313 : H12AffineFastState.Bounded env21313 := by
  intro p hp
  have h : env21313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21312_21313 : H12AffineEnvironment.transform 7 52 env21312 = env21313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env21312 == env21313) = true)

theorem identity21313 : scanCanonicalize (H12AffineFastState.compose env21313 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21314 : List Nat := [2,4,8,1,32,1,8,37,512,37,1,4096,8,4097,32,2,4096,32,37,33,4097,32,1,2,8,1,33,4097,4097,1,5,32,37,32,4096,513]

theorem envBound21314 : H12AffineFastState.Bounded env21314 := by
  intro p hp
  have h : env21314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21313_21314 : H12AffineEnvironment.transform 3 1 env21313 = env21314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21313 == env21314) = true)

theorem identity21314 : scanCanonicalize (H12AffineFastState.compose env21314 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound21314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21315 : List Nat := [2,4,8,1,32,1,8,37,512,37,1,545,8,544,32,2,545,32,37,33,544,32,1,2,8,1,33,544,544,1,5,32,37,32,545,513]

theorem envBound21315 : H12AffineFastState.Bounded env21315 := by
  intro p hp
  have h : env21315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21314_21315 : H12AffineEnvironment.transform 11 545 env21314 = env21315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env21314 == env21315) = true)

theorem identity21315 : scanCanonicalize (H12AffineFastState.compose env21315 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21315 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21316 : List Nat := [2,4,8,1,32,1,8,37,33,37,1,0,8,1,32,2,0,32,37,33,1,32,1,2,8,1,33,1,1,1,5,32,37,32,0,32]

theorem envBound21316 : H12AffineFastState.Bounded env21316 := by
  intro p hp
  have h : env21316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21315_21316 : H12AffineEnvironment.transform 8 33 env21315 = env21316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21315 == env21316) = true)

def env21317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,77835,4096,328022,75103,4268043,256,73771,77899,513]

theorem envBound21317 : H12AffineFastState.Bounded env21317 := by
  intro p hp
  have h : env21317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21304_21317 : H12AffineEnvironment.transform 13 4113 env21304 = env21317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env21304 == env21317) = true)

theorem identity21317 : scanCanonicalize (H12AffineFastState.compose env21317 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound21317 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env21318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,262144,1024,8540,5457,33,16,2,8192,64,262517,77835,4096,328022,75103,73770,256,73771,77899,513]

theorem envBound21318 : H12AffineFastState.Bounded env21318 := by
  intro p hp
  have h : env21318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21317_21318 : H12AffineEnvironment.transform 21 33 env21317 = env21318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env21317 == env21318) = true)

theorem identity21318 : scanCanonicalize (H12AffineFastState.compose env21318 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound21318 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env21319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,10281,1024,8540,5457,33,16,2,8192,64,10588,77835,4096,76159,75103,73770,256,73771,77899,513]

theorem envBound21319 : H12AffineFastState.Bounded env21319 := by
  intro p hp
  have h : env21319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21318_21319 : H12AffineEnvironment.transform 17 10281 env21318 = env21319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21318 == env21319) = true)

theorem identity21319 : scanCanonicalize (H12AffineFastState.compose env21319 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15407) := by decide +kernel

theorem selectedBound21319 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,15407,3108,10281,1024,8540,5457,33,16,2,8192,64,10588,3108,4096,5456,6512,7173,256,7172,3172,513]

theorem envBound21320 : H12AffineFastState.Bounded env21320 := by
  intro p hp
  have h : env21320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21319_21320 : H12AffineEnvironment.transform 15 15407 env21319 = env21320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15407 env21319 == env21320) = true)

theorem identity21320 : scanCanonicalize (H12AffineFastState.compose env21320 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21320 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21321 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4113,8460,15407,3108,10281,1024,8461,5376,33,16,2,8192,17,10509,3108,4096,5377,6433,7173,256,7172,3125,513]

theorem envBound21321 : H12AffineFastState.Bounded env21321 := by
  intro p hp
  have h : env21321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21320_21321 : H12AffineEnvironment.transform 5 17 env21320 = env21321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21320 == env21321) = true)

theorem identity21321 : scanCanonicalize (H12AffineFastState.compose env21321 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound21321 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21322 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,3124,8460,8202,3108,10281,1024,8461,2341,33,16,2,8192,17,10509,3108,3109,2340,1284,32,256,33,3125,513]

theorem envBound21322 : H12AffineFastState.Bounded env21322 := by
  intro p hp
  have h : env21322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21321_21322 : H12AffineEnvironment.transform 11 3109 env21321 = env21322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env21321 == env21322) = true)

def env21323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456788,2172251,2118977,368650,75103,6407191,256,2188651,2196551,513]

theorem envBound21323 : H12AffineFastState.Bounded env21323 := by
  intro p hp
  have h : env21323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21301_21323 : H12AffineEnvironment.transform 22 17 env21301 = env21323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env21301 == env21323) = true)

theorem identity21323 : scanCanonicalize (H12AffineFastState.compose env21323 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound21323 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,262144,1024,29004,2097152,4194304,17,20499,8192,64,4456788,2172251,2118977,348487,75103,6370650,256,2188651,2192650,513]

theorem envBound21324 : H12AffineFastState.Bounded env21324 := by
  intro p hp
  have h : env21324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21323_21324 : H12AffineEnvironment.transform 14 29005 env21323 = env21324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env21323 == env21324) = true)

theorem identity21324 : scanCanonicalize (H12AffineFastState.compose env21324 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound21324 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,2097152,4194304,17,20499,8192,64,4225389,2172251,2118977,76158,75103,6370650,256,2188651,2192650,513]

theorem envBound21325 : H12AffineFastState.Bounded env21325 := by
  intro p hp
  have h : env21325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21324_21325 : H12AffineEnvironment.transform 17 30777 env21324 = env21325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env21324 == env21325) = true)

def env21326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5456,4194304,17,20499,8192,64,4225389,77835,16401,76158,75103,4268042,256,94267,90202,513]

theorem envBound21326 : H12AffineFastState.Bounded env21326 := by
  intro p hp
  have h : env21326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21325_21326 : H12AffineEnvironment.transform 20 5456 env21325 = env21326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env21325 == env21326) = true)

theorem identity21326 : scanCanonicalize (H12AffineFastState.compose env21326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound21326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5456,73771,17,20499,8192,64,88390,77835,16401,76158,75103,33,256,94267,90202,513]

theorem envBound21327 : H12AffineFastState.Bounded env21327 := by
  intro p hp
  have h : env21327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21326_21327 : H12AffineEnvironment.transform 21 73771 env21326 = env21327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env21326 == env21327) = true)

theorem identity21327 : scanCanonicalize (H12AffineFastState.compose env21327 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound21327 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77834,10281,1024,8540,5456,73771,17,3,8192,64,67926,77835,4097,76158,75103,33,256,73771,77898,513]

theorem envBound21328 : H12AffineFastState.Bounded env21328 := by
  intro p hp
  have h : env21328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21327_21328 : H12AffineEnvironment.transform 13 4112 env21327 = env21328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env21327 == env21328) = true)

theorem identity21328 : scanCanonicalize (H12AffineFastState.compose env21328 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound21328 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,8192,3124,8541,65536,76846,10281,1024,8540,2420,73771,17,3,8192,64,67926,76847,3109,76158,75103,33,256,73771,76910,513]

theorem envBound21329 : H12AffineFastState.Bounded env21329 := by
  intro p hp
  have h : env21329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21328_21329 : H12AffineEnvironment.transform 11 3108 env21328 = env21329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env21328 == env21329) = true)

def env21330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5457,4194304,17,20499,8192,64,4225389,77834,16400,76158,75103,4268043,256,94266,90203,513]

theorem envBound21330 : H12AffineFastState.Bounded env21330 := by
  intro p hp
  have h : env21330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21325_21330 : H12AffineEnvironment.transform 20 5457 env21325 = env21330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env21325 == env21330) = true)

theorem identity21330 : scanCanonicalize (H12AffineFastState.compose env21330 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound21330 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5457,94266,17,20499,8192,64,67927,77834,16400,76158,75103,20529,256,94266,90203,513]

theorem envBound21331 : H12AffineFastState.Bounded env21331 := by
  intro p hp
  have h : env21331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21330_21331 : H12AffineEnvironment.transform 21 94266 env21330 = env21331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env21330 == env21331) = true)

theorem identity21331 : scanCanonicalize (H12AffineFastState.compose env21331 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21331 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8202,16400,30777,1024,29004,5457,20528,17,20499,8192,64,10589,4096,16400,2420,1365,20529,256,20528,16465,513]

theorem envBound21332 : H12AffineFastState.Bounded env21332 := by
  intro p hp
  have h : env21332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21331_21332 : H12AffineEnvironment.transform 15 8202 env21331 = env21332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21331 == env21332) = true)

theorem identity21332 : scanCanonicalize (H12AffineFastState.compose env21332 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound21332 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4097,10280,1024,8541,5457,33,17,2,8192,64,10589,4096,4097,2420,1365,32,256,33,4160,513]

theorem envBound21333 : H12AffineFastState.Bounded env21333 := by
  intro p hp
  have h : env21333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21332_21333 : H12AffineEnvironment.transform 13 4113 env21332 = env21333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env21332 == env21333) = true)

def env21334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8193,64,4677967,10560842,10507600,8830977,75102,14795782,256,2188651,2196550,513]

theorem envBound21334 : H12AffineFastState.Bounded env21334 := by
  intro p hp
  have h : env21334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21299_21334 : H12AffineEnvironment.transform 6 9 env21299 = env21334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21299 == env21334) = true)

def env21335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8193,64,4677967,2172250,2118976,442385,75102,6407190,256,2188651,2196550,513]

theorem envBound21335 : H12AffineFastState.Bounded env21335 := by
  intro p hp
  have h : env21335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21334_21335 : H12AffineEnvironment.transform 22 16 env21334 = env21335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env21334 == env21335) = true)

def env21336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8193,64,4677967,115014,45404,442385,75102,4268042,256,98679,90202,513]

theorem envBound21336 : H12AffineFastState.Bounded env21336 := by
  intro p hp
  have h : env21336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21335_21336 : H12AffineEnvironment.transform 20 58396 env21335 = env21336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env21335 == env21336) = true)

def env21337 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8193,16,4677919,114966,45324,442385,75022,4268042,256,98599,90122,513]

theorem envBound21337 : H12AffineFastState.Bounded env21337 := by
  intro p hp
  have h : env21337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21336_21337 : H12AffineEnvironment.transform 5 16 env21336 = env21337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21336 == env21337) = true)

def env21338 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8193,16,4409655,114966,45324,190521,75022,4268042,256,98599,90122,513]

theorem envBound21338 : H12AffineFastState.Bounded env21338 := by
  intro p hp
  have h : env21338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21337_21338 : H12AffineEnvironment.transform 17 10280 env21337 = env21338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21337 == env21338) = true)

theorem identity21338 : scanCanonicalize (H12AffineFastState.compose env21338 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound21338 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env21339 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,65830,16,41230,8193,16,149521,114966,45324,190521,75022,8492,256,98599,90122,513]

theorem envBound21339 : H12AffineFastState.Bounded env21339 := by
  intro p hp
  have h : env21339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21338_21339 : H12AffineEnvironment.transform 21 65830 env21338 = env21339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env21338 == env21339) = true)

theorem identity21339 : scanCanonicalize (H12AffineFastState.compose env21339 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound21339 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env21340 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58396,65830,16,41230,8193,16,34816,114966,45324,10280,75022,8492,256,98599,90122,513]

theorem envBound21340 : H12AffineFastState.Bounded env21340 := by
  intro p hp
  have h : env21340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21339_21340 : H12AffineEnvironment.transform 16 49169 env21339 = env21340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21339 == env21340) = true)

theorem identity21340 : scanCanonicalize (H12AffineFastState.compose env21340 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound21340 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env21341 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10280,1024,32769,58396,41260,16,41230,8193,16,34816,24860,45324,10280,34052,8492,256,8493,49152,513]

theorem envBound21341 : H12AffineFastState.Bounded env21341 := by
  intro p hp
  have h : env21341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21340_21341 : H12AffineEnvironment.transform 15 40970 env21340 = env21341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env21340 == env21341) = true)

def env21342 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8193,16,4409654,114966,45324,190520,75022,4268042,256,98599,90122,513]

theorem envBound21342 : H12AffineFastState.Bounded env21342 := by
  intro p hp
  have h : env21342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21337_21342 : H12AffineEnvironment.transform 17 10281 env21337 = env21342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21337 == env21342) = true)

theorem identity21342 : scanCanonicalize (H12AffineFastState.compose env21342 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound21342 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env21343 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,199939,16,41230,8193,16,17461,114966,45324,190520,75022,142601,256,98599,90122,513]

theorem envBound21343 : H12AffineFastState.Bounded env21343 := by
  intro p hp
  have h : env21343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21342_21343 : H12AffineEnvironment.transform 21 199939 env21342 = env21343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env21342 == env21343) = true)

theorem identity21343 : scanCanonicalize (H12AffineFastState.compose env21343 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21343 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env21344 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,58396,27929,16,41230,8193,16,17461,114966,45324,100386,75022,85267,256,98599,90122,513]

theorem envBound21344 : H12AffineFastState.Bounded env21344 := by
  intro p hp
  have h : env21344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21343_21344 : H12AffineEnvironment.transform 16 90138 env21343 = env21344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21343 == env21344) = true)

theorem identity21344 : scanCanonicalize (H12AffineFastState.compose env21344 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 24879) := by decide +kernel

theorem selectedBound21344 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env21345 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,24879,309,10281,1024,32769,58396,27929,16,41230,8193,16,17461,41017,45324,59661,17441,11324,256,57352,293,513]

theorem envBound21345 : H12AffineFastState.Bounded env21345 := by
  intro p hp
  have h : env21345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21344_21345 : H12AffineEnvironment.transform 15 24879 env21344 = env21345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24879 env21344 == env21345) = true)

theorem identity21345 : scanCanonicalize (H12AffineFastState.compose env21345 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound21345 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21346 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,292,32768,8203,309,10281,1024,32769,42296,11325,16,41230,8193,16,1297,41017,45324,43049,1285,11324,256,41260,293,513]

theorem envBound21346 : H12AffineFastState.Bounded env21346 := by
  intro p hp
  have h : env21346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21345_21346 : H12AffineEnvironment.transform 13 292 env21345 = env21346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env21345 == env21346) = true)

theorem identity21346 : scanCanonicalize (H12AffineFastState.compose env21346 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound21346 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21347 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,8192,292,32768,8203,309,10281,1024,32769,42296,11325,16,41230,8193,16,1297,41017,41017,43049,1285,11324,256,41260,293,513]

theorem envBound21347 : H12AffineFastState.Bounded env21347 := by
  intro p hp
  have h : env21347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21346_21347 : H12AffineEnvironment.transform 11 309 env21346 = env21347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env21346 == env21347) = true)

theorem identity21347 : scanCanonicalize (H12AffineFastState.compose env21347 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21347 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env21348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,309,8192,292,32768,8203,309,8233,1024,32769,42296,9277,16,41230,8193,16,1297,41017,41017,41001,1285,9276,256,41260,293,513]

theorem envBound21348 : H12AffineFastState.Bounded env21348 := by
  intro p hp
  have h : env21348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21347_21348 : H12AffineEnvironment.transform 10 0 env21347 = env21348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21347 == env21348) = true)

theorem identity21348 : scanCanonicalize (H12AffineFastState.compose env21348 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21348 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21349 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,8192,1,32768,8203,16,8233,1024,32769,42013,9277,16,41003,8193,16,1076,41017,41017,41001,1056,9276,37,40969,0,513]

theorem envBound21349 : H12AffineFastState.Bounded env21349 := by
  intro p hp
  have h : env21349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21348_21349 : H12AffineEnvironment.transform 7 37 env21348 = env21349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21348 == env21349) = true)

theorem identity21349 : scanCanonicalize (H12AffineFastState.compose env21349 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 9756) := by decide +kernel

theorem selectedBound21349 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env21350 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,8192,1,9756,8203,16,8233,1024,9757,513,9277,16,1591,8193,16,1076,1573,1573,1589,1056,9276,37,1557,0,513]

theorem envBound21350 : H12AffineFastState.Bounded env21350 := by
  intro p hp
  have h : env21350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21349_21350 : H12AffineEnvironment.transform 14 9756 env21349 = env21350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9756 env21349 == env21350) = true)

theorem identity21350 : scanCanonicalize (H12AffineFastState.compose env21350 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21350 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env21351 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,0,8192,1,9740,8203,0,8233,1024,9741,513,9261,0,1575,8193,0,1060,1573,1573,1573,1056,9260,37,1541,0,513]

theorem envBound21351 : H12AffineFastState.Bounded env21351 := by
  intro p hp
  have h : env21351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21350_21351 : H12AffineEnvironment.transform 3 0 env21350 = env21351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21350 == env21351) = true)

theorem identity21351 : scanCanonicalize (H12AffineFastState.compose env21351 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound21351 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21352 : List Nat := [2,4,8,0,32,0,9,37,512,1024,0,0,553,1,1061,546,0,512,1024,1060,513,1540,0,1575,552,0,1060,1573,1573,1573,1056,1541,37,1541,0,513]

theorem envBound21352 : H12AffineFastState.Bounded env21352 := by
  intro p hp
  have h : env21352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21351_21352 : H12AffineEnvironment.transform 12 553 env21351 = env21352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env21351 == env21352) = true)

theorem identity21352 : scanCanonicalize (H12AffineFastState.compose env21352 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound21352 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env21353 : List Nat := [2,4,8,0,32,0,9,37,512,37,0,0,553,1,0,546,0,512,37,1,513,545,0,514,552,0,1,512,512,512,5,544,37,544,0,513]

theorem envBound21353 : H12AffineFastState.Bounded env21353 := by
  intro p hp
  have h : env21353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21352_21353 : H12AffineEnvironment.transform 9 37 env21352 = env21353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env21352 == env21353) = true)

theorem identity21353 : scanCanonicalize (H12AffineFastState.compose env21353 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21353 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21354 : List Nat := [2,4,8,0,0,0,9,5,512,5,0,0,521,1,0,514,0,512,5,1,513,513,0,514,520,0,1,512,512,512,5,512,5,512,0,513]

theorem envBound21354 : H12AffineFastState.Bounded env21354 := by
  intro p hp
  have h : env21354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21353_21354 : H12AffineEnvironment.transform 4 0 env21353 = env21354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21353 == env21354) = true)

theorem identity21354 : scanCanonicalize (H12AffineFastState.compose env21354 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21355 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,0,8,1,0,3,0,1,5,1,0,0,0,3,9,0,1,1,1,1,5,1,5,1,0,0]

theorem envBound21355 : H12AffineFastState.Bounded env21355 := by
  intro p hp
  have h : env21355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21354_21355 : H12AffineEnvironment.transform 8 1 env21354 = env21355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21354 == env21355) = true)

def env21356 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8193,17,4677918,114967,45325,442385,75023,4268042,256,98598,90123,513]

theorem envBound21356 : H12AffineFastState.Bounded env21356 := by
  intro p hp
  have h : env21356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21336_21356 : H12AffineEnvironment.transform 5 17 env21336 = env21356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21336 == env21356) = true)

theorem identity21356 : scanCanonicalize (H12AffineFastState.compose env21356 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21356 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env21357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8193,17,4409654,114967,45325,190521,75023,4268042,256,98598,90123,513]

theorem envBound21357 : H12AffineFastState.Bounded env21357 := by
  intro p hp
  have h : env21357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21356_21357 : H12AffineEnvironment.transform 17 10280 env21356 = env21357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21356 == env21357) = true)

theorem identity21357 : scanCanonicalize (H12AffineFastState.compose env21357 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound21357 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env21358 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,4194304,16,41231,8193,17,4204845,114967,45325,100386,75023,4268042,256,98598,90123,513]

theorem envBound21358 : H12AffineFastState.Bounded env21358 := by
  intro p hp
  have h : env21358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21357_21358 : H12AffineEnvironment.transform 16 90139 env21357 = env21358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env21357 == env21358) = true)

theorem identity21358 : scanCanonicalize (H12AffineFastState.compose env21358 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound21358 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env21359 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,65830,16,41231,8193,17,75787,114967,45325,100386,75023,8492,256,98598,90123,513]

theorem envBound21359 : H12AffineFastState.Bounded env21359 := by
  intro p hp
  have h : env21359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21358_21359 : H12AffineEnvironment.transform 21 65830 env21358 = env21359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env21358 == env21359) = true)

theorem identity21359 : scanCanonicalize (H12AffineFastState.compose env21359 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound21359 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21360 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33031,57628,10280,1024,32769,58396,32801,16,41231,8193,17,43276,16400,45325,2341,41992,8492,256,33,57612,513]

theorem envBound21360 : H12AffineFastState.Bounded env21360 := by
  intro p hp
  have h : env21360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21359_21360 : H12AffineEnvironment.transform 15 33031 env21359 = env21360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env21359 == env21360) = true)

theorem identity21360 : scanCanonicalize (H12AffineFastState.compose env21360 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21360 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21361 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33031,49169,2341,1024,32769,50449,32801,16,32770,268,17,34817,16400,36864,2341,34053,33,256,33,49153,513]

theorem envBound21361 : H12AffineFastState.Bounded env21361 := by
  intro p hp
  have h : env21361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21360_21361 : H12AffineEnvironment.transform 12 269 env21360 = env21361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21360 == env21361) = true)

theorem identity21361 : scanCanonicalize (H12AffineFastState.compose env21361 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound21361 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21362 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21541,21794,5172,2341,1024,21540,4404,21508,16,21543,268,17,23588,16400,17445,2341,20768,33,256,33,5156,513]

theorem envBound21362 : H12AffineFastState.Bounded env21362 := by
  intro p hp
  have h : env21362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21361_21362 : H12AffineEnvironment.transform 14 21541 env21361 = env21362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env21361 == env21362) = true)

theorem identity21362 : scanCanonicalize (H12AffineFastState.compose env21362 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound21362 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21363 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,6160,3125,3378,5172,2341,1024,3124,4404,3092,16,3127,268,17,1076,6144,7221,2341,2352,33,256,33,5156,513]

theorem envBound21363 : H12AffineFastState.Bounded env21363 := by
  intro p hp
  have h : env21363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21362_21363 : H12AffineEnvironment.transform 13 6160 env21362 = env21363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env21362 == env21363) = true)

theorem identity21363 : scanCanonicalize (H12AffineFastState.compose env21363 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound21363 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env21364 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1045,4096,269,5125,32,295,5172,1328,1024,33,4404,1,16,34,268,17,1076,5141,4128,1328,1317,33,256,33,5156,513]

theorem envBound21364 : H12AffineFastState.Bounded env21364 := by
  intro p hp
  have h : env21364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21363_21364 : H12AffineEnvironment.transform 10 1045 env21363 = env21364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env21363 == env21364) = true)

def env21365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4677967,115015,45405,442385,75102,4268043,256,98678,90203,513]

theorem envBound21365 : H12AffineFastState.Bounded env21365 := by
  intro p hp
  have h : env21365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21335_21365 : H12AffineEnvironment.transform 20 58397 env21335 = env21365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env21335 == env21365) = true)

theorem identity21365 : scanCanonicalize (H12AffineFastState.compose env21365 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4604229,57677,45405,442385,1364,4194305,256,41340,16465,513]

theorem envBound21366 : H12AffineFastState.Bounded env21366 := by
  intro p hp
  have h : env21366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21365_21366 : H12AffineEnvironment.transform 15 8202 env21365 = env21366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21365 == env21366) = true)

theorem identity21366 : scanCanonicalize (H12AffineFastState.compose env21366 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound21366 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env21367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419912,16,41310,8193,64,10509,57677,45405,442385,1364,419913,256,41340,16465,513]

theorem envBound21367 : H12AffineFastState.Bounded env21367 := by
  intro p hp
  have h : env21367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21366_21367 : H12AffineEnvironment.transform 21 419912 env21366 = env21367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env21366 == env21367) = true)

def env21368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58397,272392,16,41310,8193,64,10509,57677,45405,294993,1364,272393,256,41340,16465,513]

theorem envBound21368 : H12AffineFastState.Bounded env21368 := by
  intro p hp
  have h : env21368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21367_21368 : H12AffineEnvironment.transform 16 16448 env21367 = env21368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env21367 == env21368) = true)

theorem identity21368 : scanCanonicalize (H12AffineFastState.compose env21368 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound21368 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,10360,1024,32769,58397,112,16,41310,8193,64,10509,57677,45405,43049,1364,113,256,41340,16465,513]

theorem envBound21369 : H12AffineFastState.Bounded env21369 := by
  intro p hp
  have h : env21369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21368_21369 : H12AffineEnvironment.transform 17 10360 env21368 = env21369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env21368 == env21369) = true)

theorem identity21369 : scanCanonicalize (H12AffineFastState.compose env21369 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21369 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21370 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,58397,32,16,41230,8193,16,10509,57629,45325,43049,1284,33,256,41260,16385,513]

theorem envBound21370 : H12AffineFastState.Bounded env21370 := by
  intro p hp
  have h : env21370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21369_21370 : H12AffineEnvironment.transform 5 16 env21369 = env21370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21369 == env21370) = true)

theorem identity21370 : scanCanonicalize (H12AffineFastState.compose env21370 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound21370 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env21371 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13576,32768,8202,13592,10280,1024,32769,37141,32,16,41230,8193,16,10509,37909,45325,43049,1284,33,256,41260,13577,513]

theorem envBound21371 : H12AffineFastState.Bounded env21371 := by
  intro p hp
  have h : env21371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21370_21371 : H12AffineEnvironment.transform 13 13576 env21370 = env21371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env21370 == env21371) = true)

theorem identity21371 : scanCanonicalize (H12AffineFastState.compose env21371 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21371 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env21372 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13576,1,8202,13592,10280,1024,0,4372,32,16,8463,8193,16,10509,5140,12556,10280,1284,33,256,8493,13577,513]

theorem envBound21372 : H12AffineFastState.Bounded env21372 := by
  intro p hp
  have h : env21372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21371_21372 : H12AffineEnvironment.transform 14 1 env21371 = env21372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21371 == env21372) = true)

theorem identity21372 : scanCanonicalize (H12AffineFastState.compose env21372 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21372 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21373 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5124,1,262,5140,2340,1024,0,4372,32,16,3,269,16,2049,5140,4096,2340,1284,33,256,33,5125,513]

theorem envBound21373 : H12AffineFastState.Bounded env21373 := by
  intro p hp
  have h : env21373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21372_21373 : H12AffineEnvironment.transform 12 268 env21372 = env21373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21372 == env21373) = true)

theorem identity21373 : scanCanonicalize (H12AffineFastState.compose env21373 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21374 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,4096,268,5124,1,262,5140,2308,1024,0,4372,0,16,3,269,16,2049,5140,4096,2308,1284,1,256,1,5125,513]

theorem envBound21374 : H12AffineFastState.Bounded env21374 := by
  intro p hp
  have h : env21374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21373_21374 : H12AffineEnvironment.transform 4 0 env21373 = env21374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21373 == env21374) = true)

theorem identity21374 : scanCanonicalize (H12AffineFastState.compose env21374 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound21374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21375 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,16,268,1044,1,262,1028,2308,1024,0,260,0,16,3,269,16,2049,1028,16,2308,1284,1,256,1,1045,513]

theorem envBound21375 : H12AffineFastState.Bounded env21375 := by
  intro p hp
  have h : env21375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21374_21375 : H12AffineEnvironment.transform 11 16 env21374 = env21375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21374 == env21375) = true)

theorem identity21375 : scanCanonicalize (H12AffineFastState.compose env21375 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound21375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21376 : List Nat := [2,4,8,16,0,16,9,256,261,1024,2048,16,268,1044,1,262,1028,2308,1024,0,260,0,16,3,269,16,2049,1028,16,2308,1284,1,256,1,1045,260]

theorem envBound21376 : H12AffineFastState.Bounded env21376 := by
  intro p hp
  have h : env21376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21375_21376 : H12AffineEnvironment.transform 8 261 env21375 = env21376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env21375 == env21376) = true)

theorem identity21376 : scanCanonicalize (H12AffineFastState.compose env21376 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound21376 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21377 : List Nat := [2,4,8,16,0,16,9,256,261,1024,276,16,268,1044,1,262,1028,16,1024,0,260,0,16,3,269,16,277,1028,16,16,1284,1,256,1,1045,260]

theorem envBound21377 : H12AffineFastState.Bounded env21377 := by
  intro p hp
  have h : env21377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21376_21377 : H12AffineEnvironment.transform 10 276 env21376 = env21377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env21376 == env21377) = true)

theorem identity21377 : scanCanonicalize (H12AffineFastState.compose env21377 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound21377 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21378 : List Nat := [2,4,8,16,0,16,9,256,261,256,276,16,268,276,1,262,260,16,256,0,260,0,16,3,269,16,277,260,16,16,4,1,256,1,277,260]

theorem envBound21378 : H12AffineFastState.Bounded env21378 := by
  intro p hp
  have h : env21378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21377_21378 : H12AffineEnvironment.transform 9 256 env21377 = env21378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env21377 == env21378) = true)

def env21379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58397,272393,16,41310,8193,64,10509,57677,45405,294992,1364,272392,256,41340,16465,513]

theorem envBound21379 : H12AffineFastState.Bounded env21379 := by
  intro p hp
  have h : env21379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21367_21379 : H12AffineEnvironment.transform 16 16449 env21367 = env21379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env21367 == env21379) = true)

theorem identity21379 : scanCanonicalize (H12AffineFastState.compose env21379 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound21379 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,2421,1024,32769,58397,8572,16,41310,8193,64,10509,57677,45405,35109,1364,8573,256,41340,16465,513]

theorem envBound21380 : H12AffineFastState.Bounded env21380 := by
  intro p hp
  have h : env21380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21379_21380 : H12AffineEnvironment.transform 17 2421 env21379 = env21380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env21379 == env21380) = true)

theorem identity21380 : scanCanonicalize (H12AffineFastState.compose env21380 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21380 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env21381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,263,16449,2421,1024,32769,50448,113,16,32851,268,64,2048,49216,36944,35109,1364,112,256,32881,16465,513]

theorem envBound21381 : H12AffineFastState.Bounded env21381 := by
  intro p hp
  have h : env21381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21380_21381 : H12AffineEnvironment.transform 12 269 env21380 = env21381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21380 == env21381) = true)

theorem identity21381 : scanCanonicalize (H12AffineFastState.compose env21381 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound21381 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env21382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,263,16449,2421,1024,80,17729,113,16,2,268,64,2048,16401,4097,2420,1364,112,256,32,16465,513]

theorem envBound21382 : H12AffineFastState.Bounded env21382 := by
  intro p hp
  have h : env21382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21381_21382 : H12AffineEnvironment.transform 14 81 env21381 = env21382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env21381 == env21382) = true)

theorem identity21382 : scanCanonicalize (H12AffineFastState.compose env21382 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 372) := by decide +kernel

theorem selectedBound21382 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,372,81,263,309,2421,1024,80,1077,113,16,2,268,64,2048,357,4097,2420,1364,112,256,32,293,513]

theorem envBound21383 : H12AffineFastState.Bounded env21383 := by
  intro p hp
  have h : env21383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21382_21383 : H12AffineEnvironment.transform 13 372 env21382 = env21383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 372 env21382 == env21383) = true)

theorem identity21383 : scanCanonicalize (H12AffineFastState.compose env21383 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound21383 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env21384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,269,372,81,263,309,2421,1024,80,1077,113,16,2,268,64,2048,357,2064,2420,1364,112,256,32,293,513]

theorem envBound21384 : H12AffineFastState.Bounded env21384 := by
  intro p hp
  have h : env21384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21383_21384 : H12AffineEnvironment.transform 11 2065 env21383 = env21384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env21383 == env21384) = true)

theorem identity21384 : scanCanonicalize (H12AffineFastState.compose env21384 (packedSelected [0,3,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound21384 : packedSelected [0,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env21385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,357,269,372,81,263,309,1,1024,80,1077,113,16,2,268,64,372,357,356,0,1364,112,256,32,293,513]

theorem envBound21385 : H12AffineFastState.Bounded env21385 := by
  intro p hp
  have h : env21385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21384_21385 : H12AffineEnvironment.transform 10 372 env21384 = env21385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env21384 == env21385) = true)

def env21386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8193,64,4677967,2172251,2118977,442384,75102,6407191,256,2188651,2196550,513]

theorem envBound21386 : H12AffineFastState.Bounded env21386 := by
  intro p hp
  have h : env21386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21334_21386 : H12AffineEnvironment.transform 22 17 env21334 = env21386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env21334 == env21386) = true)

theorem identity21386 : scanCanonicalize (H12AffineFastState.compose env21386 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21386 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456789,2172251,2118977,368650,75102,6407191,256,2188651,2196550,513]

theorem envBound21387 : H12AffineFastState.Bounded env21387 := by
  intro p hp
  have h : env21387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21386_21387 : H12AffineEnvironment.transform 16 90138 env21386 = env21387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21386 == env21387) = true)

theorem identity21387 : scanCanonicalize (H12AffineFastState.compose env21387 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound21387 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456789,2139149,2118977,270684,41992,6309185,256,2155581,2098448,513]

theorem envBound21388 : H12AffineFastState.Bounded env21388 := by
  intro p hp
  have h : env21388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21387_21388 : H12AffineEnvironment.transform 15 33110 env21387 = env21388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env21387 == env21388) = true)

theorem identity21388 : scanCanonicalize (H12AffineFastState.compose env21388 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21388 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,2097152,4194304,17,41311,8193,64,4204925,2139149,2118977,2420,41992,6309185,256,2155581,2098448,513]

theorem envBound21389 : H12AffineFastState.Bounded env21389 := by
  intro p hp
  have h : env21389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21388_21389 : H12AffineEnvironment.transform 17 10280 env21388 = env21389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21388 == env21389) = true)

theorem identity21389 : scanCanonicalize (H12AffineFastState.compose env21389 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound21389 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,25676,4194304,17,41311,8193,64,4204925,49217,12557,2420,41992,4202765,256,32881,24924,513]

theorem envBound21390 : H12AffineFastState.Bounded env21390 := by
  intro p hp
  have h : env21390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21389_21390 : H12AffineEnvironment.transform 20 25676 env21389 = env21390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env21389 == env21390) = true)

theorem identity21390 : scanCanonicalize (H12AffineFastState.compose env21390 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound21390 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,25676,8493,17,41311,8193,64,2128,49217,12557,2420,41992,32,256,32881,24924,513]

theorem envBound21391 : H12AffineFastState.Bounded env21391 := by
  intro p hp
  have h : env21391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21390_21391 : H12AffineEnvironment.transform 21 8493 env21390 = env21391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env21390 == env21391) = true)

theorem identity21391 : scanCanonicalize (H12AffineFastState.compose env21391 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21391 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1024,8540,25676,8493,17,2,8193,64,2128,24860,12557,2420,1365,32,256,8492,24924,513]

theorem envBound21392 : H12AffineFastState.Bounded env21392 := by
  intro p hp
  have h : env21392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21391_21392 : H12AffineEnvironment.transform 14 8541 env21391 = env21392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21391 == env21392) = true)

theorem identity21392 : scanCanonicalize (H12AffineFastState.compose env21392 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21392 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,81,263,16401,2340,1024,80,17728,33,17,2,269,64,2128,16400,4097,2420,1365,32,256,32,16464,513]

theorem envBound21393 : H12AffineFastState.Bounded env21393 := by
  intro p hp
  have h : env21393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21392_21393 : H12AffineEnvironment.transform 12 268 env21392 = env21393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21392 == env21393) = true)

theorem identity21393 : scanCanonicalize (H12AffineFastState.compose env21393 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1392) := by decide +kernel

theorem selectedBound21393 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1392,268,16384,81,263,16401,2340,1024,80,17728,33,17,2,269,64,2128,16400,1393,2420,1365,32,256,32,16464,513]

theorem envBound21394 : H12AffineFastState.Bounded env21394 := by
  intro p hp
  have h : env21394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21393_21394 : H12AffineEnvironment.transform 11 1392 env21393 = env21394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1392 env21393 == env21394) = true)

theorem identity21394 : scanCanonicalize (H12AffineFastState.compose env21394 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2625) := by decide +kernel

theorem selectedBound21394 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env21395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1392,268,2625,81,263,2640,2340,1024,80,3841,33,17,2,269,64,2128,2641,1393,2420,1365,32,256,32,2577,513]

theorem envBound21395 : H12AffineFastState.Bounded env21395 := by
  intro p hp
  have h : env21395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21394_21395 : H12AffineEnvironment.transform 13 2625 env21394 = env21395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2625 env21394 == env21395) = true)

theorem identity21395 : scanCanonicalize (H12AffineFastState.compose env21395 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound21395 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21396 : List Nat := [2,4,8,16,32,64,9,256,277,1024,2048,1392,268,2388,81,263,2373,2340,1024,80,3092,33,17,2,269,64,2128,2372,1393,2420,1365,32,256,32,2308,276]

theorem envBound21396 : H12AffineFastState.Bounded env21396 := by
  intro p hp
  have h : env21396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21395_21396 : H12AffineEnvironment.transform 8 277 env21395 = env21396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env21395 == env21396) = true)

theorem identity21396 : scanCanonicalize (H12AffineFastState.compose env21396 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound21396 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21397 : List Nat := [2,4,8,16,32,64,9,84,65,1024,2048,1060,88,2048,81,83,2065,2160,1024,80,3092,33,17,2,89,64,2128,2064,1061,2080,1025,32,84,32,2128,64]

theorem envBound21397 : H12AffineFastState.Bounded env21397 := by
  intro p hp
  have h : env21397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21396_21397 : H12AffineEnvironment.transform 7 84 env21396 = env21397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env21396 == env21397) = true)

theorem identity21397 : scanCanonicalize (H12AffineFastState.compose env21397 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21397 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env21398 : List Nat := [2,4,8,16,32,17,9,5,16,1024,2048,1060,9,2048,0,2,2065,2081,1024,1,3092,33,17,2,8,17,2049,2064,1061,2080,1025,32,5,32,2049,17]

theorem envBound21398 : H12AffineFastState.Bounded env21398 := by
  intro p hp
  have h : env21398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21397_21398 : H12AffineEnvironment.transform 5 17 env21397 = env21398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21397 == env21398) = true)

def env21399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound21399 : H12AffineFastState.Bounded env21399 := by
  intro p hp
  have h : env21399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21297_21399 : H12AffineEnvironment.transform 18 1025 env21297 = env21399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21297 == env21399) = true)

theorem identity21399 : scanCanonicalize (H12AffineFastState.compose env21399 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound21399 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655366,18973836,10507600,8749382,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound21400 : H12AffineFastState.Bounded env21400 := by
  intro p hp
  have h : env21400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21399_21400 : H12AffineEnvironment.transform 16 82246 env21399 = env21400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env21399 == env21400) = true)

def env21401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623434,8393984,10507600,8749382,2102684,12645453,257,21793,46212,2175563]

theorem envBound21401 : H12AffineFastState.Bounded env21401 := by
  intro p hp
  have h : env21401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21400_21401 : H12AffineEnvironment.transform 23 10588556 env21400 = env21401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env21400 == env21401) = true)

def env21402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623434,2098512,17664,2461974,2102684,6349853,257,21793,46212,2175563]

theorem envBound21402 : H12AffineFastState.Bounded env21402 := by
  intro p hp
  have h : env21402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21401_21402 : H12AffineEnvironment.transform 22 2101328 env21401 = env21402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21401 == env21402) = true)

def env21403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177098,2098512,17664,2461974,2102684,2411677,257,21793,46212,2175563]

theorem envBound21403 : H12AffineFastState.Bounded env21403 := by
  intro p hp
  have h : env21403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21402_21403 : H12AffineEnvironment.transform 21 272512 env21402 = env21403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21402 == env21403) = true)

theorem identity21403 : scanCanonicalize (H12AffineFastState.compose env21403 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound21403 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,58517,272512,62661,98780,8328,64,122079,57797,17664,357763,61705,272392,257,21793,46212,120542]

theorem envBound21404 : H12AffineFastState.Bounded env21404 := by
  intro p hp
  have h : env21404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21403_21404 : H12AffineEnvironment.transform 20 58517 env21403 = env21404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env21403 == env21404) = true)

def env21405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,58517,168,62661,98780,8328,64,122079,57797,17664,89515,61705,32,257,21793,46212,120542]

theorem envBound21405 : H12AffineFastState.Bounded env21405 := by
  intro p hp
  have h : env21405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21404_21405 : H12AffineEnvironment.transform 17 10280 env21404 = env21405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21404 == env21405) = true)

theorem identity21405 : scanCanonicalize (H12AffineFastState.compose env21405 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound21405 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,5528,10280,1025,32769,58517,168,62661,54530,8328,64,34817,57797,17664,2421,61705,32,257,21793,46212,33280]

theorem envBound21406 : H12AffineFastState.Bounded env21406 := by
  intro p hp
  have h : env21406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21405_21406 : H12AffineEnvironment.transform 15 21726 env21405 = env21406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env21405 == env21406) = true)

theorem identity21406 : scanCanonicalize (H12AffineFastState.compose env21406 (packedSelected [0,1,3,4,7,8,10,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound21406 : packedSelected [0,1,3,4,7,8,10,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8203,5528,10280,1025,32769,36928,168,32784,41431,8328,64,34817,38160,12757,2421,34268,32,257,8692,46212,33280]

theorem envBound21407 : H12AffineFastState.Bounded env21407 := by
  intro p hp
  have h : env21407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21406_21407 : H12AffineEnvironment.transform 13 13525 env21406 = env21407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env21406 == env21407) = true)

theorem identity21407 : scanCanonicalize (H12AffineFastState.compose env21407 (packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound21407 : packedSelected [0,2,3,5,6,7,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env21408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,32768,398,5528,2477,1025,32769,36928,168,32784,32850,269,64,34817,38160,4176,2421,34268,32,257,113,38145,33280]

theorem envBound21408 : H12AffineFastState.Bounded env21408 := by
  intro p hp
  have h : env21408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21407_21408 : H12AffineEnvironment.transform 12 389 env21407 = env21408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env21407 == env21408) = true)

theorem identity21408 : scanCanonicalize (H12AffineFastState.compose env21408 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound21408 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env21409 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,32768,343,5441,2420,1025,32769,36928,113,32784,32850,269,64,34817,38160,4176,2421,34053,32,257,113,38145,33280]

theorem envBound21409 : H12AffineFastState.Bounded env21409 := by
  intro p hp
  have h : env21409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21408_21409 : H12AffineEnvironment.transform 6 89 env21408 = env21409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21408 == env21409) = true)

theorem identity21409 : scanCanonicalize (H12AffineFastState.compose env21409 (packedSelected [0,1,3,5,6,7,8,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound21409 : packedSelected [0,1,3,5,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env21410 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,112,343,5441,2420,1025,113,4144,113,96,34,269,64,2161,5472,4176,2421,1397,32,257,113,5489,624]

theorem envBound21410 : H12AffineFastState.Bounded env21410 := by
  intro p hp
  have h : env21410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21409_21410 : H12AffineEnvironment.transform 14 112 env21409 = env21410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env21409 == env21410) = true)

theorem identity21410 : scanCanonicalize (H12AffineFastState.compose env21410 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21410 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21411 : List Nat := [2,4,8,16,0,64,89,256,512,1024,2048,4096,348,5456,80,343,5441,2388,1025,81,4112,81,64,2,269,64,2129,5440,4176,2389,1365,0,257,81,5457,592]

theorem envBound21411 : H12AffineFastState.Bounded env21411 := by
  intro p hp
  have h : env21411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21410_21411 : H12AffineEnvironment.transform 4 0 env21410 = env21411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21410 == env21411) = true)

theorem identity21411 : scanCanonicalize (H12AffineFastState.compose env21411 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound21411 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env21412 : List Nat := [2,4,8,16,0,64,89,84,512,1024,2048,4096,8,5124,80,3,5141,2048,1025,81,4112,81,64,2,89,64,2129,5140,4176,2049,1025,0,85,81,5125,592]

theorem envBound21412 : H12AffineFastState.Bounded env21412 := by
  intro p hp
  have h : env21412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21411_21412 : H12AffineEnvironment.transform 7 84 env21411 = env21412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env21411 == env21412) = true)

theorem identity21412 : scanCanonicalize (H12AffineFastState.compose env21412 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound21412 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env21413 : List Nat := [2,4,8,16,0,64,89,84,512,533,2048,4096,8,4625,80,3,4608,2048,532,81,4112,81,64,2,89,64,2129,4609,4176,2049,532,0,85,81,4624,592]

theorem envBound21413 : H12AffineFastState.Bounded env21413 := by
  intro p hp
  have h : env21413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21412_21413 : H12AffineEnvironment.transform 9 533 env21412 = env21413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env21412 == env21413) = true)

theorem identity21413 : scanCanonicalize (H12AffineFastState.compose env21413 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21413 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env21414 : List Nat := [2,4,8,16,0,17,8,5,512,533,2048,4096,8,4625,1,3,4608,2048,532,0,4112,0,17,2,8,17,2048,4609,4097,2049,532,0,4,0,4624,513]

theorem envBound21414 : H12AffineFastState.Bounded env21414 := by
  intro p hp
  have h : env21414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21413_21414 : H12AffineEnvironment.transform 5 17 env21413 = env21414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21413 == env21414) = true)

theorem identity21414 : scanCanonicalize (H12AffineFastState.compose env21414 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound21414 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21415 : List Nat := [2,4,8,16,0,17,8,5,512,533,2048,513,8,16,1,3,1,2048,532,0,529,0,17,2,8,17,2048,0,512,2049,532,0,4,0,17,513]

theorem envBound21415 : H12AffineFastState.Bounded env21415 := by
  intro p hp
  have h : env21415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21414_21415 : H12AffineEnvironment.transform 11 513 env21414 = env21415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env21414 == env21415) = true)

theorem identity21415 : scanCanonicalize (H12AffineFastState.compose env21415 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound21415 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21416 : List Nat := [2,4,8,16,0,17,8,5,17,4,2048,16,8,16,1,3,1,2048,5,0,0,0,17,2,8,17,2048,0,17,2049,5,0,4,0,17,16]

theorem envBound21416 : H12AffineFastState.Bounded env21416 := by
  intro p hp
  have h : env21416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21415_21416 : H12AffineEnvironment.transform 8 17 env21415 = env21416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env21415 == env21416) = true)

theorem identity21416 : scanCanonicalize (H12AffineFastState.compose env21416 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21417 : List Nat := [2,4,8,0,0,1,8,5,1,4,2048,0,8,0,1,3,1,2048,5,0,0,0,1,2,8,1,2048,0,1,2049,5,0,4,0,1,0]

theorem envBound21417 : H12AffineFastState.Bounded env21417 := by
  intro p hp
  have h : env21417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21416_21417 : H12AffineEnvironment.transform 3 0 env21416 = env21417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21416 == env21417) = true)

theorem identity21417 : scanCanonicalize (H12AffineFastState.compose env21417 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound21417 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21418 : List Nat := [2,4,8,0,0,1,8,5,1,4,11,0,8,0,1,3,1,11,5,0,0,0,1,2,8,1,11,0,1,10,5,0,4,0,1,0]

theorem envBound21418 : H12AffineFastState.Bounded env21418 := by
  intro p hp
  have h : env21418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21417_21418 : H12AffineEnvironment.transform 10 11 env21417 = env21418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env21417 == env21418) = true)

theorem identity21418 : scanCanonicalize (H12AffineFastState.compose env21418 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21418 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21419 : List Nat := [2,4,3,0,0,1,3,5,1,4,0,0,3,0,1,3,1,0,5,0,0,0,1,2,3,1,0,0,1,1,5,0,4,0,1,0]

theorem envBound21419 : H12AffineFastState.Bounded env21419 := by
  intro p hp
  have h : env21419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21418_21419 : H12AffineEnvironment.transform 2 3 env21418 = env21419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21418 == env21419) = true)

def env21420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,58517,169,62661,98780,8328,64,122079,57797,17664,89514,61705,33,257,21793,46212,120542]

theorem envBound21420 : H12AffineFastState.Bounded env21420 := by
  intro p hp
  have h : env21420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21404_21420 : H12AffineEnvironment.transform 17 10281 env21404 = env21420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21404 == env21420) = true)

theorem identity21420 : scanCanonicalize (H12AffineFastState.compose env21420 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound21420 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,82246,10281,1025,8353,17461,169,21605,74108,8328,64,97407,16741,17664,89514,20905,33,257,21793,5156,95870]

theorem envBound21421 : H12AffineFastState.Bounded env21421 := by
  intro p hp
  have h : env21421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21420_21421 : H12AffineEnvironment.transform 14 8352 env21420 = env21421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env21420 == env21421) = true)

theorem identity21421 : scanCanonicalize (H12AffineFastState.compose env21421 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21421 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8352,65536,70863,10281,1025,8353,4540,169,492,74108,8328,64,76278,5356,4233,67619,1056,33,257,168,5156,74743]

theorem envBound21422 : H12AffineFastState.Bounded env21422 := by
  intro p hp
  have h : env21422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21421_21422 : H12AffineEnvironment.transform 13 5513 env21421 = env21422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21421 == env21422) = true)

theorem identity21422 : scanCanonicalize (H12AffineFastState.compose env21422 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21422 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8352,8202,13509,10281,1025,8353,4540,169,492,374,8328,64,2556,5356,4233,10281,1056,33,257,168,5156,1021]

theorem envBound21423 : H12AffineFastState.Bounded env21423 := by
  intro p hp
  have h : env21423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21422_21423 : H12AffineEnvironment.transform 15 8202 env21422 = env21423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21422 == env21423) = true)

theorem identity21423 : scanCanonicalize (H12AffineFastState.compose env21423 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21423 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,508,342,5529,2421,1025,509,4540,169,492,374,468,64,2556,5356,4233,2421,1056,33,257,168,5156,1021]

theorem envBound21424 : H12AffineFastState.Bounded env21424 := by
  intro p hp
  have h : env21424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21423_21424 : H12AffineEnvironment.transform 12 348 env21423 = env21424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21423 == env21424) = true)

theorem identity21424 : scanCanonicalize (H12AffineFastState.compose env21424 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21424 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,372,342,5393,2421,1025,373,4404,33,356,374,348,64,2420,5220,4097,2421,1056,33,257,32,5156,885]

theorem envBound21425 : H12AffineFastState.Bounded env21425 := by
  intro p hp
  have h : env21425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21424_21425 : H12AffineEnvironment.transform 6 8 env21424 = env21425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21424 == env21425) = true)

theorem identity21425 : scanCanonicalize (H12AffineFastState.compose env21425 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21425 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21426 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,372,342,4096,2421,272,373,4404,33,356,374,348,64,2420,4469,4097,2421,305,33,257,32,4405,885]

theorem envBound21426 : H12AffineFastState.Bounded env21426 := by
  intro p hp
  have h : env21426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21425_21426 : H12AffineEnvironment.transform 9 273 env21425 = env21426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21425 == env21426) = true)

theorem identity21426 : scanCanonicalize (H12AffineFastState.compose env21426 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21426 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env21427 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,41,4112,1,35,4096,2048,101,0,4161,33,17,3,41,64,2049,4096,4097,2048,68,33,116,32,4160,512]

theorem envBound21427 : H12AffineFastState.Bounded env21427 := by
  intro p hp
  have h : env21427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21426_21427 : H12AffineEnvironment.transform 7 117 env21426 = env21427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21426 == env21427) = true)

theorem identity21427 : scanCanonicalize (H12AffineFastState.compose env21427 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21427 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21428 : List Nat := [2,4,8,16,16,64,8,69,512,84,2048,4096,25,4112,1,19,4096,2048,85,0,4161,17,17,3,25,64,2049,4096,4097,2048,68,17,68,16,4160,512]

theorem envBound21428 : H12AffineFastState.Bounded env21428 := by
  intro p hp
  have h : env21428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21427_21428 : H12AffineEnvironment.transform 4 16 env21427 = env21428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21427 == env21428) = true)

theorem identity21428 : scanCanonicalize (H12AffineFastState.compose env21428 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound21428 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21429 : List Nat := [2,4,8,16,16,64,8,69,512,84,2048,2059,25,2075,1,19,2059,2048,85,0,2122,17,17,3,25,64,2049,2059,2058,2048,68,17,68,16,2123,512]

theorem envBound21429 : H12AffineFastState.Bounded env21429 := by
  intro p hp
  have h : env21429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21428_21429 : H12AffineEnvironment.transform 11 2059 env21428 = env21429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env21428 == env21429) = true)

theorem identity21429 : scanCanonicalize (H12AffineFastState.compose env21429 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound21429 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21430 : List Nat := [2,4,8,16,16,64,8,69,4,84,2048,2059,25,2075,1,19,2059,2048,85,0,2122,17,17,3,25,64,2049,2059,2058,2048,68,17,68,16,2123,4]

theorem envBound21430 : H12AffineFastState.Bounded env21430 := by
  intro p hp
  have h : env21430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21429_21430 : H12AffineEnvironment.transform 8 4 env21429 = env21430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env21429 == env21430) = true)

theorem identity21430 : scanCanonicalize (H12AffineFastState.compose env21430 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound21430 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21431 : List Nat := [2,4,8,16,16,3,8,6,4,23,2048,2059,25,2075,1,19,2059,2048,22,0,2057,17,17,3,25,3,2049,2059,2058,2048,7,17,7,16,2056,4]

theorem envBound21431 : H12AffineFastState.Bounded env21431 := by
  intro p hp
  have h : env21431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21430_21431 : H12AffineEnvironment.transform 5 3 env21430 = env21431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env21430 == env21431) = true)

theorem identity21431 : scanCanonicalize (H12AffineFastState.compose env21431 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21431 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21432 : List Nat := [2,4,8,0,0,3,8,6,4,7,2048,2059,9,2059,1,3,2059,2048,6,0,2057,1,1,3,9,3,2049,2059,2058,2048,7,1,7,0,2056,4]

theorem envBound21432 : H12AffineFastState.Bounded env21432 := by
  intro p hp
  have h : env21432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21431_21432 : H12AffineEnvironment.transform 3 0 env21431 = env21432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21431 == env21432) = true)

theorem identity21432 : scanCanonicalize (H12AffineFastState.compose env21432 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21432 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21433 : List Nat := [2,4,3,0,0,3,3,6,4,7,2048,2048,2,2048,1,3,2048,2048,6,0,2050,1,1,3,2,3,2049,2048,2049,2048,7,1,7,0,2051,4]

theorem envBound21433 : H12AffineFastState.Bounded env21433 := by
  intro p hp
  have h : env21433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21432_21433 : H12AffineEnvironment.transform 2 3 env21432 = env21433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21432 == env21433) = true)

def env21434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177099,2098512,17664,2461974,2102684,2411676,257,21793,46212,2175563]

theorem envBound21434 : H12AffineFastState.Bounded env21434 := by
  intro p hp
  have h : env21434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21402_21434 : H12AffineEnvironment.transform 21 272513 env21402 = env21434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21402 == env21434) = true)

theorem identity21434 : scanCanonicalize (H12AffineFastState.compose env21434 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21434 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82246,262144,1025,29909,2097152,272513,2101328,95496,8328,64,2177099,2098512,17664,2450882,2102684,2373704,257,21793,16464,2175563]

theorem envBound21435 : H12AffineFastState.Bounded env21435 := by
  intro p hp
  have h : env21435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21434_21435 : H12AffineEnvironment.transform 14 29908 env21434 = env21435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21434 == env21435) = true)

def env21436 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82198,262144,1025,29829,2097152,272513,2101248,95496,8328,16,2177051,2098432,17664,2450834,2102684,2373656,257,21793,16384,2175515]

theorem envBound21436 : H12AffineFastState.Bounded env21436 := by
  intro p hp
  have h : env21436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21435_21436 : H12AffineEnvironment.transform 5 16 env21435 = env21436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21435 == env21436) = true)

theorem identity21436 : scanCanonicalize (H12AffineFastState.compose env21436 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound21436 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21437 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82198,76198,1025,29829,2097152,65831,2101248,95496,8328,16,2177051,2098432,17664,2116660,2102684,2167230,257,21793,16384,2175515]

theorem envBound21437 : H12AffineFastState.Bounded env21437 := by
  intro p hp
  have h : env21437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21436_21437 : H12AffineEnvironment.transform 17 76198 env21436 = env21437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env21436 == env21437) = true)

theorem identity21437 : scanCanonicalize (H12AffineFastState.compose env21437 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound21437 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env21438 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,24980,2340,1025,29829,2097152,8613,2101248,21898,8328,16,2103449,2098432,17664,2116660,2102684,2109756,257,21793,16384,2101913]

theorem envBound21438 : H12AffineFastState.Bounded env21438 := by
  intro p hp
  have h : env21438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21437_21438 : H12AffineEnvironment.transform 15 8322 env21437 = env21438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env21437 == env21438) = true)

theorem identity21438 : scanCanonicalize (H12AffineFastState.compose env21438 (packedSelected [17,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21438 : packedSelected [17,19,26] rootPS < 2^1333 := by decide +kernel

def env21439 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,262,16400,2340,1025,21761,2097152,33,2101248,21898,268,16,2103449,2098432,17664,2116660,2102684,2101432,257,21793,16384,2101913]

theorem envBound21439 : H12AffineFastState.Bounded env21439 := by
  intro p hp
  have h : env21439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21438_21439 : H12AffineEnvironment.transform 12 388 env21438 = env21439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21438 == env21439) = true)

theorem identity21439 : scanCanonicalize (H12AffineFastState.compose env21439 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21439 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env21440 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,136,262,5528,2340,1025,137,2097152,33,2101248,2,268,16,2103449,2098432,4232,2103740,2102684,2101432,257,169,5512,2101913]

theorem envBound21440 : H12AffineFastState.Bounded env21440 := by
  intro p hp
  have h : env21440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21439_21440 : H12AffineEnvironment.transform 13 5512 env21439 = env21440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21439 == env21440) = true)

theorem identity21440 : scanCanonicalize (H12AffineFastState.compose env21440 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4248) := by decide +kernel

theorem selectedBound21440 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21441 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,136,262,5528,2340,1025,137,4248,33,152,2,268,16,2049,5528,4232,2340,1284,32,257,169,5512,513]

theorem envBound21441 : H12AffineFastState.Bounded env21441 := by
  intro p hp
  have h : env21441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21440_21441 : H12AffineEnvironment.transform 20 4248 env21440 = env21441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4248 env21440 == env21441) = true)

theorem identity21441 : scanCanonicalize (H12AffineFastState.compose env21441 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21442 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4112,33,16,2,268,16,2049,5392,4096,2340,1284,32,257,33,5376,513]

theorem envBound21442 : H12AffineFastState.Bounded env21442 := by
  intro p hp
  have h : env21442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21441_21442 : H12AffineEnvironment.transform 6 8 env21441 = env21442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21441 == env21442) = true)

theorem identity21442 : scanCanonicalize (H12AffineFastState.compose env21442 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21443 : List Nat := [2,4,8,16,32,16,8,20,512,1024,2048,4096,24,5140,0,18,5124,2096,1025,1,4112,33,16,2,24,16,2049,5124,4096,2096,1040,32,21,33,5140,513]

theorem envBound21443 : H12AffineFastState.Bounded env21443 := by
  intro p hp
  have h : env21443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21442_21443 : H12AffineEnvironment.transform 7 20 env21442 = env21443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21442 == env21443) = true)

theorem identity21443 : scanCanonicalize (H12AffineFastState.compose env21443 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound21443 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21444 : List Nat := [2,4,8,16,32,16,8,20,512,1024,2048,1556,24,512,0,18,528,2096,1025,1,1540,33,16,2,24,16,2049,528,1556,2096,1040,32,21,33,512,513]

theorem envBound21444 : H12AffineFastState.Bounded env21444 := by
  intro p hp
  have h : env21444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21443_21444 : H12AffineEnvironment.transform 11 1556 env21443 = env21444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env21443 == env21444) = true)

theorem identity21444 : scanCanonicalize (H12AffineFastState.compose env21444 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21444 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21445 : List Nat := [2,4,8,16,32,16,8,20,1,1024,2048,1045,24,1,0,18,17,2096,1025,1,1029,33,16,2,24,16,2049,17,1045,2096,1040,32,21,33,1,0]

theorem envBound21445 : H12AffineFastState.Bounded env21445 := by
  intro p hp
  have h : env21445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21444_21445 : H12AffineEnvironment.transform 8 1 env21444 = env21445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21444 == env21445) = true)

theorem identity21445 : scanCanonicalize (H12AffineFastState.compose env21445 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound21445 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21446 : List Nat := [2,4,8,16,32,16,8,20,1,1024,1060,1045,24,1,0,18,17,1044,1025,1,1029,33,16,2,24,16,1061,17,1045,1044,1040,32,21,33,1,0]

theorem envBound21446 : H12AffineFastState.Bounded env21446 := by
  intro p hp
  have h : env21446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21445_21446 : H12AffineEnvironment.transform 10 1060 env21445 = env21446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env21445 == env21446) = true)

theorem identity21446 : scanCanonicalize (H12AffineFastState.compose env21446 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21446 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21447 : List Nat := [2,4,8,16,32,16,8,20,1,52,16,33,24,1,0,18,17,32,53,1,49,33,16,2,24,16,17,17,33,32,36,32,21,33,1,0]

theorem envBound21447 : H12AffineFastState.Bounded env21447 := by
  intro p hp
  have h : env21447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21446_21447 : H12AffineEnvironment.transform 9 52 env21446 = env21447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21446 == env21447) = true)

theorem identity21447 : scanCanonicalize (H12AffineFastState.compose env21447 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21448 : List Nat := [2,4,8,0,32,0,8,4,1,36,0,33,8,1,0,2,1,32,37,1,33,33,0,2,8,0,1,1,33,32,36,32,5,33,1,0]

theorem envBound21448 : H12AffineFastState.Bounded env21448 := by
  intro p hp
  have h : env21448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21447_21448 : H12AffineEnvironment.transform 3 0 env21447 = env21448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21447 == env21448) = true)

theorem identity21448 : scanCanonicalize (H12AffineFastState.compose env21448 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21448 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21449 : List Nat := [2,4,8,0,1,0,8,4,1,5,0,0,8,1,0,2,1,1,4,1,0,0,0,2,8,0,1,1,0,1,5,1,5,0,1,0]

theorem envBound21449 : H12AffineFastState.Bounded env21449 := by
  intro p hp
  have h : env21449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21448_21449 : H12AffineEnvironment.transform 4 1 env21448 = env21449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21448 == env21449) = true)

def env21450 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,262144,1025,29828,2097152,272513,2101249,95496,8328,17,2177050,2098433,17664,2450835,2102684,2373657,257,21793,16385,2175514]

theorem envBound21450 : H12AffineFastState.Bounded env21450 := by
  intro p hp
  have h : env21450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21435_21450 : H12AffineEnvironment.transform 5 17 env21435 = env21450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21435 == env21450) = true)

theorem identity21450 : scanCanonicalize (H12AffineFastState.compose env21450 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound21450 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21451 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,2477,1025,29828,2097152,8492,2101249,95496,8328,17,2177050,2098433,17664,2190398,2102684,2109876,257,21793,16385,2175514]

theorem envBound21451 : H12AffineFastState.Bounded env21451 := by
  intro p hp
  have h : env21451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21450_21451 : H12AffineEnvironment.transform 17 2477 env21450 = env21451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env21450 == env21451) = true)

theorem identity21451 : scanCanonicalize (H12AffineFastState.compose env21451 (packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77851) := by decide +kernel

theorem selectedBound21451 : packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS < 2^1333 := by decide +kernel

def env21452 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,2477,1025,29828,77851,8492,73754,95496,8328,17,2049,79130,17664,23589,75143,65967,257,21793,16385,513]

theorem envBound21452 : H12AffineFastState.Bounded env21452 := by
  intro p hp
  have h : env21452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21451_21452 : H12AffineEnvironment.transform 20 77851 env21451 = env21452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77851 env21451 == env21452) = true)

theorem identity21452 : scanCanonicalize (H12AffineFastState.compose env21452 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21452 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21453 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,21896,65536,82199,2477,1025,21897,69910,33,65815,87045,389,17,2049,70679,17664,23589,66698,65967,257,21793,16385,513]

theorem envBound21453 : H12AffineFastState.Bounded env21453 := by
  intro p hp
  have h : env21453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21452_21453 : H12AffineEnvironment.transform 12 269 env21452 = env21453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21452 == env21453) = true)

theorem identity21453 : scanCanonicalize (H12AffineFastState.compose env21453 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21453 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env21454 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,21896,398,16537,2477,1025,21897,4248,33,153,21899,389,17,2049,5529,17664,23589,1284,33,257,21793,16385,513]

theorem envBound21454 : H12AffineFastState.Bounded env21454 := by
  intro p hp
  have h : env21454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21453_21454 : H12AffineEnvironment.transform 15 398 env21453 = env21454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21453 == env21454) = true)

theorem identity21454 : scanCanonicalize (H12AffineFastState.compose env21454 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21454 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21455 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,137,398,5528,2477,1025,136,4248,33,153,138,389,17,2049,5529,4097,2340,1284,33,257,32,5376,513]

theorem envBound21455 : H12AffineFastState.Bounded env21455 := by
  intro p hp
  have h : env21455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21454_21455 : H12AffineEnvironment.transform 13 5377 env21454 = env21455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21454 == env21455) = true)

theorem identity21455 : scanCanonicalize (H12AffineFastState.compose env21455 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21455 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21456 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,269,4112,137,398,4233,2477,272,136,4248,33,153,138,389,17,2049,4232,4097,2340,21,33,257,32,4113,513]

theorem envBound21456 : H12AffineFastState.Bounded env21456 := by
  intro p hp
  have h : env21456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21455_21456 : H12AffineEnvironment.transform 9 273 env21455 = env21456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21455 == env21456) = true)

theorem identity21456 : scanCanonicalize (H12AffineFastState.compose env21456 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21456 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21457 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,4096,41,4112,137,170,4233,2185,52,136,4248,33,153,138,161,17,2049,4232,4097,2048,21,33,37,32,4113,513]

theorem envBound21457 : H12AffineFastState.Bounded env21457 := by
  intro p hp
  have h : env21457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21456_21457 : H12AffineEnvironment.transform 7 36 env21456 = env21457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21456 == env21457) = true)

theorem identity21457 : scanCanonicalize (H12AffineFastState.compose env21457 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound21457 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env21458 : List Nat := [2,4,8,16,32,17,128,36,11,53,2048,4096,41,4112,137,170,4233,2185,52,136,4248,33,153,138,161,17,2049,4232,4097,2048,21,33,37,32,4113,10]

theorem envBound21458 : H12AffineFastState.Bounded env21458 := by
  intro p hp
  have h : env21458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21457_21458 : H12AffineEnvironment.transform 8 11 env21457 = env21458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env21457 == env21458) = true)

theorem identity21458 : scanCanonicalize (H12AffineFastState.compose env21458 (packedSelected [0,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound21458 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env21459 : List Nat := [2,4,8,16,32,17,128,36,11,53,2048,1,41,17,137,170,136,2185,52,136,153,33,153,138,161,17,2049,137,0,2048,21,33,37,32,16,10]

theorem envBound21459 : H12AffineFastState.Bounded env21459 := by
  intro p hp
  have h : env21459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21458_21459 : H12AffineEnvironment.transform 11 1 env21458 = env21459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env21458 == env21459) = true)

theorem identity21459 : scanCanonicalize (H12AffineFastState.compose env21459 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound21459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21460 : List Nat := [2,4,8,16,32,17,128,36,11,53,152,1,41,17,137,170,136,17,52,136,153,33,153,138,161,17,153,137,0,152,21,33,37,32,16,10]

theorem envBound21460 : H12AffineFastState.Bounded env21460 := by
  intro p hp
  have h : env21460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21459_21460 : H12AffineEnvironment.transform 10 152 env21459 = env21460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env21459 == env21460) = true)

theorem identity21460 : scanCanonicalize (H12AffineFastState.compose env21460 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21460 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21461 : List Nat := [2,4,2,16,32,17,128,36,1,53,146,1,35,17,131,160,130,17,52,130,147,33,147,128,161,17,147,131,0,146,21,33,37,32,16,0]

theorem envBound21461 : H12AffineFastState.Bounded env21461 := by
  intro p hp
  have h : env21461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21460_21461 : H12AffineEnvironment.transform 2 2 env21460 = env21461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21460 == env21461) = true)

theorem identity21461 : scanCanonicalize (H12AffineFastState.compose env21461 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound21461 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env21462 : List Nat := [2,4,2,16,32,17,3,36,1,53,17,1,35,17,0,35,1,17,52,1,16,33,16,3,34,17,16,0,0,17,21,33,37,32,16,0]

theorem envBound21462 : H12AffineFastState.Bounded env21462 := by
  intro p hp
  have h : env21462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21461_21462 : H12AffineEnvironment.transform 6 3 env21461 = env21462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env21461 == env21462) = true)

theorem identity21462 : scanCanonicalize (H12AffineFastState.compose env21462 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21463 : List Nat := [2,4,2,1,32,0,3,36,1,36,0,1,35,0,0,35,1,0,37,1,1,33,1,3,34,0,1,0,0,0,4,33,37,32,1,0]

theorem envBound21463 : H12AffineFastState.Bounded env21463 := by
  intro p hp
  have h : env21463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21462_21463 : H12AffineEnvironment.transform 3 1 env21462 = env21463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21462 == env21463) = true)

theorem identity21463 : scanCanonicalize (H12AffineFastState.compose env21463 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21463 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21464 : List Nat := [2,4,2,1,1,0,3,5,1,5,0,1,2,0,0,2,1,0,4,1,1,0,1,3,3,0,1,0,0,0,4,0,4,1,1,0]

theorem envBound21464 : H12AffineFastState.Bounded env21464 := by
  intro p hp
  have h : env21464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21463_21464 : H12AffineEnvironment.transform 4 1 env21463 = env21464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21463 == env21464) = true)

def env21465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623434,2098513,17665,2461975,2102684,6349852,257,21793,46212,2175563]

theorem envBound21465 : H12AffineFastState.Bounded env21465 := by
  intro p hp
  have h : env21465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21401_21465 : H12AffineEnvironment.transform 22 2101329 env21401 = env21465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21401 == env21465) = true)

def env21466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177098,2098513,17665,2461975,2102684,2411676,257,21793,46212,2175563]

theorem envBound21466 : H12AffineFastState.Bounded env21466 := by
  intro p hp
  have h : env21466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21465_21466 : H12AffineEnvironment.transform 21 272512 env21465 = env21466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21465 == env21466) = true)

theorem identity21466 : scanCanonicalize (H12AffineFastState.compose env21466 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound21466 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4160,272512,17,98781,8328,64,75786,5393,17665,360791,1500,318684,257,21793,46212,74251]

theorem envBound21467 : H12AffineFastState.Bounded env21467 := by
  intro p hp
  have h : env21467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21466_21467 : H12AffineEnvironment.transform 20 4160 env21466 = env21467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21466 == env21467) = true)

theorem identity21467 : scanCanonicalize (H12AffineFastState.compose env21467 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21467 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,4160,272512,17,41431,8328,64,2048,5393,17665,303453,1500,318684,257,21793,46212,513]

theorem envBound21468 : H12AffineFastState.Bounded env21468 := by
  intro p hp
  have h : env21468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21467_21468 : H12AffineEnvironment.transform 15 8202 env21467 = env21468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21467 == env21468) = true)

theorem identity21468 : scanCanonicalize (H12AffineFastState.compose env21468 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound21468 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env21469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,35325,1025,32769,4160,41341,17,41431,8328,64,2048,5393,17665,10400,1500,21793,257,21793,46212,513]

theorem envBound21469 : H12AffineFastState.Bounded env21469 := by
  intro p hp
  have h : env21469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21468_21469 : H12AffineEnvironment.transform 17 35325 env21468 = env21469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env21468 == env21469) = true)

theorem identity21469 : scanCanonicalize (H12AffineFastState.compose env21469 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21469 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env21470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16401,35325,1025,32769,4160,32800,17,32906,469,64,2048,5393,17665,2557,1500,21793,257,21793,38361,513]

theorem envBound21470 : H12AffineFastState.Bounded env21470 := by
  intro p hp
  have h : env21470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21469_21470 : H12AffineEnvironment.transform 12 349 env21469 = env21470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21469 == env21470) = true)

theorem identity21470 : scanCanonicalize (H12AffineFastState.compose env21470 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21470 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,343,5392,35325,1025,32769,4160,32800,17,32906,469,64,2048,5393,4096,2557,1500,32,257,32,38361,513]

theorem envBound21471 : H12AffineFastState.Bounded env21471 := by
  intro p hp
  have h : env21471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21470_21471 : H12AffineEnvironment.transform 13 5377 env21470 = env21471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21470 == env21471) = true)

theorem identity21471 : scanCanonicalize (H12AffineFastState.compose env21471 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21471 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env21472 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5237,32768,35,5220,34953,1025,32769,4160,32800,17,32906,161,64,2048,5221,4096,2185,1192,32,117,32,38061,513]

theorem envBound21472 : H12AffineFastState.Bounded env21472 := by
  intro p hp
  have h : env21472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21471_21472 : H12AffineEnvironment.transform 7 116 env21471 = env21472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21471 == env21472) = true)

theorem identity21472 : scanCanonicalize (H12AffineFastState.compose env21472 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21472 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21473 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,32768,35,5220,34817,1025,32769,4160,32800,17,32770,41,64,2048,5221,4096,2049,1056,32,117,32,37925,513]

theorem envBound21473 : H12AffineFastState.Bounded env21473 := by
  intro p hp
  have h : env21473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21472_21473 : H12AffineEnvironment.transform 6 8 env21472 = env21473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21472 == env21473) = true)

theorem identity21473 : scanCanonicalize (H12AffineFastState.compose env21473 (packedSelected [3,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound21473 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env21474 : List Nat := [2,4,8,16,32,64,8,116,512,63,2048,4096,41,4170,32768,35,4187,34817,62,32769,4160,32800,17,32770,41,64,2048,4186,4096,2049,31,32,117,32,36890,513]

theorem envBound21474 : H12AffineFastState.Bounded env21474 := by
  intro p hp
  have h : env21474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21473_21474 : H12AffineEnvironment.transform 9 63 env21473 = env21474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env21473 == env21474) = true)

theorem identity21474 : scanCanonicalize (H12AffineFastState.compose env21474 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound21474 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env21475 : List Nat := [2,4,8,16,32,64,8,116,512,63,81,4096,41,4170,32768,35,4187,32848,62,32769,4160,32800,17,32770,41,64,81,4186,4096,80,31,32,117,32,36890,513]

theorem envBound21475 : H12AffineFastState.Bounded env21475 := by
  intro p hp
  have h : env21475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21474_21475 : H12AffineEnvironment.transform 10 81 env21474 = env21475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env21474 == env21475) = true)

theorem identity21475 : scanCanonicalize (H12AffineFastState.compose env21475 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound21475 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env21476 : List Nat := [2,4,8,16,10,64,8,94,512,21,81,4096,3,4170,32768,9,4187,32848,20,32769,4160,32778,17,32770,3,64,81,4186,4096,80,31,10,95,10,36890,513]

theorem envBound21476 : H12AffineFastState.Bounded env21476 := by
  intro p hp
  have h : env21476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21475_21476 : H12AffineEnvironment.transform 4 10 env21475 = env21476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env21475 == env21476) = true)

theorem identity21476 : scanCanonicalize (H12AffineFastState.compose env21476 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21476 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env21477 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,4096,3,4122,32768,9,4107,32768,20,32769,4112,32778,17,32770,3,16,1,4106,4096,0,31,10,15,10,36890,513]

theorem envBound21477 : H12AffineFastState.Bounded env21477 := by
  intro p hp
  have h : env21477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21476_21477 : H12AffineEnvironment.transform 5 16 env21476 = env21477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21476 == env21477) = true)

theorem identity21477 : scanCanonicalize (H12AffineFastState.compose env21477 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 26) := by decide +kernel

theorem selectedBound21477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21478 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,4096,3,4122,26,9,4107,26,20,27,4112,16,17,24,3,16,1,4106,4096,0,31,10,15,10,4096,513]

theorem envBound21478 : H12AffineFastState.Bounded env21478 := by
  intro p hp
  have h : env21478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21477_21478 : H12AffineEnvironment.transform 14 26 env21477 = env21478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26 env21477 == env21478) = true)

theorem identity21478 : scanCanonicalize (H12AffineFastState.compose env21478 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound21478 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21479 : List Nat := [2,4,8,16,10,16,8,14,512,21,1,10,3,16,26,9,1,26,20,27,26,16,17,24,3,16,1,0,10,0,31,10,15,10,10,513]

theorem envBound21479 : H12AffineFastState.Bounded env21479 := by
  intro p hp
  have h : env21479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21478_21479 : H12AffineEnvironment.transform 11 10 env21478 = env21479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env21478 == env21479) = true)

def env21480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177099,2098513,17665,2461975,2102684,2411677,257,21793,46212,2175563]

theorem envBound21480 : H12AffineFastState.Bounded env21480 := by
  intro p hp
  have h : env21480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21465_21480 : H12AffineEnvironment.transform 21 272513 env21465 = env21480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21465 == env21480) = true)

def env21481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272393,2101329,98645,8192,64,2177099,2098513,17665,2461975,2102548,2411541,257,21793,46092,2175563]

theorem envBound21481 : H12AffineFastState.Bounded env21481 := by
  intro p hp
  have h : env21481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21480_21481 : H12AffineEnvironment.transform 6 8 env21480 = env21481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21480 == env21481) = true)

theorem identity21481 : scanCanonicalize (H12AffineFastState.compose env21481 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound21481 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272393,73755,98645,8192,64,2049,79131,17665,303453,75102,392287,257,21793,46092,513]

theorem envBound21482 : H12AffineFastState.Bounded env21482 := by
  intro p hp
  have h : env21482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21481_21482 : H12AffineEnvironment.transform 20 77898 env21481 = env21482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env21481 == env21482) = true)

theorem identity21482 : scanCanonicalize (H12AffineFastState.compose env21482 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound21482 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env21483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1025,32769,77898,73771,73755,98645,8192,64,2049,79131,17665,108927,75102,62589,257,21793,46092,513]

theorem envBound21483 : H12AffineFastState.Bounded env21483 := by
  intro p hp
  have h : env21483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21482_21483 : H12AffineEnvironment.transform 17 67618 env21482 = env21483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env21482 == env21483) = true)

theorem identity21483 : scanCanonicalize (H12AffineFastState.compose env21483 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound21483 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env21484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,82246,67618,1025,8461,77898,73771,73755,73817,8192,64,2049,79131,17665,67699,75102,21873,257,21793,5376,513]

theorem envBound21484 : H12AffineFastState.Bounded env21484 := by
  intro p hp
  have h : env21484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21483_21484 : H12AffineEnvironment.transform 14 8460 env21483 = env21484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env21483 == env21484) = true)

theorem identity21484 : scanCanonicalize (H12AffineFastState.compose env21484 (packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound21484 : packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env21485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,21511,5441,23589,1025,8461,25677,29740,29724,29790,8192,64,2049,24860,17665,23668,29017,21873,257,21793,5376,513]

theorem envBound21485 : H12AffineFastState.Bounded env21485 := by
  intro p hp
  have h : env21485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21484_21485 : H12AffineEnvironment.transform 15 21511 env21484 = env21485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env21484 == env21485) = true)

theorem identity21485 : scanCanonicalize (H12AffineFastState.compose env21485 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21485 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,263,5441,2341,1025,8461,12621,8492,8476,8542,8192,64,2049,13340,4097,2420,9305,113,257,33,5376,513]

theorem envBound21486 : H12AffineFastState.Bounded env21486 := by
  intro p hp
  have h : env21486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21485_21486 : H12AffineEnvironment.transform 13 5376 env21485 = env21486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21485 == env21486) = true)

theorem identity21486 : scanCanonicalize (H12AffineFastState.compose env21486 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21486 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21487 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,263,5393,2341,1025,8461,12573,8492,8476,8462,8192,16,2049,13340,4097,2340,9225,33,257,33,5376,513]

theorem envBound21487 : H12AffineFastState.Bounded env21487 := by
  intro p hp
  have h : env21487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21486_21487 : H12AffineEnvironment.transform 5 16 env21486 = env21487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21486 == env21487) = true)

theorem identity21487 : scanCanonicalize (H12AffineFastState.compose env21487 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound21487 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env21488 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1060,8192,292,8460,263,309,2341,1025,8461,9529,8492,8476,8462,8192,16,2049,8248,1061,2340,9225,33,257,33,292,513]

theorem envBound21488 : H12AffineFastState.Bounded env21488 := by
  intro p hp
  have h : env21488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21487_21488 : H12AffineEnvironment.transform 11 1060 env21487 = env21488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env21487 == env21488) = true)

theorem identity21488 : scanCanonicalize (H12AffineFastState.compose env21488 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound21488 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env21489 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1060,2316,292,2048,263,309,2341,1025,2049,3125,2080,2064,2050,2316,16,2049,2356,1061,2340,3333,33,257,33,292,513]

theorem envBound21489 : H12AffineFastState.Bounded env21489 := by
  intro p hp
  have h : env21489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21488_21489 : H12AffineEnvironment.transform 12 2316 env21488 = env21489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env21488 == env21489) = true)

theorem identity21489 : scanCanonicalize (H12AffineFastState.compose env21489 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21489 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env21490 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1060,268,292,0,263,309,293,1025,1,1077,32,16,2,268,16,1,308,1061,292,1285,33,257,33,292,513]

theorem envBound21490 : H12AffineFastState.Bounded env21490 := by
  intro p hp
  have h : env21490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21489_21490 : H12AffineEnvironment.transform 10 0 env21489 = env21490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21489 == env21490) = true)

theorem identity21490 : scanCanonicalize (H12AffineFastState.compose env21490 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21490 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21491 : List Nat := [2,4,8,16,32,16,8,256,512,52,0,16,268,292,0,263,309,293,53,1,1,32,16,2,268,16,1,308,17,292,305,33,257,33,292,513]

theorem envBound21491 : H12AffineFastState.Bounded env21491 := by
  intro p hp
  have h : env21491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21490_21491 : H12AffineEnvironment.transform 9 52 env21490 = env21491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21490 == env21491) = true)

def env21492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272392,2101329,98644,8193,64,2177099,2098513,17665,2461975,2102549,2411540,257,21793,46093,2175563]

theorem envBound21492 : H12AffineFastState.Bounded env21492 := by
  intro p hp
  have h : env21492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21480_21492 : H12AffineEnvironment.transform 6 9 env21480 = env21492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21480 == env21492) = true)

theorem identity21492 : scanCanonicalize (H12AffineFastState.compose env21492 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21492 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,16401,262144,1025,32769,2097152,272392,2101329,32771,8193,64,2111772,2098513,17665,2396224,2102549,2411540,257,21793,46093,2110236]

theorem envBound21493 : H12AffineFastState.Bounded env21493 := by
  intro p hp
  have h : env21493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21492_21493 : H12AffineEnvironment.transform 15 343 env21492 = env21493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21492 == env21493) = true)

theorem identity21493 : scanCanonicalize (H12AffineFastState.compose env21493 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound21493 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,16401,35189,1025,32769,2097152,41341,2101329,32771,8193,64,2111772,2098513,17665,2103605,2102549,2114913,257,21793,46093,2110236]

theorem envBound21494 : H12AffineFastState.Bounded env21494 := by
  intro p hp
  have h : env21494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21493_21494 : H12AffineEnvironment.transform 17 35189 env21493 = env21494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env21493 == env21494) = true)

theorem identity21494 : scanCanonicalize (H12AffineFastState.compose env21494 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound21494 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env21495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,32768,343,5173,35189,1025,32769,2097152,41341,2101329,32771,8193,64,2111772,2098513,4389,2103605,2102549,2101573,257,261,46093,2110236]

theorem envBound21495 : H12AffineFastState.Bounded env21495 := by
  intro p hp
  have h : env21495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21494_21495 : H12AffineEnvironment.transform 13 5156 env21494 = env21495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env21494 == env21495) = true)

theorem identity21495 : scanCanonicalize (H12AffineFastState.compose env21495 (packedSelected [0,1,7,8,9,12,14,15,16,19,22] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound21495 : packedSelected [0,1,7,8,9,12,14,15,16,19,22] rootPS < 2^1333 := by decide +kernel

def env21496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,32768,343,5173,35189,1025,32769,4161,41341,16,32771,8193,64,10589,5392,4389,2420,1364,260,257,261,46093,9053]

theorem envBound21496 : H12AffineFastState.Bounded env21496 := by
  intro p hp
  have h : env21496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21495_21496 : H12AffineEnvironment.transform 20 4161 env21495 = env21496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21495 == env21496) = true)

theorem identity21496 : scanCanonicalize (H12AffineFastState.compose env21496 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21496 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env21497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8540,343,5173,10281,1025,8541,4161,33,16,8543,8193,64,10589,5392,4389,2420,1364,260,257,261,5457,9053]

theorem envBound21497 : H12AffineFastState.Bounded env21497 := by
  intro p hp
  have h : env21497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21496_21497 : H12AffineEnvironment.transform 14 8540 env21496 = env21497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21496 == env21497) = true)

theorem identity21497 : scanCanonicalize (H12AffineFastState.compose env21497 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21497 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env21498 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8540,343,4389,10281,273,8541,4161,33,16,8543,8193,64,10589,4096,4389,2420,68,260,257,261,4161,9053]

theorem envBound21498 : H12AffineFastState.Bounded env21498 := by
  intro p hp
  have h : env21498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21497_21498 : H12AffineEnvironment.transform 9 272 env21497 = env21498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21497 == env21498) = true)

theorem identity21498 : scanCanonicalize (H12AffineFastState.compose env21498 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound21498 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21499 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,121,4404,293,343,4389,2128,273,292,4161,33,16,294,120,64,2340,4096,4389,2420,68,260,257,261,4161,804]

theorem envBound21499 : H12AffineFastState.Bounded env21499 := by
  intro p hp
  have h : env21499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21498_21499 : H12AffineEnvironment.transform 12 121 env21498 = env21499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env21498 == env21499) = true)

def env21500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623435,8393985,10507600,8749382,2102685,12645452,257,21792,46213,2175562]

theorem envBound21500 : H12AffineFastState.Bounded env21500 := by
  intro p hp
  have h : env21500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21400_21500 : H12AffineEnvironment.transform 23 10588557 env21400 = env21500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env21400 == env21500) = true)

def env21501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623435,2098513,17664,2461974,2102685,6349852,257,21792,46213,2175562]

theorem envBound21501 : H12AffineFastState.Bounded env21501 := by
  intro p hp
  have h : env21501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21500_21501 : H12AffineEnvironment.transform 22 2101328 env21500 = env21501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21500 == env21501) = true)

def env21502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177099,2098513,17664,2461974,2102685,2411676,257,21792,46213,2175562]

theorem envBound21502 : H12AffineFastState.Bounded env21502 := by
  intro p hp
  have h : env21502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21501_21502 : H12AffineEnvironment.transform 21 272512 env21501 = env21502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21501 == env21502) = true)

theorem identity21502 : scanCanonicalize (H12AffineFastState.compose env21502 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,2097152,272512,2101328,41431,8328,64,2103361,2098513,17664,2404636,2102685,2411676,257,21792,46213,2101824]

theorem envBound21503 : H12AffineFastState.Bounded env21503 := by
  intro p hp
  have h : env21503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21502_21503 : H12AffineEnvironment.transform 15 8202 env21502 = env21503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21502 == env21503) = true)

theorem identity21503 : scanCanonicalize (H12AffineFastState.compose env21503 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309473) := by decide +kernel

theorem selectedBound21503 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,262144,1025,32769,309473,272512,305329,41431,8328,64,303264,310704,17664,2557,306556,29821,257,21792,46213,305825]

theorem envBound21504 : H12AffineFastState.Bounded env21504 := by
  intro p hp
  have h : env21504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21503_21504 : H12AffineEnvironment.transform 20 309473 env21503 = env21504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309473 env21503 == env21504) = true)

theorem identity21504 : scanCanonicalize (H12AffineFastState.compose env21504 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

end H12CloudChart1