import H12CloudChart1Data129

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env32988 : List Nat := [2,4,8,16,32,64,9,256,512,273,113,4096,268,4113,81,263,4097,340,272,80,4452,261,17,2,269,65,261,4389,4388,261,69,33,257,260,4452,512]

theorem envBound32988 : H12AffineFastState.Bounded env32988 := by
  intro p hp
  have h : env32988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32987_32988 : H12AffineEnvironment.transform 12 268 env32987 = env32988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32987 == env32988) = true)

theorem identity32988 : scanCanonicalize (H12AffineFastState.compose env32988 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32988 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32989 : List Nat := [2,4,8,16,32,64,9,4,512,21,113,4096,8,4113,81,3,4097,80,20,80,4192,1,17,2,9,65,1,4129,4128,1,69,33,5,0,4192,512]

theorem envBound32989 : H12AffineFastState.Bounded env32989 := by
  intro p hp
  have h : env32989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32988_32989 : H12AffineEnvironment.transform 7 4 env32988 = env32989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32988 == env32989) = true)

theorem identity32989 : scanCanonicalize (H12AffineFastState.compose env32989 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32990 : List Nat := [2,4,8,16,32,48,9,4,512,21,1,4096,8,4113,33,3,4097,32,20,32,4112,1,17,2,9,49,1,4129,4128,1,53,33,5,0,4112,512]

theorem envBound32990 : H12AffineFastState.Bounded env32990 := by
  intro p hp
  have h : env32990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32989_32990 : H12AffineEnvironment.transform 5 48 env32989 = env32990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32989 == env32990) = true)

theorem identity32990 : scanCanonicalize (H12AffineFastState.compose env32990 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound32990 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32991 : List Nat := [2,4,8,16,32,48,9,4,14,21,1,4096,8,4113,33,3,4097,32,20,32,4112,1,17,2,9,49,1,4129,4128,1,53,33,5,0,4112,14]

theorem envBound32991 : H12AffineFastState.Bounded env32991 := by
  intro p hp
  have h : env32991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32990_32991 : H12AffineEnvironment.transform 8 14 env32990 = env32991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env32990 == env32991) = true)

theorem identity32991 : scanCanonicalize (H12AffineFastState.compose env32991 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound32991 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32992 : List Nat := [2,4,8,16,32,48,9,4,14,21,1,17,8,0,33,3,16,32,20,32,1,1,17,2,9,49,1,48,49,1,53,33,5,0,1,14]

theorem envBound32992 : H12AffineFastState.Bounded env32992 := by
  intro p hp
  have h : env32992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32991_32992 : H12AffineEnvironment.transform 11 17 env32991 = env32992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32991 == env32992) = true)

def env32993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound32993 : H12AffineFastState.Bounded env32993 := by
  intro p hp
  have h : env32993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32717_32993 : H12AffineEnvironment.transform 26 30393345 env32717 = env32993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env32717 == env32993) = true)

def env32994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound32994 : H12AffineFastState.Bounded env32994 := by
  intro p hp
  have h : env32994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32993_32994 : H12AffineEnvironment.transform 18 1024 env32993 = env32994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env32993 == env32994) = true)

theorem identity32994 : scanCanonicalize (H12AffineFastState.compose env32994 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396461) := by decide +kernel

theorem selectedBound32994 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,16777216,8328,65,29868033,17270817,8804860,8830977,25265169,21457260,256,25675777,25635236,25207750]

theorem envBound32995 : H12AffineFastState.Bounded env32995 := by
  intro p hp
  have h : env32995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32994_32995 : H12AffineEnvironment.transform 20 396461 env32994 = env32995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396461 env32994 == env32995) = true)

def env32996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,8887584,8328,65,4218145,8393985,8804860,8830977,399665,12645452,256,21793,46212,474854]

theorem envBound32996 : H12AffineFastState.Bounded env32996 := by
  intro p hp
  have h : env32996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32995_32996 : H12AffineEnvironment.transform 23 8887584 env32995 = env32996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887584 env32995 == env32996) = true)

def env32997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452648,95496,8328,65,4218145,458025,45524,10281,399665,4594788,256,21793,46212,474854]

theorem envBound32997 : H12AffineFastState.Bounded env32997 := by
  intro p hp
  have h : env32997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32996_32997 : H12AffineEnvironment.transform 22 452648 env32996 = env32997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env32996 == env32997) = true)

def env32998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452648,95496,8328,65,292257,458025,45524,10281,399665,144612,256,21793,46212,474854]

theorem envBound32998 : H12AffineFastState.Bounded env32998 := by
  intro p hp
  have h : env32998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32997_32998 : H12AffineEnvironment.transform 21 272512 env32997 = env32998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32997 == env32998) = true)

theorem identity32998 : scanCanonicalize (H12AffineFastState.compose env32998 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound32998 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,396461,272512,452648,41431,8328,65,292257,458025,45524,10281,399665,144612,256,21793,46212,453177]

theorem envBound32999 : H12AffineFastState.Bounded env32999 := by
  intro p hp
  have h : env32999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32998_32999 : H12AffineEnvironment.transform 15 54495 env32998 = env32999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env32998 == env32999) = true)

def env33000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,396461,272512,452648,41351,8328,17,292257,458025,45444,10281,399665,144564,256,21793,46212,453177]

theorem envBound33000 : H12AffineFastState.Bounded env33000 := by
  intro p hp
  have h : env33000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32999_33000 : H12AffineEnvironment.transform 5 16 env32999 = env33000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32999 == env33000) = true)

theorem identity33000 : scanCanonicalize (H12AffineFastState.compose env33000 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound33000 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env33001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,35245,1024,32769,165120,41261,156037,41351,8328,17,64524,160900,45444,10281,168092,144564,256,21793,46212,156564]

theorem envBound33001 : H12AffineFastState.Bounded env33001 := by
  intro p hp
  have h : env33001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33000_33001 : H12AffineEnvironment.transform 17 35245 env33000 = env33001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env33000 == env33001) = true)

theorem identity33001 : scanCanonicalize (H12AffineFastState.compose env33001 (packedSelected [0,1,4,5,7,8,10,16,17,18,20,22,23,24,31] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound33001 : packedSelected [0,1,4,5,7,8,10,16,17,18,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env33002 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,262,131072,23588,1024,21896,151689,29860,156037,29710,8328,17,10629,160900,25613,10281,148757,144564,256,21793,24845,156564]

theorem envBound33002 : H12AffineFastState.Bounded env33002 := by
  intro p hp
  have h : env33002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33001_33002 : H12AffineEnvironment.transform 14 21897 env33001 = env33002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env33001 == env33002) = true)

theorem identity33002 : scanCanonicalize (H12AffineFastState.compose env33002 (packedSelected [0,1,4,5,7,8,17,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33002 : packedSelected [0,1,4,5,7,8,17,22,24] rootPS < 2^1333 := by decide +kernel

def env33003 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21897,262,131072,23588,1024,21896,151689,21793,147456,21899,269,17,2048,152833,17800,2476,148757,136497,256,21793,16520,147985]

theorem envBound33003 : H12AffineFastState.Bounded env33003 := by
  intro p hp
  have h : env33003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33002_33003 : H12AffineEnvironment.transform 12 389 env33002 = env33003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33002 == env33003) = true)

theorem identity33003 : scanCanonicalize (H12AffineFastState.compose env33003 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33003 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33004 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21761,262,131072,23588,1024,21760,151553,21793,147456,21763,269,17,2048,152833,17664,2340,148757,136497,256,21793,16384,147985]

theorem envBound33004 : H12AffineFastState.Bounded env33004 := by
  intro p hp
  have h : env33004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33003_33004 : H12AffineEnvironment.transform 6 8 env33003 = env33004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33003 == env33004) = true)

theorem identity33004 : scanCanonicalize (H12AffineFastState.compose env33004 (packedSelected [0,2,3,5,6,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound33004 : packedSelected [0,2,3,5,6,9,10,12] rootPS < 2^1333 := by decide +kernel

def env33005 : List Nat := [2,4,8,16,32,16,8,256,512,533,2048,4096,269,16384,21268,262,131072,23089,533,21269,151553,21300,147456,21270,269,17,2048,152340,17173,2340,148224,135972,256,21300,16384,147985]

theorem envBound33005 : H12AffineFastState.Bounded env33005 := by
  intro p hp
  have h : env33005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33004_33005 : H12AffineEnvironment.transform 9 533 env33004 = env33005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env33004 == env33005) = true)

theorem identity33005 : scanCanonicalize (H12AffineFastState.compose env33005 (packedSelected [0,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 6154) := by decide +kernel

theorem selectedBound33005 : packedSelected [0,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33006 : List Nat := [2,4,8,16,32,16,8,256,512,533,2048,4096,269,16384,21268,262,6154,23089,533,21269,18443,21300,22538,21270,269,17,2048,19230,17173,2340,23306,2862,256,21300,16384,23067]

theorem envBound33006 : H12AffineFastState.Bounded env33006 := by
  intro p hp
  have h : env33006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33005_33006 : H12AffineEnvironment.transform 16 6154 env33005 = env33006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6154 env33005 == env33006) = true)

theorem identity33006 : scanCanonicalize (H12AffineFastState.compose env33006 (packedSelected [0,2,4,6,14,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound33006 : packedSelected [0,2,4,6,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33007 : List Nat := [2,4,8,16,32,16,8,256,512,533,782,4096,269,16384,21268,262,4868,20799,533,21269,17157,21300,21252,21270,269,17,782,16400,17173,554,20484,32,256,21300,16384,20757]

theorem envBound33007 : H12AffineFastState.Bounded env33007 := by
  intro p hp
  have h : env33007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33006_33007 : H12AffineEnvironment.transform 10 782 env33006 = env33007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env33006 == env33007) = true)

theorem identity33007 : scanCanonicalize (H12AffineFastState.compose env33007 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound33007 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env33008 : List Nat := [2,4,8,16,32,16,8,256,512,533,782,538,269,16384,16654,262,286,17189,533,16655,17157,16686,16670,16652,269,17,782,16400,17173,554,16926,32,256,16686,16384,17167]

theorem envBound33008 : H12AffineFastState.Bounded env33008 := by
  intro p hp
  have h : env33008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33007_33008 : H12AffineEnvironment.transform 11 538 env33007 = env33008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env33007 == env33008) = true)

def env33009 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,396461,272512,452648,41350,8328,16,292257,458025,45445,10281,399665,144565,256,21793,46212,453177]

theorem envBound33009 : H12AffineFastState.Bounded env33009 := by
  intro p hp
  have h : env33009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32999_33009 : H12AffineEnvironment.transform 5 17 env32999 = env33009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32999 == env33009) = true)

theorem identity33009 : scanCanonicalize (H12AffineFastState.compose env33009 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound33009 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env33010 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,49305,262144,1024,32769,314420,272512,272561,41350,8328,16,292257,277936,45445,10281,317864,62508,256,21793,46212,273056]

theorem envBound33010 : H12AffineFastState.Bounded env33010 := by
  intro p hp
  have h : env33010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33009_33010 : H12AffineEnvironment.transform 16 49305 env33009 = env33010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env33009 == env33010) = true)

theorem identity33010 : scanCanonicalize (H12AffineFastState.compose env33010 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 15776) := by decide +kernel

theorem selectedBound33010 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env33011 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,15776,26926,32057,262144,1024,15777,291220,272512,272561,7206,8328,16,292257,277936,3109,10281,287752,18828,256,21793,2340,273056]

theorem envBound33011 : H12AffineFastState.Bounded env33011 := by
  intro p hp
  have h : env33011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33010_33011 : H12AffineEnvironment.transform 14 15776 env33010 = env33011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15776 env33010 == env33011) = true)

theorem identity33011 : scanCanonicalize (H12AffineFastState.compose env33011 (packedSelected [0,1,3,4,5,7,8,9,11,14,17,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound33011 : packedSelected [0,1,3,4,5,7,8,9,11,14,17,19,26] rootPS < 2^1333 := by decide +kernel

def env33012 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3384,16384,4248,17430,20481,262144,1024,4249,285868,263608,263561,7206,3504,16,284825,266376,3109,1297,280880,18828,256,21793,2340,264088]

theorem envBound33012 : H12AffineFastState.Bounded env33012 := by
  intro p hp
  have h : env33012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33011_33012 : H12AffineEnvironment.transform 12 3384 env33011 = env33012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env33011 == env33012) = true)

theorem identity33012 : scanCanonicalize (H12AffineFastState.compose env33012 (packedSelected [2,5,6,7,9,16,17,18,19,22,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 4113) := by decide +kernel

theorem selectedBound33012 : packedSelected [2,5,6,7,9,16,17,18,19,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env33013 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3384,16384,4248,17430,20481,4113,1024,4249,19645,5545,5528,7206,3504,16,18568,153,3109,1297,22817,18828,256,21793,2340,6025]

theorem envBound33013 : H12AffineFastState.Bounded env33013 := by
  intro p hp
  have h : env33013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33012_33013 : H12AffineEnvironment.transform 17 4113 env33012 = env33013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4113 env33012 == env33013) = true)

theorem identity33013 : scanCanonicalize (H12AffineFastState.compose env33013 (packedSelected [1,2,3,4,5,6,8,10,12,14,15,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33013 : packedSelected [1,2,3,4,5,6,8,10,12,14,15,17,19,22] rootPS < 2^1333 := by decide +kernel

def env33014 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,2088,16384,4248,16646,20481,4113,272,4249,18861,4281,4232,6454,2208,16,18568,153,2357,1,22817,18828,256,20529,2340,4761]

theorem envBound33014 : H12AffineFastState.Bounded env33014 := by
  intro p hp
  have h : env33014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33013_33014 : H12AffineEnvironment.transform 9 272 env33013 = env33014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33013 == env33014) = true)

theorem identity33014 : scanCanonicalize (H12AffineFastState.compose env33014 (packedSelected [1,2,4,6,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33014 : packedSelected [1,2,4,6,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env33015 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,4096,2088,16384,4248,16555,20481,4113,189,4249,18432,4281,4232,6299,2208,16,18568,153,2200,1,22668,18465,173,20529,2185,4761]

theorem envBound33015 : H12AffineFastState.Bounded env33015 := by
  intro p hp
  have h : env33015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33014_33015 : H12AffineEnvironment.transform 7 173 env33014 = env33015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33014 == env33015) = true)

theorem identity33015 : scanCanonicalize (H12AffineFastState.compose env33015 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33015 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33016 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,4096,40,16384,4248,16555,20481,4113,189,4249,16384,4281,4232,4251,160,16,16520,153,152,1,20620,16417,173,20529,137,4761]

theorem envBound33016 : H12AffineFastState.Bounded env33016 := by
  intro p hp
  have h : env33016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33015_33016 : H12AffineEnvironment.transform 10 0 env33015 = env33016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33015 == env33016) = true)

theorem identity33016 : scanCanonicalize (H12AffineFastState.compose env33016 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound33016 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env33017 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,4096,40,0,4248,171,4097,4113,189,4249,0,4281,4232,4251,160,16,136,153,152,1,4236,33,173,4145,137,4761]

theorem envBound33017 : H12AffineFastState.Bounded env33017 := by
  intro p hp
  have h : env33017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33016_33017 : H12AffineEnvironment.transform 13 0 env33016 = env33017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env33016 == env33017) = true)

theorem identity33017 : scanCanonicalize (H12AffineFastState.compose env33017 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound33017 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env33018 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,136,40,0,16,171,137,153,189,17,0,49,0,19,160,16,136,153,152,1,4,33,173,185,137,529]

theorem envBound33018 : H12AffineFastState.Bounded env33018 := by
  intro p hp
  have h : env33018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33017_33018 : H12AffineEnvironment.transform 11 136 env33017 = env33018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env33017 == env33018) = true)

theorem identity33018 : scanCanonicalize (H12AffineFastState.compose env33018 (packedSelected [0,1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33018 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env33019 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,1,40,0,16,34,0,16,52,17,0,49,0,19,41,16,1,16,17,1,4,33,36,48,0,529]

theorem envBound33019 : H12AffineFastState.Bounded env33019 := by
  intro p hp
  have h : env33019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33018_33019 : H12AffineEnvironment.transform 6 9 env33018 = env33019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33018 == env33019) = true)

theorem identity33019 : scanCanonicalize (H12AffineFastState.compose env33019 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33019 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33020 : List Nat := [2,4,8,1,32,0,9,36,512,37,0,1,40,0,1,34,0,1,37,0,0,32,0,2,41,1,1,1,0,1,4,33,36,33,0,512]

theorem envBound33020 : H12AffineFastState.Bounded env33020 := by
  intro p hp
  have h : env33020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33019_33020 : H12AffineEnvironment.transform 3 1 env33019 = env33020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33019 == env33020) = true)

theorem identity33020 : scanCanonicalize (H12AffineFastState.compose env33020 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound33020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33021 : List Nat := [2,4,8,1,32,0,9,36,33,37,0,1,40,0,1,34,0,1,37,0,0,32,0,2,41,1,1,1,0,1,4,33,36,33,0,33]

theorem envBound33021 : H12AffineFastState.Bounded env33021 := by
  intro p hp
  have h : env33021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33020_33021 : H12AffineEnvironment.transform 8 33 env33020 = env33021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env33020 == env33021) = true)

theorem identity33021 : scanCanonicalize (H12AffineFastState.compose env33021 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33022 : List Nat := [2,0,8,1,32,0,9,32,33,33,0,1,40,0,1,34,0,1,33,0,0,32,0,2,41,1,1,1,0,1,0,33,32,33,0,33]

theorem envBound33022 : H12AffineFastState.Bounded env33022 := by
  intro p hp
  have h : env33022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33021_33022 : H12AffineEnvironment.transform 1 0 env33021 = env33022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33021 == env33022) = true)

theorem identity33022 : scanCanonicalize (H12AffineFastState.compose env33022 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33022 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33023 : List Nat := [2,0,8,1,0,0,9,0,1,1,0,1,8,0,1,2,0,1,1,0,0,0,0,2,9,1,1,1,0,1,0,1,0,1,0,1]

theorem envBound33023 : H12AffineFastState.Bounded env33023 := by
  intro p hp
  have h : env33023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33022_33023 : H12AffineEnvironment.transform 4 0 env33022 = env33023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33022 == env33023) = true)

def env33024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452648,95496,8328,65,292256,458025,45524,10281,399665,144613,256,21793,46212,474854]

theorem envBound33024 : H12AffineFastState.Bounded env33024 := by
  intro p hp
  have h : env33024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32997_33024 : H12AffineEnvironment.transform 21 272513 env32997 = env33024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32997 == env33024) = true)

theorem identity33024 : scanCanonicalize (H12AffineFastState.compose env33024 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212199) := by decide +kernel

theorem selectedBound33024 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212199,1024,32769,77898,201830,120015,95496,8328,65,215367,115150,45524,10281,75222,144613,256,21793,46212,513]

theorem envBound33025 : H12AffineFastState.Bounded env33025 := by
  intro p hp
  have h : env33025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33024_33025 : H12AffineEnvironment.transform 17 212199 env33024 = env33025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212199 env33024 == env33025) = true)

def env33026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,77898,201830,119879,95496,8192,65,215367,115014,45404,10281,75102,144493,256,21793,46092,513]

theorem envBound33026 : H12AffineFastState.Bounded env33026 := by
  intro p hp
  have h : env33026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33025_33026 : H12AffineEnvironment.transform 6 8 env33025 = env33026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33025 == env33026) = true)

theorem identity33026 : scanCanonicalize (H12AffineFastState.compose env33026 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound33026 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10280,1024,32769,77898,33,119879,95496,8192,65,23808,115014,45404,10281,75102,73770,256,21793,46092,513]

theorem envBound33027 : H12AffineFastState.Bounded env33027 := by
  intro p hp
  have h : env33027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33026_33027 : H12AffineEnvironment.transform 16 70727 env33026 = env33027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env33026 == env33027) = true)

theorem identity33027 : scanCanonicalize (H12AffineFastState.compose env33027 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound33027 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env33028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,57676,10280,1024,32769,50497,33,8524,32771,8192,65,23808,13389,45404,10281,53333,54561,256,21793,46092,513]

theorem envBound33028 : H12AffineFastState.Bounded env33028 := by
  intro p hp
  have h : env33028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33027_33028 : H12AffineEnvironment.transform 15 62731 env33027 = env33028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env33027 == env33028) = true)

theorem identity33028 : scanCanonicalize (H12AffineFastState.compose env33028 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33028 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env33029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54278,49217,2341,1024,32769,50497,33,65,32771,269,65,23808,5440,36945,2340,53333,54561,256,21793,38145,513]

theorem envBound33029 : H12AffineFastState.Bounded env33029 := by
  intro p hp
  have h : env33029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33028_33029 : H12AffineEnvironment.transform 12 269 env33028 = env33029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33028 == env33029) = true)

theorem identity33029 : scanCanonicalize (H12AffineFastState.compose env33029 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33029 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env33030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33030,38209,2341,1024,32769,36929,33,65,32771,269,65,2048,5440,36945,2340,34133,32801,256,33,38145,513]

theorem envBound33030 : H12AffineFastState.Bounded env33030 := by
  intro p hp
  have h : env33030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33029_33030 : H12AffineEnvironment.transform 13 5376 env33029 = env33030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33029 == env33030) = true)

def env33031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201830,119878,95496,8193,65,215367,115015,45405,10281,75103,144492,256,21793,46093,513]

theorem envBound33031 : H12AffineFastState.Bounded env33031 := by
  intro p hp
  have h : env33031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33025_33031 : H12AffineEnvironment.transform 6 9 env33025 = env33031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33025 == env33031) = true)

theorem identity33031 : scanCanonicalize (H12AffineFastState.compose env33031 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33031 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env33032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,23668,1024,32769,77898,29820,119878,95496,8193,65,10589,115015,45405,10281,75103,87158,256,21793,46093,513]

theorem envBound33032 : H12AffineFastState.Bounded env33032 := by
  intro p hp
  have h : env33032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33031_33032 : H12AffineEnvironment.transform 16 90138 env33031 = env33032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33031 == env33032) = true)

theorem identity33032 : scanCanonicalize (H12AffineFastState.compose env33032 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound33032 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env33033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41051,49217,23668,1024,32769,36881,29820,29725,54611,8193,65,10589,24860,45405,10281,34052,62509,256,21793,46093,513]

theorem envBound33033 : H12AffineFastState.Bounded env33033 := by
  intro p hp
  have h : env33033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33032_33033 : H12AffineEnvironment.transform 15 41051 env33032 = env33033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env33032 == env33033) = true)

theorem identity33033 : scanCanonicalize (H12AffineFastState.compose env33033 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound33033 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env33034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1125,9278,17444,23668,1024,1124,5236,29820,29725,20790,8193,65,10589,24860,13624,10281,353,28744,256,21793,12392,513]

theorem envBound33034 : H12AffineFastState.Bounded env33034 := by
  intro p hp
  have h : env33034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33033_33034 : H12AffineEnvironment.transform 14 1125 env33033 = env33034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env33033 == env33034) = true)

theorem identity33034 : scanCanonicalize (H12AffineFastState.compose env33034 (packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound33034 : packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env33035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,1125,9278,13340,11340,1024,1124,5236,1092,1061,8462,8193,65,10589,4388,13624,10281,353,112,256,9497,12392,513]

theorem envBound33035 : H12AffineFastState.Bounded env33035 := by
  intro p hp
  have h : env33035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33034_33035 : H12AffineEnvironment.transform 13 12344 env33034 = env33035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env33034 == env33035) = true)

theorem identity33035 : scanCanonicalize (H12AffineFastState.compose env33035 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound33035 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env33036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,5157,1125,35,4097,2129,1024,1124,5236,1092,1061,1299,1052,65,3392,4388,4389,3124,353,112,256,260,5237,513]

theorem envBound33036 : H12AffineFastState.Bounded env33036 := by
  intro p hp
  have h : env33036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33035_33036 : H12AffineEnvironment.transform 12 1053 env33035 = env33036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env33035 == env33036) = true)

theorem identity33036 : scanCanonicalize (H12AffineFastState.compose env33036 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33036 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env33037 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1053,5157,1125,35,4097,2129,1024,1124,5236,1092,1061,1126,1052,65,3125,4177,4176,3124,20,112,117,113,5237,513]

theorem envBound33037 : H12AffineFastState.Bounded env33037 := by
  intro p hp
  have h : env33037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33036_33037 : H12AffineEnvironment.transform 7 117 env33036 = env33037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33036 == env33037) = true)

theorem identity33037 : scanCanonicalize (H12AffineFastState.compose env33037 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33037 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33038 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,121,4161,1,35,4097,2129,100,0,4112,32,65,2,120,65,2129,4177,4176,2128,20,112,117,113,4113,513]

theorem envBound33038 : H12AffineFastState.Bounded env33038 := by
  intro p hp
  have h : env33038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33037_33038 : H12AffineEnvironment.transform 9 100 env33037 = env33038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33037 == env33038) = true)

theorem identity33038 : scanCanonicalize (H12AffineFastState.compose env33038 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33038 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33039 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4112,1,35,4097,2048,53,0,4112,32,16,2,41,16,2048,4096,4097,2049,20,33,36,32,4113,513]

theorem envBound33039 : H12AffineFastState.Bounded env33039 := by
  intro p hp
  have h : env33039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33038_33039 : H12AffineEnvironment.transform 5 17 env33038 = env33039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33038 == env33039) = true)

theorem identity33039 : scanCanonicalize (H12AffineFastState.compose env33039 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33040 : List Nat := [2,4,8,16,32,17,9,36,1,53,2048,4096,40,4112,1,35,4097,2048,53,0,4112,32,16,2,41,16,2048,4096,4097,2049,20,33,36,32,4113,0]

theorem envBound33040 : H12AffineFastState.Bounded env33040 := by
  intro p hp
  have h : env33040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33039_33040 : H12AffineEnvironment.transform 8 1 env33039 = env33040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33039 == env33040) = true)

theorem identity33040 : scanCanonicalize (H12AffineFastState.compose env33040 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound33040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33041 : List Nat := [2,4,8,16,32,17,9,36,1,53,2048,2090,40,2106,1,35,2091,2048,53,0,2106,32,16,2,41,16,2048,2090,2091,2049,20,33,36,32,2107,0]

theorem envBound33041 : H12AffineFastState.Bounded env33041 := by
  intro p hp
  have h : env33041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33040_33041 : H12AffineEnvironment.transform 11 2090 env33040 = env33041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env33040 == env33041) = true)

theorem identity33041 : scanCanonicalize (H12AffineFastState.compose env33041 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound33041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33042 : List Nat := [2,4,8,16,32,17,9,36,1,53,43,1,40,17,1,35,0,43,53,0,17,32,16,2,41,16,43,1,0,42,20,33,36,32,16,0]

theorem envBound33042 : H12AffineFastState.Bounded env33042 := by
  intro p hp
  have h : env33042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33041_33042 : H12AffineEnvironment.transform 10 43 env33041 = env33042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env33041 == env33042) = true)

theorem identity33042 : scanCanonicalize (H12AffineFastState.compose env33042 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33042 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33043 : List Nat := [2,4,8,1,32,0,9,36,1,36,43,1,40,0,1,35,0,43,36,0,0,32,1,2,41,1,43,1,0,42,5,33,36,32,1,0]

theorem envBound33043 : H12AffineFastState.Bounded env33043 := by
  intro p hp
  have h : env33043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33042_33043 : H12AffineEnvironment.transform 3 1 env33042 = env33043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33042 == env33043) = true)

theorem identity33043 : scanCanonicalize (H12AffineFastState.compose env33043 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33043 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33044 : List Nat := [2,4,8,1,11,0,9,15,1,15,0,1,3,0,1,8,0,0,15,0,0,11,1,2,2,1,0,1,0,1,5,10,15,11,1,0]

theorem envBound33044 : H12AffineFastState.Bounded env33044 := by
  intro p hp
  have h : env33044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33043_33044 : H12AffineEnvironment.transform 4 11 env33043 = env33044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33043 == env33044) = true)

def env33045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452649,95497,8328,65,4218145,458024,45525,10280,399665,4594789,256,21793,46212,474854]

theorem envBound33045 : H12AffineFastState.Bounded env33045 := by
  intro p hp
  have h : env33045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32996_33045 : H12AffineEnvironment.transform 22 452649 env32996 = env33045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env32996 == env33045) = true)

def env33046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452649,95497,8328,65,292257,458024,45525,10280,399665,144613,256,21793,46212,474854]

theorem envBound33046 : H12AffineFastState.Bounded env33046 := by
  intro p hp
  have h : env33046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33045_33046 : H12AffineEnvironment.transform 21 272512 env33045 = env33046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33045 == env33046) = true)

theorem identity33046 : scanCanonicalize (H12AffineFastState.compose env33046 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33046 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396461,272512,452649,21763,8328,65,292257,458024,45525,10280,399665,144613,256,21793,46212,401132]

theorem envBound33047 : H12AffineFastState.Bounded env33047 := by
  intro p hp
  have h : env33047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33046_33047 : H12AffineEnvironment.transform 15 8202 env33046 = env33047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33046 == env33047) = true)

def env33048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396325,272392,452649,21763,8192,65,292137,458024,45405,10280,399665,144493,256,21793,46092,400996]

theorem envBound33048 : H12AffineFastState.Bounded env33048 := by
  intro p hp
  have h : env33048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33047_33048 : H12AffineEnvironment.transform 6 8 env33047 = env33048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33047 == env33048) = true)

theorem identity33048 : scanCanonicalize (H12AffineFastState.compose env33048 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound33048 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,23668,1024,32769,151633,29820,177245,21763,8192,65,10589,172380,45405,10280,148805,144493,256,21793,46092,147984]

theorem envBound33049 : H12AffineFastState.Bounded env33049 := by
  intro p hp
  have h : env33049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33048_33049 : H12AffineEnvironment.transform 17 23668 env33048 = env33049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env33048 == env33049) = true)

theorem identity33049 : scanCanonicalize (H12AffineFastState.compose env33049 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound33049 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env33050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,131072,23668,1024,21760,151633,29820,155996,21763,8192,65,10589,160861,25692,10280,148805,144493,256,21793,24845,147984]

theorem envBound33050 : H12AffineFastState.Bounded env33050 := by
  intro p hp
  have h : env33050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33049_33050 : H12AffineEnvironment.transform 14 21761 env33049 = env33050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env33049 == env33050) = true)

theorem identity33050 : scanCanonicalize (H12AffineFastState.compose env33050 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound33050 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env33051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,24909,23668,1024,21760,12572,29820,17,21763,8192,65,10589,5392,25692,10280,9224,21792,256,21793,24845,9053]

theorem envBound33051 : H12AffineFastState.Bounded env33051 := by
  intro p hp
  have h : env33051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33050_33051 : H12AffineEnvironment.transform 16 24909 env33050 = env33051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env33050 == env33051) = true)

theorem identity33051 : scanCanonicalize (H12AffineFastState.compose env33051 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 9751) := by decide +kernel

theorem selectedBound33051 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9751,13078,8202,1882,14947,1024,13079,12572,4715,17,13076,8192,65,10589,5392,587,10280,9224,13111,256,13110,1818,9053]

theorem envBound33052 : H12AffineFastState.Bounded env33052 := by
  intro p hp
  have h : env33052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33051_33052 : H12AffineEnvironment.transform 13 9751 env33051 = env33052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9751 env33051 == env33052) = true)

def env33053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396324,272393,452649,21763,8193,65,292136,458024,45404,10280,399665,144492,256,21793,46093,400997]

theorem envBound33053 : H12AffineFastState.Bounded env33053 := by
  intro p hp
  have h : env33053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33047_33053 : H12AffineEnvironment.transform 6 9 env33047 = env33053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33047 == env33053) = true)

theorem identity33053 : scanCanonicalize (H12AffineFastState.compose env33053 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 182337) := by decide +kernel

theorem selectedBound33053 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182337,1024,32769,50277,188488,8296,21763,8193,65,179561,13673,45404,10280,53616,144492,256,21793,46093,54820]

theorem envBound33054 : H12AffineFastState.Bounded env33054 := by
  intro p hp
  have h : env33054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33053_33054 : H12AffineEnvironment.transform 17 182337 env33053 = env33054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182337 env33053 == env33054) = true)

theorem identity33054 : scanCanonicalize (H12AffineFastState.compose env33054 (packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound33054 : packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env33055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,8202,131072,149521,1024,81,17461,155672,8296,21763,8193,65,146745,13673,12556,10280,20768,144492,256,21793,13405,22132]

theorem envBound33055 : H12AffineFastState.Bounded env33055 := by
  intro p hp
  have h : env33055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33054_33055 : H12AffineEnvironment.transform 14 80 env33054 = env33055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env33054 == env33055) = true)

theorem identity33055 : scanCanonicalize (H12AffineFastState.compose env33055 (packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound33055 : packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env33056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,80,8202,131072,146793,1024,81,12621,136544,8296,8315,8193,65,146745,13673,12556,10280,9304,144492,256,8281,13405,8972]

theorem envBound33056 : H12AffineFastState.Bounded env33056 := by
  intro p hp
  have h : env33056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33055_33056 : H12AffineEnvironment.transform 13 13688 env33055 = env33056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env33055 == env33056) = true)

theorem identity33056 : scanCanonicalize (H12AffineFastState.compose env33056 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound33056 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,80,8202,5172,10589,1024,81,12621,340,8296,8315,8193,65,10509,13673,12556,10280,9304,8280,256,8281,13405,8972]

theorem envBound33057 : H12AffineFastState.Bounded env33057 := by
  intro p hp
  have h : env33057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33056_33057 : H12AffineEnvironment.transform 16 5172 env33056 = env33057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env33056 == env33057) = true)

theorem identity33057 : scanCanonicalize (H12AffineFastState.compose env33057 (packedSelected [0,1,2,3,4,5,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound33057 : packedSelected [0,1,2,3,4,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,2049,80,7539,5172,5156,1024,81,3124,340,7441,7426,7544,65,5236,2064,3189,5457,6433,7457,256,7456,2340,7797]

theorem envBound33058 : H12AffineFastState.Bounded env33058 := by
  intro p hp
  have h : env33058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33057_33058 : H12AffineEnvironment.transform 12 7545 env33057 = env33058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env33057 == env33058) = true)

theorem identity33058 : scanCanonicalize (H12AffineFastState.compose env33058 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33058 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env33059 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,7465,2049,0,7459,5172,5156,1024,1,3124,260,7441,7426,7464,17,5156,2064,3109,5377,6433,7457,256,7456,2340,7717]

theorem envBound33059 : H12AffineFastState.Bounded env33059 := by
  intro p hp
  have h : env33059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33058_33059 : H12AffineEnvironment.transform 5 16 env33058 = env33059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33058 == env33059) = true)

theorem identity33059 : scanCanonicalize (H12AffineFastState.compose env33059 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33059 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env33060 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,6201,2049,0,6195,4388,4404,272,1,2340,260,6145,6162,6200,17,4404,2064,2357,4113,6433,6193,256,6192,2340,6965]

theorem envBound33060 : H12AffineFastState.Bounded env33060 := by
  intro p hp
  have h : env33060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33059_33060 : H12AffineEnvironment.transform 9 272 env33059 = env33060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33059 == env33060) = true)

theorem identity33060 : scanCanonicalize (H12AffineFastState.compose env33060 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33060 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env33061 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,6201,2049,0,6195,4096,4112,52,1,2048,32,6145,6162,6200,17,4112,2064,2065,4113,6149,6193,36,6192,2048,6673]

theorem envBound33061 : H12AffineFastState.Bounded env33061 := by
  intro p hp
  have h : env33061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33060_33061 : H12AffineEnvironment.transform 7 36 env33060 = env33061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33060 == env33061) = true)

theorem identity33061 : scanCanonicalize (H12AffineFastState.compose env33061 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound33061 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33062 : List Nat := [2,4,8,16,32,16,9,36,36,52,2048,4096,6201,2049,0,6195,4096,4112,52,1,2048,32,6145,6162,6200,17,4112,2064,2065,4113,6149,6193,36,6192,2048,6197]

theorem envBound33062 : H12AffineFastState.Bounded env33062 := by
  intro p hp
  have h : env33062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33061_33062 : H12AffineEnvironment.transform 8 36 env33061 = env33062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env33061 == env33062) = true)

theorem identity33062 : scanCanonicalize (H12AffineFastState.compose env33062 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound33062 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33063 : List Nat := [2,4,8,16,32,16,9,36,36,52,2048,48,2057,2049,0,2051,48,32,52,1,2048,32,2097,2082,2056,17,32,2064,2065,33,2101,2049,36,2048,2048,2053]

theorem envBound33063 : H12AffineFastState.Bounded env33063 := by
  intro p hp
  have h : env33063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33062_33063 : H12AffineEnvironment.transform 11 48 env33062 = env33063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33062 == env33063) = true)

theorem identity33063 : scanCanonicalize (H12AffineFastState.compose env33063 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound33063 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env33064 : List Nat := [2,4,8,16,32,16,9,36,36,52,32,48,41,33,0,35,48,32,52,1,32,32,17,2,40,17,32,48,49,33,21,33,36,32,32,37]

theorem envBound33064 : H12AffineFastState.Bounded env33064 := by
  intro p hp
  have h : env33064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33063_33064 : H12AffineEnvironment.transform 10 32 env33063 = env33064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env33063 == env33064) = true)

theorem identity33064 : scanCanonicalize (H12AffineFastState.compose env33064 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33065 : List Nat := [2,3,8,16,32,16,9,35,35,51,32,48,41,33,0,35,48,32,51,1,32,32,17,2,40,17,32,48,49,33,18,33,35,32,32,34]

theorem envBound33065 : H12AffineFastState.Bounded env33065 := by
  intro p hp
  have h : env33065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33064_33065 : H12AffineEnvironment.transform 1 3 env33064 = env33065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33064 == env33065) = true)

theorem identity33065 : scanCanonicalize (H12AffineFastState.compose env33065 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33066 : List Nat := [2,3,8,16,0,16,9,3,3,19,0,16,9,1,0,3,16,0,19,1,0,0,17,2,8,17,0,16,17,1,18,1,3,0,0,2]

theorem envBound33066 : H12AffineFastState.Bounded env33066 := by
  intro p hp
  have h : env33066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33065_33066 : H12AffineEnvironment.transform 4 0 env33065 = env33066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33065 == env33066) = true)

theorem identity33066 : scanCanonicalize (H12AffineFastState.compose env33066 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33066 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33067 : List Nat := [2,3,0,16,0,16,1,3,3,19,0,16,1,1,0,3,16,0,19,1,0,0,17,2,0,17,0,16,17,1,18,1,3,0,0,2]

theorem envBound33067 : H12AffineFastState.Bounded env33067 := by
  intro p hp
  have h : env33067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33066_33067 : H12AffineEnvironment.transform 2 0 env33066 = env33067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33066 == env33067) = true)

def env33068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452649,95497,8328,65,292256,458024,45525,10280,399665,144612,256,21793,46212,474854]

theorem envBound33068 : H12AffineFastState.Bounded env33068 := by
  intro p hp
  have h : env33068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33045_33068 : H12AffineEnvironment.transform 21 272513 env33045 = env33068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33045 == env33068) = true)

theorem identity33068 : scanCanonicalize (H12AffineFastState.compose env33068 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound33068 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115870,254130,73754,95497,8328,65,245139,79131,45525,10280,119042,144612,256,21793,46212,63189]

theorem envBound33069 : H12AffineFastState.Bounded env33069 := by
  intro p hp
  have h : env33069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33068_33069 : H12AffineEnvironment.transform 17 247859 env33068 = env33069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env33068 == env33069) = true)

def env33070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115870,254130,73754,95497,8328,17,245139,79131,45445,10280,119042,144564,256,21793,46212,63109]

theorem envBound33070 : H12AffineFastState.Bounded env33070 := by
  intro p hp
  have h : env33070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33069_33070 : H12AffineEnvironment.transform 5 16 env33069 = env33070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33069 == env33070) = true)

theorem identity33070 : scanCanonicalize (H12AffineFastState.compose env33070 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound33070 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33071 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57629,76078,1024,32769,115870,65967,73754,95497,8328,17,89230,79131,45445,10280,119042,54697,256,21793,46212,63109]

theorem envBound33071 : H12AffineFastState.Bounded env33071 := by
  intro p hp
  have h : env33071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33070_33071 : H12AffineEnvironment.transform 16 57629 env33070 = env33071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env33070 == env33071) = true)

theorem identity33071 : scanCanonicalize (H12AffineFastState.compose env33071 (packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33071 : packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,57629,76078,1024,32769,115734,65831,73754,95497,8192,17,89094,79131,45325,10280,119042,54561,256,21793,46092,62989]

theorem envBound33072 : H12AffineFastState.Bounded env33072 := by
  intro p hp
  have h : env33072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33071_33072 : H12AffineEnvironment.transform 6 8 env33071 = env33072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33071 == env33072) = true)

theorem identity33072 : scanCanonicalize (H12AffineFastState.compose env33072 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound33072 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33073 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,57629,64809,1024,32769,4113,54560,62493,41230,8192,17,34817,57628,45325,10280,1285,54561,256,21793,46092,62989]

theorem envBound33073 : H12AffineFastState.Bounded env33073 := by
  intro p hp
  have h : env33073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33072_33073 : H12AffineEnvironment.transform 15 54279 env33072 = env33073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env33072 == env33073) = true)

theorem identity33073 : scanCanonicalize (H12AffineFastState.compose env33073 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound33073 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env33074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,5393,2341,1024,29709,4113,8492,17,21762,8192,17,31757,5392,17665,10280,1285,8493,256,21793,16384,513]

theorem envBound33074 : H12AffineFastState.Bounded env33074 := by
  intro p hp
  have h : env33074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33073_33074 : H12AffineEnvironment.transform 14 29708 env33073 = env33074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env33073 == env33074) = true)

theorem identity33074 : scanCanonicalize (H12AffineFastState.compose env33074 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33074 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,5393,2341,1024,8461,4113,8492,17,2,8192,17,10509,5392,4097,10280,1285,8493,256,33,5376,513]

theorem envBound33075 : H12AffineFastState.Bounded env33075 := by
  intro p hp
  have h : env33075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33074_33075 : H12AffineEnvironment.transform 13 5376 env33074 = env33075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33074 == env33075) = true)

theorem identity33075 : scanCanonicalize (H12AffineFastState.compose env33075 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33076 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8232,8203,5173,2049,1024,8233,4113,8200,17,2,8192,17,10281,5172,4097,10280,1057,8201,36,33,5156,513]

theorem envBound33076 : H12AffineFastState.Bounded env33076 := by
  intro p hp
  have h : env33076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33075_33076 : H12AffineEnvironment.transform 7 36 env33075 = env33076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33075 == env33076) = true)

theorem identity33076 : scanCanonicalize (H12AffineFastState.compose env33076 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33076 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33077 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5173,2049,1024,0,4113,33,17,2,41,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound33077 : H12AffineFastState.Bounded env33077 := by
  intro p hp
  have h : env33077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33076_33077 : H12AffineEnvironment.transform 12 41 env33076 = env33077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33076 == env33077) = true)

def env33078 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,1,34,1029,2049,1024,0,33,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound33078 : H12AffineFastState.Bounded env33078 := by
  intro p hp
  have h : env33078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33077_33078 : H12AffineEnvironment.transform 11 48 env33077 = env33078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33077 == env33078) = true)

theorem identity33078 : scanCanonicalize (H12AffineFastState.compose env33078 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound33078 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33079 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,48,41,1044,1,34,1029,2049,1024,0,33,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,48]

theorem envBound33079 : H12AffineFastState.Bounded env33079 := by
  intro p hp
  have h : env33079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33078_33079 : H12AffineEnvironment.transform 8 49 env33078 = env33079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env33078 == env33079) = true)

def env33080 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,41,32,1,34,49,2049,52,0,33,33,17,2,41,17,2048,48,49,2049,21,32,36,33,32,48]

theorem envBound33080 : H12AffineFastState.Bounded env33080 := by
  intro p hp
  have h : env33080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33079_33080 : H12AffineEnvironment.transform 9 52 env33079 = env33080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33079 == env33080) = true)

def env33081 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,41,33,1,34,48,2049,53,0,33,33,17,2,41,17,2048,49,49,2049,20,32,36,33,33,48]

theorem envBound33081 : H12AffineFastState.Bounded env33081 := by
  intro p hp
  have h : env33081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33079_33081 : H12AffineEnvironment.transform 9 53 env33079 = env33081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33079 == env33081) = true)

theorem identity33081 : scanCanonicalize (H12AffineFastState.compose env33081 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33081 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33082 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,42,41,33,1,34,42,2049,47,0,33,33,11,2,41,11,2048,43,43,2049,14,32,36,33,33,42]

theorem envBound33082 : H12AffineFastState.Bounded env33082 := by
  intro p hp
  have h : env33082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33081_33082 : H12AffineEnvironment.transform 3 10 env33081 = env33082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33081 == env33082) = true)

def leafEnv33082 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,42,41,33,1,34,42,2049,47,0,33,33,11,2,14,41,1,11,2048,43,43,2049,14,32,36,33,4,34,33,42,1,33,0]

def active33082 : List Nat := [0,1,2,4,10]

def tree33082 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33082 : H12WitnessSearch.Good tree33082 := H12GlobalWitnessIndex.good

theorem leafIdentity33082 : H12AffineFastState.composeSystem env33082 rootObs = leafEnv33082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33082 rootObs == leafEnv33082) = true)

theorem terminalChecked33082 : H12PackedTerminal.terminalCheckFast leafEnv33082 active33082 tree33082 = true := by decide +kernel

def env33083 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,1,34,1028,2049,1024,0,32,33,17,2,41,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound33083 : H12AffineFastState.Bounded env33083 := by
  intro p hp
  have h : env33083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33077_33083 : H12AffineEnvironment.transform 11 49 env33077 = env33083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33077 == env33083) = true)

theorem identity33083 : scanCanonicalize (H12AffineFastState.compose env33083 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound33083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33084 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,49,41,528,1,34,513,2049,517,0,32,33,17,2,41,17,2048,512,48,2049,548,32,36,33,528,513]

theorem envBound33084 : H12AffineFastState.Bounded env33084 := by
  intro p hp
  have h : env33084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33083_33084 : H12AffineEnvironment.transform 9 517 env33083 = env33084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env33083 == env33084) = true)

def env33085 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,41,32,1,34,49,2049,53,0,32,33,17,2,41,17,2048,48,48,2049,20,32,36,33,32,49]

theorem envBound33085 : H12AffineFastState.Bounded env33085 := by
  intro p hp
  have h : env33085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33084_33085 : H12AffineEnvironment.transform 8 48 env33084 = env33085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33084 == env33085) = true)

theorem identity33085 : scanCanonicalize (H12AffineFastState.compose env33085 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33086 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,43,41,32,1,34,43,2049,47,0,32,33,11,2,41,11,2048,42,42,2049,14,32,36,33,32,43]

theorem envBound33086 : H12AffineFastState.Bounded env33086 := by
  intro p hp
  have h : env33086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33085_33086 : H12AffineEnvironment.transform 3 10 env33085 = env33086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33085 == env33086) = true)

def leafEnv33086 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,43,41,32,1,34,43,2049,47,0,32,33,11,2,14,41,1,11,2048,42,42,2049,14,32,36,33,4,34,32,43,1,32,0]

def active33086 : List Nat := [0,1,2,4,10]

def tree33086 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33086 : H12WitnessSearch.Good tree33086 := H12GlobalWitnessIndex.good

theorem leafIdentity33086 : H12AffineFastState.composeSystem env33086 rootObs = leafEnv33086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33086 rootObs == leafEnv33086) = true)

theorem terminalChecked33086 : H12PackedTerminal.terminalCheckFast leafEnv33086 active33086 tree33086 = true := by decide +kernel

def env33087 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,41,33,1,34,48,2049,52,0,32,33,17,2,41,17,2048,49,48,2049,21,32,36,33,33,48]

theorem envBound33087 : H12AffineFastState.Bounded env33087 := by
  intro p hp
  have h : env33087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33084_33087 : H12AffineEnvironment.transform 8 49 env33084 = env33087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env33084 == env33087) = true)

def env33088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,115870,254130,73754,95497,8328,16,245139,79131,45444,10280,119042,144565,256,21793,46212,63108]

theorem envBound33088 : H12AffineFastState.Bounded env33088 := by
  intro p hp
  have h : env33088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33069_33088 : H12AffineEnvironment.transform 5 17 env33069 = env33088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33069 == env33088) = true)

theorem identity33088 : scanCanonicalize (H12AffineFastState.compose env33088 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound33088 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79131,64808,1024,32769,115870,54697,73754,95497,8328,16,34952,79131,45444,10280,119042,65966,256,21793,46212,63108]

theorem envBound33089 : H12AffineFastState.Bounded env33089 := by
  intro p hp
  have h : env33089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33088_33089 : H12AffineEnvironment.transform 16 79131 env33088 = env33089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env33088 == env33089) = true)

theorem identity33089 : scanCanonicalize (H12AffineFastState.compose env33089 (packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound33089 : packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS < 2^1333 := by decide +kernel

def env33090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79131,2477,1024,29828,77851,8492,73754,95497,8328,16,31757,79131,17665,10280,75143,65966,256,21793,16385,513]

theorem envBound33090 : H12AffineFastState.Bounded env33090 := by
  intro p hp
  have h : env33090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33089_33090 : H12AffineEnvironment.transform 14 29829 env33089 = env33090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env33089 == env33090) = true)

theorem identity33090 : scanCanonicalize (H12AffineFastState.compose env33090 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33090 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,65536,70815,2477,1024,21760,70047,168,65950,87181,268,16,23945,70815,17665,2476,66563,65966,256,21793,16385,513]

theorem envBound33091 : H12AffineFastState.Bounded env33091 := by
  intro p hp
  have h : env33091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33090_33091 : H12AffineEnvironment.transform 12 388 env33090 = env33091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33090 == env33091) = true)

theorem identity33091 : scanCanonicalize (H12AffineFastState.compose env33091 (packedSelected [2,3,4,5,6,9,10,14,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound33091 : packedSelected [2,3,4,5,6,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env33092 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,16384,20633,65536,69895,2477,408,20632,70047,168,65950,86293,268,16,22545,69895,16537,2476,65947,65966,256,20665,16385,513]

theorem envBound33092 : H12AffineFastState.Bounded env33092 := by
  intro p hp
  have h : env33092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33091_33092 : H12AffineEnvironment.transform 9 408 env33091 = env33092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env33091 == env33092) = true)

theorem identity33092 : scanCanonicalize (H12AffineFastState.compose env33092 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33092 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33093 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,4112,137,65536,69895,2477,408,136,70047,168,65950,65797,268,16,2049,69895,4233,2476,65947,65966,256,169,4113,513]

theorem envBound33093 : H12AffineFastState.Bounded env33093 := by
  intro p hp
  have h : env33093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33092_33093 : H12AffineEnvironment.transform 13 4112 env33092 = env33093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33092 == env33093) = true)

theorem identity33093 : scanCanonicalize (H12AffineFastState.compose env33093 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33093 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33094 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4112,0,65536,69895,2340,273,1,69910,33,65815,65797,268,16,2049,69895,4096,2341,65810,65831,256,32,4113,513]

theorem envBound33094 : H12AffineFastState.Bounded env33094 := by
  intro p hp
  have h : env33094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33093_33094 : H12AffineEnvironment.transform 6 9 env33093 = env33094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33093 == env33094) = true)

theorem identity33094 : scanCanonicalize (H12AffineFastState.compose env33094 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound33094 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33095 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2049,0,65536,67862,2340,273,1,67847,33,65815,65797,268,16,2049,67862,2065,2341,65810,65831,256,32,2048,513]

theorem envBound33095 : H12AffineFastState.Bounded env33095 := by
  intro p hp
  have h : env33095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33094_33095 : H12AffineEnvironment.transform 11 2065 env33094 = env33095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env33094 == env33095) = true)

theorem identity33095 : scanCanonicalize (H12AffineFastState.compose env33095 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound33095 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env33096 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2049,0,35,2357,2340,273,1,2340,33,308,294,268,16,2049,2357,2065,2341,305,260,256,32,2048,513]

theorem envBound33096 : H12AffineFastState.Bounded env33096 := by
  intro p hp
  have h : env33096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33095_33096 : H12AffineEnvironment.transform 15 35 env33095 = env33096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env33095 == env33096) = true)

theorem identity33096 : scanCanonicalize (H12AffineFastState.compose env33096 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound33096 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33097 : List Nat := [2,4,8,16,32,17,9,256,33,273,2048,2065,269,2049,0,35,2357,2340,273,1,2340,33,308,294,268,16,2049,2357,2065,2341,305,260,256,32,2048,32]

theorem envBound33097 : H12AffineFastState.Bounded env33097 := by
  intro p hp
  have h : env33097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33096_33097 : H12AffineEnvironment.transform 8 33 env33096 = env33097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env33096 == env33097) = true)

theorem identity33097 : scanCanonicalize (H12AffineFastState.compose env33097 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33097 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env33098 : List Nat := [2,4,8,16,32,17,9,36,33,53,2048,2065,41,2049,0,35,2065,2048,53,1,2048,33,16,2,40,16,2049,2065,2065,2049,21,32,36,32,2048,32]

theorem envBound33098 : H12AffineFastState.Bounded env33098 := by
  intro p hp
  have h : env33098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33097_33098 : H12AffineEnvironment.transform 7 36 env33097 = env33098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33097 == env33098) = true)

theorem identity33098 : scanCanonicalize (H12AffineFastState.compose env33098 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound33098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33099 : List Nat := [2,4,8,16,32,17,9,36,33,53,48,33,41,49,0,35,33,48,53,1,48,33,16,2,40,16,49,33,33,49,21,32,36,32,48,32]

theorem envBound33099 : H12AffineFastState.Bounded env33099 := by
  intro p hp
  have h : env33099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33098_33099 : H12AffineEnvironment.transform 10 48 env33098 = env33099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env33098 == env33099) = true)

theorem identity33099 : scanCanonicalize (H12AffineFastState.compose env33099 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33100 : List Nat := [2,4,8,0,32,1,9,36,33,37,32,33,41,33,0,35,33,32,37,1,32,33,0,2,40,0,33,33,33,33,5,32,36,32,32,32]

theorem envBound33100 : H12AffineFastState.Bounded env33100 := by
  intro p hp
  have h : env33100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33099_33100 : H12AffineEnvironment.transform 3 0 env33099 = env33100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33099 == env33100) = true)

theorem identity33100 : scanCanonicalize (H12AffineFastState.compose env33100 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33100 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33101 : List Nat := [2,4,8,0,1,1,9,5,0,4,1,0,8,0,0,2,0,1,4,1,1,0,0,2,9,0,0,0,0,0,5,1,5,1,1,1]

theorem envBound33101 : H12AffineFastState.Bounded env33101 := by
  intro p hp
  have h : env33101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33100_33101 : H12AffineEnvironment.transform 4 1 env33100 = env33101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33100 == env33101) = true)

def env33102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,8388608,8887585,8328,65,4218144,8393984,8804860,8830977,399664,12645453,256,21792,46213,474855]

theorem envBound33102 : H12AffineFastState.Bounded env33102 := by
  intro p hp
  have h : env33102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32995_33102 : H12AffineEnvironment.transform 23 8887585 env32995 = env33102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887585 env32995 == env33102) = true)

def env33103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452648,95497,8328,65,4218144,458024,45524,10281,399664,4594789,256,21792,46213,474855]

theorem envBound33103 : H12AffineFastState.Bounded env33103 := by
  intro p hp
  have h : env33103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33102_33103 : H12AffineEnvironment.transform 22 452648 env33102 = env33103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env33102 == env33103) = true)

def env33104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452648,95497,8328,65,292256,458024,45524,10281,399664,144613,256,21792,46213,474855]

theorem envBound33104 : H12AffineFastState.Bounded env33104 := by
  intro p hp
  have h : env33104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33103_33104 : H12AffineEnvironment.transform 21 272512 env33103 = env33104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33103 == env33104) = true)

theorem identity33104 : scanCanonicalize (H12AffineFastState.compose env33104 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound33104 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58517,180408,16,95497,8328,65,171416,5392,45524,10281,61704,144613,256,21792,46213,120543]

theorem envBound33105 : H12AffineFastState.Bounded env33105 := by
  intro p hp
  have h : env33105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33104_33105 : H12AffineEnvironment.transform 17 190520 env33104 = env33105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env33104 == env33105) = true)

def env33106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58397,180272,16,95497,8192,65,171280,5392,45404,10281,61704,144493,256,21792,46093,120407]

theorem envBound33106 : H12AffineFastState.Bounded env33106 := by
  intro p hp
  have h : env33106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33105_33106 : H12AffineEnvironment.transform 6 8 env33105 = env33106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33105 == env33106) = true)

theorem identity33106 : scanCanonicalize (H12AffineFastState.compose env33106 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound33106 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58397,32,16,95497,8192,65,23808,5392,45404,10281,61704,62589,256,21792,46093,120407]

theorem envBound33107 : H12AffineFastState.Bounded env33107 := by
  intro p hp
  have h : env33107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33106_33107 : H12AffineEnvironment.transform 16 49168 env33106 = env33107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33106 == env33107) = true)

theorem identity33107 : scanCanonicalize (H12AffineFastState.compose env33107 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound33107 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,49168,10280,1024,32769,58397,32,16,8463,8192,65,23808,5392,45404,10281,61704,62589,256,21792,46093,33361]

theorem envBound33108 : H12AffineFastState.Bounded env33108 := by
  intro p hp
  have h : env33108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33107_33108 : H12AffineEnvironment.transform 15 21510 env33107 = env33108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env33107 == env33108) = true)

theorem identity33108 : scanCanonicalize (H12AffineFastState.compose env33108 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33108 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env33109 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,21510,49168,10280,1024,32769,58397,32,16,8463,8192,17,23808,5392,45324,10281,61704,62509,256,21792,46093,33281]

theorem envBound33109 : H12AffineFastState.Bounded env33109 := by
  intro p hp
  have h : env33109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33108_33109 : H12AffineEnvironment.transform 5 16 env33108 = env33109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33108 == env33109) = true)

theorem identity33109 : scanCanonicalize (H12AffineFastState.compose env33109 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33109 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33110 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,21510,16401,10280,1024,0,25628,32,16,8463,8192,17,23808,5392,12557,10281,28937,29740,256,21792,13324,512]

theorem envBound33110 : H12AffineFastState.Bounded env33110 := by
  intro p hp
  have h : env33110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33109_33110 : H12AffineEnvironment.transform 14 1 env33109 = env33110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33109 == env33110) = true)

theorem identity33110 : scanCanonicalize (H12AffineFastState.compose env33110 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound33110 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33111 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,16384,1,21510,16401,2309,1024,0,17713,32,16,34,301,17,23808,5392,4128,2308,20516,21761,256,21792,5409,512]

theorem envBound33111 : H12AffineFastState.Bounded env33111 := by
  intro p hp
  have h : env33111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33110_33111 : H12AffineEnvironment.transform 12 301 env33110 = env33111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env33110 == env33111) = true)

theorem identity33111 : scanCanonicalize (H12AffineFastState.compose env33111 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33111 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33112 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,301,5376,1,262,5393,2309,1024,0,4145,32,16,34,301,17,2048,5392,4128,2308,1316,1,256,32,5409,512]

theorem envBound33112 : H12AffineFastState.Bounded env33112 := by
  intro p hp
  have h : env33112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33111_33112 : H12AffineEnvironment.transform 13 5376 env33111 = env33112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33111 == env33112) = true)

theorem identity33112 : scanCanonicalize (H12AffineFastState.compose env33112 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound33112 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33113 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,301,32,1,262,49,2309,1024,0,1297,32,16,34,301,17,2048,48,1280,2308,1316,1,256,32,1,512]

theorem envBound33113 : H12AffineFastState.Bounded env33113 := by
  intro p hp
  have h : env33113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33112_33113 : H12AffineEnvironment.transform 11 1312 env33112 = env33113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env33112 == env33113) = true)

theorem identity33113 : scanCanonicalize (H12AffineFastState.compose env33113 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33113 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33114 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,48,301,32,1,262,49,2309,272,0,1,32,16,34,301,17,2048,48,16,2308,52,1,256,32,1,512]

theorem envBound33114 : H12AffineFastState.Bounded env33114 := by
  intro p hp
  have h : env33114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33113_33114 : H12AffineEnvironment.transform 9 272 env33113 = env33114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33113 == env33114) = true)

theorem identity33114 : scanCanonicalize (H12AffineFastState.compose env33114 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound33114 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33115 : List Nat := [2,4,8,16,32,16,8,256,512,272,292,48,301,32,1,262,49,33,272,0,1,32,16,34,301,17,292,48,16,32,52,1,256,32,1,512]

theorem envBound33115 : H12AffineFastState.Bounded env33115 := by
  intro p hp
  have h : env33115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33114_33115 : H12AffineEnvironment.transform 10 292 env33114 = env33115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env33114 == env33115) = true)

theorem identity33115 : scanCanonicalize (H12AffineFastState.compose env33115 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33115 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33116 : List Nat := [2,4,8,16,32,16,8,5,512,21,33,48,40,32,1,3,49,33,21,0,1,32,16,34,40,17,33,48,16,32,52,1,5,32,1,512]

theorem envBound33116 : H12AffineFastState.Bounded env33116 := by
  intro p hp
  have h : env33116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33115_33116 : H12AffineEnvironment.transform 7 5 env33115 = env33116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33115 == env33116) = true)

def env33117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58396,180273,16,95497,8193,65,171281,5392,45405,10281,61704,144492,256,21792,46092,120406]

theorem envBound33117 : H12AffineFastState.Bounded env33117 := by
  intro p hp
  have h : env33117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33105_33117 : H12AffineEnvironment.transform 6 9 env33105 = env33117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33105 == env33117) = true)

theorem identity33117 : scanCanonicalize (H12AffineFastState.compose env33117 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound33117 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,35189,1024,32769,58396,41340,16,95497,8193,65,64604,5392,45405,10281,61704,21793,256,21792,46092,120406]

theorem envBound33118 : H12AffineFastState.Bounded env33118 := by
  intro p hp
  have h : env33118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33117_33118 : H12AffineEnvironment.transform 16 24909 env33117 = env33118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env33117 == env33118) = true)

theorem identity33118 : scanCanonicalize (H12AffineFastState.compose env33118 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound33118 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env33119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,24909,35189,1024,32769,58396,41340,16,54531,8193,65,64604,5392,45405,10281,61704,21793,256,21792,46092,30300]

theorem envBound33119 : H12AffineFastState.Bounded env33119 := by
  intro p hp
  have h : env33119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33118_33119 : H12AffineEnvironment.transform 15 40970 env33118 = env33119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env33118 == env33119) = true)

theorem identity33119 : scanCanonicalize (H12AffineFastState.compose env33119 (packedSelected [1,3,4,8,9,10,12,14,15,18,19,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound33119 : packedSelected [1,3,4,8,9,10,12,14,15,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21541,29743,24909,23888,1024,21540,12345,30041,16,294,8193,65,10361,5392,25976,10281,9517,21793,256,21792,24617,30300]

theorem envBound33120 : H12AffineFastState.Bounded env33120 := by
  intro p hp
  have h : env33120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33119_33120 : H12AffineEnvironment.transform 14 21541 env33119 = env33120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env33119 == env33120) = true)

theorem identity33120 : scanCanonicalize (H12AffineFastState.compose env33120 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33120 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env33121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21541,21591,16693,23888,1024,21540,4161,21793,16,294,121,65,2049,5392,17664,2129,1365,21793,256,21792,16465,22052]

theorem envBound33121 : H12AffineFastState.Bounded env33121 := by
  intro p hp
  have h : env33121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33120_33121 : H12AffineEnvironment.transform 12 120 env33120 = env33121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33120 == env33121) = true)

theorem identity33121 : scanCanonicalize (H12AffineFastState.compose env33121 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound33121 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,373,263,5221,2048,1024,372,4161,113,16,294,121,65,2049,5392,4176,2129,1365,113,256,112,5377,884]

theorem envBound33122 : H12AffineFastState.Bounded env33122 := by
  intro p hp
  have h : env33122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33121_33122 : H12AffineEnvironment.transform 13 5456 env33121 = env33122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env33121 == env33122) = true)

def env33123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452648,95497,8328,65,292257,458024,45524,10281,399664,144612,256,21792,46213,474855]

theorem envBound33123 : H12AffineFastState.Bounded env33123 := by
  intro p hp
  have h : env33123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33103_33123 : H12AffineEnvironment.transform 21 272513 env33103 = env33123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33103 == env33123) = true)

def env33124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272393,452648,95497,8192,65,292137,458024,45404,10281,399664,144492,256,21792,46093,474735]

theorem envBound33124 : H12AffineFastState.Bounded env33124 := by
  intro p hp
  have h : env33124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33123_33124 : H12AffineEnvironment.transform 6 8 env33123 = env33124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33123 == env33124) = true)

def env33125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272393,272440,95497,8192,65,292137,277816,45404,10281,317728,62588,256,21792,46093,392831]

theorem envBound33125 : H12AffineFastState.Bounded env33125 := by
  intro p hp
  have h : env33125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33124_33125 : H12AffineEnvironment.transform 16 49168 env33124 = env33125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33124 == env33125) = true)

theorem identity33125 : scanCanonicalize (H12AffineFastState.compose env33125 (packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound33125 : packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env33126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10360,1024,32769,58445,113,64,95497,8192,65,23889,5440,45404,10281,61784,62588,256,21792,46093,120327]

theorem envBound33126 : H12AffineFastState.Bounded env33126 := by
  intro p hp
  have h : env33126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33125_33126 : H12AffineEnvironment.transform 17 10360 env33125 = env33126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env33125 == env33126) = true)

theorem identity33126 : scanCanonicalize (H12AffineFastState.compose env33126 (packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound33126 : packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env33127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,49168,10360,1024,32769,58445,113,64,8543,8192,65,23889,5440,45404,10281,61784,62588,256,21792,46093,33361]

theorem envBound33127 : H12AffineFastState.Bounded env33127 := by
  intro p hp
  have h : env33127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33126_33127 : H12AffineEnvironment.transform 15 21590 env33126 = env33127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env33126 == env33127) = true)

theorem identity33127 : scanCanonicalize (H12AffineFastState.compose env33127 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33127 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env33128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21590,16400,10360,1024,1,25677,113,64,8543,8192,65,23889,5440,12636,10281,29016,29820,256,21792,13325,593]

theorem envBound33128 : H12AffineFastState.Bounded env33128 := by
  intro p hp
  have h : env33128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33127_33128 : H12AffineEnvironment.transform 14 0 env33127 = env33128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33127 == env33128) = true)

theorem identity33128 : scanCanonicalize (H12AffineFastState.compose env33128 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33128 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env33129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21590,16400,2341,1024,1,17680,113,64,2,349,65,23889,5440,4097,2420,20485,21793,256,21792,5456,593]

theorem envBound33129 : H12AffineFastState.Bounded env33129 := by
  intro p hp
  have h : env33129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33128_33129 : H12AffineEnvironment.transform 12 349 env33128 = env33129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33128 == env33129) = true)

theorem identity33129 : scanCanonicalize (H12AffineFastState.compose env33129 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound33129 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,0,115,5173,2341,1024,1,4405,113,64,2,349,65,2420,5440,4097,2420,1056,260,256,261,5456,593]

theorem envBound33130 : H12AffineFastState.Bounded env33130 := by
  intro p hp
  have h : env33130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33129_33130 : H12AffineEnvironment.transform 13 5157 env33129 = env33130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env33129 == env33130) = true)

theorem identity33130 : scanCanonicalize (H12AffineFastState.compose env33130 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33130 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33131 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,5157,0,115,5173,2048,1024,1,4112,113,64,2,120,65,2129,5221,4097,2129,1056,33,37,32,5237,593]

theorem envBound33131 : H12AffineFastState.Bounded env33131 := by
  intro p hp
  have h : env33131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33130_33131 : H12AffineEnvironment.transform 7 37 env33130 = env33131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33130 == env33131) = true)

theorem identity33131 : scanCanonicalize (H12AffineFastState.compose env33131 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound33131 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33132 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3076,120,2081,0,115,2097,2048,1024,1,3092,113,64,2,120,65,2129,2145,3077,2129,1056,33,37,32,2161,593]

theorem envBound33132 : H12AffineFastState.Bounded env33132 := by
  intro p hp
  have h : env33132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33131_33132 : H12AffineEnvironment.transform 11 3076 env33131 = env33132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env33131 == env33132) = true)

theorem identity33132 : scanCanonicalize (H12AffineFastState.compose env33132 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33132 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env33133 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3076,41,2081,0,34,2097,2048,1024,1,3092,32,17,2,41,16,2048,2096,3077,2048,1056,33,37,32,2080,512]

theorem envBound33133 : H12AffineFastState.Bounded env33133 := by
  intro p hp
  have h : env33133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33132_33133 : H12AffineEnvironment.transform 5 17 env33132 = env33133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33132 == env33133) = true)

theorem identity33133 : scanCanonicalize (H12AffineFastState.compose env33133 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33133 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33134 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3076,8,2048,0,3,2064,2048,1024,1,3092,1,17,2,8,16,2048,2065,3077,2048,1025,0,4,1,2049,512]

theorem envBound33134 : H12AffineFastState.Bounded env33134 := by
  intro p hp
  have h : env33134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33133_33134 : H12AffineEnvironment.transform 4 1 env33133 = env33134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33133 == env33134) = true)

theorem identity33134 : scanCanonicalize (H12AffineFastState.compose env33134 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound33134 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33135 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2048,0,3,2064,2048,20,1,2048,1,17,2,8,16,2048,2065,2065,2048,21,0,4,1,2049,512]

theorem envBound33135 : H12AffineFastState.Bounded env33135 := by
  intro p hp
  have h : env33135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33134_33135 : H12AffineEnvironment.transform 9 20 env33134 = env33135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33134 == env33135) = true)

def env33136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272393,272441,95497,8192,65,292137,277817,45404,10281,317729,62589,256,21792,46093,392830]

theorem envBound33136 : H12AffineFastState.Bounded env33136 := by
  intro p hp
  have h : env33136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33124_33136 : H12AffineEnvironment.transform 16 49169 env33124 = env33136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env33124 == env33136) = true)

theorem identity33136 : scanCanonicalize (H12AffineFastState.compose env33136 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound33136 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58396,33,17,95497,8192,65,23809,5393,45404,10281,61705,62589,256,21792,46093,120406]

theorem envBound33137 : H12AffineFastState.Bounded env33137 := by
  intro p hp
  have h : env33137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33136_33137 : H12AffineEnvironment.transform 17 10280 env33136 = env33137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33136 == env33137) = true)

theorem identity33137 : scanCanonicalize (H12AffineFastState.compose env33137 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound33137 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,10280,1024,32769,58396,33,17,41231,8192,65,23809,5393,45404,10281,61705,62589,256,21792,46093,592]

theorem envBound33138 : H12AffineFastState.Bounded env33138 := by
  intro p hp
  have h : env33138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33137_33138 : H12AffineEnvironment.transform 15 54278 env33137 = env33138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env33137 == env33138) = true)

theorem identity33138 : scanCanonicalize (H12AffineFastState.compose env33138 (packedSelected [2,4,6,11,16,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound33138 : packedSelected [2,4,6,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env33139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,342,5441,10280,1024,21841,12620,33,17,29791,8192,65,23809,5393,25612,10281,9305,8493,256,21792,24925,592]

theorem envBound33139 : H12AffineFastState.Bounded env33139 := by
  intro p hp
  have h : env33139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33138_33139 : H12AffineEnvironment.transform 14 21840 env33138 = env33139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env33138 == env33139) = true)

theorem identity33139 : scanCanonicalize (H12AffineFastState.compose env33139 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33139 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env33140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21840,342,5441,2340,1024,21841,4160,33,17,21843,268,65,23809,5393,17664,2341,1365,33,256,21792,16465,592]

theorem envBound33140 : H12AffineFastState.Bounded env33140 := by
  intro p hp
  have h : env33140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33139_33140 : H12AffineEnvironment.transform 12 268 env33139 = env33140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33139 == env33140) = true)

def env33141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272392,452648,95497,8193,65,292136,458024,45405,10281,399664,144493,256,21792,46092,474734]

theorem envBound33141 : H12AffineFastState.Bounded env33141 := by
  intro p hp
  have h : env33141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33123_33141 : H12AffineEnvironment.transform 6 9 env33123 = env33141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33123 == env33141) = true)

def env33142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272392,272440,95497,8193,65,292136,277816,45405,10281,317728,62589,256,21792,46092,392830]

theorem envBound33142 : H12AffineFastState.Bounded env33142 := by
  intro p hp
  have h : env33142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33141_33142 : H12AffineEnvironment.transform 16 49168 env33141 = env33142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env33141 == env33142) = true)

theorem identity33142 : scanCanonicalize (H12AffineFastState.compose env33142 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound33142 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,17729,41341,41293,95497,8193,65,64605,46157,45405,10281,20565,62589,256,21792,46092,96011]

theorem envBound33143 : H12AffineFastState.Bounded env33143 := by
  intro p hp
  have h : env33143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33142_33143 : H12AffineEnvironment.transform 17 35189 env33142 = env33143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env33142 == env33143) = true)

theorem identity33143 : scanCanonicalize (H12AffineFastState.compose env33143 (packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound33143 : packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env33144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,65536,16741,2048,1024,372,17729,8200,8248,95497,8193,65,32040,13624,12328,10281,20565,29960,256,21792,13689,96011]

theorem envBound33144 : H12AffineFastState.Bounded env33144 := by
  intro p hp
  have h : env33144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33143_33144 : H12AffineEnvironment.transform 14 373 env33143 = env33144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env33143 == env33144) = true)

theorem identity33144 : scanCanonicalize (H12AffineFastState.compose env33144 (packedSelected [2,6,8,9,10,11,12,14,15,16,20,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound33144 : packedSelected [2,6,8,9,10,11,12,14,15,16,20,22,23,28] rootPS < 2^1333 := by decide +kernel

def env33145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,373,65536,13624,2048,1024,372,12572,8200,8248,65876,8193,65,2421,13624,12328,10281,9224,341,256,8573,13689,66390]

theorem envBound33145 : H12AffineFastState.Bounded env33145 := by
  intro p hp
  have h : env33145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33144_33145 : H12AffineEnvironment.transform 13 13405 env33144 = env33145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env33144 == env33145) = true)

theorem identity33145 : scanCanonicalize (H12AffineFastState.compose env33145 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33145 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env33146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,373,65536,5393,2048,1024,372,4405,33,17,65876,40,65,2421,5393,4097,2048,1057,341,256,340,5456,66390]

theorem envBound33146 : H12AffineFastState.Bounded env33146 := by
  intro p hp
  have h : env33146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33145_33146 : H12AffineEnvironment.transform 12 41 env33145 = env33146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33145 == env33146) = true)

theorem identity33146 : scanCanonicalize (H12AffineFastState.compose env33146 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound33146 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33147 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,4113,373,65536,4468,2048,101,372,4405,33,17,65876,40,65,2421,4468,4097,2048,68,341,256,340,4405,66390]

theorem envBound33147 : H12AffineFastState.Bounded env33147 := by
  intro p hp
  have h : env33147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33146_33147 : H12AffineEnvironment.transform 9 101 env33146 = env33147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env33146 == env33147) = true)

theorem identity33147 : scanCanonicalize (H12AffineFastState.compose env33147 (packedSelected [2,4,6,9,11,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound33147 : packedSelected [2,4,6,9,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env33148 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,41,4113,373,115,4468,2048,101,372,4405,33,17,295,40,65,2421,4468,4097,2048,68,341,256,340,4405,805]

theorem envBound33148 : H12AffineFastState.Bounded env33148 := by
  intro p hp
  have h : env33148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33147_33148 : H12AffineEnvironment.transform 15 115 env33147 = env33148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env33147 == env33148) = true)

theorem identity33148 : scanCanonicalize (H12AffineFastState.compose env33148 (packedSelected [2,3,4,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2431) := by decide +kernel

theorem selectedBound33148 : packedSelected [2,3,4,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33149 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2431,41,2414,373,115,2059,2048,101,372,2122,33,17,295,40,65,2421,2059,2430,2048,68,341,256,340,2122,805]

theorem envBound33149 : H12AffineFastState.Bounded env33149 := by
  intro p hp
  have h : env33149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33148_33149 : H12AffineEnvironment.transform 11 2431 env33148 = env33149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2431 env33148 == env33149) = true)

theorem identity33149 : scanCanonicalize (H12AffineFastState.compose env33149 (packedSelected [3,4,7,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33149 : packedSelected [3,4,7,8,15] rootPS < 2^1333 := by decide +kernel

def env33150 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,2138,41,2123,80,115,2059,2048,101,81,2122,33,17,2,40,65,2128,2059,2139,2048,68,112,37,113,2122,512]

theorem envBound33150 : H12AffineFastState.Bounded env33150 := by
  intro p hp
  have h : env33150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33149_33150 : H12AffineEnvironment.transform 7 37 env33149 = env33150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33149 == env33150) = true)

theorem identity33150 : scanCanonicalize (H12AffineFastState.compose env33150 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound33150 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env33151 : List Nat := [2,4,8,16,32,54,9,37,512,19,2048,2092,41,2109,38,5,2059,2048,19,39,2108,33,17,2,40,55,2086,2059,2093,2048,50,6,37,7,2108,512]

theorem envBound33151 : H12AffineFastState.Bounded env33151 := by
  intro p hp
  have h : env33151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33150_33151 : H12AffineEnvironment.transform 5 54 env33150 = env33151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env33150 == env33151) = true)

theorem identity33151 : scanCanonicalize (H12AffineFastState.compose env33151 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33151 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33152 : List Nat := [2,4,8,16,0,22,9,5,512,19,2048,2060,9,2077,6,5,2059,2048,19,7,2076,1,17,2,8,23,2054,2059,2061,2048,18,6,5,7,2076,512]

theorem envBound33152 : H12AffineFastState.Bounded env33152 := by
  intro p hp
  have h : env33152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33151_33152 : H12AffineEnvironment.transform 4 0 env33151 = env33152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33151 == env33152) = true)

theorem identity33152 : scanCanonicalize (H12AffineFastState.compose env33152 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound33152 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env33153 : List Nat := [2,4,8,16,0,22,9,5,512,19,5,9,9,24,6,5,14,5,19,7,25,1,17,2,8,23,3,14,8,5,18,6,5,7,25,512]

theorem envBound33153 : H12AffineFastState.Bounded env33153 := by
  intro p hp
  have h : env33153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33152_33153 : H12AffineEnvironment.transform 10 5 env33152 = env33153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env33152 == env33153) = true)

theorem identity33153 : scanCanonicalize (H12AffineFastState.compose env33153 (packedSelected [0,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound33153 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env33154 : List Nat := [2,4,8,9,0,15,9,5,512,10,5,9,9,1,6,5,14,5,10,7,0,1,8,2,8,14,3,14,8,5,11,6,5,7,0,512]

theorem envBound33154 : H12AffineFastState.Bounded env33154 := by
  intro p hp
  have h : env33154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33153_33154 : H12AffineEnvironment.transform 3 9 env33153 = env33154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env33153 == env33154) = true)

theorem identity33154 : scanCanonicalize (H12AffineFastState.compose env33154 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33154 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33155 : List Nat := [2,4,3,2,0,4,2,5,512,1,5,2,2,1,6,5,5,5,1,7,0,1,3,2,3,5,3,5,3,5,0,6,5,7,0,512]

theorem envBound33155 : H12AffineFastState.Bounded env33155 := by
  intro p hp
  have h : env33155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33154_33155 : H12AffineEnvironment.transform 2 3 env33154 = env33155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33154 == env33155) = true)

theorem identity33155 : scanCanonicalize (H12AffineFastState.compose env33155 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33155 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33156 : List Nat := [2,3,3,2,0,3,2,2,512,1,2,2,2,1,1,2,2,2,1,0,0,1,3,2,3,2,3,2,3,2,0,1,2,0,0,512]

theorem envBound33156 : H12AffineFastState.Bounded env33156 := by
  intro p hp
  have h : env33156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33155_33156 : H12AffineEnvironment.transform 1 3 env33155 = env33156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33155 == env33156) = true)

theorem identity33156 : scanCanonicalize (H12AffineFastState.compose env33156 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33157 : List Nat := [0,1,1,0,0,1,0,0,512,1,0,0,0,1,1,0,0,0,1,0,0,1,1,0,1,0,1,0,1,0,0,1,0,0,0,512]

theorem envBound33157 : H12AffineFastState.Bounded env33157 := by
  intro p hp
  have h : env33157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33156_33157 : H12AffineEnvironment.transform 0 0 env33156 = env33157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33156 == env33157) = true)

def env33158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272392,272441,95497,8193,65,292136,277817,45405,10281,317729,62588,256,21792,46092,392831]

theorem envBound33158 : H12AffineFastState.Bounded env33158 := by
  intro p hp
  have h : env33158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33141_33158 : H12AffineEnvironment.transform 16 49169 env33141 = env33158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env33141 == env33158) = true)

theorem identity33158 : scanCanonicalize (H12AffineFastState.compose env33158 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24909,262144,1024,8541,290153,272392,272441,95497,8193,65,292136,277817,4097,10281,292989,21792,256,21792,5456,352035]

theorem envBound33159 : H12AffineFastState.Bounded env33159 := by
  intro p hp
  have h : env33159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33158_33159 : H12AffineEnvironment.transform 14 8540 env33158 = env33159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33158 == env33159) = true)

theorem identity33159 : scanCanonicalize (H12AffineFastState.compose env33159 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound33159 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8540,65536,5221,262144,1024,8541,268353,272392,272441,65569,8193,65,262144,277817,4097,10281,265557,8200,256,8200,5456,338443]

theorem envBound33160 : H12AffineFastState.Bounded env33160 := by
  intro p hp
  have h : env33160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33159_33160 : H12AffineEnvironment.transform 13 13608 env33159 = env33160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env33159 == env33160) = true)

theorem identity33160 : scanCanonicalize (H12AffineFastState.compose env33160 (packedSelected [0,8,9,10,12,15,16,18,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound33160 : packedSelected [0,8,9,10,12,15,16,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env33161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8540,65536,5221,2420,1024,8541,4405,8572,8525,65569,8193,65,2420,13389,4097,10281,1057,8200,256,8200,5456,74623]

theorem envBound33161 : H12AffineFastState.Bounded env33161 := by
  intro p hp
  have h : env33161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33160_33161 : H12AffineEnvironment.transform 17 2420 env33160 = env33161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env33160 == env33161) = true)

theorem identity33161 : scanCanonicalize (H12AffineFastState.compose env33161 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33161 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env33162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8540,342,5221,2420,1024,8541,4405,8572,8525,375,8193,65,2420,13389,4097,10281,1057,8200,256,8200,5456,8745]

theorem envBound33162 : H12AffineFastState.Bounded env33162 := by
  intro p hp
  have h : env33162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33161_33162 : H12AffineEnvironment.transform 15 342 env33161 = env33162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33161 == env33162) = true)

theorem identity33162 : scanCanonicalize (H12AffineFastState.compose env33162 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound33162 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env33163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3101,6453,3393,342,5221,2420,1024,3392,4405,3425,3408,375,3100,65,2420,6224,4097,1076,1057,3093,256,3093,5456,3636]

theorem envBound33163 : H12AffineFastState.Bounded env33163 := by
  intro p hp
  have h : env33163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33162_33163 : H12AffineEnvironment.transform 12 3101 env33162 = env33163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env33162 == env33163) = true)

theorem identity33163 : scanCanonicalize (H12AffineFastState.compose env33163 (packedSelected [0,4,7,9,10,11,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33163 : packedSelected [0,4,7,9,10,11,16,19] rootPS < 2^1333 := by decide +kernel

def env33164 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3101,6209,3125,34,5221,2048,1024,3124,4161,3093,3108,3,3100,65,2048,6224,4097,1076,1057,3093,116,3093,5156,3636]

theorem envBound33164 : H12AffineFastState.Bounded env33164 := by
  intro p hp
  have h : env33164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33163_33164 : H12AffineEnvironment.transform 7 116 env33163 = env33164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33163 == env33164) = true)

theorem identity33164 : scanCanonicalize (H12AffineFastState.compose env33164 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound33164 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env33165 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1141,4096,104,5172,64,34,5221,1141,1024,65,4161,96,81,3,105,65,1141,5157,4097,1076,1057,96,116,96,5156,577]

theorem envBound33165 : H12AffineFastState.Bounded env33165 := by
  intro p hp
  have h : env33165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33164_33165 : H12AffineEnvironment.transform 10 1141 env33164 = env33165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env33164 == env33165) = true)

theorem identity33165 : scanCanonicalize (H12AffineFastState.compose env33165 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33165 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env33166 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1141,1076,104,0,64,34,81,1141,1024,65,1141,96,81,3,105,65,1141,17,1077,1076,1057,96,116,96,16,577]

theorem envBound33166 : H12AffineFastState.Bounded env33166 := by
  intro p hp
  have h : env33166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33165_33166 : H12AffineEnvironment.transform 11 1076 env33165 = env33166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env33165 == env33166) = true)

theorem identity33166 : scanCanonicalize (H12AffineFastState.compose env33166 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33166 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env33167 : List Nat := [2,4,8,16,32,64,9,116,512,21,96,33,104,0,64,34,81,96,21,65,96,96,81,3,105,65,96,17,32,33,52,96,116,96,16,577]

theorem envBound33167 : H12AffineFastState.Bounded env33167 := by
  intro p hp
  have h : env33167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33166_33167 : H12AffineEnvironment.transform 9 21 env33166 = env33167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33166 == env33167) = true)

theorem identity33167 : scanCanonicalize (H12AffineFastState.compose env33167 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33167 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env33168 : List Nat := [2,4,8,16,0,64,9,84,512,21,64,1,72,0,64,2,81,64,21,65,64,64,81,3,73,65,64,17,0,1,20,64,84,64,16,577]

theorem envBound33168 : H12AffineFastState.Bounded env33168 := by
  intro p hp
  have h : env33168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33167_33168 : H12AffineEnvironment.transform 4 0 env33167 = env33168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33167 == env33168) = true)

theorem identity33168 : scanCanonicalize (H12AffineFastState.compose env33168 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33168 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env33169 : List Nat := [2,4,8,16,0,17,9,5,512,21,17,1,25,0,17,2,0,17,21,16,17,17,0,3,24,16,17,17,0,1,20,17,5,17,16,528]

theorem envBound33169 : H12AffineFastState.Bounded env33169 := by
  intro p hp
  have h : env33169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33168_33169 : H12AffineEnvironment.transform 5 17 env33168 = env33169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33168 == env33169) = true)

def env33170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,4194304,452649,95496,8328,65,4218144,458025,45525,10280,399664,4594788,256,21792,46213,474855]

theorem envBound33170 : H12AffineFastState.Bounded env33170 := by
  intro p hp
  have h : env33170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33102_33170 : H12AffineEnvironment.transform 22 452649 env33102 = env33170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env33102 == env33170) = true)

def env33171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272512,452649,95496,8328,65,292256,458025,45525,10280,399664,144612,256,21792,46213,474855]

theorem envBound33171 : H12AffineFastState.Bounded env33171 := by
  intro p hp
  have h : env33171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33170_33171 : H12AffineEnvironment.transform 21 272512 env33170 = env33171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33170 == env33171) = true)

theorem identity33171 : scanCanonicalize (H12AffineFastState.compose env33171 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound33171 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4161,144492,62661,95496,8328,65,158028,57797,45525,10280,1500,144612,256,21792,46213,74251]

theorem envBound33172 : H12AffineFastState.Bounded env33172 := by
  intro p hp
  have h : env33172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33171_33172 : H12AffineEnvironment.transform 17 138476 env33171 = env33172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env33171 == env33172) = true)

theorem identity33172 : scanCanonicalize (H12AffineFastState.compose env33172 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33172 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138476,1024,32769,4161,144492,62661,21762,8328,65,158028,57797,45525,10280,1500,144612,256,21792,46213,513]

theorem envBound33173 : H12AffineFastState.Bounded env33173 := by
  intro p hp
  have h : env33173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33172_33173 : H12AffineEnvironment.transform 15 8202 env33172 = env33173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33172 == env33173) = true)

theorem identity33173 : scanCanonicalize (H12AffineFastState.compose env33173 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound33173 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env33174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,2421,1024,32769,4161,8693,62661,21762,8328,65,31957,57797,45525,10280,1500,8573,256,21792,46213,513]

theorem envBound33174 : H12AffineFastState.Bounded env33174 := by
  intro p hp
  have h : env33174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33173_33174 : H12AffineEnvironment.transform 16 5529 env33173 = env33174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env33173 == env33174) = true)

theorem identity33174 : scanCanonicalize (H12AffineFastState.compose env33174 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound33174 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env33175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,5529,2421,1024,32769,4161,33,54545,21762,348,65,23809,49169,36865,2556,1500,169,256,21792,38225,513]

theorem envBound33175 : H12AffineFastState.Bounded env33175 := by
  intro p hp
  have h : env33175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33174_33175 : H12AffineEnvironment.transform 12 468 env33174 = env33175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env33174 == env33175) = true)

theorem identity33175 : scanCanonicalize (H12AffineFastState.compose env33175 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33175 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env33176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,32768,478,5529,2421,1024,32769,4161,33,34049,1298,348,65,3345,36865,36865,2556,1500,169,256,1328,38225,513]

theorem envBound33176 : H12AffineFastState.Bounded env33176 := by
  intro p hp
  have h : env33176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33175_33176 : H12AffineEnvironment.transform 13 4112 env33175 = env33176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33175 == env33176) = true)

theorem identity33176 : scanCanonicalize (H12AffineFastState.compose env33176 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 7560) := by decide +kernel

theorem selectedBound33176 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env33177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,7560,478,5529,2421,1024,7561,4161,33,6281,1298,348,65,3345,3465,3465,2556,1500,169,256,1328,2265,513]

theorem envBound33177 : H12AffineFastState.Bounded env33177 := by
  intro p hp
  have h : env33177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33176_33177 : H12AffineEnvironment.transform 14 7560 env33176 = env33177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7560 env33176 == env33177) = true)

theorem identity33177 : scanCanonicalize (H12AffineFastState.compose env33177 (packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33177 : packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,7424,342,5393,2421,1024,7425,4161,33,6145,1298,348,65,3345,3329,3329,2420,1364,33,256,1328,2129,513]

theorem envBound33178 : H12AffineFastState.Bounded env33178 := by
  intro p hp
  have h : env33178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33177_33178 : H12AffineEnvironment.transform 6 8 env33177 = env33178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33177 == env33178) = true)

theorem identity33178 : scanCanonicalize (H12AffineFastState.compose env33178 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33178 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33179 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,6161,342,4096,2421,273,6160,4161,33,6145,3,348,65,2048,2064,2064,2420,69,33,256,33,2129,513]

theorem envBound33179 : H12AffineFastState.Bounded env33179 := by
  intro p hp
  have h : env33179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33178_33179 : H12AffineEnvironment.transform 9 273 env33178 = env33179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33178 == env33179) = true)

theorem identity33179 : scanCanonicalize (H12AffineFastState.compose env33179 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound33179 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33180 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2064,348,2048,1,342,2064,2421,273,0,2129,33,17,3,348,65,2048,2064,2064,2420,69,33,256,33,2129,513]

theorem envBound33180 : H12AffineFastState.Bounded env33180 := by
  intro p hp
  have h : env33180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33179_33180 : H12AffineEnvironment.transform 11 2064 env33179 = env33180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env33179 == env33180) = true)

theorem identity33180 : scanCanonicalize (H12AffineFastState.compose env33180 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound33180 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33181 : List Nat := [2,4,8,16,32,64,8,52,512,37,2048,2064,104,2048,1,98,2064,2113,37,0,2129,33,17,3,104,65,2048,2064,2064,2112,69,33,52,33,2129,513]

theorem envBound33181 : H12AffineFastState.Bounded env33181 := by
  intro p hp
  have h : env33181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33180_33181 : H12AffineEnvironment.transform 7 52 env33180 = env33181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env33180 == env33181) = true)

theorem identity33181 : scanCanonicalize (H12AffineFastState.compose env33181 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound33181 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33182 : List Nat := [2,4,8,16,32,64,8,52,512,37,512,528,104,512,1,98,528,577,37,0,593,33,17,3,104,65,512,528,528,576,69,33,52,33,593,513]

theorem envBound33182 : H12AffineFastState.Bounded env33182 := by
  intro p hp
  have h : env33182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33181_33182 : H12AffineEnvironment.transform 10 512 env33181 = env33182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env33181 == env33182) = true)

theorem identity33182 : scanCanonicalize (H12AffineFastState.compose env33182 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33182 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33183 : List Nat := [2,4,8,16,32,64,8,52,0,37,0,16,104,0,1,98,16,65,37,0,81,33,17,3,104,65,0,16,16,64,69,33,52,33,81,1]

theorem envBound33183 : H12AffineFastState.Bounded env33183 := by
  intro p hp
  have h : env33183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33182_33183 : H12AffineEnvironment.transform 8 0 env33182 = env33183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33182 == env33183) = true)

theorem identity33183 : scanCanonicalize (H12AffineFastState.compose env33183 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33184 : List Nat := [2,4,8,1,32,64,8,37,0,37,0,1,104,0,1,98,1,65,37,0,64,33,0,3,104,65,0,1,1,64,69,33,37,33,64,1]

theorem envBound33184 : H12AffineFastState.Bounded env33184 := by
  intro p hp
  have h : env33184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33183_33184 : H12AffineEnvironment.transform 3 1 env33183 = env33184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33183 == env33184) = true)

theorem identity33184 : scanCanonicalize (H12AffineFastState.compose env33184 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33185 : List Nat := [2,4,3,1,32,64,3,37,0,37,0,1,99,0,1,98,1,65,37,0,64,33,0,3,99,65,0,1,1,64,69,33,37,33,64,1]

theorem envBound33185 : H12AffineFastState.Bounded env33185 := by
  intro p hp
  have h : env33185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33184_33185 : H12AffineEnvironment.transform 2 3 env33184 = env33185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33184 == env33185) = true)

theorem identity33185 : scanCanonicalize (H12AffineFastState.compose env33185 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33185 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33186 : List Nat := [2,4,3,1,32,0,3,37,0,37,0,1,35,0,1,34,1,1,37,0,0,33,0,3,35,1,0,1,1,0,5,33,37,33,0,1]

theorem envBound33186 : H12AffineFastState.Bounded env33186 := by
  intro p hp
  have h : env33186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33185_33186 : H12AffineEnvironment.transform 5 0 env33185 = env33186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33185 == env33186) = true)

def env33187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452649,95496,8328,65,292257,458025,45525,10280,399664,144613,256,21792,46213,474855]

theorem envBound33187 : H12AffineFastState.Bounded env33187 := by
  intro p hp
  have h : env33187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33170_33187 : H12AffineEnvironment.transform 21 272513 env33170 = env33187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33170 == env33187) = true)

theorem identity33187 : scanCanonicalize (H12AffineFastState.compose env33187 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound33187 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396461,272513,400636,95496,8328,65,292257,395772,17664,10280,399664,144613,256,21792,16464,474855]

theorem envBound33188 : H12AffineFastState.Bounded env33188 := by
  intro p hp
  have h : env33188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33187_33188 : H12AffineEnvironment.transform 14 29909 env33187 = env33188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env33187 == env33188) = true)

def env33189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140301,33,144476,95496,8328,65,23809,139612,17664,10280,143760,144613,256,21792,16464,202311]

theorem envBound33189 : H12AffineFastState.Bounded env33189 := by
  intro p hp
  have h : env33189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33188_33189 : H12AffineEnvironment.transform 17 10400 env33188 = env33189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33188 == env33189) = true)

theorem identity33189 : scanCanonicalize (H12AffineFastState.compose env33189 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound33189 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env33190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,131072,10400,1024,29908,140301,33,144476,29910,8328,65,23809,139612,17664,10280,143760,144613,256,21792,16464,137113]

theorem envBound33190 : H12AffineFastState.Bounded env33190 := by
  intro p hp
  have h : env33190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33189_33190 : H12AffineEnvironment.transform 15 478 env33189 = env33190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env33189 == env33190) = true)

theorem identity33190 : scanCanonicalize (H12AffineFastState.compose env33190 (packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound33190 : packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,5528,10400,1024,29908,12693,33,8644,29910,8328,65,23809,13508,17664,10280,9224,8573,256,21792,16464,513]

theorem envBound33191 : H12AffineFastState.Bounded env33191 := by
  intro p hp
  have h : env33191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33190_33191 : H12AffineEnvironment.transform 16 5528 env33190 = env33191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env33190 == env33191) = true)

theorem identity33191 : scanCanonicalize (H12AffineFastState.compose env33191 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound33191 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,478,5528,2421,1024,21761,4160,33,17,21763,349,65,23809,5393,17664,2557,1501,168,256,21792,16464,513]

theorem envBound33192 : H12AffineFastState.Bounded env33192 := by
  intro p hp
  have h : env33192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33191_33192 : H12AffineEnvironment.transform 12 469 env33191 = env33192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env33191 == env33192) = true)

theorem identity33192 : scanCanonicalize (H12AffineFastState.compose env33192 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound33192 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env33193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,478,5528,2421,1024,136,4160,33,17,138,349,65,2184,5393,4233,2557,1501,168,256,169,5593,513]

theorem envBound33193 : H12AffineFastState.Bounded env33193 := by
  intro p hp
  have h : env33193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33192_33193 : H12AffineEnvironment.transform 13 5513 env33192 = env33193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env33192 == env33193) = true)

theorem identity33193 : scanCanonicalize (H12AffineFastState.compose env33193 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33193 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33194 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,5372,137,171,5357,2048,1024,136,4160,33,17,138,40,65,2184,5220,4233,2184,1192,168,117,169,5292,513]

theorem envBound33194 : H12AffineFastState.Bounded env33194 := by
  intro p hp
  have h : env33194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33193_33194 : H12AffineEnvironment.transform 7 117 env33193 = env33194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33193 == env33194) = true)

theorem identity33194 : scanCanonicalize (H12AffineFastState.compose env33194 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33194 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33195 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,120,5156,81,115,5173,2048,1024,80,4160,33,17,82,40,65,2128,5220,4177,2128,1136,112,117,113,5236,513]

theorem envBound33195 : H12AffineFastState.Bounded env33195 := by
  intro p hp
  have h : env33195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33194_33195 : H12AffineEnvironment.transform 6 88 env33194 = env33195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33194 == env33195) = true)

def env33196 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,35,5173,2048,1024,0,4112,33,17,2,40,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound33196 : H12AffineFastState.Bounded env33196 := by
  intro p hp
  have h : env33196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33195_33196 : H12AffineEnvironment.transform 5 16 env33195 = env33196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33195 == env33196) = true)

def env33197 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1044,1,35,1029,2048,1024,0,32,33,17,2,40,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound33197 : H12AffineFastState.Bounded env33197 := by
  intro p hp
  have h : env33197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33196_33197 : H12AffineEnvironment.transform 11 48 env33196 = env33197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33196 == env33197) = true)

theorem identity33197 : scanCanonicalize (H12AffineFastState.compose env33197 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound33197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33198 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,48,40,1044,1,35,1029,1045,1024,0,32,33,17,2,40,17,1045,1028,49,1045,1056,32,37,33,1044,513]

theorem envBound33198 : H12AffineFastState.Bounded env33198 := by
  intro p hp
  have h : env33198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33197_33198 : H12AffineEnvironment.transform 10 1045 env33197 = env33198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env33197 == env33198) = true)

def env33199 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,40,32,1,35,49,33,52,0,32,33,17,2,40,17,33,48,49,33,20,32,37,33,32,513]

theorem envBound33199 : H12AffineFastState.Bounded env33199 := by
  intro p hp
  have h : env33199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33198_33199 : H12AffineEnvironment.transform 9 52 env33198 = env33199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33198 == env33199) = true)

def env33200 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,40,33,1,35,48,32,53,0,32,33,17,2,40,17,32,49,49,32,21,32,37,33,33,513]

theorem envBound33200 : H12AffineFastState.Bounded env33200 := by
  intro p hp
  have h : env33200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33198_33200 : H12AffineEnvironment.transform 9 53 env33198 = env33200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33198 == env33200) = true)

theorem identity33200 : scanCanonicalize (H12AffineFastState.compose env33200 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33201 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,48,40,33,1,35,48,32,53,0,32,33,17,2,40,17,32,49,49,32,21,32,37,33,33,43]

theorem envBound33201 : H12AffineFastState.Bounded env33201 := by
  intro p hp
  have h : env33201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33200_33201 : H12AffineEnvironment.transform 8 42 env33200 = env33201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33200 == env33201) = true)

def leafEnv33201 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,48,40,33,1,35,48,32,53,0,32,33,17,2,21,40,1,17,32,49,49,32,21,32,37,33,4,35,33,43,1,32,0]

def active33201 : List Nat := [0,1,2,3,4]

def tree33201 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33201 : H12WitnessSearch.Good tree33201 := H12GlobalWitnessIndex.good

theorem leafIdentity33201 : H12AffineFastState.composeSystem env33201 rootObs = leafEnv33201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33201 rootObs == leafEnv33201) = true)

theorem terminalChecked33201 : H12PackedTerminal.terminalCheckFast leafEnv33201 active33201 tree33201 = true := by decide +kernel

def env33202 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1045,1,35,1028,2048,1024,0,33,33,17,2,40,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound33202 : H12AffineFastState.Bounded env33202 := by
  intro p hp
  have h : env33202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33196_33202 : H12AffineEnvironment.transform 11 49 env33196 = env33202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33196 == env33202) = true)

theorem identity33202 : scanCanonicalize (H12AffineFastState.compose env33202 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound33202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33203 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,49,40,1045,1,35,1028,33,1024,0,33,33,17,2,40,17,33,1029,48,33,1056,32,37,33,1045,513]

theorem envBound33203 : H12AffineFastState.Bounded env33203 := by
  intro p hp
  have h : env33203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33202_33203 : H12AffineEnvironment.transform 10 33 env33202 = env33203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env33202 == env33203) = true)

def env33204 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,40,33,1,35,48,33,52,0,33,33,17,2,40,17,33,49,48,33,20,32,37,33,33,513]

theorem envBound33204 : H12AffineFastState.Bounded env33204 := by
  intro p hp
  have h : env33204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33203_33204 : H12AffineEnvironment.transform 9 52 env33203 = env33204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33203 == env33204) = true)

def env33205 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,40,32,1,35,49,33,53,0,33,33,17,2,40,17,33,48,48,33,21,32,37,33,32,513]

theorem envBound33205 : H12AffineFastState.Bounded env33205 := by
  intro p hp
  have h : env33205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33203_33205 : H12AffineEnvironment.transform 9 53 env33203 = env33205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33203 == env33205) = true)

theorem identity33205 : scanCanonicalize (H12AffineFastState.compose env33205 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33205 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33206 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,49,40,32,1,35,49,33,53,0,33,33,17,2,40,17,33,48,48,33,21,32,37,33,32,42]

theorem envBound33206 : H12AffineFastState.Bounded env33206 := by
  intro p hp
  have h : env33206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33205_33206 : H12AffineEnvironment.transform 8 43 env33205 = env33206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33205 == env33206) = true)

def leafEnv33206 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,49,40,32,1,35,49,33,53,0,33,33,17,2,21,40,1,17,33,48,48,33,21,32,37,33,4,35,32,42,1,33,0]

def active33206 : List Nat := [0,1,2,3,4]

def tree33206 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33206 : H12WitnessSearch.Good tree33206 := H12GlobalWitnessIndex.good

theorem leafIdentity33206 : H12AffineFastState.composeSystem env33206 rootObs = leafEnv33206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33206 rootObs == leafEnv33206) = true)

theorem terminalChecked33206 : H12PackedTerminal.terminalCheckFast leafEnv33206 active33206 tree33206 = true := by decide +kernel

def env33207 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4113,33,17,3,40,16,2049,5173,4096,2049,1057,33,36,32,5157,513]

theorem envBound33207 : H12AffineFastState.Bounded env33207 := by
  intro p hp
  have h : env33207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33195_33207 : H12AffineEnvironment.transform 5 17 env33195 = env33207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33195 == env33207) = true)

theorem identity33207 : scanCanonicalize (H12AffineFastState.compose env33207 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33207 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33208 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,0,34,4097,2048,52,1,4113,33,17,3,40,16,2049,4097,4096,2049,21,33,36,32,4113,513]

theorem envBound33208 : H12AffineFastState.Bounded env33208 := by
  intro p hp
  have h : env33208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33207_33208 : H12AffineEnvironment.transform 9 52 env33207 = env33208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33207 == env33208) = true)

theorem identity33208 : scanCanonicalize (H12AffineFastState.compose env33208 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound33208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33209 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,41,48,0,34,33,2048,52,1,49,33,17,3,40,16,2049,33,32,2049,21,33,36,32,49,513]

theorem envBound33209 : H12AffineFastState.Bounded env33209 := by
  intro p hp
  have h : env33209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33208_33209 : H12AffineEnvironment.transform 11 32 env33208 = env33209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env33208 == env33209) = true)

theorem identity33209 : scanCanonicalize (H12AffineFastState.compose env33209 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33209 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33210 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,41,48,0,34,33,49,52,1,49,33,17,3,40,16,48,33,32,48,21,33,36,32,49,513]

theorem envBound33210 : H12AffineFastState.Bounded env33210 := by
  intro p hp
  have h : env33210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33209_33210 : H12AffineEnvironment.transform 10 49 env33209 = env33210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33209 == env33210) = true)

def leafEnv33210 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,41,48,0,34,33,49,52,1,49,33,17,3,21,40,1,16,48,33,32,48,21,33,36,32,4,35,49,513,1,48,0]

def active33210 : List Nat := [0,1,2,3,4,8]

def tree33210 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33210 : H12WitnessSearch.Good tree33210 := H12GlobalWitnessIndex.good

theorem leafIdentity33210 : H12AffineFastState.composeSystem env33210 rootObs = leafEnv33210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33210 rootObs == leafEnv33210) = true)

theorem terminalChecked33210 : H12PackedTerminal.terminalCheckFast leafEnv33210 active33210 tree33210 = true := by decide +kernel

def env33211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140300,32,144477,95496,8328,65,23808,139613,17664,10280,143761,144613,256,21792,16464,202310]

theorem envBound33211 : H12AffineFastState.Bounded env33211 := by
  intro p hp
  have h : env33211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33188_33211 : H12AffineEnvironment.transform 17 10401 env33188 = env33211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33188 == env33211) = true)

theorem identity33211 : scanCanonicalize (H12AffineFastState.compose env33211 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33211 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env33212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,10401,1024,29908,82966,32,87111,95496,8328,65,23808,82247,17664,10280,86411,87295,256,21792,16464,30300]

theorem envBound33212 : H12AffineFastState.Bounded env33212 := by
  intro p hp
  have h : env33212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33211_33212 : H12AffineEnvironment.transform 16 90138 env33211 = env33212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33211 == env33212) = true)

theorem identity33212 : scanCanonicalize (H12AffineFastState.compose env33212 (packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound33212 : packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21646,13460,10401,1024,29908,4248,32,201,8582,8328,65,23808,5577,17664,10280,1285,113,256,21792,16464,30300]

theorem envBound33213 : H12AffineFastState.Bounded env33213 := by
  intro p hp
  have h : env33213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33212_33213 : H12AffineEnvironment.transform 15 21646 env33212 = env33213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env33212 == env33213) = true)

theorem identity33213 : scanCanonicalize (H12AffineFastState.compose env33213 (packedSelected [5,8,10,16,19,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound33213 : packedSelected [5,8,10,16,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env33214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,8403,13460,10401,1024,137,4248,32,201,8582,8328,65,10589,5577,12637,10280,1285,113,256,8573,13325,513]

theorem envBound33214 : H12AffineFastState.Bounded env33214 := by
  intro p hp
  have h : env33214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33213_33214 : H12AffineEnvironment.transform 13 13405 env33213 = env33214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env33213 == env33214) = true)

theorem identity33214 : scanCanonicalize (H12AffineFastState.compose env33214 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33214 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8283,13340,10281,1024,1,4112,32,65,8462,8192,65,10589,5441,12637,10280,1285,113,256,8573,13325,513]

theorem envBound33215 : H12AffineFastState.Bounded env33215 := by
  intro p hp
  have h : env33215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33214_33215 : H12AffineEnvironment.transform 6 8 env33214 = env33215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33214 == env33215) = true)

theorem identity33215 : scanCanonicalize (H12AffineFastState.compose env33215 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound33215 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2396,7425,0,2311,7488,373,1024,1,4112,32,65,2130,2396,65,1,5441,6145,372,1285,113,256,2081,7505,513]

theorem envBound33216 : H12AffineFastState.Bounded env33216 := by
  intro p hp
  have h : env33216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33215_33216 : H12AffineEnvironment.transform 12 2396 env33215 = env33216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env33215 == env33216) = true)

theorem identity33216 : scanCanonicalize (H12AffineFastState.compose env33216 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound33216 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env33217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,2396,1345,0,2311,1280,373,1024,1,2128,32,65,2130,2396,65,1,3329,65,372,1285,113,256,2081,1297,513]

theorem envBound33217 : H12AffineFastState.Bounded env33217 := by
  intro p hp
  have h : env33217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33216_33217 : H12AffineEnvironment.transform 11 2112 env33216 = env33217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env33216 == env33217) = true)

theorem identity33217 : scanCanonicalize (H12AffineFastState.compose env33217 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound33217 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1281,1053,1345,0,1094,1280,373,1024,1,1297,32,65,1299,1053,65,1,64,65,372,1285,113,256,1376,1297,513]

theorem envBound33218 : H12AffineFastState.Bounded env33218 := by
  intro p hp
  have h : env33218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33217_33218 : H12AffineEnvironment.transform 10 1345 env33217 = env33218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env33217 == env33218) = true)

theorem identity33218 : scanCanonicalize (H12AffineFastState.compose env33218 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33218 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33219 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,16,268,80,0,343,17,373,273,1,0,32,65,2,268,65,1,64,65,372,20,113,256,113,0,513]

theorem envBound33219 : H12AffineFastState.Bounded env33219 := by
  intro p hp
  have h : env33219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33218_33219 : H12AffineEnvironment.transform 9 273 env33218 = env33219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33218 == env33219) = true)

theorem identity33219 : scanCanonicalize (H12AffineFastState.compose env33219 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33219 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33220 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,16,41,80,0,114,17,80,52,1,0,32,65,2,41,65,1,64,65,81,20,113,37,113,0,513]

theorem envBound33220 : H12AffineFastState.Bounded env33220 := by
  intro p hp
  have h : env33220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33219_33220 : H12AffineEnvironment.transform 7 37 env33219 = env33220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33219 == env33220) = true)

theorem identity33220 : scanCanonicalize (H12AffineFastState.compose env33220 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound33220 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env33221 : List Nat := [2,4,8,16,32,64,8,37,32,52,80,16,41,80,0,114,17,80,52,1,0,32,65,2,41,65,1,64,65,81,20,113,37,113,0,33]

theorem envBound33221 : H12AffineFastState.Bounded env33221 := by
  intro p hp
  have h : env33221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33220_33221 : H12AffineEnvironment.transform 8 32 env33220 = env33221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env33220 == env33221) = true)

theorem identity33221 : scanCanonicalize (H12AffineFastState.compose env33221 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33221 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33222 : List Nat := [2,4,8,16,32,17,8,37,32,52,1,16,41,1,0,35,17,1,52,1,0,32,16,2,41,16,1,17,16,0,20,32,37,32,0,33]

theorem envBound33222 : H12AffineFastState.Bounded env33222 := by
  intro p hp
  have h : env33222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33221_33222 : H12AffineEnvironment.transform 5 17 env33221 = env33222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33221 == env33222) = true)

theorem identity33222 : scanCanonicalize (H12AffineFastState.compose env33222 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33223 : List Nat := [2,4,8,16,11,17,8,14,11,31,1,16,2,1,0,8,17,1,31,1,0,11,16,2,2,16,1,17,16,0,20,11,14,11,0,10]

theorem envBound33223 : H12AffineFastState.Bounded env33223 := by
  intro p hp
  have h : env33223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33222_33223 : H12AffineEnvironment.transform 4 11 env33222 = env33223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33222 == env33223) = true)

theorem identity33223 : scanCanonicalize (H12AffineFastState.compose env33223 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33224 : List Nat := [2,4,2,16,1,17,2,4,1,21,1,16,2,1,0,2,17,1,21,1,0,1,16,2,2,16,1,17,16,0,20,1,4,1,0,0]

theorem envBound33224 : H12AffineFastState.Bounded env33224 := by
  intro p hp
  have h : env33224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33223_33224 : H12AffineEnvironment.transform 2 2 env33223 = env33224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33223 == env33224) = true)

theorem identity33224 : scanCanonicalize (H12AffineFastState.compose env33224 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33224 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33225 : List Nat := [2,4,2,1,1,0,2,4,1,4,1,1,2,1,0,2,0,1,4,1,0,1,1,2,2,1,1,0,1,0,5,1,4,1,0,0]

theorem envBound33225 : H12AffineFastState.Bounded env33225 := by
  intro p hp
  have h : env33225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33224_33225 : H12AffineEnvironment.transform 3 1 env33224 = env33225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33224 == env33225) = true)

def env33226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound33226 : H12AffineFastState.Bounded env33226 := by
  intro p hp
  have h : env33226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32993_33226 : H12AffineEnvironment.transform 18 1025 env32993 = env33226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env32993 == env33226) = true)

theorem identity33226 : scanCanonicalize (H12AffineFastState.compose env33226 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10873901) := by decide +kernel

theorem selectedBound33226 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10873901,8328,65,6433837,8677536,10507601,8830976,2385980,12880364,257,272512,313636,2445290]

theorem envBound33227 : H12AffineFastState.Bounded env33227 := by
  intro p hp
  have h : env33227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33226_33227 : H12AffineEnvironment.transform 23 10873901 env33226 = env33227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10873901 env33226 == env33227) = true)

def env33228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433837,8393984,10507601,8568224,2102684,12645452,257,21792,46212,2175562]

theorem envBound33228 : H12AffineFastState.Bounded env33228 := by
  intro p hp
  have h : env33228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33227_33228 : H12AffineEnvironment.transform 17 32160 env33227 = env33228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env33227 == env33228) = true)

def env33229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101328,98781,8328,65,6433837,2098512,17665,2272752,2102684,6349852,257,21792,46212,2175562]

theorem envBound33229 : H12AffineFastState.Bounded env33229 := by
  intro p hp
  have h : env33229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33228_33229 : H12AffineEnvironment.transform 22 2101328 env33228 = env33229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env33228 == env33229) = true)

def env33230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,16,98781,8328,65,4340845,5392,17665,179632,1500,4256860,257,21792,46212,74250]

theorem envBound33230 : H12AffineFastState.Bounded env33230 := by
  intro p hp
  have h : env33230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33229_33230 : H12AffineEnvironment.transform 20 4160 env33229 = env33230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33229 == env33230) = true)

theorem identity33230 : scanCanonicalize (H12AffineFastState.compose env33230 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95530) := by decide +kernel

theorem selectedBound33230 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,95530,16,98781,8328,65,215367,5392,17665,179632,1500,98678,257,21792,46212,74250]

theorem envBound33231 : H12AffineFastState.Bounded env33231 := by
  intro p hp
  have h : env33231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33230_33231 : H12AffineEnvironment.transform 21 95530 env33230 = env33231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95530 env33230 == env33231) = true)

def env33232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,95530,16,98645,8192,65,215367,5392,17665,179512,1364,98678,257,21792,46092,74250]

theorem envBound33232 : H12AffineFastState.Bounded env33232 := by
  intro p hp
  have h : env33232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33231_33232 : H12AffineEnvironment.transform 6 8 env33231 = env33232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33231 == env33232) = true)

theorem identity33232 : scanCanonicalize (H12AffineFastState.compose env33232 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33232 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4160,95530,16,95497,8192,65,215367,5392,17665,149860,1364,95530,257,21792,16464,74250]

theorem envBound33233 : H12AffineFastState.Bounded env33233 := by
  intro p hp
  have h : env33233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33232_33233 : H12AffineEnvironment.transform 14 29788 env33232 = env33233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33232 == env33233) = true)

theorem identity33233 : scanCanonicalize (H12AffineFastState.compose env33233 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33233 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21793,16,21762,8192,65,158028,5392,17665,149860,1364,21793,257,21792,16464,513]

theorem envBound33234 : H12AffineFastState.Bounded env33234 := by
  intro p hp
  have h : env33234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33233_33234 : H12AffineEnvironment.transform 15 8203 env33233 = env33234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33233 == env33234) = true)

theorem identity33234 : scanCanonicalize (H12AffineFastState.compose env33234 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12557) := by decide +kernel

theorem selectedBound33234 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,12557,32040,1025,29789,4160,21793,16,21762,8192,65,22593,5392,17665,30825,1364,21793,257,21792,16464,513]

theorem envBound33235 : H12AffineFastState.Bounded env33235 := by
  intro p hp
  have h : env33235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33234_33235 : H12AffineEnvironment.transform 16 12557 env33234 = env33235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12557 env33234 == env33235) = true)

theorem identity33235 : scanCanonicalize (H12AffineFastState.compose env33235 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound33235 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1344,8203,12557,3124,1025,1345,4160,9277,16,9246,8192,65,10589,5392,13341,2421,1364,9277,257,9276,12620,513]

theorem envBound33236 : H12AffineFastState.Bounded env33236 := by
  intro p hp
  have h : env33236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33235_33236 : H12AffineEnvironment.transform 13 12572 env33235 = env33236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env33235 == env33236) = true)

theorem identity33236 : scanCanonicalize (H12AffineFastState.compose env33236 (packedSelected [0,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound33236 : packedSelected [0,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env33237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,8192,12572,1344,8203,12557,1344,1025,1345,4160,9277,16,9246,8192,65,8233,5392,13341,1,1364,9277,257,9276,12620,513]

theorem envBound33237 : H12AffineFastState.Bounded env33237 := by
  intro p hp
  have h : env33237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33236_33237 : H12AffineEnvironment.transform 10 372 env33236 = env33237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env33236 == env33237) = true)

theorem identity33237 : scanCanonicalize (H12AffineFastState.compose env33237 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound33237 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env33238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,4429,81,1344,4422,64,1344,1025,1345,4160,5488,16,5459,4429,65,4452,5392,1360,1,1364,5488,257,5489,1,513]

theorem envBound33238 : H12AffineFastState.Bounded env33238 := by
  intro p hp
  have h : env33238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33237_33238 : H12AffineEnvironment.transform 12 4429 env33237 = env33238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env33237 == env33238) = true)

theorem identity33238 : scanCanonicalize (H12AffineFastState.compose env33238 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound33238 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env33239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,64,269,81,1344,262,64,1344,1025,1345,0,1328,16,1299,269,65,292,1360,1360,1,1364,1328,257,1329,1,513]

theorem envBound33239 : H12AffineFastState.Bounded env33239 := by
  intro p hp
  have h : env33239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33238_33239 : H12AffineEnvironment.transform 11 64 env33238 = env33239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env33238 == env33239) = true)

theorem identity33239 : scanCanonicalize (H12AffineFastState.compose env33239 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33239 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33240 : List Nat := [2,4,8,16,32,64,8,256,512,100,372,64,269,81,292,262,64,292,101,293,0,340,16,375,269,65,292,308,308,1,304,340,257,341,1,513]

theorem envBound33240 : H12AffineFastState.Bounded env33240 := by
  intro p hp
  have h : env33240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33239_33240 : H12AffineEnvironment.transform 9 100 env33239 = env33240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33239 == env33240) = true)

def env33241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95530,16,98644,8193,65,215367,5392,17665,179513,1365,98678,257,21792,46093,74250]

theorem envBound33241 : H12AffineFastState.Bounded env33241 := by
  intro p hp
  have h : env33241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33231_33241 : H12AffineEnvironment.transform 6 9 env33231 = env33241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33231 == env33241) = true)

theorem identity33241 : scanCanonicalize (H12AffineFastState.compose env33241 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33241 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4160,73771,16,98644,8193,65,203846,5392,4096,179513,1365,98678,257,33,46093,74250]

theorem envBound33242 : H12AffineFastState.Bounded env33242 := by
  intro p hp
  have h : env33242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33241_33242 : H12AffineEnvironment.transform 13 5377 env33241 = env33242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33241 == env33242) = true)

theorem identity33242 : scanCanonicalize (H12AffineFastState.compose env33242 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33242 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,10280,1025,32769,4160,33,16,41310,8193,65,146508,5392,4096,179513,1365,41340,257,33,46093,512]

theorem envBound33243 : H12AffineFastState.Bounded env33243 := by
  intro p hp
  have h : env33243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33242_33243 : H12AffineEnvironment.transform 15 8202 env33242 = env33243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33242 == env33243) = true)

end H12CloudChart1