import H12CloudChart1Data081

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity20731 : scanCanonicalize (H12AffineFastState.compose env20731 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20731 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16400,32041,1025,29788,4161,21793,17,21763,8193,65,10589,5392,17664,2421,1365,21792,257,21793,16465,513]

theorem envBound20732 : H12AffineFastState.Bounded env20732 := by
  intro p hp
  have h : env20732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20731_20732 : H12AffineEnvironment.transform 14 29789 env20731 = env20732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20731 == env20732) = true)

def env20733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound20733 : H12AffineFastState.Bounded env20733 := by
  intro p hp
  have h : env20733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20317_20733 : H12AffineEnvironment.transform 26 30393345 env20317 = env20733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env20317 == env20733) = true)

def env20734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound20734 : H12AffineFastState.Bounded env20734 := by
  intro p hp
  have h : env20734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20733_20734 : H12AffineEnvironment.transform 18 1024 env20733 = env20734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20733 == env20734) = true)

theorem identity20734 : scanCanonicalize (H12AffineFastState.compose env20734 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874365) := by decide +kernel

theorem selectedBound20734 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874365,8328,65,4237692,10939889,10507600,8830976,453996,15076541,256,2534864,2509940,510651]

theorem envBound20735 : H12AffineFastState.Bounded env20735 := by
  intro p hp
  have h : env20735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20734_20735 : H12AffineEnvironment.transform 23 8874365 env20734 = env20735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874365 env20734 == env20735) = true)

def env20736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,8388608,8874365,8328,65,4237692,8393985,8826272,8830976,453996,12645453,256,21792,46212,510651]

theorem envBound20736 : H12AffineFastState.Bounded env20736 := by
  intro p hp
  have h : env20736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20735_20736 : H12AffineEnvironment.transform 20 456944 env20735 = env20736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env20735 == env20736) = true)

def env20737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,98781,8328,65,4237692,458145,17664,10400,453996,4594925,256,21792,46212,510651]

theorem envBound20737 : H12AffineFastState.Bounded env20737 := by
  intro p hp
  have h : env20737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20736_20737 : H12AffineEnvironment.transform 22 452768 env20736 = env20737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env20736 == env20737) = true)

def env20738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,98781,8328,65,295420,458145,17664,10400,453996,144493,256,21792,46212,510651]

theorem envBound20738 : H12AffineFastState.Bounded env20738 := by
  intro p hp
  have h : env20738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20737_20738 : H12AffineEnvironment.transform 21 272512 env20737 = env20738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20737 == env20738) = true)

theorem identity20738 : scanCanonicalize (H12AffineFastState.compose env20738 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound20738 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456944,272512,452768,21762,8328,65,295420,458145,17664,10400,453996,144493,256,21792,46212,400996]

theorem envBound20739 : H12AffineFastState.Bounded env20739 := by
  intro p hp
  have h : env20739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20738_20739 : H12AffineEnvironment.transform 15 54495 env20738 = env20739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env20738 == env20739) = true)

def env20740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456824,272392,452648,21762,8192,65,295284,458025,17664,10280,453996,144493,256,21792,46092,400996]

theorem envBound20740 : H12AffineFastState.Bounded env20740 := by
  intro p hp
  have h : env20740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20739_20740 : H12AffineEnvironment.transform 6 8 env20739 = env20740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20739 == env20740) = true)

theorem identity20740 : scanCanonicalize (H12AffineFastState.compose env20740 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 37989) := by decide +kernel

theorem selectedBound20740 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env20741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,37989,262144,1024,32769,289821,272392,293965,21762,8192,65,295284,289100,17664,10280,293129,40968,256,21792,46092,297473]

theorem envBound20741 : H12AffineFastState.Bounded env20741 := by
  intro p hp
  have h : env20741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20740_20741 : H12AffineEnvironment.transform 16 37989 env20740 = env20741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37989 env20740 == env20741) = true)

theorem identity20741 : scanCanonicalize (H12AffineFastState.compose env20741 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64604) := by decide +kernel

theorem selectedBound20741 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env20742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,37989,64604,1024,32769,36929,54356,32785,21762,8192,65,32040,38160,17664,10280,34133,40968,256,21792,46092,30301]

theorem envBound20742 : H12AffineFastState.Bounded env20742 := by
  intro p hp
  have h : env20742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20741_20742 : H12AffineEnvironment.transform 17 64604 env20741 = env20742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64604 env20741 == env20742) = true)

theorem identity20742 : scanCanonicalize (H12AffineFastState.compose env20742 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound20742 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,16741,10588,1024,21761,17729,340,21777,21762,8192,65,32040,16400,17664,10280,20565,29960,256,21792,24844,30301]

theorem envBound20743 : H12AffineFastState.Bounded env20743 := by
  intro p hp
  have h : env20743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20742_20743 : H12AffineEnvironment.transform 14 21760 env20742 = env20743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env20742 == env20743) = true)

theorem identity20743 : scanCanonicalize (H12AffineFastState.compose env20743 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20743 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,21760,343,16741,2421,1024,21761,17729,340,21777,21762,41,65,23809,16400,17664,2049,20565,21793,256,21792,16677,22132]

theorem envBound20744 : H12AffineFastState.Bounded env20744 := by
  intro p hp
  have h : env20744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20743_20744 : H12AffineEnvironment.transform 12 41 env20743 = env20744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20743 == env20744) = true)

theorem identity20744 : scanCanonicalize (H12AffineFastState.compose env20744 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound20744 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env20745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,41,16384,18805,343,16741,2421,1024,18804,17729,340,18788,18807,41,65,16756,16400,17664,2049,19488,18772,256,18773,16677,18945]

theorem envBound20745 : H12AffineFastState.Bounded env20745 := by
  intro p hp
  have h : env20745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20744_20745 : H12AffineEnvironment.transform 11 3189 env20744 = env20745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env20744 == env20745) = true)

theorem identity20745 : scanCanonicalize (H12AffineFastState.compose env20745 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound20745 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,41,2128,293,343,2357,2421,1024,292,3345,340,308,295,41,65,2340,2112,3408,2049,1136,260,256,261,2421,593]

theorem envBound20746 : H12AffineFastState.Bounded env20746 := by
  intro p hp
  have h : env20746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20745_20746 : H12AffineEnvironment.transform 13 2128 env20745 = env20746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env20745 == env20746) = true)

theorem identity20746 : scanCanonicalize (H12AffineFastState.compose env20746 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20746 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env20747 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,41,2049,293,262,2357,2340,1024,292,3345,261,308,295,41,16,2340,2065,3329,2049,1057,260,256,261,2340,512]

theorem envBound20747 : H12AffineFastState.Bounded env20747 := by
  intro p hp
  have h : env20747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20746_20747 : H12AffineEnvironment.transform 5 17 env20746 = env20747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20746 == env20747) = true)

theorem identity20747 : scanCanonicalize (H12AffineFastState.compose env20747 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound20747 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20748 : List Nat := [2,4,8,16,32,17,8,15,512,1024,2048,3108,41,2049,42,9,2106,2091,1024,43,3102,10,59,40,41,16,2091,2065,3086,2049,1057,11,15,10,2091,512]

theorem envBound20748 : H12AffineFastState.Bounded env20748 := by
  intro p hp
  have h : env20748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20747_20748 : H12AffineEnvironment.transform 7 15 env20747 = env20748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env20747 == env20748) = true)

theorem identity20748 : scanCanonicalize (H12AffineFastState.compose env20748 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20749 : List Nat := [2,4,8,16,0,17,8,15,512,1024,2048,3076,9,2049,10,9,2074,2059,1024,11,3102,10,27,8,9,16,2059,2065,3086,2049,1025,11,15,10,2059,512]

theorem envBound20749 : H12AffineFastState.Bounded env20749 := by
  intro p hp
  have h : env20749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20748_20749 : H12AffineEnvironment.transform 4 0 env20748 = env20749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20748 == env20749) = true)

def env20750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456825,272393,452649,21762,8193,65,295285,458024,17664,10281,453996,144493,256,21792,46093,400996]

theorem envBound20750 : H12AffineFastState.Bounded env20750 := by
  intro p hp
  have h : env20750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20739_20750 : H12AffineEnvironment.transform 6 9 env20739 = env20750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20739 == env20750) = true)

theorem identity20750 : scanCanonicalize (H12AffineFastState.compose env20750 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound20750 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env20751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1024,32769,165200,21792,169216,21762,8193,65,64604,163841,17664,10281,168005,144493,256,21792,46093,156493]

theorem envBound20751 : H12AffineFastState.Bounded env20751 := by
  intro p hp
  have h : env20751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20750_20751 : H12AffineEnvironment.transform 17 32041 env20750 = env20751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env20750 == env20751) = true)

theorem identity20751 : scanCanonicalize (H12AffineFastState.compose env20751 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20751 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env20752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,131072,32041,1024,8460,140381,21792,144397,21762,8193,65,23889,139532,17664,10281,143688,144493,256,21792,5376,156493]

theorem envBound20752 : H12AffineFastState.Bounded env20752 := by
  intro p hp
  have h : env20752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20751_20752 : H12AffineEnvironment.transform 14 8461 env20751 = env20752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env20751 == env20752) = true)

theorem identity20752 : scanCanonicalize (H12AffineFastState.compose env20752 (packedSelected [16,17,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound20752 : packedSelected [16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env20753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,24861,32041,1024,8460,17728,21792,21776,21762,8193,65,23889,16401,17664,10281,20565,21872,256,21792,5376,592]

theorem envBound20753 : H12AffineFastState.Bounded env20753 := by
  intro p hp
  have h : env20753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20752_20753 : H12AffineEnvironment.transform 16 24861 env20752 = env20753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env20752 == env20753) = true)

theorem identity20753 : scanCanonicalize (H12AffineFastState.compose env20753 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20753 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20754 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29962,24861,32041,1024,8460,17681,21792,21776,21762,8193,16,23808,16401,17664,10281,20484,21793,256,21792,5376,513]

theorem envBound20754 : H12AffineFastState.Bounded env20754 := by
  intro p hp
  have h : env20754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20753_20754 : H12AffineEnvironment.transform 5 17 env20753 = env20754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20753 == env20754) = true)

theorem identity20754 : scanCanonicalize (H12AffineFastState.compose env20754 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20754 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20755 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,21511,16400,23588,1024,1,17681,21792,21776,21762,268,16,23808,16401,17664,2340,20484,21793,256,21792,5376,513]

theorem envBound20755 : H12AffineFastState.Bounded env20755 := by
  intro p hp
  have h : env20755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20754_20755 : H12AffineEnvironment.transform 12 269 env20754 = env20755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20754 == env20755) = true)

def env20756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,98781,8328,65,295421,458145,17664,10400,453996,144492,256,21792,46212,510651]

theorem envBound20756 : H12AffineFastState.Bounded env20756 := by
  intro p hp
  have h : env20756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20737_20756 : H12AffineEnvironment.transform 21 272513 env20737 = env20756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20737 == env20756) = true)

theorem identity20756 : scanCanonicalize (H12AffineFastState.compose env20756 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound20756 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115871,201966,120015,98781,8328,65,245138,115150,17664,10400,119043,144492,256,21792,46212,63188]

theorem envBound20757 : H12AffineFastState.Bounded env20757 := by
  intro p hp
  have h : env20757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20756_20757 : H12AffineEnvironment.transform 17 212079 env20756 = env20757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env20756 == env20757) = true)

def env20758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115871,120062,120015,98781,8328,65,97666,115150,17664,10400,119043,62588,256,21792,46212,63188]

theorem envBound20758 : H12AffineFastState.Bounded env20758 := by
  intro p hp
  have h : env20758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20757_20758 : H12AffineEnvironment.transform 16 49168 env20757 = env20758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env20757 == env20758) = true)

theorem identity20758 : scanCanonicalize (H12AffineFastState.compose env20758 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20758 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env20759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,65536,49168,122226,1024,32769,115871,120062,120015,98781,389,65,89231,115150,17664,2477,119043,54641,256,21792,38281,55257]

theorem envBound20759 : H12AffineFastState.Bounded env20759 := by
  intro p hp
  have h : env20759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20758_20759 : H12AffineEnvironment.transform 12 269 env20758 = env20759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20758 == env20759) = true)

theorem identity20759 : scanCanonicalize (H12AffineFastState.compose env20759 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20759 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env20760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,33111,49168,23589,1024,32769,17864,21929,21912,138,389,65,56792,16537,17664,2477,20564,54641,256,21792,38281,55257]

theorem envBound20760 : H12AffineFastState.Bounded env20760 := by
  intro p hp
  have h : env20760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20759_20760 : H12AffineEnvironment.transform 15 33111 env20759 = env20760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20759 == env20760) = true)

theorem identity20760 : scanCanonicalize (H12AffineFastState.compose env20760 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20760 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env20761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33111,49168,23589,1024,32769,17728,21793,21776,2,269,65,56656,16401,17664,2341,20564,54641,256,21792,38145,55121]

theorem envBound20761 : H12AffineFastState.Bounded env20761 := by
  intro p hp
  have h : env20761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20760_20761 : H12AffineEnvironment.transform 6 8 env20760 = env20761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20760 == env20761) = true)

theorem identity20761 : scanCanonicalize (H12AffineFastState.compose env20761 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,33111,38161,2340,1024,32769,4161,32,17,2,269,65,34897,5392,4097,2341,1365,32880,256,33,38145,33360]

theorem envBound20762 : H12AffineFastState.Bounded env20762 := by
  intro p hp
  have h : env20762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20761_20762 : H12AffineEnvironment.transform 13 5377 env20761 = env20762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20761 == env20762) = true)

theorem identity20762 : scanCanonicalize (H12AffineFastState.compose env20762 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound20762 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env20763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,112,295,5473,2340,1024,113,4161,32,17,2,269,65,2081,5392,4097,2341,1365,0,256,33,5489,544]

theorem envBound20763 : H12AffineFastState.Bounded env20763 := by
  intro p hp
  have h : env20763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20762_20763 : H12AffineEnvironment.transform 14 112 env20762 = env20763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env20762 == env20763) = true)

theorem identity20763 : scanCanonicalize (H12AffineFastState.compose env20763 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20763 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20764 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,269,5377,0,295,5393,2340,1024,1,4145,32,17,2,269,49,2081,5392,4097,2341,1317,0,256,33,5377,544]

theorem envBound20764 : H12AffineFastState.Bounded env20764 := by
  intro p hp
  have h : env20764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20763_20764 : H12AffineEnvironment.transform 5 48 env20763 = env20764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20763 == env20764) = true)

theorem identity20764 : scanCanonicalize (H12AffineFastState.compose env20764 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20764 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20765 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,0,263,5393,2308,1024,1,4113,0,17,2,269,17,2049,5392,4097,2309,1285,0,256,1,5377,512]

theorem envBound20765 : H12AffineFastState.Bounded env20765 := by
  intro p hp
  have h : env20765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20764_20765 : H12AffineEnvironment.transform 4 0 env20764 = env20765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20764 == env20765) = true)

theorem identity20765 : scanCanonicalize (H12AffineFastState.compose env20765 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20765 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20766 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,0,2,5140,2049,1024,1,4113,0,17,2,8,17,2049,5141,4097,2048,1024,0,5,1,5124,512]

theorem envBound20766 : H12AffineFastState.Bounded env20766 := by
  intro p hp
  have h : env20766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20765_20766 : H12AffineEnvironment.transform 7 5 env20765 = env20766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20765 == env20766) = true)

def env20767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115871,120063,120015,98781,8328,65,97667,115150,17664,10400,119043,62589,256,21792,46212,63188]

theorem envBound20767 : H12AffineFastState.Bounded env20767 := by
  intro p hp
  have h : env20767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20757_20767 : H12AffineEnvironment.transform 16 49169 env20757 = env20767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env20757 == env20767) = true)

theorem identity20767 : scanCanonicalize (H12AffineFastState.compose env20767 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20767 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env20768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49169,32041,1024,32769,17864,21928,21912,138,8328,65,64724,16537,17664,10400,20564,62589,256,21792,46212,63188]

theorem envBound20768 : H12AffineFastState.Bounded env20768 := by
  intro p hp
  have h : env20768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20767_20768 : H12AffineEnvironment.transform 15 33111 env20767 = env20768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20767 == env20768) = true)

theorem identity20768 : scanCanonicalize (H12AffineFastState.compose env20768 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20768 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env20769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,33111,49169,23668,1024,32769,17864,21928,21912,138,469,65,56713,16537,17664,2557,20564,54560,256,21792,38361,55177]

theorem envBound20769 : H12AffineFastState.Bounded env20769 := by
  intro p hp
  have h : env20769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20768_20769 : H12AffineEnvironment.transform 12 349 env20768 = env20769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20768 == env20769) = true)

theorem identity20769 : scanCanonicalize (H12AffineFastState.compose env20769 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound20769 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env20770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,32768,33111,38296,2557,1024,32769,4161,33,17,138,469,65,34816,5392,4233,2557,1501,32937,256,169,38361,33280]

theorem envBound20770 : H12AffineFastState.Bounded env20770 := by
  intro p hp
  have h : env20770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20769_20770 : H12AffineEnvironment.transform 13 5513 env20769 = env20770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20769 == env20770) = true)

theorem identity20770 : scanCanonicalize (H12AffineFastState.compose env20770 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20770 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env20771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,342,5529,2557,1024,0,4161,33,17,138,469,65,2049,5392,4233,2557,1501,168,256,169,5592,513]

theorem envBound20771 : H12AffineFastState.Bounded env20771 := by
  intro p hp
  have h : env20771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20770_20771 : H12AffineEnvironment.transform 14 1 env20770 = env20771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20770 == env20771) = true)

theorem identity20771 : scanCanonicalize (H12AffineFastState.compose env20771 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20771 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20772 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,1,342,5441,2341,1024,0,4161,33,17,82,269,65,2049,5392,4177,2341,1285,112,256,113,5376,513]

theorem envBound20772 : H12AffineFastState.Bounded env20772 := by
  intro p hp
  have h : env20772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20771_20772 : H12AffineEnvironment.transform 6 88 env20771 = env20772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20771 == env20772) = true)

theorem identity20772 : scanCanonicalize (H12AffineFastState.compose env20772 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1605) := by decide +kernel

theorem selectedBound20772 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20773 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1605,349,788,1,342,772,2341,1024,0,1540,33,17,82,269,65,2049,853,1556,2341,1285,112,256,113,837,513]

theorem envBound20773 : H12AffineFastState.Bounded env20773 := by
  intro p hp
  have h : env20773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20772_20773 : H12AffineEnvironment.transform 11 1605 env20772 = env20773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1605 env20772 == env20773) = true)

theorem identity20773 : scanCanonicalize (H12AffineFastState.compose env20773 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound20773 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20774 : List Nat := [2,4,8,16,32,64,88,256,512,1024,773,1605,349,788,1,342,772,544,1024,0,1540,33,17,82,269,65,772,853,1556,544,1285,112,256,113,837,513]

theorem envBound20774 : H12AffineFastState.Bounded env20774 := by
  intro p hp
  have h : env20774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20773_20774 : H12AffineEnvironment.transform 10 773 env20773 = env20774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env20773 == env20774) = true)

theorem identity20774 : scanCanonicalize (H12AffineFastState.compose env20774 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound20774 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20775 : List Nat := [2,4,8,16,32,64,88,256,512,368,773,821,349,788,1,342,772,544,368,0,884,33,17,82,269,65,772,853,868,544,117,112,256,113,837,513]

theorem envBound20775 : H12AffineFastState.Bounded env20775 := by
  intro p hp
  have h : env20775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20774_20775 : H12AffineEnvironment.transform 9 368 env20774 = env20775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env20774 == env20775) = true)

theorem identity20775 : scanCanonicalize (H12AffineFastState.compose env20775 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound20775 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env20776 : List Nat := [2,4,8,16,32,64,88,52,512,68,561,513,105,544,1,98,560,544,68,0,576,33,17,82,57,65,560,609,592,544,117,112,52,113,625,513]

theorem envBound20776 : H12AffineFastState.Bounded env20776 := by
  intro p hp
  have h : env20776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20775_20776 : H12AffineEnvironment.transform 7 52 env20775 = env20776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env20775 == env20776) = true)

theorem identity20776 : scanCanonicalize (H12AffineFastState.compose env20776 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20776 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env20777 : List Nat := [2,4,8,16,32,48,40,52,512,52,561,513,25,544,1,18,560,544,52,0,560,33,17,34,57,49,560,529,544,544,5,0,52,1,513,513]

theorem envBound20777 : H12AffineFastState.Bounded env20777 := by
  intro p hp
  have h : env20777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20776_20777 : H12AffineEnvironment.transform 5 48 env20776 = env20777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20776 == env20777) = true)

theorem identity20777 : scanCanonicalize (H12AffineFastState.compose env20777 (packedSelected [15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20777 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env20778 : List Nat := [2,4,8,16,0,16,8,20,512,20,529,513,25,512,1,18,528,512,20,0,528,1,17,2,25,17,528,529,512,512,5,0,20,1,513,513]

theorem envBound20778 : H12AffineFastState.Bounded env20778 := by
  intro p hp
  have h : env20778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20777_20778 : H12AffineEnvironment.transform 4 0 env20777 = env20778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20777 == env20778) = true)

theorem identity20778 : scanCanonicalize (H12AffineFastState.compose env20778 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20778 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20779 : List Nat := [2,4,8,1,0,1,8,5,512,5,512,513,8,512,1,3,513,512,5,0,513,1,0,2,8,0,513,512,512,512,5,0,5,1,513,513]

theorem envBound20779 : H12AffineFastState.Bounded env20779 := by
  intro p hp
  have h : env20779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20778_20779 : H12AffineEnvironment.transform 3 1 env20778 = env20779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20778 == env20779) = true)

theorem identity20779 : scanCanonicalize (H12AffineFastState.compose env20779 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20779 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20780 : List Nat := [2,4,8,1,0,1,8,5,0,5,0,1,8,0,1,3,1,0,5,0,1,1,0,2,8,0,1,0,0,0,5,0,5,1,1,1]

theorem envBound20780 : H12AffineFastState.Bounded env20780 := by
  intro p hp
  have h : env20780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20779_20780 : H12AffineEnvironment.transform 8 0 env20779 = env20780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20779 == env20780) = true)

theorem identity20780 : scanCanonicalize (H12AffineFastState.compose env20780 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20781 : List Nat := [2,4,2,1,0,1,2,5,0,5,0,1,2,0,1,3,1,0,5,0,1,1,0,2,2,0,1,0,0,0,5,0,5,1,1,1]

theorem envBound20781 : H12AffineFastState.Bounded env20781 := by
  intro p hp
  have h : env20781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20780_20781 : H12AffineEnvironment.transform 2 2 env20780 = env20781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20780 == env20781) = true)

def env20782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,98780,8328,65,4237692,458144,17665,10401,453996,4594924,256,21792,46212,510651]

theorem envBound20782 : H12AffineFastState.Bounded env20782 := by
  intro p hp
  have h : env20782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20736_20782 : H12AffineEnvironment.transform 22 452769 env20736 = env20782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env20736 == env20782) = true)

def env20783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,98780,8328,65,295420,458144,17665,10401,453996,144492,256,21792,46212,510651]

theorem envBound20783 : H12AffineFastState.Bounded env20783 := by
  intro p hp
  have h : env20783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20783 : H12AffineEnvironment.transform 21 272512 env20782 = env20783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20782 == env20783) = true)

theorem identity20783 : scanCanonicalize (H12AffineFastState.compose env20783 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20783 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456944,272512,452769,41431,8328,65,295420,458144,17665,10401,453996,144492,256,21792,46212,453296]

theorem envBound20784 : H12AffineFastState.Bounded env20784 := by
  intro p hp
  have h : env20784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20783_20784 : H12AffineEnvironment.transform 15 8203 env20783 = env20784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20783 == env20784) = true)

theorem identity20784 : scanCanonicalize (H12AffineFastState.compose env20784 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20784 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env20785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,262144,1024,0,424177,272512,420000,8662,8328,65,262653,425377,17665,10401,421229,144492,256,21792,13445,420529]

theorem envBound20785 : H12AffineFastState.Bounded env20785 := by
  intro p hp
  have h : env20785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20784_20785 : H12AffineEnvironment.transform 14 1 env20784 = env20785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20784 == env20785) = true)

theorem identity20785 : scanCanonicalize (H12AffineFastState.compose env20785 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound20785 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,10401,1024,0,151632,33,147457,8662,8328,65,10588,152832,17665,10401,148940,144492,256,21792,13445,147984]

theorem envBound20786 : H12AffineFastState.Bounded env20786 := by
  intro p hp
  have h : env20786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20785_20786 : H12AffineEnvironment.transform 17 10401 env20785 = env20786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20785 == env20786) = true)

theorem identity20786 : scanCanonicalize (H12AffineFastState.compose env20786 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound20786 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,25029,10401,1024,0,12693,33,8644,8662,8328,65,10588,13509,17665,10401,9225,21929,256,21792,13445,9173]

theorem envBound20787 : H12AffineFastState.Bounded env20787 := by
  intro p hp
  have h : env20787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20786_20787 : H12AffineEnvironment.transform 16 25029 env20786 = env20787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env20786 == env20787) = true)

theorem identity20787 : scanCanonicalize (H12AffineFastState.compose env20787 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20787 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,342,16536,2556,1024,0,4296,33,153,139,469,65,2049,5528,17665,2556,1364,21929,256,21792,5592,648]

theorem envBound20788 : H12AffineFastState.Bounded env20788 := by
  intro p hp
  have h : env20788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20787_20788 : H12AffineEnvironment.transform 12 349 env20787 = env20788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20787 == env20788) = true)

theorem identity20788 : scanCanonicalize (H12AffineFastState.compose env20788 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20788 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env20789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,1,342,5392,2556,1024,0,4296,33,153,139,469,65,2049,5528,4233,2556,1364,33,256,168,5592,648]

theorem envBound20789 : H12AffineFastState.Bounded env20789 := by
  intro p hp
  have h : env20789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20788_20789 : H12AffineEnvironment.transform 13 5512 env20788 = env20789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20788 == env20789) = true)

theorem identity20789 : scanCanonicalize (H12AffineFastState.compose env20789 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20789 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4160,33,17,3,349,65,2049,5392,4097,2420,1364,33,256,32,5456,512]

theorem envBound20790 : H12AffineFastState.Bounded env20790 := by
  intro p hp
  have h : env20790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20789_20790 : H12AffineEnvironment.transform 6 8 env20789 = env20790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20789 == env20790) = true)

theorem identity20790 : scanCanonicalize (H12AffineFastState.compose env20790 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2618) := by decide +kernel

theorem selectedBound20790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2618,349,3898,1,342,3882,2420,1024,0,2682,33,17,3,349,65,2049,3882,2619,2420,1364,33,256,32,3946,512]

theorem envBound20791 : H12AffineFastState.Bounded env20791 := by
  intro p hp
  have h : env20791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20790_20791 : H12AffineEnvironment.transform 11 2618 env20790 = env20791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2618 env20790 == env20791) = true)

theorem identity20791 : scanCanonicalize (H12AffineFastState.compose env20791 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20791 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20792 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2618,300,3898,1,295,3882,2309,1024,0,2571,33,17,3,300,48,2049,3882,2619,2309,1317,33,256,32,3867,512]

theorem envBound20792 : H12AffineFastState.Bounded env20792 := by
  intro p hp
  have h : env20792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20791_20792 : H12AffineEnvironment.transform 5 49 env20791 = env20792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20791 == env20792) = true)

theorem identity20792 : scanCanonicalize (H12AffineFastState.compose env20792 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound20792 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20793 : List Nat := [2,4,8,16,32,49,8,256,512,1024,1329,1803,300,523,1,295,539,1076,1024,0,1850,33,17,3,300,48,1328,539,1802,1076,1317,33,256,32,554,512]

theorem envBound20793 : H12AffineFastState.Bounded env20793 := by
  intro p hp
  have h : env20793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20792_20793 : H12AffineEnvironment.transform 10 1329 env20792 = env20793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env20792 == env20793) = true)

theorem identity20793 : scanCanonicalize (H12AffineFastState.compose env20793 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound20793 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env20794 : List Nat := [2,4,8,16,32,49,8,256,270,1024,1329,1029,300,261,1,295,277,1076,1024,0,1076,33,17,3,300,48,1328,277,1028,1076,1317,33,256,32,292,270]

theorem envBound20794 : H12AffineFastState.Bounded env20794 := by
  intro p hp
  have h : env20794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20793_20794 : H12AffineEnvironment.transform 8 270 env20793 = env20794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env20793 == env20794) = true)

theorem identity20794 : scanCanonicalize (H12AffineFastState.compose env20794 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound20794 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env20795 : List Nat := [2,4,8,16,32,49,8,256,270,21,292,16,300,261,1,295,277,33,21,0,33,33,17,3,300,48,293,277,17,33,304,33,256,32,292,270]

theorem envBound20795 : H12AffineFastState.Bounded env20795 := by
  intro p hp
  have h : env20795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20794_20795 : H12AffineEnvironment.transform 9 21 env20794 = env20795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20794 == env20795) = true)

theorem identity20795 : scanCanonicalize (H12AffineFastState.compose env20795 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20795 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20796 : List Nat := [2,4,8,16,32,49,8,36,42,21,0,16,8,33,1,3,49,33,21,0,33,33,17,3,8,48,1,49,17,33,20,33,36,32,0,42]

theorem envBound20796 : H12AffineFastState.Bounded env20796 := by
  intro p hp
  have h : env20796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20795_20796 : H12AffineEnvironment.transform 7 36 env20795 = env20796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20795 == env20796) = true)

theorem identity20796 : scanCanonicalize (H12AffineFastState.compose env20796 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20797 : List Nat := [2,4,8,16,0,17,8,4,10,21,0,16,8,1,1,3,17,1,21,0,1,1,17,3,8,16,1,17,17,1,20,1,4,0,0,10]

theorem envBound20797 : H12AffineFastState.Bounded env20797 := by
  intro p hp
  have h : env20797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20796_20797 : H12AffineEnvironment.transform 4 0 env20796 = env20797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20796 == env20797) = true)

theorem identity20797 : scanCanonicalize (H12AffineFastState.compose env20797 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound20797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20798 : List Nat := [2,4,8,5,0,4,8,4,10,0,0,5,8,1,1,3,4,1,0,0,1,1,4,3,8,5,1,4,4,1,1,1,4,0,0,10]

theorem envBound20798 : H12AffineFastState.Bounded env20798 := by
  intro p hp
  have h : env20798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20797_20798 : H12AffineEnvironment.transform 3 5 env20797 = env20798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env20797 == env20798) = true)

theorem identity20798 : scanCanonicalize (H12AffineFastState.compose env20798 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20798 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20799 : List Nat := [2,4,0,5,0,4,0,4,2,0,0,5,0,1,1,3,4,1,0,0,1,1,4,3,0,5,1,4,4,1,1,1,4,0,0,2]

theorem envBound20799 : H12AffineFastState.Bounded env20799 := by
  intro p hp
  have h : env20799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20798_20799 : H12AffineEnvironment.transform 2 0 env20798 = env20799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20798 == env20799) = true)

def env20800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,98780,8328,65,295421,458144,17665,10401,453996,144493,256,21792,46212,510651]

theorem envBound20800 : H12AffineFastState.Bounded env20800 := by
  intro p hp
  have h : env20800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20800 : H12AffineEnvironment.transform 21 272513 env20782 = env20800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20782 == env20800) = true)

theorem identity20800 : scanCanonicalize (H12AffineFastState.compose env20800 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound20800 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,77898,254011,73755,98780,8328,65,215367,79130,17665,10401,75222,144493,256,21792,46212,513]

theorem envBound20801 : H12AffineFastState.Bounded env20801 := by
  intro p hp
  have h : env20801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20800_20801 : H12AffineEnvironment.transform 17 247994 env20800 = env20801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env20800 == env20801) = true)

def env20802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77898,254011,73755,98644,8192,65,215367,79130,17665,10281,75102,144493,256,21792,46092,513]

theorem envBound20802 : H12AffineFastState.Bounded env20802 := by
  intro p hp
  have h : env20802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20801_20802 : H12AffineEnvironment.transform 6 8 env20801 = env20802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20801 == env20802) = true)

theorem identity20802 : scanCanonicalize (H12AffineFastState.compose env20802 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound20802 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,43049,1024,32769,77898,32800,73755,98644,8192,65,10588,79130,17665,10281,75102,87158,256,21792,46092,513]

theorem envBound20803 : H12AffineFastState.Bounded env20803 := by
  intro p hp
  have h : env20803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20802_20803 : H12AffineEnvironment.transform 16 90139 env20802 = env20803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env20802 == env20803) = true)

theorem identity20803 : scanCanonicalize (H12AffineFastState.compose env20803 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound20803 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,46108,43049,1024,32769,58445,32800,62492,21843,8192,65,10588,57629,17665,10281,61785,32881,256,21792,46092,513]

theorem envBound20804 : H12AffineFastState.Bounded env20804 := by
  intro p hp
  have h : env20804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20803_20804 : H12AffineEnvironment.transform 15 54279 env20803 = env20804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env20803 == env20804) = true)

theorem identity20804 : scanCanonicalize (H12AffineFastState.compose env20804 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 20836) := by decide +kernel

theorem selectedBound20804 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env20805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20836,1379,25976,31053,1024,20837,13609,20804,9592,21843,8192,65,10588,12409,17665,10281,8253,20757,256,21792,25960,513]

theorem envBound20805 : H12AffineFastState.Bounded env20805 := by
  intro p hp
  have h : env20805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20804_20805 : H12AffineEnvironment.transform 14 20836 env20804 = env20805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20836 env20804 == env20805) = true)

theorem identity20805 : scanCanonicalize (H12AffineFastState.compose env20805 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound20805 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS < 2^1333 := by decide +kernel

def env20806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,16384,20836,1379,16401,23588,1024,20837,4160,20804,17,21843,1385,65,3125,5392,17665,3392,1364,20757,256,21792,16385,513]

theorem envBound20806 : H12AffineFastState.Bounded env20806 := by
  intro p hp
  have h : env20806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20805_20806 : H12AffineEnvironment.transform 12 1385 env20805 = env20806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env20805 == env20806) = true)

theorem identity20806 : scanCanonicalize (H12AffineFastState.compose env20806 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20806 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20807 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,16384,20836,262,16401,22593,101,20837,4160,20804,17,20790,268,65,2128,4469,16740,2341,305,20757,256,20805,16385,513]

theorem envBound20807 : H12AffineFastState.Bounded env20807 := by
  intro p hp
  have h : env20807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20806_20807 : H12AffineEnvironment.transform 9 101 env20806 = env20807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20806 == env20807) = true)

theorem identity20807 : scanCanonicalize (H12AffineFastState.compose env20807 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound20807 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20808 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4161,293,262,4176,2048,101,292,4160,261,17,375,268,65,2128,4469,4389,2341,305,340,256,260,4160,513]

theorem envBound20808 : H12AffineFastState.Bounded env20808 := by
  intro p hp
  have h : env20808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20807_20808 : H12AffineEnvironment.transform 13 4161 env20807 = env20808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env20807 == env20808) = true)

theorem identity20808 : scanCanonicalize (H12AffineFastState.compose env20808 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20808 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env20809 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4113,293,262,4096,2048,53,292,4112,261,17,295,268,17,2048,4389,4389,2341,305,260,256,260,4112,513]

theorem envBound20809 : H12AffineFastState.Bounded env20809 := by
  intro p hp
  have h : env20809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20808_20809 : H12AffineEnvironment.transform 5 16 env20808 = env20809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20808 == env20809) = true)

def env20810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77898,254011,73755,98645,8193,65,215367,79130,17665,10280,75103,144493,256,21792,46093,513]

theorem envBound20810 : H12AffineFastState.Bounded env20810 := by
  intro p hp
  have h : env20810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20801_20810 : H12AffineEnvironment.transform 6 9 env20801 = env20810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20801 == env20810) = true)

theorem identity20810 : scanCanonicalize (H12AffineFastState.compose env20810 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound20810 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,77898,33,73755,98645,8193,65,43357,79130,17665,10280,75103,119927,256,21792,46093,513]

theorem envBound20811 : H12AffineFastState.Bounded env20811 := by
  intro p hp
  have h : env20811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20810_20811 : H12AffineEnvironment.transform 16 122906 env20810 = env20811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env20810 == env20811) = true)

theorem identity20811 : scanCanonicalize (H12AffineFastState.compose env20811 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20811 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env20812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4161,33,16,41310,8193,65,43357,5393,17665,10280,1364,62588,256,21792,46093,513]

theorem envBound20812 : H12AffineFastState.Bounded env20812 := by
  intro p hp
  have h : env20812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20811_20812 : H12AffineEnvironment.transform 15 8203 env20811 = env20812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20811 == env20812) = true)

theorem identity20812 : scanCanonicalize (H12AffineFastState.compose env20812 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20812 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49169,2340,1024,32769,4161,33,16,32851,268,65,34896,5393,17665,2341,1364,54641,256,21792,38144,513]

theorem envBound20813 : H12AffineFastState.Bounded env20813 := by
  intro p hp
  have h : env20813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20812_20813 : H12AffineEnvironment.transform 12 269 env20812 = env20813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20812 == env20813) = true)

theorem identity20813 : scanCanonicalize (H12AffineFastState.compose env20813 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound20813 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,262,38209,2340,1024,32769,4161,33,16,32851,268,65,34896,5393,4177,2341,1364,32801,256,112,38144,513]

theorem envBound20814 : H12AffineFastState.Bounded env20814 := by
  intro p hp
  have h : env20814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20813_20814 : H12AffineEnvironment.transform 13 5456 env20813 = env20814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env20813 == env20814) = true)

theorem identity20814 : scanCanonicalize (H12AffineFastState.compose env20814 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound20814 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,80,262,5393,2340,1024,81,4161,33,16,3,268,65,2048,5393,4177,2341,1364,113,256,112,5456,513]

theorem envBound20815 : H12AffineFastState.Bounded env20815 := by
  intro p hp
  have h : env20815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20814_20815 : H12AffineEnvironment.transform 14 80 env20814 = env20815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env20814 == env20815) = true)

theorem identity20815 : scanCanonicalize (H12AffineFastState.compose env20815 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound20815 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env20816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2144,269,3376,80,262,3441,2340,1024,81,2081,33,16,3,268,65,2048,3441,2097,2341,1364,113,256,112,3376,513]

theorem envBound20816 : H12AffineFastState.Bounded env20816 := by
  intro p hp
  have h : env20816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20815_20816 : H12AffineEnvironment.transform 11 2144 env20815 = env20816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env20815 == env20816) = true)

theorem identity20816 : scanCanonicalize (H12AffineFastState.compose env20816 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 352) := by decide +kernel

theorem selectedBound20816 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20817 : List Nat := [2,4,8,16,32,64,9,256,512,352,2048,2144,269,2128,80,262,2065,2340,352,81,2081,33,16,3,268,65,2048,2065,2097,2341,52,113,256,112,2128,513]

theorem envBound20817 : H12AffineFastState.Bounded env20817 := by
  intro p hp
  have h : env20817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20816_20817 : H12AffineEnvironment.transform 9 352 env20816 = env20817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 352 env20816 == env20817) = true)

theorem identity20817 : scanCanonicalize (H12AffineFastState.compose env20817 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20817 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20818 : List Nat := [2,4,8,16,1,64,9,256,512,321,2048,2113,269,2128,80,262,2065,2309,321,81,2048,0,16,3,268,65,2048,2065,2064,2308,21,80,256,81,2128,513]

theorem envBound20818 : H12AffineFastState.Bounded env20818 := by
  intro p hp
  have h : env20818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20817_20818 : H12AffineEnvironment.transform 4 1 env20817 = env20818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20817 == env20818) = true)

theorem identity20818 : scanCanonicalize (H12AffineFastState.compose env20818 (packedSelected [3,5,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20818 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env20819 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,2064,269,2049,1,262,2065,2309,272,0,2048,0,16,3,268,16,2048,2065,2064,2308,21,1,256,0,2049,513]

theorem envBound20819 : H12AffineFastState.Bounded env20819 := by
  intro p hp
  have h : env20819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20818_20819 : H12AffineEnvironment.transform 5 17 env20818 = env20819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20818 == env20819) = true)

theorem identity20819 : scanCanonicalize (H12AffineFastState.compose env20819 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound20819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20820 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,276,269,261,1,262,277,1,272,0,260,0,16,3,268,16,260,277,276,0,21,1,256,0,261,513]

theorem envBound20820 : H12AffineFastState.Bounded env20820 := by
  intro p hp
  have h : env20820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20819_20820 : H12AffineEnvironment.transform 10 260 env20819 = env20820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env20819 == env20820) = true)

def env20821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,8388608,8874365,8328,65,4237692,8393984,8826273,8830976,453996,12645452,256,21793,46213,510651]

theorem envBound20821 : H12AffineFastState.Bounded env20821 := by
  intro p hp
  have h : env20821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20735_20821 : H12AffineEnvironment.transform 20 456945 env20735 = env20821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env20735 == env20821) = true)

def env20822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,98781,8328,65,4237692,458144,17665,10400,453996,4594924,256,21793,46213,510651]

theorem envBound20822 : H12AffineFastState.Bounded env20822 := by
  intro p hp
  have h : env20822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20821_20822 : H12AffineEnvironment.transform 22 452768 env20821 = env20822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env20821 == env20822) = true)

def env20823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,98781,8328,65,295420,458144,17665,10400,453996,144492,256,21793,46213,510651]

theorem envBound20823 : H12AffineFastState.Bounded env20823 := by
  intro p hp
  have h : env20823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20822_20823 : H12AffineEnvironment.transform 21 272512 env20822 = env20823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20822 == env20823) = true)

theorem identity20823 : scanCanonicalize (H12AffineFastState.compose env20823 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound20823 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58517,144612,62660,98781,8328,65,171416,57796,17665,10400,61704,144492,256,21793,46213,120543]

theorem envBound20824 : H12AffineFastState.Bounded env20824 := by
  intro p hp
  have h : env20824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20823_20824 : H12AffineEnvironment.transform 17 138340 env20823 = env20824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env20823 == env20824) = true)

def env20825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144492,62540,98645,8192,65,171280,57676,17665,10280,61704,144492,256,21793,46093,120407]

theorem envBound20825 : H12AffineFastState.Bounded env20825 := by
  intro p hp
  have h : env20825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20824_20825 : H12AffineEnvironment.transform 6 8 env20824 = env20825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20824 == env20825) = true)

theorem identity20825 : scanCanonicalize (H12AffineFastState.compose env20825 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 114738) := by decide +kernel

theorem selectedBound20825 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env20826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,114738,121942,1024,32769,58397,128094,62540,98645,8192,65,89378,57676,17665,10280,61704,128094,256,21793,46093,120407]

theorem envBound20826 : H12AffineFastState.Bounded env20826 := by
  intro p hp
  have h : env20826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20825_20826 : H12AffineEnvironment.transform 16 114738 env20825 = env20826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114738 env20825 == env20826) = true)

theorem identity20826 : scanCanonicalize (H12AffineFastState.compose env20826 (packedSelected [4,7,8,9,10,11,12,15,16,20,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound20826 : packedSelected [4,7,8,9,10,11,12,15,16,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env20827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,65536,79130,76158,1024,29993,4405,65910,356,95357,8192,65,89378,5220,17665,10280,1056,65910,256,21793,16677,74623]

theorem envBound20827 : H12AffineFastState.Bounded env20827 := by
  intro p hp
  have h : env20827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20826_20827 : H12AffineEnvironment.transform 14 29992 env20826 = env20827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env20826 == env20827) = true)

theorem identity20827 : scanCanonicalize (H12AffineFastState.compose env20827 (packedSelected [0,1,2,3,5,6,8,10,11,14,16,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound20827 : packedSelected [0,1,2,3,5,6,8,10,11,14,16,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env20828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,0,65536,79130,76158,1024,1,4405,65910,356,65877,8192,65,75786,5220,12329,10280,1056,65910,256,8201,13325,74623]

theorem envBound20828 : H12AffineFastState.Bounded env20828 := by
  intro p hp
  have h : env20828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20827_20828 : H12AffineEnvironment.transform 13 13608 env20827 = env20828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env20827 == env20828) = true)

theorem identity20828 : scanCanonicalize (H12AffineFastState.compose env20828 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound20828 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env20829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,0,8574,5220,2048,1024,1,4405,8200,356,8235,8192,65,2420,5220,12329,10280,1056,8200,256,8201,13325,513]

theorem envBound20829 : H12AffineFastState.Bounded env20829 := by
  intro p hp
  have h : env20829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20828_20829 : H12AffineEnvironment.transform 15 8574 env20828 = env20829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env20828 == env20829) = true)

theorem identity20829 : scanCanonicalize (H12AffineFastState.compose env20829 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound20829 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4113,0,1095,5220,2048,1024,1,4405,1329,356,1298,1337,65,2420,5220,5392,3345,1056,1329,256,1328,4404,513]

theorem envBound20830 : H12AffineFastState.Bounded env20830 := by
  intro p hp
  have h : env20830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20829_20830 : H12AffineEnvironment.transform 12 1337 env20829 = env20830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env20829 == env20830) = true)

theorem identity20830 : scanCanonicalize (H12AffineFastState.compose env20830 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20830 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20831 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,4113,0,1047,5172,2048,1024,1,4405,1329,308,1298,1337,17,2340,5172,5392,3345,1056,1329,256,1328,4404,513]

theorem envBound20831 : H12AffineFastState.Bounded env20831 := by
  intro p hp
  have h : env20831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20830_20831 : H12AffineEnvironment.transform 5 16 env20830 = env20831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20830 == env20831) = true)

theorem identity20831 : scanCanonicalize (H12AffineFastState.compose env20831 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20831 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env20832 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1053,4113,0,1047,5172,2048,1024,1,4113,1045,16,1078,1053,17,2048,5172,5172,3125,1056,1045,36,1044,4112,513]

theorem envBound20832 : H12AffineFastState.Bounded env20832 := by
  intro p hp
  have h : env20832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20831_20832 : H12AffineEnvironment.transform 7 36 env20831 = env20832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20831 == env20832) = true)

theorem identity20832 : scanCanonicalize (H12AffineFastState.compose env20832 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound20832 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env20833 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,512,1053,529,0,1047,1588,2048,1024,1,529,1045,16,1078,1053,17,2048,1588,1588,3125,1056,1045,36,1044,528,513]

theorem envBound20833 : H12AffineFastState.Bounded env20833 := by
  intro p hp
  have h : env20833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20832_20833 : H12AffineEnvironment.transform 11 512 env20832 = env20833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env20832 == env20833) = true)

theorem identity20833 : scanCanonicalize (H12AffineFastState.compose env20833 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound20833 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20834 : List Nat := [2,4,8,16,32,16,8,36,512,20,2048,512,9,529,0,3,544,2048,20,1,529,1,16,34,9,17,2048,544,544,2081,52,1,36,0,528,513]

theorem envBound20834 : H12AffineFastState.Bounded env20834 := by
  intro p hp
  have h : env20834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20833_20834 : H12AffineEnvironment.transform 9 20 env20833 = env20834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20833 == env20834) = true)

theorem identity20834 : scanCanonicalize (H12AffineFastState.compose env20834 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound20834 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env20835 : List Nat := [2,4,8,16,32,16,8,36,32,20,2048,32,9,49,0,3,0,2048,20,1,49,1,16,34,9,17,2048,0,0,2081,52,1,36,0,48,33]

theorem envBound20835 : H12AffineFastState.Bounded env20835 := by
  intro p hp
  have h : env20835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20834_20835 : H12AffineEnvironment.transform 8 32 env20834 = env20835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env20834 == env20835) = true)

theorem identity20835 : scanCanonicalize (H12AffineFastState.compose env20835 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound20835 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20836 : List Nat := [2,4,8,16,32,16,8,36,32,20,49,32,9,49,0,3,0,49,20,1,49,1,16,34,9,17,49,0,0,16,52,1,36,0,48,33]

theorem envBound20836 : H12AffineFastState.Bounded env20836 := by
  intro p hp
  have h : env20836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20835_20836 : H12AffineEnvironment.transform 10 49 env20835 = env20836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env20835 == env20836) = true)

theorem identity20836 : scanCanonicalize (H12AffineFastState.compose env20836 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20836 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20837 : List Nat := [2,4,8,16,0,16,8,4,0,20,17,0,9,17,0,3,0,17,20,1,17,1,16,2,9,17,17,0,0,16,20,1,4,0,16,1]

theorem envBound20837 : H12AffineFastState.Bounded env20837 := by
  intro p hp
  have h : env20837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20836_20837 : H12AffineEnvironment.transform 4 0 env20836 = env20837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20836 == env20837) = true)

theorem identity20837 : scanCanonicalize (H12AffineFastState.compose env20837 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20837 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20838 : List Nat := [2,4,8,1,0,1,8,4,0,5,0,0,9,0,0,3,0,0,5,1,0,1,1,2,9,0,0,0,0,1,5,1,4,0,1,1]

theorem envBound20838 : H12AffineFastState.Bounded env20838 := by
  intro p hp
  have h : env20838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20837_20838 : H12AffineEnvironment.transform 3 1 env20837 = env20838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20837 == env20838) = true)

def env20839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144493,62541,98644,8193,65,171281,57677,17665,10281,61704,144492,256,21793,46092,120406]

theorem envBound20839 : H12AffineFastState.Bounded env20839 := by
  intro p hp
  have h : env20839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20824_20839 : H12AffineEnvironment.transform 6 9 env20824 = env20839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20824 == env20839) = true)

theorem identity20839 : scanCanonicalize (H12AffineFastState.compose env20839 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20839 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env20840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,138340,1024,32769,45341,144493,41292,98644,8193,65,171281,46156,4096,10281,41993,144492,256,32,46092,99159]

theorem envBound20840 : H12AffineFastState.Bounded env20840 := by
  intro p hp
  have h : env20840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20839_20840 : H12AffineEnvironment.transform 13 5377 env20839 = env20840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20839 == env20840) = true)

theorem identity20840 : scanCanonicalize (H12AffineFastState.compose env20840 (packedSelected [1,3,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound20840 : packedSelected [1,3,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41050,131072,138340,1024,32769,45341,144493,41292,8462,8193,65,171281,46156,4096,10281,41993,144492,256,32,46092,8973]

theorem envBound20841 : H12AffineFastState.Bounded env20841 := by
  intro p hp
  have h : env20841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20840_20841 : H12AffineEnvironment.transform 15 41050 env20840 = env20841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env20840 == env20841) = true)

theorem identity20841 : scanCanonicalize (H12AffineFastState.compose env20841 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20841 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env20842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,343,131072,138340,1024,8460,4112,144493,65,8462,8193,65,146460,5441,4096,10281,1284,144492,256,32,5377,8973]

theorem envBound20842 : H12AffineFastState.Bounded env20842 := by
  intro p hp
  have h : env20842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20841_20842 : H12AffineEnvironment.transform 14 8461 env20841 = env20842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env20841 == env20842) = true)

theorem identity20842 : scanCanonicalize (H12AffineFastState.compose env20842 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20842 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20843 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,262,131072,138293,1024,8460,4112,144444,16,8462,8193,16,146460,5392,4096,10281,1284,144445,256,32,5377,8973]

theorem envBound20843 : H12AffineFastState.Bounded env20843 := by
  intro p hp
  have h : env20843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20842_20843 : H12AffineEnvironment.transform 5 17 env20842 = env20843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20842 == env20843) = true)

theorem identity20843 : scanCanonicalize (H12AffineFastState.compose env20843 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20843 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20844 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8461,262,131072,138261,1024,8460,4112,144412,16,8462,8193,16,146460,5392,4096,10249,1284,144413,256,0,5377,8973]

theorem envBound20844 : H12AffineFastState.Bounded env20844 := by
  intro p hp
  have h : env20844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20843_20844 : H12AffineEnvironment.transform 4 0 env20843 = env20844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20843 == env20844) = true)

theorem identity20844 : scanCanonicalize (H12AffineFastState.compose env20844 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20844 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20845 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8461,262,5393,2308,1024,8460,4112,8461,16,8462,8193,16,10509,5392,4096,10249,1284,8460,256,0,5377,8973]

theorem envBound20845 : H12AffineFastState.Bounded env20845 := by
  intro p hp
  have h : env20845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20844_20845 : H12AffineEnvironment.transform 16 5393 env20844 = env20845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20844 == env20845) = true)

theorem identity20845 : scanCanonicalize (H12AffineFastState.compose env20845 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound20845 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env20846 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,8192,1306,8461,262,1290,2308,1024,8460,11,8461,16,8462,8193,16,10509,1291,27,10249,1284,8460,256,0,1306,8973]

theorem envBound20846 : H12AffineFastState.Bounded env20846 := by
  intro p hp
  have h : env20846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20845_20846 : H12AffineEnvironment.transform 11 27 env20845 = env20846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env20845 == env20846) = true)

theorem identity20846 : scanCanonicalize (H12AffineFastState.compose env20846 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound20846 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env20847 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,2056,1306,2309,262,1290,2308,1024,2308,11,2309,16,2310,2057,16,261,1291,27,1,1284,2308,256,0,1306,2821]

theorem envBound20847 : H12AffineFastState.Bounded env20847 := by
  intro p hp
  have h : env20847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20846_20847 : H12AffineEnvironment.transform 12 2056 env20846 = env20847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env20846 == env20847) = true)

theorem identity20847 : scanCanonicalize (H12AffineFastState.compose env20847 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound20847 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env20848 : List Nat := [2,4,8,16,0,17,9,256,512,4,2048,27,2056,286,2309,262,270,2308,4,2308,11,2309,16,2310,2057,16,261,271,27,1,256,2308,256,0,286,2821]

theorem envBound20848 : H12AffineFastState.Bounded env20848 := by
  intro p hp
  have h : env20848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20847_20848 : H12AffineEnvironment.transform 9 4 env20847 = env20848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env20847 == env20848) = true)

theorem identity20848 : scanCanonicalize (H12AffineFastState.compose env20848 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20848 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20849 : List Nat := [2,4,8,0,0,1,9,256,512,4,2048,11,2056,270,2309,262,270,2308,4,2308,11,2309,0,2310,2057,0,261,271,11,1,256,2308,256,0,270,2821]

theorem envBound20849 : H12AffineFastState.Bounded env20849 := by
  intro p hp
  have h : env20849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20848_20849 : H12AffineEnvironment.transform 3 0 env20848 = env20849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20848 == env20849) = true)

def env20850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,98781,8328,65,295421,458144,17665,10400,453996,144493,256,21793,46213,510651]

theorem envBound20850 : H12AffineFastState.Bounded env20850 := by
  intro p hp
  have h : env20850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20822_20850 : H12AffineEnvironment.transform 21 272513 env20822 = env20850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20822 == env20850) = true)

theorem identity20850 : scanCanonicalize (H12AffineFastState.compose env20850 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20850 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396325,272513,400500,95497,8328,65,292137,395636,17665,10400,399800,144493,256,21793,16465,474735]

theorem envBound20851 : H12AffineFastState.Bounded env20851 := by
  intro p hp
  have h : env20851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20850_20851 : H12AffineEnvironment.transform 14 29908 env20850 = env20851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20850 == env20851) = true)

def env20852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140421,33,144596,95497,8328,65,23945,139732,17665,10400,143640,144493,256,21793,16465,202447]

theorem envBound20852 : H12AffineFastState.Bounded env20852 := by
  intro p hp
  have h : env20852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20851_20852 : H12AffineEnvironment.transform 17 10400 env20851 = env20852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20851 == env20852) = true)

theorem identity20852 : scanCanonicalize (H12AffineFastState.compose env20852 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound20852 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env20853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10400,1024,29909,83102,33,87247,95497,8328,65,23945,82383,17665,10400,86275,87158,256,21793,16465,30420]

theorem envBound20853 : H12AffineFastState.Bounded env20853 := by
  intro p hp
  have h : env20853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20852_20853 : H12AffineEnvironment.transform 16 90139 env20852 = env20853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env20852 == env20853) = true)

theorem identity20853 : scanCanonicalize (H12AffineFastState.compose env20853 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound20853 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,65536,70862,10400,1024,0,77899,33,73754,66012,8328,65,10588,79130,12756,10400,75222,73891,256,8692,13444,513]

theorem envBound20854 : H12AffineFastState.Bounded env20854 := by
  intro p hp
  have h : env20854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20853_20854 : H12AffineEnvironment.transform 13 13525 env20853 = env20854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env20853 == env20854) = true)

theorem identity20854 : scanCanonicalize (H12AffineFastState.compose env20854 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20854 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env20855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,262,5576,10400,1024,0,12621,33,8476,218,8328,65,10588,13340,12756,10400,9424,8613,256,8692,13444,513]

theorem envBound20855 : H12AffineFastState.Bounded env20855 := by
  intro p hp
  have h : env20855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20854_20855 : H12AffineEnvironment.transform 15 262 env20854 = env20855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20854 == env20855) = true)

theorem identity20855 : scanCanonicalize (H12AffineFastState.compose env20855 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20855 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env20856 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13325,1,262,5392,10360,1024,0,12621,33,8476,2,8272,65,10588,13340,12556,10360,9224,8573,256,8492,13404,513]

theorem envBound20856 : H12AffineFastState.Bounded env20856 := by
  intro p hp
  have h : env20856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20855_20856 : H12AffineEnvironment.transform 6 88 env20855 = env20856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20855 == env20856) = true)

theorem identity20856 : scanCanonicalize (H12AffineFastState.compose env20856 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20856 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env20857 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,262,5392,10281,1024,0,12572,33,8476,2,8193,16,10509,13340,12556,10281,9224,8492,256,8492,13325,513]

theorem envBound20857 : H12AffineFastState.Bounded env20857 := by
  intro p hp
  have h : env20857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20856_20857 : H12AffineEnvironment.transform 5 17 env20856 = env20857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20856 == env20857) = true)

def env20858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140420,32,144597,95497,8328,65,23944,139733,17665,10400,143641,144493,256,21793,16465,202446]

theorem envBound20858 : H12AffineFastState.Bounded env20858 := by
  intro p hp
  have h : env20858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20851_20858 : H12AffineEnvironment.transform 17 10401 env20851 = env20858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20851 == env20858) = true)

theorem identity20858 : scanCanonicalize (H12AffineFastState.compose env20858 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound20858 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env20859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79251,10401,1024,29909,69911,32,65862,95497,8328,65,23944,70726,17665,10400,66698,66046,256,21793,16465,9053]

theorem envBound20859 : H12AffineFastState.Bounded env20859 := by
  intro p hp
  have h : env20859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20858_20859 : H12AffineEnvironment.transform 16 79251 env20858 = env20859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env20858 == env20859) = true)

theorem identity20859 : scanCanonicalize (H12AffineFastState.compose env20859 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20859 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS < 2^1333 := by decide +kernel

def env20860 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,29908,65536,78958,10401,1024,29909,69866,32,65723,95476,8328,65,23669,70726,17660,10400,66698,65539,253,21724,16465,8864]

theorem envBound20860 : H12AffineFastState.Bounded env20860 := by
  intro p hp
  have h : env20860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20859_20860 : H12AffineEnvironment.transform 7 253 env20859 = env20860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20859 == env20860) = true)

theorem identity20860 : scanCanonicalize (H12AffineFastState.compose env20860 (packedSelected [1,2,3,4,6,8,11,12,15,16,19,22,23,24,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound20860 : packedSelected [1,2,3,4,6,8,11,12,15,16,19,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env20861 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13524,0,65536,78958,10401,1024,1,69866,32,65723,65568,8328,65,10401,70726,12328,10400,66698,65539,253,8200,13445,8864]

theorem envBound20861 : H12AffineFastState.Bounded env20861 := by
  intro p hp
  have h : env20861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20860_20861 : H12AffineEnvironment.transform 13 13524 env20860 = env20861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env20860 == env20861) = true)

theorem identity20861 : scanCanonicalize (H12AffineFastState.compose env20861 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20861 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env20862 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13524,0,170,13508,10401,1024,1,4160,32,17,138,8328,65,10401,5356,12328,10400,1056,169,253,8200,13445,8864]

theorem envBound20862 : H12AffineFastState.Bounded env20862 := by
  intro p hp
  have h : env20862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20861_20862 : H12AffineEnvironment.transform 15 170 env20861 = env20862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20861 == env20862) = true)

theorem identity20862 : scanCanonicalize (H12AffineFastState.compose env20862 (packedSelected [0,6,7,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound20862 : packedSelected [0,6,7,11,15] rootPS < 2^1333 := by decide +kernel

def env20863 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,9,5341,0,170,5325,2216,1024,1,4160,32,17,138,129,65,2216,5356,4129,2217,1056,169,253,1,5260,681]

theorem envBound20863 : H12AffineFastState.Bounded env20863 := by
  intro p hp
  have h : env20863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20862_20863 : H12AffineEnvironment.transform 12 9 env20862 = env20863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env20862 == env20863) = true)

theorem identity20863 : scanCanonicalize (H12AffineFastState.compose env20863 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20863 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env20864 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,9,5260,0,170,5276,2216,1024,1,4113,32,17,138,129,16,2216,5309,4129,2217,1056,169,172,1,5260,681]

theorem envBound20864 : H12AffineFastState.Bounded env20864 := by
  intro p hp
  have h : env20864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20863_20864 : H12AffineEnvironment.transform 5 17 env20863 = env20864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20863 == env20864) = true)

def env20865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,98780,8328,65,4237692,458145,17664,10401,453996,4594925,256,21793,46213,510651]

theorem envBound20865 : H12AffineFastState.Bounded env20865 := by
  intro p hp
  have h : env20865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20821_20865 : H12AffineEnvironment.transform 22 452769 env20821 = env20865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env20821 == env20865) = true)

def env20866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,98780,8328,65,295420,458145,17664,10401,453996,144493,256,21793,46213,510651]

theorem envBound20866 : H12AffineFastState.Bounded env20866 := by
  intro p hp
  have h : env20866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20865_20866 : H12AffineEnvironment.transform 21 272512 env20865 = env20866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20865 == env20866) = true)

theorem identity20866 : scanCanonicalize (H12AffineFastState.compose env20866 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound20866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,180273,16,98780,8328,65,158029,5392,17664,10401,1501,144493,256,21793,46213,74250]

theorem envBound20867 : H12AffineFastState.Bounded env20867 := by
  intro p hp
  have h : env20867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20866_20867 : H12AffineEnvironment.transform 17 190641 env20866 = env20867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env20866 == env20867) = true)

theorem identity20867 : scanCanonicalize (H12AffineFastState.compose env20867 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20867 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,180273,16,41431,8328,65,158029,5392,17664,10401,1501,144493,256,21793,46213,513]

theorem envBound20868 : H12AffineFastState.Bounded env20868 := by
  intro p hp
  have h : env20868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20867_20868 : H12AffineEnvironment.transform 15 8203 env20867 = env20868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20867 == env20868) = true)

theorem identity20868 : scanCanonicalize (H12AffineFastState.compose env20868 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound20868 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43168,1024,32769,4160,32800,16,41431,8328,65,10588,5392,17664,10401,1501,29820,256,21793,46213,513]

theorem envBound20869 : H12AffineFastState.Bounded env20869 := by
  intro p hp
  have h : env20869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20868_20869 : H12AffineEnvironment.transform 16 16401 env20868 = env20869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20868 == env20869) = true)

theorem identity20869 : scanCanonicalize (H12AffineFastState.compose env20869 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20869 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13388,43168,1024,32769,4160,32800,16,41431,8328,65,10588,5392,12637,10401,1501,33,256,8572,46213,513]

theorem envBound20870 : H12AffineFastState.Bounded env20870 := by
  intro p hp
  have h : env20870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20869_20870 : H12AffineEnvironment.transform 13 13405 env20869 = env20870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20869 == env20870) = true)

theorem identity20870 : scanCanonicalize (H12AffineFastState.compose env20870 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20870 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,13388,2556,1024,8541,4160,8572,16,139,8328,65,10588,5392,12637,10401,1501,33,256,8572,5593,513]

theorem envBound20871 : H12AffineFastState.Bounded env20871 := by
  intro p hp
  have h : env20871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20870_20871 : H12AffineEnvironment.transform 14 8540 env20870 = env20871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20870 == env20871) = true)

theorem identity20871 : scanCanonicalize (H12AffineFastState.compose env20871 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20871 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,343,5392,2556,1024,1,4160,32,16,139,468,65,2048,5392,4097,2557,1501,33,256,32,5593,513]

theorem envBound20872 : H12AffineFastState.Bounded env20872 := by
  intro p hp
  have h : env20872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20871_20872 : H12AffineEnvironment.transform 12 348 env20871 = env20872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20871 == env20872) = true)

theorem identity20872 : scanCanonicalize (H12AffineFastState.compose env20872 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound20872 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2420,348,3189,0,343,3172,2556,1024,1,2356,32,16,139,468,65,2048,3172,2421,2557,1501,33,256,32,3245,513]

theorem envBound20873 : H12AffineFastState.Bounded env20873 := by
  intro p hp
  have h : env20873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20872_20873 : H12AffineEnvironment.transform 11 2420 env20872 = env20873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env20872 == env20873) = true)

theorem identity20873 : scanCanonicalize (H12AffineFastState.compose env20873 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound20873 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env20874 : List Nat := [2,4,8,16,32,64,128,231,512,1024,2048,2195,187,3189,0,176,3172,2075,1024,1,2259,32,16,139,51,65,2048,3172,2194,2074,1082,33,231,32,3245,513]

theorem envBound20874 : H12AffineFastState.Bounded env20874 := by
  intro p hp
  have h : env20874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20873_20874 : H12AffineEnvironment.transform 7 231 env20873 = env20874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env20873 == env20874) = true)

def env20875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,98780,8328,65,295421,458145,17664,10401,453996,144492,256,21793,46213,510651]

theorem envBound20875 : H12AffineFastState.Bounded env20875 := by
  intro p hp
  have h : env20875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20865_20875 : H12AffineEnvironment.transform 21 272513 env20865 = env20875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20865 == env20875) = true)

def env20876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452649,98644,8192,65,295285,458025,17664,10281,453996,144492,256,21793,46093,510515]

theorem envBound20876 : H12AffineFastState.Bounded env20876 := by
  intro p hp
  have h : env20876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20875_20876 : H12AffineEnvironment.transform 6 8 env20875 = env20876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20875 == env20876) = true)

theorem identity20876 : scanCanonicalize (H12AffineFastState.compose env20876 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound20876 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,309352,272393,305208,98644,8192,65,295285,310584,17664,10281,306557,29821,256,21793,46093,363042]

theorem envBound20877 : H12AffineFastState.Bounded env20877 := by
  intro p hp
  have h : env20877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20876_20877 : H12AffineEnvironment.transform 16 16401 env20876 = env20877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20876 == env20877) = true)

theorem identity20877 : scanCanonicalize (H12AffineFastState.compose env20877 (packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound20877 : packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env20878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,76159,1024,32769,102679,65910,98631,98644,8192,65,108554,103495,17664,10281,99330,29821,256,21793,46093,41821]

theorem envBound20878 : H12AffineFastState.Bounded env20878 := by
  intro p hp
  have h : env20878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20877_20878 : H12AffineEnvironment.transform 17 76159 env20877 = env20878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env20877 == env20878) = true)

theorem identity20878 : scanCanonicalize (H12AffineFastState.compose env20878 (packedSelected [1,5,8,17,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20878 : packedSelected [1,5,8,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env20879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2421,1024,32769,45341,8572,41293,41310,8192,65,34816,46157,17664,10281,41992,29821,256,21793,46093,41821]

theorem envBound20879 : H12AffineFastState.Bounded env20879 := by
  intro p hp
  have h : env20879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20878_20879 : H12AffineEnvironment.transform 15 8202 env20878 = env20879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20878 == env20879) = true)

theorem identity20879 : scanCanonicalize (H12AffineFastState.compose env20879 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound20879 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env20880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,8202,16401,2421,1024,30072,17508,8572,21556,21543,8192,65,32121,16692,17664,10281,20849,29821,256,21793,16756,22052]

theorem envBound20880 : H12AffineFastState.Bounded env20880 := by
  intro p hp
  have h : env20880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20879_20880 : H12AffineEnvironment.transform 14 30073 env20879 = env20880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env20879 == env20880) = true)

theorem identity20880 : scanCanonicalize (H12AffineFastState.compose env20880 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound20880 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8540,8202,5172,2421,1024,8541,4161,8572,17,2,8192,65,10588,5393,4389,10281,1364,8280,256,260,5457,513]

theorem envBound20881 : H12AffineFastState.Bounded env20881 := by
  intro p hp
  have h : env20881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20880_20881 : H12AffineEnvironment.transform 13 5157 env20880 = env20881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env20880 == env20881) = true)

def env20882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452648,98645,8193,65,295284,458024,17664,10280,453996,144492,256,21793,46092,510514]

theorem envBound20882 : H12AffineFastState.Bounded env20882 := by
  intro p hp
  have h : env20882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20875_20882 : H12AffineEnvironment.transform 6 9 env20875 = env20882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20875 == env20882) = true)

theorem identity20882 : scanCanonicalize (H12AffineFastState.compose env20882 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound20882 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254011,73755,98645,8193,65,215367,79131,17664,10280,75103,144492,256,21793,46092,513]

theorem envBound20883 : H12AffineFastState.Bounded env20883 := by
  intro p hp
  have h : env20883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20882_20883 : H12AffineEnvironment.transform 17 247859 env20882 = env20883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env20882 == env20883) = true)

theorem identity20883 : scanCanonicalize (H12AffineFastState.compose env20883 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound20883 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,77899,33,73755,98645,8193,65,43357,79131,17664,10280,75103,119926,256,21793,46092,513]

theorem envBound20884 : H12AffineFastState.Bounded env20884 := by
  intro p hp
  have h : env20884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20883_20884 : H12AffineEnvironment.transform 16 122906 env20883 = env20884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env20883 == env20884) = true)

theorem identity20884 : scanCanonicalize (H12AffineFastState.compose env20884 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20884 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env20885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4160,33,16,41310,8193,65,43357,5392,17664,10280,1364,62589,256,21793,46092,513]

theorem envBound20885 : H12AffineFastState.Bounded env20885 := by
  intro p hp
  have h : env20885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20884_20885 : H12AffineEnvironment.transform 15 8203 env20884 = env20885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20884 == env20885) = true)

theorem identity20885 : scanCanonicalize (H12AffineFastState.compose env20885 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20885 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49169,2340,1024,32769,4160,33,16,32851,268,65,34896,5392,17664,2341,1364,54640,256,21793,38145,513]

theorem envBound20886 : H12AffineFastState.Bounded env20886 := by
  intro p hp
  have h : env20886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20885_20886 : H12AffineEnvironment.transform 12 269 env20885 = env20886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20885 == env20886) = true)

theorem identity20886 : scanCanonicalize (H12AffineFastState.compose env20886 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound20886 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,262,38208,2340,1024,32769,4160,33,16,32851,268,65,34896,5392,4177,2341,1364,32801,256,112,38145,513]

theorem envBound20887 : H12AffineFastState.Bounded env20887 := by
  intro p hp
  have h : env20887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20886_20887 : H12AffineEnvironment.transform 13 5457 env20886 = env20887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env20886 == env20887) = true)

theorem identity20887 : scanCanonicalize (H12AffineFastState.compose env20887 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound20887 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,80,262,5392,2340,1024,81,4160,33,16,3,268,65,2048,5392,4177,2341,1364,113,256,112,5457,513]

theorem envBound20888 : H12AffineFastState.Bounded env20888 := by
  intro p hp
  have h : env20888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20887_20888 : H12AffineEnvironment.transform 14 80 env20887 = env20888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env20887 == env20888) = true)

theorem identity20888 : scanCanonicalize (H12AffineFastState.compose env20888 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound20888 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env20889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2096,269,3425,80,262,3360,2340,1024,81,2160,33,16,3,268,65,2048,3360,2145,2341,1364,113,256,112,3425,513]

theorem envBound20889 : H12AffineFastState.Bounded env20889 := by
  intro p hp
  have h : env20889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20888_20889 : H12AffineEnvironment.transform 11 2096 env20888 = env20889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env20888 == env20889) = true)

theorem identity20889 : scanCanonicalize (H12AffineFastState.compose env20889 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound20889 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20890 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,2096,269,2128,80,262,2065,2340,305,81,2160,33,16,3,268,65,2048,2065,2145,2341,101,113,256,112,2128,513]

theorem envBound20890 : H12AffineFastState.Bounded env20890 := by
  intro p hp
  have h : env20890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20889_20890 : H12AffineEnvironment.transform 9 305 env20889 = env20890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env20889 == env20890) = true)

theorem identity20890 : scanCanonicalize (H12AffineFastState.compose env20890 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20890 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20891 : List Nat := [2,4,8,16,32,49,9,256,512,305,2048,2096,269,2081,33,262,2065,2340,305,32,2049,33,16,3,268,48,2048,2065,2064,2341,20,0,256,1,2081,513]

theorem envBound20891 : H12AffineFastState.Bounded env20891 := by
  intro p hp
  have h : env20891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20890_20891 : H12AffineEnvironment.transform 5 49 env20890 = env20891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20890 == env20891) = true)

theorem identity20891 : scanCanonicalize (H12AffineFastState.compose env20891 (packedSelected [3,5,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20891 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env20892 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,2064,269,2049,1,262,2065,2308,273,0,2049,1,16,3,268,16,2048,2065,2064,2309,20,0,256,1,2049,513]

theorem envBound20892 : H12AffineFastState.Bounded env20892 := by
  intro p hp
  have h : env20892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20891_20892 : H12AffineEnvironment.transform 4 0 env20891 = env20892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20891 == env20892) = true)

theorem identity20892 : scanCanonicalize (H12AffineFastState.compose env20892 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound20892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20893 : List Nat := [2,4,8,16,0,17,9,256,512,273,260,276,269,261,1,262,277,0,273,0,261,1,16,3,268,16,260,277,276,1,20,0,256,1,261,513]

theorem envBound20893 : H12AffineFastState.Bounded env20893 := by
  intro p hp
  have h : env20893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20892_20893 : H12AffineEnvironment.transform 10 260 env20892 = env20893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env20892 == env20893) = true)

def env20894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound20894 : H12AffineFastState.Bounded env20894 := by
  intro p hp
  have h : env20894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20733_20894 : H12AffineEnvironment.transform 18 1025 env20733 = env20894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20733 == env20894) = true)

theorem identity20894 : scanCanonicalize (H12AffineFastState.compose env20894 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound20894 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575676,18973837,10507600,8538621,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound20895 : H12AffineFastState.Bounded env20895 := by
  intro p hp
  have h : env20895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20894_20895 : H12AffineEnvironment.transform 17 35324 env20894 = env20895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env20894 == env20895) = true)

def env20896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575540,18973701,10507600,8538485,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound20896 : H12AffineFastState.Bounded env20896 := by
  intro p hp
  have h : env20896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20895_20896 : H12AffineEnvironment.transform 6 8 env20895 = env20896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20895 == env20896) = true)

def env20897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,16777216,8192,65,21039476,18973701,2233680,2421,17024017,23160136,257,19104804,19096841,16966479]

theorem envBound20897 : H12AffineFastState.Bounded env20897 := by
  intro p hp
  have h : env20897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20896_20897 : H12AffineEnvironment.transform 22 147456 env20896 = env20897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env20896 == env20897) = true)

def env20898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973701,2118976,2421,16876545,23160136,257,18990132,18949401,16819039]

theorem envBound20898 : H12AffineFastState.Bounded env20898 := by
  intro p hp
  have h : env20898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20897_20898 : H12AffineEnvironment.transform 16 16400 env20897 = env20898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20897 == env20898) = true)

theorem identity20898 : scanCanonicalize (H12AffineFastState.compose env20898 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound20898 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,3,8192,65,4262263,2196486,2118976,2421,99330,6382923,257,2212919,2172186,41820]

theorem envBound20899 : H12AffineFastState.Bounded env20899 := by
  intro p hp
  have h : env20899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20898_20899 : H12AffineEnvironment.transform 23 3 env20898 = env20899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env20898 == env20899) = true)

def env20900 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35108,1025,32769,2097152,4194304,16,3,8192,17,4262183,2196486,2118928,2341,99330,6382875,257,2212919,2172186,41740]

theorem envBound20900 : H12AffineFastState.Bounded env20900 := by
  intro p hp
  have h : env20900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20899_20900 : H12AffineEnvironment.transform 5 16 env20899 = env20900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20899 == env20900) = true)

theorem identity20900 : scanCanonicalize (H12AffineFastState.compose env20900 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound20900 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20901 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16400,35108,1025,32769,2097152,4194304,16,3,8192,17,4229152,2098433,2118928,2341,1285,6349852,257,2114864,2139165,41740]

theorem envBound20901 : H12AffineFastState.Bounded env20901 := by
  intro p hp
  have h : env20901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20900_20901 : H12AffineEnvironment.transform 15 33031 env20900 = env20901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env20900 == env20901) = true)

theorem identity20901 : scanCanonicalize (H12AffineFastState.compose env20901 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound20901 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env20902 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16400,35108,1025,32769,50448,4194304,16,3,8192,17,4229152,49169,36864,2341,1285,4202764,257,32800,24845,41740]

theorem envBound20902 : H12AffineFastState.Bounded env20902 := by
  intro p hp
  have h : env20902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20901_20902 : H12AffineEnvironment.transform 20 50448 env20901 = env20902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env20901 == env20902) = true)

def env20903 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35109,1025,32769,2097152,4194304,16,3,8192,16,4262182,2196486,2118929,2340,99330,6382874,257,2212919,2172186,41741]

theorem envBound20903 : H12AffineFastState.Bounded env20903 := by
  intro p hp
  have h : env20903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20899_20903 : H12AffineEnvironment.transform 5 17 env20899 = env20903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20899 == env20903) = true)

theorem identity20903 : scanCanonicalize (H12AffineFastState.compose env20903 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound20903 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20904 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35109,1025,32769,2097152,73770,16,3,8192,16,10508,2196486,2118929,2340,99330,2114864,257,2212919,2172186,41741]

theorem envBound20904 : H12AffineFastState.Bounded env20904 := by
  intro p hp
  have h : env20904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20903_20904 : H12AffineEnvironment.transform 21 73770 env20903 = env20904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env20903 == env20904) = true)

theorem identity20904 : scanCanonicalize (H12AffineFastState.compose env20904 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20904 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env20905 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16400,35109,1025,32769,2097152,65830,16,3,268,16,2048,2196486,2118929,2340,99330,2114864,257,2212919,2163734,33281]

theorem envBound20905 : H12AffineFastState.Bounded env20905 := by
  intro p hp
  have h : env20905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20904_20905 : H12AffineEnvironment.transform 12 268 env20904 = env20905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20904 == env20905) = true)

theorem identity20905 : scanCanonicalize (H12AffineFastState.compose env20905 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82966) := by decide +kernel

theorem selectedBound20905 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20906 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16400,35109,1025,32769,82966,65830,16,3,268,16,2048,49168,69895,2340,99330,65830,257,32801,16384,33281]

theorem envBound20906 : H12AffineFastState.Bounded env20906 := by
  intro p hp
  have h : env20906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20905_20906 : H12AffineEnvironment.transform 20 82966 env20905 = env20906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82966 env20905 == env20906) = true)

theorem identity20906 : scanCanonicalize (H12AffineFastState.compose env20906 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound20906 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env20907 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,33031,16400,35109,1025,32769,50449,32801,16,3,268,16,2048,49168,36864,2340,1285,32801,257,32801,16384,33281]

theorem envBound20907 : H12AffineFastState.Bounded env20907 := by
  intro p hp
  have h : env20907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20906_20907 : H12AffineEnvironment.transform 15 33031 env20906 = env20907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env20906 == env20907) = true)

theorem identity20907 : scanCanonicalize (H12AffineFastState.compose env20907 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3620) := by decide +kernel

theorem selectedBound20907 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20908 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,3620,32768,33031,3636,35109,1025,32769,35637,32801,16,3,268,16,2048,36404,36864,2340,1285,32801,257,32801,3620,33281]

theorem envBound20908 : H12AffineFastState.Bounded env20908 := by
  intro p hp
  have h : env20908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20907_20908 : H12AffineEnvironment.transform 13 3620 env20907 = env20908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3620 env20907 == env20908) = true)

theorem identity20908 : scanCanonicalize (H12AffineFastState.compose env20908 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound20908 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env20909 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,268,3620,32768,33031,3636,35109,1025,32769,35637,32801,16,3,268,16,2048,36404,35877,2340,1285,32801,257,32801,3620,33281]

theorem envBound20909 : H12AffineFastState.Bounded env20909 := by
  intro p hp
  have h : env20909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20908_20909 : H12AffineEnvironment.transform 11 3109 env20908 = env20909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env20908 == env20909) = true)

theorem identity20909 : scanCanonicalize (H12AffineFastState.compose env20909 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound20909 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env20910 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,3109,56,3620,32768,32819,3636,34833,1025,32769,35329,32801,16,3,56,16,2048,36404,35877,2064,1073,32801,53,32801,3620,33281]

theorem envBound20910 : H12AffineFastState.Bounded env20910 := by
  intro p hp
  have h : env20910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20909_20910 : H12AffineEnvironment.transform 7 52 env20909 = env20910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env20909 == env20910) = true)

theorem identity20910 : scanCanonicalize (H12AffineFastState.compose env20910 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20910 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20911 : List Nat := [2,4,8,16,32,17,8,52,0,1024,2048,3109,56,3108,32768,32819,3124,34833,1025,32769,34817,32801,16,3,56,16,2048,35892,35877,2064,1073,32801,53,32801,3108,32769]

theorem envBound20911 : H12AffineFastState.Bounded env20911 := by
  intro p hp
  have h : env20911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20910_20911 : H12AffineEnvironment.transform 8 0 env20910 = env20911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20910 == env20911) = true)

theorem identity20911 : scanCanonicalize (H12AffineFastState.compose env20911 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound20911 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20912 : List Nat := [2,4,8,16,32,17,8,52,0,1024,1077,16,56,17,32768,32819,1,33828,1025,32769,33844,32801,16,3,56,16,1077,32769,32784,1061,1073,32801,53,32801,17,32769]

theorem envBound20912 : H12AffineFastState.Bounded env20912 := by
  intro p hp
  have h : env20912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20911_20912 : H12AffineEnvironment.transform 10 1077 env20911 = env20912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env20911 == env20912) = true)

theorem identity20912 : scanCanonicalize (H12AffineFastState.compose env20912 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20912 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20913 : List Nat := [2,4,8,16,32,17,8,52,0,53,0,16,56,17,32768,32819,1,32785,52,32769,32769,32801,16,3,56,16,0,32769,32784,16,4,32801,53,32801,17,32769]

theorem envBound20913 : H12AffineFastState.Bounded env20913 := by
  intro p hp
  have h : env20913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20912_20913 : H12AffineEnvironment.transform 9 53 env20912 = env20913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20912 == env20913) = true)

theorem identity20913 : scanCanonicalize (H12AffineFastState.compose env20913 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20913 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env20914 : List Nat := [2,4,8,1,32,0,8,37,0,36,0,1,41,0,32768,32802,1,32768,37,32769,32769,32801,1,3,41,1,0,32769,32769,1,4,32801,36,32801,0,32769]

theorem envBound20914 : H12AffineFastState.Bounded env20914 := by
  intro p hp
  have h : env20914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20913_20914 : H12AffineEnvironment.transform 3 1 env20913 = env20914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20913 == env20914) = true)

theorem identity20914 : scanCanonicalize (H12AffineFastState.compose env20914 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20915 : List Nat := [2,4,8,1,32,0,8,37,0,36,0,1,41,0,1,35,1,1,37,0,0,32,1,3,41,1,0,0,0,1,4,32,36,32,0,0]

theorem envBound20915 : H12AffineFastState.Bounded env20915 := by
  intro p hp
  have h : env20915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20914_20915 : H12AffineEnvironment.transform 14 1 env20914 = env20915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20914 == env20915) = true)

theorem identity20915 : scanCanonicalize (H12AffineFastState.compose env20915 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound20915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20916 : List Nat := [2,4,8,1,15,0,8,10,0,11,0,1,6,0,1,12,1,1,10,0,0,15,1,3,6,1,0,0,0,1,4,15,11,15,0,0]

theorem envBound20916 : H12AffineFastState.Bounded env20916 := by
  intro p hp
  have h : env20916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20915_20916 : H12AffineEnvironment.transform 4 15 env20915 = env20916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env20915 == env20916) = true)

theorem identity20916 : scanCanonicalize (H12AffineFastState.compose env20916 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound20916 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20917 : List Nat := [2,4,7,1,0,0,7,5,0,4,0,1,6,0,1,3,1,1,5,0,0,0,1,3,6,1,0,0,0,1,4,0,4,0,0,0]

theorem envBound20917 : H12AffineFastState.Bounded env20917 := by
  intro p hp
  have h : env20917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20916_20917 : H12AffineEnvironment.transform 2 7 env20916 = env20917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env20916 == env20917) = true)

def env20918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,16777216,8192,65,21039476,18973701,2118977,2421,16876544,23160136,257,18990133,18949400,16819038]

theorem envBound20918 : H12AffineFastState.Bounded env20918 := by
  intro p hp
  have h : env20918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20897_20918 : H12AffineEnvironment.transform 16 16401 env20897 = env20918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20897 == env20918) = true)

theorem identity20918 : scanCanonicalize (H12AffineFastState.compose env20918 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound20918 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41311,8192,65,4302891,2172250,2118977,2421,75103,6407191,257,2188650,2196551,513]

theorem envBound20919 : H12AffineFastState.Bounded env20919 := by
  intro p hp
  have h : env20919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20918_20919 : H12AffineEnvironment.transform 23 41311 env20918 = env20919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env20918 == env20919) = true)

theorem identity20919 : scanCanonicalize (H12AffineFastState.compose env20919 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound20919 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env20920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115735,4194304,17,41311,8192,65,4302891,57677,102742,2421,75103,4194304,257,41341,16464,513]

theorem envBound20920 : H12AffineFastState.Bounded env20920 := by
  intro p hp
  have h : env20920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20919_20920 : H12AffineEnvironment.transform 20 115735 env20919 = env20920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env20919 == env20920) = true)

theorem identity20920 : scanCanonicalize (H12AffineFastState.compose env20920 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20920 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env20921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,91466,4194304,17,2,8192,65,4262262,16400,77835,2421,75103,4194304,257,32,16464,513]

theorem envBound20921 : H12AffineFastState.Bounded env20921 := by
  intro p hp
  have h : env20921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20920_20921 : H12AffineEnvironment.transform 14 8541 env20920 = env20921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20920 == env20921) = true)

theorem identity20921 : scanCanonicalize (H12AffineFastState.compose env20921 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound20921 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,91466,8572,17,2,8192,65,75786,16400,77835,2421,75103,8572,257,32,16464,513]

theorem envBound20922 : H12AffineFastState.Bounded env20922 := by
  intro p hp
  have h : env20922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20921_20922 : H12AffineEnvironment.transform 21 8572 env20921 = env20922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env20921 == env20922) = true)

def env20923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,16777216,8192,65,21039477,18973701,2233681,2420,17024016,23160136,257,19104805,19096840,16966478]

theorem envBound20923 : H12AffineFastState.Bounded env20923 := by
  intro p hp
  have h : env20923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20896_20923 : H12AffineEnvironment.transform 22 147457 env20896 = env20923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env20896 == env20923) = true)

theorem identity20923 : scanCanonicalize (H12AffineFastState.compose env20923 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound20923 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,188751,8192,65,4450362,2319690,2233681,2420,75103,6521863,257,2188650,2196551,513]

theorem envBound20924 : H12AffineFastState.Bounded env20924 := by
  intro p hp
  have h : env20924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20923_20924 : H12AffineEnvironment.transform 23 188751 env20923 = env20924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env20923 == env20924) = true)

def env20925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41311,8192,65,4302890,2172250,2118977,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound20925 : H12AffineFastState.Bounded env20925 := by
  intro p hp
  have h : env20925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20924_20925 : H12AffineEnvironment.transform 16 16400 env20924 = env20925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20924 == env20925) = true)

theorem identity20925 : scanCanonicalize (H12AffineFastState.compose env20925 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound20925 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115735,4194304,17,41311,8192,65,4302890,57677,102742,2420,75103,4194304,257,41341,16464,513]

theorem envBound20926 : H12AffineFastState.Bounded env20926 := by
  intro p hp
  have h : env20926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20925_20926 : H12AffineEnvironment.transform 20 115735 env20925 = env20926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env20925 == env20926) = true)

def env20927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91199,4194304,17,375,8192,65,4261890,16741,78206,2420,75103,4194304,257,341,16464,513]

theorem envBound20927 : H12AffineFastState.Bounded env20927 := by
  intro p hp
  have h : env20927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20926_20927 : H12AffineEnvironment.transform 14 8232 env20926 = env20927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env20926 == env20927) = true)

theorem identity20927 : scanCanonicalize (H12AffineFastState.compose env20927 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound20927 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env20928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91199,65910,17,375,8192,65,2420,16741,78206,2420,75103,65910,257,341,16464,513]

theorem envBound20928 : H12AffineFastState.Bounded env20928 := by
  intro p hp
  have h : env20928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20927_20928 : H12AffineEnvironment.transform 21 65910 env20927 = env20928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env20927 == env20928) = true)

theorem identity20928 : scanCanonicalize (H12AffineFastState.compose env20928 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound20928 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env20929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,342,16400,10588,1025,8233,25961,32,17,375,8192,65,2420,16741,12328,2420,9225,32,257,341,16464,513]

theorem envBound20929 : H12AffineFastState.Bounded env20929 := by
  intro p hp
  have h : env20929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20928_20929 : H12AffineEnvironment.transform 15 342 env20928 = env20929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env20928 == env20929) = true)

theorem identity20929 : scanCanonicalize (H12AffineFastState.compose env20929 (packedSelected [0,1,2,3,4,6,7,9,14,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20929 : packedSelected [0,1,2,3,4,6,7,9,14,24,28] rootPS < 2^1333 := by decide +kernel

def env20930 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25629,32,17,3,8192,65,2048,16401,12328,2048,9225,32,117,33,16464,513]

theorem envBound20930 : H12AffineFastState.Bounded env20930 := by
  intro p hp
  have h : env20930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20929_20930 : H12AffineEnvironment.transform 7 116 env20929 = env20930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20929 == env20930) = true)

theorem identity20930 : scanCanonicalize (H12AffineFastState.compose env20930 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound20930 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20931 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,12345,8232,34,12329,10280,1025,8233,5156,32,17,3,8192,65,2048,12328,12328,2048,9225,32,117,33,12393,513]

theorem envBound20931 : H12AffineFastState.Bounded env20931 := by
  intro p hp
  have h : env20931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20930_20931 : H12AffineEnvironment.transform 13 12345 env20930 = env20931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env20930 == env20931) = true)

theorem identity20931 : scanCanonicalize (H12AffineFastState.compose env20931 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound20931 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20932 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,4096,8192,12345,8232,34,12329,8312,1025,8233,5156,32,17,3,8192,65,80,12328,12328,80,9225,32,117,33,12393,513]

theorem envBound20932 : H12AffineFastState.Bounded env20932 := by
  intro p hp
  have h : env20932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20931_20932 : H12AffineEnvironment.transform 10 80 env20931 = env20932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env20931 == env20932) = true)

theorem identity20932 : scanCanonicalize (H12AffineFastState.compose env20932 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20932 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env20933 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,4096,8192,12345,8232,34,12329,8312,100,8233,4161,32,17,3,8192,65,80,12328,12328,80,8300,32,117,33,12393,513]

theorem envBound20933 : H12AffineFastState.Bounded env20933 := by
  intro p hp
  have h : env20933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20932_20933 : H12AffineEnvironment.transform 9 101 env20932 = env20933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20932 == env20933) = true)

theorem identity20933 : scanCanonicalize (H12AffineFastState.compose env20933 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 4152) := by decide +kernel

theorem selectedBound20933 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env20934 : List Nat := [2,4,8,16,32,64,8,116,512,101,80,4096,4152,1,4112,34,17,4160,100,4113,4161,32,17,3,4152,65,80,16,16,80,4180,32,117,33,81,513]

theorem envBound20934 : H12AffineFastState.Bounded env20934 := by
  intro p hp
  have h : env20934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20933_20934 : H12AffineEnvironment.transform 12 4152 env20933 = env20934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env20933 == env20934) = true)

theorem identity20934 : scanCanonicalize (H12AffineFastState.compose env20934 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20934 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env20935 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,4096,4152,1,4112,34,17,4113,53,4113,4112,32,17,3,4152,16,1,16,16,1,4101,32,36,33,0,513]

theorem envBound20935 : H12AffineFastState.Bounded env20935 := by
  intro p hp
  have h : env20935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20934_20935 : H12AffineEnvironment.transform 5 17 env20934 = env20935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20934 == env20935) = true)

theorem identity20935 : scanCanonicalize (H12AffineFastState.compose env20935 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound20935 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20936 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,16,40,1,0,34,17,1,53,1,0,32,17,3,40,16,1,16,16,1,21,32,36,33,0,513]

theorem envBound20936 : H12AffineFastState.Bounded env20936 := by
  intro p hp
  have h : env20936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20935_20936 : H12AffineEnvironment.transform 11 16 env20935 = env20936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20935 == env20936) = true)

theorem identity20936 : scanCanonicalize (H12AffineFastState.compose env20936 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound20936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20937 : List Nat := [2,4,8,5,32,4,8,37,512,33,1,5,40,1,0,34,4,1,32,1,0,32,4,3,40,5,1,5,5,1,0,32,36,33,0,513]

theorem envBound20937 : H12AffineFastState.Bounded env20937 := by
  intro p hp
  have h : env20937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20936_20937 : H12AffineEnvironment.transform 3 5 env20936 = env20937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env20936 == env20937) = true)

theorem identity20937 : scanCanonicalize (H12AffineFastState.compose env20937 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound20937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20938 : List Nat := [2,2,8,3,32,2,8,35,512,33,1,3,40,1,0,34,2,1,32,1,0,32,2,3,40,3,1,3,3,1,0,32,34,33,0,513]

theorem envBound20938 : H12AffineFastState.Bounded env20938 := by
  intro p hp
  have h : env20938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20937_20938 : H12AffineEnvironment.transform 1 2 env20937 = env20938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env20937 == env20938) = true)

theorem identity20938 : scanCanonicalize (H12AffineFastState.compose env20938 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20938 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20939 : List Nat := [2,2,8,3,1,2,8,2,512,0,1,3,9,1,0,3,2,1,1,1,0,1,2,3,9,3,1,3,3,1,0,1,3,0,0,513]

theorem envBound20939 : H12AffineFastState.Bounded env20939 := by
  intro p hp
  have h : env20939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20938_20939 : H12AffineEnvironment.transform 4 1 env20938 = env20939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20938 == env20939) = true)

theorem identity20939 : scanCanonicalize (H12AffineFastState.compose env20939 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound20939 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20940 : List Nat := [2,2,8,3,1,2,8,2,10,0,1,3,9,1,0,3,2,1,1,1,0,1,2,3,9,3,1,3,3,1,0,1,3,0,0,11]

theorem envBound20940 : H12AffineFastState.Bounded env20940 := by
  intro p hp
  have h : env20940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20939_20940 : H12AffineEnvironment.transform 8 10 env20939 = env20940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env20939 == env20940) = true)

theorem identity20940 : scanCanonicalize (H12AffineFastState.compose env20940 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20940 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20941 : List Nat := [2,2,2,3,1,2,2,2,0,0,1,3,3,1,0,3,2,1,1,1,0,1,2,3,3,3,1,3,3,1,0,1,3,0,0,1]

theorem envBound20941 : H12AffineFastState.Bounded env20941 := by
  intro p hp
  have h : env20941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20940_20941 : H12AffineEnvironment.transform 2 2 env20940 = env20941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20940 == env20941) = true)

theorem identity20941 : scanCanonicalize (H12AffineFastState.compose env20941 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20941 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20942 : List Nat := [1,1,1,0,1,1,1,1,0,0,1,0,0,1,0,0,1,1,1,1,0,1,1,0,0,0,1,0,0,1,0,1,0,0,0,1]

theorem envBound20942 : H12AffineFastState.Bounded env20942 := by
  intro p hp
  have h : env20942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20941_20942 : H12AffineEnvironment.transform 0 1 env20941 = env20942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20941 == env20942) = true)

def env20943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91198,4194304,17,374,8192,65,4261891,16740,78207,2420,75103,4194304,257,340,16464,513]

theorem envBound20943 : H12AffineFastState.Bounded env20943 := by
  intro p hp
  have h : env20943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20926_20943 : H12AffineEnvironment.transform 14 8233 env20926 = env20943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env20926 == env20943) = true)

theorem identity20943 : scanCanonicalize (H12AffineFastState.compose env20943 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound20943 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env20944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91198,65538,17,374,8192,65,2049,16740,78207,2420,75103,65538,257,340,16464,513]

theorem envBound20944 : H12AffineFastState.Bounded env20944 := by
  intro p hp
  have h : env20944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20943_20944 : H12AffineEnvironment.transform 21 65538 env20943 = env20944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env20943 == env20944) = true)

theorem identity20944 : scanCanonicalize (H12AffineFastState.compose env20944 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound20944 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16400,10589,1025,8232,25628,32,17,374,8192,65,2049,16740,12637,2420,9597,32,257,340,16464,513]

theorem envBound20945 : H12AffineFastState.Bounded env20945 := by
  intro p hp
  have h : env20945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20944_20945 : H12AffineEnvironment.transform 15 34 env20944 = env20945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env20944 == env20945) = true)

theorem identity20945 : scanCanonicalize (H12AffineFastState.compose env20945 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20945 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env20946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,81,34,16400,2341,1025,80,17508,32,17,374,120,65,2049,16740,4389,2420,1285,32,257,340,16464,513]

theorem envBound20946 : H12AffineFastState.Bounded env20946 := by
  intro p hp
  have h : env20946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20945_20946 : H12AffineEnvironment.transform 12 120 env20945 = env20946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20945 == env20946) = true)

theorem identity20946 : scanCanonicalize (H12AffineFastState.compose env20946 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20946 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env20947 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,16384,81,34,16400,2129,1025,80,17508,32,17,2,120,65,2049,16400,4177,2048,1137,32,117,32,16464,513]

theorem envBound20947 : H12AffineFastState.Bounded env20947 := by
  intro p hp
  have h : env20947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20946_20947 : H12AffineEnvironment.transform 7 116 env20946 = env20947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20946 == env20947) = true)

def env20948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302891,2172251,2118976,2420,75103,6407190,257,2188650,2196551,513]

theorem envBound20948 : H12AffineFastState.Bounded env20948 := by
  intro p hp
  have h : env20948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20924_20948 : H12AffineEnvironment.transform 16 16401 env20924 = env20948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20924 == env20948) = true)

theorem identity20948 : scanCanonicalize (H12AffineFastState.compose env20948 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20948 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2098513,2118976,2420,1365,6349852,257,2114912,2139213,513]

theorem envBound20949 : H12AffineFastState.Bounded env20949 := by
  intro p hp
  have h : env20949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20948_20949 : H12AffineEnvironment.transform 15 8202 env20948 = env20949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20948 == env20949) = true)

theorem identity20949 : scanCanonicalize (H12AffineFastState.compose env20949 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound20949 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,2097152,32,16,41310,8192,65,34817,2098513,2118976,2420,1365,2155580,257,2114912,2139213,513]

theorem envBound20950 : H12AffineFastState.Bounded env20950 := by
  intro p hp
  have h : env20950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20949_20950 : H12AffineEnvironment.transform 21 32 env20949 = env20950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env20949 == env20950) = true)

theorem identity20950 : scanCanonicalize (H12AffineFastState.compose env20950 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20950 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10280,1025,8541,2097152,32,16,2,8192,65,10589,2098513,2118976,2420,1365,2114912,257,2114912,2098449,513]

theorem envBound20951 : H12AffineFastState.Bounded env20951 := by
  intro p hp
  have h : env20951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20950_20951 : H12AffineEnvironment.transform 14 8540 env20950 = env20951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20950 == env20951) = true)

theorem identity20951 : scanCanonicalize (H12AffineFastState.compose env20951 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20952 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8202,16401,10280,1025,8461,2097152,32,16,2,8192,17,10509,2098433,2118928,2340,1285,2114864,257,2114864,2098449,513]

theorem envBound20952 : H12AffineFastState.Bounded env20952 := by
  intro p hp
  have h : env20952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20951_20952 : H12AffineEnvironment.transform 5 16 env20951 = env20952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20951 == env20952) = true)

theorem identity20952 : scanCanonicalize (H12AffineFastState.compose env20952 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound20952 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20953 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,3344,3094,16401,1076,1025,3345,2097152,32,16,2,3100,17,1297,2098433,2118928,2340,1285,2114864,257,2114864,2098449,513]

theorem envBound20953 : H12AffineFastState.Bounded env20953 := by
  intro p hp
  have h : env20953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20952_20953 : H12AffineEnvironment.transform 12 3100 env20952 = env20953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env20952 == env20953) = true)

theorem identity20953 : scanCanonicalize (H12AffineFastState.compose env20953 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 7456) := by decide +kernel

theorem selectedBound20953 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,3344,3094,16401,1076,1025,3345,7456,32,16,2,3100,17,1297,6177,18480,2340,1285,22544,257,22544,6193,513]

theorem envBound20954 : H12AffineFastState.Bounded env20954 := by
  intro p hp
  have h : env20954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20953_20954 : H12AffineEnvironment.transform 20 7456 env20953 = env20954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 7456 env20953 == env20954) = true)

theorem identity20954 : scanCanonicalize (H12AffineFastState.compose env20954 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20954 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20955 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,4112,3344,3094,4097,1076,1025,3345,7456,32,16,2,3100,17,1297,6177,6176,2340,1285,2048,257,2048,6193,513]

theorem envBound20955 : H12AffineFastState.Bounded env20955 := by
  intro p hp
  have h : env20955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20954_20955 : H12AffineEnvironment.transform 13 4112 env20954 = env20955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env20954 == env20955) = true)

theorem identity20955 : scanCanonicalize (H12AffineFastState.compose env20955 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound20955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20956 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,3100,293,3344,3094,308,1076,1025,3345,3093,32,16,2,3100,17,1297,2324,2325,2340,1285,2048,257,2048,2308,513]

theorem envBound20956 : H12AffineFastState.Bounded env20956 := by
  intro p hp
  have h : env20956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20955_20956 : H12AffineEnvironment.transform 11 309 env20955 = env20956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env20955 == env20956) = true)

theorem identity20956 : scanCanonicalize (H12AffineFastState.compose env20956 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1825) := by decide +kernel

theorem selectedBound20956 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env20957 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1825,309,829,293,561,823,308,1076,1025,560,820,32,16,2,829,17,1297,1589,1588,1541,1285,1825,257,1825,1573,513]

theorem envBound20957 : H12AffineFastState.Bounded env20957 := by
  intro p hp
  have h : env20957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20956_20957 : H12AffineEnvironment.transform 10 1825 env20956 = env20957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1825 env20956 == env20957) = true)

theorem identity20957 : scanCanonicalize (H12AffineFastState.compose env20957 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound20957 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env20958 : List Nat := [2,4,8,16,32,16,8,256,16,1024,1329,309,301,293,33,295,308,1076,1025,32,292,32,16,2,301,17,1297,1061,1060,1045,1285,1329,257,1329,1077,17]

theorem envBound20958 : H12AffineFastState.Bounded env20958 := by
  intro p hp
  have h : env20958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20957_20958 : H12AffineEnvironment.transform 8 16 env20957 = env20958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env20957 == env20958) = true)

theorem identity20958 : scanCanonicalize (H12AffineFastState.compose env20958 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20958 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env20959 : List Nat := [2,4,8,16,32,16,8,256,16,273,32,309,301,293,33,295,308,293,272,32,292,32,16,2,301,17,0,308,309,260,20,32,257,32,292,17]

theorem envBound20959 : H12AffineFastState.Bounded env20959 := by
  intro p hp
  have h : env20959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20958_20959 : H12AffineEnvironment.transform 9 273 env20958 = env20959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20958 == env20959) = true)

theorem identity20959 : scanCanonicalize (H12AffineFastState.compose env20959 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20959 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20960 : List Nat := [2,4,8,0,32,0,8,256,0,257,32,293,301,293,33,295,292,293,256,32,292,32,0,2,301,1,0,292,293,260,4,32,257,32,292,1]

theorem envBound20960 : H12AffineFastState.Bounded env20960 := by
  intro p hp
  have h : env20960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20959_20960 : H12AffineEnvironment.transform 3 0 env20959 = env20960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20959 == env20960) = true)

theorem identity20960 : scanCanonicalize (H12AffineFastState.compose env20960 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20960 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20961 : List Nat := [2,4,8,0,32,0,8,4,0,5,32,33,41,33,33,35,32,33,4,32,32,32,0,2,41,1,0,32,33,0,4,32,5,32,32,1]

theorem envBound20961 : H12AffineFastState.Bounded env20961 := by
  intro p hp
  have h : env20961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20960_20961 : H12AffineEnvironment.transform 7 4 env20960 = env20961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20960 == env20961) = true)

theorem identity20961 : scanCanonicalize (H12AffineFastState.compose env20961 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20961 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20962 : List Nat := [2,4,8,0,1,0,8,4,0,5,1,0,8,0,0,2,1,0,4,1,1,1,0,2,8,1,0,1,0,0,4,1,5,1,1,1]

theorem envBound20962 : H12AffineFastState.Bounded env20962 := by
  intro p hp
  have h : env20962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20961_20962 : H12AffineEnvironment.transform 4 1 env20961 = env20962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20961 == env20962) = true)

def env20963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575541,18973700,10507600,8538484,25265169,23160137,257,27378725,27337993,25207630]

theorem envBound20963 : H12AffineFastState.Bounded env20963 := by
  intro p hp
  have h : env20963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20895_20963 : H12AffineEnvironment.transform 6 9 env20895 = env20963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20895 == env20963) = true)

theorem identity20963 : scanCanonicalize (H12AffineFastState.compose env20963 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8634708) := by decide +kernel

theorem selectedBound20963 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env20964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8634708,8193,65,4229153,10634576,10507600,8538484,148805,14853149,257,2229617,2286685,221722]

theorem envBound20964 : H12AffineFastState.Bounded env20964 := by
  intro p hp
  have h : env20964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20963_20964 : H12AffineEnvironment.transform 23 8634708 env20963 = env20964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8634708 env20963 == env20964) = true)

def env20965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,98644,8193,65,4229153,2098512,2233680,2420,148805,6349853,257,2229617,2286685,221722]

theorem envBound20965 : H12AffineFastState.Bounded env20965 := by
  intro p hp
  have h : env20965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20964_20965 : H12AffineEnvironment.transform 22 147456 env20964 = env20965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env20964 == env20965) = true)

def env20966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,98644,8193,65,4229153,2098512,2118976,2420,1365,6349853,257,2114913,2139213,74250]

theorem envBound20966 : H12AffineFastState.Bounded env20966 := by
  intro p hp
  have h : env20966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20965_20966 : H12AffineEnvironment.transform 16 16400 env20965 = env20966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20965 == env20966) = true)

theorem identity20966 : scanCanonicalize (H12AffineFastState.compose env20966 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20966 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2098512,2118976,2420,1365,6349853,257,2114913,2139213,513]

theorem envBound20967 : H12AffineFastState.Bounded env20967 := by
  intro p hp
  have h : env20967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20966_20967 : H12AffineEnvironment.transform 15 8203 env20966 = env20967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20966 == env20967) = true)

theorem identity20967 : scanCanonicalize (H12AffineFastState.compose env20967 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound20967 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35189,1025,32769,2097152,2114912,16,41311,8193,65,2149697,2098512,2118976,2420,1365,41341,257,2114913,2139213,513]

theorem envBound20968 : H12AffineFastState.Bounded env20968 := by
  intro p hp
  have h : env20968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20967_20968 : H12AffineEnvironment.transform 21 2114912 env20967 = env20968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env20967 == env20968) = true)

theorem identity20968 : scanCanonicalize (H12AffineFastState.compose env20968 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound20968 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30776,1025,29004,2097152,2114912,16,20498,8193,65,2112524,2098512,2118976,2420,1365,20528,257,2114913,2118912,513]

theorem envBound20969 : H12AffineFastState.Bounded env20969 := by
  intro p hp
  have h : env20969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20968_20969 : H12AffineEnvironment.transform 14 29005 env20968 = env20969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env20968 == env20969) = true)

theorem identity20969 : scanCanonicalize (H12AffineFastState.compose env20969 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound20969 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env20970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30776,1025,29004,5457,20529,16,20498,8193,65,10589,4097,16401,2420,1365,20528,257,20528,16465,513]

theorem envBound20970 : H12AffineFastState.Bounded env20970 := by
  intro p hp
  have h : env20970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20969_20970 : H12AffineEnvironment.transform 20 5457 env20969 = env20970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env20969 == env20970) = true)

theorem identity20970 : scanCanonicalize (H12AffineFastState.compose env20970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10280,1025,8540,5457,33,16,2,8193,65,10589,4097,4097,2420,1365,32,257,32,4161,513]

theorem envBound20971 : H12AffineFastState.Bounded env20971 := by
  intro p hp
  have h : env20971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20970_20971 : H12AffineEnvironment.transform 13 4112 env20970 = env20971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env20970 == env20971) = true)

theorem identity20971 : scanCanonicalize (H12AffineFastState.compose env20971 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20971 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1,343,4096,2420,1025,0,5457,33,16,2,349,65,2049,4097,4097,2420,1365,32,257,32,4161,513]

theorem envBound20972 : H12AffineFastState.Bounded env20972 := by
  intro p hp
  have h : env20972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20971_20972 : H12AffineEnvironment.transform 12 348 env20971 = env20972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20971 == env20972) = true)

theorem identity20972 : scanCanonicalize (H12AffineFastState.compose env20972 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound20972 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,576,348,592,1,343,576,2420,1025,0,1809,33,16,2,349,65,2049,577,577,2420,1365,32,257,32,513,513]

theorem envBound20973 : H12AffineFastState.Bounded env20973 := by
  intro p hp
  have h : env20973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20972_20973 : H12AffineEnvironment.transform 11 576 env20972 = env20973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env20972 == env20973) = true)

theorem identity20973 : scanCanonicalize (H12AffineFastState.compose env20973 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound20973 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,529,576,348,592,1,343,576,869,1025,0,1809,33,16,2,349,65,528,577,577,869,1365,32,257,32,513,513]

theorem envBound20974 : H12AffineFastState.Bounded env20974 := by
  intro p hp
  have h : env20974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20973_20974 : H12AffineEnvironment.transform 10 529 env20973 = env20974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env20973 == env20974) = true)

theorem identity20974 : scanCanonicalize (H12AffineFastState.compose env20974 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound20974 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env20975 : List Nat := [2,4,8,16,32,64,9,256,512,543,529,576,348,592,1,343,576,869,542,0,270,33,16,2,349,65,528,577,577,869,842,32,257,32,513,513]

theorem envBound20975 : H12AffineFastState.Bounded env20975 := by
  intro p hp
  have h : env20975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20974_20975 : H12AffineEnvironment.transform 9 543 env20974 = env20975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env20974 == env20975) = true)

theorem identity20975 : scanCanonicalize (H12AffineFastState.compose env20975 (packedSelected [2,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound20975 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20976 : List Nat := [2,4,8,16,32,64,9,256,351,320,334,287,348,271,1,343,287,58,321,0,270,33,16,2,349,65,335,286,286,58,21,32,257,32,350,350]

theorem envBound20976 : H12AffineFastState.Bounded env20976 := by
  intro p hp
  have h : env20976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20975_20976 : H12AffineEnvironment.transform 8 351 env20975 = env20976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env20975 == env20976) = true)

theorem identity20976 : scanCanonicalize (H12AffineFastState.compose env20976 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound20976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20977 : List Nat := [2,4,8,16,32,43,9,256,308,299,293,287,311,271,1,316,287,58,298,0,270,33,16,2,310,42,292,286,286,58,21,32,257,32,309,309]

theorem envBound20977 : H12AffineFastState.Bounded env20977 := by
  intro p hp
  have h : env20977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20976_20977 : H12AffineEnvironment.transform 5 43 env20976 = env20977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env20976 == env20977) = true)

theorem identity20977 : scanCanonicalize (H12AffineFastState.compose env20977 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20977 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20978 : List Nat := [2,4,8,16,32,43,9,36,16,15,1,59,19,43,1,24,59,58,14,0,42,33,16,2,18,42,0,58,58,58,21,32,37,32,17,17]

theorem envBound20978 : H12AffineFastState.Bounded env20978 := by
  intro p hp
  have h : env20978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20977_20978 : H12AffineEnvironment.transform 7 36 env20977 = env20978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20977 == env20978) = true)

def env20979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,98644,8193,65,4229153,2098512,2118977,2420,1364,6349853,257,2114912,2139212,74251]

theorem envBound20979 : H12AffineFastState.Bounded env20979 := by
  intro p hp
  have h : env20979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20965_20979 : H12AffineEnvironment.transform 16 16401 env20965 = env20979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20965 == env20979) = true)

theorem identity20979 : scanCanonicalize (H12AffineFastState.compose env20979 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20979 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,2097152,4194304,17,3,8193,65,4229153,2098512,2118977,2420,1364,6349853,257,2114912,2139212,41820]

theorem envBound20980 : H12AffineFastState.Bounded env20980 := by
  intro p hp
  have h : env20980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20979_20980 : H12AffineEnvironment.transform 15 33111 env20979 = env20980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20979 == env20980) = true)

theorem identity20980 : scanCanonicalize (H12AffineFastState.compose env20980 (packedSelected [1,4,8,9,11,14,17,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound20980 : packedSelected [1,4,8,9,11,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env20981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,12392,4194304,17,3,8193,65,4229153,13624,25897,2420,1364,4248693,257,29960,37924,41820]

theorem envBound20981 : H12AffineFastState.Bounded env20981 := by
  intro p hp
  have h : env20981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20980_20981 : H12AffineEnvironment.transform 20 12392 env20980 = env20981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env20980 == env20981) = true)

theorem identity20981 : scanCanonicalize (H12AffineFastState.compose env20981 (packedSelected [0,7,9,14,16,17,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound20981 : packedSelected [0,7,9,14,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env20982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,12392,21508,17,3,8193,65,56357,13624,25897,2420,1364,32881,257,29960,37924,41820]

theorem envBound20982 : H12AffineFastState.Bounded env20982 := by
  intro p hp
  have h : env20982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20981_20982 : H12AffineEnvironment.transform 21 21508 env20981 = env20982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env20981 == env20982) = true)

theorem identity20982 : scanCanonicalize (H12AffineFastState.compose env20982 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20982 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env20983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10281,1025,8541,12392,21508,17,3,8193,65,32121,13624,25897,2420,1364,8493,257,29960,13688,512]

theorem envBound20983 : H12AffineFastState.Bounded env20983 := by
  intro p hp
  have h : env20983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20982_20983 : H12AffineEnvironment.transform 14 8540 env20982 = env20983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20982 == env20983) = true)

theorem identity20983 : scanCanonicalize (H12AffineFastState.compose env20983 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20983 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1025,8541,12392,260,17,3,8193,65,10361,13624,12329,2420,1364,8493,257,8200,13688,512]

theorem envBound20984 : H12AffineFastState.Bounded env20984 := by
  intro p hp
  have h : env20984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20983_20984 : H12AffineEnvironment.transform 13 5376 env20983 = env20984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20983 == env20984) = true)

theorem identity20984 : scanCanonicalize (H12AffineFastState.compose env20984 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound20984 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5376,340,3,5393,2081,1025,341,4192,260,17,3,9,65,2161,5424,4129,2420,1364,293,257,0,5488,512]

theorem envBound20985 : H12AffineFastState.Bounded env20985 := by
  intro p hp
  have h : env20985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20984_20985 : H12AffineEnvironment.transform 12 8 env20984 = env20985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env20984 == env20985) = true)

theorem identity20985 : scanCanonicalize (H12AffineFastState.compose env20985 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound20985 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20986 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,0,3,5189,2081,1025,1,4192,80,17,3,9,65,2161,5220,4129,2080,1024,113,85,0,5156,512]

theorem envBound20986 : H12AffineFastState.Bounded env20986 := by
  intro p hp
  have h : env20986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20985_20986 : H12AffineEnvironment.transform 7 84 env20985 = env20986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env20985 == env20986) = true)

theorem identity20986 : scanCanonicalize (H12AffineFastState.compose env20986 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20986 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20987 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8,5125,0,3,5140,2081,1025,1,4145,1,17,3,9,16,2080,5173,4129,2080,1024,32,4,0,5156,512]

theorem envBound20987 : H12AffineFastState.Bounded env20987 := by
  intro p hp
  have h : env20987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20986_20987 : H12AffineEnvironment.transform 5 17 env20986 = env20987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20986 == env20987) = true)

theorem identity20987 : scanCanonicalize (H12AffineFastState.compose env20987 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20988 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,0,3,5140,2048,1025,1,4112,1,17,3,9,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound20988 : H12AffineFastState.Bounded env20988 := by
  intro p hp
  have h : env20988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20987_20988 : H12AffineEnvironment.transform 4 1 env20987 = env20988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20987 == env20988) = true)

def env20989 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,0,3,1028,2048,1025,1,0,1,17,3,9,16,2049,1028,16,2049,1024,1,4,0,1045,512]

theorem envBound20989 : H12AffineFastState.Bounded env20989 := by
  intro p hp
  have h : env20989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20988_20989 : H12AffineEnvironment.transform 11 16 env20988 = env20989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20988 == env20989) = true)

end H12CloudChart1