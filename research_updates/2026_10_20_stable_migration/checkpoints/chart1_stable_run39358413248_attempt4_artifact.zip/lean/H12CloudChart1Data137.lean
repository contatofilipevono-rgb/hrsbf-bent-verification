import H12CloudChart1Data136

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env34762 : List Nat := [2,4,8,16,32,17,8,37,512,1024,523,4096,41,5156,0,34,5172,523,1024,1,4112,33,16,2,41,16,523,5172,4097,523,1057,33,37,32,5157,513]

theorem envBound34762 : H12AffineFastState.Bounded env34762 := by
  intro p hp
  have h : env34762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34761_34762 : H12AffineEnvironment.transform 10 523 env34761 = env34762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34761 == env34762) = true)

theorem identity34762 : scanCanonicalize (H12AffineFastState.compose env34762 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34762 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34763 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,4096,9,5124,0,2,5140,523,1024,1,4112,1,16,2,9,16,523,5140,4097,523,1025,1,5,0,5125,513]

theorem envBound34763 : H12AffineFastState.Bounded env34763 := by
  intro p hp
  have h : env34763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34762_34763 : H12AffineEnvironment.transform 4 0 env34762 = env34763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34762 == env34763) = true)

def env34764 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,16,9,1044,0,2,1028,523,1024,1,0,1,16,2,9,16,523,1028,17,523,1025,1,5,0,1045,513]

theorem envBound34764 : H12AffineFastState.Bounded env34764 := by
  intro p hp
  have h : env34764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34763_34764 : H12AffineEnvironment.transform 11 16 env34763 = env34764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34763 == env34764) = true)

theorem identity34764 : scanCanonicalize (H12AffineFastState.compose env34764 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound34764 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34765 : List Nat := [2,4,8,16,0,17,8,5,512,523,523,16,9,543,0,2,527,523,523,1,0,1,16,2,9,16,523,527,17,523,522,1,5,0,542,513]

theorem envBound34765 : H12AffineFastState.Bounded env34765 := by
  intro p hp
  have h : env34765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34764_34765 : H12AffineEnvironment.transform 9 523 env34764 = env34765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env34764 == env34765) = true)

def env34766 : List Nat := [2,4,8,4,0,5,8,5,512,523,523,4,9,523,0,2,527,523,523,1,0,1,4,2,9,4,523,527,5,523,522,1,5,0,522,513]

theorem envBound34766 : H12AffineFastState.Bounded env34766 := by
  intro p hp
  have h : env34766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34765_34766 : H12AffineEnvironment.transform 3 4 env34765 = env34766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env34765 == env34766) = true)

theorem identity34766 : scanCanonicalize (H12AffineFastState.compose env34766 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound34766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34767 : List Nat := [2,4,8,4,0,5,8,5,9,2,2,4,9,2,0,2,6,2,2,1,0,1,4,2,9,4,2,6,5,2,3,1,5,0,3,8]

theorem envBound34767 : H12AffineFastState.Bounded env34767 := by
  intro p hp
  have h : env34767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34766_34767 : H12AffineEnvironment.transform 8 9 env34766 = env34767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env34766 == env34767) = true)

def leafEnv34767 : List Nat := [2,4,8,4,0,5,8,5,9,2,2,4,9,2,0,2,6,2,2,1,0,1,4,2,2,9,1,4,2,6,5,2,3,1,5,0,5,2,3,8,1,1,0]

def active34767 : List Nat := [0,1,2]

def tree34767 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34767 : H12WitnessSearch.Good tree34767 := H12GlobalWitnessIndex.good

theorem leafIdentity34767 : H12AffineFastState.composeSystem env34767 rootObs = leafEnv34767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34767 rootObs == leafEnv34767) = true)

theorem terminalChecked34767 : H12PackedTerminal.terminalCheckFast leafEnv34767 active34767 tree34767 = true := by decide +kernel

def env34768 : List Nat := [2,4,8,5,0,4,8,5,512,523,523,5,9,522,0,2,527,523,523,1,0,1,5,2,9,5,523,527,4,523,522,1,5,0,523,513]

theorem envBound34768 : H12AffineFastState.Bounded env34768 := by
  intro p hp
  have h : env34768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34765_34768 : H12AffineEnvironment.transform 3 5 env34765 = env34768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34765 == env34768) = true)

theorem identity34768 : scanCanonicalize (H12AffineFastState.compose env34768 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34769 : List Nat := [1,4,8,5,0,4,8,5,512,520,520,5,9,521,0,1,524,520,520,1,0,1,5,1,9,5,520,524,4,520,521,1,5,0,520,513]

theorem envBound34769 : H12AffineFastState.Bounded env34769 := by
  intro p hp
  have h : env34769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34768_34769 : H12AffineEnvironment.transform 0 1 env34768 = env34769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34768 == env34769) = true)

def leafEnv34769 : List Nat := [1,4,8,5,0,4,8,5,512,520,520,5,9,521,0,1,524,520,520,1,0,1,5,1,520,9,1,5,520,524,4,520,521,1,5,0,5,1,520,513,1,1,0]

def active34769 : List Nat := [1,2,8]

def tree34769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34769 : H12WitnessSearch.Good tree34769 := H12GlobalWitnessIndex.good

theorem leafIdentity34769 : H12AffineFastState.composeSystem env34769 rootObs = leafEnv34769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34769 rootObs == leafEnv34769) = true)

theorem terminalChecked34769 : H12PackedTerminal.terminalCheckFast leafEnv34769 active34769 tree34769 = true := by decide +kernel

def env34770 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,17,9,1045,0,2,1029,523,1024,1,1,1,16,2,9,16,523,1029,16,523,1025,1,5,0,1044,513]

theorem envBound34770 : H12AffineFastState.Bounded env34770 := by
  intro p hp
  have h : env34770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34763_34770 : H12AffineEnvironment.transform 11 17 env34763 = env34770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34763 == env34770) = true)

theorem identity34770 : scanCanonicalize (H12AffineFastState.compose env34770 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound34770 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34771 : List Nat := [2,4,8,16,0,17,8,5,31,1024,20,17,9,1045,0,2,1029,20,1024,1,1,1,16,2,9,16,20,1029,16,20,1025,1,5,0,1044,30]

theorem envBound34771 : H12AffineFastState.Bounded env34771 := by
  intro p hp
  have h : env34771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34770_34771 : H12AffineEnvironment.transform 8 31 env34770 = env34771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env34770 == env34771) = true)

def env34772 : List Nat := [2,4,8,16,0,17,8,5,31,0,20,17,9,21,0,2,5,20,0,1,1,1,16,2,9,16,20,5,16,20,1,1,5,0,20,30]

theorem envBound34772 : H12AffineFastState.Bounded env34772 := by
  intro p hp
  have h : env34772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_34772 : H12AffineEnvironment.transform 9 0 env34771 = env34772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env34771 == env34772) = true)

theorem identity34772 : scanCanonicalize (H12AffineFastState.compose env34772 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34773 : List Nat := [2,4,8,6,0,7,8,5,9,0,2,7,9,3,0,2,5,2,0,1,1,1,6,2,9,6,2,5,6,2,1,1,5,0,2,8]

theorem envBound34773 : H12AffineFastState.Bounded env34773 := by
  intro p hp
  have h : env34773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34772_34773 : H12AffineEnvironment.transform 3 6 env34772 = env34773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34772 == env34773) = true)

def leafEnv34773 : List Nat := [2,4,8,6,0,7,8,5,9,0,2,7,9,3,0,2,5,2,0,1,1,1,6,2,0,9,1,6,2,5,6,2,1,1,5,0,5,2,2,8,1,0,0]

def active34773 : List Nat := [0,1,2]

def tree34773 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34773 : H12WitnessSearch.Good tree34773 := H12GlobalWitnessIndex.good

theorem leafIdentity34773 : H12AffineFastState.composeSystem env34773 rootObs = leafEnv34773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34773 rootObs == leafEnv34773) = true)

theorem terminalChecked34773 : H12PackedTerminal.terminalCheckFast leafEnv34773 active34773 tree34773 = true := by decide +kernel

def env34774 : List Nat := [2,4,8,16,0,17,8,5,31,1,20,17,9,20,0,2,4,20,1,1,1,1,16,2,9,16,20,4,16,20,0,1,5,0,21,30]

theorem envBound34774 : H12AffineFastState.Bounded env34774 := by
  intro p hp
  have h : env34774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_34774 : H12AffineEnvironment.transform 9 1 env34771 = env34774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env34771 == env34774) = true)

theorem identity34774 : scanCanonicalize (H12AffineFastState.compose env34774 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34775 : List Nat := [1,4,8,16,0,17,8,5,28,1,20,17,9,20,0,1,4,20,1,1,1,1,16,1,9,16,20,4,16,20,0,1,5,0,21,29]

theorem envBound34775 : H12AffineFastState.Bounded env34775 := by
  intro p hp
  have h : env34775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34774_34775 : H12AffineEnvironment.transform 0 1 env34774 = env34775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34774 == env34775) = true)

def leafEnv34775 : List Nat := [1,4,8,16,0,17,8,5,28,1,20,17,9,20,0,1,4,20,1,1,1,1,16,1,1,9,1,16,20,4,16,20,0,1,5,0,5,1,21,29,1,0,0]

def active34775 : List Nat := [1,2,3]

def tree34775 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34775 : H12WitnessSearch.Good tree34775 := H12GlobalWitnessIndex.good

theorem leafIdentity34775 : H12AffineFastState.composeSystem env34775 rootObs = leafEnv34775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34775 rootObs == leafEnv34775) = true)

theorem terminalChecked34775 : H12PackedTerminal.terminalCheckFast leafEnv34775 active34775 tree34775 = true := by decide +kernel

def env34776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4161,62708,120015,21763,8328,65,97547,115150,102879,56573,1501,119927,256,21793,46212,74250]

theorem envBound34776 : H12AffineFastState.Bounded env34776 := by
  intro p hp
  have h : env34776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34753_34776 : H12AffineEnvironment.transform 16 13389 env34753 = env34776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env34753 == env34776) = true)

theorem identity34776 : scanCanonicalize (H12AffineFastState.compose env34776 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34776 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env34777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,67755,1024,29909,4161,32,73755,21763,8328,65,97547,79130,91403,10281,1501,73891,256,21793,16464,74250]

theorem envBound34777 : H12AffineFastState.Bounded env34777 := by
  intro p hp
  have h : env34777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34776_34777 : H12AffineEnvironment.transform 14 29908 env34776 = env34777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34776 == env34777) = true)

theorem identity34777 : scanCanonicalize (H12AffineFastState.compose env34777 (packedSelected [0,1,2,3,6,7,8,10,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20894) := by decide +kernel

theorem selectedBound34777 : packedSelected [0,1,2,3,6,7,8,10,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,20894,13389,22837,1024,29909,4161,32,29061,21763,8328,65,11413,25732,13461,10281,1501,28989,256,21793,16464,29588]

theorem envBound34778 : H12AffineFastState.Bounded env34778 := by
  intro p hp
  have h : env34778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34777_34778 : H12AffineEnvironment.transform 15 20894 env34777 = env34778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20894 env34777 == env34778) = true)

theorem identity34778 : scanCanonicalize (H12AffineFastState.compose env34778 (packedSelected [3,5,9,11,15,16,18,22,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound34778 : packedSelected [3,5,9,11,15,16,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env34779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6429,16384,19913,20894,3408,22837,1024,19912,4161,32,18584,21763,6549,65,5512,23961,3464,4404,1501,18464,256,21793,16464,19081]

theorem envBound34779 : H12AffineFastState.Bounded env34779 := by
  intro p hp
  have h : env34779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34778_34779 : H12AffineEnvironment.transform 12 6429 env34778 = env34779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env34778 == env34779) = true)

theorem identity34779 : scanCanonicalize (H12AffineFastState.compose env34779 (packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34779 : packedSelected [1,2,3,4,5,6,8,9,10,12,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1213,4096,5536,16384,16756,20894,493,21896,1024,16757,4161,32,17445,21763,5416,65,5512,20772,309,4404,1501,17565,256,21793,16464,17972]

theorem envBound34780 : H12AffineFastState.Bounded env34780 := by
  intro p hp
  have h : env34780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34779_34780 : H12AffineEnvironment.transform 10 1213 env34779 = env34780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env34779 == env34780) = true)

theorem identity34780 : scanCanonicalize (H12AffineFastState.compose env34780 (packedSelected [0,1,2,4,8,9,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound34780 : packedSelected [0,1,2,4,8,9,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env34781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1213,4096,5536,4113,4453,399,493,1433,1024,4452,4161,32,5172,1298,5416,65,5512,309,309,4404,1501,5260,256,1328,4161,5669]

theorem envBound34781 : H12AffineFastState.Bounded env34781 := by
  intro p hp
  have h : env34781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34780_34781 : H12AffineEnvironment.transform 13 4113 env34780 = env34781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env34780 == env34781) = true)

theorem identity34781 : scanCanonicalize (H12AffineFastState.compose env34781 (packedSelected [0,1,2,8,9,11,12,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound34781 : packedSelected [0,1,2,8,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env34782 : List Nat := [2,4,8,16,32,64,128,256,512,189,0,4096,4381,4113,4453,399,493,292,189,4452,4161,32,4233,431,4501,65,4405,309,309,4404,352,4145,256,397,4161,4760]

theorem envBound34782 : H12AffineFastState.Bounded env34782 := by
  intro p hp
  have h : env34782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34781_34782 : H12AffineEnvironment.transform 9 189 env34781 = env34782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env34781 == env34782) = true)

theorem identity34782 : scanCanonicalize (H12AffineFastState.compose env34782 (packedSelected [0,3,5,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound34782 : packedSelected [0,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env34783 : List Nat := [2,4,8,16,32,64,128,256,512,189,0,65,348,80,292,399,493,292,189,293,0,32,200,431,468,65,372,309,309,373,352,112,256,397,0,729]

theorem envBound34783 : H12AffineFastState.Bounded env34783 := by
  intro p hp
  have h : env34783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34782_34783 : H12AffineEnvironment.transform 11 65 env34782 = env34783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env34782 == env34783) = true)

theorem identity34783 : scanCanonicalize (H12AffineFastState.compose env34783 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34783 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34784 : List Nat := [2,4,8,16,32,64,9,256,512,52,0,65,348,80,292,262,356,292,52,293,0,32,65,294,349,65,372,309,309,373,352,112,256,260,0,592]

theorem envBound34784 : H12AffineFastState.Bounded env34784 := by
  intro p hp
  have h : env34784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34783_34784 : H12AffineEnvironment.transform 6 9 env34783 = env34784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34783 == env34784) = true)

theorem identity34784 : scanCanonicalize (H12AffineFastState.compose env34784 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34784 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env34785 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,65,41,80,81,115,17,81,52,80,0,32,65,83,40,65,1,64,64,0,21,112,117,113,0,592]

theorem envBound34785 : H12AffineFastState.Bounded env34785 := by
  intro p hp
  have h : env34785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34784_34785 : H12AffineEnvironment.transform 7 117 env34784 = env34785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34784 == env34785) = true)

theorem identity34785 : scanCanonicalize (H12AffineFastState.compose env34785 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34785 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34786 : List Nat := [2,4,8,16,1,64,9,84,512,21,0,65,8,80,81,82,17,81,21,80,0,1,65,83,9,65,1,64,64,0,21,81,84,80,0,592]

theorem envBound34786 : H12AffineFastState.Bounded env34786 := by
  intro p hp
  have h : env34786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34785_34786 : H12AffineEnvironment.transform 4 1 env34785 = env34786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34785 == env34786) = true)

theorem identity34786 : scanCanonicalize (H12AffineFastState.compose env34786 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34786 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34787 : List Nat := [2,4,8,16,1,16,9,4,512,21,0,17,8,0,1,2,17,1,21,0,0,1,17,3,9,17,1,16,16,0,21,1,4,0,0,512]

theorem envBound34787 : H12AffineFastState.Bounded env34787 := by
  intro p hp
  have h : env34787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34786_34787 : H12AffineEnvironment.transform 5 16 env34786 = env34787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34786 == env34787) = true)

theorem identity34787 : scanCanonicalize (H12AffineFastState.compose env34787 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34788 : List Nat := [2,4,8,16,1,16,9,4,16,21,0,17,8,0,1,2,17,1,21,0,0,1,17,3,9,17,1,16,16,0,21,1,4,0,0,16]

theorem envBound34788 : H12AffineFastState.Bounded env34788 := by
  intro p hp
  have h : env34788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34787_34788 : H12AffineEnvironment.transform 8 16 env34787 = env34788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34787 == env34788) = true)

theorem identity34788 : scanCanonicalize (H12AffineFastState.compose env34788 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound34788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34789 : List Nat := [2,4,7,16,1,16,6,4,16,21,0,17,7,0,1,2,17,1,21,0,0,1,17,3,6,17,1,16,16,0,21,1,4,0,0,16]

theorem envBound34789 : H12AffineFastState.Bounded env34789 := by
  intro p hp
  have h : env34789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34788_34789 : H12AffineEnvironment.transform 2 7 env34788 = env34789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env34788 == env34789) = true)

theorem identity34789 : scanCanonicalize (H12AffineFastState.compose env34789 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34790 : List Nat := [2,4,7,0,1,0,6,4,0,5,0,1,7,0,1,2,1,1,5,0,0,1,1,3,6,1,1,0,0,0,5,1,4,0,0,0]

theorem envBound34790 : H12AffineFastState.Bounded env34790 := by
  intro p hp
  have h : env34790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34789_34790 : H12AffineEnvironment.transform 3 0 env34789 = env34790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34789 == env34790) = true)

def env34791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound34791 : H12AffineFastState.Bounded env34791 := by
  intro p hp
  have h : env34791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34533_34791 : H12AffineEnvironment.transform 18 1025 env34533 = env34791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34533 == env34791) = true)

theorem identity34791 : scanCanonicalize (H12AffineFastState.compose env34791 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485309) := by decide +kernel

theorem selectedBound34791 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485309,8328,65,14822461,288944,10507601,8830977,10774572,4491772,257,8661136,8702260,10833914]

theorem envBound34792 : H12AffineFastState.Bounded env34792 := by
  intro p hp
  have h : env34792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34791_34792 : H12AffineEnvironment.transform 23 2485309 env34791 = env34792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485309 env34791 == env34792) = true)

def env34793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294320,2485309,8328,65,6705549,288944,2369761,179633,2102684,4491772,257,21792,46212,2175562]

theorem envBound34793 : H12AffineFastState.Bounded env34793 := by
  intro p hp
  have h : env34793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34792_34793 : H12AffineEnvironment.transform 22 294320 env34792 = env34793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294320 env34792 == env34793) = true)

def env34794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294320,98781,8328,65,4340845,288944,17665,179633,292988,4491772,257,21792,46212,352170]

theorem envBound34794 : H12AffineFastState.Bounded env34794 := by
  intro p hp
  have h : env34794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34793_34794 : H12AffineEnvironment.transform 20 290272 env34793 = env34794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env34793 == env34794) = true)

def env34795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294320,98781,8328,65,398573,288944,17665,179633,292988,41340,257,21792,46212,352170]

theorem envBound34795 : H12AffineFastState.Bounded env34795 := by
  intro p hp
  have h : env34795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34794_34795 : H12AffineEnvironment.transform 21 272512 env34794 = env34795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34794 == env34795) = true)

theorem identity34795 : scanCanonicalize (H12AffineFastState.compose env34795 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound34795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1025,32769,77899,95531,73755,98781,8328,65,215366,79131,17665,179633,75223,41340,257,21792,46212,513]

theorem envBound34796 : H12AffineFastState.Bounded env34796 := by
  intro p hp
  have h : env34796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34795_34796 : H12AffineEnvironment.transform 17 89515 env34795 = env34796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env34795 == env34796) = true)

def env34797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77899,95531,73755,98645,8192,65,215366,79131,17665,179513,75103,41340,257,21792,46092,513]

theorem envBound34797 : H12AffineFastState.Bounded env34797 := by
  intro p hp
  have h : env34797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34796_34797 : H12AffineEnvironment.transform 6 8 env34796 = env34797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34796 == env34797) = true)

theorem identity34797 : scanCanonicalize (H12AffineFastState.compose env34797 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 91402) := by decide +kernel

theorem selectedBound34797 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,91402,89379,1025,32769,77899,95531,73755,98645,8192,65,11340,79131,17665,120883,75103,41340,257,21792,46092,513]

theorem envBound34798 : H12AffineFastState.Bounded env34798 := by
  intro p hp
  have h : env34798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34797_34798 : H12AffineEnvironment.transform 16 91402 env34797 = env34798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91402 env34797 == env34798) = true)

theorem identity34798 : scanCanonicalize (H12AffineFastState.compose env34798 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34798 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env34799 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,32768,65536,90138,88115,273,32769,77899,94267,73755,98645,8192,65,10588,77835,16401,120883,73807,41340,257,20528,45340,513]

theorem envBound34799 : H12AffineFastState.Bounded env34799 := by
  intro p hp
  have h : env34799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34798_34799 : H12AffineEnvironment.transform 9 272 env34798 = env34799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34798 == env34799) = true)

theorem identity34799 : scanCanonicalize (H12AffineFastState.compose env34799 (packedSelected [3,5,10,11,17,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound34799 : packedSelected [3,5,10,11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env34800 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,29005,65536,90138,88115,273,29004,77899,94267,73755,94232,8192,65,10588,77835,16401,76158,73807,20529,257,20528,16465,513]

theorem envBound34800 : H12AffineFastState.Bounded env34800 := by
  intro p hp
  have h : env34800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34799_34800 : H12AffineEnvironment.transform 14 29005 env34799 = env34800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env34799 == env34800) = true)

theorem identity34800 : scanCanonicalize (H12AffineFastState.compose env34800 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound34800 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34801 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,65536,77834,67619,273,8540,77899,73771,73755,73736,8192,65,10588,77835,4097,76158,73807,33,257,32,4161,513]

theorem envBound34801 : H12AffineFastState.Bounded env34801 := by
  intro p hp
  have h : env34801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34800_34801 : H12AffineEnvironment.transform 13 4112 env34800 = env34801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env34800 == env34801) = true)

theorem identity34801 : scanCanonicalize (H12AffineFastState.compose env34801 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound34801 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env34802 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,2310,14604,293,273,8540,14669,10541,10525,10510,8192,65,10588,14605,4097,8312,10569,33,257,32,4161,513]

theorem envBound34802 : H12AffineFastState.Bounded env34802 := by
  intro p hp
  have h : env34802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34801_34802 : H12AffineEnvironment.transform 15 2310 env34801 = env34802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env34801 == env34802) = true)

theorem identity34802 : scanCanonicalize (H12AffineFastState.compose env34802 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound34802 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34803 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,4381,4112,4160,2310,2065,293,273,4161,2128,6192,6144,6163,4381,65,6209,2064,4097,4453,6228,33,257,32,4161,513]

theorem envBound34803 : H12AffineFastState.Bounded env34803 := by
  intro p hp
  have h : env34803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34802_34803 : H12AffineEnvironment.transform 12 4381 env34802 = env34803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env34802 == env34803) = true)

theorem identity34803 : scanCanonicalize (H12AffineFastState.compose env34803 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound34803 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34804 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2065,2316,2049,2129,2310,2065,293,273,2128,2128,33,17,2,2316,65,80,2064,2064,2420,69,33,257,32,2128,513]

theorem envBound34804 : H12AffineFastState.Bounded env34804 := by
  intro p hp
  have h : env34804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34803_34804 : H12AffineEnvironment.transform 11 2065 env34803 = env34804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env34803 == env34804) = true)

theorem identity34804 : scanCanonicalize (H12AffineFastState.compose env34804 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound34804 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34805 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,324,89,340,260,83,324,293,273,261,261,33,17,2,89,65,80,325,325,33,69,33,257,32,261,513]

theorem envBound34805 : H12AffineFastState.Bounded env34805 := by
  intro p hp
  have h : env34805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34804_34805 : H12AffineEnvironment.transform 10 341 env34804 = env34805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env34804 == env34805) = true)

theorem identity34805 : scanCanonicalize (H12AffineFastState.compose env34805 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound34805 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34806 : List Nat := [2,4,8,16,32,64,8,256,80,272,341,324,89,340,260,83,324,293,273,261,261,33,17,2,89,65,80,325,325,33,69,33,257,32,261,81]

theorem envBound34806 : H12AffineFastState.Bounded env34806 := by
  intro p hp
  have h : env34806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34805_34806 : H12AffineEnvironment.transform 8 80 env34805 = env34806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env34805 == env34806) = true)

theorem identity34806 : scanCanonicalize (H12AffineFastState.compose env34806 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34806 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env34807 : List Nat := [2,4,8,16,32,49,8,256,33,272,292,309,40,293,260,34,309,293,273,261,261,33,17,2,40,48,33,308,308,33,52,33,257,32,261,32]

theorem envBound34807 : H12AffineFastState.Bounded env34807 := by
  intro p hp
  have h : env34807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34806_34807 : H12AffineEnvironment.transform 5 49 env34806 = env34807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34806 == env34807) = true)

theorem identity34807 : scanCanonicalize (H12AffineFastState.compose env34807 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound34807 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34808 : List Nat := [2,4,8,16,32,49,8,52,33,36,16,1,40,17,48,34,1,17,37,49,49,33,17,2,40,48,33,0,0,33,52,33,53,32,49,32]

theorem envBound34808 : H12AffineFastState.Bounded env34808 := by
  intro p hp
  have h : env34808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34807_34808 : H12AffineEnvironment.transform 7 52 env34807 = env34808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env34807 == env34808) = true)

theorem identity34808 : scanCanonicalize (H12AffineFastState.compose env34808 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34808 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34809 : List Nat := [2,4,8,16,16,1,8,4,17,20,16,1,24,17,0,18,1,17,21,1,1,17,17,2,24,0,17,0,0,17,4,17,5,16,1,16]

theorem envBound34809 : H12AffineFastState.Bounded env34809 := by
  intro p hp
  have h : env34809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34808_34809 : H12AffineEnvironment.transform 4 16 env34808 = env34809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34808 == env34809) = true)

def env34810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95531,73755,98644,8193,65,215366,79131,17665,179512,75102,41340,257,21792,46093,513]

theorem envBound34810 : H12AffineFastState.Bounded env34810 := by
  intro p hp
  have h : env34810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34796_34810 : H12AffineEnvironment.transform 6 9 env34796 = env34810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34796 == env34810) = true)

theorem identity34810 : scanCanonicalize (H12AffineFastState.compose env34810 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound34810 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35188,1025,32769,58397,41341,62541,21762,8193,65,171280,57677,17665,179512,61704,41340,257,21792,46093,513]

theorem envBound34811 : H12AffineFastState.Bounded env34811 := by
  intro p hp
  have h : env34811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34810_34811 : H12AffineEnvironment.transform 15 54358 env34810 = env34811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env34810 == env34811) = true)

theorem identity34811 : scanCanonicalize (H12AffineFastState.compose env34811 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34811 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env34812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,35188,1025,32769,45340,41341,41292,3,8193,65,171280,46156,4096,179512,41993,41340,257,33,46093,513]

theorem envBound34812 : H12AffineFastState.Bounded env34812 := by
  intro p hp
  have h : env34812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34811_34812 : H12AffineEnvironment.transform 13 5377 env34811 = env34812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34811 == env34812) = true)

theorem identity34812 : scanCanonicalize (H12AffineFastState.compose env34812 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34812 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34813 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,131072,35109,1025,32769,45340,41260,41245,3,8193,16,171280,46109,4096,179512,41993,41261,257,33,46093,513]

theorem envBound34813 : H12AffineFastState.Bounded env34813 := by
  intro p hp
  have h : env34813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34812_34813 : H12AffineEnvironment.transform 5 17 env34812 = env34813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34812 == env34813) = true)

theorem identity34813 : scanCanonicalize (H12AffineFastState.compose env34813 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound34813 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34814 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1025,8461,4112,32,17,3,8193,16,146460,5393,4096,138292,1285,33,257,33,5377,513]

theorem envBound34814 : H12AffineFastState.Bounded env34814 := by
  intro p hp
  have h : env34814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34813_34814 : H12AffineEnvironment.transform 14 8460 env34813 = env34814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env34813 == env34814) = true)

theorem identity34814 : scanCanonicalize (H12AffineFastState.compose env34814 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound34814 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34815 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5377,261,3,131072,2080,1025,260,4112,32,17,3,8,16,138261,5393,4096,138292,1285,33,257,33,5377,513]

theorem envBound34815 : H12AffineFastState.Bounded env34815 := by
  intro p hp
  have h : env34815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34814_34815 : H12AffineEnvironment.transform 12 9 env34814 = env34815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env34814 == env34815) = true)

def env34816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294320,98781,8328,65,398572,288944,17665,179633,292988,41341,257,21792,46212,352170]

theorem envBound34816 : H12AffineFastState.Bounded env34816 := by
  intro p hp
  have h : env34816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34794_34816 : H12AffineEnvironment.transform 21 272513 env34794 = env34816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34794 == env34816) = true)

theorem identity34816 : scanCanonicalize (H12AffineFastState.compose env34816 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,290272,272513,294320,41431,8328,65,398572,288944,17665,179633,292988,41341,257,21792,46212,294816]

theorem envBound34817 : H12AffineFastState.Bounded env34817 := by
  intro p hp
  have h : env34817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34816_34817 : H12AffineEnvironment.transform 15 8202 env34816 = env34817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34816 == env34817) = true)

def env34818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,16,41431,8328,65,158028,5392,17665,179633,1500,41341,257,21792,46212,512]

theorem envBound34818 : H12AffineFastState.Bounded env34818 := by
  intro p hp
  have h : env34818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34817_34818 : H12AffineEnvironment.transform 17 32160 env34817 = env34818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env34817 == env34818) = true)

theorem identity34818 : scanCanonicalize (H12AffineFastState.compose env34818 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound34818 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8202,131072,32160,1025,8353,4160,21793,16,375,8328,65,158028,5392,17665,138513,1500,477,257,21792,5156,512]

theorem envBound34819 : H12AffineFastState.Bounded env34819 := by
  intro p hp
  have h : env34819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34818_34819 : H12AffineEnvironment.transform 14 8352 env34818 = env34819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env34818 == env34819) = true)

theorem identity34819 : scanCanonicalize (H12AffineFastState.compose env34819 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound34819 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8202,5173,32160,1025,8353,4160,21793,16,375,8328,65,32121,5392,17665,2340,1500,477,257,21792,5156,512]

theorem envBound34820 : H12AffineFastState.Bounded env34820 := by
  intro p hp
  have h : env34820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34819_34820 : H12AffineEnvironment.transform 16 5173 env34819 = env34820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env34819 == env34820) = true)

theorem identity34820 : scanCanonicalize (H12AffineFastState.compose env34820 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound34820 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,8352,8202,5173,2388,1025,8353,4160,8661,16,375,8328,65,2445,5392,12789,2340,1500,477,257,8660,5156,512]

theorem envBound34821 : H12AffineFastState.Bounded env34821 := by
  intro p hp
  have h : env34821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34820_34821 : H12AffineEnvironment.transform 13 13556 env34820 = env34821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env34820 == env34821) = true)

theorem identity34821 : scanCanonicalize (H12AffineFastState.compose env34821 (packedSelected [2,11,14,18,19,26] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound34821 : packedSelected [2,11,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env34822 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,13556,8352,8202,5173,2297,1025,8353,4160,8312,16,218,8328,65,2080,5309,12376,2185,1137,112,172,8313,5156,512]

theorem envBound34822 : H12AffineFastState.Bounded env34822 := by
  intro p hp
  have h : env34822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34821_34822 : H12AffineEnvironment.transform 7 173 env34821 = env34822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34821 == env34822) = true)

theorem identity34822 : scanCanonicalize (H12AffineFastState.compose env34822 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound34822 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env34823 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,88,5292,248,82,5173,2297,1025,249,4160,32,16,218,208,65,2080,5309,4096,2185,1137,112,172,33,5156,512]

theorem envBound34823 : H12AffineFastState.Bounded env34823 := by
  intro p hp
  have h : env34823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34822_34823 : H12AffineEnvironment.transform 12 88 env34822 = env34823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env34822 == env34823) = true)

def env34824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,17,41431,8328,65,158029,5393,17665,179633,1501,41341,257,21792,46212,513]

theorem envBound34824 : H12AffineFastState.Bounded env34824 := by
  intro p hp
  have h : env34824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34817_34824 : H12AffineEnvironment.transform 17 32161 env34817 = env34824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env34817 == env34824) = true)

theorem identity34824 : scanCanonicalize (H12AffineFastState.compose env34824 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound34824 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24981,32161,1025,32769,4161,21792,17,41431,8328,65,2264,5393,17665,56356,1501,41341,257,21792,46212,513]

theorem envBound34825 : H12AffineFastState.Bounded env34825 := by
  intro p hp
  have h : env34825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34824_34825 : H12AffineEnvironment.transform 16 24981 env34824 = env34825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env34824 == env34825) = true)

theorem identity34825 : scanCanonicalize (H12AffineFastState.compose env34825 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound34825 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,24981,32161,1025,29708,4161,21792,17,21978,8328,65,2264,5393,17665,10281,1501,21872,257,21792,16521,513]

theorem envBound34826 : H12AffineFastState.Bounded env34826 := by
  intro p hp
  have h : env34826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34825_34826 : H12AffineEnvironment.transform 14 29709 env34825 = env34826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env34825 == env34826) = true)

theorem identity34826 : scanCanonicalize (H12AffineFastState.compose env34826 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound34826 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env34827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21896,399,16400,23588,1025,21897,4161,21792,17,21978,269,65,2264,5393,17665,2476,1501,21872,257,21792,16521,513]

theorem envBound34827 : H12AffineFastState.Bounded env34827 := by
  intro p hp
  have h : env34827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34826_34827 : H12AffineEnvironment.transform 12 389 env34826 = env34827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env34826 == env34827) = true)

theorem identity34827 : scanCanonicalize (H12AffineFastState.compose env34827 (packedSelected [3,4,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound34827 : packedSelected [3,4,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5156,428,399,5172,2048,1025,429,4161,260,17,510,269,65,2264,5393,4389,2476,1501,340,257,260,5293,513]

theorem envBound34828 : H12AffineFastState.Bounded env34828 := by
  intro p hp
  have h : env34828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34827_34828 : H12AffineEnvironment.transform 13 5156 env34827 = env34828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env34827 == env34828) = true)

theorem identity34828 : scanCanonicalize (H12AffineFastState.compose env34828 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound34828 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env34829 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,120,5156,81,114,5172,2048,1025,80,4161,249,17,3,240,65,2264,5356,4312,2129,1056,169,252,249,5293,513]

theorem envBound34829 : H12AffineFastState.Bounded env34829 := by
  intro p hp
  have h : env34829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34828_34829 : H12AffineEnvironment.transform 7 253 env34828 = env34829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env34828 == env34829) = true)

theorem identity34829 : scanCanonicalize (H12AffineFastState.compose env34829 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34829 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34830 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,5156,81,114,5172,2048,1025,80,4161,32,17,3,41,65,2049,5173,4097,2129,1056,112,37,32,5236,513]

theorem envBound34830 : H12AffineFastState.Bounded env34830 := by
  intro p hp
  have h : env34830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34829_34830 : H12AffineEnvironment.transform 6 89 env34829 = env34830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34829 == env34830) = true)

theorem identity34830 : scanCanonicalize (H12AffineFastState.compose env34830 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34830 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34831 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,4113,32,17,3,41,17,2049,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound34831 : H12AffineFastState.Bounded env34831 := by
  intro p hp
  have h : env34831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34830_34831 : H12AffineEnvironment.transform 5 16 env34830 = env34831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34830 == env34831) = true)

theorem identity34831 : scanCanonicalize (H12AffineFastState.compose env34831 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34831 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34832 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4113,1,34,4097,2048,52,0,4113,32,17,3,41,17,2049,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound34832 : H12AffineFastState.Bounded env34832 := by
  intro p hp
  have h : env34832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34831_34832 : H12AffineEnvironment.transform 9 53 env34831 = env34832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34831 == env34832) = true)

theorem identity34832 : scanCanonicalize (H12AffineFastState.compose env34832 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound34832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34833 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,17,40,0,1,34,16,2048,52,0,0,32,17,3,41,17,2049,17,16,2049,21,32,37,32,0,513]

theorem envBound34833 : H12AffineFastState.Bounded env34833 := by
  intro p hp
  have h : env34833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34832_34833 : H12AffineEnvironment.transform 11 17 env34832 = env34833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34832 == env34833) = true)

theorem identity34833 : scanCanonicalize (H12AffineFastState.compose env34833 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34834 : List Nat := [2,4,8,16,32,16,9,36,512,53,522,17,40,0,1,34,16,522,52,0,0,32,17,3,41,17,523,17,16,523,21,32,37,32,0,513]

theorem envBound34834 : H12AffineFastState.Bounded env34834 := by
  intro p hp
  have h : env34834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34833_34834 : H12AffineEnvironment.transform 10 522 env34833 = env34834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34833 == env34834) = true)

theorem identity34834 : scanCanonicalize (H12AffineFastState.compose env34834 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound34834 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34835 : List Nat := [2,4,8,16,32,16,9,36,10,53,0,17,40,0,1,34,16,0,52,0,0,32,17,3,41,17,1,17,16,1,21,32,37,32,0,11]

theorem envBound34835 : H12AffineFastState.Bounded env34835 := by
  intro p hp
  have h : env34835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34834_34835 : H12AffineEnvironment.transform 8 10 env34834 = env34835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env34834 == env34835) = true)

def env34836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294320,98780,8328,65,4340844,288944,17664,179633,292989,4491772,257,21792,46212,352171]

theorem envBound34836 : H12AffineFastState.Bounded env34836 := by
  intro p hp
  have h : env34836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34793_34836 : H12AffineEnvironment.transform 20 290273 env34793 = env34836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env34793 == env34836) = true)

def env34837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294320,98780,8328,65,398572,288944,17664,179633,292989,41340,257,21792,46212,352171]

theorem envBound34837 : H12AffineFastState.Bounded env34837 := by
  intro p hp
  have h : env34837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34836_34837 : H12AffineEnvironment.transform 21 272512 env34836 = env34837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34836 == env34837) = true)

theorem identity34837 : scanCanonicalize (H12AffineFastState.compose env34837 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound34837 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108927,1025,32769,115870,98815,120015,98780,8328,65,245139,115151,17664,179633,119042,41340,257,21792,46212,63188]

theorem envBound34838 : H12AffineFastState.Bounded env34838 := by
  intro p hp
  have h : env34838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34837_34838 : H12AffineEnvironment.transform 17 108927 env34837 = env34838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env34837 == env34838) = true)

def env34839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1025,32769,102814,98815,98767,98780,8328,65,245139,103631,4096,179633,99330,41340,257,32,46212,41940]

theorem envBound34839 : H12AffineFastState.Bounded env34839 := by
  intro p hp
  have h : env34839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34838_34839 : H12AffineEnvironment.transform 13 5376 env34838 = env34839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34838 == env34839) = true)

theorem identity34839 : scanCanonicalize (H12AffineFastState.compose env34839 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34839 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env34840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35189,1025,32769,45460,41461,41413,41430,8328,65,171417,46277,4096,179633,41992,41340,257,32,46212,41940]

theorem envBound34840 : H12AffineFastState.Bounded env34840 := by
  intro p hp
  have h : env34840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34839_34840 : H12AffineEnvironment.transform 15 8202 env34839 = env34840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34839 == env34840) = true)

theorem identity34840 : scanCanonicalize (H12AffineFastState.compose env34840 (packedSelected [3,5,6,12,17,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound34840 : packedSelected [3,5,6,12,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5376,32768,2,131072,35189,1025,32769,37276,33277,33229,33246,128,65,171417,38093,4096,171449,33792,33140,257,32,38028,33756]

theorem envBound34841 : H12AffineFastState.Bounded env34841 := by
  intro p hp
  have h : env34841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34840_34841 : H12AffineEnvironment.transform 12 8 env34840 = env34841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env34840 == env34841) = true)

theorem identity34841 : scanCanonicalize (H12AffineFastState.compose env34841 (packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34841 : packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env34842 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8,5376,32768,2,131072,35189,1025,32769,37189,33060,33044,33031,89,65,171328,37908,4096,171360,33792,33140,257,32,37973,33541]

theorem envBound34842 : H12AffineFastState.Bounded env34842 := by
  intro p hp
  have h : env34842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34841_34842 : H12AffineEnvironment.transform 6 89 env34841 = env34842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34841 == env34842) = true)

theorem identity34842 : scanCanonicalize (H12AffineFastState.compose env34842 (packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34842 : packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env34843 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5376,32768,2,131072,35109,1025,32769,37141,33060,33044,33031,9,17,171280,37908,4096,171312,33792,33060,257,32,37893,33541]

theorem envBound34843 : H12AffineFastState.Bounded env34843 := by
  intro p hp
  have h : env34843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34842_34843 : H12AffineEnvironment.transform 5 16 env34842 = env34843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34842 == env34843) = true)

theorem identity34843 : scanCanonicalize (H12AffineFastState.compose env34843 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound34843 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34844 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8,5376,32768,2,38160,35109,1025,32769,37141,33060,33044,33031,9,17,2048,37908,4096,2080,33792,33060,257,32,37893,33541]

theorem envBound34844 : H12AffineFastState.Bounded env34844 := by
  intro p hp
  have h : env34844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34843_34844 : H12AffineEnvironment.transform 16 38160 env34843 = env34844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env34843 == env34844) = true)

theorem identity34844 : scanCanonicalize (H12AffineFastState.compose env34844 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3360) := by decide +kernel

theorem selectedBound34844 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env34845 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3360,8,2080,32768,2,34864,35109,1025,32769,35893,33060,33044,33031,9,17,2048,35124,3360,2080,33792,33060,257,32,35109,33541]

theorem envBound34845 : H12AffineFastState.Bounded env34845 := by
  intro p hp
  have h : env34845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34844_34845 : H12AffineEnvironment.transform 11 3360 env34844 = env34845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3360 env34844 == env34845) = true)

theorem identity34845 : scanCanonicalize (H12AffineFastState.compose env34845 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound34845 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34846 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3360,8,2080,261,2,2357,2080,1025,260,3376,33,17,2,9,17,2048,2097,3360,2080,1285,33,257,32,2080,512]

theorem envBound34846 : H12AffineFastState.Bounded env34846 := by
  intro p hp
  have h : env34846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34845_34846 : H12AffineEnvironment.transform 14 261 env34845 = env34846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env34845 == env34846) = true)

theorem identity34846 : scanCanonicalize (H12AffineFastState.compose env34846 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34846 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34847 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3328,8,2048,261,2,2325,2048,1025,260,3344,1,17,2,9,17,2048,2065,3328,2048,1285,1,257,0,2048,512]

theorem envBound34847 : H12AffineFastState.Bounded env34847 := by
  intro p hp
  have h : env34847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34846_34847 : H12AffineEnvironment.transform 4 0 env34846 = env34847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34846 == env34847) = true)

theorem identity34847 : scanCanonicalize (H12AffineFastState.compose env34847 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1792) := by decide +kernel

theorem selectedBound34847 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34848 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1792,512,8,1792,261,2,1557,1792,1025,260,528,1,17,2,9,17,1792,1809,512,1792,1285,1,257,0,1792,512]

theorem envBound34848 : H12AffineFastState.Bounded env34848 := by
  intro p hp
  have h : env34848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34847_34848 : H12AffineEnvironment.transform 10 1792 env34847 = env34848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env34847 == env34848) = true)

theorem identity34848 : scanCanonicalize (H12AffineFastState.compose env34848 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34848 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34849 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1541,512,8,1541,0,2,1557,1541,1025,1,528,1,17,2,9,17,1541,1556,512,1541,1024,1,4,0,1541,512]

theorem envBound34849 : H12AffineFastState.Bounded env34849 := by
  intro p hp
  have h : env34849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34848_34849 : H12AffineEnvironment.transform 7 5 env34848 = env34849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34848 == env34849) = true)

theorem identity34849 : scanCanonicalize (H12AffineFastState.compose env34849 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34850 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1028,1,8,1028,0,2,1044,1028,1025,1,17,1,17,2,9,17,1028,1045,1,1028,1024,1,4,0,1028,1]

theorem envBound34850 : H12AffineFastState.Bounded env34850 := by
  intro p hp
  have h : env34850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34849_34850 : H12AffineEnvironment.transform 8 1 env34849 = env34850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34849 == env34850) = true)

theorem identity34850 : scanCanonicalize (H12AffineFastState.compose env34850 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound34850 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34851 : List Nat := [2,4,8,16,0,16,9,5,1,15,11,1,8,11,0,2,27,11,14,1,17,1,17,2,9,17,11,26,1,11,15,1,4,0,11,1]

theorem envBound34851 : H12AffineFastState.Bounded env34851 := by
  intro p hp
  have h : env34851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34850_34851 : H12AffineEnvironment.transform 9 15 env34850 = env34851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env34850 == env34851) = true)

theorem identity34851 : scanCanonicalize (H12AffineFastState.compose env34851 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34851 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34852 : List Nat := [0,4,8,16,0,16,9,5,1,13,9,1,8,9,0,0,25,9,12,1,17,1,17,0,9,17,9,24,1,9,13,1,4,0,9,1]

theorem envBound34852 : H12AffineFastState.Bounded env34852 := by
  intro p hp
  have h : env34852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34851_34852 : H12AffineEnvironment.transform 0 0 env34851 = env34852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34851 == env34852) = true)

theorem identity34852 : scanCanonicalize (H12AffineFastState.compose env34852 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound34852 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34853 : List Nat := [0,4,8,8,0,8,9,5,1,13,9,1,8,9,0,0,1,9,12,1,9,1,9,0,9,9,9,0,1,9,13,1,4,0,9,1]

theorem envBound34853 : H12AffineFastState.Bounded env34853 := by
  intro p hp
  have h : env34853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34852_34853 : H12AffineEnvironment.transform 3 8 env34852 = env34853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env34852 == env34853) = true)

theorem identity34853 : scanCanonicalize (H12AffineFastState.compose env34853 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34854 : List Nat := [0,4,4,4,0,4,5,5,1,1,5,1,4,5,0,0,1,5,0,1,5,1,5,0,5,5,5,0,1,5,1,1,4,0,5,1]

theorem envBound34854 : H12AffineFastState.Bounded env34854 := by
  intro p hp
  have h : env34854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34853_34854 : H12AffineEnvironment.transform 2 4 env34853 = env34854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34853 == env34854) = true)

def env34855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1025,32769,102815,98815,98766,98780,8328,65,245139,103630,4097,179633,99331,41340,257,33,46212,41941]

theorem envBound34855 : H12AffineFastState.Bounded env34855 := by
  intro p hp
  have h : env34855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34838_34855 : H12AffineEnvironment.transform 13 5377 env34838 = env34855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34838 == env34855) = true)

theorem identity34855 : scanCanonicalize (H12AffineFastState.compose env34855 (packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound34855 : packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,131072,35325,1025,32769,45341,41341,41292,41310,8328,65,171281,46156,4097,179633,42113,41340,257,33,46212,41941]

theorem envBound34856 : H12AffineFastState.Bounded env34856 := by
  intro p hp
  have h : env34856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34855_34856 : H12AffineEnvironment.transform 15 8322 env34855 = env34856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env34855 == env34856) = true)

theorem identity34856 : scanCanonicalize (H12AffineFastState.compose env34856 (packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound34856 : packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env34857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,5393,35325,1025,32769,45341,41341,41292,41310,8328,65,34816,46156,4097,43168,42113,41340,257,33,46212,41941]

theorem envBound34857 : H12AffineFastState.Bounded env34857 := by
  intro p hp
  have h : env34857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34856_34857 : H12AffineEnvironment.transform 16 5393 env34856 = env34857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env34856 == env34857) = true)

theorem identity34857 : scanCanonicalize (H12AffineFastState.compose env34857 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound34857 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,5393,10281,1025,8661,4297,169,152,138,8328,65,10708,5528,4097,2420,1365,168,257,33,5456,513]

theorem envBound34858 : H12AffineFastState.Bounded env34858 := by
  intro p hp
  have h : env34858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34857_34858 : H12AffineEnvironment.transform 14 8660 env34857 = env34858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34857 == env34858) = true)

def env34859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294320,98780,8328,65,398573,288944,17664,179633,292989,41341,257,21792,46212,352171]

theorem envBound34859 : H12AffineFastState.Bounded env34859 := by
  intro p hp
  have h : env34859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34836_34859 : H12AffineEnvironment.transform 21 272513 env34836 = env34859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34836 == env34859) = true)

theorem identity34859 : scanCanonicalize (H12AffineFastState.compose env34859 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound34859 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,290273,272513,294320,21762,8328,65,398573,288944,17664,179633,292989,41341,257,21792,46212,297845]

theorem envBound34860 : H12AffineFastState.Bounded env34860 := by
  intro p hp
  have h : env34860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34859_34860 : H12AffineEnvironment.transform 15 54494 env34859 = env34860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env34859 == env34860) = true)

def env34861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,290153,272393,294200,21762,8192,65,398437,288824,17664,179513,292989,41341,257,21792,46092,297845]

theorem envBound34861 : H12AffineFastState.Bounded env34861 := by
  intro p hp
  have h : env34861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34860_34861 : H12AffineEnvironment.transform 6 8 env34860 = env34861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34860 == env34861) = true)

theorem identity34861 : scanCanonicalize (H12AffineFastState.compose env34861 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound34861 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,146744,1025,32769,151633,136497,147456,21762,8192,65,10589,152832,17664,179513,148805,41341,257,21792,46092,177741]

theorem envBound34862 : H12AffineFastState.Bounded env34862 := by
  intro p hp
  have h : env34862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34861_34862 : H12AffineEnvironment.transform 17 146744 env34861 = env34862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env34861 == env34862) = true)

theorem identity34862 : scanCanonicalize (H12AffineFastState.compose env34862 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound34862 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env34863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16400,32040,1025,32769,4161,21793,16,21762,8192,65,10589,5392,17664,64809,1365,41341,257,21792,46092,63069]

theorem envBound34863 : H12AffineFastState.Bounded env34863 := by
  intro p hp
  have h : env34863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34862_34863 : H12AffineEnvironment.transform 16 16400 env34862 = env34863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34862 == env34863) = true)

theorem identity34863 : scanCanonicalize (H12AffineFastState.compose env34863 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,32040,1025,29788,4161,21793,16,21762,8192,65,10589,5392,17664,2420,1365,21792,257,21792,16465,512]

theorem envBound34864 : H12AffineFastState.Bounded env34864 := by
  intro p hp
  have h : env34864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34863_34864 : H12AffineEnvironment.transform 14 29789 env34863 = env34864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34863 == env34864) = true)

theorem identity34864 : scanCanonicalize (H12AffineFastState.compose env34864 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound34864 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8312,8203,5173,10509,1025,8313,4161,260,16,295,8192,65,10589,5392,4389,2420,1365,261,257,261,5236,512]

theorem envBound34865 : H12AffineFastState.Bounded env34865 := by
  intro p hp
  have h : env34865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34864_34865 : H12AffineEnvironment.transform 13 5157 env34864 = env34865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env34864 == env34865) = true)

theorem identity34865 : scanCanonicalize (H12AffineFastState.compose env34865 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound34865 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env34866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2057,5157,2161,2050,5173,260,1025,2160,4161,260,16,295,2057,65,340,5392,4389,2420,1365,261,257,261,5236,512]

theorem envBound34866 : H12AffineFastState.Bounded env34866 := by
  intro p hp
  have h : env34866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34865_34866 : H12AffineEnvironment.transform 12 2057 env34865 = env34866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env34865 == env34866) = true)

theorem identity34866 : scanCanonicalize (H12AffineFastState.compose env34866 (packedSelected [5,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound34866 : packedSelected [5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env34867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,340,4096,349,5157,293,342,5173,260,1025,292,4161,260,16,295,349,65,340,5392,4389,32,1365,261,257,261,5236,512]

theorem envBound34867 : H12AffineFastState.Bounded env34867 := by
  intro p hp
  have h : env34867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34866_34867 : H12AffineEnvironment.transform 10 340 env34866 = env34867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env34866 == env34867) = true)

theorem identity34867 : scanCanonicalize (H12AffineFastState.compose env34867 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34868 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1,4096,8,5157,112,3,5173,81,1025,113,4161,81,16,114,8,65,1,5189,4208,32,1024,80,84,80,5236,512]

theorem envBound34868 : H12AffineFastState.Bounded env34868 := by
  intro p hp
  have h : env34868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34867_34868 : H12AffineEnvironment.transform 7 85 env34867 = env34868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34867 == env34868) = true)

theorem identity34868 : scanCanonicalize (H12AffineFastState.compose env34868 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound34868 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env34869 : List Nat := [2,4,8,16,32,64,8,85,512,37,1,4096,8,4096,112,3,4112,81,36,113,4161,81,16,114,8,65,1,4192,4208,32,37,80,84,80,4177,512]

theorem envBound34869 : H12AffineFastState.Bounded env34869 := by
  intro p hp
  have h : env34869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34868_34869 : H12AffineEnvironment.transform 9 37 env34868 = env34869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env34868 == env34869) = true)

theorem identity34869 : scanCanonicalize (H12AffineFastState.compose env34869 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34869 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env34870 : List Nat := [2,4,8,16,32,17,8,4,512,37,1,4096,8,4096,33,3,4112,0,36,32,4112,0,16,35,8,16,1,4145,4129,32,37,1,5,1,4096,512]

theorem envBound34870 : H12AffineFastState.Bounded env34870 := by
  intro p hp
  have h : env34870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34869_34870 : H12AffineEnvironment.transform 5 17 env34869 = env34870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34869 == env34870) = true)

theorem identity34870 : scanCanonicalize (H12AffineFastState.compose env34870 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound34870 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34871 : List Nat := [2,4,8,16,32,17,8,4,512,37,1,544,8,544,33,3,560,0,36,32,560,0,16,35,8,16,1,529,513,32,37,1,5,1,544,512]

theorem envBound34871 : H12AffineFastState.Bounded env34871 := by
  intro p hp
  have h : env34871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34870_34871 : H12AffineEnvironment.transform 11 544 env34870 = env34871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env34870 == env34871) = true)

theorem identity34871 : scanCanonicalize (H12AffineFastState.compose env34871 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34871 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34872 : List Nat := [2,4,8,16,32,17,8,4,16,37,1,48,8,48,33,3,32,0,36,32,32,0,16,35,8,16,1,1,17,32,37,1,5,1,48,16]

theorem envBound34872 : H12AffineFastState.Bounded env34872 := by
  intro p hp
  have h : env34872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34871_34872 : H12AffineEnvironment.transform 8 16 env34871 = env34872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34871 == env34872) = true)

theorem identity34872 : scanCanonicalize (H12AffineFastState.compose env34872 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34872 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34873 : List Nat := [2,4,8,16,0,17,8,4,16,5,1,16,8,16,1,3,0,0,4,0,0,0,16,3,8,16,1,1,17,0,5,1,5,1,16,16]

theorem envBound34873 : H12AffineFastState.Bounded env34873 := by
  intro p hp
  have h : env34873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34872_34873 : H12AffineEnvironment.transform 4 0 env34872 = env34873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34872 == env34873) = true)

def env34874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,290152,272392,294201,21762,8193,65,398436,288825,17664,179512,292989,41341,257,21792,46093,297845]

theorem envBound34874 : H12AffineFastState.Bounded env34874 := by
  intro p hp
  have h : env34874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34860_34874 : H12AffineEnvironment.transform 6 9 env34860 = env34874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34860 == env34874) = true)

theorem identity34874 : scanCanonicalize (H12AffineFastState.compose env34874 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound34874 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35188,1025,32769,58396,41340,62541,21762,8193,65,171280,57677,17664,179512,61705,41341,257,21792,46093,513]

theorem envBound34875 : H12AffineFastState.Bounded env34875 := by
  intro p hp
  have h : env34875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34874_34875 : H12AffineEnvironment.transform 17 35188 env34874 = env34875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34874 == env34875) = true)

theorem identity34875 : scanCanonicalize (H12AffineFastState.compose env34875 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34875 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21792,17,21762,8193,65,158028,5393,17664,149860,1365,21793,257,21792,16465,513]

theorem envBound34876 : H12AffineFastState.Bounded env34876 := by
  intro p hp
  have h : env34876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34875_34876 : H12AffineEnvironment.transform 14 29788 env34875 = env34876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34875 == env34876) = true)

def env34877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294321,2485309,8328,65,6705548,288944,2369760,179632,2102685,4491772,257,21793,46213,2175563]

theorem envBound34877 : H12AffineFastState.Bounded env34877 := by
  intro p hp
  have h : env34877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34792_34877 : H12AffineEnvironment.transform 22 294321 env34792 = env34877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294321 env34792 == env34877) = true)

def env34878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294321,98781,8328,65,4340844,288944,17664,179632,292989,4491772,257,21793,46213,352171]

theorem envBound34878 : H12AffineFastState.Bounded env34878 := by
  intro p hp
  have h : env34878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34877_34878 : H12AffineEnvironment.transform 20 290272 env34877 = env34878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env34877 == env34878) = true)

def env34879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294321,98781,8328,65,398572,288944,17664,179632,292989,41340,257,21793,46213,352171]

theorem envBound34879 : H12AffineFastState.Bounded env34879 := by
  intro p hp
  have h : env34879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34878_34879 : H12AffineEnvironment.transform 21 272512 env34878 = env34879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34878 == env34879) = true)

def env34880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272392,294201,98645,8192,65,398436,288824,17664,179512,292989,41340,257,21793,46093,352035]

theorem envBound34880 : H12AffineFastState.Bounded env34880 := by
  intro p hp
  have h : env34880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34879_34880 : H12AffineEnvironment.transform 6 8 env34879 = env34880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34879 == env34880) = true)

theorem identity34880 : scanCanonicalize (H12AffineFastState.compose env34880 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound34880 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,290152,272392,294201,98645,8192,65,283765,288824,17664,64809,292989,41340,257,21793,46093,352035]

theorem envBound34881 : H12AffineFastState.Bounded env34881 := by
  intro p hp
  have h : env34881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34880_34881 : H12AffineEnvironment.transform 16 16401 env34880 = env34881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34880 == env34881) = true)

def env34882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,262144,1025,32769,276584,272392,272441,98645,8192,65,262517,277816,4096,43049,273789,41340,257,33,46093,330275]

theorem envBound34882 : H12AffineFastState.Bounded env34882 := by
  intro p hp
  have h : env34882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34881_34882 : H12AffineEnvironment.transform 13 5376 env34881 = env34882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34881 == env34882) = true)

theorem identity34882 : scanCanonicalize (H12AffineFastState.compose env34882 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound34882 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35189,1025,32769,45341,41341,41292,98645,8192,65,34816,46157,4096,43049,41992,41340,257,33,46093,99158]

theorem envBound34883 : H12AffineFastState.Bounded env34883 := by
  intro p hp
  have h : env34883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34882_34883 : H12AffineEnvironment.transform 17 35189 env34882 = env34883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env34882 == env34883) = true)

theorem identity34883 : scanCanonicalize (H12AffineFastState.compose env34883 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound34883 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5393,35189,1025,32769,45341,41341,41292,2,8192,65,34816,46157,4096,43049,41992,41340,257,33,46093,513]

theorem envBound34884 : H12AffineFastState.Bounded env34884 := by
  intro p hp
  have h : env34884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34883_34884 : H12AffineEnvironment.transform 15 33111 env34883 = env34884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env34883 == env34884) = true)

theorem identity34884 : scanCanonicalize (H12AffineFastState.compose env34884 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound34884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8283,5393,10361,1025,8461,4113,113,64,2,8192,65,10508,5441,4096,2341,1284,112,257,33,5377,513]

theorem envBound34885 : H12AffineFastState.Bounded env34885 := by
  intro p hp
  have h : env34885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34884_34885 : H12AffineEnvironment.transform 14 8460 env34884 = env34885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env34884 == env34885) = true)

theorem identity34885 : scanCanonicalize (H12AffineFastState.compose env34885 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34885 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34886 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8313,8283,5220,10361,1025,8312,4113,113,64,2,8192,65,10361,5172,4096,2128,1137,112,116,33,5236,513]

theorem envBound34886 : H12AffineFastState.Bounded env34886 := by
  intro p hp
  have h : env34886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34885_34886 : H12AffineEnvironment.transform 7 117 env34885 = env34886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34885 == env34886) = true)

theorem identity34886 : scanCanonicalize (H12AffineFastState.compose env34886 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound34886 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34887 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,4096,8192,5237,8313,8283,5220,8233,1025,8312,4113,113,64,2,8192,65,8233,5172,4096,0,1137,112,116,33,5236,513]

theorem envBound34887 : H12AffineFastState.Bounded env34887 := by
  intro p hp
  have h : env34887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34886_34887 : H12AffineEnvironment.transform 10 80 env34886 = env34887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env34886 == env34887) = true)

theorem identity34887 : scanCanonicalize (H12AffineFastState.compose env34887 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound34887 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env34888 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,4096,4153,5237,4160,4194,5220,4112,1025,4161,4113,113,64,2,4153,65,4112,5172,4096,0,1137,112,116,33,5236,513]

theorem envBound34888 : H12AffineFastState.Bounded env34888 := by
  intro p hp
  have h : env34888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34887_34888 : H12AffineEnvironment.transform 12 4153 env34887 = env34888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env34887 == env34888) = true)

theorem identity34888 : scanCanonicalize (H12AffineFastState.compose env34888 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34888 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env34889 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,4096,4153,4112,4160,4194,4097,4112,100,4161,4113,113,64,2,4153,65,4112,4177,4096,0,20,112,116,33,4113,513]

theorem envBound34889 : H12AffineFastState.Bounded env34889 := by
  intro p hp
  have h : env34889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34888_34889 : H12AffineEnvironment.transform 9 101 env34888 = env34889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34888 == env34889) = true)

theorem identity34889 : scanCanonicalize (H12AffineFastState.compose env34889 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound34889 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34890 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,64,121,80,0,34,65,80,100,1,81,113,64,2,121,65,80,17,64,0,20,112,116,33,81,513]

theorem envBound34890 : H12AffineFastState.Bounded env34890 := by
  intro p hp
  have h : env34890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34889_34890 : H12AffineEnvironment.transform 11 64 env34889 = env34890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env34889 == env34890) = true)

def env34891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,262144,1025,32769,276585,272392,272440,98645,8192,65,262516,277817,4097,43048,273788,41340,257,32,46093,330274]

theorem envBound34891 : H12AffineFastState.Bounded env34891 := by
  intro p hp
  have h : env34891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34881_34891 : H12AffineEnvironment.transform 13 5377 env34881 = env34891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34881 == env34891) = true)

theorem identity34891 : scanCanonicalize (H12AffineFastState.compose env34891 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,5392,262144,1025,8540,276585,272392,272440,73736,8192,65,262516,277817,4097,2421,273788,33,257,32,5456,330274]

theorem envBound34892 : H12AffineFastState.Bounded env34892 := by
  intro p hp
  have h : env34892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34891_34892 : H12AffineEnvironment.transform 14 8541 env34891 = env34892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34891 == env34892) = true)

theorem identity34892 : scanCanonicalize (H12AffineFastState.compose env34892 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34892 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5392,262144,1025,8540,276585,272392,272440,2,8192,65,262516,277817,4097,2421,273788,33,257,32,5456,272936]

theorem envBound34893 : H12AffineFastState.Bounded env34893 := by
  intro p hp
  have h : env34893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34892_34893 : H12AffineEnvironment.transform 15 8202 env34892 = env34893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34892 == env34893) = true)

theorem identity34893 : scanCanonicalize (H12AffineFastState.compose env34893 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7432) := by decide +kernel

theorem selectedBound34893 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7432,5377,7253,7426,5392,262144,1025,7252,263521,267520,267568,2,7432,65,262516,262193,4097,2421,266356,33,257,32,5456,268064]

theorem envBound34894 : H12AffineFastState.Bounded env34894 := by
  intro p hp
  have h : env34894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34893_34894 : H12AffineEnvironment.transform 12 7432 env34893 = env34894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7432 env34893 == env34894) = true)

theorem identity34894 : scanCanonicalize (H12AffineFastState.compose env34894 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 3345) := by decide +kernel

theorem selectedBound34894 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env34895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7432,5377,7253,7426,5392,3345,1025,7252,2160,6161,6177,2,7432,65,3173,3360,4097,2421,7525,33,257,32,5456,6705]

theorem envBound34895 : H12AffineFastState.Bounded env34895 := by
  intro p hp
  have h : env34895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34894_34895 : H12AffineEnvironment.transform 17 3345 env34894 = env34895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3345 env34894 == env34895) = true)

theorem identity34895 : scanCanonicalize (H12AffineFastState.compose env34895 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34895 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env34896 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7293,5236,7253,7287,5221,3172,1025,7252,2160,6161,6177,2,7293,65,3173,3157,4097,2048,7184,33,116,32,5157,6705]

theorem envBound34896 : H12AffineFastState.Bounded env34896 := by
  intro p hp
  have h : env34896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34895_34896 : H12AffineEnvironment.transform 7 117 env34895 = env34896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34895 == env34896) = true)

theorem identity34896 : scanCanonicalize (H12AffineFastState.compose env34896 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound34896 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34897 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3108,89,2128,113,83,2113,3172,1025,112,2160,1077,1029,2,89,65,3173,3157,3109,2048,52,33,116,32,2049,1557]

theorem envBound34897 : H12AffineFastState.Bounded env34897 := by
  intro p hp
  have h : env34897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34896_34897 : H12AffineEnvironment.transform 11 3108 env34896 = env34897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env34896 == env34897) = true)

theorem identity34897 : scanCanonicalize (H12AffineFastState.compose env34897 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound34897 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34898 : List Nat := [2,4,8,16,32,64,8,117,512,564,2048,2576,89,2128,113,83,2113,2640,565,112,2160,513,561,2,89,65,2641,2657,2577,2048,52,33,116,32,2049,33]

theorem envBound34898 : H12AffineFastState.Bounded env34898 := by
  intro p hp
  have h : env34898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34897_34898 : H12AffineEnvironment.transform 9 564 env34897 = env34898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env34897 == env34898) = true)

theorem identity34898 : scanCanonicalize (H12AffineFastState.compose env34898 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34898 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34899 : List Nat := [2,4,8,16,32,49,8,4,512,564,2048,2576,40,2081,0,34,2096,2593,565,1,2049,513,561,2,40,48,2592,2576,2577,2048,52,33,5,32,2049,33]

theorem envBound34899 : H12AffineFastState.Bounded env34899 := by
  intro p hp
  have h : env34899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34898_34899 : H12AffineEnvironment.transform 5 49 env34898 = env34899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34898 == env34899) = true)

theorem identity34899 : scanCanonicalize (H12AffineFastState.compose env34899 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34899 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34900 : List Nat := [2,4,8,16,32,49,8,4,512,564,33,561,40,0,0,34,17,512,565,1,32,513,561,2,40,48,513,561,560,33,52,33,5,32,32,33]

theorem envBound34900 : H12AffineFastState.Bounded env34900 := by
  intro p hp
  have h : env34900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34899_34900 : H12AffineEnvironment.transform 10 33 env34899 = env34900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34899 == env34900) = true)

theorem identity34900 : scanCanonicalize (H12AffineFastState.compose env34900 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34900 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34901 : List Nat := [2,4,8,16,16,1,8,4,512,516,17,513,24,0,0,18,17,512,517,1,16,513,513,2,24,0,513,513,512,17,4,17,5,16,16,17]

theorem envBound34901 : H12AffineFastState.Bounded env34901 := by
  intro p hp
  have h : env34901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34900_34901 : H12AffineEnvironment.transform 4 16 env34900 = env34901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34900 == env34901) = true)

theorem identity34901 : scanCanonicalize (H12AffineFastState.compose env34901 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34901 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34902 : List Nat := [2,4,8,1,1,1,8,4,512,516,0,513,9,0,0,3,0,512,517,1,1,513,513,2,9,0,513,513,512,0,4,0,5,1,1,0]

theorem envBound34902 : H12AffineFastState.Bounded env34902 := by
  intro p hp
  have h : env34902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34901_34902 : H12AffineEnvironment.transform 3 1 env34901 = env34902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34901 == env34902) = true)

theorem identity34902 : scanCanonicalize (H12AffineFastState.compose env34902 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34902 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34903 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,1,9,0,0,3,0,0,5,1,1,1,1,2,9,0,1,1,0,0,4,0,5,1,1,0]

theorem envBound34903 : H12AffineFastState.Bounded env34903 := by
  intro p hp
  have h : env34903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34902_34903 : H12AffineEnvironment.transform 8 0 env34902 = env34903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34902 == env34903) = true)

def env34904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294200,98644,8193,65,398437,288825,17664,179513,292989,41340,257,21793,46092,352034]

theorem envBound34904 : H12AffineFastState.Bounded env34904 := by
  intro p hp
  have h : env34904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34879_34904 : H12AffineEnvironment.transform 6 9 env34879 = env34904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34879 == env34904) = true)

theorem identity34904 : scanCanonicalize (H12AffineFastState.compose env34904 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound34904 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73755,98644,8193,65,215366,79130,17664,179513,75102,41340,257,21793,46092,513]

theorem envBound34905 : H12AffineFastState.Bounded env34905 := by
  intro p hp
  have h : env34905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34904_34905 : H12AffineEnvironment.transform 17 89379 env34904 = env34905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env34904 == env34905) = true)

theorem identity34905 : scanCanonicalize (H12AffineFastState.compose env34905 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound34905 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35188,1025,32769,58397,41341,62540,21763,8193,65,171281,57677,17664,179513,61705,41340,257,21793,46092,513]

theorem envBound34906 : H12AffineFastState.Bounded env34906 := by
  intro p hp
  have h : env34906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34905_34906 : H12AffineEnvironment.transform 15 54359 env34905 = env34906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env34905 == env34906) = true)

theorem identity34906 : scanCanonicalize (H12AffineFastState.compose env34906 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound34906 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env34907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,35188,1025,32769,45341,41341,41292,3,8193,65,171281,46157,4096,179513,41993,41340,257,33,46092,513]

theorem envBound34907 : H12AffineFastState.Bounded env34907 := by
  intro p hp
  have h : env34907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34906_34907 : H12AffineEnvironment.transform 13 5376 env34906 = env34907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34906 == env34907) = true)

theorem identity34907 : scanCanonicalize (H12AffineFastState.compose env34907 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34907 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34908 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33030,131072,35109,1025,32769,45341,41260,41245,3,8193,16,171281,46108,4096,179513,41993,41261,257,33,46092,513]

theorem envBound34908 : H12AffineFastState.Bounded env34908 := by
  intro p hp
  have h : env34908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34907_34908 : H12AffineEnvironment.transform 5 17 env34907 = env34908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34907 == env34908) = true)

theorem identity34908 : scanCanonicalize (H12AffineFastState.compose env34908 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound34908 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34909 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10281,1025,8461,4113,32,17,3,8193,16,146461,5392,4096,138293,1285,33,257,33,5376,513]

theorem envBound34909 : H12AffineFastState.Bounded env34909 := by
  intro p hp
  have h : env34909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34908_34909 : H12AffineEnvironment.transform 14 8460 env34908 = env34909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env34908 == env34909) = true)

theorem identity34909 : scanCanonicalize (H12AffineFastState.compose env34909 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13593) := by decide +kernel

theorem selectedBound34909 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34910 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,13593,10281,1025,8461,4113,32,17,3,8193,16,2308,5392,4096,10540,1285,33,257,33,5376,513]

theorem envBound34910 : H12AffineFastState.Bounded env34910 := by
  intro p hp
  have h : env34910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34909_34910 : H12AffineEnvironment.transform 16 13593 env34909 = env34910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13593 env34909 == env34910) = true)

def env34911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294321,98781,8328,65,398573,288944,17664,179632,292989,41341,257,21793,46213,352171]

theorem envBound34911 : H12AffineFastState.Bounded env34911 := by
  intro p hp
  have h : env34911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34878_34911 : H12AffineEnvironment.transform 21 272513 env34878 = env34911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34878 == env34911) = true)

theorem identity34911 : scanCanonicalize (H12AffineFastState.compose env34911 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound34911 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21793,17,98781,8328,65,158029,5392,17664,179632,1501,41341,257,21793,46213,74251]

theorem envBound34912 : H12AffineFastState.Bounded env34912 := by
  intro p hp
  have h : env34912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34911_34912 : H12AffineEnvironment.transform 17 32160 env34911 = env34912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env34911 == env34912) = true)

theorem identity34912 : scanCanonicalize (H12AffineFastState.compose env34912 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34912 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,17,41431,8328,65,158029,5392,17664,179632,1501,41341,257,21793,46213,513]

theorem envBound34913 : H12AffineFastState.Bounded env34913 := by
  intro p hp
  have h : env34913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34912_34913 : H12AffineEnvironment.transform 15 8202 env34912 = env34913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34912 == env34913) = true)

theorem identity34913 : scanCanonicalize (H12AffineFastState.compose env34913 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound34913 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24981,32160,1025,32769,4160,21793,17,41431,8328,65,2264,5392,17664,56357,1501,41341,257,21793,46213,513]

theorem envBound34914 : H12AffineFastState.Bounded env34914 := by
  intro p hp
  have h : env34914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34913_34914 : H12AffineEnvironment.transform 16 24981 env34913 = env34914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env34913 == env34914) = true)

theorem identity34914 : scanCanonicalize (H12AffineFastState.compose env34914 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound34914 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,24981,32160,1025,29709,4160,21793,17,21979,8328,65,2264,5392,17664,10281,1501,21873,257,21793,16521,513]

theorem envBound34915 : H12AffineFastState.Bounded env34915 := by
  intro p hp
  have h : env34915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34914_34915 : H12AffineEnvironment.transform 14 29708 env34914 = env34915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env34914 == env34915) = true)

theorem identity34915 : scanCanonicalize (H12AffineFastState.compose env34915 (packedSelected [2,3,6,10,17,18,19,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound34915 : packedSelected [2,3,6,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env34916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21897,399,16400,23589,1025,21896,4160,21793,17,21979,269,65,2264,5392,17664,2476,1501,21873,257,21793,16521,513]

theorem envBound34916 : H12AffineFastState.Bounded env34916 := by
  intro p hp
  have h : env34916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34915_34916 : H12AffineEnvironment.transform 12 389 env34915 = env34916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env34915 == env34916) = true)

theorem identity34916 : scanCanonicalize (H12AffineFastState.compose env34916 (packedSelected [3,4,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound34916 : packedSelected [3,4,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34917 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,16384,21621,115,16400,23589,1025,21620,4160,21725,17,21543,241,65,2264,5356,17660,2128,1057,21645,253,21725,16521,513]

theorem envBound34917 : H12AffineFastState.Bounded env34917 := by
  intro p hp
  have h : env34917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34916_34917 : H12AffineEnvironment.transform 7 252 env34916 = env34917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env34916 == env34917) = true)

theorem identity34917 : scanCanonicalize (H12AffineFastState.compose env34917 (packedSelected [0,2,5,6,8,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound34917 : packedSelected [0,2,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env34918 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,121,5372,137,115,5356,2265,1025,136,4160,33,17,219,241,65,2264,5356,4096,2128,1057,113,253,33,5237,513]

theorem envBound34918 : H12AffineFastState.Bounded env34918 := by
  intro p hp
  have h : env34918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34917_34918 : H12AffineEnvironment.transform 13 5372 env34917 = env34918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env34917 == env34918) = true)

theorem identity34918 : scanCanonicalize (H12AffineFastState.compose env34918 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34918 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34919 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5293,137,34,5309,2184,1025,136,4113,33,17,138,160,16,2185,5309,4096,2049,1057,32,172,33,5156,513]

theorem envBound34919 : H12AffineFastState.Bounded env34919 := by
  intro p hp
  have h : env34919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34918_34919 : H12AffineEnvironment.transform 5 17 env34918 = env34919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34918 == env34919) = true)

theorem identity34919 : scanCanonicalize (H12AffineFastState.compose env34919 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34919 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34920 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5172,2049,1025,1,4113,33,17,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound34920 : H12AffineFastState.Bounded env34920 := by
  intro p hp
  have h : env34920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34919_34920 : H12AffineEnvironment.transform 6 9 env34919 = env34920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34919 == env34920) = true)

def env34921 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,0,34,1028,2049,1025,1,33,33,17,3,41,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound34921 : H12AffineFastState.Bounded env34921 := by
  intro p hp
  have h : env34921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34920_34921 : H12AffineEnvironment.transform 11 48 env34920 = env34921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34920 == env34921) = true)

theorem identity34921 : scanCanonicalize (H12AffineFastState.compose env34921 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound34921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34922 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,48,40,1,0,34,17,2049,20,1,33,33,17,3,41,16,2048,17,48,2049,52,32,37,33,1,513]

theorem envBound34922 : H12AffineFastState.Bounded env34922 := by
  intro p hp
  have h : env34922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34921_34922 : H12AffineEnvironment.transform 9 21 env34921 = env34922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34921 == env34922) = true)

def env34923 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,8,1,0,2,17,2049,20,1,1,1,17,3,9,16,2048,17,16,2049,20,0,5,1,1,513]

theorem envBound34923 : H12AffineFastState.Bounded env34923 := by
  intro p hp
  have h : env34923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34922_34923 : H12AffineEnvironment.transform 4 0 env34922 = env34923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34922 == env34923) = true)

theorem identity34923 : scanCanonicalize (H12AffineFastState.compose env34923 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34924 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,16,8,1,0,2,17,522,20,1,1,1,17,3,9,16,523,17,16,522,20,0,5,1,1,513]

theorem envBound34924 : H12AffineFastState.Bounded env34924 := by
  intro p hp
  have h : env34924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34923_34924 : H12AffineEnvironment.transform 10 523 env34923 = env34924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34923 == env34924) = true)

def leafEnv34924 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,16,8,1,0,2,17,522,20,1,1,1,17,3,21,9,1,16,523,17,16,522,20,0,5,1,5,3,1,513,1,1,0]

def active34924 : List Nat := [0,1,2,3,8]

def tree34924 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34924 : H12WitnessSearch.Good tree34924 := H12GlobalWitnessIndex.good

theorem leafIdentity34924 : H12AffineFastState.composeSystem env34924 rootObs = leafEnv34924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34924 rootObs == leafEnv34924) = true)

theorem terminalChecked34924 : H12PackedTerminal.terminalCheckFast leafEnv34924 active34924 tree34924 = true := by decide +kernel

def env34925 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,9,1,0,3,17,2049,20,1,0,0,17,3,8,16,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound34925 : H12AffineFastState.Bounded env34925 := by
  intro p hp
  have h : env34925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34922_34925 : H12AffineEnvironment.transform 4 1 env34922 = env34925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34922 == env34925) = true)

theorem identity34925 : scanCanonicalize (H12AffineFastState.compose env34925 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34926 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,1,0,3,17,0,20,1,0,0,17,3,8,16,1,17,17,0,21,1,4,0,1,513]

theorem envBound34926 : H12AffineFastState.Bounded env34926 := by
  intro p hp
  have h : env34926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34925_34926 : H12AffineEnvironment.transform 10 1 env34925 = env34926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34925 == env34926) = true)

def leafEnv34926 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,9,1,0,3,17,0,20,1,0,0,17,3,20,8,1,16,1,17,17,0,21,1,4,0,5,2,1,513,1,0,0]

def active34926 : List Nat := [0,1,2,3,8]

def tree34926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34926 : H12WitnessSearch.Good tree34926 := H12GlobalWitnessIndex.good

theorem leafIdentity34926 : H12AffineFastState.composeSystem env34926 rootObs = leafEnv34926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34926 rootObs == leafEnv34926) = true)

theorem terminalChecked34926 : H12PackedTerminal.terminalCheckFast leafEnv34926 active34926 tree34926 = true := by decide +kernel

def env34927 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,0,34,1029,2049,1025,1,32,33,17,3,41,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound34927 : H12AffineFastState.Bounded env34927 := by
  intro p hp
  have h : env34927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34920_34927 : H12AffineEnvironment.transform 11 49 env34920 = env34927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34920 == env34927) = true)

theorem identity34927 : scanCanonicalize (H12AffineFastState.compose env34927 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34928 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,0,3,1029,2049,1025,1,1,0,17,3,8,16,2048,1029,16,2049,1024,1,4,0,1045,513]

theorem envBound34928 : H12AffineFastState.Bounded env34928 := by
  intro p hp
  have h : env34928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34927_34928 : H12AffineEnvironment.transform 4 1 env34927 = env34928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34927 == env34928) = true)

def env34929 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,0,3,17,2049,21,1,1,0,17,3,8,16,2048,17,16,2049,20,1,4,0,1,513]

theorem envBound34929 : H12AffineFastState.Bounded env34929 := by
  intro p hp
  have h : env34929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34928_34929 : H12AffineEnvironment.transform 9 20 env34928 = env34929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34928 == env34929) = true)

theorem identity34929 : scanCanonicalize (H12AffineFastState.compose env34929 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34929 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34930 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,16,9,1,0,3,17,523,21,1,1,0,17,3,8,16,522,17,16,523,20,1,4,0,1,513]

theorem envBound34930 : H12AffineFastState.Bounded env34930 := by
  intro p hp
  have h : env34930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34929_34930 : H12AffineEnvironment.transform 10 522 env34929 = env34930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34929 == env34930) = true)

def leafEnv34930 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,16,9,1,0,3,17,523,21,1,1,0,17,3,21,8,1,16,522,17,16,523,20,1,4,0,5,2,1,513,1,1,0]

def active34930 : List Nat := [0,1,2,3,8]

def tree34930 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34930 : H12WitnessSearch.Good tree34930 := H12GlobalWitnessIndex.good

theorem leafIdentity34930 : H12AffineFastState.composeSystem env34930 rootObs = leafEnv34930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34930 rootObs == leafEnv34930) = true)

theorem terminalChecked34930 : H12PackedTerminal.terminalCheckFast leafEnv34930 active34930 tree34930 = true := by decide +kernel

def env34931 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,9,0,0,3,16,2049,20,1,1,0,17,3,8,16,2048,16,16,2049,21,1,4,0,0,513]

theorem envBound34931 : H12AffineFastState.Bounded env34931 := by
  intro p hp
  have h : env34931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34928_34931 : H12AffineEnvironment.transform 9 21 env34928 = env34931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env34928 == env34931) = true)

theorem identity34931 : scanCanonicalize (H12AffineFastState.compose env34931 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34932 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,0,0,3,16,1,20,1,1,0,17,3,8,16,0,16,16,1,21,1,4,0,0,513]

theorem envBound34932 : H12AffineFastState.Bounded env34932 := by
  intro p hp
  have h : env34932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34931_34932 : H12AffineEnvironment.transform 10 0 env34931 = env34932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34931 == env34932) = true)

def leafEnv34932 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,16,9,0,0,3,16,1,20,1,1,0,17,3,20,8,1,16,0,16,16,1,21,1,4,0,5,2,0,513,1,1,0]

def active34932 : List Nat := [0,1,2,3,8]

def tree34932 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34932 : H12WitnessSearch.Good tree34932 := H12GlobalWitnessIndex.good

theorem leafIdentity34932 : H12AffineFastState.composeSystem env34932 rootObs = leafEnv34932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34932 rootObs == leafEnv34932) = true)

theorem terminalChecked34932 : H12PackedTerminal.terminalCheckFast leafEnv34932 active34932 tree34932 = true := by decide +kernel

def env34933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294321,98780,8328,65,4340845,288944,17665,179632,292988,4491772,257,21793,46213,352170]

theorem envBound34933 : H12AffineFastState.Bounded env34933 := by
  intro p hp
  have h : env34933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34877_34933 : H12AffineEnvironment.transform 20 290273 env34877 = env34933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env34877 == env34933) = true)

def env34934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294321,98780,8328,65,398573,288944,17665,179632,292988,41340,257,21793,46213,352170]

theorem envBound34934 : H12AffineFastState.Bounded env34934 := by
  intro p hp
  have h : env34934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34933_34934 : H12AffineEnvironment.transform 21 272512 env34933 = env34934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34933 == env34934) = true)

theorem identity34934 : scanCanonicalize (H12AffineFastState.compose env34934 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound34934 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,290273,272512,294321,95496,8328,65,398573,288944,17665,149860,292988,21928,257,21793,16465,352170]

theorem envBound34935 : H12AffineFastState.Bounded env34935 := by
  intro p hp
  have h : env34935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34934_34935 : H12AffineEnvironment.transform 14 29908 env34934 = env34935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env34934 == env34935) = true)

def env34936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1025,8661,276705,272512,272561,73736,8328,65,398573,277936,4097,138340,273788,168,257,33,5457,330410]

theorem envBound34936 : H12AffineFastState.Bounded env34936 := by
  intro p hp
  have h : env34936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34935_34936 : H12AffineEnvironment.transform 13 5376 env34935 = env34936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34935 == env34936) = true)

theorem identity34936 : scanCanonicalize (H12AffineFastState.compose env34936 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1025,8661,4296,169,152,73736,8328,65,146628,5529,4097,138340,1365,168,257,33,5457,74371]

theorem envBound34937 : H12AffineFastState.Bounded env34937 := by
  intro p hp
  have h : env34937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34936_34937 : H12AffineEnvironment.transform 17 10281 env34936 = env34937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34936 == env34937) = true)

theorem identity34937 : scanCanonicalize (H12AffineFastState.compose env34937 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound34937 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env34938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79130,10281,1025,8661,4296,169,152,73736,8328,65,68062,5529,4097,76158,1365,168,257,33,5457,74371]

theorem envBound34938 : H12AffineFastState.Bounded env34938 := by
  intro p hp
  have h : env34938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34937_34938 : H12AffineEnvironment.transform 16 79130 env34937 = env34938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env34937 == env34938) = true)

theorem identity34938 : scanCanonicalize (H12AffineFastState.compose env34938 (packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound34938 : packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env34939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,478,13508,10281,1025,8661,4296,169,152,8662,8328,65,2048,5529,4097,10400,1365,168,257,33,5457,9053]

theorem envBound34939 : H12AffineFastState.Bounded env34939 := by
  intro p hp
  have h : env34939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34938_34939 : H12AffineEnvironment.transform 15 478 env34938 = env34939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env34938 == env34939) = true)

def env34940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1025,8660,276704,272512,272560,73737,8328,65,398573,277937,4096,138341,273789,169,257,32,5456,330411]

theorem envBound34940 : H12AffineFastState.Bounded env34940 := by
  intro p hp
  have h : env34940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34935_34940 : H12AffineEnvironment.transform 13 5377 env34935 = env34940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34935 == env34940) = true)

theorem identity34940 : scanCanonicalize (H12AffineFastState.compose env34940 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 204219) := by decide +kernel

theorem selectedBound34940 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env34941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,204219,1025,8660,206171,210235,210187,73737,8328,65,67926,204810,4096,138341,209094,169,257,32,5456,136976]

theorem envBound34941 : H12AffineFastState.Bounded env34941 := by
  intro p hp
  have h : env34941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34940_34941 : H12AffineEnvironment.transform 17 204219 env34940 = env34941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204219 env34940 == env34941) = true)

theorem identity34941 : scanCanonicalize (H12AffineFastState.compose env34941 (packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound34941 : packedSelected [3,4,7,9,10,14,16,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env34942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,5393,67754,1025,8660,77898,73770,73754,73737,8328,65,67926,79131,4096,2420,75223,169,257,32,5456,513]

theorem envBound34942 : H12AffineFastState.Bounded env34942 := by
  intro p hp
  have h : env34942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34941_34942 : H12AffineEnvironment.transform 16 5393 env34941 = env34942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env34941 == env34942) = true)

theorem identity34942 : scanCanonicalize (H12AffineFastState.compose env34942 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34942 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env34943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5393,10400,1025,8660,4160,32,16,3,8328,65,10588,5393,4096,2420,1501,169,257,32,5456,513]

theorem envBound34943 : H12AffineFastState.Bounded env34943 := by
  intro p hp
  have h : env34943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34942_34943 : H12AffineEnvironment.transform 15 8202 env34942 = env34943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34942 == env34943) = true)

theorem identity34943 : scanCanonicalize (H12AffineFastState.compose env34943 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound34943 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,5377,396,83,5393,2297,1025,397,4160,32,16,3,209,65,2309,5393,4096,2420,1501,169,257,32,5456,513]

theorem envBound34944 : H12AffineFastState.Bounded env34944 := by
  intro p hp
  have h : env34944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34943_34944 : H12AffineEnvironment.transform 12 89 env34943 = env34944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env34943 == env34944) = true)

theorem identity34944 : scanCanonicalize (H12AffineFastState.compose env34944 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34944 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env34945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5377,261,83,5393,2160,1025,260,4160,32,16,3,88,65,2309,5393,4096,2420,1364,32,257,32,5456,513]

theorem envBound34945 : H12AffineFastState.Bounded env34945 := by
  intro p hp
  have h : env34945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34944_34945 : H12AffineEnvironment.transform 6 9 env34944 = env34945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34944 == env34945) = true)

def env34946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294321,98780,8328,65,398572,288944,17665,179632,292988,41341,257,21793,46213,352170]

theorem envBound34946 : H12AffineFastState.Bounded env34946 := by
  intro p hp
  have h : env34946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34933_34946 : H12AffineEnvironment.transform 21 272513 env34933 = env34946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34933 == env34946) = true)

theorem identity34946 : scanCanonicalize (H12AffineFastState.compose env34946 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound34946 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,58517,41461,62661,98780,8328,65,171416,57796,17665,179632,61704,41341,257,21793,46213,120542]

theorem envBound34947 : H12AffineFastState.Bounded env34947 := by
  intro p hp
  have h : env34947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34946_34947 : H12AffineEnvironment.transform 17 35188 env34946 = env34947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34946 == env34947) = true)

def env34948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,35188,1025,32769,45341,41461,41293,98780,8328,65,171416,46156,4233,179632,42112,41341,257,169,46213,99158]

theorem envBound34948 : H12AffineFastState.Bounded env34948 := by
  intro p hp
  have h : env34948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34947_34948 : H12AffineEnvironment.transform 13 5512 env34947 = env34948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34947 == env34948) = true)

theorem identity34948 : scanCanonicalize (H12AffineFastState.compose env34948 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34948 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1025,32769,45341,41340,41293,98645,8193,65,171281,46156,4096,179513,41993,41341,257,32,46092,99158]

theorem envBound34949 : H12AffineFastState.Bounded env34949 := by
  intro p hp
  have h : env34949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34948_34949 : H12AffineEnvironment.transform 6 9 env34948 = env34949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34948 == env34949) = true)

theorem identity34949 : scanCanonicalize (H12AffineFastState.compose env34949 (packedSelected [1,5,8,15,16,19,20,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound34949 : packedSelected [1,5,8,15,16,19,20,24,26,38] rootPS < 2^1333 := by decide +kernel

def env34950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103446,35188,1025,32769,45341,41340,41293,98645,8193,65,67847,46156,4096,76079,41993,41341,257,32,46092,99158]

theorem envBound34950 : H12AffineFastState.Bounded env34950 := by
  intro p hp
  have h : env34950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34949_34950 : H12AffineEnvironment.transform 16 103446 env34949 = env34950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env34949 == env34950) = true)

theorem identity34950 : scanCanonicalize (H12AffineFastState.compose env34950 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound34950 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5440,35188,1025,32769,45341,41340,41293,3,8193,65,34897,46156,4096,43129,41993,41341,257,32,46092,512]

theorem envBound34951 : H12AffineFastState.Bounded env34951 := by
  intro p hp
  have h : env34951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34950_34951 : H12AffineEnvironment.transform 15 33110 env34950 = env34951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env34950 == env34951) = true)

theorem identity34951 : scanCanonicalize (H12AffineFastState.compose env34951 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34951 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34952 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,5377,32768,33063,5425,35077,1025,32769,45341,41229,41276,3,8193,48,34848,46141,4096,43016,41993,41228,257,32,46092,512]

theorem envBound34952 : H12AffineFastState.Bounded env34952 := by
  intro p hp
  have h : env34952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34951_34952 : H12AffineEnvironment.transform 5 49 env34951 = env34952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34951 == env34952) = true)

theorem identity34952 : scanCanonicalize (H12AffineFastState.compose env34952 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound34952 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env34953 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5377,32768,33063,5425,35077,1025,32769,36913,32801,32784,3,301,48,34848,38161,4096,35108,34085,32800,257,32,38176,512]

theorem envBound34953 : H12AffineFastState.Bounded env34953 := by
  intro p hp
  have h : env34953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34952_34953 : H12AffineEnvironment.transform 12 300 env34952 = env34953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env34952 == env34953) = true)

theorem identity34953 : scanCanonicalize (H12AffineFastState.compose env34953 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound34953 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env34954 : List Nat := [2,4,8,16,32,49,9,256,512,304,2048,4096,300,4145,32768,33063,4097,35077,305,32769,36913,32801,32784,3,301,48,34848,36897,4096,35108,32789,32800,257,32,36880,512]

theorem envBound34954 : H12AffineFastState.Bounded env34954 := by
  intro p hp
  have h : env34954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34953_34954 : H12AffineEnvironment.transform 9 304 env34953 = env34954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env34953 == env34954) = true)

theorem identity34954 : scanCanonicalize (H12AffineFastState.compose env34954 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34954 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34955 : List Nat := [2,4,8,16,32,49,9,37,512,21,2048,4096,9,4145,32768,32770,4097,34848,20,32769,36913,32801,32784,3,8,48,34848,36897,4096,34817,32789,32800,36,32,36880,512]

theorem envBound34955 : H12AffineFastState.Bounded env34955 := by
  intro p hp
  have h : env34955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34954_34955 : H12AffineEnvironment.transform 7 37 env34954 = env34955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34954 == env34955) = true)

theorem identity34955 : scanCanonicalize (H12AffineFastState.compose env34955 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound34955 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env34956 : List Nat := [2,4,8,16,32,49,9,37,512,21,2048,4096,9,4145,32,34,4097,2048,20,33,4113,1,48,3,8,48,2048,4097,4096,2081,53,0,36,32,4144,512]

theorem envBound34956 : H12AffineFastState.Bounded env34956 := by
  intro p hp
  have h : env34956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34955_34956 : H12AffineEnvironment.transform 14 32 env34955 = env34956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env34955 == env34956) = true)

theorem identity34956 : scanCanonicalize (H12AffineFastState.compose env34956 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34956 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34957 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,4096,9,4112,1,3,4097,2048,20,0,4113,1,17,3,8,17,2048,4097,4096,2048,20,0,5,1,4113,512]

theorem envBound34957 : H12AffineFastState.Bounded env34957 := by
  intro p hp
  have h : env34957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34956_34957 : H12AffineEnvironment.transform 4 1 env34956 = env34957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34956 == env34957) = true)

theorem identity34957 : scanCanonicalize (H12AffineFastState.compose env34957 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound34957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34958 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2576,9,2560,1,3,2577,2048,20,0,2561,1,17,3,8,17,2048,2577,2576,2048,20,0,5,1,2561,512]

theorem envBound34958 : H12AffineFastState.Bounded env34958 := by
  intro p hp
  have h : env34958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34957_34958 : H12AffineEnvironment.transform 11 2576 env34957 = env34958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env34957 == env34958) = true)

theorem identity34958 : scanCanonicalize (H12AffineFastState.compose env34958 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound34958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34959 : List Nat := [2,4,8,16,1,16,9,4,512,21,30,526,9,542,1,3,527,30,20,0,543,1,17,3,8,17,30,527,526,30,20,0,5,1,543,512]

theorem envBound34959 : H12AffineFastState.Bounded env34959 := by
  intro p hp
  have h : env34959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34958_34959 : H12AffineEnvironment.transform 10 30 env34958 = env34959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env34958 == env34959) = true)

theorem identity34959 : scanCanonicalize (H12AffineFastState.compose env34959 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34959 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34960 : List Nat := [2,4,8,16,1,16,9,4,1,21,30,15,9,31,1,3,14,30,20,0,30,1,17,3,8,17,30,14,15,30,20,0,5,1,30,1]

theorem envBound34960 : H12AffineFastState.Bounded env34960 := by
  intro p hp
  have h : env34960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34959_34960 : H12AffineEnvironment.transform 8 1 env34959 = env34960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34959 == env34960) = true)

def leafEnv34960 : List Nat := [2,4,8,16,1,16,9,4,1,21,30,15,9,31,1,3,14,30,20,0,30,1,17,3,21,8,1,17,30,14,15,30,20,0,5,1,5,2,30,1,1,31,0]

def active34960 : List Nat := [0,1,2,3]

def tree34960 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34960 : H12WitnessSearch.Good tree34960 := H12GlobalWitnessIndex.good

theorem leafIdentity34960 : H12AffineFastState.composeSystem env34960 rootObs = leafEnv34960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34960 rootObs == leafEnv34960) = true)

theorem terminalChecked34960 : H12PackedTerminal.terminalCheckFast leafEnv34960 active34960 tree34960 = true := by decide +kernel

def env34961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,35188,1025,32769,45340,41461,41292,98780,8328,65,171416,46157,4232,179632,42113,41341,257,168,46213,99159]

theorem envBound34961 : H12AffineFastState.Bounded env34961 := by
  intro p hp
  have h : env34961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34947_34961 : H12AffineEnvironment.transform 13 5513 env34947 = env34961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env34947 == env34961) = true)

theorem identity34961 : scanCanonicalize (H12AffineFastState.compose env34961 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34961 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10281,1025,8540,4161,168,17,73857,8328,65,146629,5392,4232,138477,1500,32,257,168,5592,74250]

theorem envBound34962 : H12AffineFastState.Bounded env34962 := by
  intro p hp
  have h : env34962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34961_34962 : H12AffineEnvironment.transform 14 8541 env34961 = env34962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34961 == env34962) = true)

theorem identity34962 : scanCanonicalize (H12AffineFastState.compose env34962 (packedSelected [0,2,4,5,6,8,9,10,11,16,18,19,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34962 : packedSelected [0,2,4,5,6,8,9,10,11,16,18,19,24,27,28] rootPS < 2^1333 := by decide +kernel

def env34963 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,65536,131072,10281,1025,8540,4161,113,17,73816,8273,65,146460,5392,4177,138292,1285,32,257,113,5377,74250]

theorem envBound34963 : H12AffineFastState.Bounded env34963 := by
  intro p hp
  have h : env34963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34962_34963 : H12AffineEnvironment.transform 6 89 env34962 = env34963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34962 == env34963) = true)

theorem identity34963 : scanCanonicalize (H12AffineFastState.compose env34963 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound34963 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34964 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,8283,131072,10281,1025,8540,4161,113,17,3,8273,65,146460,5392,4177,138292,1285,32,257,113,5377,593]

theorem envBound34964 : H12AffineFastState.Bounded env34964 := by
  intro p hp
  have h : env34964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34963_34964 : H12AffineEnvironment.transform 15 8283 env34963 = env34964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env34963 == env34964) = true)

theorem identity34964 : scanCanonicalize (H12AffineFastState.compose env34964 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34964 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env34965 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1025,8461,4112,32,17,3,8192,16,146460,5392,4096,138292,1285,32,257,32,5377,512]

theorem envBound34965 : H12AffineFastState.Bounded env34965 := by
  intro p hp
  have h : env34965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34964_34965 : H12AffineEnvironment.transform 5 17 env34964 = env34965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34964 == env34965) = true)

theorem identity34965 : scanCanonicalize (H12AffineFastState.compose env34965 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound34965 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34966 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,13373,10281,1025,8461,4112,32,17,3,8192,16,2081,5392,4096,10249,1285,32,257,32,5377,512]

theorem envBound34966 : H12AffineFastState.Bounded env34966 := by
  intro p hp
  have h : env34966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34965_34966 : H12AffineEnvironment.transform 16 13373 env34965 = env34966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env34965 == env34966) = true)

theorem identity34966 : scanCanonicalize (H12AffineFastState.compose env34966 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound34966 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34967 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,261,3,5172,2080,1025,260,4112,32,17,3,9,16,2081,5392,4096,2048,1285,32,257,32,5377,512]

theorem envBound34967 : H12AffineFastState.Bounded env34967 := by
  intro p hp
  have h : env34967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34966_34967 : H12AffineEnvironment.transform 12 9 env34966 = env34967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env34966 == env34967) = true)

theorem identity34967 : scanCanonicalize (H12AffineFastState.compose env34967 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound34967 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34968 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,4096,9,5377,261,3,5172,261,1025,260,4112,32,17,3,9,16,260,5392,4096,293,1285,32,257,32,5377,512]

theorem envBound34968 : H12AffineFastState.Bounded env34968 := by
  intro p hp
  have h : env34968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34967_34968 : H12AffineEnvironment.transform 10 293 env34967 = env34968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env34967 == env34968) = true)

theorem identity34968 : scanCanonicalize (H12AffineFastState.compose env34968 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34968 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env34969 : List Nat := [2,4,8,16,1,17,8,256,512,1024,260,4096,9,5377,261,3,5141,261,1025,260,4112,1,17,3,9,16,260,5392,4096,260,1285,1,257,1,5377,512]

theorem envBound34969 : H12AffineFastState.Bounded env34969 := by
  intro p hp
  have h : env34969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34968_34969 : H12AffineEnvironment.transform 4 1 env34968 = env34969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34968 == env34969) = true)

theorem identity34969 : scanCanonicalize (H12AffineFastState.compose env34969 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound34969 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34970 : List Nat := [2,4,8,16,1,17,8,256,512,1024,260,1028,9,261,261,3,17,261,1025,260,1044,1,17,3,9,16,260,276,1028,260,1285,1,257,1,261,512]

theorem envBound34970 : H12AffineFastState.Bounded env34970 := by
  intro p hp
  have h : env34970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34969_34970 : H12AffineEnvironment.transform 11 1028 env34969 = env34970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env34969 == env34970) = true)

theorem identity34970 : scanCanonicalize (H12AffineFastState.compose env34970 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34970 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34971 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1,1028,9,0,0,3,17,0,1025,1,1044,1,17,3,9,16,1,17,1028,1,1024,1,4,1,0,512]

theorem envBound34971 : H12AffineFastState.Bounded env34971 := by
  intro p hp
  have h : env34971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34970_34971 : H12AffineEnvironment.transform 7 5 env34970 = env34971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34970 == env34971) = true)

theorem identity34971 : scanCanonicalize (H12AffineFastState.compose env34971 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34972 : List Nat := [2,4,8,16,1,17,8,5,1,1024,1,1028,9,0,0,3,17,0,1025,1,1044,1,17,3,9,16,1,17,1028,1,1024,1,4,1,0,1]

theorem envBound34972 : H12AffineFastState.Bounded env34972 := by
  intro p hp
  have h : env34972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34971_34972 : H12AffineEnvironment.transform 8 1 env34971 = env34972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34971 == env34972) = true)

def env34973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound34973 : H12AffineFastState.Bounded env34973 := by
  intro p hp
  have h : env34973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31961_34973 : H12AffineEnvironment.transform 31 145662401 env31961 = env34973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env31961 == env34973) = true)

def env34974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound34974 : H12AffineFastState.Bounded env34974 := by
  intro p hp
  have h : env34974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34973_34974 : H12AffineEnvironment.transform 29 155254784 env34973 = env34974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env34973 == env34974) = true)

def env34975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound34975 : H12AffineFastState.Bounded env34975 := by
  intro p hp
  have h : env34975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34974_34975 : H12AffineEnvironment.transform 25 64 env34974 = env34975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env34974 == env34975) = true)

def env34976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound34976 : H12AffineFastState.Bounded env34976 := by
  intro p hp
  have h : env34976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34975_34976 : H12AffineEnvironment.transform 26 30393344 env34975 = env34976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env34975 == env34976) = true)

def env34977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound34977 : H12AffineFastState.Bounded env34977 := by
  intro p hp
  have h : env34977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34976_34977 : H12AffineEnvironment.transform 18 1024 env34976 = env34977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34976 == env34977) = true)

theorem identity34977 : scanCanonicalize (H12AffineFastState.compose env34977 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601476) := by decide +kernel

theorem selectedBound34977 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601476,8328,64,6685700,8405128,10507600,8830976,2113556,12624325,256,168,57613,2189250]

theorem envBound34978 : H12AffineFastState.Bounded env34978 := by
  intro p hp
  have h : env34978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34977_34978 : H12AffineEnvironment.transform 23 10601476 env34977 = env34978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601476 env34977 == env34978) = true)

def env34979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685700,8393984,10485976,8820104,2102684,12624325,256,168,46213,2175562]

theorem envBound34979 : H12AffineFastState.Bounded env34979 := by
  intro p hp
  have h : env34979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34978_34979 : H12AffineEnvironment.transform 13 5512 env34978 = env34979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34978 == env34979) = true)

def env34980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685700,2098648,4096,2524496,2102684,6336797,256,168,46213,2175562]

theorem envBound34980 : H12AffineFastState.Bounded env34980 := by
  intro p hp
  have h : env34980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34979_34980 : H12AffineEnvironment.transform 22 2101464 env34979 = env34980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env34979 == env34980) = true)

def env34981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491428,2098648,4096,2524496,2102684,2142525,256,168,46213,2175562]

theorem envBound34981 : H12AffineFastState.Bounded env34981 := by
  intro p hp
  have h : env34981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34980_34981 : H12AffineEnvironment.transform 21 32 env34980 = env34981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env34980 == env34981) = true)

def env34982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98644,8192,64,2491428,2098512,4096,2524496,2102548,2142525,256,32,46093,2175562]

theorem envBound34982 : H12AffineFastState.Bounded env34982 := by
  intro p hp
  have h : env34982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34981_34982 : H12AffineEnvironment.transform 6 8 env34981 = env34982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34981 == env34982) = true)

def env34983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398436,5392,4096,431376,1364,41341,256,32,46093,74250]

theorem envBound34983 : H12AffineFastState.Bounded env34983 := by
  intro p hp
  have h : env34983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34982_34983 : H12AffineEnvironment.transform 20 4160 env34982 = env34983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34982 == env34983) = true)

theorem identity34983 : scanCanonicalize (H12AffineFastState.compose env34983 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34983 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,32,16,73737,8192,64,398436,5392,4096,406605,1364,32,256,32,5456,74250]

theorem envBound34984 : H12AffineFastState.Bounded env34984 := by
  intro p hp
  have h : env34984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34983_34984 : H12AffineEnvironment.transform 14 8541 env34983 = env34984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34983 == env34984) = true)

theorem identity34984 : scanCanonicalize (H12AffineFastState.compose env34984 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67698) := by decide +kernel

theorem selectedBound34984 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67698,1024,8540,4160,32,16,73737,8192,64,203798,5392,4096,212031,1364,32,256,32,5456,74250]

theorem envBound34985 : H12AffineFastState.Bounded env34985 := by
  intro p hp
  have h : env34985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34984_34985 : H12AffineEnvironment.transform 17 67698 env34984 = env34985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67698 env34984 == env34985) = true)

theorem identity34985 : scanCanonicalize (H12AffineFastState.compose env34985 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound34985 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env34986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,5221,67698,1024,8540,4160,32,16,73737,8192,64,67699,5392,4096,75866,1364,32,256,32,5456,74250]

theorem envBound34986 : H12AffineFastState.Bounded env34986 := by
  intro p hp
  have h : env34986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34985_34986 : H12AffineEnvironment.transform 16 5221 env34985 = env34986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env34985 == env34986) = true)

theorem identity34986 : scanCanonicalize (H12AffineFastState.compose env34986 (packedSelected [4,11,12,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 10622) := by decide +kernel

theorem selectedBound34986 : packedSelected [4,11,12,15,20,22] rootPS < 2^1333 := by decide +kernel

def env34987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,10622,5221,8460,1024,8540,4160,32,16,2423,8192,64,8461,5392,4096,292,1364,32,256,32,5456,2932]

theorem envBound34987 : H12AffineFastState.Bounded env34987 := by
  intro p hp
  have h : env34987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34986_34987 : H12AffineEnvironment.transform 15 10622 env34986 = env34987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10622 env34986 == env34987) = true)

theorem identity34987 : scanCanonicalize (H12AffineFastState.compose env34987 (packedSelected [0,4,9,11,12,15,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34987 : packedSelected [0,4,9,11,12,15,20,27] rootPS < 2^1333 := by decide +kernel

def env34988 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,10542,5173,8460,1024,8460,4112,32,16,2343,8192,16,8461,5392,4096,292,1284,32,256,32,5376,2852]

theorem envBound34988 : H12AffineFastState.Bounded env34988 := by
  intro p hp
  have h : env34988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34987_34988 : H12AffineEnvironment.transform 5 16 env34987 = env34988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34987 == env34988) = true)

theorem identity34988 : scanCanonicalize (H12AffineFastState.compose env34988 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound34988 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env34989 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,2088,5376,2341,262,5173,2340,1024,2340,4112,32,16,2343,2088,16,2341,5392,4096,292,1284,32,256,32,5376,2852]

theorem envBound34989 : H12AffineFastState.Bounded env34989 := by
  intro p hp
  have h : env34989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34988_34989 : H12AffineEnvironment.transform 12 2088 env34988 = env34989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env34988 == env34989) = true)

theorem identity34989 : scanCanonicalize (H12AffineFastState.compose env34989 (packedSelected [0,2,6,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound34989 : packedSelected [0,2,6,9,10] rootPS < 2^1333 := by decide +kernel

def env34990 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,2088,0,2341,262,309,2340,1024,2340,1296,32,16,2343,2088,16,2341,16,1280,292,1284,32,256,32,0,2852]

theorem envBound34990 : H12AffineFastState.Bounded env34990 := by
  intro p hp
  have h : env34990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34989_34990 : H12AffineEnvironment.transform 11 1280 env34989 = env34990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env34989 == env34990) = true)

theorem identity34990 : scanCanonicalize (H12AffineFastState.compose env34990 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34990 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34991 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1061,2088,0,2048,35,16,2049,1024,2049,1077,32,16,2050,2088,16,2048,16,1061,1,1057,32,37,32,0,2561]

theorem envBound34991 : H12AffineFastState.Bounded env34991 := by
  intro p hp
  have h : env34991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34990_34991 : H12AffineEnvironment.transform 7 37 env34990 = env34991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34990 == env34991) = true)

theorem identity34991 : scanCanonicalize (H12AffineFastState.compose env34991 (packedSelected [2,3,5,14] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34991 : packedSelected [2,3,5,14] rootPS < 2^1333 := by decide +kernel

def env34992 : List Nat := [2,4,8,16,32,16,8,37,512,1024,0,1061,40,0,0,35,16,1,1024,1,1077,32,16,2,40,16,0,16,1061,1,1057,32,37,32,0,513]

theorem envBound34992 : H12AffineFastState.Bounded env34992 := by
  intro p hp
  have h : env34992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34991_34992 : H12AffineEnvironment.transform 10 0 env34991 = env34992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34991 == env34992) = true)

theorem identity34992 : scanCanonicalize (H12AffineFastState.compose env34992 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound34992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34993 : List Nat := [2,4,8,16,32,16,8,37,512,36,0,1,40,0,0,35,16,1,36,1,17,32,16,2,40,16,0,16,1,1,5,32,37,32,0,513]

theorem envBound34993 : H12AffineFastState.Bounded env34993 := by
  intro p hp
  have h : env34993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34992_34993 : H12AffineEnvironment.transform 9 36 env34992 = env34993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env34992 == env34993) = true)

theorem identity34993 : scanCanonicalize (H12AffineFastState.compose env34993 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34994 : List Nat := [2,4,8,16,32,16,8,37,0,36,0,1,40,0,0,35,16,1,36,1,17,32,16,2,40,16,0,16,1,1,5,32,37,32,0,1]

theorem envBound34994 : H12AffineFastState.Bounded env34994 := by
  intro p hp
  have h : env34994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34993_34994 : H12AffineEnvironment.transform 8 0 env34993 = env34994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34993 == env34994) = true)

def env34995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398437,5393,4096,431377,1365,41340,256,32,46093,74251]

theorem envBound34995 : H12AffineFastState.Bounded env34995 := by
  intro p hp
  have h : env34995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34982_34995 : H12AffineEnvironment.transform 20 4161 env34982 = env34995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34982 == env34995) = true)

theorem identity34995 : scanCanonicalize (H12AffineFastState.compose env34995 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound34995 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1024,32769,4161,32,17,98644,8192,64,171281,5393,4096,138341,1365,41340,256,32,46093,74251]

theorem envBound34996 : H12AffineFastState.Bounded env34996 := by
  intro p hp
  have h : env34996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34995_34996 : H12AffineEnvironment.transform 17 35188 env34995 = env34996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34995 == env34996) = true)

theorem identity34996 : scanCanonicalize (H12AffineFastState.compose env34996 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34996 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,65536,131072,2420,1024,1,4161,32,17,65876,8192,64,138513,5393,4096,138341,1365,8572,256,32,13325,74251]

theorem envBound34997 : H12AffineFastState.Bounded env34997 := by
  intro p hp
  have h : env34997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34996_34997 : H12AffineEnvironment.transform 14 0 env34996 = env34997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34996 == env34997) = true)

theorem identity34997 : scanCanonicalize (H12AffineFastState.compose env34997 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound34997 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env34998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,65536,5393,2420,1024,1,4161,32,17,65876,8192,64,2048,5393,4096,2420,1365,8572,256,32,13325,74251]

theorem envBound34998 : H12AffineFastState.Bounded env34998 := by
  intro p hp
  have h : env34998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34997_34998 : H12AffineEnvironment.transform 16 5393 env34997 = env34998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env34997 == env34998) = true)

theorem identity34998 : scanCanonicalize (H12AffineFastState.compose env34998 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34998 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,8202,5393,2420,1024,1,4161,32,17,8542,8192,64,2048,5393,4096,2420,1365,8572,256,32,13325,513]

theorem envBound34999 : H12AffineFastState.Bounded env34999 := by
  intro p hp
  have h : env34999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34998_34999 : H12AffineEnvironment.transform 15 8202 env34998 = env34999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34998 == env34999) = true)

theorem identity34999 : scanCanonicalize (H12AffineFastState.compose env34999 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound34999 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35000 : List Nat := [2,4,8,16,32,64,8,256,512,612,2048,4096,8192,4964,0,8202,4981,2420,612,1,4161,32,17,8542,8192,64,2048,4981,4096,2420,817,8572,256,32,12905,513]

theorem envBound35000 : H12AffineFastState.Bounded env35000 := by
  intro p hp
  have h : env35000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34999_35000 : H12AffineEnvironment.transform 9 612 env34999 = env35000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env34999 == env35000) = true)

def env35001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101329,98644,8193,64,2491428,2098513,4096,2524496,2102549,2142525,256,33,46092,2175562]

theorem envBound35001 : H12AffineFastState.Bounded env35001 := by
  intro p hp
  have h : env35001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34981_35001 : H12AffineEnvironment.transform 6 9 env34981 = env35001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34981 == env35001) = true)

def env35002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398436,5393,4096,431376,1365,41341,256,33,46092,74250]

theorem envBound35002 : H12AffineFastState.Bounded env35002 := by
  intro p hp
  have h : env35002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35001_35002 : H12AffineEnvironment.transform 20 4160 env35001 = env35002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35001 == env35002) = true)

theorem identity35002 : scanCanonicalize (H12AffineFastState.compose env35002 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35002 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,4160,32,17,98644,8193,64,146508,5393,4096,179512,1365,41341,256,33,46092,74250]

theorem envBound35003 : H12AffineFastState.Bounded env35003 := by
  intro p hp
  have h : env35003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35002_35003 : H12AffineEnvironment.transform 17 10280 env35002 = env35003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35002 == env35003) = true)

def env35004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98644,8193,64,398437,5392,4096,431377,1364,41340,256,33,46092,74251]

theorem envBound35004 : H12AffineFastState.Bounded env35004 := by
  intro p hp
  have h : env35004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35001_35004 : H12AffineEnvironment.transform 20 4161 env35001 = env35004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35001 == env35004) = true)

theorem identity35004 : scanCanonicalize (H12AffineFastState.compose env35004 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35004 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env35005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398437,5392,4096,431377,1364,41340,256,33,46092,513]

theorem envBound35005 : H12AffineFastState.Bounded env35005 := by
  intro p hp
  have h : env35005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35004_35005 : H12AffineEnvironment.transform 15 8202 env35004 = env35005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35004 == env35005) = true)

theorem identity35005 : scanCanonicalize (H12AffineFastState.compose env35005 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35005 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398437,5392,4096,406604,1364,33,256,33,5457,513]

theorem envBound35006 : H12AffineFastState.Bounded env35006 := by
  intro p hp
  have h : env35006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35005_35006 : H12AffineEnvironment.transform 14 8541 env35005 = env35006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35005 == env35006) = true)

theorem identity35006 : scanCanonicalize (H12AffineFastState.compose env35006 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35006 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35007 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,32,16,3,8193,16,398389,5392,4096,406556,1284,33,256,33,5377,513]

theorem envBound35007 : H12AffineFastState.Bounded env35007 := by
  intro p hp
  have h : env35007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35006_35007 : H12AffineEnvironment.transform 5 16 env35006 = env35007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35006 == env35007) = true)

theorem identity35007 : scanCanonicalize (H12AffineFastState.compose env35007 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound35007 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35008 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1024,8460,4113,32,16,3,8193,16,146460,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound35008 : H12AffineFastState.Bounded env35008 := by
  intro p hp
  have h : env35008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35007_35008 : H12AffineEnvironment.transform 17 10281 env35007 = env35008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35007 == env35008) = true)

theorem identity35008 : scanCanonicalize (H12AffineFastState.compose env35008 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35008 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35009 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,131072,2341,1024,0,4113,32,16,3,269,16,138512,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound35009 : H12AffineFastState.Bounded env35009 := by
  intro p hp
  have h : env35009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35008_35009 : H12AffineEnvironment.transform 12 268 env35008 = env35009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35008 == env35009) = true)

theorem identity35009 : scanCanonicalize (H12AffineFastState.compose env35009 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound35009 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35010 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,4097,2341,1024,0,4113,32,16,3,269,16,3345,5392,4096,3124,1284,33,256,33,5377,513]

theorem envBound35010 : H12AffineFastState.Bounded env35010 := by
  intro p hp
  have h : env35010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35009_35010 : H12AffineEnvironment.transform 16 4097 env35009 = env35010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env35009 == env35010) = true)

theorem identity35010 : scanCanonicalize (H12AffineFastState.compose env35010 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35010 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35011 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,268,4112,1,262,4097,2341,273,0,4113,32,16,3,269,16,2048,4097,4096,2341,21,33,256,33,4112,513]

theorem envBound35011 : H12AffineFastState.Bounded env35011 := by
  intro p hp
  have h : env35011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35010_35011 : H12AffineEnvironment.transform 9 273 env35010 = env35011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35010 == env35011) = true)

theorem identity35011 : scanCanonicalize (H12AffineFastState.compose env35011 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35012 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,41,4112,1,35,4097,2048,52,0,4113,32,16,3,40,16,2048,4097,4096,2048,21,33,37,33,4112,513]

theorem envBound35012 : H12AffineFastState.Bounded env35012 := by
  intro p hp
  have h : env35012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35011_35012 : H12AffineEnvironment.transform 7 37 env35011 = env35012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35011 == env35012) = true)

theorem identity35012 : scanCanonicalize (H12AffineFastState.compose env35012 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound35012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35013 : List Nat := [2,4,8,16,32,16,9,37,512,52,513,4096,41,4112,1,35,4097,513,52,0,4113,32,16,3,40,16,513,4097,4096,513,21,33,37,33,4112,513]

theorem envBound35013 : H12AffineFastState.Bounded env35013 := by
  intro p hp
  have h : env35013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35012_35013 : H12AffineEnvironment.transform 10 513 env35012 = env35013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env35012 == env35013) = true)

theorem identity35013 : scanCanonicalize (H12AffineFastState.compose env35013 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound35013 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35014 : List Nat := [2,4,8,16,32,16,9,37,512,52,513,554,41,570,1,35,555,513,52,0,571,32,16,3,40,16,513,555,554,513,21,33,37,33,570,513]

theorem envBound35014 : H12AffineFastState.Bounded env35014 := by
  intro p hp
  have h : env35014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1