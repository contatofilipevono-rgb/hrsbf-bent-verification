import H12CloudChart1Data015

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans3939_3940 : H12AffineEnvironment.transform 4 11 env3939 = env3940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3939 == env3940) = true)

theorem identity3940 : scanCanonicalize (H12AffineFastState.compose env3940 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3941 : List Nat := [2,4,3,1,0,1,3,4,512,1024,513,1540,3,1540,1,2,1540,513,1024,1,1540,0,1,3,2,0,512,1540,1541,513,1025,0,4,1,1541,512]

theorem envBound3941 : H12AffineFastState.Bounded env3941 := by
  intro p hp
  have h : env3941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3940_3941 : H12AffineEnvironment.transform 2 3 env3940 = env3941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3940 == env3941) = true)

theorem identity3941 : scanCanonicalize (H12AffineFastState.compose env3941 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3942 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1028,3,1028,1,2,1028,1,1024,1,1028,0,1,3,2,0,0,1028,1029,1,1025,0,4,1,1029,0]

theorem envBound3942 : H12AffineFastState.Bounded env3942 := by
  intro p hp
  have h : env3942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3941_3942 : H12AffineEnvironment.transform 8 0 env3941 = env3942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3941 == env3942) = true)

def leafEnv3942 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1028,3,1028,1,2,1028,1,1024,1,1028,0,1,3,1025,2,1,0,0,1028,1029,1,1025,0,4,1,4,2,1029,0,1,1028,0]

def active3942 : List Nat := [0,1,9]

def tree3942 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3942 : H12WitnessSearch.Good tree3942 := H12GlobalWitnessIndex.good

theorem leafIdentity3942 : H12AffineFastState.composeSystem env3942 rootObs = leafEnv3942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3942 rootObs == leafEnv3942) = true)

theorem terminalChecked3942 : H12PackedTerminal.terminalCheckFast leafEnv3942 active3942 tree3942 = true := by decide +kernel

def env3943 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,33,269828,41002,8224,269829,323625,16384,16644,22560,1285,323352,256,20481,286228,269585]

theorem envBound3943 : H12AffineFastState.Bounded env3943 := by
  intro p hp
  have h : env3943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3930_3943 : H12AffineEnvironment.transform 6 41 env3930 = env3943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3930 == env3943) = true)

theorem identity3943 : scanCanonicalize (H12AffineFastState.compose env3943 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound3943 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3944 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,48668,1024,32768,4096,33,40984,41002,8224,40985,20021,16384,16644,22560,1285,20740,256,20481,57352,41741]

theorem envBound3944 : H12AffineFastState.Bounded env3944 := by
  intro p hp
  have h : env3944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3943_3944 : H12AffineEnvironment.transform 17 48668 env3943 = env3944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env3943 == env3944) = true)

theorem identity3944 : scanCanonicalize (H12AffineFastState.compose env3944 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound3944 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3945 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,1841,32768,8494,4357,48668,1024,32768,4096,33,40984,41002,8224,40985,2308,1841,1589,7953,1285,5685,256,5936,42809,41741]

theorem envBound3945 : H12AffineFastState.Bounded env3945 := by
  intro p hp
  have h : env3945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3944_3945 : H12AffineEnvironment.transform 13 1841 env3944 = env3945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env3944 == env3945) = true)

theorem identity3945 : scanCanonicalize (H12AffineFastState.compose env3945 (packedSelected [0,4,7,9,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound3945 : packedSelected [0,4,7,9,13,21] rootPS < 2^1333 := by decide +kernel

def env3946 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,8192,1841,32768,8494,1589,43308,1024,32768,1840,33,40984,41002,8224,40985,2308,1841,1589,2081,1285,261,256,0,42809,41741]

theorem envBound3946 : H12AffineFastState.Bounded env3946 := by
  intro p hp
  have h : env3946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3945_3946 : H12AffineEnvironment.transform 11 1840 env3945 = env3946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env3945 == env3946) = true)

theorem identity3946 : scanCanonicalize (H12AffineFastState.compose env3946 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound3946 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3947 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,2600,1841,32768,2822,1589,33540,1024,32768,1840,33,35376,35330,2568,35377,2308,1841,1589,2081,1285,261,256,0,36113,35109]

theorem envBound3947 : H12AffineFastState.Bounded env3947 := by
  intro p hp
  have h : env3947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3946_3947 : H12AffineEnvironment.transform 12 2600 env3946 = env3947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env3946 == env3947) = true)

theorem identity3947 : scanCanonicalize (H12AffineFastState.compose env3947 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound3947 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3948 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,2600,1841,1071,2822,1589,1835,1024,1071,1840,33,3615,3629,2568,3614,2308,1841,1589,2081,1285,261,256,0,2366,3338]

theorem envBound3948 : H12AffineFastState.Bounded env3948 := by
  intro p hp
  have h : env3948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3947_3948 : H12AffineEnvironment.transform 14 1071 env3947 = env3948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env3947 == env3948) = true)

theorem identity3948 : scanCanonicalize (H12AffineFastState.compose env3948 (packedSelected [3,5,6,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3948 : packedSelected [3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3949 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1589,2600,1588,1071,2563,1589,1582,1024,1071,1589,33,3615,3629,2568,3614,2049,1588,1589,2081,1024,0,5,0,2107,3087]

theorem envBound3949 : H12AffineFastState.Bounded env3949 := by
  intro p hp
  have h : env3949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3948_3949 : H12AffineEnvironment.transform 7 5 env3948 = env3949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3948 == env3949) = true)

theorem identity3949 : scanCanonicalize (H12AffineFastState.compose env3949 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound3949 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3950 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1556,1589,1084,1588,1071,1047,1589,1582,1024,1071,1589,33,11,57,1052,10,1557,1588,1589,1589,1024,0,5,0,1583,539]

theorem envBound3950 : H12AffineFastState.Bounded env3950 := by
  intro p hp
  have h : env3950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3949_3950 : H12AffineEnvironment.transform 10 1556 env3949 = env3950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env3949 == env3950) = true)

theorem identity3950 : scanCanonicalize (H12AffineFastState.compose env3950 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3950 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env3951 : List Nat := [2,4,8,16,32,16,41,5,1,1024,1045,1076,1084,1077,1071,1047,1076,1071,1024,1071,1076,33,11,57,1052,10,1044,1077,1076,1076,1024,0,5,0,1070,26]

theorem envBound3951 : H12AffineFastState.Bounded env3951 := by
  intro p hp
  have h : env3951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3950_3951 : H12AffineEnvironment.transform 8 1 env3950 = env3951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3950 == env3951) = true)

theorem identity3951 : scanCanonicalize (H12AffineFastState.compose env3951 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound3951 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3952 : List Nat := [2,4,8,16,32,16,41,5,1,47,58,27,19,26,0,56,27,0,47,0,27,33,11,57,51,10,59,26,27,27,47,0,5,0,1,26]

theorem envBound3952 : H12AffineFastState.Bounded env3952 := by
  intro p hp
  have h : env3952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3951_3952 : H12AffineEnvironment.transform 9 47 env3951 = env3952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env3951 == env3952) = true)

theorem identity3952 : scanCanonicalize (H12AffineFastState.compose env3952 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3953 : List Nat := [2,4,8,10,32,10,41,5,1,47,32,1,9,0,0,34,1,0,47,0,1,33,11,35,41,10,33,0,1,1,47,0,5,0,1,0]

theorem envBound3953 : H12AffineFastState.Bounded env3953 := by
  intro p hp
  have h : env3953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3952_3953 : H12AffineEnvironment.transform 3 10 env3952 = env3953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3952 == env3953) = true)

theorem identity3953 : scanCanonicalize (H12AffineFastState.compose env3953 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3954 : List Nat := [2,4,7,5,32,5,38,5,1,32,32,1,6,0,0,34,1,0,32,0,1,33,4,35,38,5,33,0,1,1,32,0,5,0,1,0]

theorem envBound3954 : H12AffineFastState.Bounded env3954 := by
  intro p hp
  have h : env3954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3953_3954 : H12AffineEnvironment.transform 2 7 env3953 = env3954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3953 == env3954) = true)

theorem identity3954 : scanCanonicalize (H12AffineFastState.compose env3954 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3954 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3955 : List Nat := [2,0,3,1,32,1,34,1,1,32,32,1,2,0,0,34,1,0,32,0,1,33,0,35,34,1,33,0,1,1,32,0,1,0,1,0]

theorem envBound3955 : H12AffineFastState.Bounded env3955 := by
  intro p hp
  have h : env3955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3954_3955 : H12AffineEnvironment.transform 1 0 env3954 = env3955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3954 == env3955) = true)

def leafEnv3955 : List Nat := [2,0,3,1,32,1,34,1,1,32,32,1,2,0,0,34,1,0,32,0,1,33,0,35,32,34,1,1,33,0,1,1,32,0,1,0,0,2,1,0,1,0,0]

def active3955 : List Nat := [0,4]

def tree3955 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3955 : H12WitnessSearch.Good tree3955 := H12GlobalWitnessIndex.good

theorem leafIdentity3955 : H12AffineFastState.composeSystem env3955 rootObs = leafEnv3955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3955 rootObs == leafEnv3955) = true)

theorem terminalChecked3955 : H12PackedTerminal.terminalCheckFast leafEnv3955 active3955 tree3955 = true := by decide +kernel

def env3956 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,137,8388608,41002,8329,8388609,323712,16384,16813,22560,1285,8450484,256,20481,8405177,8389564]

theorem envBound3956 : H12AffineFastState.Bounded env3956 := by
  intro p hp
  have h : env3956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3928_3956 : H12AffineEnvironment.transform 21 137 env3928 = env3956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env3928 == env3956) = true)

theorem identity3956 : scanCanonicalize (H12AffineFastState.compose env3956 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 270081) := by decide +kernel

theorem selectedBound3956 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env3957 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,137,270081,41002,8329,270080,323712,16384,16813,22560,1285,323253,256,20481,286648,269501]

theorem envBound3957 : H12AffineFastState.Bounded env3957 := by
  intro p hp
  have h : env3957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3956_3957 : H12AffineEnvironment.transform 22 270081 env3956 = env3957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 270081 env3956 == env3957) = true)

def env3958 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,262144,1024,32768,4096,33,270081,41002,8225,270080,323624,16384,16645,22560,1285,323101,256,20481,286480,269333]

theorem envBound3958 : H12AffineFastState.Bounded env3958 := by
  intro p hp
  have h : env3958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3957_3958 : H12AffineEnvironment.transform 6 40 env3957 = env3958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3957 == env3958) = true)

theorem identity3958 : scanCanonicalize (H12AffineFastState.compose env3958 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 48921) := by decide +kernel

theorem selectedBound3958 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3959 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,48921,1024,32768,4096,33,40984,41002,8225,40985,20273,16384,16645,22560,1285,20740,256,20481,57353,41740]

theorem envBound3959 : H12AffineFastState.Bounded env3959 := by
  intro p hp
  have h : env3959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3958_3959 : H12AffineEnvironment.transform 17 48921 env3958 = env3959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48921 env3958 == env3959) = true)

theorem identity3959 : scanCanonicalize (H12AffineFastState.compose env3959 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound3959 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3960 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,13884,8494,4356,2341,1024,13884,4096,33,5668,5654,8225,5669,20273,16384,16645,22560,1285,20740,256,20481,22069,5424]

theorem envBound3960 : H12AffineFastState.Bounded env3960 := by
  intro p hp
  have h : env3960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3959_3960 : H12AffineEnvironment.transform 14 13884 env3959 = env3960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env3959 == env3960) = true)

theorem identity3960 : scanCanonicalize (H12AffineFastState.compose env3960 (packedSelected [1,5,8,13,21,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3960 : packedSelected [1,5,8,13,21,24] rootPS < 2^1333 := by decide +kernel

def env3961 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,4096,8192,16384,13884,8235,4097,2080,1024,13884,4096,33,5668,5654,8225,5669,20020,16384,16384,22560,1024,20481,5,20481,22069,5173]

theorem envBound3961 : H12AffineFastState.Bounded env3961 := by
  intro p hp
  have h : env3961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3960_3961 : H12AffineEnvironment.transform 7 5 env3960 = env3961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3960 == env3961) = true)

theorem identity3961 : scanCanonicalize (H12AffineFastState.compose env3961 (packedSelected [0,1,2,3,6,7,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3961 : packedSelected [0,1,2,3,6,7,12,13] rootPS < 2^1333 := by decide +kernel

def env3962 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1038,8192,16384,8754,8235,1039,2080,1024,8754,1038,33,554,536,8225,555,20020,16384,16384,19502,1024,17423,5,17423,16955,59]

theorem envBound3962 : H12AffineFastState.Bounded env3962 := by
  intro p hp
  have h : env3962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3961_3962 : H12AffineEnvironment.transform 11 1038 env3961 = env3962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env3961 == env3962) = true)

theorem identity3962 : scanCanonicalize (H12AffineFastState.compose env3962 (packedSelected [3,5,10,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3962 : packedSelected [3,5,10,12,18] rootPS < 2^1333 := by decide +kernel

def env3963 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1038,8192,1038,8754,8235,1039,2080,1024,8754,1038,33,554,536,8225,555,2618,1038,1038,2080,1024,1,5,1,1589,59]

theorem envBound3963 : H12AffineFastState.Bounded env3963 := by
  intro p hp
  have h : env3963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3962_3963 : H12AffineEnvironment.transform 13 1038 env3962 = env3963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1038 env3962 == env3963) = true)

theorem identity3963 : scanCanonicalize (H12AffineFastState.compose env3963 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound3963 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3964 : List Nat := [2,4,8,16,32,16,40,5,512,1024,522,1038,8192,1038,8754,8235,1039,554,1024,8754,1038,33,554,536,8225,555,48,1038,1038,554,1024,1,5,1,1589,59]

theorem envBound3964 : H12AffineFastState.Bounded env3964 := by
  intro p hp
  have h : env3964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3963_3964 : H12AffineEnvironment.transform 10 522 env3963 = env3964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env3963 == env3964) = true)

theorem identity3964 : scanCanonicalize (H12AffineFastState.compose env3964 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound3964 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3965 : List Nat := [2,4,8,16,32,16,40,5,59,1024,49,1038,8192,1038,8201,8235,1039,17,1024,8201,1038,33,17,35,8225,16,48,1038,1038,17,1024,1,5,1,1038,59]

theorem envBound3965 : H12AffineFastState.Bounded env3965 := by
  intro p hp
  have h : env3965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3964_3965 : H12AffineEnvironment.transform 8 59 env3964 = env3965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env3964 == env3965) = true)

theorem identity3965 : scanCanonicalize (H12AffineFastState.compose env3965 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound3965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3966 : List Nat := [2,4,8,16,32,16,40,5,59,1024,49,1038,50,1038,59,25,1039,17,1024,59,1038,33,17,35,19,16,48,1038,1038,17,1024,1,5,1,1038,59]

theorem envBound3966 : H12AffineFastState.Bounded env3966 := by
  intro p hp
  have h : env3966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3965_3966 : H12AffineEnvironment.transform 12 50 env3965 = env3966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env3965 == env3966) = true)

theorem identity3966 : scanCanonicalize (H12AffineFastState.compose env3966 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3966 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3967 : List Nat := [2,4,8,0,32,0,40,5,43,1024,33,1038,34,1038,43,9,1039,1,1024,43,1038,33,1,35,3,0,32,1038,1038,1,1024,1,5,1,1038,43]

theorem envBound3967 : H12AffineFastState.Bounded env3967 := by
  intro p hp
  have h : env3967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3966_3967 : H12AffineEnvironment.transform 3 0 env3966 = env3967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3966 == env3967) = true)

theorem identity3967 : scanCanonicalize (H12AffineFastState.compose env3967 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3967 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3968 : List Nat := [2,4,3,0,32,0,35,5,32,1024,33,1029,34,1029,32,2,1028,1,1024,32,1029,33,1,35,3,0,32,1029,1029,1,1024,1,5,1,1029,32]

theorem envBound3968 : H12AffineFastState.Bounded env3968 := by
  intro p hp
  have h : env3968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3967_3968 : H12AffineEnvironment.transform 2 3 env3967 = env3968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3967 == env3968) = true)

theorem identity3968 : scanCanonicalize (H12AffineFastState.compose env3968 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3968 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3969 : List Nat := [2,4,3,0,0,0,3,5,0,1024,1,1029,2,1029,0,2,1028,1,1024,0,1029,1,1,3,3,0,0,1029,1029,1,1024,1,5,1,1029,0]

theorem envBound3969 : H12AffineFastState.Bounded env3969 := by
  intro p hp
  have h : env3969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3968_3969 : H12AffineEnvironment.transform 4 0 env3968 = env3969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3968 == env3969) = true)

def env3970 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,32,270081,41002,8224,270080,323625,16384,16644,22560,1285,323100,256,20481,286481,269332]

theorem envBound3970 : H12AffineFastState.Bounded env3970 := by
  intro p hp
  have h : env3970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3957_3970 : H12AffineEnvironment.transform 6 41 env3957 = env3970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3957 == env3970) = true)

theorem identity3970 : scanCanonicalize (H12AffineFastState.compose env3970 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 60956) := by decide +kernel

theorem selectedBound3970 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3971 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,60956,1024,32768,4096,32,61725,41002,8224,61724,7733,16384,16644,22560,1285,0,256,20481,45325,61960]

theorem envBound3971 : H12AffineFastState.Bounded env3971 := by
  intro p hp
  have h : env3971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3970_3971 : H12AffineEnvironment.transform 17 60956 env3970 = env3971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60956 env3970 == env3971) = true)

theorem identity3971 : scanCanonicalize (H12AffineFastState.compose env3971 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound3971 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3972 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,13885,8494,4357,22561,1024,13885,4096,32,18208,5655,8224,18209,7733,16384,16644,22560,1285,0,256,20481,1840,17461]

theorem envBound3972 : H12AffineFastState.Bounded env3972 := by
  intro p hp
  have h : env3972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3971_3972 : H12AffineEnvironment.transform 14 13885 env3971 = env3972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env3971 == env3972) = true)

theorem identity3972 : scanCanonicalize (H12AffineFastState.compose env3972 (packedSelected [4,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3972 : packedSelected [4,20,22] rootPS < 2^1333 := by decide +kernel

def env3973 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1588,8192,16384,8201,8494,1841,19989,1024,8201,1588,32,18208,35,8224,18209,2049,16384,16644,19988,1285,0,256,17973,1840,17461]

theorem envBound3973 : H12AffineFastState.Bounded env3973 := by
  intro p hp
  have h : env3973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3972_3973 : H12AffineEnvironment.transform 11 1588 env3972 = env3973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3972 == env3973) = true)

theorem identity3973 : scanCanonicalize (H12AffineFastState.compose env3973 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3973 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3974 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1588,8192,16384,8201,8235,1588,19989,1024,8201,1588,32,17957,35,8224,17956,2049,16384,16385,19988,1024,0,5,17973,1589,17461]

theorem envBound3974 : H12AffineFastState.Bounded env3974 := by
  intro p hp
  have h : env3974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3973_3974 : H12AffineEnvironment.transform 7 5 env3973 = env3974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3973 == env3974) = true)

theorem identity3974 : scanCanonicalize (H12AffineFastState.compose env3974 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3974 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3975 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1588,1588,8192,16384,8201,8235,1588,16417,1024,8201,1588,32,17957,35,8224,17956,1589,16384,16385,16416,1024,0,5,17973,1589,17461]

theorem envBound3975 : H12AffineFastState.Bounded env3975 := by
  intro p hp
  have h : env3975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3974_3975 : H12AffineEnvironment.transform 10 1588 env3974 = env3975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env3974 == env3975) = true)

theorem identity3975 : scanCanonicalize (H12AffineFastState.compose env3975 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3975 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3976 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1588,1588,8192,1551,8201,8235,1588,1582,1024,8201,1588,32,42,35,8224,43,1589,1551,1550,1583,1024,0,5,58,1589,570]

theorem envBound3976 : H12AffineFastState.Bounded env3976 := by
  intro p hp
  have h : env3976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3975_3976 : H12AffineEnvironment.transform 13 1551 env3975 = env3976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1551 env3975 == env3976) = true)

theorem identity3976 : scanCanonicalize (H12AffineFastState.compose env3976 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound3976 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env3977 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1588,1588,1063,1551,1070,1036,1588,1582,1024,1070,1588,32,42,35,1031,43,1589,1551,1550,1583,1024,0,5,58,1589,570]

theorem envBound3977 : H12AffineFastState.Bounded env3977 := by
  intro p hp
  have h : env3977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3976_3977 : H12AffineEnvironment.transform 12 1063 env3976 = env3977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env3976 == env3977) = true)

theorem identity3977 : scanCanonicalize (H12AffineFastState.compose env3977 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3977 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3978 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1550,1550,1053,1551,1044,1036,1550,1556,1024,1044,1550,26,16,25,1031,17,1551,1551,1550,1557,1024,0,5,0,1551,512]

theorem envBound3978 : H12AffineFastState.Bounded env3978 := by
  intro p hp
  have h : env3978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3977_3978 : H12AffineEnvironment.transform 4 26 env3977 = env3978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3977 == env3978) = true)

theorem identity3978 : scanCanonicalize (H12AffineFastState.compose env3978 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3978 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3979 : List Nat := [2,4,8,16,26,16,19,5,0,1024,1038,1038,1053,1039,1044,1036,1038,1044,1024,1044,1038,26,16,25,1031,17,1039,1039,1038,1045,1024,0,5,0,1039,0]

theorem envBound3979 : H12AffineFastState.Bounded env3979 := by
  intro p hp
  have h : env3979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3978_3979 : H12AffineEnvironment.transform 8 0 env3978 = env3979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3978 == env3979) = true)

theorem identity3979 : scanCanonicalize (H12AffineFastState.compose env3979 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound3979 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3980 : List Nat := [2,4,8,16,26,16,19,5,0,20,26,26,9,27,0,24,26,0,20,0,26,26,16,25,19,17,27,27,26,1,20,0,5,0,27,0]

theorem envBound3980 : H12AffineFastState.Bounded env3980 := by
  intro p hp
  have h : env3980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3979_3980 : H12AffineEnvironment.transform 9 20 env3979 = env3980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env3979 == env3980) = true)

def env3981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,8388608,41002,8329,8388608,323713,16384,16812,22561,1285,12644669,256,20480,8405177,8389565]

theorem envBound3981 : H12AffineFastState.Bounded env3981 := by
  intro p hp
  have h : env3981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3927_3981 : H12AffineEnvironment.transform 5 17 env3927 = env3981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3927 == env3981) = true)

theorem identity3981 : scanCanonicalize (H12AffineFastState.compose env3981 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3981 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,445,41002,8329,445,323713,16384,16812,22561,1285,4255872,256,20480,16644,512]

theorem envBound3982 : H12AffineFastState.Bounded env3982 := by
  intro p hp
  have h : env3982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3981_3982 : H12AffineEnvironment.transform 22 445 env3981 = env3982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3981 == env3982) = true)

theorem identity3982 : scanCanonicalize (H12AffineFastState.compose env3982 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3982 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,41349,445,41002,8329,445,323713,16384,16812,22561,1285,20741,256,20480,16644,512]

theorem envBound3983 : H12AffineFastState.Bounded env3983 := by
  intro p hp
  have h : env3983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3982_3983 : H12AffineEnvironment.transform 21 41349 env3982 = env3983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3982 == env3983) = true)

theorem identity3983 : scanCanonicalize (H12AffineFastState.compose env3983 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound3983 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13972,8494,4525,262144,1024,13972,4096,5905,445,5822,8329,445,280085,16384,16812,22561,1285,20741,256,20480,16644,512]

theorem envBound3984 : H12AffineFastState.Bounded env3984 := by
  intro p hp
  have h : env3984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3983_3984 : H12AffineEnvironment.transform 14 13972 env3983 = env3984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env3983 == env3984) = true)

theorem identity3984 : scanCanonicalize (H12AffineFastState.compose env3984 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound3984 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3985 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,262144,1024,13972,4096,5905,445,5822,8329,445,268217,4524,4096,2445,1285,169,256,428,4264,512]

theorem envBound3985 : H12AffineFastState.Bounded env3985 := by
  intro p hp
  have h : env3985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3984_3985 : H12AffineEnvironment.transform 13 4524 env3984 = env3985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env3984 == env3985) = true)

theorem identity3985 : scanCanonicalize (H12AffineFastState.compose env3985 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound3985 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env3986 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,7869,1024,13972,4096,5905,445,5822,8329,445,2308,4524,4096,2445,1285,169,256,428,4264,512]

theorem envBound3986 : H12AffineFastState.Bounded env3986 := by
  intro p hp
  have h : env3986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3985_3986 : H12AffineEnvironment.transform 17 7869 env3985 = env3986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env3985 == env3986) = true)

theorem identity3986 : scanCanonicalize (H12AffineFastState.compose env3986 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3986 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env3987 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,8192,4264,13972,8234,4265,7869,1024,13972,4096,5653,185,5822,8329,185,2048,4264,4096,2185,1025,169,4,168,4264,512]

theorem envBound3987 : H12AffineFastState.Bounded env3987 := by
  intro p hp
  have h : env3987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3986_3987 : H12AffineEnvironment.transform 7 4 env3986 = env3987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3986 == env3987) = true)

theorem identity3987 : scanCanonicalize (H12AffineFastState.compose env3987 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3987 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3988 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1589,8192,1693,8353,8234,1692,2184,1024,8353,1589,32,185,139,8329,185,2048,1693,1589,2185,1025,169,4,168,1693,512]

theorem envBound3988 : H12AffineFastState.Bounded env3988 := by
  intro p hp
  have h : env3988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3987_3988 : H12AffineEnvironment.transform 11 1589 env3987 = env3988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3987 == env3988) = true)

theorem identity3988 : scanCanonicalize (H12AffineFastState.compose env3988 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound3988 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env3989 : List Nat := [2,4,8,16,32,17,128,4,512,1024,539,1589,8192,1693,8353,8234,1692,659,1024,8353,1589,32,185,139,8329,185,539,1693,1589,658,1025,169,4,168,1693,512]

theorem envBound3989 : H12AffineFastState.Bounded env3989 := by
  intro p hp
  have h : env3989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3988_3989 : H12AffineEnvironment.transform 10 539 env3988 = env3989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env3988 == env3989) = true)

theorem identity3989 : scanCanonicalize (H12AffineFastState.compose env3989 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound3989 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env3990 : List Nat := [2,4,8,16,32,17,128,4,512,1024,539,1589,41,1693,136,3,1692,659,1024,136,1589,32,185,139,160,185,539,1693,1589,658,1025,169,4,168,1693,512]

theorem envBound3990 : H12AffineFastState.Bounded env3990 := by
  intro p hp
  have h : env3990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3989_3990 : H12AffineEnvironment.transform 12 41 env3989 = env3990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env3989 == env3990) = true)

theorem identity3990 : scanCanonicalize (H12AffineFastState.compose env3990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3991 : List Nat := [2,4,8,16,32,17,41,4,512,1024,539,1589,41,1588,33,3,1589,570,1024,33,1589,32,16,34,9,16,539,1588,1589,571,1025,0,4,1,1588,512]

theorem envBound3991 : H12AffineFastState.Bounded env3991 := by
  intro p hp
  have h : env3991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3990_3991 : H12AffineEnvironment.transform 6 41 env3990 = env3991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3990 == env3991) = true)

theorem identity3991 : scanCanonicalize (H12AffineFastState.compose env3991 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3992 : List Nat := [2,4,8,16,11,17,2,4,512,1024,539,1566,2,1567,10,3,1566,529,1024,10,1566,11,16,9,9,16,539,1567,1566,528,1025,0,4,1,1567,512]

theorem envBound3992 : H12AffineFastState.Bounded env3992 := by
  intro p hp
  have h : env3992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3991_3992 : H12AffineEnvironment.transform 4 11 env3991 = env3992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3991 == env3992) = true)

theorem identity3992 : scanCanonicalize (H12AffineFastState.compose env3992 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3992 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3993 : List Nat := [2,4,8,11,11,10,2,4,512,1024,512,1541,2,1540,10,3,1541,522,1024,10,1541,11,11,9,9,11,512,1540,1541,523,1025,0,4,1,1540,512]

theorem envBound3993 : H12AffineFastState.Bounded env3993 := by
  intro p hp
  have h : env3993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3992_3993 : H12AffineEnvironment.transform 3 11 env3992 = env3993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3992 == env3993) = true)

theorem identity3993 : scanCanonicalize (H12AffineFastState.compose env3993 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3994 : List Nat := [2,4,3,0,0,1,2,4,512,1024,512,1541,2,1540,1,3,1541,513,1024,1,1541,0,0,2,2,0,512,1540,1541,512,1025,0,4,1,1540,512]

theorem envBound3994 : H12AffineFastState.Bounded env3994 := by
  intro p hp
  have h : env3994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3993_3994 : H12AffineEnvironment.transform 2 3 env3993 = env3994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3993 == env3994) = true)

theorem identity3994 : scanCanonicalize (H12AffineFastState.compose env3994 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3994 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3995 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,2,1028,1,3,1029,1,1024,1,1029,0,0,2,2,0,0,1028,1029,0,1025,0,4,1,1028,0]

theorem envBound3995 : H12AffineFastState.Bounded env3995 := by
  intro p hp
  have h : env3995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3994_3995 : H12AffineEnvironment.transform 8 0 env3994 = env3995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3994 == env3995) = true)

def leafEnv3995 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,2,1028,1,3,1029,1,1024,1,1029,0,0,2,1025,2,1,0,0,1028,1029,0,1025,0,4,1,4,2,1028,0,1,1028,0]

def active3995 : List Nat := [0,1,9]

def tree3995 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3995 : H12WitnessSearch.Good tree3995 := H12GlobalWitnessIndex.good

theorem leafIdentity3995 : H12AffineFastState.composeSystem env3995 rootObs = leafEnv3995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3995 rootObs == leafEnv3995) = true)

theorem terminalChecked3995 : H12PackedTerminal.terminalCheckFast leafEnv3995 active3995 tree3995 = true := by decide +kernel

def env3996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323793,16384,16893,22641,74794,12644669,257,20560,8479127,8389613]

theorem envBound3996 : H12AffineFastState.Bounded env3996 := by
  intro p hp
  have h : env3996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3925_3996 : H12AffineEnvironment.transform 18 1025 env3925 = env3996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3925 == env3996) = true)

theorem identity3996 : scanCanonicalize (H12AffineFastState.compose env3996 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91182) := by decide +kernel

theorem selectedBound3996 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,91182,41002,8329,91262,323793,16384,16893,22641,74794,4298003,257,20560,1465,92099]

theorem envBound3997 : H12AffineFastState.Bounded env3997 := by
  intro p hp
  have h : env3997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3996_3997 : H12AffineEnvironment.transform 22 91182 env3996 = env3997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91182 env3996 == env3997) = true)

def env3998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,91182,41002,8329,91182,323713,16384,16813,22561,74794,4298003,257,20480,1465,92051]

theorem envBound3998 : H12AffineFastState.Bounded env3998 := by
  intro p hp
  have h : env3998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3997_3998 : H12AffineEnvironment.transform 5 16 env3997 = env3998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3997 == env3998) = true)

theorem identity3998 : scanCanonicalize (H12AffineFastState.compose env3998 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 26003) := by decide +kernel

theorem selectedBound3998 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,445,41002,8329,445,323713,16384,16813,22561,16825,4255872,257,20480,1465,512]

theorem envBound3999 : H12AffineFastState.Bounded env3999 := by
  intro p hp
  have h : env3999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3998_3999 : H12AffineEnvironment.transform 15 26003 env3998 = env3999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26003 env3998 == env3999) = true)

theorem identity3999 : scanCanonicalize (H12AffineFastState.compose env3999 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3999 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,41348,445,41002,8329,445,323713,16384,16813,22561,16825,20740,257,20480,1465,512]

theorem envBound4000 : H12AffineFastState.Bounded env4000 := by
  intro p hp
  have h : env4000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3999_4000 : H12AffineEnvironment.transform 21 41348 env3999 = env4000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3999 == env4000) = true)

theorem identity4000 : scanCanonicalize (H12AffineFastState.compose env4000 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4000 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4001 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26003,4524,262144,1025,29225,4096,21421,445,20995,8329,445,262824,16384,16813,22561,16825,20740,257,20480,1465,512]

theorem envBound4001 : H12AffineFastState.Bounded env4001 := by
  intro p hp
  have h : env4001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4000_4001 : H12AffineEnvironment.transform 14 29225 env4000 = env4001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4000 == env4001) = true)

theorem identity4001 : scanCanonicalize (H12AffineFastState.compose env4001 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4001 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4002 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26003,1213,262144,1025,26424,1297,18108,445,18194,8329,445,262824,16384,16813,19760,16825,17429,257,17681,1465,512]

theorem envBound4002 : H12AffineFastState.Bounded env4002 := by
  intro p hp
  have h : env4002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4001_4002 : H12AffineEnvironment.transform 11 1297 env4001 = env4002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4001 == env4002) = true)

theorem identity4002 : scanCanonicalize (H12AffineFastState.compose env4002 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4002 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4003 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1692,8612,8975,1213,262144,1025,8612,1297,32,445,398,8329,445,262824,1692,1841,2988,1829,649,257,909,1465,512]

theorem envBound4003 : H12AffineFastState.Bounded env4003 := by
  intro p hp
  have h : env4003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4002_4003 : H12AffineEnvironment.transform 13 1692 env4002 = env4003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env4002 == env4003) = true)

theorem identity4003 : scanCanonicalize (H12AffineFastState.compose env4003 (packedSelected [8,10,12,15,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4003 : packedSelected [8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4004 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1692,8201,8866,1213,262144,1025,8201,1212,32,16,35,8329,16,262824,1692,1692,2561,1672,649,172,544,1044,512]

theorem envBound4004 : H12AffineFastState.Bounded env4004 := by
  intro p hp
  have h : env4004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4003_4004 : H12AffineEnvironment.transform 7 173 env4003 = env4004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4003 == env4004) = true)

theorem identity4004 : scanCanonicalize (H12AffineFastState.compose env4004 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4004 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4005 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1692,8201,8866,1213,1583,1025,8201,1212,32,16,35,8329,16,1159,1692,1692,2561,1672,649,172,544,1044,512]

theorem envBound4005 : H12AffineFastState.Bounded env4005 := by
  intro p hp
  have h : env4005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4004_4005 : H12AffineEnvironment.transform 17 1583 env4004 = env4005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env4004 == env4005) = true)

def env4006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,91182,41002,8329,91183,323712,16384,16812,22560,74794,4298003,257,20481,1465,92050]

theorem envBound4006 : H12AffineFastState.Bounded env4006 := by
  intro p hp
  have h : env4006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3997_4006 : H12AffineEnvironment.transform 5 17 env3997 = env4006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3997 == env4006) = true)

def env4007 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41088,91182,41002,8329,91183,323712,16384,16812,22560,74794,79251,257,20481,1465,92050]

theorem envBound4007 : H12AffineFastState.Bounded env4007 := by
  intro p hp
  have h : env4007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4006_4007 : H12AffineEnvironment.transform 21 41088 env4006 = env4007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4006 == env4007) = true)

theorem identity4007 : scanCanonicalize (H12AffineFastState.compose env4007 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4007 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4008 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1025,32768,4096,41088,91182,41002,8329,91183,323712,16384,16552,22560,74794,78999,5,20481,1213,91798]

theorem envBound4008 : H12AffineFastState.Bounded env4008 := by
  intro p hp
  have h : env4008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4007_4008 : H12AffineEnvironment.transform 7 4 env4007 = env4008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4007 == env4008) = true)

def env4009 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4096,41000,91182,41002,8225,91183,323624,16384,16384,22560,74794,78911,5,20481,1045,91710]

theorem envBound4009 : H12AffineFastState.Bounded env4009 := by
  intro p hp
  have h : env4009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4008_4009 : H12AffineEnvironment.transform 6 40 env4008 = env4009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4008 == env4009) = true)

def env4010 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4096,41001,91182,41002,8224,91183,323625,16384,16385,22560,74794,78910,5,20481,1044,91711]

theorem envBound4010 : H12AffineFastState.Bounded env4010 := by
  intro p hp
  have h : env4010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4008_4010 : H12AffineEnvironment.transform 6 41 env4008 = env4010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4008 == env4010) = true)

theorem identity4010 : scanCanonicalize (H12AffineFastState.compose env4010 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound4010 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4011 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,65536,1045,262144,1025,32768,1045,41001,91182,41002,8224,91183,320572,16384,16385,19509,74794,73771,5,17428,1044,91711]

theorem envBound4011 : H12AffineFastState.Bounded env4011 := by
  intro p hp
  have h : env4011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4010_4011 : H12AffineEnvironment.transform 11 1045 env4010 = env4011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env4010 == env4011) = true)

theorem identity4011 : scanCanonicalize (H12AffineFastState.compose env4011 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 60447) := by decide +kernel

theorem selectedBound4011 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env4012 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,32768,60447,1045,262144,1025,32768,1045,41001,34865,41002,8224,34864,320572,16384,16385,19509,51253,52276,5,17428,1044,35360]

theorem envBound4012 : H12AffineFastState.Bounded env4012 := by
  intro p hp
  have h : env4012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4011_4012 : H12AffineEnvironment.transform 15 60447 env4011 = env4012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 60447 env4011 == env4012) = true)

theorem identity4012 : scanCanonicalize (H12AffineFastState.compose env4012 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 19477) := by decide +kernel

theorem selectedBound4012 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4013 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,19477,8202,1045,262144,1025,19477,1045,27708,17444,27711,8224,17445,272425,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4013 : H12AffineFastState.Bounded env4013 := by
  intro p hp
  have h : env4013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4012_4013 : H12AffineEnvironment.transform 14 19477 env4012 = env4013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19477 env4012 == env4013) = true)

theorem identity4013 : scanCanonicalize (H12AffineFastState.compose env4013 (packedSelected [2,3,4,8,9,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4013 : packedSelected [2,3,4,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env4014 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,8192,16384,19477,8202,1045,8201,1025,19477,1045,27708,17444,27711,8224,17445,2080,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4014 : H12AffineFastState.Bounded env4014 := by
  intro p hp
  have h : env4014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4013_4014 : H12AffineEnvironment.transform 17 8201 env4013 = env4014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8201 env4013 == env4014) = true)

theorem identity4014 : scanCanonicalize (H12AffineFastState.compose env4014 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound4014 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env4015 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1045,1542,16384,19477,1548,1045,1551,1025,19477,1045,19002,17444,19001,1574,17445,2080,16384,16385,19509,1056,33,5,17428,1044,17973]

theorem envBound4015 : H12AffineFastState.Bounded env4015 := by
  intro p hp
  have h : env4015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4014_4015 : H12AffineEnvironment.transform 12 1542 env4014 = env4015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env4014 == env4015) = true)

theorem identity4015 : scanCanonicalize (H12AffineFastState.compose env4015 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4015 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env4016 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1582,1045,1542,16384,16955,1548,1045,1551,1025,16955,1045,17428,17444,17431,1574,17445,1550,16384,16385,16923,1056,33,5,17428,1044,17973]

theorem envBound4016 : H12AffineFastState.Bounded env4016 := by
  intro p hp
  have h : env4016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4015_4016 : H12AffineEnvironment.transform 10 1582 env4015 = env4016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env4015 == env4016) = true)

theorem identity4016 : scanCanonicalize (H12AffineFastState.compose env4016 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound4016 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4017 : List Nat := [2,4,8,16,32,17,41,4,59,1024,1045,1045,1085,16384,16384,1079,1045,1076,1025,16384,1045,17428,17444,17431,1053,17445,1077,16384,16385,16416,1056,33,5,17428,1044,17422]

theorem envBound4017 : H12AffineFastState.Bounded env4017 := by
  intro p hp
  have h : env4017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4016_4017 : H12AffineEnvironment.transform 8 59 env4016 = env4017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env4016 == env4017) = true)

theorem identity4017 : scanCanonicalize (H12AffineFastState.compose env4017 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound4017 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4018 : List Nat := [2,4,8,16,32,17,41,4,59,1024,1045,1045,1085,1077,1077,1079,1045,1076,1025,1077,1045,33,17,34,1053,16,1077,1077,1076,1045,1056,33,5,33,1044,59]

theorem envBound4018 : H12AffineFastState.Bounded env4018 := by
  intro p hp
  have h : env4018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4017_4018 : H12AffineEnvironment.transform 13 1077 env4017 = env4018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env4017 == env4018) = true)

theorem identity4018 : scanCanonicalize (H12AffineFastState.compose env4018 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound4018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4019 : List Nat := [2,4,8,16,32,17,41,4,59,21,0,0,40,32,32,34,0,33,20,32,0,33,17,34,8,16,32,32,33,0,53,33,5,33,1,59]

theorem envBound4019 : H12AffineFastState.Bounded env4019 := by
  intro p hp
  have h : env4019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4018_4019 : H12AffineEnvironment.transform 9 21 env4018 = env4019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env4018 == env4019) = true)

theorem identity4019 : scanCanonicalize (H12AffineFastState.compose env4019 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4019 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4020 : List Nat := [2,4,8,16,27,17,18,4,0,21,0,0,19,27,27,25,0,26,20,27,0,26,17,25,8,16,27,27,26,0,14,26,5,26,1,0]

theorem envBound4020 : H12AffineFastState.Bounded env4020 := by
  intro p hp
  have h : env4020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4019_4020 : H12AffineEnvironment.transform 4 27 env4019 = env4020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4019 == env4020) = true)

theorem identity4020 : scanCanonicalize (H12AffineFastState.compose env4020 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4021 : List Nat := [2,4,8,11,0,10,9,4,0,14,0,0,8,0,0,2,0,1,15,0,0,1,10,2,8,11,0,0,1,0,14,1,5,1,1,0]

theorem envBound4021 : H12AffineFastState.Bounded env4021 := by
  intro p hp
  have h : env4021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4020_4021 : H12AffineEnvironment.transform 3 11 env4020 = env4021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4020 == env4021) = true)

def env4022 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,41089,91182,41002,8329,91183,323712,16384,16812,22560,74794,79250,257,20481,1465,92050]

theorem envBound4022 : H12AffineFastState.Bounded env4022 := by
  intro p hp
  have h : env4022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4006_4022 : H12AffineEnvironment.transform 21 41089 env4006 = env4022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4006 == env4022) = true)

theorem identity4022 : scanCanonicalize (H12AffineFastState.compose env4022 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25751) := by decide +kernel

theorem selectedBound4022 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4023 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25751,4525,262144,1025,32768,4096,41089,185,41002,8329,184,323712,16384,16812,22560,16573,20741,257,20481,1465,773]

theorem envBound4023 : H12AffineFastState.Bounded env4023 := by
  intro p hp
  have h : env4023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4022_4023 : H12AffineEnvironment.transform 15 25751 env4022 = env4023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25751 env4022 == env4023) = true)

def env4024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,32768,25751,1045,262144,1025,32768,1464,41089,185,41002,8329,184,320824,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4024 : H12AffineFastState.Bounded env4024 := by
  intro p hp
  have h : env4024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4023_4024 : H12AffineEnvironment.transform 11 1464 env4023 = env4024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4023 == env4024) = true)

theorem identity4024 : scanCanonicalize (H12AffineFastState.compose env4024 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26033) := by decide +kernel

theorem selectedBound4024 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26033,25751,1045,262144,1025,26033,1464,17712,185,17819,8329,184,262281,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4025 : H12AffineFastState.Bounded env4025 := by
  intro p hp
  have h : env4025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4024_4025 : H12AffineEnvironment.transform 14 26033 env4024 = env4025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26033 env4024 == env4025) = true)

theorem identity4025 : scanCanonicalize (H12AffineFastState.compose env4025 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19761) := by decide +kernel

theorem selectedBound4025 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4026 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26033,25751,1045,19761,1025,26033,1464,17712,185,17819,8329,184,19896,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4026 : H12AffineFastState.Bounded env4026 := by
  intro p hp
  have h : env4026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4025_4026 : H12AffineEnvironment.transform 17 19761 env4025 = env4026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19761 env4025 == env4026) = true)

theorem identity4026 : scanCanonicalize (H12AffineFastState.compose env4026 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4026 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4027 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,9,16384,17848,17566,1045,19761,1025,17848,1464,17712,185,17819,128,184,19896,16384,16812,19864,16573,17597,257,17849,1465,773]

theorem envBound4027 : H12AffineFastState.Bounded env4027 := by
  intro p hp
  have h : env4027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4026_4027 : H12AffineEnvironment.transform 12 9 env4026 = env4027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4026 == env4027) = true)

theorem identity4027 : scanCanonicalize (H12AffineFastState.compose env4027 (packedSelected [1,2,5,6,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound4027 : packedSelected [1,2,5,6,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env4028 : List Nat := [2,4,8,16,32,17,128,256,512,1024,799,1464,9,16384,17848,17566,1045,17966,1025,17848,1464,17712,185,17819,128,184,18087,16384,16812,18055,16573,17597,257,17849,1465,773]

theorem envBound4028 : H12AffineFastState.Bounded env4028 := by
  intro p hp
  have h : env4028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4027_4028 : H12AffineEnvironment.transform 10 799 env4027 = env4028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env4027 == env4028) = true)

theorem identity4028 : scanCanonicalize (H12AffineFastState.compose env4028 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4028 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4029 : List Nat := [2,4,8,16,32,17,128,256,33,1024,318,1464,9,16384,17848,17566,1045,17423,1025,17848,1464,17712,185,17819,128,184,17542,16384,16812,17574,16573,17597,257,17849,1465,292]

theorem envBound4029 : H12AffineFastState.Bounded env4029 := by
  intro p hp
  have h : env4029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4028_4029 : H12AffineEnvironment.transform 8 33 env4028 = env4029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4028 == env4029) = true)

theorem identity4029 : scanCanonicalize (H12AffineFastState.compose env4029 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4029 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4030 : List Nat := [2,4,8,16,32,17,128,173,33,1024,147,1045,9,16384,17429,17566,1045,17423,1025,17429,1045,17565,185,17462,128,184,17542,16384,16385,17574,16573,17597,172,17428,1044,137]

theorem envBound4030 : H12AffineFastState.Bounded env4030 := by
  intro p hp
  have h : env4030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4029_4030 : H12AffineEnvironment.transform 7 173 env4029 = env4030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4029 == env4030) = true)

theorem identity4030 : scanCanonicalize (H12AffineFastState.compose env4030 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound4030 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4031 : List Nat := [2,4,8,16,32,17,128,173,33,1024,147,1045,9,1028,17,154,1045,11,1025,17,1045,153,185,50,128,184,130,1028,1029,162,1209,185,172,16,1044,137]

theorem envBound4031 : H12AffineFastState.Bounded env4031 := by
  intro p hp
  have h : env4031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4030_4031 : H12AffineEnvironment.transform 13 1028 env4030 = env4031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env4030 == env4031) = true)

theorem identity4031 : scanCanonicalize (H12AffineFastState.compose env4031 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound4031 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env4032 : List Nat := [2,4,8,16,32,17,128,173,33,52,147,33,9,48,17,154,33,11,53,17,33,153,185,50,128,184,130,48,49,162,141,185,172,16,32,137]

theorem envBound4032 : H12AffineFastState.Bounded env4032 := by
  intro p hp
  have h : env4032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4031_4032 : H12AffineEnvironment.transform 9 52 env4031 = env4032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env4031 == env4032) = true)

theorem identity4032 : scanCanonicalize (H12AffineFastState.compose env4032 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4032 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4033 : List Nat := [2,4,8,16,27,17,128,150,26,15,147,26,9,11,17,154,26,11,14,17,26,153,130,9,128,131,130,11,10,153,141,130,151,16,27,137]

theorem envBound4033 : H12AffineFastState.Bounded env4033 := by
  intro p hp
  have h : env4033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4032_4033 : H12AffineEnvironment.transform 4 27 env4032 = env4033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4032 == env4033) = true)

theorem identity4033 : scanCanonicalize (H12AffineFastState.compose env4033 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4033 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env4034 : List Nat := [2,4,3,16,16,17,128,150,17,4,147,17,2,0,17,145,17,0,5,17,17,146,130,2,128,131,130,0,1,146,134,130,151,16,16,130]

theorem envBound4034 : H12AffineFastState.Bounded env4034 := by
  intro p hp
  have h : env4034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4033_4034 : H12AffineEnvironment.transform 2 3 env4033 = env4034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4033 == env4034) = true)

theorem identity4034 : scanCanonicalize (H12AffineFastState.compose env4034 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound4034 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4035 : List Nat := [2,4,3,16,16,17,2,20,17,4,17,17,2,0,17,19,17,0,5,17,17,16,0,2,2,1,0,0,1,16,4,0,21,16,16,0]

theorem envBound4035 : H12AffineFastState.Bounded env4035 := by
  intro p hp
  have h : env4035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4034_4035 : H12AffineEnvironment.transform 6 2 env4034 = env4035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env4034 == env4035) = true)

theorem identity4035 : scanCanonicalize (H12AffineFastState.compose env4035 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4036 : List Nat := [2,4,3,1,1,0,2,5,0,4,0,0,2,0,0,2,0,0,5,0,0,1,0,2,2,1,0,0,1,1,4,0,4,1,1,0]

theorem envBound4036 : H12AffineFastState.Bounded env4036 := by
  intro p hp
  have h : env4036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4035_4036 : H12AffineEnvironment.transform 3 1 env4035 = env4036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4035 == env4036) = true)

def env4037 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,32768,25751,1044,262144,1025,32768,1465,41089,185,41002,8329,184,320825,16384,16812,19865,16573,17596,257,17848,1465,773]

theorem envBound4037 : H12AffineFastState.Bounded env4037 := by
  intro p hp
  have h : env4037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4023_4037 : H12AffineEnvironment.transform 11 1465 env4023 = env4037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4023 == env4037) = true)

theorem identity4037 : scanCanonicalize (H12AffineFastState.compose env4037 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4037 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4038 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,25662,1044,262144,1025,32768,1296,41000,16,41002,8224,17,320825,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4038 : H12AffineFastState.Bounded env4038 := by
  intro p hp
  have h : env4038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4037_4038 : H12AffineEnvironment.transform 6 41 env4037 = env4038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4037 == env4038) = true)

theorem identity4038 : scanCanonicalize (H12AffineFastState.compose env4038 (packedSelected [5,6,8,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 42022) := by decide +kernel

theorem selectedBound4038 : packedSelected [5,6,8,13,17] rootPS < 2^1333 := by decide +kernel

def env4039 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,32768,25662,1044,42022,1025,32768,1296,41000,16,41002,8224,17,16671,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4039 : H12AffineFastState.Bounded env4039 := by
  intro p hp
  have h : env4039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4038_4039 : H12AffineEnvironment.transform 17 42022 env4038 = env4039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 42022 env4038 == env4039) = true)

theorem identity4039 : scanCanonicalize (H12AffineFastState.compose env4039 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 25912) := by decide +kernel

theorem selectedBound4039 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4040 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,25912,25662,1044,16670,1025,25912,1296,17680,16,17682,8224,17,16671,16384,16645,19760,16404,17429,257,17681,1296,773]

theorem envBound4040 : H12AffineFastState.Bounded env4040 := by
  intro p hp
  have h : env4040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4039_4040 : H12AffineEnvironment.transform 14 25912 env4039 = env4040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25912 env4039 == env4040) = true)

theorem identity4040 : scanCanonicalize (H12AffineFastState.compose env4040 (packedSelected [1,2,3,10,11,12,23] rootPS)) = affineNative (2^(13+1) ^^^ 11292) := by decide +kernel

theorem selectedBound4040 : packedSelected [1,2,3,10,11,12,23] rootPS < 2^1333 := by decide +kernel

def env4041 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,11292,2340,2082,1044,11522,1025,2340,1296,10508,16,10510,8224,17,11523,11292,11545,8492,11272,10249,257,10509,1296,773]

theorem envBound4041 : H12AffineFastState.Bounded env4041 := by
  intro p hp
  have h : env4041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4040_4041 : H12AffineEnvironment.transform 13 11292 env4040 = env4041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11292 env4040 == env4041) = true)

theorem identity4041 : scanCanonicalize (H12AffineFastState.compose env4041 (packedSelected [3,4,5,6,7,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4041 : packedSelected [3,4,5,6,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4042 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1044,8192,11292,2080,2082,1044,11270,1025,2080,1044,10248,16,10250,8224,17,11271,11292,11293,8232,11272,10249,5,10249,1044,513]

theorem envBound4042 : H12AffineFastState.Bounded env4042 := by
  intro p hp
  have h : env4042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4041_4042 : H12AffineEnvironment.transform 7 4 env4041 = env4042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4041 == env4042) = true)

theorem identity4042 : scanCanonicalize (H12AffineFastState.compose env4042 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound4042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4043 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1044,2088,1076,2080,2082,1044,1070,1025,2080,1044,32,16,34,2056,17,1071,1076,1077,2048,1056,33,5,33,1044,513]

theorem envBound4043 : H12AffineFastState.Bounded env4043 := by
  intro p hp
  have h : env4043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4042_4043 : H12AffineEnvironment.transform 12 2088 env4042 = env4043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env4042 == env4043) = true)

theorem identity4043 : scanCanonicalize (H12AffineFastState.compose env4043 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4043 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4044 : List Nat := [2,4,8,16,32,17,41,4,512,32,2048,52,2088,20,2080,2082,52,14,33,2080,52,32,16,34,2056,17,15,20,21,2048,0,33,5,33,52,513]

theorem envBound4044 : H12AffineFastState.Bounded env4044 := by
  intro p hp
  have h : env4044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4043_4044 : H12AffineEnvironment.transform 9 32 env4043 = env4044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4043 == env4044) = true)

theorem identity4044 : scanCanonicalize (H12AffineFastState.compose env4044 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4044 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4045 : List Nat := [2,4,8,16,32,17,41,4,33,32,2048,52,2088,20,2080,2082,52,14,33,2080,52,32,16,34,2056,17,15,20,21,2048,0,33,5,33,52,32]

theorem envBound4045 : H12AffineFastState.Bounded env4045 := by
  intro p hp
  have h : env4045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4044_4045 : H12AffineEnvironment.transform 8 33 env4044 = env4045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4044 == env4045) = true)

theorem identity4045 : scanCanonicalize (H12AffineFastState.compose env4045 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4045 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4046 : List Nat := [2,4,7,16,32,17,38,4,33,32,2048,52,2087,20,2080,2082,52,1,33,2080,52,32,16,34,2055,17,0,20,21,2048,0,33,5,33,52,32]

theorem envBound4046 : H12AffineFastState.Bounded env4046 := by
  intro p hp
  have h : env4046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4045_4046 : H12AffineEnvironment.transform 2 7 env4045 = env4046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4045 == env4046) = true)

theorem identity4046 : scanCanonicalize (H12AffineFastState.compose env4046 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound4046 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env4047 : List Nat := [2,4,7,16,32,17,38,4,33,32,21,52,50,20,53,55,52,1,33,53,52,32,16,34,18,17,0,20,21,21,0,33,5,33,52,32]

theorem envBound4047 : H12AffineFastState.Bounded env4047 := by
  intro p hp
  have h : env4047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4046_4047 : H12AffineEnvironment.transform 10 21 env4046 = env4047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env4046 == env4047) = true)

theorem identity4047 : scanCanonicalize (H12AffineFastState.compose env4047 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound4047 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4048 : List Nat := [2,4,7,16,21,17,19,4,20,21,21,1,7,20,0,2,1,1,20,0,1,21,16,23,18,17,0,20,21,21,0,20,5,20,1,21]

theorem envBound4048 : H12AffineFastState.Bounded env4048 := by
  intro p hp
  have h : env4048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4047_4048 : H12AffineEnvironment.transform 4 21 env4047 = env4048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env4047 == env4048) = true)

theorem identity4048 : scanCanonicalize (H12AffineFastState.compose env4048 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4048 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4049 : List Nat := [2,4,7,0,5,1,3,4,4,5,5,1,7,4,0,2,1,1,4,0,1,5,0,7,2,1,0,4,5,5,0,4,5,4,1,5]

theorem envBound4049 : H12AffineFastState.Bounded env4049 := by
  intro p hp
  have h : env4049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4048_4049 : H12AffineEnvironment.transform 3 0 env4048 = env4049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4048 == env4049) = true)

def leafEnv4049 : List Nat := [2,4,7,0,5,1,3,4,4,5,5,1,7,4,0,2,1,1,4,0,1,5,0,7,0,2,1,1,0,4,5,5,0,4,5,4,4,6,1,5,1,5,0]

def active4049 : List Nat := [0,1]

def tree4049 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4049 : H12WitnessSearch.Good tree4049 := H12GlobalWitnessIndex.good

theorem leafIdentity4049 : H12AffineFastState.composeSystem env4049 rootObs = leafEnv4049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4049 rootObs == leafEnv4049) = true)

theorem terminalChecked4049 : H12PackedTerminal.terminalCheckFast leafEnv4049 active4049 tree4049 = true := by decide +kernel

def env4050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849104,16385,16892,547952,598059,12644669,525568,545873,8479127,8914924]

theorem envBound4050 : H12AffineFastState.Bounded env4050 := by
  intro p hp
  have h : env4050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3924_4050 : H12AffineEnvironment.transform 27 16385 env3924 = env4050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3924 == env4050) = true)

def env4051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16385,16892,22640,74795,12644669,256,20561,8479127,8389612]

theorem envBound4051 : H12AffineFastState.Bounded env4051 := by
  intro p hp
  have h : env4051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4050_4051 : H12AffineEnvironment.transform 18 1024 env4050 = env4051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4050 == env4051) = true)

theorem identity4051 : scanCanonicalize (H12AffineFastState.compose env4051 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4293055) := by decide +kernel

theorem selectedBound4051 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,4293055,41002,8329,4293102,323792,16385,16892,22640,74795,94338,256,20561,4251688,4293203]

theorem envBound4052 : H12AffineFastState.Bounded env4052 := by
  intro p hp
  have h : env4052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4051_4052 : H12AffineEnvironment.transform 22 4293055 env4051 = env4052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4293055 env4051 == env4052) = true)

def env4053 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,4293055,41002,8329,4293054,323712,16385,16812,22560,74795,94338,256,20481,4251688,4293123]

theorem envBound4053 : H12AffineFastState.Bounded env4053 := by
  intro p hp
  have h : env4053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4052_4053 : H12AffineEnvironment.transform 5 16 env4052 = env4053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4052 == env4053) = true)

theorem identity4053 : scanCanonicalize (H12AffineFastState.compose env4053 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98307) := by decide +kernel

theorem selectedBound4053 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4054 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98307,444,41002,8329,445,323712,16385,16812,22560,74795,94338,256,20481,90155,512]

theorem envBound4054 : H12AffineFastState.Bounded env4054 := by
  intro p hp
  have h : env4054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4053_4054 : H12AffineEnvironment.transform 21 98307 env4053 = env4054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98307 env4053 == env4054) = true)

theorem identity4054 : scanCanonicalize (H12AffineFastState.compose env4054 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound4054 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4055 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1024,32768,4096,41348,444,41002,8329,445,323712,16385,16812,22560,1452,20741,256,20481,16812,512]

theorem envBound4055 : H12AffineFastState.Bounded env4055 := by
  intro p hp
  have h : env4055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4054_4055 : H12AffineEnvironment.transform 15 8583 env4054 = env4055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env4054 == env4055) = true)

theorem identity4055 : scanCanonicalize (H12AffineFastState.compose env4055 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4055 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4056 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13885,8583,4524,262144,1024,13885,4096,6073,444,5655,8329,445,280253,16385,16812,22560,1452,20741,256,20481,16812,512]

theorem envBound4056 : H12AffineFastState.Bounded env4056 := by
  intro p hp
  have h : env4056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4055_4056 : H12AffineEnvironment.transform 14 13885 env4055 = env4056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4055 == env4056) = true)

theorem identity4056 : scanCanonicalize (H12AffineFastState.compose env4056 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound4056 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4057 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8583,4524,262144,1024,13885,4096,6073,444,5655,8329,445,268217,4357,4264,2340,1452,1,256,261,4264,512]

theorem envBound4057 : H12AffineFastState.Bounded env4057 := by
  intro p hp
  have h : env4057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4056_4057 : H12AffineEnvironment.transform 13 4356 env4056 = env4057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env4056 == env4057) = true)

theorem identity4057 : scanCanonicalize (H12AffineFastState.compose env4057 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound4057 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4058 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8583,4524,2340,1024,13885,4096,6073,444,5655,8329,445,7837,4357,4264,2340,1452,1,256,261,4264,512]

theorem envBound4058 : H12AffineFastState.Bounded env4058 := by
  intro p hp
  have h : env4058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4057_4058 : H12AffineEnvironment.transform 17 2340 env4057 = env4058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env4057 == env4058) = true)

theorem identity4058 : scanCanonicalize (H12AffineFastState.compose env4058 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4058 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4059 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8322,4265,2081,1024,13885,4096,5820,185,5655,8329,184,7837,4096,4264,2081,1193,1,5,0,4264,512]

theorem envBound4059 : H12AffineFastState.Bounded env4059 := by
  intro p hp
  have h : env4059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4058_4059 : H12AffineEnvironment.transform 7 5 env4058 = env4059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4058 == env4059) = true)

theorem identity4059 : scanCanonicalize (H12AffineFastState.compose env4059 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4059 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4060 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1693,8192,1692,8352,8322,1588,2081,1024,8352,1693,33,185,138,8329,184,2048,1693,1589,2081,1193,1,5,0,1589,512]

theorem envBound4060 : H12AffineFastState.Bounded env4060 := by
  intro p hp
  have h : env4060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4059_4060 : H12AffineEnvironment.transform 11 1693 env4059 = env4060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4059 == env4060) = true)

theorem identity4060 : scanCanonicalize (H12AffineFastState.compose env4060 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound4060 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4061 : List Nat := [2,4,8,16,32,16,128,5,512,188,2048,545,8192,544,8352,8322,648,2081,188,8352,545,33,185,138,8329,184,2048,545,649,2081,21,1,5,0,649,512]

theorem envBound4061 : H12AffineFastState.Bounded env4061 := by
  intro p hp
  have h : env4061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4060_4061 : H12AffineEnvironment.transform 9 188 env4060 = env4061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env4060 == env4061) = true)

theorem identity4061 : scanCanonicalize (H12AffineFastState.compose env4061 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound4061 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4062 : List Nat := [2,4,8,16,32,16,50,5,512,14,2048,545,8192,544,8210,8240,570,2081,14,8210,545,33,11,56,8251,10,2048,545,571,2081,21,1,5,0,571,512]

theorem envBound4062 : H12AffineFastState.Bounded env4062 := by
  intro p hp
  have h : env4062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4061_4062 : H12AffineEnvironment.transform 6 50 env4061 = env4062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env4061 == env4062) = true)

theorem identity4062 : scanCanonicalize (H12AffineFastState.compose env4062 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4062 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4063 : List Nat := [2,4,8,11,32,11,41,5,512,14,2048,545,8192,544,8201,8235,545,2081,14,8201,545,33,11,35,8224,10,2048,545,544,2081,14,1,5,0,544,512]

theorem envBound4063 : H12AffineFastState.Bounded env4063 := by
  intro p hp
  have h : env4063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4062_4063 : H12AffineEnvironment.transform 3 11 env4062 = env4063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4062 == env4063) = true)

theorem identity4063 : scanCanonicalize (H12AffineFastState.compose env4063 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound4063 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4064 : List Nat := [2,4,8,11,32,11,41,5,512,14,522,545,8192,544,8201,8235,545,555,14,8201,545,33,11,35,8224,10,522,545,544,555,14,1,5,0,544,512]

theorem envBound4064 : H12AffineFastState.Bounded env4064 := by
  intro p hp
  have h : env4064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4063_4064 : H12AffineEnvironment.transform 10 522 env4063 = env4064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env4063 == env4064) = true)

theorem identity4064 : scanCanonicalize (H12AffineFastState.compose env4064 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 547) := by decide +kernel

theorem selectedBound4064 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4065 : List Nat := [2,4,8,11,32,11,41,5,512,14,522,545,547,544,554,520,545,555,14,554,545,33,11,35,515,10,522,545,544,555,14,1,5,0,544,512]

theorem envBound4065 : H12AffineFastState.Bounded env4065 := by
  intro p hp
  have h : env4065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4064_4065 : H12AffineEnvironment.transform 12 547 env4064 = env4065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 547 env4064 == env4065) = true)

theorem identity4065 : scanCanonicalize (H12AffineFastState.compose env4065 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4065 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4066 : List Nat := [2,4,8,11,10,11,3,5,512,14,522,523,521,522,512,520,523,513,14,512,523,11,11,9,515,10,522,523,522,513,14,1,5,0,522,512]

theorem envBound4066 : H12AffineFastState.Bounded env4066 := by
  intro p hp
  have h : env4066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4065_4066 : H12AffineEnvironment.transform 4 10 env4065 = env4066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4065 == env4066) = true)

theorem identity4066 : scanCanonicalize (H12AffineFastState.compose env4066 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4066 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4067 : List Nat := [2,4,2,1,0,1,3,5,512,4,512,513,515,512,512,514,513,513,4,512,513,1,1,3,515,0,512,513,512,513,4,1,5,0,512,512]

theorem envBound4067 : H12AffineFastState.Bounded env4067 := by
  intro p hp
  have h : env4067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4066_4067 : H12AffineEnvironment.transform 2 2 env4066 = env4067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4066 == env4067) = true)

theorem identity4067 : scanCanonicalize (H12AffineFastState.compose env4067 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4068 : List Nat := [2,4,2,1,0,1,3,5,0,4,0,1,3,0,0,2,1,1,4,0,1,1,1,3,3,0,0,1,0,1,4,1,5,0,0,0]

theorem envBound4068 : H12AffineFastState.Bounded env4068 := by
  intro p hp
  have h : env4068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4067_4068 : H12AffineEnvironment.transform 8 0 env4067 = env4068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4067 == env4068) = true)

def env4069 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,4293055,41002,8329,4293055,323713,16385,16813,22561,74795,94338,256,20480,4251688,4293122]

theorem envBound4069 : H12AffineFastState.Bounded env4069 := by
  intro p hp
  have h : env4069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4052_4069 : H12AffineEnvironment.transform 5 17 env4052 = env4069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4052 == env4069) = true)

def env4070 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4525,262144,1024,32768,4096,4194304,4293055,41002,8329,4293055,303145,4265,4357,2185,74795,73770,256,168,4239488,4293122]

theorem envBound4070 : H12AffineFastState.Bounded env4070 := by
  intro p hp
  have h : env4070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4069_4070 : H12AffineEnvironment.transform 13 4264 env4069 = env4070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env4069 == env4070) = true)

theorem identity4070 : scanCanonicalize (H12AffineFastState.compose env4070 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound4070 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4071 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8352,65536,4525,262144,1024,8352,4096,4194304,4268319,138,8329,4268319,262281,4265,4357,2185,74795,73770,256,168,4198432,4268706]

theorem envBound4071 : H12AffineFastState.Bounded env4071 := by
  intro p hp
  have h : env4071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4070_4071 : H12AffineEnvironment.transform 14 8352 env4070 = env4071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env4070 == env4071) = true)

theorem identity4071 : scanCanonicalize (H12AffineFastState.compose env4071 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 75938) := by decide +kernel

theorem selectedBound4071 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4072 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8352,65536,4525,75938,1024,8352,4096,4194304,4268319,138,8329,4268319,75819,4265,4357,2185,74795,73770,256,168,4198432,4268706]

theorem envBound4072 : H12AffineFastState.Bounded env4072 := by
  intro p hp
  have h : env4072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4071_4072 : H12AffineEnvironment.transform 17 75938 env4071 = env4072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75938 env4071 == env4072) = true)

theorem identity4072 : scanCanonicalize (H12AffineFastState.compose env4072 (packedSelected [1,5,6,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 8081) := by decide +kernel

theorem selectedBound4072 : packedSelected [1,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env4073 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,8352,8081,4525,14131,1024,8352,4096,4194304,4210318,138,8329,4210318,14266,4265,4357,2185,15290,16315,256,168,4198432,4209971]

theorem envBound4073 : H12AffineFastState.Bounded env4073 := by
  intro p hp
  have h : env4073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4072_4073 : H12AffineEnvironment.transform 15 8081 env4072 = env4073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8081 env4072 == env4073) = true)

theorem identity4073 : scanCanonicalize (H12AffineFastState.compose env4073 (packedSelected [2,11,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4073 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4074 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,4264,8352,8065,4525,14115,1024,8352,4096,4194304,4210318,138,8329,4210318,14250,4265,4357,2185,15274,16299,256,168,4198432,4209955]

theorem envBound4074 : H12AffineFastState.Bounded env4074 := by
  intro p hp
  have h : env4074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4073_4074 : H12AffineEnvironment.transform 3 0 env4073 = env4074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4073 == env4074) = true)

theorem identity4074 : scanCanonicalize (H12AffineFastState.compose env4074 (packedSelected [0,3,5,6,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 2950) := by decide +kernel

theorem selectedBound4074 : packedSelected [0,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env4075 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,4264,8352,8065,4525,14115,1024,8352,4096,2950,13576,138,8329,13576,14250,4265,4357,2185,15274,16299,256,168,7078,13989]

theorem envBound4075 : H12AffineFastState.Bounded env4075 := by
  intro p hp
  have h : env4075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4074_4075 : H12AffineEnvironment.transform 21 2950 env4074 = env4075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2950 env4074 == env4075) = true)

theorem identity4075 : scanCanonicalize (H12AffineFastState.compose env4075 (packedSelected [0,1,3,4,7,9,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4075 : packedSelected [0,1,3,4,7,9,21] rootPS < 2^1333 := by decide +kernel

def env4076 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,4096,8192,4264,8352,7812,4264,13862,1024,8352,4096,2691,13325,138,8329,13325,13999,4265,4096,2185,15023,16046,5,168,6819,13989]

theorem envBound4076 : H12AffineFastState.Bounded env4076 := by
  intro p hp
  have h : env4076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4075_4076 : H12AffineEnvironment.transform 7 5 env4075 = env4076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4075 == env4076) = true)

theorem identity4076 : scanCanonicalize (H12AffineFastState.compose env4076 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 4131) := by decide +kernel

theorem selectedBound4076 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4077 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,4096,4131,4264,4227,7812,4264,1541,1024,4227,4096,2691,1070,138,4266,1070,1676,4265,4096,2185,2700,3725,5,168,6819,1670]

theorem envBound4077 : H12AffineFastState.Bounded env4077 := by
  intro p hp
  have h : env4077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4076_4077 : H12AffineEnvironment.transform 12 4131 env4076 = env4077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4131 env4076 == env4077) = true)

theorem identity4077 : scanCanonicalize (H12AffineFastState.compose env4077 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4077 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4078 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1197,1166,1029,1070,2601,1029,1541,1024,1070,1197,2691,1070,138,1031,1070,1676,1028,1197,2185,2700,3725,5,168,3598,1670]

theorem envBound4078 : H12AffineFastState.Bounded env4078 := by
  intro p hp
  have h : env4078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4077_4078 : H12AffineEnvironment.transform 11 1197 env4077 = env4078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env4077 == env4078) = true)

theorem identity4078 : scanCanonicalize (H12AffineFastState.compose env4078 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound4078 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4079 : List Nat := [2,4,8,0,32,1,128,5,512,1024,42,1197,1166,1029,1070,515,1029,1541,1024,1070,1197,681,1070,138,1031,1070,1676,1028,1197,163,678,1703,5,168,1572,1670]

theorem envBound4079 : H12AffineFastState.Bounded env4079 := by
  intro p hp
  have h : env4079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4078_4079 : H12AffineEnvironment.transform 10 42 env4078 = env4079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env4078 == env4079) = true)

theorem identity4079 : scanCanonicalize (H12AffineFastState.compose env4079 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound4079 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env4080 : List Nat := [2,4,8,0,32,1,128,5,512,134,42,43,8,131,168,515,131,643,134,168,43,681,168,138,129,168,522,130,43,163,678,545,5,168,674,512]

theorem envBound4080 : H12AffineFastState.Bounded env4080 := by
  intro p hp
  have h : env4080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4079_4080 : H12AffineEnvironment.transform 9 134 env4079 = env4080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env4079 == env4080) = true)

theorem identity4080 : scanCanonicalize (H12AffineFastState.compose env4080 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4080 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4081 : List Nat := [2,4,3,0,32,1,128,5,512,134,33,32,3,131,163,515,131,643,134,163,32,674,163,129,129,163,513,130,32,163,678,545,5,163,674,512]

theorem envBound4081 : H12AffineFastState.Bounded env4081 := by
  intro p hp
  have h : env4081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4080_4081 : H12AffineEnvironment.transform 2 3 env4080 = env4081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4080 == env4081) = true)

theorem identity4081 : scanCanonicalize (H12AffineFastState.compose env4081 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4081 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env4082 : List Nat := [2,4,3,0,32,1,128,5,32,134,33,32,3,131,163,35,131,163,134,163,32,130,163,129,129,163,33,130,32,163,134,1,5,163,130,32]

theorem envBound4082 : H12AffineFastState.Bounded env4082 := by
  intro p hp
  have h : env4082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4081_4082 : H12AffineEnvironment.transform 8 32 env4081 = env4082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4081 == env4082) = true)

theorem identity4082 : scanCanonicalize (H12AffineFastState.compose env4082 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4083 : List Nat := [2,4,3,0,1,1,128,5,1,134,0,1,3,131,130,2,131,130,134,130,1,130,130,129,129,130,0,130,1,130,134,1,5,130,130,1]

theorem envBound4083 : H12AffineFastState.Bounded env4083 := by
  intro p hp
  have h : env4083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4082_4083 : H12AffineEnvironment.transform 4 1 env4082 = env4083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4082 == env4083) = true)

theorem identity4083 : scanCanonicalize (H12AffineFastState.compose env4083 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4084 : List Nat := [2,4,3,0,1,1,3,5,1,5,0,1,3,0,1,2,0,1,5,1,1,1,1,2,2,1,0,1,1,1,5,1,5,1,1,1]

theorem envBound4084 : H12AffineFastState.Bounded env4084 := by
  intro p hp
  have h : env4084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4083_4084 : H12AffineEnvironment.transform 6 3 env4083 = env4084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4083 == env4084) = true)

def env4085 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,4194304,4293055,41002,8329,4293055,303144,4264,4356,2184,74795,73771,256,169,4239489,4293122]

theorem envBound4085 : H12AffineFastState.Bounded env4085 := by
  intro p hp
  have h : env4085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4069_4085 : H12AffineEnvironment.transform 13 4265 env4069 = env4085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env4069 == env4085) = true)

theorem identity4085 : scanCanonicalize (H12AffineFastState.compose env4085 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound4085 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env4086 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33167,4525,262144,1024,32768,4096,4194304,4194352,41002,8329,4194352,303144,4264,4356,2184,42404,41380,256,169,4239489,4195213]

theorem envBound4086 : H12AffineFastState.Bounded env4086 := by
  intro p hp
  have h : env4086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4085_4086 : H12AffineEnvironment.transform 15 33167 env4085 = env4086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env4085 == env4086) = true)

theorem identity4086 : scanCanonicalize (H12AffineFastState.compose env4086 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1923) := by decide +kernel

theorem selectedBound4086 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env4087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33167,4525,1923,1024,32768,4096,4194304,4194352,41002,8329,4194352,42923,4264,4356,2184,42404,41380,256,169,4239489,4195213]

theorem envBound4087 : H12AffineFastState.Bounded env4087 := by
  intro p hp
  have h : env4087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4086_4087 : H12AffineEnvironment.transform 17 1923 env4086 = env4087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1923 env4086 == env4087) = true)

def env4088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33167,4525,1923,1024,32768,4096,41088,41136,41002,8329,41136,42923,4264,4356,2184,42404,41380,256,169,4097,41741]

theorem envBound4088 : H12AffineFastState.Bounded env4088 := by
  intro p hp
  have h : env4088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4087_4088 : H12AffineEnvironment.transform 21 41088 env4087 = env4088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4087 == env4088) = true)

theorem identity4088 : scanCanonicalize (H12AffineFastState.compose env4088 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4088 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1551,4096,8192,4265,32768,33167,4525,1923,1024,32768,4096,41088,41136,41002,8329,41136,42923,4264,4356,1671,42404,41380,256,169,4097,41741]

theorem envBound4089 : H12AffineFastState.Bounded env4089 := by
  intro p hp
  have h : env4089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4088_4089 : H12AffineEnvironment.transform 10 1551 env4088 = env4089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4088 == env4089) = true)

theorem identity4089 : scanCanonicalize (H12AffineFastState.compose env4089 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4089 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env4090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1551,4096,8192,4265,13973,14106,4525,1923,1024,13973,4096,5653,5669,5823,8329,5669,4414,4264,4356,1671,4913,5937,256,169,4097,5528]

theorem envBound4090 : H12AffineFastState.Bounded env4090 := by
  intro p hp
  have h : env4090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4089_4090 : H12AffineEnvironment.transform 14 13973 env4089 = env4090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4089 == env4090) = true)

theorem identity4090 : scanCanonicalize (H12AffineFastState.compose env4090 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4090 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env4091 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1551,4096,8192,4265,13973,13854,4265,1671,1024,13973,4096,5653,5669,5823,8329,5669,4154,4264,4096,1671,4661,5685,4,169,4097,5276]

theorem envBound4091 : H12AffineFastState.Bounded env4091 := by
  intro p hp
  have h : env4091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4090_4091 : H12AffineEnvironment.transform 7 4 env4090 = env4091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4090 == env4091) = true)

theorem identity4091 : scanCanonicalize (H12AffineFastState.compose env4091 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4091 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4092 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1551,1589,8192,1692,8352,8235,1692,1671,1024,8352,1589,32,16,138,8329,16,1551,1693,1589,1671,1024,0,4,169,1588,681]

theorem envBound4092 : H12AffineFastState.Bounded env4092 := by
  intro p hp
  have h : env4092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4091_4092 : H12AffineEnvironment.transform 11 1589 env4091 = env4092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4091 == env4092) = true)

theorem identity4092 : scanCanonicalize (H12AffineFastState.compose env4092 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound4092 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4093 : List Nat := [2,4,8,16,32,17,19,4,512,1024,1551,1589,8192,1551,8243,8235,1551,1556,1024,8243,1589,32,16,25,8218,16,1551,1550,1589,1556,1024,0,4,58,1588,570]

theorem envBound4093 : H12AffineFastState.Bounded env4093 := by
  intro p hp
  have h : env4093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4092_4093 : H12AffineEnvironment.transform 6 19 env4092 = env4093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env4092 == env4093) = true)

theorem identity4093 : scanCanonicalize (H12AffineFastState.compose env4093 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4093 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4094 : List Nat := [2,4,8,16,32,17,19,4,512,1024,1551,1589,1031,1551,1076,1068,1551,1556,1024,1076,1589,32,16,25,1053,16,1551,1550,1589,1556,1024,0,4,58,1588,570]

theorem envBound4094 : H12AffineFastState.Bounded env4094 := by
  intro p hp
  have h : env4094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4093_4094 : H12AffineEnvironment.transform 12 1031 env4093 = env4094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4093 == env4094) = true)

theorem identity4094 : scanCanonicalize (H12AffineFastState.compose env4094 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4094 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env4095 : List Nat := [2,4,8,16,26,17,19,4,512,1024,1551,1551,1031,1551,1038,1046,1551,1556,1024,1038,1551,26,16,25,1053,16,1551,1550,1551,1556,1024,0,4,0,1550,512]

theorem envBound4095 : H12AffineFastState.Bounded env4095 := by
  intro p hp
  have h : env4095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4094_4095 : H12AffineEnvironment.transform 4 26 env4094 = env4095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4094 == env4095) = true)

def env4096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,33167,4525,1923,1024,32768,4096,41089,41137,41002,8329,41137,42923,4264,4356,2184,42404,41380,256,169,4096,41740]

theorem envBound4096 : H12AffineFastState.Bounded env4096 := by
  intro p hp
  have h : env4096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4087_4096 : H12AffineEnvironment.transform 21 41089 env4087 = env4096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4087 == env4096) = true)

theorem identity4096 : scanCanonicalize (H12AffineFastState.compose env4096 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11951) := by decide +kernel

theorem selectedBound4096 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,11951,12064,4525,1923,1024,11951,4096,3630,3614,3717,8329,3614,2308,4264,4356,2184,2827,3851,256,169,4096,3491]

theorem envBound4097 : H12AffineFastState.Bounded env4097 := by
  intro p hp
  have h : env4097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4096_4097 : H12AffineEnvironment.transform 14 11951 env4096 = env4097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11951 env4096 == env4097) = true)

theorem identity4097 : scanCanonicalize (H12AffineFastState.compose env4097 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound4097 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env4098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1945,8192,1840,11951,12064,1588,1923,1024,11951,1945,3630,3614,3717,8329,3614,2308,1841,1693,2184,2827,3851,256,169,1945,3491]

theorem envBound4098 : H12AffineFastState.Bounded env4098 := by
  intro p hp
  have h : env4098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4097_4098 : H12AffineEnvironment.transform 11 1945 env4097 = env4098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env4097 == env4098) = true)

theorem identity4098 : scanCanonicalize (H12AffineFastState.compose env4098 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound4098 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env4099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1702,1945,8192,1840,8201,8582,1588,1923,1024,8201,1945,136,184,35,8329,184,1954,1841,1693,1582,1453,429,256,169,1945,773]

theorem envBound4099 : H12AffineFastState.Bounded env4099 := by
  intro p hp
  have h : env4099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4098_4099 : H12AffineEnvironment.transform 10 1702 env4098 = env4099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env4098 == env4099) = true)

theorem identity4099 : scanCanonicalize (H12AffineFastState.compose env4099 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4099 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4100 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1551,1840,8192,1840,8201,8495,1588,1834,1024,8201,1840,33,17,35,8224,17,1803,1841,1588,1582,1284,260,256,0,1840,773]

theorem envBound4100 : H12AffineFastState.Bounded env4100 := by
  intro p hp
  have h : env4100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4099_4100 : H12AffineEnvironment.transform 6 41 env4099 = env4100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4099 == env4100) = true)

theorem identity4100 : scanCanonicalize (H12AffineFastState.compose env4100 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4101 : List Nat := [2,4,8,11,32,10,41,256,512,1024,1551,1835,8192,1835,8201,8495,1583,1834,1024,8201,1835,33,10,35,8224,10,1803,1834,1583,1582,1284,260,256,0,1835,773]

theorem envBound4101 : H12AffineFastState.Bounded env4101 := by
  intro p hp
  have h : env4101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4100_4101 : H12AffineEnvironment.transform 3 11 env4100 = env4101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4100 == env4101) = true)

theorem identity4101 : scanCanonicalize (H12AffineFastState.compose env4101 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound4101 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4102 : List Nat := [2,4,8,11,32,10,41,256,512,1024,1551,1835,1030,1835,1039,1321,1583,1834,1024,1039,1835,33,10,35,1062,10,1803,1834,1583,1582,1284,260,256,0,1835,773]

theorem envBound4102 : H12AffineFastState.Bounded env4102 := by
  intro p hp
  have h : env4102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4101_4102 : H12AffineEnvironment.transform 12 1030 env4101 = env4102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env4101 == env4102) = true)

theorem identity4102 : scanCanonicalize (H12AffineFastState.compose env4102 (packedSelected [2,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4102 : packedSelected [2,11,23] rootPS < 2^1333 := by decide +kernel

def env4103 : List Nat := [2,4,8,11,32,10,41,4,512,1024,1551,1583,1030,1583,1039,1069,1583,1582,1024,1039,1583,33,10,35,1062,10,1551,1582,1583,1582,1024,0,4,0,1583,513]

theorem envBound4103 : H12AffineFastState.Bounded env4103 := by
  intro p hp
  have h : env4103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4102_4103 : H12AffineEnvironment.transform 7 4 env4102 = env4103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4102 == env4103) = true)

theorem identity4103 : scanCanonicalize (H12AffineFastState.compose env4103 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound4103 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4104 : List Nat := [2,4,8,11,32,10,41,4,14,1024,1025,1057,1030,1057,1039,1069,1057,1056,1024,1039,1057,33,10,35,1062,10,1025,1056,1057,1056,1024,0,4,0,1057,15]

theorem envBound4104 : H12AffineFastState.Bounded env4104 := by
  intro p hp
  have h : env4104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4103_4104 : H12AffineEnvironment.transform 8 14 env4103 = env4104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env4103 == env4104) = true)

theorem identity4104 : scanCanonicalize (H12AffineFastState.compose env4104 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4104 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4105 : List Nat := [2,4,3,0,32,1,34,4,5,1024,1025,1057,1030,1057,1028,1062,1057,1056,1024,1028,1057,33,1,35,1062,1,1025,1056,1057,1056,1024,0,4,0,1057,4]

theorem envBound4105 : H12AffineFastState.Bounded env4105 := by
  intro p hp
  have h : env4105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4104_4105 : H12AffineEnvironment.transform 2 3 env4104 = env4105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4104 == env4105) = true)

theorem identity4105 : scanCanonicalize (H12AffineFastState.compose env4105 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4105 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env4106 : List Nat := [2,0,3,0,32,1,34,0,1,1024,1025,1057,1026,1057,1024,1058,1057,1056,1024,1024,1057,33,1,35,1058,1,1025,1056,1057,1056,1024,0,0,0,1057,0]

theorem envBound4106 : H12AffineFastState.Bounded env4106 := by
  intro p hp
  have h : env4106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4105_4106 : H12AffineEnvironment.transform 1 0 env4105 = env4106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4105 == env4106) = true)

theorem identity4106 : scanCanonicalize (H12AffineFastState.compose env4106 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4107 : List Nat := [2,0,3,0,32,1,34,0,1,32,33,1,34,1,32,2,1,0,32,32,1,33,1,35,2,1,33,0,1,0,32,0,0,0,1,0]

theorem envBound4107 : H12AffineFastState.Bounded env4107 := by
  intro p hp
  have h : env4107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4106_4107 : H12AffineEnvironment.transform 9 32 env4106 = env4107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4106 == env4107) = true)

def leafEnv4107 : List Nat := [2,0,3,0,32,1,34,0,1,32,33,1,34,1,32,2,1,0,32,32,1,33,1,35,32,2,1,1,33,0,1,0,32,0,0,0,0,34,1,0,1,1,0]

def active4107 : List Nat := [0,4]

def tree4107 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4107 : H12WitnessSearch.Good tree4107 := H12GlobalWitnessIndex.good

theorem leafIdentity4107 : H12AffineFastState.composeSystem env4107 rootObs = leafEnv4107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4107 rootObs == leafEnv4107) = true)

theorem terminalChecked4107 : H12PackedTerminal.terminalCheckFast leafEnv4107 active4107 tree4107 = true := by decide +kernel

def env4108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,12644669,257,20560,8479127,8389613]

theorem envBound4108 : H12AffineFastState.Bounded env4108 := by
  intro p hp
  have h : env4108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4050_4108 : H12AffineEnvironment.transform 18 1025 env4050 = env4108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4050 == env4108) = true)

theorem identity4108 : scanCanonicalize (H12AffineFastState.compose env4108 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115902) := by decide +kernel

theorem selectedBound4108 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,115902,8388608,41002,8329,8388688,323793,16385,16892,22641,74794,8467843,257,20560,8479127,8389613]

theorem envBound4109 : H12AffineFastState.Bounded env4109 := by
  intro p hp
  have h : env4109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4108_4109 : H12AffineEnvironment.transform 21 115902 env4108 = env4109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115902 env4108 == env4109) = true)

def env4110 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115902,8388608,41002,8329,8388608,323713,16385,16812,22561,74794,8467843,257,20480,8479127,8389565]

theorem envBound4110 : H12AffineFastState.Bounded env4110 := by
  intro p hp
  have h : env4110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4109_4110 : H12AffineEnvironment.transform 5 16 env4109 = env4110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4109 == env4110) = true)

def env4111 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115902,5544,41002,8329,5544,323713,16385,16812,22561,74794,73771,257,20480,95295,5653]

theorem envBound4111 : H12AffineFastState.Bounded env4111 := by
  intro p hp
  have h : env4111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4110_4111 : H12AffineEnvironment.transform 22 5544 env4110 = env4111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env4110 == env4111) = true)

theorem identity4111 : scanCanonicalize (H12AffineFastState.compose env4111 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4111 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env4112 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,115734,5376,41002,8225,5376,323625,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4112 : H12AffineFastState.Bounded env4112 := by
  intro p hp
  have h : env4112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4111_4112 : H12AffineEnvironment.transform 6 40 env4111 = env4112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4111 == env4112) = true)

theorem identity4112 : scanCanonicalize (H12AffineFastState.compose env4112 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4112 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4113 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8201,65536,4356,262144,1025,8201,4096,91167,5376,35,8225,5376,282656,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4113 : H12AffineFastState.Bounded env4113 := by
  intro p hp
  have h : env4113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4112_4113 : H12AffineEnvironment.transform 14 8201 env4112 = env4113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4112 == env4113) = true)

theorem identity4113 : scanCanonicalize (H12AffineFastState.compose env4113 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4113 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4114 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8201,65536,4356,2080,1025,8201,4096,91167,5376,35,8225,5376,22528,16385,16644,22561,74794,73771,257,20480,95295,5653]

theorem envBound4114 : H12AffineFastState.Bounded env4114 := by
  intro p hp
  have h : env4114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4113_4114 : H12AffineEnvironment.transform 17 2080 env4113 = env4114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4113 == env4114) = true)

theorem identity4114 : scanCanonicalize (H12AffineFastState.compose env4114 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound4114 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env4115 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8201,65536,4356,2080,1025,8201,4096,78910,5376,35,8225,5376,2081,4128,4389,2048,74794,73771,257,33,74782,5653]

theorem envBound4115 : H12AffineFastState.Bounded env4115 := by
  intro p hp
  have h : env4115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4114_4115 : H12AffineEnvironment.transform 13 4129 env4114 = env4115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env4114 == env4115) = true)

theorem identity4115 : scanCanonicalize (H12AffineFastState.compose env4115 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound4115 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env4116 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8201,2342,4356,2080,1025,8201,4096,15640,5376,35,8225,5376,2081,4128,4389,2048,11532,10509,257,33,11576,5653]

theorem envBound4116 : H12AffineFastState.Bounded env4116 := by
  intro p hp
  have h : env4116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4115_4116 : H12AffineEnvironment.transform 15 2342 env4115 = env4116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env4115 == env4116) = true)

theorem identity4116 : scanCanonicalize (H12AffineFastState.compose env4116 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound4116 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4117 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,4649,4129,4640,2342,4356,2080,1025,4640,4096,3889,5376,35,4616,5376,2081,4128,4389,2048,7973,6948,257,33,7953,5653]

theorem envBound4117 : H12AffineFastState.Bounded env4117 := by
  intro p hp
  have h : env4117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4116_4117 : H12AffineEnvironment.transform 12 4649 env4116 = env4117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env4116 == env4117) = true)

theorem identity4117 : scanCanonicalize (H12AffineFastState.compose env4117 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4117 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env4118 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,4649,4129,4640,2082,4096,2080,1025,4640,4096,3637,5124,35,4616,5124,2081,4128,4129,2048,7713,6688,5,33,7701,5653]

theorem envBound4118 : H12AffineFastState.Bounded env4118 := by
  intro p hp
  have h : env4118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4117_4118 : H12AffineEnvironment.transform 7 4 env4117 = env4118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4117 == env4118) = true)

theorem identity4118 : scanCanonicalize (H12AffineFastState.compose env4118 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4118 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4119 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1071,1542,1038,1551,2082,1071,2080,1025,1551,1071,3637,43,35,1575,43,2081,1039,1038,2048,2574,3599,5,33,2618,570]

theorem envBound4119 : H12AffineFastState.Bounded env4119 := by
  intro p hp
  have h : env4119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4118_4119 : H12AffineEnvironment.transform 11 1071 env4118 = env4119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env4118 == env4119) = true)

theorem identity4119 : scanCanonicalize (H12AffineFastState.compose env4119 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4119 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env4120 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1582,1071,1542,1038,1551,1548,1071,1550,1025,1551,1071,27,43,35,1575,43,1551,1039,1038,1582,1056,33,5,33,1044,570]

theorem envBound4120 : H12AffineFastState.Bounded env4120 := by
  intro p hp
  have h : env4120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4119_4120 : H12AffineEnvironment.transform 10 1582 env4119 = env4120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env4119 == env4120) = true)

def env4121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,115902,5545,41002,8329,5545,323713,16385,16812,22561,74794,73770,257,20480,95294,5652]

theorem envBound4121 : H12AffineFastState.Bounded env4121 := by
  intro p hp
  have h : env4121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4110_4121 : H12AffineEnvironment.transform 22 5545 env4110 = env4121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env4110 == env4121) = true)

theorem identity4121 : scanCanonicalize (H12AffineFastState.compose env4121 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound4121 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28680,65536,4524,262144,1025,28680,4096,79030,5545,20514,8329,5545,262281,16385,16812,22561,74794,73770,257,20480,95294,5652]

theorem envBound4122 : H12AffineFastState.Bounded env4122 := by
  intro p hp
  have h : env4122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4121_4122 : H12AffineEnvironment.transform 14 28680 env4121 = env4122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env4121 == env4122) = true)

theorem identity4122 : scanCanonicalize (H12AffineFastState.compose env4122 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound4122 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,25628,65536,1464,262144,1025,25628,1044,73890,445,17462,8329,445,262281,16385,16812,19509,74794,73770,257,17428,90154,512]

theorem envBound4123 : H12AffineFastState.Bounded env4123 := by
  intro p hp
  have h : env4123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4122_4123 : H12AffineEnvironment.transform 11 1044 env4122 = env4123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env4122 == env4123) = true)

theorem identity4123 : scanCanonicalize (H12AffineFastState.compose env4123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4124 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,16384,25628,65536,1044,262144,1025,25628,1044,73890,17,17462,8329,17,262281,16385,16384,19509,74794,73770,173,17428,90154,512]

theorem envBound4124 : H12AffineFastState.Bounded env4124 := by
  intro p hp
  have h : env4124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4123_4124 : H12AffineEnvironment.transform 7 172 env4123 = env4124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4123 == env4124) = true)

theorem identity4124 : scanCanonicalize (H12AffineFastState.compose env4124 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound4124 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4125 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,3222,10378,65536,1044,262144,1025,10378,1044,73890,17,2208,8329,17,262281,3223,3222,163,74794,73770,173,2178,76988,512]

theorem envBound4125 : H12AffineFastState.Bounded env4125 := by
  intro p hp
  have h : env4125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4124_4125 : H12AffineEnvironment.transform 13 3222 env4124 = env4125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env4124 == env4125) = true)

theorem identity4125 : scanCanonicalize (H12AffineFastState.compose env4125 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound4125 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4126 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1044,8192,3222,10378,65536,1044,26,1025,10378,1044,73890,17,2208,8329,17,147,3223,3222,163,74794,73770,173,2178,76988,512]

theorem envBound4126 : H12AffineFastState.Bounded env4126 := by
  intro p hp
  have h : env4126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4125_4126 : H12AffineEnvironment.transform 17 26 env4125 = env4126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env4125 == env4126) = true)

theorem identity4126 : scanCanonicalize (H12AffineFastState.compose env4126 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound4126 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4127 : List Nat := [2,4,8,16,32,16,128,172,137,1024,2048,1044,8192,3222,10378,65536,1044,26,1025,10378,1044,73890,17,2208,8329,17,147,3223,3222,163,74794,73770,173,2178,76988,137]

theorem envBound4127 : H12AffineFastState.Bounded env4127 := by
  intro p hp
  have h : env4127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4126_4127 : H12AffineEnvironment.transform 8 137 env4126 = env4127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env4126 == env4127) = true)

theorem identity4127 : scanCanonicalize (H12AffineFastState.compose env4127 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 10241) := by decide +kernel

theorem selectedBound4127 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4128 : List Nat := [2,4,8,16,32,16,128,172,137,1024,2048,1044,8192,3222,10378,10241,1044,26,1025,10378,1044,2211,17,2208,8329,17,147,3223,3222,163,3115,2091,173,2178,1213,137]

theorem envBound4128 : H12AffineFastState.Bounded env4128 := by
  intro p hp
  have h : env4128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4127_4128 : H12AffineEnvironment.transform 15 10241 env4127 = env4128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10241 env4127 == env4128) = true)

theorem identity4128 : scanCanonicalize (H12AffineFastState.compose env4128 (packedSelected [1,3,6,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4128 : packedSelected [1,3,6,12,15] rootPS < 2^1333 := by decide +kernel

def env4129 : List Nat := [2,4,8,0,32,0,128,172,137,1024,2048,1028,8192,3206,10378,10241,1028,10,1025,10378,1028,2211,1,2208,8329,1,131,3207,3206,163,3115,2091,173,2178,1197,137]

theorem envBound4129 : H12AffineFastState.Bounded env4129 := by
  intro p hp
  have h : env4129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4128_4129 : H12AffineEnvironment.transform 3 0 env4128 = env4129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4128 == env4129) = true)

theorem identity4129 : scanCanonicalize (H12AffineFastState.compose env4129 (packedSelected [1,4,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound4129 : packedSelected [1,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4130 : List Nat := [2,4,8,0,32,0,128,172,137,1024,2048,1028,161,3206,2091,2208,1028,10,1025,2091,1028,2211,1,2208,40,1,131,3207,3206,163,3115,2091,173,2178,1197,137]

theorem envBound4130 : H12AffineFastState.Bounded env4130 := by
  intro p hp
  have h : env4130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4129_4130 : H12AffineEnvironment.transform 12 161 env4129 = env4130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env4129 == env4130) = true)

theorem identity4130 : scanCanonicalize (H12AffineFastState.compose env4130 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound4130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4131 : List Nat := [2,4,8,0,32,0,128,172,137,1024,1028,1028,161,130,1071,1188,1028,10,1025,1071,1028,1191,1,1188,40,1,131,131,130,163,47,1071,173,1158,1197,137]

theorem envBound4131 : H12AffineFastState.Bounded env4131 := by
  intro p hp
  have h : env4131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4130_4131 : H12AffineEnvironment.transform 10 1028 env4130 = env4131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env4130 == env4131) = true)

theorem identity4131 : scanCanonicalize (H12AffineFastState.compose env4131 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound4131 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env4132 : List Nat := [2,4,8,0,32,0,34,14,43,1024,1028,1028,3,32,1071,1030,1028,10,1025,1071,1028,1029,1,1030,40,1,33,33,32,1,47,1071,15,1060,1039,43]

theorem envBound4132 : H12AffineFastState.Bounded env4132 := by
  intro p hp
  have h : env4132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4131_4132 : H12AffineEnvironment.transform 6 34 env4131 = env4132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env4131 == env4132) = true)

theorem identity4132 : scanCanonicalize (H12AffineFastState.compose env4132 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound4132 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env4133 : List Nat := [2,4,8,0,32,0,34,14,43,47,43,43,3,32,0,41,43,10,46,0,43,42,1,41,40,1,33,33,32,1,47,0,15,11,32,43]

theorem envBound4133 : H12AffineFastState.Bounded env4133 := by
  intro p hp
  have h : env4133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4132_4133 : H12AffineEnvironment.transform 9 47 env4132 = env4133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env4132 == env4133) = true)

theorem identity4133 : scanCanonicalize (H12AffineFastState.compose env4133 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4134 : List Nat := [2,4,8,0,11,0,9,14,0,4,0,0,3,11,0,2,0,10,5,0,0,1,1,2,3,1,10,10,11,1,4,0,15,11,11,0]

theorem envBound4134 : H12AffineFastState.Bounded env4134 := by
  intro p hp
  have h : env4134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4133_4134 : H12AffineEnvironment.transform 4 11 env4133 = env4134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4133 == env4134) = true)

theorem identity4134 : scanCanonicalize (H12AffineFastState.compose env4134 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4134 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4135 : List Nat := [2,4,2,0,1,0,3,4,0,4,0,0,3,1,0,2,0,0,5,0,0,1,1,2,3,1,0,0,1,1,4,0,5,1,1,0]

theorem envBound4135 : H12AffineFastState.Bounded env4135 := by
  intro p hp
  have h : env4135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4134_4135 : H12AffineEnvironment.transform 2 2 env4134 = env4135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4134 == env4135) = true)

def env4136 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115902,8388608,41002,8329,8388609,323712,16385,16813,22560,74794,8467843,257,20481,8479127,8389564]

theorem envBound4136 : H12AffineFastState.Bounded env4136 := by
  intro p hp
  have h : env4136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4109_4136 : H12AffineEnvironment.transform 5 17 env4109 = env4136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4109 == env4136) = true)

theorem identity4136 : scanCanonicalize (H12AffineFastState.compose env4136 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4136 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4137 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115902,444,41002,8329,445,323712,16385,16813,22560,74794,78911,257,20481,90155,512]

theorem envBound4137 : H12AffineFastState.Bounded env4137 := by
  intro p hp
  have h : env4137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4136_4137 : H12AffineEnvironment.transform 22 444 env4136 = env4137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4136 == env4137) = true)

theorem identity4137 : scanCanonicalize (H12AffineFastState.compose env4137 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound4137 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4138 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1025,32768,4096,41349,444,41002,8329,445,323712,16385,16813,22560,16657,20740,257,20481,1296,512]

theorem envBound4138 : H12AffineFastState.Bounded env4138 := by
  intro p hp
  have h : env4138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4137_4138 : H12AffineEnvironment.transform 15 25915 env4137 = env4138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env4137 == env4138) = true)

theorem identity4138 : scanCanonicalize (H12AffineFastState.compose env4138 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound4138 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4139 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29313,25915,4525,262144,1025,29313,4096,21252,444,21163,8329,445,262657,16385,16813,22560,16657,20740,257,20481,1296,512]

theorem envBound4139 : H12AffineFastState.Bounded env4139 := by
  intro p hp
  have h : env4139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4138_4139 : H12AffineEnvironment.transform 14 29313 env4138 = env4139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env4138 == env4139) = true)

theorem identity4139 : scanCanonicalize (H12AffineFastState.compose env4139 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound4139 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4140 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25915,1045,262144,1025,26425,1464,18108,444,18195,8329,445,262657,16385,16813,19864,16657,17596,257,17849,1296,512]

theorem envBound4140 : H12AffineFastState.Bounded env4140 := by
  intro p hp
  have h : env4140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4139_4140 : H12AffineEnvironment.transform 11 1464 env4139 = env4140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4139 == env4140) = true)

theorem identity4140 : scanCanonicalize (H12AffineFastState.compose env4140 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4140 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4141 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,16384,26425,25915,1045,262144,1025,26425,1296,17940,276,18195,8225,277,262657,16385,16645,19760,16657,17428,257,17681,1296,512]

theorem envBound4141 : H12AffineFastState.Bounded env4141 := by
  intro p hp
  have h : env4141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4140_4141 : H12AffineEnvironment.transform 6 40 env4140 = env4141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4140 == env4141) = true)

def env4142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849104,268435456,268435965,547952,598058,12644669,525568,545873,8479127,8914924]

theorem envBound4142 : H12AffineFastState.Bounded env4142 := by
  intro p hp
  have h : env4142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3923_4142 : H12AffineEnvironment.transform 20 4097 env3923 = env4142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env3923 == env4142) = true)

def env4143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849104,16384,16893,547952,598058,12644669,525568,545873,8479127,8914924]

theorem envBound4143 : H12AffineFastState.Bounded env4143 := by
  intro p hp
  have h : env4143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4142_4143 : H12AffineEnvironment.transform 27 16384 env4142 = env4143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4142 == env4143) = true)

def env4144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323792,16384,16893,22640,74794,12644669,256,20561,8479127,8389612]

theorem envBound4144 : H12AffineFastState.Bounded env4144 := by
  intro p hp
  have h : env4144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4143_4144 : H12AffineEnvironment.transform 18 1024 env4143 = env4144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4143 == env4144) = true)

theorem identity4144 : scanCanonicalize (H12AffineFastState.compose env4144 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91351) := by decide +kernel

theorem selectedBound4144 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,91351,41002,8329,91271,323792,16384,16893,22640,74794,4298218,256,20561,1344,91963]

theorem envBound4145 : H12AffineFastState.Bounded env4145 := by
  intro p hp
  have h : env4145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4144_4145 : H12AffineEnvironment.transform 22 91351 env4144 = env4145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91351 env4144 == env4145) = true)

def env4146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,91271,41002,8329,91271,323712,16384,16813,22560,74794,4298170,256,20481,1296,91963]

theorem envBound4146 : H12AffineFastState.Bounded env4146 := by
  intro p hp
  have h : env4146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4145_4146 : H12AffineEnvironment.transform 5 16 env4145 = env4146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4145 == env4146) = true)

def env4147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,41088,91271,41002,8329,91271,323712,16384,16813,22560,74794,79162,256,20481,1296,91963]

theorem envBound4147 : H12AffineFastState.Bounded env4147 := by
  intro p hp
  have h : env4147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4146_4147 : H12AffineEnvironment.transform 21 41088 env4146 = env4147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4146 == env4147) = true)

theorem identity4147 : scanCanonicalize (H12AffineFastState.compose env4147 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4147 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4148 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4097,41088,91271,41002,8329,91271,323712,16384,16552,22560,74794,78911,5,20481,1045,91710]

theorem envBound4148 : H12AffineFastState.Bounded env4148 := by
  intro p hp
  have h : env4148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4147_4148 : H12AffineEnvironment.transform 7 5 env4147 = env4148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4147 == env4148) = true)

def env4149 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4097,41000,91183,41002,8225,91183,323624,16384,16384,22560,74794,78911,5,20481,1045,91710]

theorem envBound4149 : H12AffineFastState.Bounded env4149 := by
  intro p hp
  have h : env4149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4148_4149 : H12AffineEnvironment.transform 6 40 env4148 = env4149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4148 == env4149) = true)

def env4150 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1024,32768,4097,41001,91182,41002,8224,91182,323625,16384,16385,22560,74794,78911,5,20481,1045,91710]

theorem envBound4150 : H12AffineFastState.Bounded env4150 := by
  intro p hp
  have h : env4150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4148_4150 : H12AffineEnvironment.transform 6 41 env4148 = env4150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4148 == env4150) = true)

theorem identity4150 : scanCanonicalize (H12AffineFastState.compose env4150 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound4150 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4151 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1044,262144,1024,32768,1045,41001,91182,41002,8224,91182,320573,16384,16385,19508,74794,73771,5,17429,1045,91710]

theorem envBound4151 : H12AffineFastState.Bounded env4151 := by
  intro p hp
  have h : env4151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4150_4151 : H12AffineEnvironment.transform 11 1044 env4150 = env4151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env4150 == env4151) = true)

theorem identity4151 : scanCanonicalize (H12AffineFastState.compose env4151 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 82999) := by decide +kernel

theorem selectedBound4151 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env4152 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,65536,1044,82999,1024,32768,1045,41001,91182,41002,8224,91182,106506,16384,16385,19508,74794,73771,5,17429,1045,91710]

theorem envBound4152 : H12AffineFastState.Bounded env4152 := by
  intro p hp
  have h : env4152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4151_4152 : H12AffineEnvironment.transform 17 82999 env4151 = env4152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82999 env4151 == env4152) = true)

theorem identity4152 : scanCanonicalize (H12AffineFastState.compose env4152 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound4152 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env4153 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,16384,32768,8203,1044,25660,1024,32768,1045,41001,17445,41002,8224,17445,32769,16384,16385,19508,1057,32,5,17429,1045,17973]

theorem envBound4153 : H12AffineFastState.Bounded env4153 := by
  intro p hp
  have h : env4153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4152_4153 : H12AffineEnvironment.transform 15 8203 env4152 = env4153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env4152 == env4153) = true)

theorem identity4153 : scanCanonicalize (H12AffineFastState.compose env4153 (packedSelected [0,2,3,5,6,7,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 8754) := by decide +kernel

theorem selectedBound4153 : packedSelected [0,2,3,5,6,7,12,13] rootPS < 2^1333 := by decide +kernel

def env4154 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,8754,32768,8203,1044,1550,1024,32768,1045,41001,9751,41002,8224,9751,32769,8754,8755,11782,1057,32,5,9767,1045,9223]

theorem envBound4154 : H12AffineFastState.Bounded env4154 := by
  intro p hp
  have h : env4154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4153_4154 : H12AffineEnvironment.transform 13 8754 env4153 = env4154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8754 env4153 == env4154) = true)

theorem identity4154 : scanCanonicalize (H12AffineFastState.compose env4154 (packedSelected [2,3,5,6,7,9,11,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 11815) := by decide +kernel

theorem selectedBound4154 : packedSelected [2,3,5,6,7,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env4155 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1044,8192,8754,11815,8203,1044,1550,1024,11815,1045,3598,9751,3597,8224,9751,11814,8754,8755,11782,1057,32,5,9767,1045,9223]

theorem envBound4155 : H12AffineFastState.Bounded env4155 := by
  intro p hp
  have h : env4155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4154_4155 : H12AffineEnvironment.transform 14 11815 env4154 = env4155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11815 env4154 == env4155) = true)

theorem identity4155 : scanCanonicalize (H12AffineFastState.compose env4155 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4155 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4156 : List Nat := [2,4,8,10,32,10,41,5,512,1024,2048,1038,8192,8744,11815,8203,1038,1550,1024,11815,1039,3598,9741,3597,8224,9741,11814,8744,8745,11782,1057,32,5,9767,1039,9223]

theorem envBound4156 : H12AffineFastState.Bounded env4156 := by
  intro p hp
  have h : env4156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4155_4156 : H12AffineEnvironment.transform 3 10 env4155 = env4156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4155 == env4156) = true)

theorem identity4156 : scanCanonicalize (H12AffineFastState.compose env4156 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound4156 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4157 : List Nat := [2,4,8,10,32,10,41,5,512,1024,2048,1038,2088,2560,1551,2083,1038,1550,1024,1551,1039,3598,3621,3597,2056,3621,1550,2560,2561,1582,1057,32,5,3599,1039,3119]

theorem envBound4157 : H12AffineFastState.Bounded env4157 := by
  intro p hp
  have h : env4157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4156_4157 : H12AffineEnvironment.transform 12 2088 env4156 = env4157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env4156 == env4157) = true)

theorem identity4157 : scanCanonicalize (H12AffineFastState.compose env4157 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4157 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env4158 : List Nat := [2,4,8,10,32,10,41,5,0,1024,2048,1038,2088,2048,1039,2083,1038,1038,1024,1039,1039,3086,3109,3085,2056,3109,1038,2048,2049,1070,1057,32,5,3087,1039,3119]

theorem envBound4158 : H12AffineFastState.Bounded env4158 := by
  intro p hp
  have h : env4158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4157_4158 : H12AffineEnvironment.transform 8 0 env4157 = env4158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4157 == env4158) = true)

theorem identity4158 : scanCanonicalize (H12AffineFastState.compose env4158 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4158 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4159 : List Nat := [2,4,8,10,32,10,41,5,0,1024,1071,1038,1031,1071,1039,1036,1038,1038,1024,1039,1039,33,10,34,1063,10,1038,1071,1070,1070,1057,32,5,32,1039,0]

theorem envBound4159 : H12AffineFastState.Bounded env4159 := by
  intro p hp
  have h : env4159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4158_4159 : H12AffineEnvironment.transform 10 1071 env4158 = env4159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env4158 == env4159) = true)

theorem identity4159 : scanCanonicalize (H12AffineFastState.compose env4159 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound4159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4160 : List Nat := [2,4,8,10,32,10,41,5,0,46,1,32,41,1,33,34,32,32,46,33,33,33,10,34,9,10,32,1,0,0,15,32,5,32,33,0]

theorem envBound4160 : H12AffineFastState.Bounded env4160 := by
  intro p hp
  have h : env4160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4159_4160 : H12AffineEnvironment.transform 9 46 env4159 = env4160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env4159 == env4160) = true)

theorem identity4160 : scanCanonicalize (H12AffineFastState.compose env4160 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4160 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4161 : List Nat := [2,4,8,10,1,10,8,5,0,15,1,1,8,1,0,3,1,1,15,0,0,0,10,3,9,10,1,1,0,0,15,1,5,1,0,0]

theorem envBound4161 : H12AffineFastState.Bounded env4161 := by
  intro p hp
  have h : env4161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4160_4161 : H12AffineEnvironment.transform 4 1 env4160 = env4161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4160 == env4161) = true)

def env4162 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,41089,91271,41002,8329,91271,323712,16384,16813,22560,74794,79163,256,20481,1296,91963]

theorem envBound4162 : H12AffineFastState.Bounded env4162 := by
  intro p hp
  have h : env4162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4146_4162 : H12AffineEnvironment.transform 21 41089 env4146 = env4162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4146 == env4162) = true)

theorem identity4162 : scanCanonicalize (H12AffineFastState.compose env4162 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound4162 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4163 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25663,4524,262144,1024,32768,4097,41089,184,41002,8329,184,323712,16384,16813,22560,16405,20740,256,20481,1296,772]

theorem envBound4163 : H12AffineFastState.Bounded env4163 := by
  intro p hp
  have h : env4163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4162_4163 : H12AffineEnvironment.transform 15 25663 env4162 = env4163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env4162 == env4163) = true)

def env4164 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,32768,25663,1212,262144,1024,32768,1297,41089,184,41002,8329,184,320912,16384,16813,19760,16405,17428,256,17681,1296,772]

theorem envBound4164 : H12AffineFastState.Bounded env4164 := by
  intro p hp
  have h : env4164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4163_4164 : H12AffineEnvironment.transform 11 1296 env4163 = env4164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env4163 == env4164) = true)

theorem identity4164 : scanCanonicalize (H12AffineFastState.compose env4164 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4164 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env4165 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,25663,1045,262144,1024,32768,1297,41000,17,41002,8224,17,320825,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4165 : H12AffineFastState.Bounded env4165 := by
  intro p hp
  have h : env4165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4164_4165 : H12AffineEnvironment.transform 6 41 env4164 = env4165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4164 == env4165) = true)

theorem identity4165 : scanCanonicalize (H12AffineFastState.compose env4165 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4165 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4166 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,32768,25663,1045,2081,1024,32768,1297,41000,17,41002,8224,17,60696,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4166 : H12AffineFastState.Bounded env4166 := by
  intro p hp
  have h : env4166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4165_4166 : H12AffineEnvironment.transform 17 2081 env4165 = env4166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4165 == env4166) = true)

theorem identity4166 : scanCanonicalize (H12AffineFastState.compose env4166 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 19729) := by decide +kernel

theorem selectedBound4166 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4167 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1296,8192,16384,19729,25663,1045,2081,1024,19729,1297,27961,17,27963,8224,17,8201,16384,16644,19760,16405,17428,256,17681,1296,772]

theorem envBound4167 : H12AffineFastState.Bounded env4167 := by
  intro p hp
  have h : env4167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4166_4167 : H12AffineEnvironment.transform 14 19729 env4166 = env4167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19729 env4166 == env4167) = true)

theorem identity4167 : scanCanonicalize (H12AffineFastState.compose env4167 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound4167 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4168 : List Nat := [2,4,8,16,32,16,41,256,319,1024,2048,1296,8192,16384,19729,25663,1045,2081,1024,19729,1297,27961,17,27963,8224,17,8201,16384,16644,19760,16405,17428,256,17681,1296,59]

theorem envBound4168 : H12AffineFastState.Bounded env4168 := by
  intro p hp
  have h : env4168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4167_4168 : H12AffineEnvironment.transform 8 319 env4167 = env4168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env4167 == env4168) = true)

theorem identity4168 : scanCanonicalize (H12AffineFastState.compose env4168 (packedSelected [0,1,4,5,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound4168 : packedSelected [0,1,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4169 : List Nat := [2,4,8,16,32,16,41,256,319,1024,2048,1296,8192,11545,8200,2342,1045,2081,1024,8200,1297,32,17,34,8224,17,8201,11545,11293,8233,11532,10509,256,10248,1296,59]

theorem envBound4169 : H12AffineFastState.Bounded env4169 := by
  intro p hp
  have h : env4169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4168_4169 : H12AffineEnvironment.transform 13 11545 env4168 = env4169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env4168 == env4169) = true)

theorem identity4169 : scanCanonicalize (H12AffineFastState.compose env4169 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound4169 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4170 : List Nat := [2,4,8,16,32,16,41,256,319,1024,2048,1296,1063,2366,1071,2342,1045,2081,1024,1071,1297,32,17,34,1031,17,1070,2366,2106,1038,2347,3370,256,3119,1296,59]

theorem envBound4170 : H12AffineFastState.Bounded env4170 := by
  intro p hp
  have h : env4170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4169_4170 : H12AffineEnvironment.transform 12 1063 env4169 = env4170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env4169 == env4170) = true)

theorem identity4170 : scanCanonicalize (H12AffineFastState.compose env4170 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound4170 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env4171 : List Nat := [2,4,8,16,32,16,41,256,319,1024,1039,1296,1063,1329,1071,1321,1045,1070,1024,1071,1297,32,17,34,1031,17,1070,1329,1077,1038,1316,293,256,32,1296,59]

theorem envBound4171 : H12AffineFastState.Bounded env4171 := by
  intro p hp
  have h : env4171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4170_4171 : H12AffineEnvironment.transform 10 1039 env4170 = env4171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env4170 == env4171) = true)

theorem identity4171 : scanCanonicalize (H12AffineFastState.compose env4171 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4172 : List Nat := [2,4,8,16,32,16,41,5,58,1024,1039,1045,1063,1076,1071,1068,1045,1070,1024,1071,1044,32,17,34,1031,17,1070,1076,1077,1038,1057,32,5,32,1045,59]

theorem envBound4172 : H12AffineFastState.Bounded env4172 := by
  intro p hp
  have h : env4172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4171_4172 : H12AffineEnvironment.transform 7 5 env4171 = env4172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4171 == env4172) = true)

theorem identity4172 : scanCanonicalize (H12AffineFastState.compose env4172 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 59) := by decide +kernel

theorem selectedBound4172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4173 : List Nat := [2,4,8,16,32,16,41,5,58,59,52,46,28,15,20,23,46,21,59,20,47,32,17,34,60,17,21,15,14,53,26,32,5,32,46,59]

theorem envBound4173 : H12AffineFastState.Bounded env4173 := by
  intro p hp
  have h : env4173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4172_4173 : H12AffineEnvironment.transform 9 59 env4172 = env4173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 59 env4172 == env4173) = true)

theorem identity4173 : scanCanonicalize (H12AffineFastState.compose env4173 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4173 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4174 : List Nat := [2,4,8,10,32,10,41,5,32,33,46,46,6,15,14,13,46,15,33,14,47,32,11,34,38,11,15,15,14,47,0,32,5,32,46,33]

theorem envBound4174 : H12AffineFastState.Bounded env4174 := by
  intro p hp
  have h : env4174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4173_4174 : H12AffineEnvironment.transform 3 10 env4173 = env4174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4173 == env4174) = true)

theorem identity4174 : scanCanonicalize (H12AffineFastState.compose env4174 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4175 : List Nat := [2,4,8,10,14,10,7,5,14,15,0,0,6,15,14,13,0,15,15,14,1,14,11,12,8,11,15,15,14,1,0,14,5,14,0,15]

theorem envBound4175 : H12AffineFastState.Bounded env4175 := by
  intro p hp
  have h : env4175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4174_4175 : H12AffineEnvironment.transform 4 14 env4174 = env4175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4174 == env4175) = true)

theorem identity4175 : scanCanonicalize (H12AffineFastState.compose env4175 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4175 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4176 : List Nat := [2,4,3,1,5,1,7,5,5,4,0,0,6,4,5,6,0,4,4,5,1,5,0,7,3,0,4,4,5,1,0,5,5,5,0,4]

theorem envBound4176 : H12AffineFastState.Bounded env4176 := by
  intro p hp
  have h : env4176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4175_4176 : H12AffineEnvironment.transform 2 3 env4175 = env4176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4175 == env4176) = true)

def leafEnv4176 : List Nat := [2,4,3,1,5,1,7,5,5,4,0,0,6,4,5,6,0,4,4,5,1,5,0,7,1,3,1,0,4,4,5,1,0,5,5,5,5,2,0,4,1,4,0]

def active4176 : List Nat := [0,1]

def tree4176 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4176 : H12WitnessSearch.Good tree4176 := H12GlobalWitnessIndex.good

theorem leafIdentity4176 : H12AffineFastState.composeSystem env4176 rootObs = leafEnv4176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4176 rootObs == leafEnv4176) = true)

theorem terminalChecked4176 : H12PackedTerminal.terminalCheckFast leafEnv4176 active4176 tree4176 = true := by decide +kernel

def env4177 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,32768,25663,1213,262144,1024,32768,1296,41089,184,41002,8329,184,320913,16384,16813,19761,16405,17429,256,17680,1296,772]

theorem envBound4177 : H12AffineFastState.Bounded env4177 := by
  intro p hp
  have h : env4177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4163_4177 : H12AffineEnvironment.transform 11 1297 env4163 = env4177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4163 == env4177) = true)

theorem identity4177 : scanCanonicalize (H12AffineFastState.compose env4177 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 25880) := by decide +kernel

theorem selectedBound4177 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4178 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,25880,25663,1213,262144,1024,25880,1296,17817,184,17714,8329,184,262281,16384,16813,19761,16405,17429,256,17680,1296,772]

theorem envBound4178 : H12AffineFastState.Bounded env4178 := by
  intro p hp
  have h : env4178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4177_4178 : H12AffineEnvironment.transform 14 25880 env4177 = env4178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25880 env4177 == env4178) = true)

theorem identity4178 : scanCanonicalize (H12AffineFastState.compose env4178 (packedSelected [0,1,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 11570) := by decide +kernel

theorem selectedBound4178 : packedSelected [0,1,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4179 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,11570,2090,2317,1213,262144,1024,2090,1296,10411,184,10240,8329,184,262281,11570,11423,8195,11559,10535,256,10274,1296,772]

theorem envBound4179 : H12AffineFastState.Bounded env4179 := by
  intro p hp
  have h : env4179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4178_4179 : H12AffineEnvironment.transform 13 11570 env4178 = env4179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11570 env4178 == env4179) = true)

theorem identity4179 : scanCanonicalize (H12AffineFastState.compose env4179 (packedSelected [0,1,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 8362) := by decide +kernel

theorem selectedBound4179 : packedSelected [0,1,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env4180 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,11570,2090,2317,1213,8362,1024,2090,1296,10411,184,10240,8329,184,8227,11570,11423,8195,11559,10535,256,10274,1296,772]

theorem envBound4180 : H12AffineFastState.Bounded env4180 := by
  intro p hp
  have h : env4180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4179_4180 : H12AffineEnvironment.transform 17 8362 env4179 = env4180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8362 env4179 == env4180) = true)

theorem identity4180 : scanCanonicalize (H12AffineFastState.compose env4180 (packedSelected [0,1,3,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4180 : packedSelected [0,1,3,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env4181 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,9,3387,2090,2317,1213,163,1024,2090,1296,2210,184,2057,128,184,42,3387,3222,10,3374,2350,256,2091,1296,772]

theorem envBound4181 : H12AffineFastState.Bounded env4181 := by
  intro p hp
  have h : env4181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4180_4181 : H12AffineEnvironment.transform 12 9 env4180 = env4181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4180 == env4181) = true)

theorem identity4181 : scanCanonicalize (H12AffineFastState.compose env4181 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound4181 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4182 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,3387,2090,2317,1213,163,1024,2090,1296,2210,184,2057,128,184,42,3387,3222,10,3374,2350,256,2091,1296,397]

theorem envBound4182 : H12AffineFastState.Bounded env4182 := by
  intro p hp
  have h : env4182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4181_4182 : H12AffineEnvironment.transform 8 137 env4181 = env4182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env4181 == env4182) = true)

theorem identity4182 : scanCanonicalize (H12AffineFastState.compose env4182 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound4182 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env4183 : List Nat := [2,4,8,16,32,16,128,256,137,1024,58,1297,9,1281,16,311,1213,163,1024,16,1296,152,184,51,128,184,42,1281,1196,10,1300,276,256,17,1296,397]

theorem envBound4183 : H12AffineFastState.Bounded env4183 := by
  intro p hp
  have h : env4183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4182_4183 : H12AffineEnvironment.transform 10 58 env4182 = env4183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env4182 == env4183) = true)

theorem identity4183 : scanCanonicalize (H12AffineFastState.compose env4183 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound4183 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env4184 : List Nat := [2,4,8,16,32,16,128,189,137,1024,58,1196,9,1212,16,138,1213,163,1024,16,1197,152,184,51,128,184,42,1212,1196,10,1193,169,189,17,1197,48]

theorem envBound4184 : H12AffineFastState.Bounded env4184 := by
  intro p hp
  have h : env4184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4183_4184 : H12AffineEnvironment.transform 7 189 env4183 = env4184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env4183 == env4184) = true)

theorem identity4184 : scanCanonicalize (H12AffineFastState.compose env4184 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound4184 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env4185 : List Nat := [2,4,8,16,32,16,50,15,59,1024,58,1054,9,1038,16,56,1039,17,1024,16,1055,42,10,51,50,10,42,1038,1054,10,1051,27,15,17,1055,48]

theorem envBound4185 : H12AffineFastState.Bounded env4185 := by
  intro p hp
  have h : env4185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4184_4185 : H12AffineEnvironment.transform 6 50 env4184 = env4185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env4184 == env4185) = true)

theorem identity4185 : scanCanonicalize (H12AffineFastState.compose env4185 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound4185 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4186 : List Nat := [2,4,8,16,32,16,50,15,59,36,58,58,9,42,16,56,43,17,36,16,59,42,10,51,50,10,42,42,58,10,63,27,15,17,59,48]

theorem envBound4186 : H12AffineFastState.Bounded env4186 := by
  intro p hp
  have h : env4186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4185_4186 : H12AffineEnvironment.transform 9 36 env4185 = env4186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env4185 == env4186) = true)

theorem identity4186 : scanCanonicalize (H12AffineFastState.compose env4186 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4186 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4187 : List Nat := [2,4,8,16,10,16,24,15,17,14,16,16,9,0,16,18,1,17,14,16,17,0,10,25,24,10,0,0,16,10,21,27,15,17,17,26]

theorem envBound4187 : H12AffineFastState.Bounded env4187 := by
  intro p hp
  have h : env4187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4186_4187 : H12AffineEnvironment.transform 4 10 env4186 = env4187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4186 == env4187) = true)

theorem identity4187 : scanCanonicalize (H12AffineFastState.compose env4187 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4187 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1