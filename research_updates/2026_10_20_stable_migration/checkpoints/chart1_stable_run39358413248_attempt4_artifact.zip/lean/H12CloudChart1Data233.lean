import H12CloudChart1Data232

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound59095 : H12AffineFastState.Bounded env59095 := by
  intro p hp
  have h : env59095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59086_59095 : H12AffineEnvironment.transform 22 65 env59086 = env59095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65 env59086 == env59095) = true)

theorem identity59095 : scanCanonicalize (H12AffineFastState.compose env59095 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound59095 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,43048,1024,32768,2097152,33,65,41351,8329,17,7405,4176,42464,7624,45284,5141,257,46360,42416,512]

theorem envBound59096 : H12AffineFastState.Bounded env59096 := by
  intro p hp
  have h : env59096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59095_59096 : H12AffineEnvironment.transform 17 43048 env59095 = env59096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env59095 == env59096) = true)

theorem identity59096 : scanCanonicalize (H12AffineFastState.compose env59096 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 4981) := by decide +kernel

theorem selectedBound59096 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42417,43048,1024,32768,4981,33,65,41351,8329,17,7405,4176,42464,7624,45284,5141,257,46360,42416,512]

theorem envBound59097 : H12AffineFastState.Bounded env59097 := by
  intro p hp
  have h : env59097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59096_59097 : H12AffineEnvironment.transform 20 4981 env59096 = env59097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4981 env59096 == env59097) = true)

theorem identity59097 : scanCanonicalize (H12AffineFastState.compose env59097 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound59097 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env59098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1213,32768,33167,42417,43048,1024,32768,1945,33,65,41351,8329,17,2049,1212,42464,2340,41992,249,257,41460,42416,512]

theorem envBound59098 : H12AffineFastState.Bounded env59098 := by
  intro p hp
  have h : env59098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59097_59098 : H12AffineEnvironment.transform 11 1260 env59097 = env59098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env59097 == env59098) = true)

theorem identity59098 : scanCanonicalize (H12AffineFastState.compose env59098 (packedSelected [1,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound59098 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env59099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,1260,8192,1213,32768,33167,42417,42786,1024,32768,1945,33,65,41351,8329,17,1803,1212,42464,1582,41992,249,257,41460,42416,512]

theorem envBound59099 : H12AffineFastState.Bounded env59099 := by
  intro p hp
  have h : env59099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59098_59099 : H12AffineEnvironment.transform 10 1802 env59098 = env59099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env59098 == env59099) = true)

theorem identity59099 : scanCanonicalize (H12AffineFastState.compose env59099 (packedSelected [3,5,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 9052) := by decide +kernel

theorem selectedBound59099 : packedSelected [3,5,11,15] rootPS < 2^1333 := by decide +kernel

def env59100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,1260,8192,1213,9052,8915,1773,1150,1024,9052,1945,33,65,731,8329,17,1803,1212,1724,1582,1876,249,257,680,1772,512]

theorem envBound59100 : H12AffineFastState.Bounded env59100 := by
  intro p hp
  have h : env59100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59099_59100 : H12AffineEnvironment.transform 14 9052 env59099 = env59100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9052 env59099 == env59100) = true)

theorem identity59100 : scanCanonicalize (H12AffineFastState.compose env59100 (packedSelected [0,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 1759) := by decide +kernel

theorem selectedBound59100 : packedSelected [0,5,11] rootPS < 2^1333 := by decide +kernel

def env59101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,1260,1759,1213,1411,1036,1773,1150,1024,1411,1945,33,65,731,1622,17,1803,1212,1724,1582,1876,249,257,680,1772,512]

theorem envBound59101 : H12AffineFastState.Bounded env59101 := by
  intro p hp
  have h : env59101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59100_59101 : H12AffineEnvironment.transform 12 1759 env59100 = env59101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1759 env59100 == env59101) = true)

theorem identity59101 : scanCanonicalize (H12AffineFastState.compose env59101 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound59101 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env59102 : List Nat := [2,4,8,16,32,64,128,256,80,1024,1370,1260,1167,1213,1411,1036,1213,1150,1024,1411,1481,33,65,139,1030,17,1371,1212,1260,1150,1284,249,257,248,1212,80]

theorem envBound59102 : H12AffineFastState.Bounded env59102 := by
  intro p hp
  have h : env59102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59101_59102 : H12AffineEnvironment.transform 8 80 env59101 = env59102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env59101 == env59102) = true)

theorem identity59102 : scanCanonicalize (H12AffineFastState.compose env59102 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound59102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59103 : List Nat := [2,4,8,16,32,64,128,256,80,63,357,211,176,130,444,51,130,65,63,444,502,33,65,139,57,17,356,131,211,65,315,249,257,248,131,80]

theorem envBound59103 : H12AffineFastState.Bounded env59103 := by
  intro p hp
  have h : env59103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59102_59103 : H12AffineEnvironment.transform 9 63 env59102 = env59103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env59102 == env59103) = true)

def env59104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131152,4315354,8463814,4294967296,256,4307611964,34359738368,33563273]

theorem envBound59104 : H12AffineFastState.Bounded env59104 := by
  intro p hp
  have h : env59104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59036_59104 : H12AffineEnvironment.transform 18 1025 env59036 = env59104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env59036 == env59104) = true)

def env59105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131152,4315354,8463814,4294967296,256,4307611964,131072,33563273]

theorem envBound59105 : H12AffineFastState.Bounded env59105 := by
  intro p hp
  have h : env59105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59104_59105 : H12AffineEnvironment.transform 34 131072 env59104 = env59105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env59104 == env59105) = true)

theorem identity59105 : scanCanonicalize (H12AffineFastState.compose env59105 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 149250195) := by decide +kernel

theorem selectedBound59105 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env59106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131152,4315354,8463814,149250195,256,136679855,131072,33563273]

theorem envBound59106 : H12AffineFastState.Bounded env59106 := by
  intro p hp
  have h : env59106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59105_59106 : H12AffineEnvironment.transform 31 149250195 env59105 = env59106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 149250195 env59105 == env59106) = true)

theorem identity59106 : scanCanonicalize (H12AffineFastState.compose env59106 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound59106 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env59107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,77954,4315354,8463814,149250195,256,136679855,78034,33563273]

theorem envBound59107 : H12AffineFastState.Bounded env59107 := by
  intro p hp
  have h : env59107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59106_59107 : H12AffineEnvironment.transform 16 78034 env59106 = env59107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env59106 == env59107) = true)

def env59108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4177,77954,4294794,8463814,149237955,256,136679855,78034,33563273]

theorem envBound59108 : H12AffineFastState.Bounded env59108 := by
  intro p hp
  have h : env59108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59107_59108 : H12AffineEnvironment.transform 13 4176 env59107 = env59108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env59107 == env59108) = true)

def env59109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,33554432,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,33563273]

theorem envBound59109 : H12AffineFastState.Bounded env59109 := by
  intro p hp
  have h : env59109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59108_59109 : H12AffineEnvironment.transform 14 2640 env59108 = env59109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2640 env59108 == env59109) = true)

def env59110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397000,8388689,134217728,4177,77954,4260570,8463814,149237955,256,136649727,78034,8389185]

theorem envBound59110 : H12AffineFastState.Bounded env59110 := by
  intro p hp
  have h : env59110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59109_59110 : H12AffineEnvironment.transform 24 8397000 env59109 = env59110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397000 env59109 == env59110) = true)

def env59111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397000,8388689,6561532,4177,77954,4260570,8463814,8465983,256,4261123,78034,8389185]

theorem envBound59111 : H12AffineFastState.Bounded env59111 := by
  intro p hp
  have h : env59111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59110_59111 : H12AffineEnvironment.transform 26 6561532 env59110 = env59111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env59110 == env59111) = true)

def env59112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399767,8397000,8388689,2366324,4177,77954,67410,8463814,8465983,256,65675,78034,8389185]

theorem envBound59112 : H12AffineFastState.Bounded env59112 := by
  intro p hp
  have h : env59112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59111_59112 : H12AffineEnvironment.transform 21 1416 env59111 = env59112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59111 == env59112) = true)

def env59113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3671,1288,9617,2366324,4177,77954,67410,65542,68607,256,65675,78034,10113]

theorem envBound59113 : H12AffineFastState.Bounded env59113 := by
  intro p hp
  have h : env59113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59112_59113 : H12AffineEnvironment.transform 22 9664 env59112 = env59113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59112 == env59113) = true)

def env59114 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1288,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59114 : H12AffineFastState.Bounded env59114 := by
  intro p hp
  have h : env59114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59113_59114 : H12AffineEnvironment.transform 8 0 env59113 = env59114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59113 == env59114) = true)

theorem identity59114 : scanCanonicalize (H12AffineFastState.compose env59114 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 77299) := by decide +kernel

theorem selectedBound59114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59115 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,77299,1416,9664,3159,1288,9617,341127,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59115 : H12AffineFastState.Bounded env59115 := by
  intro p hp
  have h : env59115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59114_59115 : H12AffineEnvironment.transform 20 77299 env59114 = env59115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77299 env59114 == env59115) = true)

def env59116 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,67699,1416,64,3159,1288,17,332039,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59116 : H12AffineFastState.Bounded env59116 := by
  intro p hp
  have h : env59116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59115_59116 : H12AffineEnvironment.transform 12 1408 env59115 = env59116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59115 == env59116) = true)

theorem identity59116 : scanCanonicalize (H12AffineFastState.compose env59116 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59116 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59117 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4494,1244,262144,1025,2128,6653,1416,64,3159,1288,17,262281,4177,1164,5340,4488,6257,256,4357,1244,1]

theorem envBound59117 : H12AffineFastState.Bounded env59117 := by
  intro p hp
  have h : env59117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59116_59117 : H12AffineEnvironment.transform 15 4494 env59116 = env59117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59116 == env59117) = true)

theorem identity59117 : scanCanonicalize (H12AffineFastState.compose env59117 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59117 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59118 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,4494,1244,262144,1025,1449,5124,1416,64,430,1288,17,262281,4177,1164,5340,4488,5512,256,4357,1244,1]

theorem envBound59118 : H12AffineFastState.Bounded env59118 := by
  intro p hp
  have h : env59118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59117_59118 : H12AffineEnvironment.transform 10 1529 env59117 = env59118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59117 == env59118) = true)

theorem identity59118 : scanCanonicalize (H12AffineFastState.compose env59118 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59118 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59119 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,4494,1244,5609,1025,1449,5124,1416,64,430,1288,17,5472,4177,1164,5340,4488,5512,256,4357,1244,1]

theorem envBound59119 : H12AffineFastState.Bounded env59119 := by
  intro p hp
  have h : env59119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59118_59119 : H12AffineEnvironment.transform 17 5609 env59118 = env59119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59118 == env59119) = true)

theorem identity59119 : scanCanonicalize (H12AffineFastState.compose env59119 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59119 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59120 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1449,1408,1529,1449,1063,1244,64,1025,1449,429,1416,64,430,1288,17,201,1528,1164,373,1057,33,256,1196,1244,1]

theorem envBound59120 : H12AffineFastState.Bounded env59120 := by
  intro p hp
  have h : env59120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59119_59120 : H12AffineEnvironment.transform 11 1449 env59119 = env59120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59119 == env59120) = true)

theorem identity59120 : scanCanonicalize (H12AffineFastState.compose env59120 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59120 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59121 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,372,349,292,372,250,1,64,220,372,429,341,64,430,469,17,201,293,81,373,252,33,256,113,1,1]

theorem envBound59121 : H12AffineFastState.Bounded env59121 := by
  intro p hp
  have h : env59121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59120_59121 : H12AffineEnvironment.transform 9 221 env59120 = env59121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59120 == env59121) = true)

theorem identity59121 : scanCanonicalize (H12AffineFastState.compose env59121 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59121 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59122 : List Nat := [2,4,8,16,32,16,128,256,0,141,292,292,269,292,292,170,1,16,140,292,429,261,16,430,389,17,153,293,1,293,172,33,256,33,1,1]

theorem envBound59122 : H12AffineFastState.Bounded env59122 := by
  intro p hp
  have h : env59122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59121_59122 : H12AffineEnvironment.transform 5 16 env59121 = env59122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59121 == env59122) = true)

theorem identity59122 : scanCanonicalize (H12AffineFastState.compose env59122 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59122 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59123 : List Nat := [0,4,8,16,32,16,128,256,0,141,292,292,269,292,292,168,1,16,140,292,429,261,16,428,389,17,153,293,1,293,172,33,256,33,1,1]

theorem envBound59123 : H12AffineFastState.Bounded env59123 := by
  intro p hp
  have h : env59123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59122_59123 : H12AffineEnvironment.transform 0 0 env59122 = env59123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59122 == env59123) = true)

theorem identity59123 : scanCanonicalize (H12AffineFastState.compose env59123 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound59123 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59124 : List Nat := [0,4,8,16,32,16,128,140,0,141,168,168,129,168,168,168,1,16,140,168,33,137,16,32,9,17,153,169,1,169,172,33,140,33,1,1]

theorem envBound59124 : H12AffineFastState.Bounded env59124 := by
  intro p hp
  have h : env59124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59123_59124 : H12AffineEnvironment.transform 7 140 env59123 = env59124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env59123 == env59124) = true)

theorem identity59124 : scanCanonicalize (H12AffineFastState.compose env59124 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound59124 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59125 : List Nat := [0,4,8,16,32,16,16,28,0,29,56,56,17,56,56,56,1,16,28,56,33,25,16,32,9,17,9,57,1,57,60,33,28,33,1,1]

theorem envBound59125 : H12AffineFastState.Bounded env59125 := by
  intro p hp
  have h : env59125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59124_59125 : H12AffineEnvironment.transform 6 16 env59124 = env59125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env59124 == env59125) = true)

theorem identity59125 : scanCanonicalize (H12AffineFastState.compose env59125 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59125 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env59126 : List Nat := [0,4,8,16,1,16,16,28,0,29,25,25,17,25,25,25,1,16,28,25,0,25,16,1,9,17,9,24,1,24,29,0,28,0,1,1]

theorem envBound59126 : H12AffineFastState.Bounded env59126 := by
  intro p hp
  have h : env59126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59125_59126 : H12AffineEnvironment.transform 4 1 env59125 = env59126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59125 == env59126) = true)

theorem identity59126 : scanCanonicalize (H12AffineFastState.compose env59126 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59127 : List Nat := [0,4,1,16,1,16,16,21,0,20,16,16,17,16,16,16,1,16,21,16,0,16,16,1,0,17,0,17,1,17,20,0,21,0,1,1]

theorem envBound59127 : H12AffineFastState.Bounded env59127 := by
  intro p hp
  have h : env59127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59126_59127 : H12AffineEnvironment.transform 2 1 env59126 = env59127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59126 == env59127) = true)

theorem identity59127 : scanCanonicalize (H12AffineFastState.compose env59127 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59127 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59128 : List Nat := [0,4,1,0,1,0,0,5,0,4,0,0,1,0,0,0,1,0,5,0,0,0,0,1,0,1,0,1,1,1,4,0,5,0,1,1]

theorem envBound59128 : H12AffineFastState.Bounded env59128 := by
  intro p hp
  have h : env59128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59127_59128 : H12AffineEnvironment.transform 3 0 env59127 = env59128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59127 == env59128) = true)

def env59129 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,67698,1416,65,3159,1288,16,332038,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59129 : H12AffineFastState.Bounded env59129 := by
  intro p hp
  have h : env59129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59115_59129 : H12AffineEnvironment.transform 12 1409 env59115 = env59129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59115 == env59129) = true)

theorem identity59129 : scanCanonicalize (H12AffineFastState.compose env59129 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59129 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59130 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,67698,1416,65,3159,1288,16,328078,217,66955,66898,65542,68095,256,65675,67035,0]

theorem envBound59130 : H12AffineFastState.Bounded env59130 := by
  intro p hp
  have h : env59130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59129_59130 : H12AffineEnvironment.transform 11 136 env59129 = env59130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59129 == env59130) = true)

theorem identity59130 : scanCanonicalize (H12AffineFastState.compose env59130 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59130 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59131 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,65536,67035,65982,1025,2128,67698,1416,65,3159,1288,16,48,217,66955,66898,65542,68095,256,65675,67035,0]

theorem envBound59131 : H12AffineFastState.Bounded env59131 := by
  intro p hp
  have h : env59131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59130_59131 : H12AffineEnvironment.transform 17 65982 env59130 = env59131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59130 == env59131) = true)

theorem identity59131 : scanCanonicalize (H12AffineFastState.compose env59131 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound59131 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59132 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2128,1094,413,1528,1025,2128,3124,1416,65,3159,1288,16,48,217,461,276,1088,3513,256,1229,413,0]

theorem envBound59132 : H12AffineFastState.Bounded env59132 := by
  intro p hp
  have h : env59132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59131_59132 : H12AffineEnvironment.transform 15 1094 env59131 = env59132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env59131 == env59132) = true)

theorem identity59132 : scanCanonicalize (H12AffineFastState.compose env59132 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59132 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59133 : List Nat := [2,4,8,16,32,64,128,256,0,1024,373,136,1409,216,293,1094,413,1528,1025,293,1345,1416,65,1314,1288,16,48,217,461,276,1088,1228,256,1229,413,0]

theorem envBound59133 : H12AffineFastState.Bounded env59133 := by
  intro p hp
  have h : env59133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59132_59133 : H12AffineEnvironment.transform 10 373 env59132 = env59133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59132 == env59133) = true)

theorem identity59133 : scanCanonicalize (H12AffineFastState.compose env59133 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59133 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59134 : List Nat := [2,4,8,16,32,64,128,69,0,1024,48,136,1220,216,96,1094,216,1213,1025,96,1028,1229,65,1127,1101,16,48,217,136,81,1088,1228,69,1229,216,0]

theorem envBound59134 : H12AffineFastState.Bounded env59134 := by
  intro p hp
  have h : env59134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59133_59134 : H12AffineEnvironment.transform 7 69 env59133 = env59134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59133 == env59134) = true)

theorem identity59134 : scanCanonicalize (H12AffineFastState.compose env59134 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59134 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59135 : List Nat := [2,4,8,16,32,64,128,69,0,236,48,136,40,216,96,170,216,81,237,96,232,33,65,139,161,16,48,217,136,81,172,32,69,33,216,0]

theorem envBound59135 : H12AffineFastState.Bounded env59135 := by
  intro p hp
  have h : env59135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59134_59135 : H12AffineEnvironment.transform 9 236 env59134 = env59135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59134 == env59135) = true)

theorem identity59135 : scanCanonicalize (H12AffineFastState.compose env59135 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59135 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59136 : List Nat := [2,4,8,16,32,64,9,69,0,101,48,1,40,81,96,35,81,81,100,96,97,33,65,2,40,16,48,80,1,81,37,32,69,33,81,0]

theorem envBound59136 : H12AffineFastState.Bounded env59136 := by
  intro p hp
  have h : env59136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59135_59136 : H12AffineEnvironment.transform 6 9 env59135 = env59136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59135 == env59136) = true)

theorem identity59136 : scanCanonicalize (H12AffineFastState.compose env59136 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59136 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59137 : List Nat := [2,4,8,16,32,11,9,14,0,46,48,1,40,26,43,35,26,26,47,43,42,33,10,2,40,16,48,27,1,26,37,32,14,33,26,0]

theorem envBound59137 : H12AffineFastState.Bounded env59137 := by
  intro p hp
  have h : env59137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59136_59137 : H12AffineEnvironment.transform 5 11 env59136 = env59137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59136 == env59137) = true)

theorem identity59137 : scanCanonicalize (H12AffineFastState.compose env59137 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59137 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59138 : List Nat := [2,4,8,16,17,11,9,14,0,31,1,1,25,26,26,18,26,26,30,26,27,16,10,2,25,16,1,27,1,26,20,17,14,16,26,0]

theorem envBound59138 : H12AffineFastState.Bounded env59138 := by
  intro p hp
  have h : env59138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59137_59138 : H12AffineEnvironment.transform 4 17 env59137 = env59138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59137 == env59138) = true)

def env59139 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1288,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59139 : H12AffineFastState.Bounded env59139 := by
  intro p hp
  have h : env59139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59113_59139 : H12AffineEnvironment.transform 8 1 env59113 = env59139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59113 == env59139) = true)

theorem identity59139 : scanCanonicalize (H12AffineFastState.compose env59139 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 67698) := by decide +kernel

theorem selectedBound59139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59140 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,67698,1416,9664,3158,1288,9617,332039,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59140 : H12AffineFastState.Bounded env59140 := by
  intro p hp
  have h : env59140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59139_59140 : H12AffineEnvironment.transform 20 67698 env59139 = env59140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67698 env59139 == env59140) = true)

def env59141 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,67698,1416,64,3158,1288,17,332039,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59141 : H12AffineFastState.Bounded env59141 := by
  intro p hp
  have h : env59141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59140_59141 : H12AffineEnvironment.transform 12 1408 env59140 = env59141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59140 == env59141) = true)

theorem identity59141 : scanCanonicalize (H12AffineFastState.compose env59141 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound59141 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59142 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4494,1244,262144,1025,2129,6652,1416,64,3158,1288,17,262281,4177,1164,5341,4488,6256,256,4357,1244,0]

theorem envBound59142 : H12AffineFastState.Bounded env59142 := by
  intro p hp
  have h : env59142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59141_59142 : H12AffineEnvironment.transform 15 4494 env59141 = env59142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env59141 == env59142) = true)

theorem identity59142 : scanCanonicalize (H12AffineFastState.compose env59142 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59142 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59143 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,4494,1244,262144,1025,1449,5124,1416,64,430,1288,17,262281,4177,1164,5341,4488,5512,256,4357,1244,0]

theorem envBound59143 : H12AffineFastState.Bounded env59143 := by
  intro p hp
  have h : env59143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59142_59143 : H12AffineEnvironment.transform 10 1528 env59142 = env59143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59142 == env59143) = true)

theorem identity59143 : scanCanonicalize (H12AffineFastState.compose env59143 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59143 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59144 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,4494,1244,5609,1025,1449,5124,1416,64,430,1288,17,5472,4177,1164,5341,4488,5512,256,4357,1244,0]

theorem envBound59144 : H12AffineFastState.Bounded env59144 := by
  intro p hp
  have h : env59144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59143_59144 : H12AffineEnvironment.transform 17 5609 env59143 = env59144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59143 == env59144) = true)

theorem identity59144 : scanCanonicalize (H12AffineFastState.compose env59144 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound59144 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59145 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1449,1408,1529,1449,1063,1244,64,1025,1449,429,1416,64,430,1288,17,201,1528,1164,372,1057,33,256,1196,1244,0]

theorem envBound59145 : H12AffineFastState.Bounded env59145 := by
  intro p hp
  have h : env59145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59144_59145 : H12AffineEnvironment.transform 11 1449 env59144 = env59145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env59144 == env59145) = true)

theorem identity59145 : scanCanonicalize (H12AffineFastState.compose env59145 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59145 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59146 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,373,348,293,373,251,0,64,221,373,429,340,64,430,468,17,201,292,80,372,253,33,256,112,0,0]

theorem envBound59146 : H12AffineFastState.Bounded env59146 := by
  intro p hp
  have h : env59146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59145_59146 : H12AffineEnvironment.transform 9 220 env59145 = env59146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59145 == env59146) = true)

theorem identity59146 : scanCanonicalize (H12AffineFastState.compose env59146 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59146 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59147 : List Nat := [2,4,8,16,32,64,128,173,1,220,137,216,241,136,216,251,0,64,221,216,0,249,64,3,121,17,201,137,80,217,253,33,173,112,0,0]

theorem envBound59147 : H12AffineFastState.Bounded env59147 := by
  intro p hp
  have h : env59147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59146_59147 : H12AffineEnvironment.transform 7 173 env59146 = env59147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59146 == env59147) = true)

theorem identity59147 : scanCanonicalize (H12AffineFastState.compose env59147 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59147 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59148 : List Nat := [2,4,8,16,32,64,105,68,1,53,96,49,24,97,49,18,0,64,52,49,0,16,64,3,121,17,32,96,80,48,20,33,68,112,0,0]

theorem envBound59148 : H12AffineFastState.Bounded env59148 := by
  intro p hp
  have h : env59148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59147_59148 : H12AffineEnvironment.transform 6 105 env59147 = env59148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59147 == env59148) = true)

theorem identity59148 : scanCanonicalize (H12AffineFastState.compose env59148 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound59148 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env59149 : List Nat := [2,4,8,16,26,64,83,68,1,15,90,11,24,91,11,18,0,64,14,11,0,16,64,3,67,17,26,90,80,10,20,27,68,74,0,0]

theorem envBound59149 : H12AffineFastState.Bounded env59149 := by
  intro p hp
  have h : env59149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59148_59149 : H12AffineEnvironment.transform 4 26 env59148 = env59149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env59148 == env59149) = true)

theorem identity59149 : scanCanonicalize (H12AffineFastState.compose env59149 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59150 : List Nat := [2,4,8,16,26,1,18,5,1,15,27,11,24,26,11,18,0,1,14,11,0,16,1,3,2,17,26,27,17,10,20,27,5,11,0,0]

theorem envBound59150 : H12AffineFastState.Bounded env59150 := by
  intro p hp
  have h : env59150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59149_59150 : H12AffineEnvironment.transform 5 1 env59149 = env59150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59149 == env59150) = true)

def env59151 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,67698,1416,65,3158,1288,16,332039,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59151 : H12AffineFastState.Bounded env59151 := by
  intro p hp
  have h : env59151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59140_59151 : H12AffineEnvironment.transform 12 1409 env59140 = env59151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59140 == env59151) = true)

theorem identity59151 : scanCanonicalize (H12AffineFastState.compose env59151 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59151 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59152 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2129,65536,67034,262144,1025,2129,67698,1416,65,3158,1288,16,328078,216,66954,66899,65542,68094,256,65675,67034,1]

theorem envBound59152 : H12AffineFastState.Bounded env59152 := by
  intro p hp
  have h : env59152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59151_59152 : H12AffineEnvironment.transform 11 137 env59151 = env59152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59151 == env59152) = true)

theorem identity59152 : scanCanonicalize (H12AffineFastState.compose env59152 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound59152 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59153 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2129,65536,67034,65983,1025,2129,67698,1416,65,3158,1288,16,49,216,66954,66899,65542,68094,256,65675,67034,1]

theorem envBound59153 : H12AffineFastState.Bounded env59153 := by
  intro p hp
  have h : env59153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59152_59153 : H12AffineEnvironment.transform 17 65983 env59152 = env59153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env59152 == env59153) = true)

theorem identity59153 : scanCanonicalize (H12AffineFastState.compose env59153 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound59153 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59154 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1409,217,2129,1094,412,1529,1025,2129,3124,1416,65,3158,1288,16,49,216,460,277,1088,3512,256,1229,412,1]

theorem envBound59154 : H12AffineFastState.Bounded env59154 := by
  intro p hp
  have h : env59154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59153_59154 : H12AffineEnvironment.transform 15 1094 env59153 = env59154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env59153 == env59154) = true)

theorem identity59154 : scanCanonicalize (H12AffineFastState.compose env59154 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59154 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59155 : List Nat := [2,4,8,16,32,64,128,256,1,424,2048,137,41,217,2129,494,412,81,425,2129,2460,32,65,2558,160,16,49,216,460,277,488,2064,256,357,412,1]

theorem envBound59155 : H12AffineFastState.Bounded env59155 := by
  intro p hp
  have h : env59155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59154_59155 : H12AffineEnvironment.transform 9 424 env59154 = env59155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59154 == env59155) = true)

theorem identity59155 : scanCanonicalize (H12AffineFastState.compose env59155 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59155 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59156 : List Nat := [2,4,8,16,32,64,128,256,1,424,49,137,41,217,96,494,412,81,425,96,429,32,65,463,160,16,49,216,460,277,488,33,256,357,412,1]

theorem envBound59156 : H12AffineFastState.Bounded env59156 := by
  intro p hp
  have h : env59156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59155_59156 : H12AffineEnvironment.transform 10 49 env59155 = env59156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59155 == env59156) = true)

theorem identity59156 : scanCanonicalize (H12AffineFastState.compose env59156 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59156 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59157 : List Nat := [2,4,8,16,32,64,115,256,1,347,49,122,41,42,96,285,367,81,346,96,350,32,65,316,83,16,49,43,319,277,283,33,256,357,367,1]

theorem envBound59157 : H12AffineFastState.Bounded env59157 := by
  intro p hp
  have h : env59157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59156_59157 : H12AffineEnvironment.transform 6 115 env59156 = env59157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59156 == env59157) = true)

theorem identity59157 : scanCanonicalize (H12AffineFastState.compose env59157 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59157 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59158 : List Nat := [2,4,8,16,32,64,115,69,1,30,49,122,41,42,96,88,42,81,31,96,27,32,65,121,83,16,49,43,122,80,94,33,69,32,42,1]

theorem envBound59158 : H12AffineFastState.Bounded env59158 := by
  intro p hp
  have h : env59158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59157_59158 : H12AffineEnvironment.transform 7 69 env59157 = env59158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59157 == env59158) = true)

def env59159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3670,1289,9616,2366324,4177,77954,67410,65543,68606,256,65675,78034,10112]

theorem envBound59159 : H12AffineFastState.Bounded env59159 := by
  intro p hp
  have h : env59159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59112_59159 : H12AffineEnvironment.transform 22 9665 env59112 = env59159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59112 == env59159) = true)

def env59160 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59160 : H12AffineFastState.Bounded env59160 := by
  intro p hp
  have h : env59160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59159_59160 : H12AffineEnvironment.transform 8 0 env59159 = env59160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59159 == env59160) = true)

theorem identity59160 : scanCanonicalize (H12AffineFastState.compose env59160 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59160 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59161 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,4130,8432,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365812,4177,8352,5488,4133,6620,256,4265,8432,9600]

theorem envBound59161 : H12AffineFastState.Bounded env59161 := by
  intro p hp
  have h : env59161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59160_59161 : H12AffineEnvironment.transform 15 4130 env59160 = env59161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59160 == env59161) = true)

def env59162 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4130,1392,262144,1025,2128,2097152,1416,65,3158,1289,16,2365812,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59162 : H12AffineFastState.Bounded env59162 := by
  intro p hp
  have h : env59162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59161_59162 : H12AffineEnvironment.transform 12 1408 env59161 = env59162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59161 == env59162) = true)

theorem identity59162 : scanCanonicalize (H12AffineFastState.compose env59162 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59162 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59163 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4130,1392,262144,1025,2128,2265,1416,65,3158,1289,16,266669,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59163 : H12AffineFastState.Bounded env59163 := by
  intro p hp
  have h : env59163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59162_59163 : H12AffineEnvironment.transform 20 2265 env59162 = env59163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59162 == env59163) = true)

theorem identity59163 : scanCanonicalize (H12AffineFastState.compose env59163 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59163 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59164 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,4130,1392,276,1025,2128,2265,1416,65,3158,1289,16,4281,4177,1312,5488,4133,6620,256,4265,1392,0]

theorem envBound59164 : H12AffineFastState.Bounded env59164 := by
  intro p hp
  have h : env59164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59163_59164 : H12AffineEnvironment.transform 17 276 env59163 = env59164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59163 == env59164) = true)

theorem identity59164 : scanCanonicalize (H12AffineFastState.compose env59164 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59164 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59165 : List Nat := [2,4,8,16,32,64,128,256,0,237,2048,4096,365,4176,2128,4130,413,276,236,2128,2265,357,65,2235,484,16,4281,4177,461,4509,4133,6620,256,4265,413,0]

theorem envBound59165 : H12AffineFastState.Bounded env59165 := by
  intro p hp
  have h : env59165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59164_59165 : H12AffineEnvironment.transform 9 237 env59164 = env59165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59164 == env59165) = true)

theorem identity59165 : scanCanonicalize (H12AffineFastState.compose env59165 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59165 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59166 : List Nat := [2,4,8,16,32,64,128,69,0,237,2048,4096,40,4176,2128,4130,216,81,236,2128,2265,32,65,2235,161,16,4281,4177,136,4312,4133,6297,69,4265,216,0]

theorem envBound59166 : H12AffineFastState.Bounded env59166 := by
  intro p hp
  have h : env59166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59165_59166 : H12AffineEnvironment.transform 7 69 env59165 = env59166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59165 == env59166) = true)

theorem identity59166 : scanCanonicalize (H12AffineFastState.compose env59166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound59166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59167 : List Nat := [2,4,8,16,32,64,128,69,0,237,2048,2233,40,2281,2128,2203,216,81,236,2128,2265,32,65,2235,161,16,2048,2280,136,2145,2204,32,69,2064,216,0]

theorem envBound59167 : H12AffineFastState.Bounded env59167 := by
  intro p hp
  have h : env59167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59166_59167 : H12AffineEnvironment.transform 11 2233 env59166 = env59167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env59166 == env59167) = true)

theorem identity59167 : scanCanonicalize (H12AffineFastState.compose env59167 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound59167 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59168 : List Nat := [2,4,8,16,32,64,128,69,0,237,195,122,40,42,147,88,216,81,236,147,26,32,65,120,161,16,195,43,136,162,95,32,69,211,216,0]

theorem envBound59168 : H12AffineFastState.Bounded env59168 := by
  intro p hp
  have h : env59168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59167_59168 : H12AffineEnvironment.transform 10 195 env59167 = env59168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env59167 == env59168) = true)

theorem identity59168 : scanCanonicalize (H12AffineFastState.compose env59168 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59168 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59169 : List Nat := [2,4,8,16,32,64,114,69,0,31,49,122,40,42,97,88,42,81,30,97,26,32,65,120,83,16,49,43,122,80,95,32,69,33,42,0]

theorem envBound59169 : H12AffineFastState.Bounded env59169 := by
  intro p hp
  have h : env59169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59168_59169 : H12AffineEnvironment.transform 6 114 env59168 = env59169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59168 == env59169) = true)

def env59170 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2097152,1416,64,3158,1289,17,2365812,4177,1313,5488,4133,6620,256,4265,1393,1]

theorem envBound59170 : H12AffineFastState.Bounded env59170 := by
  intro p hp
  have h : env59170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59161_59170 : H12AffineEnvironment.transform 12 1409 env59161 = env59170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59161 == env59170) = true)

theorem identity59170 : scanCanonicalize (H12AffineFastState.compose env59170 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59170 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59171 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,6653,1416,64,3158,1289,17,262281,4177,1313,5488,4133,6620,256,4265,1393,1]

theorem envBound59171 : H12AffineFastState.Bounded env59171 := by
  intro p hp
  have h : env59171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59170_59171 : H12AffineEnvironment.transform 20 6653 env59170 = env59171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59170 == env59171) = true)

theorem identity59171 : scanCanonicalize (H12AffineFastState.compose env59171 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59171 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59172 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,4130,1393,262144,1025,1449,5124,1416,64,431,1289,17,262281,4177,1313,5488,4133,5157,256,4265,1393,1]

theorem envBound59172 : H12AffineFastState.Bounded env59172 := by
  intro p hp
  have h : env59172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59171_59172 : H12AffineEnvironment.transform 10 1529 env59171 = env59172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59171 == env59172) = true)

theorem identity59172 : scanCanonicalize (H12AffineFastState.compose env59172 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59172 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59173 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,4130,1393,5609,1025,1449,5124,1416,64,431,1289,17,5472,4177,1313,5488,4133,5157,256,4265,1393,1]

theorem envBound59173 : H12AffineFastState.Bounded env59173 := by
  intro p hp
  have h : env59173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59172_59173 : H12AffineEnvironment.transform 17 5609 env59172 = env59173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59172 == env59173) = true)

theorem identity59173 : scanCanonicalize (H12AffineFastState.compose env59173 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59173 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59174 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1029,1409,1109,1449,1063,1393,492,1025,1449,1,1416,64,431,1289,17,357,1108,1313,373,1056,32,256,1196,1393,1]

theorem envBound59174 : H12AffineFastState.Bounded env59174 := by
  intro p hp
  have h : env59174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59173_59174 : H12AffineEnvironment.transform 11 1029 env59173 = env59174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59173 == env59174) = true)

theorem identity59174 : scanCanonicalize (H12AffineFastState.compose env59174 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59174 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59175 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,216,348,136,372,250,428,492,220,372,1,341,64,431,468,17,357,137,508,373,253,32,256,113,428,1]

theorem envBound59175 : H12AffineFastState.Bounded env59175 := by
  intro p hp
  have h : env59175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59174_59175 : H12AffineEnvironment.transform 9 221 env59174 = env59175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59174 == env59175) = true)

theorem identity59175 : scanCanonicalize (H12AffineFastState.compose env59175 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59175 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59176 : List Nat := [2,4,8,16,32,64,128,173,0,221,137,216,241,136,217,250,1,65,220,217,1,248,64,2,121,17,200,137,81,216,253,32,173,113,1,1]

theorem envBound59176 : H12AffineFastState.Bounded env59176 := by
  intro p hp
  have h : env59176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59175_59176 : H12AffineEnvironment.transform 7 173 env59175 = env59176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59175 == env59176) = true)

theorem identity59176 : scanCanonicalize (H12AffineFastState.compose env59176 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59176 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59177 : List Nat := [2,4,8,16,0,64,128,141,0,221,137,216,209,136,217,218,1,65,220,217,1,216,64,2,89,17,200,137,81,216,221,0,141,81,1,1]

theorem envBound59177 : H12AffineFastState.Bounded env59177 := by
  intro p hp
  have h : env59177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59176_59177 : H12AffineEnvironment.transform 4 0 env59176 = env59177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59176 == env59177) = true)

theorem identity59177 : scanCanonicalize (H12AffineFastState.compose env59177 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound59177 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59178 : List Nat := [2,4,8,16,0,64,19,30,0,78,26,75,66,27,74,73,1,65,79,74,1,75,64,2,89,17,91,26,81,75,78,0,30,81,1,1]

theorem envBound59178 : H12AffineFastState.Bounded env59178 := by
  intro p hp
  have h : env59178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59177_59178 : H12AffineEnvironment.transform 6 19 env59177 = env59178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env59177 == env59178) = true)

def env59179 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound59179 : H12AffineFastState.Bounded env59179 := by
  intro p hp
  have h : env59179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59159_59179 : H12AffineEnvironment.transform 8 1 env59159 = env59179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59159 == env59179) = true)

theorem identity59179 : scanCanonicalize (H12AffineFastState.compose env59179 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 13731) := by decide +kernel

theorem selectedBound59179 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59180 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,13731,1393,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365813,4177,1313,12528,13732,15452,256,13608,1393,9601]

theorem envBound59180 : H12AffineFastState.Bounded env59180 := by
  intro p hp
  have h : env59180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59179_59180 : H12AffineEnvironment.transform 15 13731 env59179 = env59180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13731 env59179 == env59180) = true)

def env59181 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4131,1393,262144,1025,2129,2097152,1416,65,3159,1289,16,2365813,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59181 : H12AffineFastState.Bounded env59181 := by
  intro p hp
  have h : env59181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59180_59181 : H12AffineEnvironment.transform 12 1408 env59180 = env59181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59180 == env59181) = true)

theorem identity59181 : scanCanonicalize (H12AffineFastState.compose env59181 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound59181 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59182 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4131,1393,262144,1025,2129,2265,1416,65,3159,1289,16,266668,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59182 : H12AffineFastState.Bounded env59182 := by
  intro p hp
  have h : env59182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59181_59182 : H12AffineEnvironment.transform 20 2265 env59181 = env59182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env59181 == env59182) = true)

theorem identity59182 : scanCanonicalize (H12AffineFastState.compose env59182 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59182 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59183 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,4131,1393,277,1025,2129,2265,1416,65,3159,1289,16,4281,4177,1313,5488,4132,6620,256,4264,1393,1]

theorem envBound59183 : H12AffineFastState.Bounded env59183 := by
  intro p hp
  have h : env59183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59182_59183 : H12AffineEnvironment.transform 17 277 env59182 = env59183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59182 == env59183) = true)

theorem identity59183 : scanCanonicalize (H12AffineFastState.compose env59183 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59183 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59184 : List Nat := [2,4,8,16,32,64,128,256,1,237,2048,4096,365,4176,2129,4131,412,277,236,2129,2265,357,65,2234,484,16,4281,4177,460,4509,4132,6620,256,4264,412,1]

theorem envBound59184 : H12AffineFastState.Bounded env59184 := by
  intro p hp
  have h : env59184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59183_59184 : H12AffineEnvironment.transform 9 237 env59183 = env59184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59183 == env59184) = true)

theorem identity59184 : scanCanonicalize (H12AffineFastState.compose env59184 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59184 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59185 : List Nat := [2,4,8,16,32,64,128,256,1,237,373,4096,365,4176,292,4131,412,277,236,292,428,357,65,463,484,16,4281,4177,460,4509,4132,4265,256,4264,412,1]

theorem envBound59185 : H12AffineFastState.Bounded env59185 := by
  intro p hp
  have h : env59185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59184_59185 : H12AffineEnvironment.transform 10 373 env59184 = env59185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59184 == env59185) = true)

theorem identity59185 : scanCanonicalize (H12AffineFastState.compose env59185 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59185 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59186 : List Nat := [2,4,8,16,32,64,128,256,1,237,373,460,365,412,292,495,412,277,236,292,428,357,65,463,484,16,373,413,460,81,488,357,256,356,412,1]

theorem envBound59186 : H12AffineFastState.Bounded env59186 := by
  intro p hp
  have h : env59186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59185_59186 : H12AffineEnvironment.transform 11 460 env59185 = env59186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59185 == env59186) = true)

theorem identity59186 : scanCanonicalize (H12AffineFastState.compose env59186 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59186 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59187 : List Nat := [2,4,8,16,32,64,128,68,1,237,49,136,41,216,96,171,216,81,236,96,232,33,65,139,160,16,49,217,136,81,172,33,68,32,216,1]

theorem envBound59187 : H12AffineFastState.Bounded env59187 := by
  intro p hp
  have h : env59187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59186_59187 : H12AffineEnvironment.transform 7 68 env59186 = env59187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59186 == env59187) = true)

theorem identity59187 : scanCanonicalize (H12AffineFastState.compose env59187 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59187 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59188 : List Nat := [2,4,8,16,32,64,9,68,1,100,49,1,41,81,96,34,81,81,101,96,97,33,65,2,41,16,49,80,1,81,37,33,68,32,81,1]

theorem envBound59188 : H12AffineFastState.Bounded env59188 := by
  intro p hp
  have h : env59188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59187_59188 : H12AffineEnvironment.transform 6 9 env59187 = env59188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59187 == env59188) = true)

theorem identity59188 : scanCanonicalize (H12AffineFastState.compose env59188 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59188 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59189 : List Nat := [2,4,8,16,32,10,9,14,1,46,49,1,41,27,42,34,27,27,47,42,43,33,11,2,41,16,49,26,1,27,37,33,14,32,27,1]

theorem envBound59189 : H12AffineFastState.Bounded env59189 := by
  intro p hp
  have h : env59189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59188_59189 : H12AffineEnvironment.transform 5 10 env59188 = env59189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59188 == env59189) = true)

theorem identity59189 : scanCanonicalize (H12AffineFastState.compose env59189 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59189 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59190 : List Nat := [2,4,8,16,16,10,9,14,1,30,1,1,25,27,26,18,27,27,31,26,27,17,11,2,25,16,1,26,1,27,21,17,14,16,27,1]

theorem envBound59190 : H12AffineFastState.Bounded env59190 := by
  intro p hp
  have h : env59190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59189_59190 : H12AffineEnvironment.transform 4 16 env59189 = env59190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59189 == env59190) = true)

def env59191 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2097152,1416,64,3159,1289,17,2365813,4177,1313,5489,4133,6621,256,4265,1393,0]

theorem envBound59191 : H12AffineFastState.Bounded env59191 := by
  intro p hp
  have h : env59191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59180_59191 : H12AffineEnvironment.transform 12 1409 env59180 = env59191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59180 == env59191) = true)

theorem identity59191 : scanCanonicalize (H12AffineFastState.compose env59191 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59191 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59192 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,6652,1416,64,3159,1289,17,262281,4177,1313,5489,4133,6621,256,4265,1393,0]

theorem envBound59192 : H12AffineFastState.Bounded env59192 := by
  intro p hp
  have h : env59192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59191_59192 : H12AffineEnvironment.transform 20 6652 env59191 = env59192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59191 == env59192) = true)

theorem identity59192 : scanCanonicalize (H12AffineFastState.compose env59192 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59192 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59193 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,4130,1393,262144,1025,1449,5124,1416,64,431,1289,17,262281,4177,1313,5489,4133,5157,256,4265,1393,0]

theorem envBound59193 : H12AffineFastState.Bounded env59193 := by
  intro p hp
  have h : env59193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59192_59193 : H12AffineEnvironment.transform 10 1528 env59192 = env59193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59192 == env59193) = true)

theorem identity59193 : scanCanonicalize (H12AffineFastState.compose env59193 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59193 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59194 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,4130,1393,5609,1025,1449,5124,1416,64,431,1289,17,5472,4177,1313,5489,4133,5157,256,4265,1393,0]

theorem envBound59194 : H12AffineFastState.Bounded env59194 := by
  intro p hp
  have h : env59194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59193_59194 : H12AffineEnvironment.transform 17 5609 env59193 = env59194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59193 == env59194) = true)

theorem identity59194 : scanCanonicalize (H12AffineFastState.compose env59194 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59194 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59195 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1029,1409,1109,1449,1063,1393,492,1025,1449,1,1416,64,431,1289,17,357,1108,1313,372,1056,32,256,1196,1393,0]

theorem envBound59195 : H12AffineFastState.Bounded env59195 := by
  intro p hp
  have h : env59195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59194_59195 : H12AffineEnvironment.transform 11 1029 env59194 = env59195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59194 == env59195) = true)

theorem identity59195 : scanCanonicalize (H12AffineFastState.compose env59195 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59195 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59196 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,217,349,137,373,251,429,492,221,373,1,340,64,431,469,17,357,136,509,372,252,32,256,112,429,0]

theorem envBound59196 : H12AffineFastState.Bounded env59196 := by
  intro p hp
  have h : env59196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59195_59196 : H12AffineEnvironment.transform 9 220 env59195 = env59196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59195 == env59196) = true)

theorem identity59196 : scanCanonicalize (H12AffineFastState.compose env59196 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59196 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59197 : List Nat := [2,4,8,16,32,16,128,256,1,140,292,137,269,137,293,171,429,444,141,293,1,260,16,431,389,17,309,136,429,292,172,32,256,32,429,0]

theorem envBound59197 : H12AffineFastState.Bounded env59197 := by
  intro p hp
  have h : env59197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59196_59197 : H12AffineEnvironment.transform 5 16 env59196 = env59197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59196 == env59197) = true)

theorem identity59197 : scanCanonicalize (H12AffineFastState.compose env59197 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59198 : List Nat := [2,4,8,2,32,2,128,256,1,140,292,137,269,137,293,171,429,430,141,293,1,260,2,431,389,3,295,136,429,292,172,32,256,32,429,0]

theorem envBound59198 : H12AffineFastState.Bounded env59198 := by
  intro p hp
  have h : env59198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59197_59198 : H12AffineEnvironment.transform 3 2 env59197 = env59198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59197 == env59198) = true)

theorem identity59198 : scanCanonicalize (H12AffineFastState.compose env59198 (packedSelected [3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound59198 : packedSelected [3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59199 : List Nat := [2,4,8,2,32,2,40,256,1,36,292,33,269,33,293,3,261,262,37,293,1,260,2,263,301,3,295,32,261,292,4,32,256,32,261,0]

theorem envBound59199 : H12AffineFastState.Bounded env59199 := by
  intro p hp
  have h : env59199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59198_59199 : H12AffineEnvironment.transform 6 40 env59198 = env59199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env59198 == env59199) = true)

theorem identity59199 : scanCanonicalize (H12AffineFastState.compose env59199 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59199 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59200 : List Nat := [2,4,8,2,10,2,2,256,1,14,270,11,269,11,271,3,261,262,15,271,1,260,2,263,263,3,269,10,261,270,4,10,256,10,261,0]

theorem envBound59200 : H12AffineFastState.Bounded env59200 := by
  intro p hp
  have h : env59200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59199_59200 : H12AffineEnvironment.transform 4 10 env59199 = env59200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59199 == env59200) = true)

theorem identity59200 : scanCanonicalize (H12AffineFastState.compose env59200 (packedSelected [1,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59200 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59201 : List Nat := [2,4,3,2,1,2,2,256,1,5,261,0,262,0,260,3,261,262,4,260,1,260,2,263,263,3,262,1,261,261,4,1,256,1,261,0]

theorem envBound59201 : H12AffineFastState.Bounded env59201 := by
  intro p hp
  have h : env59201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59200_59201 : H12AffineEnvironment.transform 2 3 env59200 = env59201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59200 == env59201) = true)

theorem identity59201 : scanCanonicalize (H12AffineFastState.compose env59201 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59201 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59202 : List Nat := [1,4,0,1,1,1,1,256,1,5,261,0,261,0,260,0,261,261,4,260,1,260,1,260,260,0,261,1,261,261,4,1,256,1,261,0]

theorem envBound59202 : H12AffineFastState.Bounded env59202 := by
  intro p hp
  have h : env59202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59201_59202 : H12AffineEnvironment.transform 0 1 env59201 = env59202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59201 == env59202) = true)

def env59203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399767,8397000,8388689,2366325,4177,77954,67411,8463814,8465983,256,65674,78034,8389185]

theorem envBound59203 : H12AffineFastState.Bounded env59203 := by
  intro p hp
  have h : env59203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59111_59203 : H12AffineEnvironment.transform 21 1417 env59111 = env59203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59111 == env59203) = true)

def env59204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3671,1288,9617,2366325,4177,77954,67411,65542,68607,256,65674,78034,10113]

theorem envBound59204 : H12AffineFastState.Bounded env59204 := by
  intro p hp
  have h : env59204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59203_59204 : H12AffineEnvironment.transform 22 9664 env59203 = env59204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59203 == env59204) = true)

def env59205 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1288,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59205 : H12AffineFastState.Bounded env59205 := by
  intro p hp
  have h : env59205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59204_59205 : H12AffineEnvironment.transform 8 0 env59204 = env59205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59204 == env59205) = true)

theorem identity59205 : scanCanonicalize (H12AffineFastState.compose env59205 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59206 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,66734,1417,9664,3159,1288,9617,335323,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59206 : H12AffineFastState.Bounded env59206 := by
  intro p hp
  have h : env59206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59205_59206 : H12AffineEnvironment.transform 20 66734 env59205 = env59206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59205 == env59206) = true)

def env59207 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,66734,1417,64,3159,1288,17,335323,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound59207 : H12AffineFastState.Bounded env59207 := by
  intro p hp
  have h : env59207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59206_59207 : H12AffineEnvironment.transform 12 1408 env59206 = env59207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59206 == env59207) = true)

theorem identity59207 : scanCanonicalize (H12AffineFastState.compose env59207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7506) := by decide +kernel

theorem selectedBound59207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59208 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7506,2048,262144,1025,2128,6652,1417,64,3159,1288,17,262281,4177,2128,6145,7508,5293,256,7640,2048,1]

theorem envBound59208 : H12AffineFastState.Bounded env59208 := by
  intro p hp
  have h : env59208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59207_59208 : H12AffineEnvironment.transform 15 7506 env59207 = env59208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7506 env59207 == env59208) = true)

theorem identity59208 : scanCanonicalize (H12AffineFastState.compose env59208 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59208 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59209 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,4267,1529,262144,1025,1449,5125,1417,64,430,1288,17,262281,4177,1449,5624,4269,5293,256,4129,1529,1]

theorem envBound59209 : H12AffineFastState.Bounded env59209 := by
  intro p hp
  have h : env59209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59208_59209 : H12AffineEnvironment.transform 10 1529 env59208 = env59209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59208 == env59209) = true)

theorem identity59209 : scanCanonicalize (H12AffineFastState.compose env59209 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59209 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59210 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,4267,1529,5609,1025,1449,5125,1417,64,430,1288,17,5472,4177,1449,5624,4269,5293,256,4129,1529,1]

theorem envBound59210 : H12AffineFastState.Bounded env59210 := by
  intro p hp
  have h : env59210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59209_59210 : H12AffineEnvironment.transform 17 5609 env59209 = env59210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59209 == env59210) = true)

theorem identity59210 : scanCanonicalize (H12AffineFastState.compose env59210 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59210 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59211 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1164,1408,1244,1449,1063,1529,357,1025,1449,137,1417,64,430,1288,17,492,1245,1449,372,1057,33,256,1197,1529,1]

theorem envBound59211 : H12AffineFastState.Bounded env59211 := by
  intro p hp
  have h : env59211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59210_59211 : H12AffineEnvironment.transform 11 1164 env59210 = env59211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59210 == env59211) = true)

theorem identity59211 : scanCanonicalize (H12AffineFastState.compose env59211 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59211 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59212 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,80,348,0,373,251,293,357,221,373,137,341,64,430,468,17,492,1,373,372,253,33,256,113,293,1]

theorem envBound59212 : H12AffineFastState.Bounded env59212 := by
  intro p hp
  have h : env59212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59211_59212 : H12AffineEnvironment.transform 9 220 env59211 = env59212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59211 == env59212) = true)

theorem identity59212 : scanCanonicalize (H12AffineFastState.compose env59212 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59212 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59213 : List Nat := [2,4,8,16,32,16,128,256,0,140,293,0,268,0,293,171,293,309,141,293,137,261,16,430,388,17,444,1,293,292,173,33,256,33,293,1]

theorem envBound59213 : H12AffineFastState.Bounded env59213 := by
  intro p hp
  have h : env59213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59212_59213 : H12AffineEnvironment.transform 5 16 env59212 = env59213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59212 == env59213) = true)

theorem identity59213 : scanCanonicalize (H12AffineFastState.compose env59213 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound59213 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59214 : List Nat := [2,4,8,16,32,16,41,256,0,37,293,0,268,0,293,2,293,309,36,293,32,261,16,263,301,17,277,1,293,292,4,33,256,33,293,1]

theorem envBound59214 : H12AffineFastState.Bounded env59214 := by
  intro p hp
  have h : env59214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59213_59214 : H12AffineEnvironment.transform 6 41 env59213 = env59214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env59213 == env59214) = true)

theorem identity59214 : scanCanonicalize (H12AffineFastState.compose env59214 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59214 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59215 : List Nat := [2,4,0,16,32,16,33,256,0,37,293,0,260,0,293,2,293,309,36,293,32,261,16,263,293,17,277,1,293,292,4,33,256,33,293,1]

theorem envBound59215 : H12AffineFastState.Bounded env59215 := by
  intro p hp
  have h : env59215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59214_59215 : H12AffineEnvironment.transform 2 0 env59214 = env59215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59214 == env59215) = true)

theorem identity59215 : scanCanonicalize (H12AffineFastState.compose env59215 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59215 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59216 : List Nat := [0,4,0,16,32,16,33,256,0,37,293,0,260,0,293,0,293,309,36,293,32,261,16,261,293,17,277,1,293,292,4,33,256,33,293,1]

theorem envBound59216 : H12AffineFastState.Bounded env59216 := by
  intro p hp
  have h : env59216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59215_59216 : H12AffineEnvironment.transform 0 0 env59215 = env59216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59215 == env59216) = true)

def env59217 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,66734,1417,65,3159,1288,16,335323,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59217 : H12AffineFastState.Bounded env59217 := by
  intro p hp
  have h : env59217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59206_59217 : H12AffineEnvironment.transform 12 1409 env59206 = env59217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59206 == env59217) = true)

theorem identity59217 : scanCanonicalize (H12AffineFastState.compose env59217 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59217 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59218 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,66734,1417,65,3159,1288,16,328079,3077,67927,66899,65542,68095,256,65674,67847,0]

theorem envBound59218 : H12AffineFastState.Bounded env59218 := by
  intro p hp
  have h : env59218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59217_59218 : H12AffineEnvironment.transform 11 3156 env59217 = env59218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59217 == env59218) = true)

theorem identity59218 : scanCanonicalize (H12AffineFastState.compose env59218 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59218 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59219 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,68963,1025,2128,66734,1417,65,3159,1288,16,3308,3077,67927,66899,65542,68095,256,65674,67847,0]

theorem envBound59219 : H12AffineFastState.Bounded env59219 := by
  intro p hp
  have h : env59219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59218_59219 : H12AffineEnvironment.transform 17 68963 env59218 = env59219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59218 == env59219) = true)

theorem identity59219 : scanCanonicalize (H12AffineFastState.compose env59219 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59219 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59220 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,2203,412,1528,1025,2128,3125,1417,65,3159,1288,16,3308,3077,460,3528,2205,356,256,2065,412,0]

theorem envBound59220 : H12AffineFastState.Bounded env59220 := by
  intro p hp
  have h : env59220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59219_59220 : H12AffineEnvironment.transform 15 2203 env59219 = env59220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59219 == env59220) = true)

theorem identity59220 : scanCanonicalize (H12AffineFastState.compose env59220 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound59220 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59221 : List Nat := [2,4,8,16,32,64,128,256,0,1024,372,1312,1409,1392,292,495,412,1528,1025,292,1345,1417,65,1315,1288,16,1432,1393,460,1212,489,356,256,357,412,0]

theorem envBound59221 : H12AffineFastState.Bounded env59221 := by
  intro p hp
  have h : env59221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59220_59221 : H12AffineEnvironment.transform 10 372 env59220 = env59221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env59220 == env59221) = true)

theorem identity59221 : scanCanonicalize (H12AffineFastState.compose env59221 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59221 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59222 : List Nat := [2,4,8,16,32,64,128,256,0,236,372,460,365,412,292,495,412,276,237,292,429,357,65,463,484,16,372,413,460,80,489,356,256,357,412,0]

theorem envBound59222 : H12AffineFastState.Bounded env59222 := by
  intro p hp
  have h : env59222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59221_59222 : H12AffineEnvironment.transform 9 236 env59221 = env59222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59221 == env59222) = true)

theorem identity59222 : scanCanonicalize (H12AffineFastState.compose env59222 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59222 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59223 : List Nat := [2,4,8,16,32,64,128,68,0,236,48,136,41,216,96,171,216,80,237,96,233,33,65,139,160,16,48,217,136,80,173,32,68,33,216,0]

theorem envBound59223 : H12AffineFastState.Bounded env59223 := by
  intro p hp
  have h : env59223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59222_59223 : H12AffineEnvironment.transform 7 68 env59222 = env59223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59222 == env59223) = true)

theorem identity59223 : scanCanonicalize (H12AffineFastState.compose env59223 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59223 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59224 : List Nat := [2,4,8,16,32,64,9,68,0,101,48,1,41,81,96,34,81,80,100,96,96,33,65,2,41,16,48,80,1,80,36,32,68,33,81,0]

theorem envBound59224 : H12AffineFastState.Bounded env59224 := by
  intro p hp
  have h : env59224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59223_59224 : H12AffineEnvironment.transform 6 9 env59223 = env59224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59223 == env59224) = true)

theorem identity59224 : scanCanonicalize (H12AffineFastState.compose env59224 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59224 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59225 : List Nat := [2,4,8,16,32,10,9,14,0,47,48,1,41,27,42,34,27,26,46,42,42,33,11,2,41,16,48,26,1,26,36,32,14,33,27,0]

theorem envBound59225 : H12AffineFastState.Bounded env59225 := by
  intro p hp
  have h : env59225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59224_59225 : H12AffineEnvironment.transform 5 10 env59224 = env59225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59224 == env59225) = true)

theorem identity59225 : scanCanonicalize (H12AffineFastState.compose env59225 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59225 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59226 : List Nat := [2,4,8,16,17,10,9,14,0,30,1,1,24,27,27,19,27,26,31,27,27,16,11,2,24,16,1,26,1,26,21,17,14,16,27,0]

theorem envBound59226 : H12AffineFastState.Bounded env59226 := by
  intro p hp
  have h : env59226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59225_59226 : H12AffineEnvironment.transform 4 17 env59225 = env59226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59225 == env59226) = true)

theorem identity59226 : scanCanonicalize (H12AffineFastState.compose env59226 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59227 : List Nat := [2,4,8,10,11,10,9,14,0,4,1,1,2,1,1,9,1,0,5,1,1,10,11,2,2,10,1,0,1,0,15,11,14,10,1,0]

theorem envBound59227 : H12AffineFastState.Bounded env59227 := by
  intro p hp
  have h : env59227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59226_59227 : H12AffineEnvironment.transform 3 10 env59226 = env59227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59226 == env59227) = true)

def env59228 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1288,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59228 : H12AffineFastState.Bounded env59228 := by
  intro p hp
  have h : env59228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59204_59228 : H12AffineEnvironment.transform 8 1 env59204 = env59228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59204 == env59228) = true)

theorem identity59228 : scanCanonicalize (H12AffineFastState.compose env59228 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 74030) := by decide +kernel

theorem selectedBound59228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59229 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,74030,1417,9664,3158,1288,9617,342106,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59229 : H12AffineFastState.Bounded env59229 := by
  intro p hp
  have h : env59229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59228_59229 : H12AffineEnvironment.transform 20 74030 env59228 = env59229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74030 env59228 == env59229) = true)

def env59230 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,66734,1417,64,3158,1288,17,335322,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59230 : H12AffineFastState.Bounded env59230 := by
  intro p hp
  have h : env59230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59229_59230 : H12AffineEnvironment.transform 12 1408 env59229 = env59230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59229 == env59230) = true)

theorem identity59230 : scanCanonicalize (H12AffineFastState.compose env59230 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7507) := by decide +kernel

theorem selectedBound59230 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59231 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7507,2049,262144,1025,2129,6653,1417,64,3158,1288,17,262281,4177,2129,6145,7509,5293,256,7641,2049,0]

theorem envBound59231 : H12AffineFastState.Bounded env59231 := by
  intro p hp
  have h : env59231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59230_59231 : H12AffineEnvironment.transform 15 7507 env59230 = env59231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7507 env59230 == env59231) = true)

theorem identity59231 : scanCanonicalize (H12AffineFastState.compose env59231 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59231 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59232 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,4267,1529,262144,1025,1449,5125,1417,64,430,1288,17,262281,4177,1449,5625,4269,5293,256,4129,1529,0]

theorem envBound59232 : H12AffineFastState.Bounded env59232 := by
  intro p hp
  have h : env59232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59231_59232 : H12AffineEnvironment.transform 10 1528 env59231 = env59232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59231 == env59232) = true)

theorem identity59232 : scanCanonicalize (H12AffineFastState.compose env59232 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59232 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59233 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,4267,1529,5609,1025,1449,5125,1417,64,430,1288,17,5472,4177,1449,5625,4269,5293,256,4129,1529,0]

theorem envBound59233 : H12AffineFastState.Bounded env59233 := by
  intro p hp
  have h : env59233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59232_59233 : H12AffineEnvironment.transform 17 5609 env59232 = env59233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59232 == env59233) = true)

theorem identity59233 : scanCanonicalize (H12AffineFastState.compose env59233 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59233 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59234 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1164,1408,1244,1449,1063,1529,357,1025,1449,137,1417,64,430,1288,17,492,1245,1449,373,1057,33,256,1197,1529,0]

theorem envBound59234 : H12AffineFastState.Bounded env59234 := by
  intro p hp
  have h : env59234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59233_59234 : H12AffineEnvironment.transform 11 1164 env59233 = env59234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59233 == env59234) = true)

theorem identity59234 : scanCanonicalize (H12AffineFastState.compose env59234 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59234 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59235 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,81,349,1,372,250,292,357,220,372,137,340,64,430,469,17,492,0,372,373,252,33,256,112,292,0]

theorem envBound59235 : H12AffineFastState.Bounded env59235 := by
  intro p hp
  have h : env59235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59234_59235 : H12AffineEnvironment.transform 9 221 env59234 = env59235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59234 == env59235) = true)

theorem identity59235 : scanCanonicalize (H12AffineFastState.compose env59235 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59235 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59236 : List Nat := [2,4,8,16,32,64,128,173,1,221,136,81,240,1,217,250,137,200,220,217,137,249,64,3,120,17,65,0,217,216,252,33,173,112,137,0]

theorem envBound59236 : H12AffineFastState.Bounded env59236 := by
  intro p hp
  have h : env59236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59235_59236 : H12AffineEnvironment.transform 7 173 env59235 = env59236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59235 == env59236) = true)

theorem identity59236 : scanCanonicalize (H12AffineFastState.compose env59236 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59236 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59237 : List Nat := [2,4,8,16,32,64,105,68,1,52,97,81,25,1,48,19,96,33,53,48,96,16,64,3,120,17,65,0,48,49,21,33,68,112,96,0]

theorem envBound59237 : H12AffineFastState.Bounded env59237 := by
  intro p hp
  have h : env59237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59236_59237 : H12AffineEnvironment.transform 6 105 env59236 = env59237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59236 == env59237) = true)

theorem identity59237 : scanCanonicalize (H12AffineFastState.compose env59237 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59238 : List Nat := [2,4,8,16,2,64,75,68,1,22,67,81,25,1,18,19,66,3,23,18,66,16,64,3,90,17,65,0,18,19,21,3,68,82,66,0]

theorem envBound59238 : H12AffineFastState.Bounded env59238 := by
  intro p hp
  have h : env59238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59237_59238 : H12AffineEnvironment.transform 4 2 env59237 = env59238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59237 == env59238) = true)

theorem identity59238 : scanCanonicalize (H12AffineFastState.compose env59238 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59238 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env59239 : List Nat := [2,4,3,16,2,64,64,68,1,22,67,81,18,1,18,19,66,3,23,18,66,16,64,3,81,17,65,0,18,19,21,3,68,82,66,0]

theorem envBound59239 : H12AffineFastState.Bounded env59239 := by
  intro p hp
  have h : env59239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59238_59239 : H12AffineEnvironment.transform 2 3 env59238 = env59239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59238 == env59239) = true)

theorem identity59239 : scanCanonicalize (H12AffineFastState.compose env59239 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59239 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59240 : List Nat := [2,4,3,16,2,0,0,4,1,22,3,17,18,1,18,19,2,3,23,18,2,16,0,3,17,17,1,0,18,19,21,3,4,18,2,0]

theorem envBound59240 : H12AffineFastState.Bounded env59240 := by
  intro p hp
  have h : env59240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59239_59240 : H12AffineEnvironment.transform 5 0 env59239 = env59240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59239 == env59240) = true)

theorem identity59240 : scanCanonicalize (H12AffineFastState.compose env59240 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59241 : List Nat := [0,4,1,16,0,0,0,4,1,20,1,17,16,1,16,17,0,1,21,16,0,16,0,1,17,17,1,0,16,17,21,1,4,16,0,0]

theorem envBound59241 : H12AffineFastState.Bounded env59241 := by
  intro p hp
  have h : env59241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59240_59241 : H12AffineEnvironment.transform 0 0 env59240 = env59241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59240 == env59241) = true)

theorem identity59241 : scanCanonicalize (H12AffineFastState.compose env59241 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59241 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59242 : List Nat := [0,4,1,1,0,0,0,4,1,5,1,0,1,1,1,0,0,1,4,1,0,1,0,1,0,0,1,0,1,0,4,1,4,1,0,0]

theorem envBound59242 : H12AffineFastState.Bounded env59242 := by
  intro p hp
  have h : env59242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59241_59242 : H12AffineEnvironment.transform 3 1 env59241 = env59242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59241 == env59242) = true)

def env59243 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,66735,1417,65,3158,1288,16,335323,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59243 : H12AffineFastState.Bounded env59243 := by
  intro p hp
  have h : env59243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59229_59243 : H12AffineEnvironment.transform 12 1409 env59229 = env59243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59229 == env59243) = true)

theorem identity59243 : scanCanonicalize (H12AffineFastState.compose env59243 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59243 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59244 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,66735,1417,65,3158,1288,16,328079,3077,67927,66898,65542,68094,256,65674,67847,1]

theorem envBound59244 : H12AffineFastState.Bounded env59244 := by
  intro p hp
  have h : env59244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59243_59244 : H12AffineEnvironment.transform 11 3156 env59243 = env59244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59243 == env59244) = true)

theorem identity59244 : scanCanonicalize (H12AffineFastState.compose env59244 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59244 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59245 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,68963,1025,2129,66735,1417,65,3158,1288,16,3308,3077,67927,66898,65542,68094,256,65674,67847,1]

theorem envBound59245 : H12AffineFastState.Bounded env59245 := by
  intro p hp
  have h : env59245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59244_59245 : H12AffineEnvironment.transform 17 68963 env59244 = env59245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59244 == env59245) = true)

theorem identity59245 : scanCanonicalize (H12AffineFastState.compose env59245 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59245 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59246 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,2202,413,1529,1025,2129,3125,1417,65,3158,1288,16,3308,3077,461,3528,2204,356,256,2064,413,1]

theorem envBound59246 : H12AffineFastState.Bounded env59246 := by
  intro p hp
  have h : env59246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59245_59246 : H12AffineEnvironment.transform 15 2202 env59245 = env59246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59245 == env59246) = true)

theorem identity59246 : scanCanonicalize (H12AffineFastState.compose env59246 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59246 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59247 : List Nat := [2,4,8,16,32,64,128,256,1,425,2048,2557,40,2477,2129,2202,413,80,424,2129,2460,32,65,2559,161,16,2373,2476,461,2145,2204,356,256,2064,413,1]

theorem envBound59247 : H12AffineFastState.Bounded env59247 := by
  intro p hp
  have h : env59247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59246_59247 : H12AffineEnvironment.transform 9 425 env59246 = env59247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59246 == env59247) = true)

theorem identity59247 : scanCanonicalize (H12AffineFastState.compose env59247 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59247 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59248 : List Nat := [2,4,8,16,32,64,128,69,1,236,2048,2232,40,2280,2129,2202,216,80,237,2129,2265,32,65,2234,161,16,2048,2281,136,2145,2204,33,69,2064,216,1]

theorem envBound59248 : H12AffineFastState.Bounded env59248 := by
  intro p hp
  have h : env59248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59247_59248 : H12AffineEnvironment.transform 7 69 env59247 = env59248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59247 == env59248) = true)

theorem identity59248 : scanCanonicalize (H12AffineFastState.compose env59248 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59249 : List Nat := [2,4,8,16,32,64,115,69,1,31,2048,2123,40,2075,2129,2153,43,80,30,2129,2090,32,65,2121,82,16,2048,2074,123,2145,2159,33,69,2064,43,1]

theorem envBound59249 : H12AffineFastState.Bounded env59249 := by
  intro p hp
  have h : env59249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59248_59249 : H12AffineEnvironment.transform 6 115 env59248 = env59249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59248 == env59249) = true)

def env59250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3670,1289,9616,2366325,4177,77954,67411,65543,68606,256,65674,78034,10112]

theorem envBound59250 : H12AffineFastState.Bounded env59250 := by
  intro p hp
  have h : env59250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59203_59250 : H12AffineEnvironment.transform 22 9665 env59203 = env59250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59203 == env59250) = true)

def env59251 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59251 : H12AffineFastState.Bounded env59251 := by
  intro p hp
  have h : env59251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59250_59251 : H12AffineEnvironment.transform 8 0 env59250 = env59251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59250 == env59251) = true)

theorem identity59251 : scanCanonicalize (H12AffineFastState.compose env59251 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 14718) := by decide +kernel

theorem selectedBound59251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59252 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,14718,2476,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365813,4177,2556,15405,14713,12416,256,14836,2476,9600]

theorem envBound59252 : H12AffineFastState.Bounded env59252 := by
  intro p hp
  have h : env59252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59251_59252 : H12AffineEnvironment.transform 15 14718 env59251 = env59252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14718 env59251 == env59252) = true)

def env59253 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,2097152,1417,65,3158,1289,16,2365813,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59253 : H12AffineFastState.Bounded env59253 := by
  intro p hp
  have h : env59253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59252_59253 : H12AffineEnvironment.transform 12 1408 env59252 = env59253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59252 == env59253) = true)

theorem identity59253 : scanCanonicalize (H12AffineFastState.compose env59253 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59253 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59254 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,1029,1417,65,3158,1289,16,269680,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59254 : H12AffineFastState.Bounded env59254 := by
  intro p hp
  have h : env59254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59253_59254 : H12AffineEnvironment.transform 20 1029 env59253 = env59254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env59253 == env59254) = true)

theorem identity59254 : scanCanonicalize (H12AffineFastState.compose env59254 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59254 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59255 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,7422,2476,3529,1025,2128,1029,1417,65,3158,1289,16,4281,4177,2556,6573,7417,5376,256,7284,2476,0]

theorem envBound59255 : H12AffineFastState.Bounded env59255 := by
  intro p hp
  have h : env59255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59254_59255 : H12AffineEnvironment.transform 17 3529 env59254 = env59255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59254 == env59255) = true)

theorem identity59255 : scanCanonicalize (H12AffineFastState.compose env59255 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59255 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59256 : List Nat := [2,4,8,16,32,64,128,256,0,1024,48,4096,1408,4176,96,5326,412,1529,1025,96,1029,1417,65,1126,1289,16,4281,4177,460,4509,5321,5376,256,5188,412,0]

theorem envBound59256 : H12AffineFastState.Bounded env59256 := by
  intro p hp
  have h : env59256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59255_59256 : H12AffineEnvironment.transform 10 48 env59255 = env59256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59255 == env59256) = true)

theorem identity59256 : scanCanonicalize (H12AffineFastState.compose env59256 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound59256 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59257 : List Nat := [2,4,8,16,32,64,128,256,0,425,48,4096,41,4176,96,4455,412,80,424,96,428,32,65,463,160,16,4281,4177,460,4509,4448,4265,256,4589,412,0]

theorem envBound59257 : H12AffineFastState.Bounded env59257 := by
  intro p hp
  have h : env59257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59256_59257 : H12AffineEnvironment.transform 9 425 env59256 = env59257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env59256 == env59257) = true)

theorem identity59257 : scanCanonicalize (H12AffineFastState.compose env59257 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59257 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59258 : List Nat := [2,4,8,16,32,64,128,256,0,425,48,137,41,217,96,494,412,80,424,96,428,32,65,463,160,16,48,216,460,276,489,32,256,356,412,0]

theorem envBound59258 : H12AffineFastState.Bounded env59258 := by
  intro p hp
  have h : env59258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59257_59258 : H12AffineEnvironment.transform 11 137 env59257 = env59258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59257 == env59258) = true)

theorem identity59258 : scanCanonicalize (H12AffineFastState.compose env59258 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound59258 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59259 : List Nat := [2,4,8,16,32,64,128,183,0,30,48,137,41,217,96,89,43,80,31,96,27,32,65,120,160,16,48,216,123,163,94,32,183,211,43,0]

theorem envBound59259 : H12AffineFastState.Bounded env59259 := by
  intro p hp
  have h : env59259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59258_59259 : H12AffineEnvironment.transform 7 183 env59258 = env59259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env59258 == env59259) = true)

theorem identity59259 : scanCanonicalize (H12AffineFastState.compose env59259 (packedSelected [1,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59259 : packedSelected [1,6,9] rootPS < 2^1333 := by decide +kernel

def env59260 : List Nat := [2,4,8,16,32,64,114,69,0,30,48,123,41,43,96,89,43,80,31,96,27,32,65,120,82,16,48,42,123,81,94,32,69,33,43,0]

theorem envBound59260 : H12AffineFastState.Bounded env59260 := by
  intro p hp
  have h : env59260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59259_59260 : H12AffineEnvironment.transform 6 114 env59259 = env59260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59259 == env59260) = true)

def env59261 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7423,2476,262144,1025,2128,2097152,1417,64,3158,1289,17,2365813,4177,2556,6572,7416,5377,256,7285,2476,1]

theorem envBound59261 : H12AffineFastState.Bounded env59261 := by
  intro p hp
  have h : env59261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59252_59261 : H12AffineEnvironment.transform 12 1409 env59252 = env59261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59252 == env59261) = true)

theorem identity59261 : scanCanonicalize (H12AffineFastState.compose env59261 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59261 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59262 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7423,2476,262144,1025,2128,6652,1417,64,3158,1289,17,262281,4177,2556,6572,7416,5377,256,7285,2476,1]

theorem envBound59262 : H12AffineFastState.Bounded env59262 := by
  intro p hp
  have h : env59262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59261_59262 : H12AffineEnvironment.transform 20 6652 env59261 = env59262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59261 == env59262) = true)

theorem identity59262 : scanCanonicalize (H12AffineFastState.compose env59262 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59262 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59263 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,4358,1109,262144,1025,1449,5125,1417,64,431,1289,17,262281,4177,1029,5205,4353,5377,256,4492,1109,1]

theorem envBound59263 : H12AffineFastState.Bounded env59263 := by
  intro p hp
  have h : env59263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59262_59263 : H12AffineEnvironment.transform 10 1529 env59262 = env59263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59262 == env59263) = true)

theorem identity59263 : scanCanonicalize (H12AffineFastState.compose env59263 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59263 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59264 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1409,4176,1449,4358,1109,5609,1025,1449,5125,1417,64,431,1289,17,5472,4177,1029,5205,4353,5377,256,4492,1109,1]

theorem envBound59264 : H12AffineFastState.Bounded env59264 := by
  intro p hp
  have h : env59264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59263_59264 : H12AffineEnvironment.transform 17 5609 env59263 = env59264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59263 == env59264) = true)

theorem identity59264 : scanCanonicalize (H12AffineFastState.compose env59264 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59264 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59265 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1313,1409,1393,1449,1063,1109,200,1025,1449,292,1417,64,431,1289,17,65,1392,1029,372,1056,32,256,1197,1109,1]

theorem envBound59265 : H12AffineFastState.Bounded env59265 := by
  intro p hp
  have h : env59265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59264_59265 : H12AffineEnvironment.transform 11 1313 env59264 = env59265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59264 == env59265) = true)

theorem identity59265 : scanCanonicalize (H12AffineFastState.compose env59265 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59265 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59266 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,509,349,429,373,251,137,200,221,373,292,341,64,431,469,17,65,428,217,372,252,32,256,113,137,1]

theorem envBound59266 : H12AffineFastState.Bounded env59266 := by
  intro p hp
  have h : env59266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59265_59266 : H12AffineEnvironment.transform 9 220 env59265 = env59266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59265 == env59266) = true)

theorem identity59266 : scanCanonicalize (H12AffineFastState.compose env59266 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59266 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59267 : List Nat := [2,4,8,16,32,64,128,173,0,220,136,80,240,0,216,251,137,200,221,216,137,248,64,2,120,17,65,1,217,217,252,32,173,113,137,1]

theorem envBound59267 : H12AffineFastState.Bounded env59267 := by
  intro p hp
  have h : env59267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59266_59267 : H12AffineEnvironment.transform 7 173 env59266 = env59267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59266 == env59267) = true)

theorem identity59267 : scanCanonicalize (H12AffineFastState.compose env59267 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound59267 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env59268 : List Nat := [2,4,8,16,32,64,40,5,0,116,32,80,88,0,112,83,33,96,117,112,33,80,64,2,120,17,65,1,113,113,84,32,5,113,33,1]

theorem envBound59268 : H12AffineFastState.Bounded env59268 := by
  intro p hp
  have h : env59268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59267_59268 : H12AffineEnvironment.transform 6 40 env59267 = env59268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env59267 == env59268) = true)

theorem identity59268 : scanCanonicalize (H12AffineFastState.compose env59268 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59268 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59269 : List Nat := [2,4,8,16,11,64,3,5,0,95,11,80,88,0,91,83,10,75,94,91,10,80,64,2,83,17,65,1,90,90,84,11,5,90,10,1]

theorem envBound59269 : H12AffineFastState.Bounded env59269 := by
  intro p hp
  have h : env59269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59268_59269 : H12AffineEnvironment.transform 4 11 env59268 = env59269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59268 == env59269) = true)

theorem identity59269 : scanCanonicalize (H12AffineFastState.compose env59269 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59269 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59270 : List Nat := [2,4,8,3,11,64,3,5,0,76,11,67,75,0,72,64,10,75,77,72,10,67,64,2,64,2,65,1,73,73,71,11,5,73,10,1]

theorem envBound59270 : H12AffineFastState.Bounded env59270 := by
  intro p hp
  have h : env59270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59269_59270 : H12AffineEnvironment.transform 3 3 env59269 = env59270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59269 == env59270) = true)

theorem identity59270 : scanCanonicalize (H12AffineFastState.compose env59270 (packedSelected [6,9] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59270 : packedSelected [6,9] rootPS < 2^1333 := by decide +kernel

def env59271 : List Nat := [2,4,1,3,2,64,3,5,0,69,2,67,66,0,65,64,3,66,68,65,3,67,64,2,64,2,65,1,64,64,71,2,5,64,3,1]

theorem envBound59271 : H12AffineFastState.Bounded env59271 := by
  intro p hp
  have h : env59271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59270_59271 : H12AffineEnvironment.transform 2 1 env59270 = env59271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59270 == env59271) = true)

def env59272 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59272 : H12AffineFastState.Bounded env59272 := by
  intro p hp
  have h : env59272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59250_59272 : H12AffineEnvironment.transform 8 1 env59250 = env59272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59250 == env59272) = true)

theorem identity59272 : scanCanonicalize (H12AffineFastState.compose env59272 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59273 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,7422,11308,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365812,4177,11388,6572,7417,5377,256,7284,11308,9601]

theorem envBound59273 : H12AffineFastState.Bounded env59273 := by
  intro p hp
  have h : env59273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59272_59273 : H12AffineEnvironment.transform 15 7422 env59272 = env59273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59272 == env59273) = true)

def env59274 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,2097152,1417,65,3159,1289,16,2365812,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59274 : H12AffineFastState.Bounded env59274 := by
  intro p hp
  have h : env59274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59273_59274 : H12AffineEnvironment.transform 12 1408 env59273 = env59274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59273 == env59274) = true)

theorem identity59274 : scanCanonicalize (H12AffineFastState.compose env59274 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59274 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59275 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,1028,1417,65,3159,1289,16,269680,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59275 : H12AffineFastState.Bounded env59275 := by
  intro p hp
  have h : env59275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59274_59275 : H12AffineEnvironment.transform 20 1028 env59274 = env59275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59274 == env59275) = true)

theorem identity59275 : scanCanonicalize (H12AffineFastState.compose env59275 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59275 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59276 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,7422,2476,3529,1025,2129,1028,1417,65,3159,1289,16,4281,4177,2556,6572,7417,5377,256,7284,2476,1]

theorem envBound59276 : H12AffineFastState.Bounded env59276 := by
  intro p hp
  have h : env59276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59275_59276 : H12AffineEnvironment.transform 17 3529 env59275 = env59276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59275 == env59276) = true)

theorem identity59276 : scanCanonicalize (H12AffineFastState.compose env59276 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59276 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59277 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,4096,1408,4176,96,5327,413,1528,1025,96,1028,1417,65,1126,1289,16,4281,4177,461,4509,5320,5377,256,5189,413,1]

theorem envBound59277 : H12AffineFastState.Bounded env59277 := by
  intro p hp
  have h : env59277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59276_59277 : H12AffineEnvironment.transform 10 49 env59276 = env59277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59276 == env59277) = true)

theorem identity59277 : scanCanonicalize (H12AffineFastState.compose env59277 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59277 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59278 : List Nat := [2,4,8,16,32,64,128,69,1,1024,49,4096,1221,4176,96,5327,216,1213,1025,96,1028,1228,65,1126,1100,16,4281,4177,136,4312,5320,5188,69,5189,216,1]

theorem envBound59278 : H12AffineFastState.Bounded env59278 := by
  intro p hp
  have h : env59278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59277_59278 : H12AffineEnvironment.transform 7 69 env59277 = env59278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59277 == env59278) = true)

theorem identity59278 : scanCanonicalize (H12AffineFastState.compose env59278 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59278 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59279 : List Nat := [2,4,8,16,32,64,128,69,1,1024,49,136,1221,216,96,1095,216,1213,1025,96,1028,1228,65,1126,1100,16,49,217,136,80,1088,1228,69,1229,216,1]

theorem envBound59279 : H12AffineFastState.Bounded env59279 := by
  intro p hp
  have h : env59279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59278_59279 : H12AffineEnvironment.transform 11 136 env59278 = env59279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59278 == env59279) = true)

theorem identity59279 : scanCanonicalize (H12AffineFastState.compose env59279 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59279 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59280 : List Nat := [2,4,8,16,32,64,128,69,1,237,49,136,40,216,96,170,216,80,236,96,233,33,65,139,161,16,49,217,136,80,173,33,69,32,216,1]

theorem envBound59280 : H12AffineFastState.Bounded env59280 := by
  intro p hp
  have h : env59280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59279_59280 : H12AffineEnvironment.transform 9 237 env59279 = env59280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59279 == env59280) = true)

theorem identity59280 : scanCanonicalize (H12AffineFastState.compose env59280 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59280 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59281 : List Nat := [2,4,8,16,32,64,9,69,1,100,49,1,40,81,96,35,81,80,101,96,96,33,65,2,40,16,49,80,1,80,36,33,69,32,81,1]

theorem envBound59281 : H12AffineFastState.Bounded env59281 := by
  intro p hp
  have h : env59281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59280_59281 : H12AffineEnvironment.transform 6 9 env59280 = env59281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59280 == env59281) = true)

theorem identity59281 : scanCanonicalize (H12AffineFastState.compose env59281 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59281 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59282 : List Nat := [2,4,8,16,32,11,9,14,1,47,49,1,40,26,43,35,26,27,46,43,43,33,10,2,40,16,49,27,1,27,36,33,14,32,26,1]

theorem envBound59282 : H12AffineFastState.Bounded env59282 := by
  intro p hp
  have h : env59282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59281_59282 : H12AffineEnvironment.transform 5 11 env59281 = env59282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59281 == env59282) = true)

theorem identity59282 : scanCanonicalize (H12AffineFastState.compose env59282 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59282 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59283 : List Nat := [2,4,8,16,16,11,9,14,1,31,1,1,24,26,27,19,26,27,30,27,27,17,10,2,24,16,1,27,1,27,20,17,14,16,26,1]

theorem envBound59283 : H12AffineFastState.Bounded env59283 := by
  intro p hp
  have h : env59283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59282_59283 : H12AffineEnvironment.transform 4 16 env59282 = env59283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59282 == env59283) = true)

theorem identity59283 : scanCanonicalize (H12AffineFastState.compose env59283 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59284 : List Nat := [2,4,8,11,11,11,9,14,1,4,1,1,3,1,0,8,1,0,5,0,0,10,10,2,3,11,1,0,1,0,15,10,14,11,1,1]

theorem envBound59284 : H12AffineFastState.Bounded env59284 := by
  intro p hp
  have h : env59284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59283_59284 : H12AffineEnvironment.transform 3 11 env59283 = env59284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59283 == env59284) = true)

def env59285 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,2097152,1417,64,3159,1289,17,2365812,4177,2557,6572,7417,5377,256,7284,2477,0]

theorem envBound59285 : H12AffineFastState.Bounded env59285 := by
  intro p hp
  have h : env59285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59273_59285 : H12AffineEnvironment.transform 12 1409 env59273 = env59285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59273 == env59285) = true)

theorem identity59285 : scanCanonicalize (H12AffineFastState.compose env59285 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59285 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59286 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,6653,1417,64,3159,1289,17,262281,4177,2557,6572,7417,5377,256,7284,2477,0]

theorem envBound59286 : H12AffineFastState.Bounded env59286 := by
  intro p hp
  have h : env59286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59285_59286 : H12AffineEnvironment.transform 20 6653 env59285 = env59286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59285 == env59286) = true)

theorem identity59286 : scanCanonicalize (H12AffineFastState.compose env59286 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59286 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59287 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,4358,1109,262144,1025,1449,5125,1417,64,431,1289,17,262281,4177,1029,5204,4353,5377,256,4492,1109,0]

theorem envBound59287 : H12AffineFastState.Bounded env59287 := by
  intro p hp
  have h : env59287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59286_59287 : H12AffineEnvironment.transform 10 1528 env59286 = env59287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59286 == env59287) = true)

theorem identity59287 : scanCanonicalize (H12AffineFastState.compose env59287 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5609) := by decide +kernel

theorem selectedBound59287 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59288 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1409,4176,1449,4358,1109,5609,1025,1449,5125,1417,64,431,1289,17,5472,4177,1029,5204,4353,5377,256,4492,1109,0]

theorem envBound59288 : H12AffineFastState.Bounded env59288 := by
  intro p hp
  have h : env59288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59287_59288 : H12AffineEnvironment.transform 17 5609 env59287 = env59288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5609 env59287 == env59288) = true)

theorem identity59288 : scanCanonicalize (H12AffineFastState.compose env59288 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound59288 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59289 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1313,1409,1393,1449,1063,1109,200,1025,1449,292,1417,64,431,1289,17,65,1392,1029,373,1056,32,256,1197,1109,0]

theorem envBound59289 : H12AffineFastState.Bounded env59289 := by
  intro p hp
  have h : env59289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59288_59289 : H12AffineEnvironment.transform 11 1313 env59288 = env59289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env59288 == env59289) = true)

theorem identity59289 : scanCanonicalize (H12AffineFastState.compose env59289 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59289 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59290 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,508,348,428,372,250,136,200,220,372,292,340,64,431,468,17,65,429,216,373,253,32,256,112,136,0]

theorem envBound59290 : H12AffineFastState.Bounded env59290 := by
  intro p hp
  have h : env59290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59289_59290 : H12AffineEnvironment.transform 9 221 env59289 = env59290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59289 == env59290) = true)

theorem identity59290 : scanCanonicalize (H12AffineFastState.compose env59290 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59290 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59291 : List Nat := [2,4,8,16,32,16,128,256,1,141,293,428,268,428,292,170,136,152,140,292,292,260,16,431,388,17,17,429,136,293,173,32,256,32,136,0]

theorem envBound59291 : H12AffineFastState.Bounded env59291 := by
  intro p hp
  have h : env59291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59290_59291 : H12AffineEnvironment.transform 5 16 env59290 = env59291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59290 == env59291) = true)

theorem identity59291 : scanCanonicalize (H12AffineFastState.compose env59291 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 55) := by decide +kernel

theorem selectedBound59291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59292 : List Nat := [2,4,8,16,32,16,128,55,1,141,18,155,59,155,19,170,136,152,140,19,19,51,16,152,179,17,17,154,136,18,173,32,55,32,136,0]

theorem envBound59292 : H12AffineFastState.Bounded env59292 := by
  intro p hp
  have h : env59292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59291_59292 : H12AffineEnvironment.transform 7 55 env59291 = env59292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 55 env59291 == env59292) = true)

theorem identity59292 : scanCanonicalize (H12AffineFastState.compose env59292 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound59292 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59293 : List Nat := [2,4,8,16,19,16,128,4,1,141,18,155,8,155,19,153,136,152,140,19,19,0,16,152,128,17,17,154,136,18,158,19,4,19,136,0]

theorem envBound59293 : H12AffineFastState.Bounded env59293 := by
  intro p hp
  have h : env59293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59292_59293 : H12AffineEnvironment.transform 4 19 env59292 = env59293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env59292 == env59293) = true)

theorem identity59293 : scanCanonicalize (H12AffineFastState.compose env59293 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59293 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59294 : List Nat := [2,4,8,9,10,9,128,4,1,141,11,130,8,130,10,128,136,129,140,10,10,0,9,129,128,8,8,131,136,11,135,10,4,10,136,0]

theorem envBound59294 : H12AffineFastState.Bounded env59294 := by
  intro p hp
  have h : env59294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59293_59294 : H12AffineEnvironment.transform 3 9 env59293 = env59294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59293 == env59294) = true)

theorem identity59294 : scanCanonicalize (H12AffineFastState.compose env59294 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59295 : List Nat := [2,4,3,2,1,2,128,4,1,134,0,130,3,130,1,128,131,129,135,1,1,0,2,129,128,3,3,131,131,0,135,1,4,1,131,0]

theorem envBound59295 : H12AffineFastState.Bounded env59295 := by
  intro p hp
  have h : env59295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59294_59295 : H12AffineEnvironment.transform 2 3 env59294 = env59295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59294 == env59295) = true)

theorem identity59295 : scanCanonicalize (H12AffineFastState.compose env59295 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59295 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59296 : List Nat := [1,4,0,1,1,1,128,4,1,133,0,129,0,129,1,128,128,129,132,1,1,0,1,129,128,0,0,128,128,0,132,1,4,1,128,0]

theorem envBound59296 : H12AffineFastState.Bounded env59296 := by
  intro p hp
  have h : env59296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59295_59296 : H12AffineEnvironment.transform 0 1 env59295 = env59296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59295 == env59296) = true)

theorem identity59296 : scanCanonicalize (H12AffineFastState.compose env59296 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59296 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59297 : List Nat := [1,4,0,1,1,1,0,4,1,5,0,1,0,1,1,0,0,1,4,1,1,0,1,1,0,0,0,0,0,0,4,1,4,1,0,0]

theorem envBound59297 : H12AffineFastState.Bounded env59297 := by
  intro p hp
  have h : env59297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59296_59297 : H12AffineEnvironment.transform 6 0 env59296 = env59297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59296 == env59297) = true)

def env59298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397000,8388689,6561533,4177,77954,4260570,8463814,8465982,256,4261122,78034,8389185]

theorem envBound59298 : H12AffineFastState.Bounded env59298 := by
  intro p hp
  have h : env59298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59110_59298 : H12AffineEnvironment.transform 26 6561533 env59110 = env59298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env59110 == env59298) = true)

def env59299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399767,8397000,8388689,2366325,4177,77954,67410,8463814,8465982,256,65674,78034,8389185]

theorem envBound59299 : H12AffineFastState.Bounded env59299 := by
  intro p hp
  have h : env59299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59298_59299 : H12AffineEnvironment.transform 21 1416 env59298 = env59299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59298 == env59299) = true)

def env59300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3671,1288,9617,2366325,4177,77954,67410,65542,68606,256,65674,78034,10113]

theorem envBound59300 : H12AffineFastState.Bounded env59300 := by
  intro p hp
  have h : env59300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59299_59300 : H12AffineEnvironment.transform 22 9664 env59299 = env59300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59299 == env59300) = true)

def env59301 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1288,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59301 : H12AffineFastState.Bounded env59301 := by
  intro p hp
  have h : env59301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59300_59301 : H12AffineEnvironment.transform 8 0 env59300 = env59301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59300 == env59301) = true)

theorem identity59301 : scanCanonicalize (H12AffineFastState.compose env59301 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 8580) := by decide +kernel

theorem selectedBound59301 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59302 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,8580,1416,9664,3159,1288,9617,276721,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound59302 : H12AffineFastState.Bounded env59302 := by
  intro p hp
  have h : env59302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59301_59302 : H12AffineEnvironment.transform 20 8580 env59301 = env59302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 8580 env59301 == env59302) = true)

def env59303 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,1028,1416,64,3159,1288,17,269681,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound59303 : H12AffineFastState.Bounded env59303 := by
  intro p hp
  have h : env59303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59302_59303 : H12AffineEnvironment.transform 12 1408 env59302 = env59303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59302 == env59303) = true)

theorem identity59303 : scanCanonicalize (H12AffineFastState.compose env59303 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3576) := by decide +kernel

theorem selectedBound59303 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59304 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3576,1408,3496,2128,65536,67754,262144,1025,2128,1028,1416,64,3159,1288,17,262281,3497,67834,66898,65542,68094,256,65674,67754,1]

theorem envBound59304 : H12AffineFastState.Bounded env59304 := by
  intro p hp
  have h : env59304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59303_59304 : H12AffineEnvironment.transform 11 3576 env59303 = env59304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3576 env59303 == env59304) = true)

theorem identity59304 : scanCanonicalize (H12AffineFastState.compose env59304 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59304 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59305 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1448,65536,66898,262144,1025,1448,1028,1416,64,431,1288,17,262281,81,66818,66898,65542,66566,256,65674,66898,1]

theorem envBound59305 : H12AffineFastState.Bounded env59305 := by
  intro p hp
  have h : env59305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59304_59305 : H12AffineEnvironment.transform 10 1528 env59304 = env59305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59304 == env59305) = true)

theorem identity59305 : scanCanonicalize (H12AffineFastState.compose env59305 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound59305 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59306 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1448,65536,66898,1513,1025,1448,1028,1416,64,431,1288,17,1376,81,66818,66898,65542,66566,256,65674,66898,1]

theorem envBound59306 : H12AffineFastState.Bounded env59306 := by
  intro p hp
  have h : env59306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59305_59306 : H12AffineEnvironment.transform 17 1513 env59305 = env59306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env59305 == env59306) = true)

theorem identity59306 : scanCanonicalize (H12AffineFastState.compose env59306 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59306 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59307 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,0,1408,80,1448,1062,372,1513,1025,1448,1028,1416,64,431,1288,17,1376,81,292,372,1056,32,256,1196,372,1]

theorem envBound59307 : H12AffineFastState.Bounded env59307 := by
  intro p hp
  have h : env59307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59306_59307 : H12AffineEnvironment.transform 15 1062 env59306 = env59307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59306 == env59307) = true)

theorem identity59307 : scanCanonicalize (H12AffineFastState.compose env59307 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59307 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59308 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,0,349,80,373,251,372,308,220,373,217,341,64,431,469,17,445,81,292,372,253,32,256,113,372,1]

theorem envBound59308 : H12AffineFastState.Bounded env59308 := by
  intro p hp
  have h : env59308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59307_59308 : H12AffineEnvironment.transform 9 221 env59307 = env59308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59307 == env59308) = true)

theorem identity59308 : scanCanonicalize (H12AffineFastState.compose env59308 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59308 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59309 : List Nat := [2,4,8,16,32,17,128,256,0,140,293,0,268,1,292,170,293,308,141,292,136,260,17,431,388,17,445,0,292,293,172,32,256,32,293,1]

theorem envBound59309 : H12AffineFastState.Bounded env59309 := by
  intro p hp
  have h : env59309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59308_59309 : H12AffineEnvironment.transform 5 17 env59308 = env59309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59308 == env59309) = true)

theorem identity59309 : scanCanonicalize (H12AffineFastState.compose env59309 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound59309 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59310 : List Nat := [2,4,8,16,32,17,128,157,0,140,184,0,145,1,185,170,184,169,141,185,136,153,17,50,25,17,32,0,185,184,172,32,157,32,184,1]

theorem envBound59310 : H12AffineFastState.Bounded env59310 := by
  intro p hp
  have h : env59310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59309_59310 : H12AffineEnvironment.transform 7 157 env59309 = env59310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env59309 == env59310) = true)

theorem identity59310 : scanCanonicalize (H12AffineFastState.compose env59310 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound59310 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59311 : List Nat := [2,4,8,16,32,17,10,23,0,6,50,0,27,1,51,32,50,35,7,51,2,19,17,50,25,17,32,0,51,50,38,32,23,32,50,1]

theorem envBound59311 : H12AffineFastState.Bounded env59311 := by
  intro p hp
  have h : env59311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59310_59311 : H12AffineEnvironment.transform 6 10 env59310 = env59311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env59310 == env59311) = true)

theorem identity59311 : scanCanonicalize (H12AffineFastState.compose env59311 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59311 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59312 : List Nat := [2,4,8,16,1,17,10,23,0,6,19,0,27,1,18,1,19,2,7,18,2,19,17,19,25,17,1,0,18,19,7,1,23,1,19,1]

theorem envBound59312 : H12AffineFastState.Bounded env59312 := by
  intro p hp
  have h : env59312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59311_59312 : H12AffineEnvironment.transform 4 1 env59311 = env59312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59311 == env59312) = true)

theorem identity59312 : scanCanonicalize (H12AffineFastState.compose env59312 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59313 : List Nat := [0,4,8,16,1,17,8,21,0,4,17,0,25,1,16,1,17,0,5,16,0,17,17,17,25,17,1,0,16,17,5,1,21,1,17,1]

theorem envBound59313 : H12AffineFastState.Bounded env59313 := by
  intro p hp
  have h : env59313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59312_59313 : H12AffineEnvironment.transform 0 0 env59312 = env59313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59312 == env59313) = true)

def env59314 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,1029,1416,65,3159,1288,16,269680,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound59314 : H12AffineFastState.Bounded env59314 := by
  intro p hp
  have h : env59314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59302_59314 : H12AffineEnvironment.transform 12 1409 env59302 = env59314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59302 == env59314) = true)

theorem identity59314 : scanCanonicalize (H12AffineFastState.compose env59314 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59314 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59315 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,1029,1416,65,3159,1288,16,269680,4177,2557,6572,7416,5376,256,7284,2477,0]

theorem envBound59315 : H12AffineFastState.Bounded env59315 := by
  intro p hp
  have h : env59315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59314_59315 : H12AffineEnvironment.transform 15 7422 env59314 = env59315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59314 == env59315) = true)

theorem identity59315 : scanCanonicalize (H12AffineFastState.compose env59315 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59315 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59316 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,3528,1025,2128,1029,1416,65,3159,1288,16,4280,4177,2557,6572,7416,5376,256,7284,2477,0]

theorem envBound59316 : H12AffineFastState.Bounded env59316 := by
  intro p hp
  have h : env59316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59315_59316 : H12AffineEnvironment.transform 17 3528 env59315 = env59316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59315 == env59316) = true)

theorem identity59316 : scanCanonicalize (H12AffineFastState.compose env59316 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59316 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59317 : List Nat := [2,4,8,16,32,64,128,256,0,1024,48,4096,1409,4176,96,5326,413,1528,1025,96,1029,1416,65,1127,1288,16,4280,4177,461,4508,5320,5376,256,5188,413,0]

theorem envBound59317 : H12AffineFastState.Bounded env59317 := by
  intro p hp
  have h : env59317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59316_59317 : H12AffineEnvironment.transform 10 48 env59316 = env59317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59316 == env59317) = true)

theorem identity59317 : scanCanonicalize (H12AffineFastState.compose env59317 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59317 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59318 : List Nat := [2,4,8,16,32,64,128,256,0,424,48,4096,41,4176,96,4454,413,80,425,96,429,32,65,463,160,16,4280,4177,461,4508,4448,4264,256,4588,413,0]

theorem envBound59318 : H12AffineFastState.Bounded env59318 := by
  intro p hp
  have h : env59318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59317_59318 : H12AffineEnvironment.transform 9 424 env59317 = env59318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59317 == env59318) = true)

theorem identity59318 : scanCanonicalize (H12AffineFastState.compose env59318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59319 : List Nat := [2,4,8,16,32,64,128,256,0,424,48,136,41,216,96,494,413,80,425,96,429,32,65,463,160,16,48,217,461,276,488,32,256,356,413,0]

theorem envBound59319 : H12AffineFastState.Bounded env59319 := by
  intro p hp
  have h : env59319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59318_59319 : H12AffineEnvironment.transform 11 136 env59318 = env59319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59318 == env59319) = true)

theorem identity59319 : scanCanonicalize (H12AffineFastState.compose env59319 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound59319 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59320 : List Nat := [2,4,8,16,32,64,128,183,0,31,48,136,41,216,96,89,42,80,30,96,26,32,65,120,160,16,48,217,122,163,95,32,183,211,42,0]

theorem envBound59320 : H12AffineFastState.Bounded env59320 := by
  intro p hp
  have h : env59320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59319_59320 : H12AffineEnvironment.transform 7 183 env59319 = env59320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env59319 == env59320) = true)

theorem identity59320 : scanCanonicalize (H12AffineFastState.compose env59320 (packedSelected [1,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59320 : packedSelected [1,6,9] rootPS < 2^1333 := by decide +kernel

def env59321 : List Nat := [2,4,8,16,32,64,114,69,0,31,48,122,41,42,96,89,42,80,30,96,26,32,65,120,82,16,48,43,122,81,95,32,69,33,42,0]

theorem envBound59321 : H12AffineFastState.Bounded env59321 := by
  intro p hp
  have h : env59321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59320_59321 : H12AffineEnvironment.transform 6 114 env59320 = env59321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59320 == env59321) = true)

def env59322 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1288,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59322 : H12AffineFastState.Bounded env59322 := by
  intro p hp
  have h : env59322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59300_59322 : H12AffineEnvironment.transform 8 1 env59300 = env59322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59300 == env59322) = true)

theorem identity59322 : scanCanonicalize (H12AffineFastState.compose env59322 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59323 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,1028,1416,9664,3158,1288,9617,269680,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound59323 : H12AffineFastState.Bounded env59323 := by
  intro p hp
  have h : env59323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59322_59323 : H12AffineEnvironment.transform 20 1028 env59322 = env59323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59322 == env59323) = true)

def env59324 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,1028,1416,64,3158,1288,17,269680,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound59324 : H12AffineFastState.Bounded env59324 := by
  intro p hp
  have h : env59324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59323_59324 : H12AffineEnvironment.transform 12 1408 env59323 = env59324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59323 == env59324) = true)

theorem identity59324 : scanCanonicalize (H12AffineFastState.compose env59324 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3577) := by decide +kernel

theorem selectedBound59324 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59325 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3577,1408,3497,2129,65536,67755,262144,1025,2129,1028,1416,64,3158,1288,17,262281,3496,67835,66899,65542,68095,256,65674,67755,0]

theorem envBound59325 : H12AffineFastState.Bounded env59325 := by
  intro p hp
  have h : env59325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59324_59325 : H12AffineEnvironment.transform 11 3577 env59324 = env59325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3577 env59324 == env59325) = true)

theorem identity59325 : scanCanonicalize (H12AffineFastState.compose env59325 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59325 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59326 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1448,65536,66898,262144,1025,1448,1028,1416,64,431,1288,17,262281,81,66818,66899,65542,66566,256,65674,66898,0]

theorem envBound59326 : H12AffineFastState.Bounded env59326 := by
  intro p hp
  have h : env59326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59325_59326 : H12AffineEnvironment.transform 10 1529 env59325 = env59326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59325 == env59326) = true)

theorem identity59326 : scanCanonicalize (H12AffineFastState.compose env59326 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound59326 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59327 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1448,65536,66898,1513,1025,1448,1028,1416,64,431,1288,17,1376,81,66818,66899,65542,66566,256,65674,66898,0]

theorem envBound59327 : H12AffineFastState.Bounded env59327 := by
  intro p hp
  have h : env59327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59326_59327 : H12AffineEnvironment.transform 17 1513 env59326 = env59327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env59326 == env59327) = true)

theorem identity59327 : scanCanonicalize (H12AffineFastState.compose env59327 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59327 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59328 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,0,1408,80,1448,1062,372,1513,1025,1448,1028,1416,64,431,1288,17,1376,81,292,373,1056,32,256,1196,372,0]

theorem envBound59328 : H12AffineFastState.Bounded env59328 := by
  intro p hp
  have h : env59328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59327_59328 : H12AffineEnvironment.transform 15 1062 env59327 = env59328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59327 == env59328) = true)

theorem identity59328 : scanCanonicalize (H12AffineFastState.compose env59328 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59328 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59329 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,0,348,80,372,250,372,309,221,372,216,340,64,431,468,17,444,81,292,373,252,32,256,112,372,0]

theorem envBound59329 : H12AffineFastState.Bounded env59329 := by
  intro p hp
  have h : env59329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59328_59329 : H12AffineEnvironment.transform 9 220 env59328 = env59329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59328 == env59329) = true)

theorem identity59329 : scanCanonicalize (H12AffineFastState.compose env59329 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59329 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59330 : List Nat := [2,4,8,16,32,64,128,173,1,220,136,0,241,80,217,250,217,152,221,217,216,249,64,2,121,17,17,81,137,216,252,32,173,112,217,0]

theorem envBound59330 : H12AffineFastState.Bounded env59330 := by
  intro p hp
  have h : env59330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59329_59330 : H12AffineEnvironment.transform 7 173 env59329 = env59330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59329 == env59330) = true)

theorem identity59330 : scanCanonicalize (H12AffineFastState.compose env59330 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound59330 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env59331 : List Nat := [2,4,8,16,2,64,128,143,1,220,136,0,211,80,217,216,217,152,221,217,216,219,64,2,91,17,17,81,137,216,222,2,143,82,217,0]

theorem envBound59331 : H12AffineFastState.Bounded env59331 := by
  intro p hp
  have h : env59331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59330_59331 : H12AffineEnvironment.transform 4 2 env59330 = env59331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env59330 == env59331) = true)

theorem identity59331 : scanCanonicalize (H12AffineFastState.compose env59331 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound59331 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59332 : List Nat := [2,4,8,16,2,18,128,143,1,142,136,0,129,2,139,138,139,152,143,139,138,137,18,2,9,17,17,3,137,138,140,2,143,0,139,0]

theorem envBound59332 : H12AffineFastState.Bounded env59332 := by
  intro p hp
  have h : env59332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59331_59332 : H12AffineEnvironment.transform 5 18 env59331 = env59332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env59331 == env59332) = true)

theorem identity59332 : scanCanonicalize (H12AffineFastState.compose env59332 (packedSelected [0,4,6] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59332 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env59333 : List Nat := [2,4,8,9,2,11,128,143,1,142,136,0,129,2,139,138,139,129,143,139,138,137,11,2,9,8,8,3,137,138,140,2,143,0,139,0]

theorem envBound59333 : H12AffineFastState.Bounded env59333 := by
  intro p hp
  have h : env59333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59332_59333 : H12AffineEnvironment.transform 3 9 env59332 = env59333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59332 == env59333) = true)

theorem identity59333 : scanCanonicalize (H12AffineFastState.compose env59333 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59333 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env59334 : List Nat := [2,4,8,9,2,11,0,15,1,14,8,0,1,2,11,10,11,1,15,11,10,9,11,2,9,8,8,3,9,10,12,2,15,0,11,0]

theorem envBound59334 : H12AffineFastState.Bounded env59334 := by
  intro p hp
  have h : env59334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59333_59334 : H12AffineEnvironment.transform 6 0 env59333 = env59334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59333 == env59334) = true)

theorem identity59334 : scanCanonicalize (H12AffineFastState.compose env59334 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59334 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59335 : List Nat := [0,4,8,9,0,9,0,13,1,12,8,0,1,0,9,8,9,1,13,9,8,9,9,0,9,8,8,1,9,8,12,0,13,0,9,0]

theorem envBound59335 : H12AffineFastState.Bounded env59335 := by
  intro p hp
  have h : env59335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59334_59335 : H12AffineEnvironment.transform 0 0 env59334 = env59335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59334 == env59335) = true)

def env59336 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,1028,1416,65,3158,1288,16,269680,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound59336 : H12AffineFastState.Bounded env59336 := by
  intro p hp
  have h : env59336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59323_59336 : H12AffineEnvironment.transform 12 1409 env59323 = env59336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59323 == env59336) = true)

theorem identity59336 : scanCanonicalize (H12AffineFastState.compose env59336 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59336 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59337 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,1028,1416,65,3158,1288,16,269680,4177,2557,6573,7416,5377,256,7284,2477,1]

theorem envBound59337 : H12AffineFastState.Bounded env59337 := by
  intro p hp
  have h : env59337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59336_59337 : H12AffineEnvironment.transform 15 7422 env59336 = env59337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59336 == env59337) = true)

theorem identity59337 : scanCanonicalize (H12AffineFastState.compose env59337 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59337 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59338 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,3528,1025,2129,1028,1416,65,3158,1288,16,4280,4177,2557,6573,7416,5377,256,7284,2477,1]

theorem envBound59338 : H12AffineFastState.Bounded env59338 := by
  intro p hp
  have h : env59338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59337_59338 : H12AffineEnvironment.transform 17 3528 env59337 = env59338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59337 == env59338) = true)

theorem identity59338 : scanCanonicalize (H12AffineFastState.compose env59338 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59338 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59339 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,4096,1409,4176,96,5327,412,1529,1025,96,1028,1416,65,1127,1288,16,4280,4177,460,4508,5321,5377,256,5189,412,1]

theorem envBound59339 : H12AffineFastState.Bounded env59339 := by
  intro p hp
  have h : env59339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59338_59339 : H12AffineEnvironment.transform 10 49 env59338 = env59339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59338 == env59339) = true)

theorem identity59339 : scanCanonicalize (H12AffineFastState.compose env59339 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59339 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59340 : List Nat := [2,4,8,16,32,64,128,69,1,1024,49,4096,1220,4176,96,5327,217,1212,1025,96,1028,1229,65,1127,1101,16,4280,4177,137,4313,5321,5188,69,5189,217,1]

theorem envBound59340 : H12AffineFastState.Bounded env59340 := by
  intro p hp
  have h : env59340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59339_59340 : H12AffineEnvironment.transform 7 69 env59339 = env59340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59339 == env59340) = true)

theorem identity59340 : scanCanonicalize (H12AffineFastState.compose env59340 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59340 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59341 : List Nat := [2,4,8,16,32,64,128,69,1,1024,49,137,1220,217,96,1094,217,1212,1025,96,1028,1229,65,1127,1101,16,49,216,137,80,1088,1229,69,1228,217,1]

theorem envBound59341 : H12AffineFastState.Bounded env59341 := by
  intro p hp
  have h : env59341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59340_59341 : H12AffineEnvironment.transform 11 137 env59340 = env59341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59340 == env59341) = true)

def env59342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3670,1289,9616,2366325,4177,77954,67410,65543,68607,256,65674,78034,10112]

theorem envBound59342 : H12AffineFastState.Bounded env59342 := by
  intro p hp
  have h : env59342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59299_59342 : H12AffineEnvironment.transform 22 9665 env59299 = env59342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59299 == env59342) = true)

def env59343 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound59343 : H12AffineFastState.Bounded env59343 := by
  intro p hp
  have h : env59343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59342_59343 : H12AffineEnvironment.transform 8 0 env59342 = env59343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59342 == env59343) = true)

theorem identity59343 : scanCanonicalize (H12AffineFastState.compose env59343 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59344 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,8192,3076,2128,65536,76934,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2360609,3077,77014,66898,65543,68095,256,65674,76934,9600]

theorem envBound59344 : H12AffineFastState.Bounded env59344 := by
  intro p hp
  have h : env59344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59343_59344 : H12AffineEnvironment.transform 11 3156 env59343 = env59344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59343 == env59344) = true)

def env59345 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,2097152,1416,65,3158,1289,16,2360609,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59345 : H12AffineFastState.Bounded env59345 := by
  intro p hp
  have h : env59345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59344_59345 : H12AffineEnvironment.transform 12 1408 env59344 = env59345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59344 == env59345) = true)

theorem identity59345 : scanCanonicalize (H12AffineFastState.compose env59345 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59345 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59346 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,66734,1416,65,3158,1289,16,328079,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59346 : H12AffineFastState.Bounded env59346 := by
  intro p hp
  have h : env59346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59345_59346 : H12AffineEnvironment.transform 20 66734 env59345 = env59346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59345 == env59346) = true)

theorem identity59346 : scanCanonicalize (H12AffineFastState.compose env59346 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59346 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59347 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,68962,1025,2128,66734,1416,65,3158,1289,16,3309,3077,67926,66898,65543,68095,256,65674,67846,0]

theorem envBound59347 : H12AffineFastState.Bounded env59347 := by
  intro p hp
  have h : env59347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59346_59347 : H12AffineEnvironment.transform 17 68962 env59346 = env59347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59346 == env59347) = true)

theorem identity59347 : scanCanonicalize (H12AffineFastState.compose env59347 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59347 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59348 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,2203,413,1529,1025,2128,3125,1416,65,3158,1289,16,3309,3077,461,3529,2204,356,256,2065,413,0]

theorem envBound59348 : H12AffineFastState.Bounded env59348 := by
  intro p hp
  have h : env59348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59347_59348 : H12AffineEnvironment.transform 15 2203 env59347 = env59348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59347 == env59348) = true)

theorem identity59348 : scanCanonicalize (H12AffineFastState.compose env59348 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound59348 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59349 : List Nat := [2,4,8,16,32,64,128,256,0,1024,372,1312,1408,1392,292,495,413,1529,1025,292,1345,1416,65,1314,1289,16,1433,1393,461,1213,488,356,256,357,413,0]

theorem envBound59349 : H12AffineFastState.Bounded env59349 := by
  intro p hp
  have h : env59349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59348_59349 : H12AffineEnvironment.transform 10 372 env59348 = env59349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env59348 == env59349) = true)

theorem identity59349 : scanCanonicalize (H12AffineFastState.compose env59349 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59349 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59350 : List Nat := [2,4,8,16,32,64,128,256,0,237,372,461,365,413,292,495,413,276,236,292,428,357,65,463,484,16,372,412,461,80,488,356,256,357,413,0]

theorem envBound59350 : H12AffineFastState.Bounded env59350 := by
  intro p hp
  have h : env59350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59349_59350 : H12AffineEnvironment.transform 9 237 env59349 = env59350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59349 == env59350) = true)

def env59351 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,2097152,1416,64,3158,1289,17,2360609,3077,67927,66898,65543,68095,256,65674,67847,1]

theorem envBound59351 : H12AffineFastState.Bounded env59351 := by
  intro p hp
  have h : env59351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59344_59351 : H12AffineEnvironment.transform 12 1409 env59344 = env59351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59344 == env59351) = true)

theorem identity59351 : scanCanonicalize (H12AffineFastState.compose env59351 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59351 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59352 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,1448,1416,64,3158,1289,17,262281,3077,67927,66898,65543,68095,256,65674,67847,1]

theorem envBound59352 : H12AffineFastState.Bounded env59352 := by
  intro p hp
  have h : env59352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59351_59352 : H12AffineEnvironment.transform 20 1448 env59351 = env59352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59351 == env59352) = true)

theorem identity59352 : scanCanonicalize (H12AffineFastState.compose env59352 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59352 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59353 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1448,65536,66815,262144,1025,1448,1448,1416,64,430,1289,17,262281,509,66735,66898,65543,66567,256,65674,66815,1]

theorem envBound59353 : H12AffineFastState.Bounded env59353 := by
  intro p hp
  have h : env59353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59352_59353 : H12AffineEnvironment.transform 10 1528 env59352 = env59353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59352 == env59353) = true)

theorem identity59353 : scanCanonicalize (H12AffineFastState.compose env59353 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59353 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59354 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,428,1409,508,1448,65536,66815,1093,1025,1448,1448,1416,64,430,1289,17,1228,509,66735,66898,65543,66567,256,65674,66815,1]

theorem envBound59354 : H12AffineFastState.Bounded env59354 := by
  intro p hp
  have h : env59354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59353_59354 : H12AffineEnvironment.transform 17 1093 env59353 = env59354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59353 == env59354) = true)

theorem identity59354 : scanCanonicalize (H12AffineFastState.compose env59354 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

end H12CloudChart1