import H12CloudChart1Data225

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity57251 : scanCanonicalize (H12AffineFastState.compose env57251 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound57251 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57252 : List Nat := [2,4,8,16,32,64,88,256,90,94,270,1,301,80,340,3,293,74,94,340,271,32,334,41,380,287,277,80,373,43,289,113,257,11,292,90]

theorem envBound57252 : H12AffineFastState.Bounded env57252 := by
  intro p hp
  have h : env57252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57251_57252 : H12AffineEnvironment.transform 8 90 env57251 = env57252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env57251 == env57252) = true)

theorem identity57252 : scanCanonicalize (H12AffineFastState.compose env57252 (packedSelected [4,7,13] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57252 : packedSelected [4,7,13] rootPS < 2^1333 := by decide +kernel

def env57253 : List Nat := [2,4,8,16,32,11,19,256,17,21,270,1,301,27,287,3,293,1,21,287,271,32,261,41,311,287,277,27,318,43,289,58,257,11,292,17]

theorem envBound57253 : H12AffineFastState.Bounded env57253 := by
  intro p hp
  have h : env57253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57252_57253 : H12AffineEnvironment.transform 5 11 env57252 = env57253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57252 == env57253) = true)

def env57254 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,4096,300,4177,340,2,4389,4171,1024,340,5456,32,1296,1143,380,1345,5451,4177,4469,1583,288,112,257,1109,4388,512]

theorem envBound57254 : H12AffineFastState.Bounded env57254 := by
  intro p hp
  have h : env57254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57243_57254 : H12AffineEnvironment.transform 6 89 env57243 = env57254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57243 == env57254) = true)

def env57255 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,0,300,81,340,2,293,75,1024,340,1360,32,1296,1143,380,1345,1355,81,373,1583,288,112,257,1109,292,512]

theorem envBound57255 : H12AffineFastState.Bounded env57255 := by
  intro p hp
  have h : env57255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57254_57255 : H12AffineEnvironment.transform 11 0 env57254 = env57255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57254 == env57255) = true)

theorem identity57255 : scanCanonicalize (H12AffineFastState.compose env57255 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound57255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57256 : List Nat := [2,4,8,16,32,64,89,256,512,368,634,0,300,81,340,2,293,75,368,340,32,32,96,263,380,49,59,81,373,863,288,112,257,293,292,512]

theorem envBound57256 : H12AffineFastState.Bounded env57256 := by
  intro p hp
  have h : env57256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57255_57256 : H12AffineEnvironment.transform 9 368 env57255 = env57256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env57255 == env57256) = true)

theorem identity57256 : scanCanonicalize (H12AffineFastState.compose env57256 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57256 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57257 : List Nat := [2,4,8,16,32,64,89,79,512,63,634,0,99,81,27,2,106,75,63,27,32,32,96,72,51,49,59,81,58,528,111,112,78,106,107,512]

theorem envBound57257 : H12AffineFastState.Bounded env57257 := by
  intro p hp
  have h : env57257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57256_57257 : H12AffineEnvironment.transform 7 79 env57256 = env57257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57256 == env57257) = true)

def env57258 : List Nat := [2,4,8,16,32,48,41,63,512,63,522,0,19,33,27,2,26,59,63,27,32,32,16,56,51,49,59,33,58,528,31,0,62,26,27,512]

theorem envBound57258 : H12AffineFastState.Bounded env57258 := by
  intro p hp
  have h : env57258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57257_57258 : H12AffineEnvironment.transform 5 48 env57257 = env57258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57257 == env57258) = true)

theorem identity57258 : scanCanonicalize (H12AffineFastState.compose env57258 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57259 : List Nat := [2,4,8,16,32,48,41,63,11,63,1,0,19,33,27,2,26,59,63,27,32,32,16,56,51,49,59,33,58,27,31,0,62,26,27,11]

theorem envBound57259 : H12AffineFastState.Bounded env57259 := by
  intro p hp
  have h : env57259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57258_57259 : H12AffineEnvironment.transform 8 11 env57258 = env57259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57258 == env57259) = true)

theorem identity57259 : scanCanonicalize (H12AffineFastState.compose env57259 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57259 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57260 : List Nat := [2,4,8,10,32,42,41,37,11,37,1,0,9,33,1,2,0,33,37,1,32,32,10,34,41,43,33,33,32,1,5,0,36,0,1,11]

theorem envBound57260 : H12AffineFastState.Bounded env57260 := by
  intro p hp
  have h : env57260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57259_57260 : H12AffineEnvironment.transform 3 10 env57259 = env57260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57259 == env57260) = true)

theorem identity57260 : scanCanonicalize (H12AffineFastState.compose env57260 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57260 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57261 : List Nat := [2,4,8,10,11,1,2,14,11,14,1,0,9,10,1,2,0,10,14,1,11,11,10,9,2,0,10,10,11,1,5,0,15,0,1,11]

theorem envBound57261 : H12AffineFastState.Bounded env57261 := by
  intro p hp
  have h : env57261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57260_57261 : H12AffineEnvironment.transform 4 11 env57260 = env57261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57260 == env57261) = true)

def env57262 : List Nat := [2,4,8,16,32,49,40,62,512,63,523,0,18,32,27,2,27,58,63,27,32,32,17,57,51,49,59,32,58,528,30,1,63,27,26,512]

theorem envBound57262 : H12AffineFastState.Bounded env57262 := by
  intro p hp
  have h : env57262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57257_57262 : H12AffineEnvironment.transform 5 49 env57257 = env57262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57257 == env57262) = true)

theorem identity57262 : scanCanonicalize (H12AffineFastState.compose env57262 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound57262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57263 : List Nat := [2,4,8,16,32,49,40,62,17,63,26,0,18,32,27,2,27,58,63,27,32,32,17,57,51,49,59,32,58,1,30,1,63,27,26,17]

theorem envBound57263 : H12AffineFastState.Bounded env57263 := by
  intro p hp
  have h : env57263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57262_57263 : H12AffineEnvironment.transform 8 17 env57262 = env57263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env57262 == env57263) = true)

def env57264 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1802,1,300,80,340,2,292,74,1024,340,1361,32,1296,1143,380,1345,1354,80,372,1583,288,112,257,1109,293,512]

theorem envBound57264 : H12AffineFastState.Bounded env57264 := by
  intro p hp
  have h : env57264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57254_57264 : H12AffineEnvironment.transform 11 1 env57254 = env57264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57254 == env57264) = true)

theorem identity57264 : scanCanonicalize (H12AffineFastState.compose env57264 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound57264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57265 : List Nat := [2,4,8,16,32,64,89,256,97,1024,1387,1,300,80,340,2,292,74,1024,340,1361,32,1296,1143,380,1345,1354,80,372,1102,288,112,257,1109,293,97]

theorem envBound57265 : H12AffineFastState.Bounded env57265 := by
  intro p hp
  have h : env57265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57264_57265 : H12AffineEnvironment.transform 8 97 env57264 = env57265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env57264 == env57265) = true)

theorem identity57265 : scanCanonicalize (H12AffineFastState.compose env57265 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57265 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57266 : List Nat := [2,4,8,11,32,64,66,256,97,1024,1387,1,300,75,335,2,292,74,1024,335,1354,32,1291,1132,359,1345,1354,75,367,1102,288,107,257,1102,293,97]

theorem envBound57266 : H12AffineFastState.Bounded env57266 := by
  intro p hp
  have h : env57266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57265_57266 : H12AffineEnvironment.transform 3 11 env57265 = env57266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57265 == env57266) = true)

theorem identity57266 : scanCanonicalize (H12AffineFastState.compose env57266 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57266 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57267 : List Nat := [2,4,8,11,32,64,66,79,97,1024,1060,1,99,75,0,2,107,74,1024,0,1029,32,1092,1132,40,1038,1029,75,32,1102,111,107,78,1102,106,97]

theorem envBound57267 : H12AffineFastState.Bounded env57267 := by
  intro p hp
  have h : env57267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57266_57267 : H12AffineEnvironment.transform 7 79 env57266 = env57267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57266 == env57267) = true)

theorem identity57267 : scanCanonicalize (H12AffineFastState.compose env57267 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound57267 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57268 : List Nat := [2,4,8,11,32,64,66,79,97,36,0,1,99,75,0,2,107,74,36,0,33,32,96,72,40,42,33,75,32,106,111,107,78,106,106,97]

theorem envBound57268 : H12AffineFastState.Bounded env57268 := by
  intro p hp
  have h : env57268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57267_57268 : H12AffineEnvironment.transform 9 36 env57267 = env57268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env57267 == env57268) = true)

def env57269 : List Nat := [2,4,8,11,32,32,34,47,1,36,0,1,3,43,0,2,11,42,36,0,33,32,0,40,40,42,33,43,32,10,15,11,46,10,10,1]

theorem envBound57269 : H12AffineFastState.Bounded env57269 := by
  intro p hp
  have h : env57269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57268_57269 : H12AffineEnvironment.transform 5 32 env57268 = env57269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57268 == env57269) = true)

theorem identity57269 : scanCanonicalize (H12AffineFastState.compose env57269 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57269 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57270 : List Nat := [2,4,3,0,32,32,34,36,1,36,0,1,3,32,0,2,0,33,36,0,33,32,0,35,35,33,33,32,32,1,4,0,37,1,1,1]

theorem envBound57270 : H12AffineFastState.Bounded env57270 := by
  intro p hp
  have h : env57270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57269_57270 : H12AffineEnvironment.transform 2 3 env57269 = env57270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57269 == env57270) = true)

def env57271 : List Nat := [2,4,8,11,32,33,35,46,0,36,0,1,2,42,0,2,10,43,36,0,33,32,1,41,40,42,33,42,32,11,14,10,47,11,11,0]

theorem envBound57271 : H12AffineFastState.Bounded env57271 := by
  intro p hp
  have h : env57271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57268_57271 : H12AffineEnvironment.transform 5 33 env57268 = env57271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57268 == env57271) = true)

def env57272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,10798237,16384,77954,4315355,8463815,10564039,257,6406395,78035,33563273]

theorem envBound57272 : H12AffineFastState.Bounded env57272 := by
  intro p hp
  have h : env57272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56825_57272 : H12AffineEnvironment.transform 26 10798237 env56825 = env57272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 10798237 env56825 == env57272) = true)

def env57273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,4247640,8409088,10798237,16384,77954,4315355,8463815,10564039,257,6406395,78035,4256465]

theorem envBound57273 : H12AffineFastState.Bounded env57273 := by
  intro p hp
  have h : env57273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57272_57273 : H12AffineEnvironment.transform 24 4247640 env57272 = env57273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env57272 == env57273) = true)

def env57274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4486237,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound57274 : H12AffineFastState.Bounded env57274 := by
  intro p hp
  have h : env57274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57273_57274 : H12AffineEnvironment.transform 22 6336704 env57273 = env57274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env57273 == env57274) = true)

def env57275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4273309,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound57275 : H12AffineFastState.Bounded env57275 := by
  intro p hp
  have h : env57275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57274_57275 : H12AffineEnvironment.transform 17 82112 env57274 = env57275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57274 == env57275) = true)

def env57276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142598,28888,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57276 : H12AffineFastState.Bounded env57276 := by
  intro p hp
  have h : env57276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57275_57276 : H12AffineEnvironment.transform 21 41088 env57275 = env57276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57275 == env57276) = true)

theorem identity57276 : scanCanonicalize (H12AffineFastState.compose env57276 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound57276 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,78034,82112,1024,30112,2097152,21792,2101312,2114598,28888,2113600,90557,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57277 : H12AffineFastState.Bounded env57277 := by
  intro p hp
  have h : env57277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57276_57277 : H12AffineEnvironment.transform 14 30112 env57276 = env57277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env57276 == env57277) = true)

theorem identity57277 : scanCanonicalize (H12AffineFastState.compose env57277 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57277 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,78034,82112,1024,30112,83418,21792,87450,66044,28888,66970,90557,16384,77954,96347,28765,74119,257,9633,78035,21073]

theorem envBound57278 : H12AffineFastState.Bounded env57278 := by
  intro p hp
  have h : env57278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57277_57278 : H12AffineEnvironment.transform 20 83418 env57277 = env57278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57277 == env57278) = true)

theorem identity57278 : scanCanonicalize (H12AffineFastState.compose env57278 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57278 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,65536,78034,69777,1024,9713,71051,1393,67019,66044,8329,66970,78316,4177,77954,75786,8204,74119,257,9633,78035,512]

theorem envBound57279 : H12AffineFastState.Bounded env57279 := by
  intro p hp
  have h : env57279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57278_57279 : H12AffineEnvironment.transform 13 4177 env57278 = env57279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57278 == env57279) = true)

theorem identity57279 : scanCanonicalize (H12AffineFastState.compose env57279 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound57279 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9713,9342,5292,13551,1024,9713,12789,1393,8629,9602,8329,8676,5522,4177,5372,3188,8204,1529,257,9633,5293,512]

theorem envBound57280 : H12AffineFastState.Bounded env57280 := by
  intro p hp
  have h : env57280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57279_57280 : H12AffineEnvironment.transform 15 9342 env57279 = env57280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env57279 == env57280) = true)

theorem identity57280 : scanCanonicalize (H12AffineFastState.compose env57280 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound57280 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,2830,2689,5292,6672,1024,2830,7946,1393,3914,2941,3702,3867,5522,4177,5372,3188,3827,1529,257,2910,5293,512]

theorem envBound57281 : H12AffineFastState.Bounded env57281 := by
  intro p hp
  have h : env57281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57280_57281 : H12AffineEnvironment.transform 12 3839 env57280 = env57281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env57280 == env57281) = true)

theorem identity57281 : scanCanonicalize (H12AffineFastState.compose env57281 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound57281 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57282 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,4096,2990,4177,2830,2689,4605,6672,337,2830,6747,32,2587,2941,2855,2634,4291,4177,4525,2341,2978,168,257,2910,4604,512]

theorem envBound57282 : H12AffineFastState.Bounded env57282 := by
  intro p hp
  have h : env57282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57281_57282 : H12AffineEnvironment.transform 9 337 env57281 = env57282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57281 == env57282) = true)

def env57283 : List Nat := [2,4,8,16,32,64,128,4,512,85,2048,4096,2730,4177,2570,2689,4345,6672,85,2570,6747,32,2587,2681,2595,2634,4291,4177,4265,2081,2726,168,5,2650,4344,512]

theorem envBound57283 : H12AffineFastState.Bounded env57283 := by
  intro p hp
  have h : env57283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57282_57283 : H12AffineEnvironment.transform 7 4 env57282 = env57283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57282 == env57283) = true)

def env57284 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,4096,2730,4129,2570,2689,4233,6672,37,2570,6699,32,2587,2569,2595,2618,4275,4129,4265,2081,2726,168,5,2602,4232,512]

theorem envBound57284 : H12AffineFastState.Bounded env57284 := by
  intro p hp
  have h : env57284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57283_57284 : H12AffineEnvironment.transform 5 48 env57283 = env57284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57283 == env57284) = true)

theorem identity57284 : scanCanonicalize (H12AffineFastState.compose env57284 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound57284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57285 : List Nat := [2,4,8,16,32,48,128,4,512,37,2048,2217,2730,2184,2570,2689,2080,697,37,2570,642,32,2587,2569,2595,2618,2074,2184,2048,2081,2726,168,5,2602,2081,512]

theorem envBound57285 : H12AffineFastState.Bounded env57285 := by
  intro p hp
  have h : env57285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57284_57285 : H12AffineEnvironment.transform 11 2217 env57284 = env57285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env57284 == env57285) = true)

def env57286 : List Nat := [2,4,8,16,32,48,128,4,512,37,648,545,34,512,130,9,680,697,37,130,642,32,147,129,171,178,658,512,648,681,46,168,5,162,681,512]

theorem envBound57286 : H12AffineFastState.Bounded env57286 := by
  intro p hp
  have h : env57286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57285_57286 : H12AffineEnvironment.transform 10 648 env57285 = env57286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57285 == env57286) = true)

theorem identity57286 : scanCanonicalize (H12AffineFastState.compose env57286 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57286 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57287 : List Nat := [2,4,8,16,32,48,56,4,512,37,560,545,34,512,58,9,528,513,37,58,570,32,43,57,19,10,554,512,560,529,46,16,5,26,529,512]

theorem envBound57287 : H12AffineFastState.Bounded env57287 := by
  intro p hp
  have h : env57287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57286_57287 : H12AffineEnvironment.transform 6 56 env57286 = env57287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57286 == env57287) = true)

def env57288 : List Nat := [2,4,8,16,32,48,128,4,512,37,649,544,35,513,131,8,681,697,37,131,642,32,146,128,170,179,659,513,649,680,47,168,5,163,680,512]

theorem envBound57288 : H12AffineFastState.Bounded env57288 := by
  intro p hp
  have h : env57288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57285_57288 : H12AffineEnvironment.transform 10 649 env57285 = env57288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57285 == env57288) = true)

theorem identity57288 : scanCanonicalize (H12AffineFastState.compose env57288 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57288 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57289 : List Nat := [2,4,8,16,32,48,51,4,512,37,570,544,35,513,48,8,538,522,37,48,561,32,33,51,25,0,544,513,570,539,47,27,5,16,539,512]

theorem envBound57289 : H12AffineFastState.Bounded env57289 := by
  intro p hp
  have h : env57289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57288_57289 : H12AffineEnvironment.transform 6 51 env57288 = env57289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57288 == env57289) = true)

theorem identity57289 : scanCanonicalize (H12AffineFastState.compose env57289 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57289 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57290 : List Nat := [2,4,2,16,32,48,51,4,512,37,560,544,35,513,48,2,528,512,37,48,561,32,33,51,19,0,544,513,560,529,37,17,5,16,529,512]

theorem envBound57290 : H12AffineFastState.Bounded env57290 := by
  intro p hp
  have h : env57290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57289_57290 : H12AffineEnvironment.transform 2 2 env57289 = env57290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57289 == env57290) = true)

def env57291 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,4096,2730,4128,2570,2689,4232,6672,36,2570,6698,32,2587,2568,2595,2619,4274,4128,4265,2081,2726,168,5,2603,4233,512]

theorem envBound57291 : H12AffineFastState.Bounded env57291 := by
  intro p hp
  have h : env57291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57283_57291 : H12AffineEnvironment.transform 5 49 env57283 = env57291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57283 == env57291) = true)

theorem identity57291 : scanCanonicalize (H12AffineFastState.compose env57291 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound57291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57292 : List Nat := [2,4,8,16,32,49,128,4,512,36,2048,2049,2730,2081,2570,2689,2185,529,36,2570,555,32,2587,2568,2595,2619,2227,2081,2216,2081,2726,168,5,2603,2184,512]

theorem envBound57292 : H12AffineFastState.Bounded env57292 := by
  intro p hp
  have h : env57292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57291_57292 : H12AffineEnvironment.transform 11 2049 env57291 = env57292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env57291 == env57292) = true)

def env57293 : List Nat := [2,4,8,16,0,17,128,4,512,4,2048,2049,2698,2049,2570,2689,2185,529,4,2570,523,0,2587,2568,2563,2587,2195,2049,2184,2049,2694,136,5,2571,2184,512]

theorem envBound57293 : H12AffineFastState.Bounded env57293 := by
  intro p hp
  have h : env57293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57292_57293 : H12AffineEnvironment.transform 4 0 env57292 = env57293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57292 == env57293) = true)

theorem identity57293 : scanCanonicalize (H12AffineFastState.compose env57293 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57293 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57294 : List Nat := [2,4,8,11,0,10,128,4,512,4,2048,2049,2698,2049,2570,2689,2185,522,4,2570,523,0,2560,2568,2563,2560,2184,2049,2184,2049,2694,136,5,2571,2184,512]

theorem envBound57294 : H12AffineFastState.Bounded env57294 := by
  intro p hp
  have h : env57294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57293_57294 : H12AffineEnvironment.transform 3 11 env57293 = env57294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57293 == env57294) = true)

theorem identity57294 : scanCanonicalize (H12AffineFastState.compose env57294 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57294 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57295 : List Nat := [2,4,8,11,0,10,128,4,512,4,1,0,651,0,523,640,136,522,4,523,523,0,513,521,514,513,137,0,137,0,647,136,5,522,137,512]

theorem envBound57295 : H12AffineFastState.Bounded env57295 := by
  intro p hp
  have h : env57295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57294_57295 : H12AffineEnvironment.transform 10 1 env57294 = env57295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57294 == env57295) = true)

theorem identity57295 : scanCanonicalize (H12AffineFastState.compose env57295 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound57295 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57296 : List Nat := [2,4,8,11,0,10,128,4,137,4,1,0,2,0,130,9,136,131,4,130,130,0,136,128,139,136,137,0,137,0,14,136,5,131,137,137]

theorem envBound57296 : H12AffineFastState.Bounded env57296 := by
  intro p hp
  have h : env57296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57295_57296 : H12AffineEnvironment.transform 8 137 env57295 = env57296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env57295 == env57296) = true)

theorem identity57296 : scanCanonicalize (H12AffineFastState.compose env57296 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57297 : List Nat := [2,4,3,0,0,1,128,4,130,4,1,0,2,0,130,2,131,131,4,130,130,0,131,128,128,131,130,0,130,0,5,131,5,131,130,130]

theorem envBound57297 : H12AffineFastState.Bounded env57297 := by
  intro p hp
  have h : env57297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57296_57297 : H12AffineEnvironment.transform 2 3 env57296 = env57297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57296 == env57297) = true)

theorem identity57297 : scanCanonicalize (H12AffineFastState.compose env57297 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57297 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57298 : List Nat := [2,4,3,0,0,1,3,4,1,4,1,0,2,0,1,2,0,0,4,1,1,0,0,3,3,0,1,0,1,0,5,0,5,0,1,1]

theorem envBound57298 : H12AffineFastState.Bounded env57298 := by
  intro p hp
  have h : env57298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57297_57298 : H12AffineEnvironment.transform 6 3 env57297 = env57298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57297 == env57298) = true)

def env57299 : List Nat := [2,4,8,16,1,16,128,4,512,5,2048,2049,2699,2048,2570,2689,2185,529,5,2570,522,1,2587,2568,2562,2586,2194,2048,2185,2048,2695,137,5,2570,2184,512]

theorem envBound57299 : H12AffineFastState.Bounded env57299 := by
  intro p hp
  have h : env57299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57292_57299 : H12AffineEnvironment.transform 4 1 env57292 = env57299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57292 == env57299) = true)

theorem identity57299 : scanCanonicalize (H12AffineFastState.compose env57299 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57299 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57300 : List Nat := [2,4,8,0,1,0,128,4,512,5,2048,2049,2699,2048,2570,2689,2185,513,5,2570,522,1,2571,2568,2562,2570,2178,2048,2185,2048,2695,137,5,2570,2184,512]

theorem envBound57300 : H12AffineFastState.Bounded env57300 := by
  intro p hp
  have h : env57300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57299_57300 : H12AffineEnvironment.transform 3 0 env57299 = env57300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57299 == env57300) = true)

theorem identity57300 : scanCanonicalize (H12AffineFastState.compose env57300 (packedSelected [4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound57300 : packedSelected [4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57301 : List Nat := [2,4,8,0,1,0,128,4,512,5,649,648,2,649,131,8,512,513,5,131,522,1,130,129,139,131,523,649,512,649,14,137,5,131,513,512]

theorem envBound57301 : H12AffineFastState.Bounded env57301 := by
  intro p hp
  have h : env57301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57300_57301 : H12AffineEnvironment.transform 10 649 env57300 = env57301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57300 == env57301) = true)

theorem identity57301 : scanCanonicalize (H12AffineFastState.compose env57301 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound57301 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57302 : List Nat := [2,4,8,0,1,0,128,4,137,5,0,1,2,0,131,8,137,136,5,131,131,1,130,129,139,131,130,0,137,0,14,137,5,131,136,137]

theorem envBound57302 : H12AffineFastState.Bounded env57302 := by
  intro p hp
  have h : env57302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57301_57302 : H12AffineEnvironment.transform 8 137 env57301 = env57302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env57301 == env57302) = true)

theorem identity57302 : scanCanonicalize (H12AffineFastState.compose env57302 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57303 : List Nat := [2,4,2,0,1,0,128,4,131,5,0,1,2,0,131,2,131,130,5,131,131,1,130,129,129,131,130,0,131,0,4,131,5,131,130,131]

theorem envBound57303 : H12AffineFastState.Bounded env57303 := by
  intro p hp
  have h : env57303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57302_57303 : H12AffineEnvironment.transform 2 2 env57302 = env57303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57302 == env57303) = true)

def env57304 : List Nat := [2,4,8,16,32,64,128,5,512,84,2048,4096,2731,4177,2571,2689,4344,6672,84,2571,6747,32,2587,2680,2594,2634,4291,4177,4264,2080,2727,168,4,2651,4345,512]

theorem envBound57304 : H12AffineFastState.Bounded env57304 := by
  intro p hp
  have h : env57304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57282_57304 : H12AffineEnvironment.transform 7 5 env57282 = env57304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57282 == env57304) = true)

def env57305 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,4096,2731,4129,2571,2689,4232,6672,36,2571,6699,32,2587,2568,2594,2618,4275,4129,4264,2080,2727,168,4,2603,4233,512]

theorem envBound57305 : H12AffineFastState.Bounded env57305 := by
  intro p hp
  have h : env57305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57304_57305 : H12AffineEnvironment.transform 5 48 env57304 = env57305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57304 == env57305) = true)

theorem identity57305 : scanCanonicalize (H12AffineFastState.compose env57305 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57306 : List Nat := [2,4,8,16,32,48,128,5,512,36,2048,643,2731,674,2571,2689,523,2195,36,2571,2216,32,2587,2568,2594,2618,560,674,555,2080,2727,168,4,2603,522,512]

theorem envBound57306 : H12AffineFastState.Bounded env57306 := by
  intro p hp
  have h : env57306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57305_57306 : H12AffineEnvironment.transform 11 643 env57305 = env57306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57305 == env57306) = true)

def env57307 : List Nat := [2,4,8,0,32,32,128,5,512,36,2048,643,2731,674,2571,2689,523,2179,36,2571,2216,32,2571,2568,2594,2602,544,674,555,2080,2727,168,4,2603,522,512]

theorem envBound57307 : H12AffineFastState.Bounded env57307 := by
  intro p hp
  have h : env57307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57306_57307 : H12AffineEnvironment.transform 3 0 env57306 = env57307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57306 == env57307) = true)

theorem identity57307 : scanCanonicalize (H12AffineFastState.compose env57307 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound57307 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57308 : List Nat := [2,4,8,0,32,32,128,5,512,36,512,643,171,674,11,129,523,643,36,11,680,32,11,8,34,42,544,674,555,544,167,168,4,43,522,512]

theorem envBound57308 : H12AffineFastState.Bounded env57308 := by
  intro p hp
  have h : env57308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57307_57308 : H12AffineEnvironment.transform 10 512 env57307 = env57308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env57307 == env57308) = true)

theorem identity57308 : scanCanonicalize (H12AffineFastState.compose env57308 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57308 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57309 : List Nat := [2,4,8,0,32,32,8,5,512,36,512,523,35,554,11,9,523,523,36,11,544,32,11,8,34,42,544,554,555,544,47,32,4,43,522,512]

theorem envBound57309 : H12AffineFastState.Bounded env57309 := by
  intro p hp
  have h : env57309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57308_57309 : H12AffineEnvironment.transform 6 8 env57308 = env57309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57308 == env57309) = true)

theorem identity57309 : scanCanonicalize (H12AffineFastState.compose env57309 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57309 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57310 : List Nat := [2,4,3,0,32,32,3,5,512,36,512,512,35,545,0,2,512,512,36,0,544,32,0,3,34,33,544,545,544,544,36,32,4,32,513,512]

theorem envBound57310 : H12AffineFastState.Bounded env57310 := by
  intro p hp
  have h : env57310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57309_57310 : H12AffineEnvironment.transform 2 3 env57309 = env57310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57309 == env57310) = true)

theorem identity57310 : scanCanonicalize (H12AffineFastState.compose env57310 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57310 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57311 : List Nat := [2,4,3,0,32,32,3,5,0,36,0,0,35,33,0,2,0,0,36,0,32,32,0,3,34,33,32,33,32,32,36,32,4,32,1,0]

theorem envBound57311 : H12AffineFastState.Bounded env57311 := by
  intro p hp
  have h : env57311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57310_57311 : H12AffineEnvironment.transform 8 0 env57310 = env57311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57310 == env57311) = true)

theorem identity57311 : scanCanonicalize (H12AffineFastState.compose env57311 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57312 : List Nat := [2,4,3,0,0,0,3,5,0,4,0,0,3,1,0,2,0,0,4,0,0,0,0,3,2,1,0,1,0,0,4,0,4,0,1,0]

theorem envBound57312 : H12AffineFastState.Bounded env57312 := by
  intro p hp
  have h : env57312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57311_57312 : H12AffineEnvironment.transform 4 0 env57311 = env57312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57311 == env57312) = true)

def env57313 : List Nat := [2,4,8,1,32,33,128,5,512,36,2048,643,2731,674,2571,2689,523,2178,36,2571,2216,32,2570,2568,2594,2603,545,674,555,2080,2727,168,4,2603,522,512]

theorem envBound57313 : H12AffineFastState.Bounded env57313 := by
  intro p hp
  have h : env57313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57306_57313 : H12AffineEnvironment.transform 3 1 env57306 = env57313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57306 == env57313) = true)

theorem identity57313 : scanCanonicalize (H12AffineFastState.compose env57313 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57313 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57314 : List Nat := [2,4,2,1,32,33,128,5,512,36,2048,643,2721,674,2561,2689,513,2178,36,2561,2210,32,2560,2562,2594,2593,545,674,545,2080,2727,162,4,2593,512,512]

theorem envBound57314 : H12AffineFastState.Bounded env57314 := by
  intro p hp
  have h : env57314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57313_57314 : H12AffineEnvironment.transform 2 2 env57313 = env57314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57313 == env57314) = true)

def env57315 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,4096,2731,4128,2571,2689,4233,6672,37,2571,6698,32,2587,2569,2594,2619,4274,4128,4264,2080,2727,168,4,2602,4232,512]

theorem envBound57315 : H12AffineFastState.Bounded env57315 := by
  intro p hp
  have h : env57315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57304_57315 : H12AffineEnvironment.transform 5 49 env57304 = env57315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57304 == env57315) = true)

theorem identity57315 : scanCanonicalize (H12AffineFastState.compose env57315 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57316 : List Nat := [2,4,8,16,32,49,128,5,512,37,2048,555,2731,523,2571,2689,674,2107,37,2571,2049,32,2587,2569,2594,2619,665,523,643,2080,2727,168,4,2602,675,512]

theorem envBound57316 : H12AffineFastState.Bounded env57316 := by
  intro p hp
  have h : env57316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57315_57316 : H12AffineEnvironment.transform 11 555 env57315 = env57316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57315 == env57316) = true)

def env57317 : List Nat := [2,4,8,16,16,1,128,5,512,21,2048,539,2715,523,2571,2689,658,2059,21,2571,2049,16,2587,2569,2578,2571,665,523,643,2064,2711,152,4,2586,659,512]

theorem envBound57317 : H12AffineFastState.Bounded env57317 := by
  intro p hp
  have h : env57317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57316_57317 : H12AffineEnvironment.transform 4 16 env57316 = env57317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57316 == env57317) = true)

def env57318 : List Nat := [2,4,8,16,17,0,128,5,512,20,2048,538,2714,523,2571,2689,659,2058,20,2571,2049,17,2587,2569,2579,2570,665,523,643,2065,2710,153,4,2587,658,512]

theorem envBound57318 : H12AffineFastState.Bounded env57318 := by
  intro p hp
  have h : env57318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57316_57318 : H12AffineEnvironment.transform 4 17 env57316 = env57318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57316 == env57318) = true)

theorem identity57318 : scanCanonicalize (H12AffineFastState.compose env57318 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound57318 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57319 : List Nat := [2,4,8,16,17,0,128,5,512,20,523,538,145,523,0,138,659,513,20,0,522,17,16,2,24,1,665,523,643,538,157,153,4,16,658,512]

theorem envBound57319 : H12AffineFastState.Bounded env57319 := by
  intro p hp
  have h : env57319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57318_57319 : H12AffineEnvironment.transform 10 523 env57318 = env57319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env57318 == env57319) = true)

theorem identity57319 : scanCanonicalize (H12AffineFastState.compose env57319 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57319 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57320 : List Nat := [2,4,8,16,17,0,3,5,512,20,523,538,18,523,0,9,528,513,20,0,522,17,16,2,24,1,538,523,512,538,30,26,4,16,529,512]

theorem envBound57320 : H12AffineFastState.Bounded env57320 := by
  intro p hp
  have h : env57320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57319_57320 : H12AffineEnvironment.transform 6 3 env57319 = env57320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57319 == env57320) = true)

theorem identity57320 : scanCanonicalize (H12AffineFastState.compose env57320 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57320 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57321 : List Nat := [2,4,2,16,17,0,3,5,512,20,513,528,18,513,0,3,528,513,20,0,512,17,16,2,18,1,528,513,512,528,20,16,4,16,529,512]

theorem envBound57321 : H12AffineFastState.Bounded env57321 := by
  intro p hp
  have h : env57321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57320_57321 : H12AffineEnvironment.transform 2 2 env57320 = env57321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57320 == env57321) = true)

theorem identity57321 : scanCanonicalize (H12AffineFastState.compose env57321 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57321 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57322 : List Nat := [2,4,2,16,17,0,3,5,0,20,1,16,18,1,0,3,16,1,20,0,0,17,16,2,18,1,16,1,0,16,20,16,4,16,17,0]

theorem envBound57322 : H12AffineFastState.Bounded env57322 := by
  intro p hp
  have h : env57322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57321_57322 : H12AffineEnvironment.transform 8 0 env57321 = env57322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57321 == env57322) = true)

theorem identity57322 : scanCanonicalize (H12AffineFastState.compose env57322 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57323 : List Nat := [2,4,2,1,0,0,3,5,0,5,1,1,3,1,0,3,1,1,5,0,0,0,1,2,3,1,1,1,0,1,5,1,4,1,0,0]

theorem envBound57323 : H12AffineFastState.Bounded env57323 := by
  intro p hp
  have h : env57323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57322_57323 : H12AffineEnvironment.transform 3 1 env57322 = env57323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57322 == env57323) = true)

def env57324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142599,28889,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57324 : H12AffineFastState.Bounded env57324 := by
  intro p hp
  have h : env57324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57275_57324 : H12AffineEnvironment.transform 21 41089 env57275 = env57324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57275 == env57324) = true)

theorem identity57324 : scanCanonicalize (H12AffineFastState.compose env57324 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57324 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12513,65536,78034,82112,1024,12513,2097152,4192,2101313,2097510,28889,2113601,75005,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57325 : H12AffineFastState.Bounded env57325 := by
  intro p hp
  have h : env57325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57324_57325 : H12AffineEnvironment.transform 14 12513 env57324 = env57325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57324 == env57325) = true)

theorem identity57325 : scanCanonicalize (H12AffineFastState.compose env57325 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57325 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12513,65536,78034,79256,1024,12513,2097152,4192,2101313,2097510,1409,2110745,75005,13656,77954,68866,2176390,74118,257,2168098,78035,9992]

theorem envBound57326 : H12AffineFastState.Bounded env57326 := by
  intro p hp
  have h : env57326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57325_57326 : H12AffineEnvironment.transform 13 13656 env57325 = env57326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57325 == env57326) = true)

theorem identity57326 : scanCanonicalize (H12AffineFastState.compose env57326 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57326 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12513,65536,78034,79256,1024,12513,71050,4192,67019,70892,1409,73875,75005,13656,77954,68866,8204,74118,257,168,78035,9992]

theorem envBound57327 : H12AffineFastState.Bounded env57327 := by
  intro p hp
  have h : env57327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57326_57327 : H12AffineEnvironment.transform 20 71050 env57326 = env57327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57326 == env57327) = true)

theorem identity57327 : scanCanonicalize (H12AffineFastState.compose env57327 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1419) := by decide +kernel

theorem selectedBound57327 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,12513,1419,13657,12307,1024,12513,4097,4192,64,4455,1409,9496,8566,13656,13577,2185,8204,9229,257,168,13656,9992]

theorem envBound57328 : H12AffineFastState.Bounded env57328 := by
  intro p hp
  have h : env57328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57327_57328 : H12AffineEnvironment.transform 15 1419 env57327 = env57328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1419 env57327 == env57328) = true)

theorem identity57328 : scanCanonicalize (H12AffineFastState.compose env57328 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57328 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,1419,4176,5402,1024,5608,4097,4192,64,4455,1409,17,1151,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57329 : H12AffineFastState.Bounded env57329 := by
  intro p hp
  have h : env57329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57328_57329 : H12AffineEnvironment.transform 12 1289 env57328 = env57329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57328 == env57329) = true)

theorem identity57329 : scanCanonicalize (H12AffineFastState.compose env57329 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3815) := by decide +kernel

theorem selectedBound57329 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3815,1289,3766,2831,1419,3767,3069,1024,2831,3814,3719,64,3968,1409,17,1151,3766,3815,2185,1285,260,257,168,3766,513]

theorem envBound57330 : H12AffineFastState.Bounded env57330 := by
  intro p hp
  have h : env57330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57329_57330 : H12AffineEnvironment.transform 11 3815 env57329 = env57330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3815 env57329 == env57330) = true)

theorem identity57330 : scanCanonicalize (H12AffineFastState.compose env57330 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound57330 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57331 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,2414,640,2367,2831,514,2366,3069,905,2831,2415,2318,64,2057,520,17,1014,2367,2414,2185,652,260,257,168,2367,513]

theorem envBound57331 : H12AffineFastState.Bounded env57331 := by
  intro p hp
  have h : env57331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57330_57331 : H12AffineEnvironment.transform 9 905 env57330 = env57331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env57330 == env57331) = true)

theorem identity57331 : scanCanonicalize (H12AffineFastState.compose env57331 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1014) := by decide +kernel

theorem selectedBound57331 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57332 : List Nat := [2,4,8,16,32,64,128,256,512,905,1014,664,640,713,249,514,712,11,905,249,665,760,64,1023,520,17,1014,713,664,895,652,260,257,168,713,513]

theorem envBound57332 : H12AffineFastState.Bounded env57332 := by
  intro p hp
  have h : env57332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57331_57332 : H12AffineEnvironment.transform 10 1014 env57331 = env57332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1014 env57331 == env57332) = true)

theorem identity57332 : scanCanonicalize (H12AffineFastState.compose env57332 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57332 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57333 : List Nat := [2,4,8,16,32,64,128,256,372,253,130,492,500,445,249,374,444,11,253,249,493,396,64,139,380,17,130,445,492,11,504,260,257,168,445,373]

theorem envBound57333 : H12AffineFastState.Bounded env57333 := by
  intro p hp
  have h : env57333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57332_57333 : H12AffineEnvironment.transform 8 372 env57332 = env57333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57332 == env57333) = true)

theorem identity57333 : scanCanonicalize (H12AffineFastState.compose env57333 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57333 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57334 : List Nat := [2,4,8,16,32,64,128,79,59,253,130,163,187,242,249,57,243,11,253,249,162,195,64,139,51,17,130,242,163,11,183,75,78,168,242,58]

theorem envBound57334 : H12AffineFastState.Bounded env57334 := by
  intro p hp
  have h : env57334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57333_57334 : H12AffineEnvironment.transform 7 79 env57333 = env57334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57333 == env57334) = true)

theorem identity57334 : scanCanonicalize (H12AffineFastState.compose env57334 (packedSelected [0,2,3,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57334 : packedSelected [0,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env57335 : List Nat := [2,4,8,16,11,64,128,79,16,214,130,136,144,217,210,18,216,11,214,210,137,195,64,139,24,17,130,217,136,11,156,75,78,131,217,17]

theorem envBound57335 : H12AffineFastState.Bounded env57335 := by
  intro p hp
  have h : env57335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57334_57335 : H12AffineEnvironment.transform 4 11 env57334 = env57335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57334 == env57335) = true)

theorem identity57335 : scanCanonicalize (H12AffineFastState.compose env57335 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57335 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57336 : List Nat := [2,4,8,16,11,11,128,4,16,157,130,136,144,146,153,18,147,11,157,153,137,136,11,139,24,17,130,146,136,11,156,0,5,131,146,17]

theorem envBound57336 : H12AffineFastState.Bounded env57336 := by
  intro p hp
  have h : env57336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57335_57336 : H12AffineEnvironment.transform 5 11 env57335 = env57336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57335 == env57336) = true)

theorem identity57336 : scanCanonicalize (H12AffineFastState.compose env57336 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57336 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57337 : List Nat := [2,4,8,16,11,11,2,4,16,31,0,10,18,16,27,18,17,11,31,27,11,10,11,9,24,17,0,16,10,11,30,0,5,1,16,17]

theorem envBound57337 : H12AffineFastState.Bounded env57337 := by
  intro p hp
  have h : env57337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57336_57337 : H12AffineEnvironment.transform 6 2 env57336 = env57337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57336 == env57337) = true)

theorem identity57337 : scanCanonicalize (H12AffineFastState.compose env57337 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57338 : List Nat := [2,4,8,0,11,11,2,4,0,15,0,10,2,0,11,2,1,11,15,11,11,10,11,9,8,1,0,0,10,11,14,0,5,1,0,1]

theorem envBound57338 : H12AffineFastState.Bounded env57338 := by
  intro p hp
  have h : env57338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57337_57338 : H12AffineEnvironment.transform 3 0 env57337 = env57338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57337 == env57338) = true)

theorem identity57338 : scanCanonicalize (H12AffineFastState.compose env57338 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57339 : List Nat := [2,4,0,0,3,3,2,4,0,7,0,2,2,0,3,2,1,3,7,3,3,2,3,1,0,1,0,0,2,3,6,0,5,1,0,1]

theorem envBound57339 : H12AffineFastState.Bounded env57339 := by
  intro p hp
  have h : env57339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57338_57339 : H12AffineEnvironment.transform 2 0 env57338 = env57339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57338 == env57339) = true)

def env57340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295814,4247640,6348992,4273308,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256465]

theorem envBound57340 : H12AffineFastState.Bounded env57340 := by
  intro p hp
  have h : env57340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57274_57340 : H12AffineEnvironment.transform 17 82113 env57274 = env57340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57274 == env57340) = true)

def env57341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142598,28888,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57341 : H12AffineFastState.Bounded env57341 := by
  intro p hp
  have h : env57341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57340_57341 : H12AffineEnvironment.transform 21 41088 env57340 = env57341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57340 == env57341) = true)

theorem identity57341 : scanCanonicalize (H12AffineFastState.compose env57341 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound57341 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9712,65536,78034,82113,1024,9712,2097152,1392,2101312,2102390,28888,2113600,78316,16384,77954,96347,2176391,74119,257,2187387,78035,21073]

theorem envBound57342 : H12AffineFastState.Bounded env57342 := by
  intro p hp
  have h : env57342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57341_57342 : H12AffineEnvironment.transform 14 9712 env57341 = env57342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env57341 == env57342) = true)

theorem identity57342 : scanCanonicalize (H12AffineFastState.compose env57342 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57342 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9712,65536,78034,82113,1024,9712,83418,1392,87450,86444,28888,66970,78316,16384,77954,96347,28765,74119,257,9633,78035,21073]

theorem envBound57343 : H12AffineFastState.Bounded env57343 := by
  intro p hp
  have h : env57343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57342_57343 : H12AffineEnvironment.transform 20 83418 env57342 = env57343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57342 == env57343) = true)

theorem identity57343 : scanCanonicalize (H12AffineFastState.compose env57343 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57343 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,65536,78034,69776,1024,9712,71051,1392,67019,66045,8329,66970,78316,4177,77954,75786,8204,74119,257,9633,78035,512]

theorem envBound57344 : H12AffineFastState.Bounded env57344 := by
  intro p hp
  have h : env57344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57343_57344 : H12AffineEnvironment.transform 13 4177 env57343 = env57344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57343 == env57344) = true)

theorem identity57344 : scanCanonicalize (H12AffineFastState.compose env57344 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9343) := by decide +kernel

theorem selectedBound57344 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,9712,9343,5293,13551,1024,9712,12788,1392,8628,9602,8329,8677,5523,4177,5373,3189,8204,1528,257,9633,5292,512]

theorem envBound57345 : H12AffineFastState.Bounded env57345 := by
  intro p hp
  have h : env57345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57344_57345 : H12AffineEnvironment.transform 15 9343 env57344 = env57345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9343 env57344 == env57345) = true)

theorem identity57345 : scanCanonicalize (H12AffineFastState.compose env57345 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57345 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,2830,2689,5293,6673,1024,2830,7946,1392,3914,2940,3703,3867,5523,4177,5373,3189,3826,1528,257,2911,5292,512]

theorem envBound57346 : H12AffineFastState.Bounded env57346 := by
  intro p hp
  have h : env57346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57345_57346 : H12AffineEnvironment.transform 12 3838 env57345 = env57346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57345 == env57346) = true)

theorem identity57346 : scanCanonicalize (H12AffineFastState.compose env57346 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound57346 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57347 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,4096,2990,4177,2830,2689,4605,6673,336,2830,6746,32,2586,2940,2855,2635,4291,4177,4525,2341,2978,168,257,2911,4604,512]

theorem envBound57347 : H12AffineFastState.Bounded env57347 := by
  intro p hp
  have h : env57347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57346_57347 : H12AffineEnvironment.transform 9 336 env57346 = env57347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env57346 == env57347) = true)

def env57348 : List Nat := [2,4,8,16,32,64,128,4,512,84,2048,4096,2730,4177,2570,2689,4345,6673,84,2570,6746,32,2586,2680,2595,2635,4291,4177,4265,2081,2726,168,5,2651,4344,512]

theorem envBound57348 : H12AffineFastState.Bounded env57348 := by
  intro p hp
  have h : env57348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57347_57348 : H12AffineEnvironment.transform 7 4 env57347 = env57348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57347 == env57348) = true)

def env57349 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,4096,2730,4129,2570,2689,4233,6673,36,2570,6698,32,2586,2568,2595,2619,4275,4129,4265,2081,2726,168,5,2603,4232,512]

theorem envBound57349 : H12AffineFastState.Bounded env57349 := by
  intro p hp
  have h : env57349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57348_57349 : H12AffineEnvironment.transform 5 48 env57348 = env57349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57348 == env57349) = true)

theorem identity57349 : scanCanonicalize (H12AffineFastState.compose env57349 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57350 : List Nat := [2,4,8,16,32,48,128,4,512,36,2048,555,2730,522,2570,2689,674,2106,36,2570,2049,32,2586,2568,2595,2619,664,522,642,2081,2726,168,5,2603,675,512]

theorem envBound57350 : H12AffineFastState.Bounded env57350 := by
  intro p hp
  have h : env57350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57349_57350 : H12AffineEnvironment.transform 11 555 env57349 = env57350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57349 == env57350) = true)

def env57351 : List Nat := [2,4,8,16,16,0,128,4,512,20,2048,539,2714,522,2570,2689,658,2058,20,2570,2049,16,2586,2568,2579,2571,664,522,642,2065,2710,152,5,2587,659,512]

theorem envBound57351 : H12AffineFastState.Bounded env57351 := by
  intro p hp
  have h : env57351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57350_57351 : H12AffineEnvironment.transform 4 16 env57350 = env57351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57350 == env57351) = true)

def env57352 : List Nat := [2,4,8,16,17,1,128,4,512,21,2048,538,2715,522,2570,2689,659,2059,21,2570,2049,17,2586,2568,2578,2570,664,522,642,2064,2711,153,5,2586,658,512]

theorem envBound57352 : H12AffineFastState.Bounded env57352 := by
  intro p hp
  have h : env57352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57350_57352 : H12AffineEnvironment.transform 4 17 env57350 = env57352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57350 == env57352) = true)

theorem identity57352 : scanCanonicalize (H12AffineFastState.compose env57352 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57352 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57353 : List Nat := [2,4,8,16,17,1,128,4,512,21,522,538,145,522,0,139,659,513,21,0,523,17,16,2,24,0,664,522,642,538,157,153,5,16,658,512]

theorem envBound57353 : H12AffineFastState.Bounded env57353 := by
  intro p hp
  have h : env57353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57352_57353 : H12AffineEnvironment.transform 10 522 env57352 = env57353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57352 == env57353) = true)

theorem identity57353 : scanCanonicalize (H12AffineFastState.compose env57353 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57353 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57354 : List Nat := [2,4,8,16,17,1,2,4,512,21,522,538,19,522,0,9,529,513,21,0,523,17,16,2,24,0,538,522,512,538,31,27,5,16,528,512]

theorem envBound57354 : H12AffineFastState.Bounded env57354 := by
  intro p hp
  have h : env57354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57353_57354 : H12AffineEnvironment.transform 6 2 env57353 = env57354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57353 == env57354) = true)

theorem identity57354 : scanCanonicalize (H12AffineFastState.compose env57354 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57354 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57355 : List Nat := [2,4,3,16,17,1,2,4,512,21,513,529,19,513,0,2,529,513,21,0,512,17,16,2,19,0,529,513,512,529,20,16,5,16,528,512]

theorem envBound57355 : H12AffineFastState.Bounded env57355 := by
  intro p hp
  have h : env57355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57354_57355 : H12AffineEnvironment.transform 2 3 env57354 = env57355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57354 == env57355) = true)

theorem identity57355 : scanCanonicalize (H12AffineFastState.compose env57355 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57355 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57356 : List Nat := [2,4,3,16,17,1,2,4,0,21,1,17,19,1,0,2,17,1,21,0,0,17,16,2,19,0,17,1,0,17,20,16,5,16,16,0]

theorem envBound57356 : H12AffineFastState.Bounded env57356 := by
  intro p hp
  have h : env57356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57355_57356 : H12AffineEnvironment.transform 8 0 env57355 = env57356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57355 == env57356) = true)

theorem identity57356 : scanCanonicalize (H12AffineFastState.compose env57356 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57357 : List Nat := [2,4,3,0,1,1,2,4,0,5,1,1,3,1,0,2,1,1,5,0,0,1,0,2,3,0,1,1,0,1,4,0,5,0,0,0]

theorem envBound57357 : H12AffineFastState.Bounded env57357 := by
  intro p hp
  have h : env57357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57356_57357 : H12AffineEnvironment.transform 3 0 env57356 = env57357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57356 == env57357) = true)

def env57358 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,4096,2730,4128,2570,2689,4232,6673,37,2570,6699,32,2586,2569,2595,2618,4274,4128,4265,2081,2726,168,5,2602,4233,512]

theorem envBound57358 : H12AffineFastState.Bounded env57358 := by
  intro p hp
  have h : env57358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57348_57358 : H12AffineEnvironment.transform 5 49 env57348 = env57358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57348 == env57358) = true)

theorem identity57358 : scanCanonicalize (H12AffineFastState.compose env57358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57359 : List Nat := [2,4,8,16,32,49,128,4,512,37,2048,642,2730,674,2570,2689,522,2195,37,2570,2217,32,2586,2569,2595,2618,560,674,555,2081,2726,168,5,2602,523,512]

theorem envBound57359 : H12AffineFastState.Bounded env57359 := by
  intro p hp
  have h : env57359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57358_57359 : H12AffineEnvironment.transform 11 642 env57358 = env57359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57358 == env57359) = true)

def env57360 : List Nat := [2,4,8,0,32,33,128,4,512,37,2048,642,2730,674,2570,2689,522,2179,37,2570,2217,32,2570,2569,2595,2602,544,674,555,2081,2726,168,5,2602,523,512]

theorem envBound57360 : H12AffineFastState.Bounded env57360 := by
  intro p hp
  have h : env57360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57359_57360 : H12AffineEnvironment.transform 3 0 env57359 = env57360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57359 == env57360) = true)

theorem identity57360 : scanCanonicalize (H12AffineFastState.compose env57360 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57360 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57361 : List Nat := [2,4,3,0,32,33,128,4,512,37,2048,642,2721,674,2561,2689,513,2179,37,2561,2210,32,2561,2562,2595,2593,544,674,544,2081,2726,163,5,2593,512,512]

theorem envBound57361 : H12AffineFastState.Bounded env57361 := by
  intro p hp
  have h : env57361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57360_57361 : H12AffineEnvironment.transform 2 3 env57360 = env57361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57360 == env57361) = true)

def env57362 : List Nat := [2,4,8,1,32,32,128,4,512,37,2048,642,2730,674,2570,2689,522,2178,37,2570,2217,32,2571,2569,2595,2603,545,674,555,2081,2726,168,5,2602,523,512]

theorem envBound57362 : H12AffineFastState.Bounded env57362 := by
  intro p hp
  have h : env57362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57359_57362 : H12AffineEnvironment.transform 3 1 env57359 = env57362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57359 == env57362) = true)

theorem identity57362 : scanCanonicalize (H12AffineFastState.compose env57362 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound57362 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57363 : List Nat := [2,4,8,1,32,32,128,4,512,37,512,642,170,674,10,129,522,642,37,10,681,32,11,9,35,43,545,674,555,545,166,168,5,42,523,512]

theorem envBound57363 : H12AffineFastState.Bounded env57363 := by
  intro p hp
  have h : env57363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57362_57363 : H12AffineEnvironment.transform 10 512 env57362 = env57363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env57362 == env57363) = true)

theorem identity57363 : scanCanonicalize (H12AffineFastState.compose env57363 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57363 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57364 : List Nat := [2,4,8,1,32,32,8,4,512,37,512,522,34,554,10,9,522,522,37,10,545,32,11,9,35,43,545,554,555,545,46,32,5,42,523,512]

theorem envBound57364 : H12AffineFastState.Bounded env57364 := by
  intro p hp
  have h : env57364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57363_57364 : H12AffineEnvironment.transform 6 8 env57363 = env57364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57363 == env57364) = true)

theorem identity57364 : scanCanonicalize (H12AffineFastState.compose env57364 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57364 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57365 : List Nat := [2,4,2,1,32,32,2,4,512,37,512,512,34,544,0,3,512,512,37,0,545,32,1,3,35,33,545,544,545,545,36,32,5,32,513,512]

theorem envBound57365 : H12AffineFastState.Bounded env57365 := by
  intro p hp
  have h : env57365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57364_57365 : H12AffineEnvironment.transform 2 2 env57364 = env57365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57364 == env57365) = true)

theorem identity57365 : scanCanonicalize (H12AffineFastState.compose env57365 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57365 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57366 : List Nat := [2,4,2,1,32,32,2,4,0,37,0,0,34,32,0,3,0,0,37,0,33,32,1,3,35,33,33,32,33,33,36,32,5,32,1,0]

theorem envBound57366 : H12AffineFastState.Bounded env57366 := by
  intro p hp
  have h : env57366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57365_57366 : H12AffineEnvironment.transform 8 0 env57365 = env57366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57365 == env57366) = true)

theorem identity57366 : scanCanonicalize (H12AffineFastState.compose env57366 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57367 : List Nat := [2,4,2,1,1,1,2,4,0,4,0,0,3,1,0,3,0,0,4,0,0,1,1,3,2,0,0,1,0,0,5,1,5,1,1,0]

theorem envBound57367 : H12AffineFastState.Bounded env57367 := by
  intro p hp
  have h : env57367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57366_57367 : H12AffineEnvironment.transform 4 1 env57366 = env57367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57366 == env57367) = true)

def env57368 : List Nat := [2,4,8,16,32,64,128,5,512,85,2048,4096,2731,4177,2571,2689,4344,6673,85,2571,6746,32,2586,2681,2594,2635,4291,4177,4264,2080,2727,168,4,2650,4345,512]

theorem envBound57368 : H12AffineFastState.Bounded env57368 := by
  intro p hp
  have h : env57368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57347_57368 : H12AffineEnvironment.transform 7 5 env57347 = env57368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57347 == env57368) = true)

def env57369 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,4096,2731,4129,2571,2689,4232,6673,37,2571,6698,32,2586,2569,2594,2619,4275,4129,4264,2080,2727,168,4,2602,4233,512]

theorem envBound57369 : H12AffineFastState.Bounded env57369 := by
  intro p hp
  have h : env57369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57368_57369 : H12AffineEnvironment.transform 5 48 env57368 = env57369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57368 == env57369) = true)

theorem identity57369 : scanCanonicalize (H12AffineFastState.compose env57369 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound57369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57370 : List Nat := [2,4,8,16,32,48,128,5,512,37,2048,2049,2731,2080,2571,2689,2185,528,37,2571,555,32,2586,2569,2594,2619,2226,2080,2217,2080,2727,168,4,2602,2184,512]

theorem envBound57370 : H12AffineFastState.Bounded env57370 := by
  intro p hp
  have h : env57370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57369_57370 : H12AffineEnvironment.transform 11 2049 env57369 = env57370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env57369 == env57370) = true)

def env57371 : List Nat := [2,4,8,16,0,16,128,5,512,5,2048,2049,2699,2048,2571,2689,2185,528,5,2571,523,0,2586,2569,2562,2587,2194,2048,2185,2048,2695,136,4,2570,2184,512]

theorem envBound57371 : H12AffineFastState.Bounded env57371 := by
  intro p hp
  have h : env57371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57370_57371 : H12AffineEnvironment.transform 4 0 env57370 = env57371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57370 == env57371) = true)

theorem identity57371 : scanCanonicalize (H12AffineFastState.compose env57371 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57371 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57372 : List Nat := [2,4,8,1,0,1,128,5,512,5,2048,2049,2699,2048,2571,2689,2185,513,5,2571,523,0,2571,2569,2562,2570,2179,2048,2185,2048,2695,136,4,2570,2184,512]

theorem envBound57372 : H12AffineFastState.Bounded env57372 := by
  intro p hp
  have h : env57372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57371_57372 : H12AffineEnvironment.transform 3 1 env57371 = env57372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57371 == env57372) = true)

theorem identity57372 : scanCanonicalize (H12AffineFastState.compose env57372 (packedSelected [4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound57372 : packedSelected [4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57373 : List Nat := [2,4,8,1,0,1,128,5,512,5,649,648,2,649,130,8,512,513,5,130,523,0,130,128,139,131,522,649,512,649,14,136,4,131,513,512]

theorem envBound57373 : H12AffineFastState.Bounded env57373 := by
  intro p hp
  have h : env57373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57372_57373 : H12AffineEnvironment.transform 10 649 env57372 = env57373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57372 == env57373) = true)

theorem identity57373 : scanCanonicalize (H12AffineFastState.compose env57373 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound57373 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57374 : List Nat := [2,4,8,1,0,1,128,5,137,5,0,1,2,0,130,8,137,136,5,130,130,0,130,128,139,131,131,0,137,0,14,136,4,131,136,137]

theorem envBound57374 : H12AffineFastState.Bounded env57374 := by
  intro p hp
  have h : env57374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57373_57374 : H12AffineEnvironment.transform 8 137 env57373 = env57374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env57373 == env57374) = true)

theorem identity57374 : scanCanonicalize (H12AffineFastState.compose env57374 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57375 : List Nat := [2,4,3,1,0,1,128,5,130,5,0,1,2,0,130,3,130,131,5,130,130,0,130,128,128,131,131,0,130,0,5,131,4,131,131,130]

theorem envBound57375 : H12AffineFastState.Bounded env57375 := by
  intro p hp
  have h : env57375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57374_57375 : H12AffineEnvironment.transform 2 3 env57374 = env57375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57374 == env57375) = true)

def env57376 : List Nat := [2,4,8,16,1,17,128,5,512,4,2048,2049,2698,2049,2571,2689,2185,528,4,2571,522,1,2586,2569,2563,2586,2195,2049,2184,2049,2694,137,4,2571,2184,512]

theorem envBound57376 : H12AffineFastState.Bounded env57376 := by
  intro p hp
  have h : env57376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57370_57376 : H12AffineEnvironment.transform 4 1 env57370 = env57376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57370 == env57376) = true)

theorem identity57376 : scanCanonicalize (H12AffineFastState.compose env57376 (packedSelected [0,4,5,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57376 : packedSelected [0,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57377 : List Nat := [2,4,8,11,1,10,128,5,512,4,2048,2049,2698,2049,2571,2689,2185,523,4,2571,522,1,2561,2569,2563,2561,2184,2049,2184,2049,2694,137,4,2571,2184,512]

theorem envBound57377 : H12AffineFastState.Bounded env57377 := by
  intro p hp
  have h : env57377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57376_57377 : H12AffineEnvironment.transform 3 11 env57376 = env57377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57376 == env57377) = true)

theorem identity57377 : scanCanonicalize (H12AffineFastState.compose env57377 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57377 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57378 : List Nat := [2,4,8,11,1,10,128,5,512,4,1,0,651,0,522,640,136,523,4,522,522,1,512,520,514,512,137,0,137,0,647,137,4,522,137,512]

theorem envBound57378 : H12AffineFastState.Bounded env57378 := by
  intro p hp
  have h : env57378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57377_57378 : H12AffineEnvironment.transform 10 1 env57377 = env57378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57377 == env57378) = true)

theorem identity57378 : scanCanonicalize (H12AffineFastState.compose env57378 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound57378 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57379 : List Nat := [2,4,8,11,1,10,128,5,137,4,1,0,2,0,131,9,136,130,4,131,131,1,137,129,139,137,137,0,137,0,14,137,4,131,137,137]

theorem envBound57379 : H12AffineFastState.Bounded env57379 := by
  intro p hp
  have h : env57379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57378_57379 : H12AffineEnvironment.transform 8 137 env57378 = env57379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env57378 == env57379) = true)

theorem identity57379 : scanCanonicalize (H12AffineFastState.compose env57379 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57380 : List Nat := [2,4,2,1,1,0,128,5,131,4,1,0,2,0,131,3,130,130,4,131,131,1,131,129,129,131,131,0,131,0,4,131,4,131,131,131]

theorem envBound57380 : H12AffineFastState.Bounded env57380 := by
  intro p hp
  have h : env57380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57379_57380 : H12AffineEnvironment.transform 2 2 env57379 = env57380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57379 == env57380) = true)

theorem identity57380 : scanCanonicalize (H12AffineFastState.compose env57380 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57380 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57381 : List Nat := [2,4,2,1,1,0,2,5,1,4,1,0,2,0,1,3,0,0,4,1,1,1,1,3,3,1,1,0,1,0,4,1,4,1,1,1]

theorem envBound57381 : H12AffineFastState.Bounded env57381 := by
  intro p hp
  have h : env57381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57380_57381 : H12AffineEnvironment.transform 6 2 env57380 = env57381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57380 == env57381) = true)

def env57382 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,4096,2731,4128,2571,2689,4233,6673,36,2571,6699,32,2586,2568,2594,2618,4274,4128,4264,2080,2727,168,4,2603,4232,512]

theorem envBound57382 : H12AffineFastState.Bounded env57382 := by
  intro p hp
  have h : env57382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57368_57382 : H12AffineEnvironment.transform 5 49 env57368 = env57382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57368 == env57382) = true)

theorem identity57382 : scanCanonicalize (H12AffineFastState.compose env57382 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound57382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57383 : List Nat := [2,4,8,16,32,49,128,5,512,36,2048,2216,2731,2184,2571,2689,2081,697,36,2571,643,32,2586,2568,2594,2618,2074,2184,2048,2080,2727,168,4,2603,2080,512]

theorem envBound57383 : H12AffineFastState.Bounded env57383 := by
  intro p hp
  have h : env57383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57382_57383 : H12AffineEnvironment.transform 11 2216 env57382 = env57383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env57382 == env57383) = true)

def env57384 : List Nat := [2,4,8,16,32,49,128,5,512,36,648,544,35,512,131,9,681,697,36,131,643,32,146,128,170,178,658,512,648,680,47,168,4,163,680,512]

theorem envBound57384 : H12AffineFastState.Bounded env57384 := by
  intro p hp
  have h : env57384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57383_57384 : H12AffineEnvironment.transform 10 648 env57383 = env57384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57383 == env57384) = true)

theorem identity57384 : scanCanonicalize (H12AffineFastState.compose env57384 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57384 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57385 : List Nat := [2,4,8,16,32,49,56,5,512,36,560,544,35,512,59,9,529,513,36,59,571,32,42,56,18,10,554,512,560,528,47,16,4,27,528,512]

theorem envBound57385 : H12AffineFastState.Bounded env57385 := by
  intro p hp
  have h : env57385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57384_57385 : H12AffineEnvironment.transform 6 56 env57384 = env57385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57384 == env57385) = true)

def env57386 : List Nat := [2,4,8,16,32,49,128,5,512,36,649,545,34,513,130,8,680,697,36,130,643,32,147,129,171,179,659,513,649,681,46,168,4,162,681,512]

theorem envBound57386 : H12AffineFastState.Bounded env57386 := by
  intro p hp
  have h : env57386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57383_57386 : H12AffineEnvironment.transform 10 649 env57383 = env57386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57383 == env57386) = true)

theorem identity57386 : scanCanonicalize (H12AffineFastState.compose env57386 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57386 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57387 : List Nat := [2,4,8,16,32,49,50,5,512,36,571,545,34,513,48,8,538,523,36,48,561,32,33,51,25,1,545,513,571,539,46,26,4,16,539,512]

theorem envBound57387 : H12AffineFastState.Bounded env57387 := by
  intro p hp
  have h : env57387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57386_57387 : H12AffineEnvironment.transform 6 50 env57386 = env57387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57386 == env57387) = true)

theorem identity57387 : scanCanonicalize (H12AffineFastState.compose env57387 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57387 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57388 : List Nat := [2,4,3,16,32,49,50,5,512,36,560,545,34,513,48,3,529,512,36,48,561,32,33,51,18,1,545,513,560,528,37,17,4,16,528,512]

theorem envBound57388 : H12AffineFastState.Bounded env57388 := by
  intro p hp
  have h : env57388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57387_57388 : H12AffineEnvironment.transform 2 3 env57387 = env57388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57387 == env57388) = true)

def env57389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142599,28889,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57389 : H12AffineFastState.Bounded env57389 := by
  intro p hp
  have h : env57389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57340_57389 : H12AffineEnvironment.transform 21 41089 env57340 = env57389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57340 == env57389) = true)

theorem identity57389 : scanCanonicalize (H12AffineFastState.compose env57389 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24752) := by decide +kernel

theorem selectedBound57389 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24752,65536,78034,82113,1024,24752,2097152,16433,2101313,2117943,28889,2113601,95405,16384,77954,96346,2176390,74118,257,2187386,78035,21072]

theorem envBound57390 : H12AffineFastState.Bounded env57390 := by
  intro p hp
  have h : env57390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57389_57390 : H12AffineEnvironment.transform 14 24752 env57389 = env57390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24752 env57389 == env57390) = true)

theorem identity57390 : scanCanonicalize (H12AffineFastState.compose env57390 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13656) := by decide +kernel

theorem selectedBound57390 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5608,65536,78034,79257,1024,5608,2097152,13673,2101313,2106479,1409,2110745,66037,13656,77954,68866,2176390,74118,257,2168098,78035,9992]

theorem envBound57391 : H12AffineFastState.Bounded env57391 := by
  intro p hp
  have h : env57391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57390_57391 : H12AffineEnvironment.transform 13 13656 env57390 = env57391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13656 env57390 == env57391) = true)

theorem identity57391 : scanCanonicalize (H12AffineFastState.compose env57391 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57391 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5608,65536,78034,79257,1024,5608,71050,13673,67019,78309,1409,73875,66037,13656,77954,68866,8204,74118,257,168,78035,9992]

theorem envBound57392 : H12AffineFastState.Bounded env57392 := by
  intro p hp
  have h : env57392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57391_57392 : H12AffineEnvironment.transform 20 71050 env57391 = env57392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57391 == env57392) = true)

theorem identity57392 : scanCanonicalize (H12AffineFastState.compose env57392 (packedSelected [1,3,4,9,13,16,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1419) := by decide +kernel

theorem selectedBound57392 : packedSelected [1,3,4,9,13,16,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13656,5608,1419,13657,12306,1024,5608,4097,13673,64,13422,1409,9496,1150,13656,13577,2185,8204,9229,257,168,13656,9992]

theorem envBound57393 : H12AffineFastState.Bounded env57393 := by
  intro p hp
  have h : env57393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57392_57393 : H12AffineEnvironment.transform 15 1419 env57392 = env57393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1419 env57392 == env57393) = true)

theorem identity57393 : scanCanonicalize (H12AffineFastState.compose env57393 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57393 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4177,5608,1419,4176,5403,1024,5608,4097,4192,64,4455,1409,17,1150,4177,4096,2185,1285,260,257,168,4177,513]

theorem envBound57394 : H12AffineFastState.Bounded env57394 := by
  intro p hp
  have h : env57394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57393_57394 : H12AffineEnvironment.transform 12 1289 env57393 = env57394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57393 == env57394) = true)

theorem identity57394 : scanCanonicalize (H12AffineFastState.compose env57394 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3814) := by decide +kernel

theorem selectedBound57394 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3814,1289,3767,2830,1419,3766,3069,1024,2830,3815,3718,64,3969,1409,17,1150,3767,3814,2185,1285,260,257,168,3767,513]

theorem envBound57395 : H12AffineFastState.Bounded env57395 := by
  intro p hp
  have h : env57395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57394_57395 : H12AffineEnvironment.transform 11 3814 env57394 = env57395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3814 env57394 == env57395) = true)

theorem identity57395 : scanCanonicalize (H12AffineFastState.compose env57395 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound57395 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57396 : List Nat := [2,4,8,16,32,64,128,256,512,905,2048,2415,640,2366,2830,514,2367,3069,905,2830,2414,2319,64,2056,520,17,1015,2366,2415,2185,652,260,257,168,2366,513]

theorem envBound57396 : H12AffineFastState.Bounded env57396 := by
  intro p hp
  have h : env57396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57395_57396 : H12AffineEnvironment.transform 9 905 env57395 = env57396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env57395 == env57396) = true)

theorem identity57396 : scanCanonicalize (H12AffineFastState.compose env57396 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1015) := by decide +kernel

theorem selectedBound57396 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57397 : List Nat := [2,4,8,16,32,64,128,256,512,905,1015,664,640,713,249,514,712,10,905,249,665,760,64,1023,520,17,1015,713,664,894,652,260,257,168,713,513]

theorem envBound57397 : H12AffineFastState.Bounded env57397 := by
  intro p hp
  have h : env57397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57396_57397 : H12AffineEnvironment.transform 10 1015 env57396 = env57397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1015 env57396 == env57397) = true)

theorem identity57397 : scanCanonicalize (H12AffineFastState.compose env57397 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57397 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57398 : List Nat := [2,4,8,16,32,64,128,256,372,253,131,492,500,445,249,374,444,10,253,249,493,396,64,139,380,17,131,445,492,10,504,260,257,168,445,373]

theorem envBound57398 : H12AffineFastState.Bounded env57398 := by
  intro p hp
  have h : env57398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57397_57398 : H12AffineEnvironment.transform 8 372 env57397 = env57398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57397 == env57398) = true)

theorem identity57398 : scanCanonicalize (H12AffineFastState.compose env57398 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57398 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57399 : List Nat := [2,4,8,16,32,64,128,78,58,253,131,162,186,243,249,56,242,10,253,249,163,194,64,139,50,17,131,243,162,10,182,74,79,168,243,59]

theorem envBound57399 : H12AffineFastState.Bounded env57399 := by
  intro p hp
  have h : env57399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57398_57399 : H12AffineEnvironment.transform 7 78 env57398 = env57399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57398 == env57399) = true)

theorem identity57399 : scanCanonicalize (H12AffineFastState.compose env57399 (packedSelected [0,2,3,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57399 : packedSelected [0,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env57400 : List Nat := [2,4,8,16,10,64,128,78,16,215,131,136,144,217,211,18,216,10,215,211,137,194,64,139,24,17,131,217,136,10,156,74,79,130,217,17]

theorem envBound57400 : H12AffineFastState.Bounded env57400 := by
  intro p hp
  have h : env57400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57399_57400 : H12AffineEnvironment.transform 4 10 env57399 = env57400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57399 == env57400) = true)

theorem identity57400 : scanCanonicalize (H12AffineFastState.compose env57400 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57400 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57401 : List Nat := [2,4,8,16,10,11,128,5,16,156,131,136,144,146,152,18,147,10,156,152,137,137,11,139,24,17,131,146,136,10,156,1,4,130,146,17]

theorem envBound57401 : H12AffineFastState.Bounded env57401 := by
  intro p hp
  have h : env57401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57400_57401 : H12AffineEnvironment.transform 5 11 env57400 = env57401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57400 == env57401) = true)

theorem identity57401 : scanCanonicalize (H12AffineFastState.compose env57401 (packedSelected [1,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57401 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env57402 : List Nat := [2,4,8,11,10,11,128,5,11,135,131,136,139,137,131,9,136,10,135,131,137,137,11,139,3,10,131,137,136,10,135,1,4,130,137,10]

theorem envBound57402 : H12AffineFastState.Bounded env57402 := by
  intro p hp
  have h : env57402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57401_57402 : H12AffineEnvironment.transform 3 11 env57401 = env57402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57401 == env57402) = true)

theorem identity57402 : scanCanonicalize (H12AffineFastState.compose env57402 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound57402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57403 : List Nat := [2,4,8,11,10,11,0,5,11,7,3,8,11,9,3,9,8,10,7,3,9,9,11,11,3,10,3,9,8,10,7,1,4,2,9,10]

theorem envBound57403 : H12AffineFastState.Bounded env57403 := by
  intro p hp
  have h : env57403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57402_57403 : H12AffineEnvironment.transform 6 0 env57402 = env57403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env57402 == env57403) = true)

theorem identity57403 : scanCanonicalize (H12AffineFastState.compose env57403 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57403 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57404 : List Nat := [2,4,0,3,2,3,0,5,3,7,3,0,3,1,3,1,0,2,7,3,1,1,3,3,3,2,3,1,0,2,7,1,4,2,1,2]

theorem envBound57404 : H12AffineFastState.Bounded env57404 := by
  intro p hp
  have h : env57404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57403_57404 : H12AffineEnvironment.transform 2 0 env57403 = env57404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57403 == env57404) = true)

theorem identity57404 : scanCanonicalize (H12AffineFastState.compose env57404 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57405 : List Nat := [0,4,0,1,0,1,0,5,1,5,1,0,1,1,1,1,0,0,5,1,1,1,1,1,1,0,1,1,0,0,5,1,4,0,1,0]

theorem envBound57405 : H12AffineFastState.Bounded env57405 := by
  intro p hp
  have h : env57405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57404_57405 : H12AffineEnvironment.transform 0 0 env57404 = env57405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57404 == env57405) = true)

def env57406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4486236,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound57406 : H12AffineFastState.Bounded env57406 := by
  intro p hp
  have h : env57406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57273_57406 : H12AffineEnvironment.transform 22 6336705 env57273 = env57406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env57273 == env57406) = true)

def env57407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4273308,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound57407 : H12AffineFastState.Bounded env57407 := by
  intro p hp
  have h : env57407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57406_57407 : H12AffineEnvironment.transform 17 82112 env57406 = env57407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57406 == env57407) = true)

def env57408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142599,28888,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57408 : H12AffineFastState.Bounded env57408 := by
  intro p hp
  have h : env57408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57407_57408 : H12AffineEnvironment.transform 21 41088 env57407 = env57408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57407 == env57408) = true)

theorem identity57408 : scanCanonicalize (H12AffineFastState.compose env57408 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound57408 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,248,65536,78034,82112,1024,248,2097152,8312,2101313,2109823,28888,2113601,70884,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57409 : H12AffineFastState.Bounded env57409 := by
  intro p hp
  have h : env57409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57408_57409 : H12AffineEnvironment.transform 14 248 env57408 = env57409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env57408 == env57409) = true)

theorem identity57409 : scanCanonicalize (H12AffineFastState.compose env57409 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57409 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,248,65536,78034,82112,1024,248,83418,8312,87451,95397,28888,66971,70884,16384,77954,96347,28764,74118,257,9633,78035,21073]

theorem envBound57410 : H12AffineFastState.Bounded env57410 := by
  intro p hp
  have h : env57410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57409_57410 : H12AffineEnvironment.transform 20 83418 env57409 = env57410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57409 == env57410) = true)

theorem identity57410 : scanCanonicalize (H12AffineFastState.compose env57410 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57410 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,65536,78034,69777,1024,248,71051,8312,67018,74996,8329,66971,70884,4177,77954,75786,8205,74118,257,9633,78035,512]

theorem envBound57411 : H12AffineFastState.Bounded env57411 := by
  intro p hp
  have h : env57411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57410_57411 : H12AffineEnvironment.transform 13 4177 env57410 = env57411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57410 == env57411) = true)

theorem identity57411 : scanCanonicalize (H12AffineFastState.compose env57411 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound57411 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,248,375,12709,4582,1024,248,5372,8312,1213,9603,8329,1260,5523,4177,12789,10621,8205,8433,257,9633,12708,512]

theorem envBound57412 : H12AffineFastState.Bounded env57412 := by
  intro p hp
  have h : env57412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57411_57412 : H12AffineEnvironment.transform 15 375 env57411 = env57412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env57411 == env57412) = true)

theorem identity57412 : scanCanonicalize (H12AffineFastState.compose env57412 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3839) := by decide +kernel

theorem selectedBound57412 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3839,4177,248,375,8026,4582,1024,248,5372,3719,1213,2940,3702,1260,5523,4177,7946,1922,3826,3598,257,2910,8027,512]

theorem envBound57413 : H12AffineFastState.Bounded env57413 := by
  intro p hp
  have h : env57413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57412_57413 : H12AffineEnvironment.transform 12 3839 env57412 = env57413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3839 env57412 == env57413) = true)

theorem identity57413 : scanCanonicalize (H12AffineFastState.compose env57413 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57413 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,88,4177,248,375,4605,4582,1024,248,5372,32,1213,1499,209,1260,5523,4177,4525,1922,85,169,257,1529,4604,512]

theorem envBound57414 : H12AffineFastState.Bounded env57414 := by
  intro p hp
  have h : env57414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57413_57414 : H12AffineEnvironment.transform 10 1703 env57413 = env57414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57413 == env57414) = true)

def env57415 : List Nat := [2,4,8,16,32,64,128,256,512,392,815,4096,88,4177,248,375,4605,4582,392,248,4468,32,309,83,209,356,4123,4177,4525,522,85,169,257,113,4604,512]

theorem envBound57415 : H12AffineFastState.Bounded env57415 := by
  intro p hp
  have h : env57415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57414_57415 : H12AffineEnvironment.transform 9 392 env57414 = env57415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env57414 == env57415) = true)

def env57416 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,4096,40,4129,136,263,4493,4502,392,136,4356,32,309,35,161,276,4123,4129,4525,522,37,169,257,1,4492,512]

theorem envBound57416 : H12AffineFastState.Bounded env57416 := by
  intro p hp
  have h : env57416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57415_57416 : H12AffineEnvironment.transform 5 48 env57415 = env57416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57415 == env57416) = true)

theorem identity57416 : scanCanonicalize (H12AffineFastState.compose env57416 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 643) := by decide +kernel

theorem selectedBound57416 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57417 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,643,40,674,136,263,782,789,392,136,903,32,309,35,161,276,664,674,814,522,37,169,257,1,783,512]

theorem envBound57417 : H12AffineFastState.Bounded env57417 := by
  intro p hp
  have h : env57417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57416_57417 : H12AffineEnvironment.transform 11 643 env57416 = env57417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 643 env57416 == env57417) = true)

theorem identity57417 : scanCanonicalize (H12AffineFastState.compose env57417 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57417 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57418 : List Nat := [2,4,8,16,32,48,128,20,512,156,571,643,40,674,136,19,538,513,156,136,659,32,33,35,161,0,664,674,570,522,37,169,21,1,539,512]

theorem envBound57418 : H12AffineFastState.Bounded env57418 := by
  intro p hp
  have h : env57418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57417_57418 : H12AffineEnvironment.transform 7 20 env57417 = env57418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57417 == env57418) = true)

theorem identity57418 : scanCanonicalize (H12AffineFastState.compose env57418 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57418 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57419 : List Nat := [2,4,8,16,32,48,51,20,512,47,571,560,40,529,59,19,538,513,47,59,544,32,33,35,18,0,555,529,570,522,37,26,21,1,539,512]

theorem envBound57419 : H12AffineFastState.Bounded env57419 := by
  intro p hp
  have h : env57419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57418_57419 : H12AffineEnvironment.transform 6 51 env57418 = env57419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57418 == env57419) = true)

theorem identity57419 : scanCanonicalize (H12AffineFastState.compose env57419 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57419 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57420 : List Nat := [2,4,8,16,1,17,18,20,512,14,538,529,9,529,26,19,538,513,14,26,513,1,0,2,18,0,522,529,539,522,4,26,21,1,539,512]

theorem envBound57420 : H12AffineFastState.Bounded env57420 := by
  intro p hp
  have h : env57420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57419_57420 : H12AffineEnvironment.transform 4 1 env57419 = env57420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57419 == env57420) = true)

def env57421 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,4096,41,4128,137,262,4492,4503,392,137,4357,32,309,34,160,277,4123,4128,4525,522,36,169,257,0,4493,512]

theorem envBound57421 : H12AffineFastState.Bounded env57421 := by
  intro p hp
  have h : env57421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57415_57421 : H12AffineEnvironment.transform 5 49 env57415 = env57421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57415 == env57421) = true)

theorem identity57421 : scanCanonicalize (H12AffineFastState.compose env57421 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57422 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,555,41,523,137,262,935,956,392,137,814,32,309,34,160,277,560,523,902,522,36,169,257,0,934,512]

theorem envBound57422 : H12AffineFastState.Bounded env57422 := by
  intro p hp
  have h : env57422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57421_57422 : H12AffineEnvironment.transform 11 555 env57421 = env57422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57421 == env57422) = true)

theorem identity57422 : scanCanonicalize (H12AffineFastState.compose env57422 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57422 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57423 : List Nat := [2,4,8,16,32,49,128,15,512,135,544,555,41,523,137,9,680,691,135,137,545,32,58,34,160,26,560,523,649,522,36,169,14,0,681,512]

theorem envBound57423 : H12AffineFastState.Bounded env57423 := by
  intro p hp
  have h : env57423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57422_57423 : H12AffineEnvironment.transform 7 15 env57422 = env57423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57422 == env57423) = true)

theorem identity57423 : scanCanonicalize (H12AffineFastState.compose env57423 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57423 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57424 : List Nat := [2,4,8,16,32,49,50,15,512,53,544,555,41,523,59,9,538,513,53,59,545,32,58,34,18,26,560,523,571,522,36,27,14,0,539,512]

theorem envBound57424 : H12AffineFastState.Bounded env57424 := by
  intro p hp
  have h : env57424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57423_57424 : H12AffineEnvironment.transform 6 50 env57423 = env57424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57423 == env57424) = true)

theorem identity57424 : scanCanonicalize (H12AffineFastState.compose env57424 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57424 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env57425 : List Nat := [2,4,8,16,10,27,24,15,512,31,522,513,3,523,17,9,538,513,31,17,523,10,16,8,18,26,538,523,529,522,14,27,14,0,539,512]

theorem envBound57425 : H12AffineFastState.Bounded env57425 := by
  intro p hp
  have h : env57425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57424_57425 : H12AffineEnvironment.transform 4 10 env57424 = env57425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57424 == env57425) = true)

theorem identity57425 : scanCanonicalize (H12AffineFastState.compose env57425 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57426 : List Nat := [2,4,8,10,10,1,2,15,512,5,522,513,3,523,11,9,512,513,5,11,523,10,10,8,8,0,512,523,523,522,14,1,14,0,513,512]

theorem envBound57426 : H12AffineFastState.Bounded env57426 := by
  intro p hp
  have h : env57426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57425_57426 : H12AffineEnvironment.transform 3 10 env57425 = env57426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57425 == env57426) = true)

def env57427 : List Nat := [2,4,8,16,32,64,128,256,512,393,814,4096,88,4177,248,375,4605,4582,393,248,4469,32,308,82,209,357,4122,4177,4525,523,85,169,257,112,4604,512]

theorem envBound57427 : H12AffineFastState.Bounded env57427 := by
  intro p hp
  have h : env57427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57414_57427 : H12AffineEnvironment.transform 9 393 env57414 = env57427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env57414 == env57427) = true)

def env57428 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,4096,40,4129,136,263,4493,4502,393,136,4357,32,308,34,161,277,4122,4129,4525,523,37,169,257,0,4492,512]

theorem envBound57428 : H12AffineFastState.Bounded env57428 := by
  intro p hp
  have h : env57428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57427_57428 : H12AffineEnvironment.transform 5 48 env57427 = env57428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57427 == env57428) = true)

theorem identity57428 : scanCanonicalize (H12AffineFastState.compose env57428 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 902) := by decide +kernel

theorem selectedBound57428 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57429 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,902,40,935,136,263,523,528,393,136,643,32,308,34,161,277,924,935,555,523,37,169,257,0,522,512]

theorem envBound57429 : H12AffineFastState.Bounded env57429 := by
  intro p hp
  have h : env57429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57428_57429 : H12AffineEnvironment.transform 11 902 env57428 = env57429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 902 env57428 == env57429) = true)

theorem identity57429 : scanCanonicalize (H12AffineFastState.compose env57429 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound57429 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57430 : List Nat := [2,4,8,16,32,48,128,256,277,393,59,147,40,178,136,263,286,261,393,136,406,32,308,34,161,277,137,178,318,286,37,169,257,0,287,277]

theorem envBound57430 : H12AffineFastState.Bounded env57430 := by
  intro p hp
  have h : env57430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57429_57430 : H12AffineEnvironment.transform 8 277 env57429 = env57430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env57429 == env57430) = true)

theorem identity57430 : scanCanonicalize (H12AffineFastState.compose env57430 (packedSelected [0,1,4,7,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57430 : packedSelected [0,1,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57431 : List Nat := [2,4,8,16,32,48,128,31,10,150,59,147,40,178,136,24,1,26,150,136,137,32,43,34,161,10,137,178,33,1,37,169,30,0,0,10]

theorem envBound57431 : H12AffineFastState.Bounded env57431 := by
  intro p hp
  have h : env57431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57430_57431 : H12AffineEnvironment.transform 7 31 env57430 = env57431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57430 == env57431) = true)

theorem identity57431 : scanCanonicalize (H12AffineFastState.compose env57431 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57431 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57432 : List Nat := [2,4,8,16,32,48,40,31,10,62,59,59,40,26,32,24,1,26,62,32,33,32,43,34,9,10,33,26,33,1,37,1,30,0,0,10]

theorem envBound57432 : H12AffineFastState.Bounded env57432 := by
  intro p hp
  have h : env57432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57431_57432 : H12AffineEnvironment.transform 6 40 env57431 = env57432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57431 == env57432) = true)

def env57433 : List Nat := [2,4,8,0,32,32,40,15,10,46,43,43,40,10,32,8,1,10,46,32,33,32,43,34,9,10,33,10,33,1,37,1,14,0,0,10]

theorem envBound57433 : H12AffineFastState.Bounded env57433 := by
  intro p hp
  have h : env57433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57432_57433 : H12AffineEnvironment.transform 3 0 env57432 = env57433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57432 == env57433) = true)

def env57434 : List Nat := [2,4,8,1,32,33,40,14,10,47,42,42,40,11,32,9,1,11,47,32,33,32,43,34,9,10,33,11,33,1,37,1,15,0,0,10]

theorem envBound57434 : H12AffineFastState.Bounded env57434 := by
  intro p hp
  have h : env57434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57432_57434 : H12AffineEnvironment.transform 3 1 env57432 = env57434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57432 == env57434) = true)

theorem identity57434 : scanCanonicalize (H12AffineFastState.compose env57434 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57435 : List Nat := [2,4,8,1,11,10,3,14,10,4,1,1,3,11,11,9,1,11,4,11,10,11,0,9,9,10,10,11,10,1,14,1,15,0,0,10]

theorem envBound57435 : H12AffineFastState.Bounded env57435 := by
  intro p hp
  have h : env57435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57434_57435 : H12AffineEnvironment.transform 4 11 env57434 = env57435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57434 == env57435) = true)

def env57436 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,4096,41,4128,137,262,4492,4503,393,137,4356,32,308,35,160,276,4122,4128,4525,523,36,169,257,1,4493,512]

theorem envBound57436 : H12AffineFastState.Bounded env57436 := by
  intro p hp
  have h : env57436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57427_57436 : H12AffineEnvironment.transform 5 49 env57427 = env57436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57427 == env57436) = true)

theorem identity57436 : scanCanonicalize (H12AffineFastState.compose env57436 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 814) := by decide +kernel

theorem selectedBound57436 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57437 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,814,41,782,137,262,674,697,393,137,554,32,308,35,160,276,820,782,643,523,36,169,257,1,675,512]

theorem envBound57437 : H12AffineFastState.Bounded env57437 := by
  intro p hp
  have h : env57437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57436_57437 : H12AffineEnvironment.transform 11 814 env57436 = env57437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 814 env57436 == env57437) = true)

theorem identity57437 : scanCanonicalize (H12AffineFastState.compose env57437 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57437 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57438 : List Nat := [2,4,8,16,32,49,128,256,10,393,292,292,41,260,137,262,168,179,393,137,32,32,308,35,160,276,318,260,137,1,36,169,257,1,169,10]

theorem envBound57438 : H12AffineFastState.Bounded env57438 := by
  intro p hp
  have h : env57438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57437_57438 : H12AffineEnvironment.transform 8 10 env57437 = env57438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57437 == env57438) = true)

theorem identity57438 : scanCanonicalize (H12AffineFastState.compose env57438 (packedSelected [0,4,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57438 : packedSelected [0,4,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57439 : List Nat := [2,4,8,16,32,49,128,30,10,151,58,58,41,26,137,24,168,179,151,137,32,32,42,35,160,10,32,26,137,1,36,169,31,1,169,10]

theorem envBound57439 : H12AffineFastState.Bounded env57439 := by
  intro p hp
  have h : env57439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57438_57439 : H12AffineEnvironment.transform 7 30 env57438 = env57439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57438 == env57439) = true)

theorem identity57439 : scanCanonicalize (H12AffineFastState.compose env57439 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57439 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57440 : List Nat := [2,4,8,16,32,49,41,30,10,62,58,58,41,26,32,24,1,26,62,32,32,32,42,35,9,10,32,26,32,1,36,0,31,1,0,10]

theorem envBound57440 : H12AffineFastState.Bounded env57440 := by
  intro p hp
  have h : env57440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57439_57440 : H12AffineEnvironment.transform 6 41 env57439 = env57440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57439 == env57440) = true)

def env57441 : List Nat := [2,4,8,0,32,33,41,14,10,46,42,42,41,10,32,8,1,10,46,32,32,32,42,35,9,10,32,10,32,1,36,0,15,1,0,10]

theorem envBound57441 : H12AffineFastState.Bounded env57441 := by
  intro p hp
  have h : env57441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57440_57441 : H12AffineEnvironment.transform 3 0 env57440 = env57441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57440 == env57441) = true)

theorem identity57441 : scanCanonicalize (H12AffineFastState.compose env57441 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57442 : List Nat := [2,4,8,0,11,10,2,14,10,5,1,1,2,10,11,8,1,10,5,11,11,11,1,8,9,10,11,10,11,1,15,0,15,1,0,10]

theorem envBound57442 : H12AffineFastState.Bounded env57442 := by
  intro p hp
  have h : env57442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57441_57442 : H12AffineEnvironment.transform 4 11 env57441 = env57442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57441 == env57442) = true)

def env57443 : List Nat := [2,4,8,1,32,32,41,15,10,47,43,43,41,11,32,9,1,11,47,32,32,32,42,35,9,10,32,11,32,1,36,0,14,1,0,10]

theorem envBound57443 : H12AffineFastState.Bounded env57443 := by
  intro p hp
  have h : env57443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57440_57443 : H12AffineEnvironment.transform 3 1 env57440 = env57443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57440 == env57443) = true)

def env57444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142598,28889,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57444 : H12AffineFastState.Bounded env57444 := by
  intro p hp
  have h : env57444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57407_57444 : H12AffineEnvironment.transform 21 41089 env57407 = env57444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57407 == env57444) = true)

theorem identity57444 : scanCanonicalize (H12AffineFastState.compose env57444 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17848) := by decide +kernel

theorem selectedBound57444 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17848,65536,78034,82112,1024,17848,2097152,25913,2101312,2126910,28889,2113600,86437,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57445 : H12AffineFastState.Bounded env57445 := by
  intro p hp
  have h : env57445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57444_57445 : H12AffineEnvironment.transform 14 17848 env57444 = env57445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17848 env57444 == env57445) = true)

theorem identity57445 : scanCanonicalize (H12AffineFastState.compose env57445 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound57445 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12513,65536,78034,79257,1024,12513,2097152,4192,2101312,2097511,1408,2110745,75004,13657,77954,68867,2176391,74119,257,2168099,78035,9993]

theorem envBound57446 : H12AffineFastState.Bounded env57446 := by
  intro p hp
  have h : env57446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57445_57446 : H12AffineEnvironment.transform 13 13657 env57445 = env57446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env57445 == env57446) = true)

theorem identity57446 : scanCanonicalize (H12AffineFastState.compose env57446 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57446 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,12513,65536,78034,79257,1024,12513,71050,4192,67018,70893,1408,73875,75004,13657,77954,68867,8205,74119,257,169,78035,9993]

theorem envBound57447 : H12AffineFastState.Bounded env57447 := by
  intro p hp
  have h : env57447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57446_57447 : H12AffineEnvironment.transform 20 71050 env57446 = env57447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57446 == env57447) = true)

theorem identity57447 : scanCanonicalize (H12AffineFastState.compose env57447 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57447 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,65536,71130,69777,1024,5609,71050,4192,67018,70893,1408,66971,66036,4177,71050,68867,1285,66703,257,169,71131,513]

theorem envBound57448 : H12AffineFastState.Bounded env57448 := by
  intro p hp
  have h : env57448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57447_57448 : H12AffineEnvironment.transform 12 1288 env57447 = env57448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57447 == env57448) = true)

theorem identity57448 : scanCanonicalize (H12AffineFastState.compose env57448 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound57448 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,514,6104,4755,1024,5609,6024,4192,1992,5871,1408,1945,1014,4177,6024,3841,1285,1677,257,169,6105,513]

theorem envBound57449 : H12AffineFastState.Bounded env57449 := by
  intro p hp
  have h : env57449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57448_57449 : H12AffineEnvironment.transform 15 514 env57448 = env57449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env57448 == env57449) = true)

theorem identity57449 : scanCanonicalize (H12AffineFastState.compose env57449 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57449 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,445,1029,514,1588,895,1024,1029,1636,396,1992,1795,1408,1945,1014,445,1636,3841,1285,1677,257,169,1589,513]

theorem envBound57450 : H12AffineFastState.Bounded env57450 := by
  intro p hp
  have h : env57450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57449_57450 : H12AffineEnvironment.transform 11 492 env57449 = env57450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57449 == env57450) = true)

theorem identity57450 : scanCanonicalize (H12AffineFastState.compose env57450 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57450 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,492,1288,445,1029,514,1588,895,1024,1029,1636,396,1992,1795,1408,1945,1014,445,1636,10,1285,1677,257,169,1589,513]

theorem envBound57451 : H12AffineFastState.Bounded env57451 := by
  intro p hp
  have h : env57451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57450_57451 : H12AffineEnvironment.transform 10 1803 env57450 = env57451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57450 == env57451) = true)

theorem identity57451 : scanCanonicalize (H12AffineFastState.compose env57451 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound57451 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57452 : List Nat := [2,4,8,16,32,64,128,256,512,904,131,492,640,445,909,514,444,895,904,909,492,396,64,139,520,17,1014,445,492,10,653,261,257,169,445,513]

theorem envBound57452 : H12AffineFastState.Bounded env57452 := by
  intro p hp
  have h : env57452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57451_57452 : H12AffineEnvironment.transform 9 904 env57451 = env57452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env57451 == env57452) = true)

theorem identity57452 : scanCanonicalize (H12AffineFastState.compose env57452 (packedSelected [0,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57452 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57453 : List Nat := [2,4,8,1,32,64,128,256,512,904,131,492,640,428,909,514,429,878,904,909,492,396,64,139,520,0,999,428,492,10,653,261,257,169,428,513]

theorem envBound57453 : H12AffineFastState.Bounded env57453 := by
  intro p hp
  have h : env57453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57452_57453 : H12AffineEnvironment.transform 3 1 env57452 = env57453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57452 == env57453) = true)

theorem identity57453 : scanCanonicalize (H12AffineFastState.compose env57453 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57453 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57454 : List Nat := [2,4,8,1,10,64,128,256,512,904,131,454,640,390,909,514,391,836,904,909,454,396,64,139,520,0,973,390,454,10,653,261,257,131,390,513]

theorem envBound57454 : H12AffineFastState.Bounded env57454 := by
  intro p hp
  have h : env57454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57453_57454 : H12AffineEnvironment.transform 4 10 env57453 = env57454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57453 == env57454) = true)

theorem identity57454 : scanCanonicalize (H12AffineFastState.compose env57454 (packedSelected [3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 335) := by decide +kernel

theorem selectedBound57454 : packedSelected [3,4,9] rootPS < 2^1333 := by decide +kernel

def env57455 : List Nat := [2,4,8,1,10,64,128,256,335,199,131,454,463,390,194,333,391,11,199,194,454,396,64,139,327,0,130,390,454,10,450,261,257,131,390,334]

theorem envBound57455 : H12AffineFastState.Bounded env57455 := by
  intro p hp
  have h : env57455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57454_57455 : H12AffineEnvironment.transform 8 335 env57454 = env57455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 335 env57454 == env57455) = true)

theorem identity57455 : scanCanonicalize (H12AffineFastState.compose env57455 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57456 : List Nat := [2,4,8,1,10,64,8,256,335,79,11,334,327,270,74,333,271,11,79,74,334,260,64,3,327,0,10,270,334,10,330,261,257,11,270,334]

theorem envBound57456 : H12AffineFastState.Bounded env57456 := by
  intro p hp
  have h : env57456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57455_57456 : H12AffineEnvironment.transform 6 8 env57455 = env57456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57455 == env57456) = true)

theorem identity57456 : scanCanonicalize (H12AffineFastState.compose env57456 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound57456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57457 : List Nat := [2,4,8,1,10,64,8,7,72,79,11,73,64,9,74,74,8,11,79,74,73,3,64,3,64,0,10,9,73,10,77,2,6,11,9,73]

theorem envBound57457 : H12AffineFastState.Bounded env57457 := by
  intro p hp
  have h : env57457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57456_57457 : H12AffineEnvironment.transform 7 7 env57456 = env57457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env57456 == env57457) = true)

theorem identity57457 : scanCanonicalize (H12AffineFastState.compose env57457 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57458 : List Nat := [2,4,2,1,0,64,2,7,66,69,1,67,64,3,64,64,2,1,69,64,67,3,64,3,64,0,0,3,67,0,71,2,6,1,3,67]

theorem envBound57458 : H12AffineFastState.Bounded env57458 := by
  intro p hp
  have h : env57458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57457_57458 : H12AffineEnvironment.transform 2 2 env57457 = env57458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57457 == env57458) = true)

def env57459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295815,4247640,6348993,4273309,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256465]

theorem envBound57459 : H12AffineFastState.Bounded env57459 := by
  intro p hp
  have h : env57459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57406_57459 : H12AffineEnvironment.transform 17 82113 env57406 = env57459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57406 == env57459) = true)

def env57460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142599,28888,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57460 : H12AffineFastState.Bounded env57460 := by
  intro p hp
  have h : env57460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57459_57460 : H12AffineEnvironment.transform 21 41088 env57459 = env57460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57459 == env57460) = true)

theorem identity57460 : scanCanonicalize (H12AffineFastState.compose env57460 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 20648) := by decide +kernel

theorem selectedBound57460 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20648,65536,78034,82113,1024,20648,2097152,28712,2101313,2122031,28888,2113601,83125,16384,77954,96347,2176390,74118,257,2187387,78035,21073]

theorem envBound57461 : H12AffineFastState.Bounded env57461 := by
  intro p hp
  have h : env57461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57460_57461 : H12AffineEnvironment.transform 14 20648 env57460 = env57461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20648 env57460 == env57461) = true)

theorem identity57461 : scanCanonicalize (H12AffineFastState.compose env57461 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 83418) := by decide +kernel

theorem selectedBound57461 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20648,65536,78034,82113,1024,20648,83418,28712,87451,74997,28888,66971,83125,16384,77954,96347,28764,74118,257,9633,78035,21073]

theorem envBound57462 : H12AffineFastState.Bounded env57462 := by
  intro p hp
  have h : env57462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57461_57462 : H12AffineEnvironment.transform 20 83418 env57461 = env57462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83418 env57461 == env57462) = true)

theorem identity57462 : scanCanonicalize (H12AffineFastState.compose env57462 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57462 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,65536,78034,69776,1024,249,71051,8313,67018,74997,8329,66971,70884,4177,77954,75786,8205,74118,257,9633,78035,512]

theorem envBound57463 : H12AffineFastState.Bounded env57463 := by
  intro p hp
  have h : env57463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57462_57463 : H12AffineEnvironment.transform 13 4177 env57462 = env57463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57462 == env57463) = true)

theorem identity57463 : scanCanonicalize (H12AffineFastState.compose env57463 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound57463 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,249,374,12708,4582,1024,249,5373,8313,1212,9603,8329,1261,5522,4177,12788,10620,8205,8432,257,9633,12709,512]

theorem envBound57464 : H12AffineFastState.Bounded env57464 := by
  intro p hp
  have h : env57464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57463_57464 : H12AffineEnvironment.transform 15 374 env57463 = env57464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env57463 == env57464) = true)

theorem identity57464 : scanCanonicalize (H12AffineFastState.compose env57464 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3838) := by decide +kernel

theorem selectedBound57464 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3838,4177,249,374,8026,4582,1024,249,5373,3719,1212,2941,3703,1261,5522,4177,7946,1922,3827,3598,257,2911,8027,512]

theorem envBound57465 : H12AffineFastState.Bounded env57465 := by
  intro p hp
  have h : env57465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57464_57465 : H12AffineEnvironment.transform 12 3838 env57464 = env57465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3838 env57464 == env57465) = true)

theorem identity57465 : scanCanonicalize (H12AffineFastState.compose env57465 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57465 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,89,4177,249,374,4605,4582,1024,249,5373,32,1212,1498,208,1261,5522,4177,4525,1922,84,169,257,1528,4604,512]

theorem envBound57466 : H12AffineFastState.Bounded env57466 := by
  intro p hp
  have h : env57466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57465_57466 : H12AffineEnvironment.transform 10 1703 env57465 = env57466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57465 == env57466) = true)

def env57467 : List Nat := [2,4,8,16,32,64,128,256,512,392,815,4096,89,4177,249,374,4605,4582,392,249,4469,32,308,82,208,357,4122,4177,4525,522,84,169,257,112,4604,512]

theorem envBound57467 : H12AffineFastState.Bounded env57467 := by
  intro p hp
  have h : env57467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57466_57467 : H12AffineEnvironment.transform 9 392 env57466 = env57467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env57466 == env57467) = true)

def env57468 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,4096,41,4129,137,262,4493,4502,392,137,4357,32,308,34,160,277,4122,4129,4525,522,36,169,257,0,4492,512]

theorem envBound57468 : H12AffineFastState.Bounded env57468 := by
  intro p hp
  have h : env57468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57467_57468 : H12AffineEnvironment.transform 5 48 env57467 = env57468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57467 == env57468) = true)

theorem identity57468 : scanCanonicalize (H12AffineFastState.compose env57468 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 815) := by decide +kernel

theorem selectedBound57468 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57469 : List Nat := [2,4,8,16,32,48,128,256,512,392,815,815,41,782,137,262,674,697,392,137,554,32,308,34,160,277,821,782,642,522,36,169,257,0,675,512]

theorem envBound57469 : H12AffineFastState.Bounded env57469 := by
  intro p hp
  have h : env57469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57468_57469 : H12AffineEnvironment.transform 11 815 env57468 = env57469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 815 env57468 == env57469) = true)

theorem identity57469 : scanCanonicalize (H12AffineFastState.compose env57469 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57469 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57470 : List Nat := [2,4,8,16,32,48,128,256,11,392,292,292,41,261,137,262,169,178,392,137,33,32,308,34,160,277,318,261,137,1,36,169,257,0,168,11]

theorem envBound57470 : H12AffineFastState.Bounded env57470 := by
  intro p hp
  have h : env57470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57469_57470 : H12AffineEnvironment.transform 8 11 env57469 = env57470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57469 == env57470) = true)

theorem identity57470 : scanCanonicalize (H12AffineFastState.compose env57470 (packedSelected [0,4,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57470 : packedSelected [0,4,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57471 : List Nat := [2,4,8,16,32,48,128,31,11,151,59,59,41,26,137,25,169,178,151,137,33,32,43,34,160,10,33,26,137,1,36,169,30,0,168,11]

theorem envBound57471 : H12AffineFastState.Bounded env57471 := by
  intro p hp
  have h : env57471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57470_57471 : H12AffineEnvironment.transform 7 31 env57470 = env57471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57470 == env57471) = true)

theorem identity57471 : scanCanonicalize (H12AffineFastState.compose env57471 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57471 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57472 : List Nat := [2,4,8,16,32,48,40,31,11,63,59,59,41,26,33,25,1,26,63,33,33,32,43,34,8,10,33,26,33,1,36,1,30,0,0,11]

theorem envBound57472 : H12AffineFastState.Bounded env57472 := by
  intro p hp
  have h : env57472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57471_57472 : H12AffineEnvironment.transform 6 40 env57471 = env57472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57471 == env57472) = true)

def env57473 : List Nat := [2,4,8,0,32,32,40,15,11,47,43,43,41,10,33,9,1,10,47,33,33,32,43,34,8,10,33,10,33,1,36,1,14,0,0,11]

theorem envBound57473 : H12AffineFastState.Bounded env57473 := by
  intro p hp
  have h : env57473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57473 : H12AffineEnvironment.transform 3 0 env57472 = env57473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57472 == env57473) = true)

def env57474 : List Nat := [2,4,8,1,32,33,40,14,11,46,42,42,41,11,33,8,1,11,46,33,33,32,43,34,8,10,33,11,33,1,36,1,15,0,0,11]

theorem envBound57474 : H12AffineFastState.Bounded env57474 := by
  intro p hp
  have h : env57474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57474 : H12AffineEnvironment.transform 3 1 env57472 = env57474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57472 == env57474) = true)

theorem identity57474 : scanCanonicalize (H12AffineFastState.compose env57474 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57475 : List Nat := [2,4,8,1,11,10,3,14,11,5,1,1,2,11,10,8,1,11,5,10,10,11,0,9,8,10,10,11,10,1,15,1,15,0,0,11]

theorem envBound57475 : H12AffineFastState.Bounded env57475 := by
  intro p hp
  have h : env57475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57474_57475 : H12AffineEnvironment.transform 4 11 env57474 = env57475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57474 == env57475) = true)

def env57476 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,4096,40,4128,136,263,4492,4503,392,136,4356,32,308,35,161,276,4122,4128,4525,522,37,169,257,1,4493,512]

theorem envBound57476 : H12AffineFastState.Bounded env57476 := by
  intro p hp
  have h : env57476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57467_57476 : H12AffineEnvironment.transform 5 49 env57467 = env57476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57467 == env57476) = true)

theorem identity57476 : scanCanonicalize (H12AffineFastState.compose env57476 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 902) := by decide +kernel

theorem selectedBound57476 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57477 : List Nat := [2,4,8,16,32,49,128,256,512,392,815,902,40,934,136,263,522,529,392,136,642,32,308,35,161,276,924,934,555,522,37,169,257,1,523,512]

theorem envBound57477 : H12AffineFastState.Bounded env57477 := by
  intro p hp
  have h : env57477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57476_57477 : H12AffineEnvironment.transform 11 902 env57476 = env57477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 902 env57476 == env57477) = true)

theorem identity57477 : scanCanonicalize (H12AffineFastState.compose env57477 (packedSelected [3,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound57477 : packedSelected [3,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57478 : List Nat := [2,4,8,16,32,49,128,256,277,392,58,147,40,179,136,263,287,260,392,136,407,32,308,35,161,276,137,179,318,287,37,169,257,1,286,277]

theorem envBound57478 : H12AffineFastState.Bounded env57478 := by
  intro p hp
  have h : env57478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57477_57478 : H12AffineEnvironment.transform 8 277 env57477 = env57478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env57477 == env57478) = true)

theorem identity57478 : scanCanonicalize (H12AffineFastState.compose env57478 (packedSelected [0,1,4,7,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57478 : packedSelected [0,1,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57479 : List Nat := [2,4,8,16,32,49,128,30,11,150,58,147,40,179,136,25,1,26,150,136,137,32,42,35,161,10,137,179,32,1,37,169,31,1,0,11]

theorem envBound57479 : H12AffineFastState.Bounded env57479 := by
  intro p hp
  have h : env57479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57478_57479 : H12AffineEnvironment.transform 7 30 env57478 = env57479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57478 == env57479) = true)

theorem identity57479 : scanCanonicalize (H12AffineFastState.compose env57479 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57479 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57480 : List Nat := [2,4,8,16,32,49,41,30,11,63,58,58,40,26,33,25,1,26,63,33,32,32,42,35,8,10,32,26,32,1,37,0,31,1,0,11]

theorem envBound57480 : H12AffineFastState.Bounded env57480 := by
  intro p hp
  have h : env57480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57479_57480 : H12AffineEnvironment.transform 6 41 env57479 = env57480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57479 == env57480) = true)

def env57481 : List Nat := [2,4,8,0,32,33,41,14,11,47,42,42,40,10,33,9,1,10,47,33,32,32,42,35,8,10,32,10,32,1,37,0,15,1,0,11]

theorem envBound57481 : H12AffineFastState.Bounded env57481 := by
  intro p hp
  have h : env57481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57480_57481 : H12AffineEnvironment.transform 3 0 env57480 = env57481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57480 == env57481) = true)

theorem identity57481 : scanCanonicalize (H12AffineFastState.compose env57481 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57482 : List Nat := [2,4,8,0,11,10,2,14,11,4,1,1,3,10,10,9,1,10,4,10,11,11,1,8,8,10,11,10,11,1,14,0,15,1,0,11]

theorem envBound57482 : H12AffineFastState.Bounded env57482 := by
  intro p hp
  have h : env57482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57481_57482 : H12AffineEnvironment.transform 4 11 env57481 = env57482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57481 == env57482) = true)

def env57483 : List Nat := [2,4,8,1,32,32,41,15,11,46,43,43,40,11,33,8,1,11,46,33,32,32,42,35,8,10,32,11,32,1,37,0,14,1,0,11]

theorem envBound57483 : H12AffineFastState.Bounded env57483 := by
  intro p hp
  have h : env57483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57480_57483 : H12AffineEnvironment.transform 3 1 env57480 = env57483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57480 == env57483) = true)

def env57484 : List Nat := [2,4,8,16,32,64,128,256,512,393,814,4096,89,4177,249,374,4605,4582,393,249,4468,32,309,83,208,356,4123,4177,4525,523,84,169,257,113,4604,512]

theorem envBound57484 : H12AffineFastState.Bounded env57484 := by
  intro p hp
  have h : env57484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57466_57484 : H12AffineEnvironment.transform 9 393 env57466 = env57484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env57466 == env57484) = true)

def env57485 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,4096,41,4129,137,262,4493,4502,393,137,4356,32,309,35,160,276,4123,4129,4525,523,36,169,257,1,4492,512]

theorem envBound57485 : H12AffineFastState.Bounded env57485 := by
  intro p hp
  have h : env57485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57484_57485 : H12AffineEnvironment.transform 5 48 env57484 = env57485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57484 == env57485) = true)

theorem identity57485 : scanCanonicalize (H12AffineFastState.compose env57485 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57486 : List Nat := [2,4,8,16,32,48,128,256,512,393,814,555,41,522,137,262,934,957,393,137,815,32,309,35,160,276,560,522,902,523,36,169,257,1,935,512]

theorem envBound57486 : H12AffineFastState.Bounded env57486 := by
  intro p hp
  have h : env57486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57485_57486 : H12AffineEnvironment.transform 11 555 env57485 = env57486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57485 == env57486) = true)

theorem identity57486 : scanCanonicalize (H12AffineFastState.compose env57486 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57486 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57487 : List Nat := [2,4,8,16,32,48,128,15,512,134,545,555,41,522,137,9,681,690,134,137,544,32,58,35,160,27,560,522,649,523,36,169,14,1,680,512]

theorem envBound57487 : H12AffineFastState.Bounded env57487 := by
  intro p hp
  have h : env57487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57486_57487 : H12AffineEnvironment.transform 7 15 env57486 = env57487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57486 == env57487) = true)

theorem identity57487 : scanCanonicalize (H12AffineFastState.compose env57487 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57487 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57488 : List Nat := [2,4,8,16,32,48,51,15,512,53,545,555,41,522,58,9,538,513,53,58,544,32,58,35,19,27,560,522,570,523,36,26,14,1,539,512]

theorem envBound57488 : H12AffineFastState.Bounded env57488 := by
  intro p hp
  have h : env57488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57487_57488 : H12AffineEnvironment.transform 6 51 env57487 = env57488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57487 == env57488) = true)

theorem identity57488 : scanCanonicalize (H12AffineFastState.compose env57488 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57488 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env57489 : List Nat := [2,4,8,16,10,26,25,15,512,31,523,513,3,522,16,9,538,513,31,16,522,10,16,9,19,27,538,522,528,523,14,26,14,1,539,512]

theorem envBound57489 : H12AffineFastState.Bounded env57489 := by
  intro p hp
  have h : env57489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57488_57489 : H12AffineEnvironment.transform 4 10 env57488 = env57489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57488 == env57489) = true)

theorem identity57489 : scanCanonicalize (H12AffineFastState.compose env57489 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57490 : List Nat := [2,4,8,10,10,0,3,15,512,5,523,513,3,522,10,9,512,513,5,10,522,10,10,9,9,1,512,522,522,523,14,0,14,1,513,512]

theorem envBound57490 : H12AffineFastState.Bounded env57490 := by
  intro p hp
  have h : env57490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57489_57490 : H12AffineEnvironment.transform 3 10 env57489 = env57490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57489 == env57490) = true)

def env57491 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,4096,40,4128,136,263,4492,4503,393,136,4357,32,309,34,161,277,4123,4128,4525,523,37,169,257,0,4493,512]

theorem envBound57491 : H12AffineFastState.Bounded env57491 := by
  intro p hp
  have h : env57491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57484_57491 : H12AffineEnvironment.transform 5 49 env57484 = env57491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57484 == env57491) = true)

theorem identity57491 : scanCanonicalize (H12AffineFastState.compose env57491 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 642) := by decide +kernel

theorem selectedBound57491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57492 : List Nat := [2,4,8,16,32,49,128,256,512,393,814,642,40,674,136,263,782,789,393,136,903,32,309,34,161,277,665,674,815,523,37,169,257,0,783,512]

theorem envBound57492 : H12AffineFastState.Bounded env57492 := by
  intro p hp
  have h : env57492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57491_57492 : H12AffineEnvironment.transform 11 642 env57491 = env57492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 642 env57491 == env57492) = true)

theorem identity57492 : scanCanonicalize (H12AffineFastState.compose env57492 (packedSelected [5,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57492 : packedSelected [5,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57493 : List Nat := [2,4,8,16,32,49,128,20,512,157,570,642,40,674,136,19,538,513,157,136,659,32,33,34,161,1,665,674,571,523,37,169,21,0,539,512]

theorem envBound57493 : H12AffineFastState.Bounded env57493 := by
  intro p hp
  have h : env57493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57492_57493 : H12AffineEnvironment.transform 7 20 env57492 = env57493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57492 == env57493) = true)

theorem identity57493 : scanCanonicalize (H12AffineFastState.compose env57493 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound57493 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57494 : List Nat := [2,4,8,16,32,49,50,20,512,47,570,560,40,528,58,19,538,513,47,58,545,32,33,34,19,1,555,528,571,523,37,27,21,0,539,512]

theorem envBound57494 : H12AffineFastState.Bounded env57494 := by
  intro p hp
  have h : env57494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57493_57494 : H12AffineEnvironment.transform 6 50 env57493 = env57494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env57493 == env57494) = true)

theorem identity57494 : scanCanonicalize (H12AffineFastState.compose env57494 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57494 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57495 : List Nat := [2,4,8,16,0,17,18,20,512,15,538,528,8,528,26,19,538,513,15,26,513,0,1,2,19,1,523,528,539,523,5,27,21,0,539,512]

theorem envBound57495 : H12AffineFastState.Bounded env57495 := by
  intro p hp
  have h : env57495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57494_57495 : H12AffineEnvironment.transform 4 0 env57494 = env57495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57494 == env57495) = true)

def env57496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142598,28889,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57496 : H12AffineFastState.Bounded env57496 := by
  intro p hp
  have h : env57496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57459_57496 : H12AffineEnvironment.transform 21 41089 env57459 = env57496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57459 == env57496) = true)

theorem identity57496 : scanCanonicalize (H12AffineFastState.compose env57496 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 5609) := by decide +kernel

theorem selectedBound57496 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5609,65536,78034,82113,1024,5609,2097152,13672,2101312,2106479,28889,2113600,66037,16384,77954,96346,2176391,74119,257,2187386,78035,21072]

theorem envBound57497 : H12AffineFastState.Bounded env57497 := by
  intro p hp
  have h : env57497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57496_57497 : H12AffineEnvironment.transform 14 5609 env57496 = env57497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5609 env57496 == env57497) = true)

theorem identity57497 : scanCanonicalize (H12AffineFastState.compose env57497 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound57497 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5609,65536,78034,79256,1024,5609,2097152,13672,2101312,2106479,1408,2110745,66037,13657,77954,68867,2176391,74119,257,2168099,78035,9993]

theorem envBound57498 : H12AffineFastState.Bounded env57498 := by
  intro p hp
  have h : env57498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57497_57498 : H12AffineEnvironment.transform 13 13657 env57497 = env57498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env57497 == env57498) = true)

theorem identity57498 : scanCanonicalize (H12AffineFastState.compose env57498 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57498 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13657,5609,65536,78034,79256,1024,5609,71050,13672,67018,78309,1408,73875,66037,13657,77954,68867,8205,74119,257,169,78035,9993]

theorem envBound57499 : H12AffineFastState.Bounded env57499 := by
  intro p hp
  have h : env57499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57498_57499 : H12AffineEnvironment.transform 20 71050 env57498 = env57499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57498 == env57499) = true)

theorem identity57499 : scanCanonicalize (H12AffineFastState.compose env57499 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57499 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,65536,71130,69776,1024,5609,71050,4192,67018,70893,1408,66971,66037,4177,71050,68867,1285,66703,257,169,71131,513]

theorem envBound57500 : H12AffineFastState.Bounded env57500 := by
  intro p hp
  have h : env57500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57499_57500 : H12AffineEnvironment.transform 12 1288 env57499 = env57500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57499 == env57500) = true)

theorem identity57500 : scanCanonicalize (H12AffineFastState.compose env57500 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound57500 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4177,5609,514,6104,4754,1024,5609,6024,4192,1992,5871,1408,1945,1015,4177,6024,3841,1285,1677,257,169,6105,513]

theorem envBound57501 : H12AffineFastState.Bounded env57501 := by
  intro p hp
  have h : env57501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57500_57501 : H12AffineEnvironment.transform 15 514 env57500 = env57501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env57500 == env57501) = true)

theorem identity57501 : scanCanonicalize (H12AffineFastState.compose env57501 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57501 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,445,1029,514,1588,894,1024,1029,1636,396,1992,1795,1408,1945,1015,445,1636,3841,1285,1677,257,169,1589,513]

theorem envBound57502 : H12AffineFastState.Bounded env57502 := by
  intro p hp
  have h : env57502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57501_57502 : H12AffineEnvironment.transform 11 492 env57501 = env57502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57501 == env57502) = true)

theorem identity57502 : scanCanonicalize (H12AffineFastState.compose env57502 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound57502 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,492,1288,445,1029,514,1588,894,1024,1029,1636,396,1992,1795,1408,1945,1015,445,1636,11,1285,1677,257,169,1589,513]

theorem envBound57503 : H12AffineFastState.Bounded env57503 := by
  intro p hp
  have h : env57503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57502_57503 : H12AffineEnvironment.transform 10 1802 env57502 = env57503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env57502 == env57503) = true)

theorem identity57503 : scanCanonicalize (H12AffineFastState.compose env57503 (packedSelected [0,4,7,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 905) := by decide +kernel

theorem selectedBound57503 : packedSelected [0,4,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57504 : List Nat := [2,4,8,16,32,64,128,256,512,905,131,492,641,445,908,514,445,894,905,908,493,396,65,138,521,16,1015,445,493,11,652,260,257,169,444,513]

theorem envBound57504 : H12AffineFastState.Bounded env57504 := by
  intro p hp
  have h : env57504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57503_57504 : H12AffineEnvironment.transform 9 905 env57503 = env57504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 905 env57503 == env57504) = true)

theorem identity57504 : scanCanonicalize (H12AffineFastState.compose env57504 (packedSelected [0,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound57504 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env57505 : List Nat := [2,4,8,16,32,48,128,256,512,905,131,412,641,445,908,514,445,782,905,908,413,396,49,138,521,16,903,445,413,11,652,260,257,169,444,513]

theorem envBound57505 : H12AffineFastState.Bounded env57505 := by
  intro p hp
  have h : env57505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57504_57505 : H12AffineEnvironment.transform 5 48 env57504 = env57505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env57504 == env57505) = true)

def env57506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430022,4247641,8409088,10798237,16384,77954,4315355,8463815,10564039,257,6406395,78035,4256464]

theorem envBound57506 : H12AffineFastState.Bounded env57506 := by
  intro p hp
  have h : env57506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57272_57506 : H12AffineEnvironment.transform 24 4247641 env57272 = env57506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env57272 == env57506) = true)

def env57507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4486237,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57507 : H12AffineFastState.Bounded env57507 := by
  intro p hp
  have h : env57507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57506_57507 : H12AffineEnvironment.transform 22 6336704 env57506 = env57507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336704 env57506 == env57507) = true)

def env57508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4273309,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57508 : H12AffineFastState.Bounded env57508 := by
  intro p hp
  have h : env57508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57507_57508 : H12AffineEnvironment.transform 17 82112 env57507 = env57508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57507 == env57508) = true)

def env57509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101312,2142598,28889,2113600,103453,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57509 : H12AffineFastState.Bounded env57509 := by
  intro p hp
  have h : env57509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57508_57509 : H12AffineEnvironment.transform 21 41088 env57508 = env57509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57508 == env57509) = true)

theorem identity57509 : scanCanonicalize (H12AffineFastState.compose env57509 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57509 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,32768,65536,74046,82112,1024,32768,2097152,41088,2097580,2138218,24885,2113600,99825,16384,74094,92599,2172011,74119,257,2187387,74047,17340]

theorem envBound57510 : H12AffineFastState.Bounded env57510 := by
  intro p hp
  have h : env57510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57509_57510 : H12AffineEnvironment.transform 11 492 env57509 = env57510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57509 == env57510) = true)

theorem identity57510 : scanCanonicalize (H12AffineFastState.compose env57510 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57510 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,16384,32768,65536,66614,82112,1024,32768,2097152,34184,2097580,2131298,17469,2113600,99825,16384,66662,85183,2163043,66703,257,2180467,66615,17340]

theorem envBound57511 : H12AffineFastState.Bounded env57511 := by
  intro p hp
  have h : env57511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57510_57511 : H12AffineEnvironment.transform 12 1288 env57510 = env57511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57510 == env57511) = true)

theorem identity57511 : scanCanonicalize (H12AffineFastState.compose env57511 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 83419) := by decide +kernel

theorem selectedBound57511 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,16384,32768,65536,66614,82112,1024,32768,83419,34184,83063,114873,17469,66971,99825,16384,66662,85183,17592,66703,257,168,66615,17340]

theorem envBound57512 : H12AffineFastState.Bounded env57512 := by
  intro p hp
  have h : env57512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57511_57512 : H12AffineEnvironment.transform 20 83419 env57511 = env57512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83419 env57511 == env57512) = true)

theorem identity57512 : scanCanonicalize (H12AffineFastState.compose env57512 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound57512 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,65536,66614,65916,1024,32768,66663,34184,67019,98565,1409,66971,99825,444,66662,68867,1284,66703,257,168,66615,512]

theorem envBound57513 : H12AffineFastState.Bounded env57513 := by
  intro p hp
  have h : env57513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57512_57513 : H12AffineEnvironment.transform 13 444 env57512 = env57513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env57512 == env57513) = true)

theorem identity57513 : scanCanonicalize (H12AffineFastState.compose env57513 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57513 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1288,444,32768,1874,868,1582,1024,32768,821,34184,665,34391,1409,713,33443,444,820,2641,1284,989,257,168,869,512]

theorem envBound57514 : H12AffineFastState.Bounded env57514 := by
  intro p hp
  have h : env57514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57513_57514 : H12AffineEnvironment.transform 15 1874 env57513 = env57514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57513 == env57514) = true)

def env57515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101313,2142599,28888,2113601,103452,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57515 : H12AffineFastState.Bounded env57515 := by
  intro p hp
  have h : env57515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57508_57515 : H12AffineEnvironment.transform 21 41089 env57508 = env57515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57508 == env57515) = true)

theorem identity57515 : scanCanonicalize (H12AffineFastState.compose env57515 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound57515 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,65536,78034,70765,1024,32768,2097152,41089,2101313,2142599,9333,2102508,103452,5293,77954,77047,2176390,74118,257,2176215,78035,1788]

theorem envBound57516 : H12AffineFastState.Bounded env57516 := by
  intro p hp
  have h : env57516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57515_57516 : H12AffineEnvironment.transform 13 5293 env57515 = env57516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env57515 == env57516) = true)

theorem identity57516 : scanCanonicalize (H12AffineFastState.compose env57516 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57516 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,65536,78034,70765,1024,32768,71050,41089,67019,107533,9333,65894,103452,5293,77954,77047,8204,74118,257,8541,78035,1788]

theorem envBound57517 : H12AffineFastState.Bounded env57517 := by
  intro p hp
  have h : env57517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57516_57517 : H12AffineEnvironment.transform 20 71050 env57516 = env57517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57516 == env57517) = true)

theorem identity57517 : scanCanonicalize (H12AffineFastState.compose env57517 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound57517 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,32768,33167,45405,38370,1024,32768,37893,41089,33860,9602,9333,33001,5523,5293,45325,44408,8204,40969,257,8541,45404,1788]

theorem envBound57518 : H12AffineFastState.Bounded env57518 := by
  intro p hp
  have h : env57518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57517_57518 : H12AffineEnvironment.transform 15 33167 env57517 = env57518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env57517 == env57518) = true)

def env57519 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5293,32768,33167,45325,38322,1024,32768,37893,41089,33812,9602,9253,32953,5523,5293,45325,44328,8204,40969,257,8461,45324,1708]

theorem envBound57519 : H12AffineFastState.Bounded env57519 := by
  intro p hp
  have h : env57519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57518_57519 : H12AffineEnvironment.transform 5 16 env57518 = env57519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57518 == env57519) = true)

theorem identity57519 : scanCanonicalize (H12AffineFastState.compose env57519 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound57519 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57520 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,8192,4097,32768,33167,45325,37150,172,32768,37033,41089,32952,8494,8329,32953,4415,4097,45325,43396,8204,40969,257,8461,45324,512]

theorem envBound57520 : H12AffineFastState.Bounded env57520 := by
  intro p hp
  have h : env57520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57519_57520 : H12AffineEnvironment.transform 9 172 env57519 = env57520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env57519 == env57520) = true)

theorem identity57520 : scanCanonicalize (H12AffineFastState.compose env57520 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57520 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57521 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2562,4097,32768,33167,39695,37150,172,32768,37033,35459,32952,2860,2699,32953,4415,4097,39695,33670,2574,35339,257,2831,39694,512]

theorem envBound57521 : H12AffineFastState.Bounded env57521 := by
  intro p hp
  have h : env57521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57520_57521 : H12AffineEnvironment.transform 12 2562 env57520 = env57521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57520 == env57521) = true)

theorem identity57521 : scanCanonicalize (H12AffineFastState.compose env57521 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57521 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57522 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,4096,2562,4097,2723,2860,4524,7101,172,2723,6666,32,2587,2860,2699,2586,4415,4097,4524,2341,2574,168,257,2831,4525,512]

theorem envBound57522 : H12AffineFastState.Bounded env57522 := by
  intro p hp
  have h : env57522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1