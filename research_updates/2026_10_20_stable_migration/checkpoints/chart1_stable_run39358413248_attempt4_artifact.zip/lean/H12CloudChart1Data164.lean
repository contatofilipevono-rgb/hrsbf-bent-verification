import H12CloudChart1Data163

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity41589 : scanCanonicalize (H12AffineFastState.compose env41589 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41589 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41590 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,17,8192,8232,8232,35,9228,9245,1025,8233,9245,1044,16,1078,8192,17,1,1061,17,0,8253,8201,36,9277,1077,1589]

theorem envBound41590 : H12AffineFastState.Bounded env41590 := by
  intro p hp
  have h : env41590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41589_41590 : H12AffineEnvironment.transform 5 17 env41589 = env41590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41589 == env41590) = true)

theorem identity41590 : scanCanonicalize (H12AffineFastState.compose env41590 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41590 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41591 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,8192,8232,8232,35,8248,8233,53,8233,8233,32,16,2,8192,17,1,17,17,0,8253,8201,36,8201,1,513]

theorem envBound41591 : H12AffineFastState.Bounded env41591 := by
  intro p hp
  have h : env41591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41590_41591 : H12AffineEnvironment.transform 9 52 env41590 = env41591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41590 == env41591) = true)

theorem identity41591 : scanCanonicalize (H12AffineFastState.compose env41591 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41591 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41592 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,0,0,35,16,1,53,1,1,32,16,2,40,17,1,17,17,0,21,33,36,33,1,513]

theorem envBound41592 : H12AffineFastState.Bounded env41592 := by
  intro p hp
  have h : env41592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41591_41592 : H12AffineEnvironment.transform 12 40 env41591 = env41592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41591 == env41592) = true)

theorem identity41592 : scanCanonicalize (H12AffineFastState.compose env41592 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound41592 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41593 : List Nat := [2,4,8,16,20,17,8,17,512,0,1,17,28,0,0,23,16,1,1,1,1,20,16,2,28,17,1,17,17,0,21,21,16,21,1,513]

theorem envBound41593 : H12AffineFastState.Bounded env41593 := by
  intro p hp
  have h : env41593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41592_41593 : H12AffineEnvironment.transform 4 20 env41592 = env41593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env41592 == env41593) = true)

theorem identity41593 : scanCanonicalize (H12AffineFastState.compose env41593 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound41593 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41594 : List Nat := [2,4,8,9,13,8,8,8,512,0,1,8,5,0,0,14,9,1,1,1,1,13,9,2,5,8,1,8,8,0,12,12,9,12,1,513]

theorem envBound41594 : H12AffineFastState.Bounded env41594 := by
  intro p hp
  have h : env41594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41593_41594 : H12AffineEnvironment.transform 3 9 env41593 = env41594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env41593 == env41594) = true)

theorem identity41594 : scanCanonicalize (H12AffineFastState.compose env41594 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41595 : List Nat := [2,4,4,5,1,4,4,4,512,0,1,4,5,0,0,2,5,1,1,1,1,1,5,2,5,4,1,4,4,0,0,0,5,0,1,513]

theorem envBound41595 : H12AffineFastState.Bounded env41595 := by
  intro p hp
  have h : env41595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41594_41595 : H12AffineEnvironment.transform 2 4 env41594 = env41595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41594 == env41595) = true)

theorem identity41595 : scanCanonicalize (H12AffineFastState.compose env41595 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound41595 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41596 : List Nat := [2,4,4,5,1,4,4,4,7,0,1,4,5,0,0,2,5,1,1,1,1,1,5,2,5,4,1,4,4,0,0,0,5,0,1,6]

theorem envBound41596 : H12AffineFastState.Bounded env41596 := by
  intro p hp
  have h : env41596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41595_41596 : H12AffineEnvironment.transform 8 7 env41595 = env41596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env41595 == env41596) = true)

theorem identity41596 : scanCanonicalize (H12AffineFastState.compose env41596 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41596 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41597 : List Nat := [2,3,3,2,1,3,3,3,0,0,1,3,2,0,0,2,2,1,1,1,1,1,2,2,2,3,1,3,3,0,0,0,2,0,1,1]

theorem envBound41597 : H12AffineFastState.Bounded env41597 := by
  intro p hp
  have h : env41597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41596_41597 : H12AffineEnvironment.transform 1 3 env41596 = env41597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41596 == env41597) = true)

theorem identity41597 : scanCanonicalize (H12AffineFastState.compose env41597 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41597 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41598 : List Nat := [0,1,1,0,1,1,1,1,0,0,1,1,0,0,0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,0,0,0,0,0,1,1]

theorem envBound41598 : H12AffineFastState.Bounded env41598 := by
  intro p hp
  have h : env41598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41597_41598 : H12AffineEnvironment.transform 0 0 env41597 = env41598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41597 == env41598) = true)

def env41599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272392,17,95497,8192,64,2048,5392,45404,283905,61704,318548,257,21793,46092,120407]

theorem envBound41599 : H12AffineFastState.Bounded env41599 := by
  intro p hp
  have h : env41599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41581_41599 : H12AffineEnvironment.transform 16 38161 env41581 = env41599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env41581 == env41599) = true)

theorem identity41599 : scanCanonicalize (H12AffineFastState.compose env41599 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound41599 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35189,1025,32769,58396,41341,17,95497,8192,64,2048,5392,45404,56436,61704,21793,257,21793,46092,120407]

theorem envBound41600 : H12AffineFastState.Bounded env41600 := by
  intro p hp
  have h : env41600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41599_41600 : H12AffineEnvironment.transform 17 35189 env41599 = env41600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env41599 == env41600) = true)

theorem identity41600 : scanCanonicalize (H12AffineFastState.compose env41600 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound41600 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env41601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,65536,16693,23889,1025,21541,12344,30041,17,95497,8192,64,2048,5392,25976,2128,9516,21793,257,21793,24616,66163]

theorem envBound41601 : H12AffineFastState.Bounded env41601 := by
  intro p hp
  have h : env41601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41600_41601 : H12AffineEnvironment.transform 14 21540 env41600 = env41601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env41600 == env41601) = true)

theorem identity41601 : scanCanonicalize (H12AffineFastState.compose env41601 (packedSelected [2,3,5,6,7,9,10,11,12,15,18,19,20,22,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound41601 : packedSelected [2,3,5,6,7,9,10,11,12,15,18,19,20,22,26,27] rootPS < 2^1333 := by decide +kernel

def env41602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,30043,16693,23889,1025,21541,12344,30041,17,82,8192,64,2048,5392,25976,2128,9516,21793,257,21793,24616,30504]

theorem envBound41602 : H12AffineFastState.Bounded env41602 := by
  intro p hp
  have h : env41602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41601_41602 : H12AffineEnvironment.transform 15 30043 env41601 = env41602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env41601 == env41602) = true)

theorem identity41602 : scanCanonicalize (H12AffineFastState.compose env41602 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41602 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env41603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,293,8282,5172,2128,1025,292,12344,8280,17,82,8192,64,2048,5392,12409,2128,9516,32,257,32,13609,8745]

theorem envBound41603 : H12AffineFastState.Bounded env41603 := by
  intro p hp
  have h : env41603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41602_41603 : H12AffineEnvironment.transform 13 5377 env41602 = env41603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41602 == env41603) = true)

theorem identity41603 : scanCanonicalize (H12AffineFastState.compose env41603 (packedSelected [0,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound41603 : packedSelected [0,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env41604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7465,5377,293,7539,5172,2128,1025,292,3345,7537,17,82,7465,64,2048,5392,3408,2128,6149,32,257,32,2048,7936]

theorem envBound41604 : H12AffineFastState.Bounded env41604 := by
  intro p hp
  have h : env41604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41603_41604 : H12AffineEnvironment.transform 12 7465 env41603 = env41604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env41603 == env41604) = true)

theorem identity41604 : scanCanonicalize (H12AffineFastState.compose env41604 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41604 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env41605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,5416,5377,293,5490,5172,81,1025,292,1296,5488,17,82,5416,64,1,5392,1361,81,4100,32,257,32,1,5889]

theorem envBound41605 : H12AffineFastState.Bounded env41605 := by
  intro p hp
  have h : env41605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41604_41605 : H12AffineEnvironment.transform 10 1 env41604 = env41605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41604 == env41605) = true)

theorem identity41605 : scanCanonicalize (H12AffineFastState.compose env41605 (packedSelected [2,3,4,5,6,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound41605 : packedSelected [2,3,4,5,6,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env41606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1281,41,0,293,115,309,81,1025,292,1296,113,17,82,41,64,1,17,1361,81,1285,32,257,32,1,512]

theorem envBound41606 : H12AffineFastState.Bounded env41606 := by
  intro p hp
  have h : env41606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41605_41606 : H12AffineEnvironment.transform 11 1281 env41605 = env41606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env41605 == env41606) = true)

theorem identity41606 : scanCanonicalize (H12AffineFastState.compose env41606 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41606 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41607 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,1281,41,0,293,35,309,1,1025,292,1296,33,17,2,41,16,1,17,1281,1,1285,32,257,32,1,512]

theorem envBound41607 : H12AffineFastState.Bounded env41607 := by
  intro p hp
  have h : env41607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41606_41607 : H12AffineEnvironment.transform 5 16 env41606 = env41607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41606 == env41607) = true)

theorem identity41607 : scanCanonicalize (H12AffineFastState.compose env41607 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41607 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41608 : List Nat := [2,4,8,16,0,16,8,256,512,1024,1,1281,9,0,261,3,277,1,1025,260,1296,1,17,2,9,16,1,17,1281,1,1285,0,257,0,1,512]

theorem envBound41608 : H12AffineFastState.Bounded env41608 := by
  intro p hp
  have h : env41608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41607_41608 : H12AffineEnvironment.transform 4 0 env41607 = env41608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41607 == env41608) = true)

theorem identity41608 : scanCanonicalize (H12AffineFastState.compose env41608 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41608 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41609 : List Nat := [2,4,8,16,0,16,8,256,512,272,1,17,9,0,261,3,277,1,273,260,0,1,17,2,9,16,1,17,17,1,21,0,257,0,1,512]

theorem envBound41609 : H12AffineFastState.Bounded env41609 := by
  intro p hp
  have h : env41609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41608_41609 : H12AffineEnvironment.transform 9 272 env41608 = env41609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41608 == env41609) = true)

def env41610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169216,95497,8193,64,2049,163841,45405,283905,156697,411972,257,21793,46093,213831]

theorem envBound41610 : H12AffineFastState.Bounded env41610 := by
  intro p hp
  have h : env41610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41580_41610 : H12AffineEnvironment.transform 6 9 env41580 = env41610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41580 == env41610) = true)

def env41611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,16,95497,8193,64,2049,5393,45405,283905,61705,318548,257,21793,46093,120407]

theorem envBound41611 : H12AffineFastState.Bounded env41611 := by
  intro p hp
  have h : env41611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41610_41611 : H12AffineEnvironment.transform 16 38160 env41610 = env41611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env41610 == env41611) = true)

def env41612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,12572,272393,16,95497,8193,64,2049,5393,25693,283905,9225,264532,257,21793,24845,66391]

theorem envBound41612 : H12AffineFastState.Bounded env41612 := by
  intro p hp
  have h : env41612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41611_41612 : H12AffineEnvironment.transform 14 21760 env41611 = env41612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41611 == env41612) = true)

theorem identity41612 : scanCanonicalize (H12AffineFastState.compose env41612 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound41612 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env41613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,16400,262144,1025,21761,12572,272393,16,29791,8193,64,2049,5393,25693,283905,9225,264532,257,21793,24845,513]

theorem envBound41613 : H12AffineFastState.Bounded env41613 := by
  intro p hp
  have h : env41613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41612_41613 : H12AffineEnvironment.transform 15 342 env41612 = env41613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env41612 == env41613) = true)

theorem identity41613 : scanCanonicalize (H12AffineFastState.compose env41613 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound41613 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,16400,23668,1025,21761,12572,29821,16,29791,8193,64,2049,5393,25693,2421,9225,21792,257,21793,24845,513]

theorem envBound41614 : H12AffineFastState.Bounded env41614 := by
  intro p hp
  have h : env41614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41613_41614 : H12AffineEnvironment.transform 17 23668 env41613 = env41614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env41613 == env41614) = true)

theorem identity41614 : scanCanonicalize (H12AffineFastState.compose env41614 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41614 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,342,5393,2421,1025,0,12572,8572,16,8542,8193,64,2049,5393,12636,2421,9225,33,257,32,13324,513]

theorem envBound41615 : H12AffineFastState.Bounded env41615 := by
  intro p hp
  have h : env41615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41614_41615 : H12AffineEnvironment.transform 13 5377 env41614 = env41615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41614 == env41615) = true)

theorem identity41615 : scanCanonicalize (H12AffineFastState.compose env41615 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound41615 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env41616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2317,5377,1,342,5393,2421,1025,0,6161,2161,16,2131,2316,64,2049,5393,6225,2421,3332,33,257,32,7425,513]

theorem envBound41616 : H12AffineFastState.Bounded env41616 := by
  intro p hp
  have h : env41616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41615_41616 : H12AffineEnvironment.transform 12 2317 env41615 = env41616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env41615 == env41616) = true)

theorem identity41616 : scanCanonicalize (H12AffineFastState.compose env41616 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41616 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env41617 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2317,5377,1,262,5393,2341,1025,0,6161,2081,16,2051,2316,16,2049,5393,6145,2341,3332,33,257,32,7425,513]

theorem envBound41617 : H12AffineFastState.Bounded env41617 := by
  intro p hp
  have h : env41617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41616_41617 : H12AffineEnvironment.transform 5 16 env41616 = env41617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41616 == env41617) = true)

theorem identity41617 : scanCanonicalize (H12AffineFastState.compose env41617 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41617 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41618 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,4096,269,5377,1,262,5393,293,1025,0,4113,33,16,3,268,16,1,5393,4097,293,1284,33,257,32,5377,513]

theorem envBound41618 : H12AffineFastState.Bounded env41618 := by
  intro p hp
  have h : env41618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41617_41618 : H12AffineEnvironment.transform 10 0 env41617 = env41618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41617 == env41618) = true)

theorem identity41618 : scanCanonicalize (H12AffineFastState.compose env41618 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound41618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41619 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,1028,269,261,1,262,277,293,1025,0,1045,33,16,3,268,16,1,277,1029,293,1284,33,257,32,261,513]

theorem envBound41619 : H12AffineFastState.Bounded env41619 := by
  intro p hp
  have h : env41619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41618_41619 : H12AffineEnvironment.transform 11 1028 env41618 = env41619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env41618 == env41619) = true)

theorem identity41619 : scanCanonicalize (H12AffineFastState.compose env41619 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound41619 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41620 : List Nat := [2,4,8,16,32,16,9,256,42,1024,0,1028,269,261,1,262,277,293,1025,0,1045,33,16,3,268,16,1,277,1029,293,1284,33,257,32,261,43]

theorem envBound41620 : H12AffineFastState.Bounded env41620 := by
  intro p hp
  have h : env41620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41619_41620 : H12AffineEnvironment.transform 8 42 env41619 = env41620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env41619 == env41620) = true)

theorem identity41620 : scanCanonicalize (H12AffineFastState.compose env41620 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound41620 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41621 : List Nat := [2,4,8,16,32,16,9,256,42,314,0,318,269,261,1,262,277,293,315,0,303,33,16,3,268,16,1,277,319,293,62,33,257,32,261,43]

theorem envBound41621 : H12AffineFastState.Bounded env41621 := by
  intro p hp
  have h : env41621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41620_41621 : H12AffineEnvironment.transform 9 314 env41620 = env41621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env41620 == env41621) = true)

theorem identity41621 : scanCanonicalize (H12AffineFastState.compose env41621 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound41621 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41622 : List Nat := [2,4,8,16,32,16,9,62,42,4,0,0,51,59,1,56,43,27,5,0,17,33,16,3,50,16,1,43,1,27,62,33,63,32,59,43]

theorem envBound41622 : H12AffineFastState.Bounded env41622 := by
  intro p hp
  have h : env41622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41621_41622 : H12AffineEnvironment.transform 7 62 env41621 = env41622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env41621 == env41622) = true)

theorem identity41622 : scanCanonicalize (H12AffineFastState.compose env41622 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41622 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41623 : List Nat := [2,4,8,0,32,0,9,46,42,4,0,0,35,43,1,40,43,11,5,0,1,33,0,3,34,0,1,43,1,11,46,33,47,32,43,43]

theorem envBound41623 : H12AffineFastState.Bounded env41623 := by
  intro p hp
  have h : env41623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41622_41623 : H12AffineEnvironment.transform 3 0 env41622 = env41623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41622 == env41623) = true)

theorem identity41623 : scanCanonicalize (H12AffineFastState.compose env41623 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41624 : List Nat := [2,4,1,0,32,0,0,39,35,4,0,0,35,34,1,33,34,2,5,0,1,33,0,3,34,0,1,34,1,2,39,33,38,32,34,34]

theorem envBound41624 : H12AffineFastState.Bounded env41624 := by
  intro p hp
  have h : env41624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41623_41624 : H12AffineEnvironment.transform 2 1 env41623 = env41624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41623 == env41624) = true)

theorem identity41624 : scanCanonicalize (H12AffineFastState.compose env41624 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41624 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env41625 : List Nat := [2,4,1,0,0,0,0,7,3,4,0,0,3,2,1,1,2,2,5,0,1,1,0,3,2,0,1,2,1,2,7,1,6,0,2,2]

theorem envBound41625 : H12AffineFastState.Bounded env41625 := by
  intro p hp
  have h : env41625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41624_41625 : H12AffineEnvironment.transform 4 0 env41624 = env41625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41624 == env41625) = true)

theorem identity41625 : scanCanonicalize (H12AffineFastState.compose env41625 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41626 : List Nat := [2,2,1,0,0,0,0,1,3,2,0,0,3,2,1,1,2,2,3,0,1,1,0,3,2,0,1,2,1,2,1,1,0,0,2,2]

theorem envBound41626 : H12AffineFastState.Bounded env41626 := by
  intro p hp
  have h : env41626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41625_41626 : H12AffineEnvironment.transform 1 2 env41625 = env41626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41625 == env41626) = true)

def env41627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,12573,272393,16,95497,8193,64,2049,5393,25692,283905,9224,264533,257,21793,24844,66390]

theorem envBound41627 : H12AffineFastState.Bounded env41627 := by
  intro p hp
  have h : env41627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41611_41627 : H12AffineEnvironment.transform 14 21761 env41611 = env41627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env41611 == env41627) = true)

theorem identity41627 : scanCanonicalize (H12AffineFastState.compose env41627 (packedSelected [1,4,8,9,12,14,16,19,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound41627 : packedSelected [1,4,8,9,12,14,16,19,38] rootPS < 2^1333 := by decide +kernel

def env41628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,32041,1025,21760,12573,21792,16,95497,8193,64,2049,5393,25692,10280,9224,29820,257,21793,24844,66390]

theorem envBound41628 : H12AffineFastState.Bounded env41628 := by
  intro p hp
  have h : env41628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41627_41628 : H12AffineEnvironment.transform 17 32041 env41627 = env41628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env41627 == env41628) = true)

theorem identity41628 : scanCanonicalize (H12AffineFastState.compose env41628 (packedSelected [4,5,9,12,14,15,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound41628 : packedSelected [4,5,9,12,14,15,16,24,26] rootPS < 2^1333 := by decide +kernel

def env41629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8282,16401,32041,1025,21760,12573,21792,16,21843,8193,64,2049,5393,25692,10280,9224,29820,257,21793,24844,8972]

theorem envBound41629 : H12AffineFastState.Bounded env41629 := by
  intro p hp
  have h : env41629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41628_41629 : H12AffineEnvironment.transform 15 8282 env41628 = env41629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env41628 == env41629) = true)

theorem identity41629 : scanCanonicalize (H12AffineFastState.compose env41629 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41629 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env41630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,8282,13341,2341,1025,8460,12573,8492,16,8543,8193,64,2049,5393,4176,10280,9224,112,257,8493,5376,8972]

theorem envBound41630 : H12AffineFastState.Bounded env41630 := by
  intro p hp
  have h : env41630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41629_41630 : H12AffineEnvironment.transform 13 13324 env41629 = env41630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41629 == env41630) = true)

theorem identity41630 : scanCanonicalize (H12AffineFastState.compose env41630 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41630 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env41631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,342,5393,2341,1025,0,4113,32,16,83,269,64,2049,5393,4176,2340,1284,112,257,33,5376,512]

theorem envBound41631 : H12AffineFastState.Bounded env41631 := by
  intro p hp
  have h : env41631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41630_41631 : H12AffineEnvironment.transform 12 268 env41630 = env41631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41630 == env41631) = true)

theorem identity41631 : scanCanonicalize (H12AffineFastState.compose env41631 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41632 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5376,1,342,5393,2308,1025,0,4113,1,16,83,269,64,2049,5393,4176,2309,1284,81,257,0,5376,512]

theorem envBound41632 : H12AffineFastState.Bounded env41632 := by
  intro p hp
  have h : env41632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41631_41632 : H12AffineEnvironment.transform 4 1 env41631 = env41632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41631 == env41632) = true)

theorem identity41632 : scanCanonicalize (H12AffineFastState.compose env41632 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41632 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41633 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,4096,268,4112,1,342,4097,2308,273,0,4113,1,16,83,269,64,2049,4097,4176,2309,20,81,257,0,4112,512]

theorem envBound41633 : H12AffineFastState.Bounded env41633 := by
  intro p hp
  have h : env41633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41632_41633 : H12AffineEnvironment.transform 9 272 env41632 = env41633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41632 == env41633) = true)

theorem identity41633 : scanCanonicalize (H12AffineFastState.compose env41633 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound41633 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41634 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,2113,268,2129,1,342,2112,2308,273,0,2128,1,16,83,269,64,2049,2112,2065,2309,20,81,257,0,2129,512]

theorem envBound41634 : H12AffineFastState.Bounded env41634 := by
  intro p hp
  have h : env41634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41633_41634 : H12AffineEnvironment.transform 11 2113 env41633 = env41634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env41633 == env41634) = true)

theorem identity41634 : scanCanonicalize (H12AffineFastState.compose env41634 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41634 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env41635 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2065,268,2049,1,262,2064,2308,273,0,2048,1,16,3,269,16,2049,2064,2065,2309,20,1,257,0,2049,512]

theorem envBound41635 : H12AffineFastState.Bounded env41635 := by
  intro p hp
  have h : env41635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41634_41635 : H12AffineEnvironment.transform 5 16 env41634 = env41635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41634 == env41635) = true)

theorem identity41635 : scanCanonicalize (H12AffineFastState.compose env41635 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41636 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,2065,8,2049,1,2,2064,2048,21,0,2048,1,16,3,9,16,2049,2064,2065,2049,20,1,5,0,2049,512]

theorem envBound41636 : H12AffineFastState.Bounded env41636 := by
  intro p hp
  have h : env41636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41635_41636 : H12AffineEnvironment.transform 7 4 env41635 = env41636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41635 == env41636) = true)

def env41637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95497,8193,64,2049,5392,45405,283905,61704,318549,257,21793,46093,120406]

theorem envBound41637 : H12AffineFastState.Bounded env41637 := by
  intro p hp
  have h : env41637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41610_41637 : H12AffineEnvironment.transform 16 38161 env41610 = env41637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env41610 == env41637) = true)

theorem identity41637 : scanCanonicalize (H12AffineFastState.compose env41637 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41637 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58397,33,17,95497,8193,64,2049,5392,45405,32041,61704,62589,257,21793,46093,120406]

theorem envBound41638 : H12AffineFastState.Bounded env41638 := by
  intro p hp
  have h : env41638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41637_41638 : H12AffineEnvironment.transform 17 10280 env41637 = env41638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41637 == env41638) = true)

theorem identity41638 : scanCanonicalize (H12AffineFastState.compose env41638 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41638 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,38161,2421,1025,32769,50496,33,17,87124,348,64,2049,5392,36864,23668,53333,54560,257,21793,38224,120406]

theorem envBound41639 : H12AffineFastState.Bounded env41639 := by
  intro p hp
  have h : env41639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41638_41639 : H12AffineEnvironment.transform 12 349 env41638 = env41639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41638 == env41639) = true)

theorem identity41639 : scanCanonicalize (H12AffineFastState.compose env41639 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41639 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env41640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,65536,38161,2421,1025,32769,36929,33,17,65877,348,64,2049,5392,36864,2421,34132,32801,257,32,38224,99159]

theorem envBound41640 : H12AffineFastState.Bounded env41640 := by
  intro p hp
  have h : env41640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41639_41640 : H12AffineEnvironment.transform 13 5377 env41639 = env41640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41639 == env41640) = true)

theorem identity41640 : scanCanonicalize (H12AffineFastState.compose env41640 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound41640 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,80,65536,5441,2421,1025,81,4113,33,17,65877,348,64,2049,5392,4176,2421,1284,113,257,32,5376,66311]

theorem envBound41641 : H12AffineFastState.Bounded env41641 := by
  intro p hp
  have h : env41641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41640_41641 : H12AffineEnvironment.transform 14 80 env41640 = env41641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env41640 == env41641) = true)

theorem identity41641 : scanCanonicalize (H12AffineFastState.compose env41641 (packedSelected [1,8,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound41641 : packedSelected [1,8,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1328,4096,349,5377,80,65536,5441,1093,1025,81,4113,33,17,65877,348,64,1329,5392,4176,1093,1284,113,257,32,5376,66311]

theorem envBound41642 : H12AffineFastState.Bounded env41642 := by
  intro p hp
  have h : env41642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41641_41642 : H12AffineEnvironment.transform 10 1328 env41641 = env41642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env41641 == env41642) = true)

def env41643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169216,95497,8328,64,2185,163841,45524,283905,156697,412108,257,21793,46212,213966]

theorem envBound41643 : H12AffineFastState.Bounded env41643 := by
  intro p hp
  have h : env41643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41579_41643 : H12AffineEnvironment.transform 21 272513 env41579 = env41643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41579 == env41643) = true)

theorem identity41643 : scanCanonicalize (H12AffineFastState.compose env41643 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound41643 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58516,272513,17,95497,8328,64,2185,5392,45524,283905,61704,318685,257,21793,46212,120543]

theorem envBound41644 : H12AffineFastState.Bounded env41644 := by
  intro p hp
  have h : env41644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41643_41644 : H12AffineEnvironment.transform 16 38161 env41643 = env41644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env41643 == env41644) = true)

def env41645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272393,17,95497,8192,64,2049,5392,45404,283905,61704,318549,257,21793,46092,120407]

theorem envBound41645 : H12AffineFastState.Bounded env41645 := by
  intro p hp
  have h : env41645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41644_41645 : H12AffineEnvironment.transform 6 8 env41644 = env41645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41644 == env41645) = true)

theorem identity41645 : scanCanonicalize (H12AffineFastState.compose env41645 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound41645 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35189,1025,32769,58396,41340,17,95497,8192,64,2049,5392,45404,56436,61704,21792,257,21793,46092,120407]

theorem envBound41646 : H12AffineFastState.Bounded env41646 := by
  intro p hp
  have h : env41646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41645_41646 : H12AffineEnvironment.transform 17 35189 env41645 = env41646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env41645 == env41646) = true)

theorem identity41646 : scanCanonicalize (H12AffineFastState.compose env41646 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound41646 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env41647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,32768,65536,38161,35189,1025,32769,45113,41340,17,74028,8192,64,2049,5392,45404,34897,42285,261,257,260,46092,98930]

theorem envBound41647 : H12AffineFastState.Bounded env41647 := by
  intro p hp
  have h : env41647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41646_41647 : H12AffineEnvironment.transform 13 5157 env41646 = env41647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env41646 == env41647) = true)

theorem identity41647 : scanCanonicalize (H12AffineFastState.compose env41647 (packedSelected [2,3,4,6,10,11,16,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound41647 : packedSelected [2,3,4,6,10,11,16,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env41648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,80,65536,5441,2341,1025,81,12393,8492,17,74028,8192,64,2049,5392,12556,2049,9597,261,257,260,13404,66082]

theorem envBound41648 : H12AffineFastState.Bounded env41648 := by
  intro p hp
  have h : env41648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41647_41648 : H12AffineEnvironment.transform 14 80 env41647 = env41648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env41647 == env41648) = true)

theorem identity41648 : scanCanonicalize (H12AffineFastState.compose env41648 (packedSelected [2,6,9,11,14,16,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound41648 : packedSelected [2,6,9,11,14,16,20,22,23] rootPS < 2^1333 := by decide +kernel

def env41649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,80,343,5441,2341,1025,81,12393,8492,17,8315,8192,64,2049,5392,12556,2049,9597,261,257,260,13404,885]

theorem envBound41649 : H12AffineFastState.Bounded env41649 := by
  intro p hp
  have h : env41649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41648_41649 : H12AffineEnvironment.transform 15 343 env41648 = env41649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env41648 == env41649) = true)

theorem identity41649 : scanCanonicalize (H12AffineFastState.compose env41649 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound41649 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,5157,80,343,5441,2341,1025,81,5377,1092,17,1299,1384,64,2049,5392,5220,2049,21,261,257,260,4404,885]

theorem envBound41650 : H12AffineFastState.Bounded env41650 := by
  intro p hp
  have h : env41650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41649_41650 : H12AffineEnvironment.transform 12 1384 env41649 = env41650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env41649 == env41650) = true)

theorem identity41650 : scanCanonicalize (H12AffineFastState.compose env41650 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41650 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env41651 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5157,80,115,5221,2049,1025,81,5157,1092,17,1079,1100,64,2049,5172,5220,2049,21,33,37,32,4112,593]

theorem envBound41651 : H12AffineFastState.Bounded env41651 := by
  intro p hp
  have h : env41651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41650_41651 : H12AffineEnvironment.transform 7 36 env41650 = env41651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41650 == env41651) = true)

theorem identity41651 : scanCanonicalize (H12AffineFastState.compose env41651 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41651 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env41652 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,120,4113,80,115,4177,2049,53,81,4113,112,17,3,120,64,2049,4096,4176,2049,21,33,37,32,4112,593]

theorem envBound41652 : H12AffineFastState.Bounded env41652 := by
  intro p hp
  have h : env41652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41651_41652 : H12AffineEnvironment.transform 9 52 env41651 = env41652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41651 == env41652) = true)

theorem identity41652 : scanCanonicalize (H12AffineFastState.compose env41652 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound41652 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41653 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,2059,120,2074,80,115,2138,2049,53,81,2074,112,17,3,120,64,2049,2059,2139,2049,21,33,37,32,2075,593]

theorem envBound41653 : H12AffineFastState.Bounded env41653 := by
  intro p hp
  have h : env41653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41652_41653 : H12AffineEnvironment.transform 11 2059 env41652 = env41653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env41652 == env41653) = true)

theorem identity41653 : scanCanonicalize (H12AffineFastState.compose env41653 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound41653 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41654 : List Nat := [2,4,8,16,32,0,8,36,512,52,2048,2059,56,2074,16,51,2074,2049,53,17,2074,48,17,3,56,0,2049,2059,2075,2049,21,33,37,32,2075,529]

theorem envBound41654 : H12AffineFastState.Bounded env41654 := by
  intro p hp
  have h : env41654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41653_41654 : H12AffineEnvironment.transform 5 0 env41653 = env41654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41653 == env41654) = true)

theorem identity41654 : scanCanonicalize (H12AffineFastState.compose env41654 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound41654 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41655 : List Nat := [2,4,8,16,32,0,8,36,512,52,15,4,56,21,16,51,21,14,53,17,21,48,17,3,56,0,14,4,20,14,21,33,37,32,20,529]

theorem envBound41655 : H12AffineFastState.Bounded env41655 := by
  intro p hp
  have h : env41655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41654_41655 : H12AffineEnvironment.transform 10 15 env41654 = env41655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env41654 == env41655) = true)

theorem identity41655 : scanCanonicalize (H12AffineFastState.compose env41655 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound41655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41656 : List Nat := [2,4,8,16,32,0,8,36,60,52,15,4,56,21,16,51,21,14,53,17,21,48,17,3,56,0,14,4,20,14,21,33,37,32,20,45]

theorem envBound41656 : H12AffineFastState.Bounded env41656 := by
  intro p hp
  have h : env41656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41655_41656 : H12AffineEnvironment.transform 8 60 env41655 = env41656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env41655 == env41656) = true)

theorem identity41656 : scanCanonicalize (H12AffineFastState.compose env41656 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41656 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41657 : List Nat := [2,4,3,16,32,0,3,36,55,52,4,4,51,21,16,51,21,5,53,17,21,48,17,3,51,0,5,4,20,5,21,33,37,32,20,38]

theorem envBound41657 : H12AffineFastState.Bounded env41657 := by
  intro p hp
  have h : env41657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41656_41657 : H12AffineEnvironment.transform 2 3 env41656 = env41657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41656 == env41657) = true)

theorem identity41657 : scanCanonicalize (H12AffineFastState.compose env41657 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41657 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env41658 : List Nat := [2,4,3,1,32,0,3,36,38,37,4,4,34,4,1,34,4,5,36,0,4,33,0,3,34,0,5,4,5,5,4,33,37,32,5,38]

theorem envBound41658 : H12AffineFastState.Bounded env41658 := by
  intro p hp
  have h : env41658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41657_41658 : H12AffineEnvironment.transform 3 1 env41657 = env41658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41657 == env41658) = true)

theorem identity41658 : scanCanonicalize (H12AffineFastState.compose env41658 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41659 : List Nat := [2,4,3,1,1,0,3,5,7,4,4,4,3,4,1,3,4,5,5,0,4,0,0,3,3,0,5,4,5,5,4,0,4,1,5,7]

theorem envBound41659 : H12AffineFastState.Bounded env41659 := by
  intro p hp
  have h : env41659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41658_41659 : H12AffineEnvironment.transform 4 1 env41658 = env41659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41658 == env41659) = true)

theorem identity41659 : scanCanonicalize (H12AffineFastState.compose env41659 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41659 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41660 : List Nat := [2,0,3,1,1,0,3,1,3,0,0,0,3,0,1,3,0,1,1,0,0,0,0,3,3,0,1,0,1,1,0,0,0,1,1,3]

theorem envBound41660 : H12AffineFastState.Bounded env41660 := by
  intro p hp
  have h : env41660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41659_41660 : H12AffineEnvironment.transform 1 0 env41659 = env41660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41659 == env41660) = true)

def env41661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95497,8193,64,2048,5392,45405,283905,61704,318548,257,21793,46093,120406]

theorem envBound41661 : H12AffineFastState.Bounded env41661 := by
  intro p hp
  have h : env41661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41644_41661 : H12AffineEnvironment.transform 6 9 env41644 = env41661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41644 == env41661) = true)

theorem identity41661 : scanCanonicalize (H12AffineFastState.compose env41661 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58397,32,17,95497,8193,64,2048,5392,45405,32041,61704,62588,257,21793,46093,120406]

theorem envBound41662 : H12AffineFastState.Bounded env41662 := by
  intro p hp
  have h : env41662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41661_41662 : H12AffineEnvironment.transform 17 10280 env41661 = env41662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41661 == env41662) = true)

theorem identity41662 : scanCanonicalize (H12AffineFastState.compose env41662 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound41662 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,38161,10280,1025,32769,58397,32,17,8543,8193,64,2048,5392,45405,32041,61704,62588,257,21793,46093,33280]

theorem envBound41663 : H12AffineFastState.Bounded env41663 := by
  intro p hp
  have h : env41663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41662_41663 : H12AffineEnvironment.transform 15 21590 env41662 = env41663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env41662 == env41663) = true)

theorem identity41663 : scanCanonicalize (H12AffineFastState.compose env41663 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41663 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env41664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,342,38161,10280,1025,32769,45341,32,17,8543,8193,64,2048,5392,45405,10281,41992,41340,257,33,46093,33280]

theorem envBound41664 : H12AffineFastState.Bounded env41664 := by
  intro p hp
  have h : env41664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41663_41664 : H12AffineEnvironment.transform 13 5376 env41663 = env41664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41663 == env41664) = true)

theorem identity41664 : scanCanonicalize (H12AffineFastState.compose env41664 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41664 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,32768,342,38161,2341,1025,32769,36880,32,17,82,268,64,2048,5392,36944,2340,34053,32881,257,33,38144,33280]

theorem envBound41665 : H12AffineFastState.Bounded env41665 := by
  intro p hp
  have h : env41665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41664_41665 : H12AffineEnvironment.transform 12 269 env41664 = env41665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41664 == env41665) = true)

theorem identity41665 : scanCanonicalize (H12AffineFastState.compose env41665 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound41665 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,342,5441,2341,1025,81,4160,32,17,82,268,64,2048,5392,4096,2340,1365,33,257,33,5456,592]

theorem envBound41666 : H12AffineFastState.Bounded env41666 := by
  intro p hp
  have h : env41666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41665_41666 : H12AffineEnvironment.transform 14 80 env41665 = env41666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env41665 == env41666) = true)

theorem identity41666 : scanCanonicalize (H12AffineFastState.compose env41666 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound41666 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2341,269,3109,80,342,3172,2341,1025,81,2405,32,17,82,268,64,2048,3125,2341,2340,1365,33,257,33,3189,592]

theorem envBound41667 : H12AffineFastState.Bounded env41667 := by
  intro p hp
  have h : env41667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41666_41667 : H12AffineEnvironment.transform 11 2341 env41666 = env41667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env41666 == env41667) = true)

theorem identity41667 : scanCanonicalize (H12AffineFastState.compose env41667 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41667 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41668 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,2080,8,3109,80,83,3172,2080,1025,81,2144,32,17,82,9,64,2048,3125,2080,2081,1104,33,4,33,3189,592]

theorem envBound41668 : H12AffineFastState.Bounded env41668 := by
  intro p hp
  have h : env41668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41667_41668 : H12AffineEnvironment.transform 7 5 env41667 = env41668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41667 == env41668) = true)

theorem identity41668 : scanCanonicalize (H12AffineFastState.compose env41668 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound41668 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41669 : List Nat := [2,4,8,16,32,64,9,5,512,1024,1044,1076,8,49,80,83,112,1076,1025,81,1140,32,17,82,9,64,1044,33,1076,1077,1104,33,4,33,97,592]

theorem envBound41669 : H12AffineFastState.Bounded env41669 := by
  intro p hp
  have h : env41669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41668_41669 : H12AffineEnvironment.transform 10 1044 env41668 = env41669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env41668 == env41669) = true)

theorem identity41669 : scanCanonicalize (H12AffineFastState.compose env41669 (packedSelected [1,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound41669 : packedSelected [1,6,8,11] rootPS < 2^1333 := by decide +kernel

def env41670 : List Nat := [2,4,8,16,32,64,9,5,512,85,65,97,8,49,80,83,112,97,84,81,33,32,17,82,9,64,65,33,97,96,5,33,4,33,97,592]

theorem envBound41670 : H12AffineFastState.Bounded env41670 := by
  intro p hp
  have h : env41670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41669_41670 : H12AffineEnvironment.transform 9 85 env41669 = env41670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env41669 == env41670) = true)

theorem identity41670 : scanCanonicalize (H12AffineFastState.compose env41670 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41671 : List Nat := [2,4,8,0,32,64,9,5,512,69,65,97,8,33,64,67,96,97,68,65,33,32,1,66,9,64,65,33,97,96,5,33,4,33,97,576]

theorem envBound41671 : H12AffineFastState.Bounded env41671 := by
  intro p hp
  have h : env41671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41670_41671 : H12AffineEnvironment.transform 3 0 env41670 = env41671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41670 == env41671) = true)

def env41672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169217,95496,8328,64,4464648,163840,45525,283904,156697,4350284,257,21793,46212,213966]

theorem envBound41672 : H12AffineFastState.Bounded env41672 := by
  intro p hp
  have h : env41672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41578_41672 : H12AffineEnvironment.transform 22 169217 env41578 = env41672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env41578 == env41672) = true)

def env41673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169217,95496,8328,64,2184,163840,45525,283904,156697,412108,257,21793,46212,213966]

theorem envBound41673 : H12AffineFastState.Bounded env41673 := by
  intro p hp
  have h : env41673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41672_41673 : H12AffineEnvironment.transform 21 272512 env41672 = env41673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41672 == env41673) = true)

theorem identity41673 : scanCanonicalize (H12AffineFastState.compose env41673 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound41673 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160133,272512,156117,95496,8328,64,2184,160980,17665,283904,156697,412108,257,21793,16464,213966]

theorem envBound41674 : H12AffineFastState.Bounded env41674 := by
  intro p hp
  have h : env41674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41673_41674 : H12AffineEnvironment.transform 14 29908 env41673 = env41674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env41673 == env41674) = true)

def env41675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272392,155997,95496,8192,64,2048,160860,17665,283904,156697,411972,257,21793,16464,213830]

theorem envBound41675 : H12AffineFastState.Bounded env41675 := by
  intro p hp
  have h : env41675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41674_41675 : H12AffineEnvironment.transform 6 8 env41674 = env41675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41674 == env41675) = true)

theorem identity41675 : scanCanonicalize (H12AffineFastState.compose env41675 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 204082) := by decide +kernel

theorem selectedBound41675 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env41676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,204082,1025,29789,160013,210234,155997,95496,8192,64,2048,160860,17665,215090,156697,87158,257,21793,16464,213830]

theorem envBound41676 : H12AffineFastState.Bounded env41676 := by
  intro p hp
  have h : env41676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41675_41676 : H12AffineEnvironment.transform 17 204082 env41675 = env41676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204082 env41675 == env41676) = true)

theorem identity41676 : scanCanonicalize (H12AffineFastState.compose env41676 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound41676 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env41677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,32040,1025,29789,69911,21792,65863,95496,8192,64,2048,70726,17665,10280,66563,87158,257,21793,16464,9052]

theorem envBound41677 : H12AffineFastState.Bounded env41677 := by
  intro p hp
  have h : env41677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41676_41677 : H12AffineEnvironment.transform 16 90138 env41676 = env41677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env41676 == env41677) = true)

theorem identity41677 : scanCanonicalize (H12AffineFastState.compose env41677 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41677 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,82247,23669,1025,21760,69911,21792,65863,87125,349,64,2048,70726,17665,2421,66563,87158,257,21793,16464,513]

theorem envBound41678 : H12AffineFastState.Bounded env41678 := by
  intro p hp
  have h : env41678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41677_41678 : H12AffineEnvironment.transform 12 349 env41677 = env41678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41677 == env41678) = true)

theorem identity41678 : scanCanonicalize (H12AffineFastState.compose env41678 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41678 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,65536,70726,2420,1025,1,69911,33,65863,65876,349,64,2048,70726,4096,2421,66563,65911,257,32,5457,513]

theorem envBound41679 : H12AffineFastState.Bounded env41679 := by
  intro p hp
  have h : env41679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41678_41679 : H12AffineEnvironment.transform 13 5377 env41678 = env41679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41678 == env41679) = true)

theorem identity41679 : scanCanonicalize (H12AffineFastState.compose env41679 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41679 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41680 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,0,65536,69974,2420,273,1,69911,33,65863,65876,349,64,2048,69974,4096,2421,65811,65911,257,32,4161,513]

theorem envBound41680 : H12AffineFastState.Bounded env41680 := by
  intro p hp
  have h : env41680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41679_41680 : H12AffineEnvironment.transform 9 272 env41679 = env41680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41679 == env41680) = true)

theorem identity41680 : scanCanonicalize (H12AffineFastState.compose env41680 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 4147) := by decide +kernel

theorem selectedBound41680 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env41681 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,0,4147,357,2420,273,1,292,33,4468,4455,349,64,2048,357,4096,2421,4384,4420,257,32,4161,513]

theorem envBound41681 : H12AffineFastState.Bounded env41681 := by
  intro p hp
  have h : env41681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41680_41681 : H12AffineEnvironment.transform 15 4147 env41680 = env41681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4147 env41680 == env41681) = true)

theorem identity41681 : scanCanonicalize (H12AffineFastState.compose env41681 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound41681 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41682 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,309,349,292,0,262,357,2420,273,1,292,33,65,82,349,64,2048,357,309,2421,21,113,257,32,372,513]

theorem envBound41682 : H12AffineFastState.Bounded env41682 := by
  intro p hp
  have h : env41682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41681_41682 : H12AffineEnvironment.transform 11 309 env41681 = env41682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env41681 == env41682) = true)

theorem identity41682 : scanCanonicalize (H12AffineFastState.compose env41682 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound41682 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41683 : List Nat := [2,4,8,16,32,64,8,256,512,272,292,309,349,292,0,262,357,80,273,1,292,33,65,82,349,64,292,357,309,81,21,113,257,32,372,513]

theorem envBound41683 : H12AffineFastState.Bounded env41683 := by
  intro p hp
  have h : env41683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41682_41683 : H12AffineEnvironment.transform 10 292 env41682 = env41683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env41682 == env41683) = true)

def env41684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160012,272393,155996,95496,8193,64,2049,160861,17665,283904,156697,411973,257,21793,16464,213831]

theorem envBound41684 : H12AffineFastState.Bounded env41684 := by
  intro p hp
  have h : env41684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41674_41684 : H12AffineEnvironment.transform 6 9 env41674 = env41684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41674 == env41684) = true)

theorem identity41684 : scanCanonicalize (H12AffineFastState.compose env41684 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound41684 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env41685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149861,1025,29788,160012,156012,155996,95496,8193,64,2049,160861,17665,138341,156697,32,257,21793,16464,213831]

theorem envBound41685 : H12AffineFastState.Bounded env41685 := by
  intro p hp
  have h : env41685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41684_41685 : H12AffineEnvironment.transform 17 149861 env41684 = env41685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env41684 == env41685) = true)

theorem identity41685 : scanCanonicalize (H12AffineFastState.compose env41685 (packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound41685 : packedSelected [0,1,3,5,7,9,12,14,15,16,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env41686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,131072,149861,1025,29788,160012,156012,155996,8542,8193,64,2049,160861,17665,138341,156697,32,257,21793,16464,136977]

theorem envBound41686 : H12AffineFastState.Bounded env41686 := by
  intro p hp
  have h : env41686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41685_41686 : H12AffineEnvironment.transform 15 21590 env41685 = env41686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env41685 == env41686) = true)

theorem identity41686 : scanCanonicalize (H12AffineFastState.compose env41686 (packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound41686 : packedSelected [0,3,9,18,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env41687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,16449,2340,1025,29788,12621,8493,8477,8542,8193,64,2049,13340,17665,23588,9304,32,257,21793,16464,22352]

theorem envBound41687 : H12AffineFastState.Bounded env41687 := by
  intro p hp
  have h : env41687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41686_41687 : H12AffineEnvironment.transform 16 16449 env41686 = env41687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env41686 == env41687) = true)

theorem identity41687 : scanCanonicalize (H12AffineFastState.compose env41687 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41687 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env41688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,21590,16449,2340,1025,21841,4160,32,16,83,268,64,2049,5393,17665,23588,1365,32,257,21793,16464,22352]

theorem envBound41688 : H12AffineFastState.Bounded env41688 := by
  intro p hp
  have h : env41688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41687_41688 : H12AffineEnvironment.transform 12 269 env41687 = env41688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41687 == env41688) = true)

theorem identity41688 : scanCanonicalize (H12AffineFastState.compose env41688 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound41688 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4161,1297,1047,4096,2340,1025,1296,4160,32,16,83,268,64,2049,5393,5440,3173,1365,32,257,1376,4113,1809]

theorem envBound41689 : H12AffineFastState.Bounded env41689 := by
  intro p hp
  have h : env41689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41688_41689 : H12AffineEnvironment.transform 13 4161 env41688 = env41689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env41688 == env41689) = true)

theorem identity41689 : scanCanonicalize (H12AffineFastState.compose env41689 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound41689 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41690 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,269,4161,81,343,4096,2340,321,80,4160,32,16,83,268,64,2049,4177,4096,2341,21,32,257,32,4113,593]

theorem envBound41690 : H12AffineFastState.Bounded env41690 := by
  intro p hp
  have h : env41690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41689_41690 : H12AffineEnvironment.transform 9 320 env41689 = env41690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41689 == env41690) = true)

theorem identity41690 : scanCanonicalize (H12AffineFastState.compose env41690 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41690 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41691 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,269,65,81,343,0,2340,321,80,64,32,16,83,268,64,2049,81,0,2341,21,32,257,32,17,593]

theorem envBound41691 : H12AffineFastState.Bounded env41691 := by
  intro p hp
  have h : env41691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41690_41691 : H12AffineEnvironment.transform 11 0 env41690 = env41691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41690 == env41691) = true)

theorem identity41691 : scanCanonicalize (H12AffineFastState.compose env41691 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41691 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41692 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,269,16,0,262,0,2340,272,1,17,32,16,2,268,17,2049,0,0,2341,21,32,257,32,17,512]

theorem envBound41692 : H12AffineFastState.Bounded env41692 := by
  intro p hp
  have h : env41692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41691_41692 : H12AffineEnvironment.transform 5 17 env41691 = env41692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41691 == env41692) = true)

theorem identity41692 : scanCanonicalize (H12AffineFastState.compose env41692 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41692 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41693 : List Nat := [2,4,8,1,32,0,9,256,512,256,2048,0,269,1,0,262,0,2340,257,1,0,32,1,2,268,0,2049,0,0,2341,4,32,257,32,0,512]

theorem envBound41693 : H12AffineFastState.Bounded env41693 := by
  intro p hp
  have h : env41693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41692_41693 : H12AffineEnvironment.transform 3 1 env41692 = env41693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41692 == env41693) = true)

theorem identity41693 : scanCanonicalize (H12AffineFastState.compose env41693 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 299) := by decide +kernel

theorem selectedBound41693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41694 : List Nat := [2,4,8,1,32,0,9,256,512,256,299,0,269,1,0,262,0,15,257,1,0,32,1,2,268,0,298,0,0,14,4,32,257,32,0,512]

theorem envBound41694 : H12AffineFastState.Bounded env41694 := by
  intro p hp
  have h : env41694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41693_41694 : H12AffineEnvironment.transform 10 299 env41693 = env41694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 299 env41693 == env41694) = true)

theorem identity41694 : scanCanonicalize (H12AffineFastState.compose env41694 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound41694 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41695 : List Nat := [2,4,8,1,32,0,9,256,260,256,299,0,269,1,0,262,0,15,257,1,0,32,1,2,268,0,298,0,0,14,4,32,257,32,0,260]

theorem envBound41695 : H12AffineFastState.Bounded env41695 := by
  intro p hp
  have h : env41695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41694_41695 : H12AffineEnvironment.transform 8 260 env41694 = env41695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env41694 == env41695) = true)

theorem identity41695 : scanCanonicalize (H12AffineFastState.compose env41695 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41695 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41696 : List Nat := [2,4,8,1,32,0,9,36,32,36,15,0,41,1,0,34,0,15,37,1,0,32,1,2,40,0,14,0,0,14,4,32,37,32,0,32]

theorem envBound41696 : H12AffineFastState.Bounded env41696 := by
  intro p hp
  have h : env41696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41695_41696 : H12AffineEnvironment.transform 7 36 env41695 = env41696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41695 == env41696) = true)

theorem identity41696 : scanCanonicalize (H12AffineFastState.compose env41696 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41697 : List Nat := [2,4,8,1,1,0,9,5,1,5,15,0,8,1,0,3,0,15,4,1,0,1,1,2,9,0,14,0,0,14,4,1,4,1,0,1]

theorem envBound41697 : H12AffineFastState.Bounded env41697 := by
  intro p hp
  have h : env41697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41696_41697 : H12AffineEnvironment.transform 4 1 env41696 = env41697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41696 == env41697) = true)

theorem identity41697 : scanCanonicalize (H12AffineFastState.compose env41697 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound41697 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env41698 : List Nat := [2,4,7,1,1,0,6,5,1,5,0,0,7,1,0,3,0,0,4,1,0,1,1,2,6,0,1,0,0,1,4,1,4,1,0,1]

theorem envBound41698 : H12AffineFastState.Bounded env41698 := by
  intro p hp
  have h : env41698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41697_41698 : H12AffineEnvironment.transform 2 7 env41697 = env41698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env41697 == env41698) = true)

def env41699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169217,95496,8328,64,2185,163840,45525,283904,156697,412109,257,21793,46212,213966]

theorem envBound41699 : H12AffineFastState.Bounded env41699 := by
  intro p hp
  have h : env41699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41672_41699 : H12AffineEnvironment.transform 21 272513 env41672 = env41699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41672 == env41699) = true)

theorem identity41699 : scanCanonicalize (H12AffineFastState.compose env41699 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound41699 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,272513,62661,95496,8328,64,2185,57796,45525,283904,1501,272393,257,21793,46212,74250]

theorem envBound41700 : H12AffineFastState.Bounded env41700 := by
  intro p hp
  have h : env41700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41699_41700 : H12AffineEnvironment.transform 16 25028 env41699 = env41700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env41699 == env41700) = true)

theorem identity41700 : scanCanonicalize (H12AffineFastState.compose env41700 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41700 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,4161,272513,62661,21763,8328,64,2185,57796,45525,283904,1501,272393,257,21793,46212,513]

theorem envBound41701 : H12AffineFastState.Bounded env41701 := by
  intro p hp
  have h : env41701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41700_41701 : H12AffineEnvironment.transform 15 8203 env41700 = env41701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41700 == env41701) = true)

theorem identity41701 : scanCanonicalize (H12AffineFastState.compose env41701 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41701 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env41702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,5529,262144,1025,32769,4161,272513,32920,8542,8328,64,2185,38297,45525,270685,1501,272393,257,8572,46212,513]

theorem envBound41702 : H12AffineFastState.Bounded env41702 := by
  intro p hp
  have h : env41702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41701_41702 : H12AffineEnvironment.transform 13 13405 env41701 = env41702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41701 == env41702) = true)

theorem identity41702 : scanCanonicalize (H12AffineFastState.compose env41702 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound41702 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env41703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,5529,35324,1025,32769,4161,41341,32920,8542,8328,64,2185,38297,45525,43169,1501,41461,257,8572,46212,513]

theorem envBound41703 : H12AffineFastState.Bounded env41703 := by
  intro p hp
  have h : env41703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41702_41703 : H12AffineEnvironment.transform 17 35324 env41702 = env41703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env41702 == env41703) = true)

theorem identity41703 : scanCanonicalize (H12AffineFastState.compose env41703 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41703 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env41704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,5529,10401,1025,8540,4161,32,8645,8542,8328,64,2185,13508,4232,2556,1501,168,257,8572,5593,513]

theorem envBound41704 : H12AffineFastState.Bounded env41704 := by
  intro p hp
  have h : env41704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41703_41704 : H12AffineEnvironment.transform 14 8541 env41703 = env41704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41703 == env41704) = true)

theorem identity41704 : scanCanonicalize (H12AffineFastState.compose env41704 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound41704 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,478,5529,2420,1025,137,4161,32,16,139,349,64,2185,5393,4232,2556,1501,168,257,169,5593,513]

theorem envBound41705 : H12AffineFastState.Bounded env41705 := by
  intro p hp
  have h : env41705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41704_41705 : H12AffineEnvironment.transform 12 469 env41704 = env41705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env41704 == env41705) = true)

theorem identity41705 : scanCanonicalize (H12AffineFastState.compose env41705 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound41705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41706 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,81,263,5440,2420,1025,80,4161,32,16,82,349,64,2128,5393,4177,2341,1284,113,257,112,5376,513]

theorem envBound41706 : H12AffineFastState.Bounded env41706 := by
  intro p hp
  have h : env41706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41705_41706 : H12AffineEnvironment.transform 6 89 env41705 = env41706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env41705 == env41706) = true)

theorem identity41706 : scanCanonicalize (H12AffineFastState.compose env41706 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3124) := by decide +kernel

theorem selectedBound41706 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41707 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3124,268,2405,81,263,2420,2420,1025,80,3189,32,16,82,349,64,2128,2341,3173,2341,1284,113,257,112,2356,513]

theorem envBound41707 : H12AffineFastState.Bounded env41707 := by
  intro p hp
  have h : env41707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41706_41707 : H12AffineEnvironment.transform 11 3124 env41706 = env41707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3124 env41706 == env41707) = true)

theorem identity41707 : scanCanonicalize (H12AffineFastState.compose env41707 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1872) := by decide +kernel

theorem selectedBound41707 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41708 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1872,868,268,1589,81,263,1572,1572,1025,80,805,32,16,82,349,64,1792,1653,821,1653,1284,113,257,112,1636,513]

theorem envBound41708 : H12AffineFastState.Bounded env41708 := by
  intro p hp
  have h : env41708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41707_41708 : H12AffineEnvironment.transform 10 1872 env41707 = env41708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1872 env41707 == env41708) = true)

theorem identity41708 : scanCanonicalize (H12AffineFastState.compose env41708 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41708 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41709 : List Nat := [2,4,8,16,32,64,89,36,512,1024,1652,576,40,1589,81,35,1572,1572,1025,80,513,32,16,82,121,64,1572,1653,529,1653,1056,113,37,112,1636,513]

theorem envBound41709 : H12AffineFastState.Bounded env41709 := by
  intro p hp
  have h : env41709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41708_41709 : H12AffineEnvironment.transform 7 36 env41708 = env41709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41708 == env41709) = true)

theorem identity41709 : scanCanonicalize (H12AffineFastState.compose env41709 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41709 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41710 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1573,529,40,1589,0,35,1572,1572,1025,1,513,32,16,3,40,17,1572,1572,529,1572,1056,32,37,33,1589,513]

theorem envBound41710 : H12AffineFastState.Bounded env41710 := by
  intro p hp
  have h : env41710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41709_41710 : H12AffineEnvironment.transform 5 17 env41709 = env41710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41709 == env41710) = true)

theorem identity41710 : scanCanonicalize (H12AffineFastState.compose env41710 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41710 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41711 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1573,512,40,1572,0,35,1572,1572,1025,1,513,32,1,3,40,0,1572,1572,512,1572,1056,32,37,33,1572,513]

theorem envBound41711 : H12AffineFastState.Bounded env41711 := by
  intro p hp
  have h : env41711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41710_41711 : H12AffineEnvironment.transform 3 1 env41710 = env41711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41710 == env41711) = true)

theorem identity41711 : scanCanonicalize (H12AffineFastState.compose env41711 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound41711 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41712 : List Nat := [2,4,8,1,32,0,8,36,512,36,513,512,40,512,0,35,512,512,37,1,513,32,1,3,40,0,512,512,512,512,4,32,37,33,512,513]

theorem envBound41712 : H12AffineFastState.Bounded env41712 := by
  intro p hp
  have h : env41712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41711_41712 : H12AffineEnvironment.transform 9 36 env41711 = env41712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env41711 == env41712) = true)

theorem identity41712 : scanCanonicalize (H12AffineFastState.compose env41712 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41713 : List Nat := [2,4,8,1,32,0,8,36,0,36,1,0,40,0,0,35,0,0,37,1,1,32,1,3,40,0,0,0,0,0,4,32,37,33,0,1]

theorem envBound41713 : H12AffineFastState.Bounded env41713 := by
  intro p hp
  have h : env41713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41712_41713 : H12AffineEnvironment.transform 8 0 env41712 = env41713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41712 == env41713) = true)

theorem identity41713 : scanCanonicalize (H12AffineFastState.compose env41713 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41714 : List Nat := [2,4,8,1,11,0,8,15,0,15,1,0,3,0,0,8,0,0,14,1,1,11,1,3,3,0,0,0,0,0,4,11,14,10,0,1]

theorem envBound41714 : H12AffineFastState.Bounded env41714 := by
  intro p hp
  have h : env41714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41713_41714 : H12AffineEnvironment.transform 4 11 env41713 = env41714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41713 == env41714) = true)

def env41715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound41715 : H12AffineFastState.Bounded env41715 := by
  intro p hp
  have h : env41715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41285_41715 : H12AffineEnvironment.transform 26 30393345 env41285 = env41715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env41285 == env41715) = true)

def env41716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound41716 : H12AffineFastState.Bounded env41716 := by
  intro p hp
  have h : env41716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41715_41716 : H12AffineEnvironment.transform 18 1024 env41715 = env41716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env41715 == env41716) = true)

theorem identity41716 : scanCanonicalize (H12AffineFastState.compose env41716 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound41716 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188616,8328,64,15115593,57796,10507601,8830977,10543448,4194440,256,8430053,8405056,10602126]

theorem envBound41717 : H12AffineFastState.Bounded env41717 := by
  intro p hp
  have h : env41717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41716_41717 : H12AffineEnvironment.transform 23 2188616 env41716 = env41717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env41716 == env41717) = true)

def env41718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62660,2188616,8328,64,6705549,57796,2138517,406725,2102684,4194440,256,21793,46212,2175562]

theorem envBound41718 : H12AffineFastState.Bounded env41718 := by
  intro p hp
  have h : env41718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41717_41718 : H12AffineEnvironment.transform 22 62660 env41717 = env41718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env41717 == env41718) = true)

def env41719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62660,2188616,8328,64,158029,57796,2138517,406725,2102684,2373704,256,21793,46212,2175562]

theorem envBound41719 : H12AffineFastState.Bounded env41719 := by
  intro p hp
  have h : env41719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41718_41719 : H12AffineEnvironment.transform 21 2373824 env41718 = env41719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env41718 == env41719) = true)

theorem identity41719 : scanCanonicalize (H12AffineFastState.compose env41719 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound41719 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,392287,62660,41431,8328,64,158029,57796,91402,406725,119043,392407,256,21793,46212,63189]

theorem envBound41720 : H12AffineFastState.Bounded env41720 := by
  intro p hp
  have h : env41720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41719_41720 : H12AffineEnvironment.transform 20 115871 env41719 = env41720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env41719 == env41720) = true)

def env41721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115871,119927,62660,41431,8328,64,158029,57796,91402,138477,119043,120063,256,21793,46212,63189]

theorem envBound41721 : H12AffineFastState.Bounded env41721 := by
  intro p hp
  have h : env41721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41720_41721 : H12AffineEnvironment.transform 17 10280 env41720 = env41721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41720 == env41721) = true)

def env41722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102815,98679,41412,41431,8328,64,146509,46276,77834,138477,99331,98815,256,33,46212,41941]

theorem envBound41722 : H12AffineFastState.Bounded env41722 := by
  intro p hp
  have h : env41722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41721_41722 : H12AffineEnvironment.transform 13 5376 env41721 = env41722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41721 == env41722) = true)

theorem identity41722 : scanCanonicalize (H12AffineFastState.compose env41722 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41722 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102678,98679,41293,41310,8193,64,146509,46157,77834,138340,99331,98678,256,33,46093,41820]

theorem envBound41723 : H12AffineFastState.Bounded env41723 := by
  intro p hp
  have h : env41723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41722_41723 : H12AffineEnvironment.transform 6 9 env41722 = env41723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41722 == env41723) = true)

theorem identity41723 : scanCanonicalize (H12AffineFastState.compose env41723 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41723 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env41724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,77899,73770,16,3,8193,64,146509,5392,77834,138340,75102,73771,256,33,5456,513]

theorem envBound41724 : H12AffineFastState.Bounded env41724 := by
  intro p hp
  have h : env41724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41723_41724 : H12AffineEnvironment.transform 14 8541 env41723 = env41724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41723 == env41724) = true)

theorem identity41724 : scanCanonicalize (H12AffineFastState.compose env41724 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound41724 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env41725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,70678,10280,1024,8540,77899,73770,16,3,8193,64,75867,5392,77834,67698,75102,73771,256,33,5456,513]

theorem envBound41725 : H12AffineFastState.Bounded env41725 := by
  intro p hp
  have h : env41725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41724_41725 : H12AffineEnvironment.transform 16 70678 env41724 = env41725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env41724 == env41725) = true)

theorem identity41725 : scanCanonicalize (H12AffineFastState.compose env41725 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41725 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41726 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,65536,70678,10280,1024,8460,77851,73770,16,3,8193,16,75787,5392,77834,67618,75022,73771,256,33,5376,513]

theorem envBound41726 : H12AffineFastState.Bounded env41726 := by
  intro p hp
  have h : env41726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41725_41726 : H12AffineEnvironment.transform 5 16 env41725 = env41726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41725 == env41726) = true)

theorem identity41726 : scanCanonicalize (H12AffineFastState.compose env41726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41727 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,65536,70678,2340,1024,0,69911,65830,16,3,269,16,67847,5392,69894,67618,66562,65831,256,33,5376,513]

theorem envBound41727 : H12AffineFastState.Bounded env41727 := by
  intro p hp
  have h : env41727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41726_41727 : H12AffineEnvironment.transform 12 268 env41726 = env41727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41726 == env41727) = true)

theorem identity41727 : scanCanonicalize (H12AffineFastState.compose env41727 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound41727 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41728 : List Nat := [2,4,8,16,32,16,9,256,512,1024,561,4096,268,5376,1,65536,70678,789,1024,0,69911,65830,16,3,269,16,66358,5392,69894,66067,66562,65831,256,33,5376,513]

theorem envBound41728 : H12AffineFastState.Bounded env41728 := by
  intro p hp
  have h : env41728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41727_41728 : H12AffineEnvironment.transform 10 561 env41727 = env41728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env41727 == env41728) = true)

theorem identity41728 : scanCanonicalize (H12AffineFastState.compose env41728 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound41728 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env41729 : List Nat := [2,4,8,16,32,16,9,256,512,1024,561,528,268,1808,1,65536,67078,789,1024,0,66311,65830,16,3,269,16,66358,1792,66326,66067,66562,65831,256,33,1808,513]

theorem envBound41729 : H12AffineFastState.Bounded env41729 := by
  intro p hp
  have h : env41729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41728_41729 : H12AffineEnvironment.transform 11 528 env41728 = env41729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env41728 == env41729) = true)

theorem identity41729 : scanCanonicalize (H12AffineFastState.compose env41729 (packedSelected [0,4,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41729 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env41730 : List Nat := [2,4,8,16,32,16,9,256,512,1024,561,528,268,1808,1,262,1792,789,1024,0,513,32,16,3,269,16,560,1792,528,789,1284,33,256,33,1808,513]

theorem envBound41730 : H12AffineFastState.Bounded env41730 := by
  intro p hp
  have h : env41730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41729_41730 : H12AffineEnvironment.transform 15 262 env41729 = env41730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41729 == env41730) = true)

theorem identity41730 : scanCanonicalize (H12AffineFastState.compose env41730 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41731 : List Nat := [2,4,8,16,0,16,9,256,512,1024,529,528,268,1808,1,262,1792,789,1024,0,513,0,16,3,269,16,528,1792,528,789,1284,1,256,1,1808,513]

theorem envBound41731 : H12AffineFastState.Bounded env41731 := by
  intro p hp
  have h : env41731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41730_41731 : H12AffineEnvironment.transform 4 0 env41730 = env41731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41730 == env41731) = true)

theorem identity41731 : scanCanonicalize (H12AffineFastState.compose env41731 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41731 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41732 : List Nat := [2,4,8,16,0,16,9,256,0,1024,17,16,268,1296,1,262,1280,277,1024,0,1,0,16,3,269,16,16,1280,16,277,1284,1,256,1,1296,1]

theorem envBound41732 : H12AffineFastState.Bounded env41732 := by
  intro p hp
  have h : env41732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41731_41732 : H12AffineEnvironment.transform 8 0 env41731 = env41732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41731 == env41732) = true)

def env41733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102814,98678,41413,41431,8328,64,146508,46277,77835,138477,99330,98814,256,32,46212,41940]

theorem envBound41733 : H12AffineFastState.Bounded env41733 := by
  intro p hp
  have h : env41733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41721_41733 : H12AffineEnvironment.transform 13 5377 env41721 = env41733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41721 == env41733) = true)

def env41734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10280,1024,32769,102814,98678,41413,41431,8328,64,10588,46277,77835,2557,99330,98814,256,32,46212,41940]

theorem envBound41734 : H12AffineFastState.Bounded env41734 := by
  intro p hp
  have h : env41734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41733_41734 : H12AffineEnvironment.transform 16 5392 env41733 = env41734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env41733 == env41734) = true)

theorem identity41734 : scanCanonicalize (H12AffineFastState.compose env41734 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound41734 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,5392,10280,1024,8660,77899,73891,16,2,8328,64,10588,5392,77835,2557,75223,73771,256,32,5457,513]

theorem envBound41735 : H12AffineFastState.Bounded env41735 := by
  intro p hp
  have h : env41735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41734_41735 : H12AffineEnvironment.transform 14 8661 env41734 = env41735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env41734 == env41735) = true)

theorem identity41735 : scanCanonicalize (H12AffineFastState.compose env41735 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound41735 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env41736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,65536,5392,2556,1024,0,70047,65911,16,2,348,64,2184,5392,70111,2557,66563,66047,256,32,5457,513]

theorem envBound41736 : H12AffineFastState.Bounded env41736 := by
  intro p hp
  have h : env41736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41735_41736 : H12AffineEnvironment.transform 12 468 env41735 = env41736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env41735 == env41736) = true)

theorem identity41736 : scanCanonicalize (H12AffineFastState.compose env41736 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound41736 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,479,5392,2556,1024,0,4160,168,16,2,348,64,2184,5392,4096,2557,1500,32,256,32,5457,513]

theorem envBound41737 : H12AffineFastState.Bounded env41737 := by
  intro p hp
  have h : env41737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41736_41737 : H12AffineEnvironment.transform 15 479 env41736 = env41737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env41736 == env41737) = true)

theorem identity41737 : scanCanonicalize (H12AffineFastState.compose env41737 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41737 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5392,2420,1024,0,4160,32,16,2,348,64,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound41738 : H12AffineFastState.Bounded env41738 := by
  intro p hp
  have h : env41738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41737_41738 : H12AffineEnvironment.transform 6 8 env41737 = env41738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41737 == env41738) = true)

theorem identity41738 : scanCanonicalize (H12AffineFastState.compose env41738 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound41738 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1793,348,512,1,343,529,2420,1024,0,1857,32,16,2,348,64,2048,529,1793,2421,1364,32,256,32,592,513]

theorem envBound41739 : H12AffineFastState.Bounded env41739 := by
  intro p hp
  have h : env41739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41738_41739 : H12AffineEnvironment.transform 11 1793 env41738 = env41739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env41738 == env41739) = true)

theorem identity41739 : scanCanonicalize (H12AffineFastState.compose env41739 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1653) := by decide +kernel

theorem selectedBound41739 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1653,1793,348,512,1,343,529,1793,1024,0,1857,32,16,2,348,64,1653,529,1793,1792,1364,32,256,32,592,513]

theorem envBound41740 : H12AffineFastState.Bounded env41740 := by
  intro p hp
  have h : env41740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41739_41740 : H12AffineEnvironment.transform 10 1653 env41739 = env41740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1653 env41739 == env41740) = true)

theorem identity41740 : scanCanonicalize (H12AffineFastState.compose env41740 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound41740 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41741 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1653,1621,8,512,1,3,529,1621,1024,0,1557,32,16,2,8,64,1653,529,1621,1620,1024,32,84,32,592,513]

theorem envBound41741 : H12AffineFastState.Bounded env41741 := by
  intro p hp
  have h : env41741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41740_41741 : H12AffineEnvironment.transform 7 84 env41740 = env41741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env41740 == env41741) = true)

theorem identity41741 : scanCanonicalize (H12AffineFastState.compose env41741 (packedSelected [2,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41741 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env41742 : List Nat := [2,4,8,16,32,64,8,84,1,1024,1140,1108,8,1,1,3,16,1108,1024,0,1044,32,16,2,8,64,1140,16,1108,1109,1024,32,84,32,81,0]

theorem envBound41742 : H12AffineFastState.Bounded env41742 := by
  intro p hp
  have h : env41742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41741_41742 : H12AffineEnvironment.transform 8 1 env41741 = env41742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41741 == env41742) = true)

theorem identity41742 : scanCanonicalize (H12AffineFastState.compose env41742 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound41742 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41743 : List Nat := [2,4,8,16,32,64,8,84,1,116,0,32,8,1,1,3,16,32,116,0,96,32,16,2,8,64,0,16,32,33,116,32,84,32,81,0]

theorem envBound41743 : H12AffineFastState.Bounded env41743 := by
  intro p hp
  have h : env41743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41742_41743 : H12AffineEnvironment.transform 9 116 env41742 = env41743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env41742 == env41743) = true)

theorem identity41743 : scanCanonicalize (H12AffineFastState.compose env41743 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound41743 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41744 : List Nat := [2,4,8,16,32,33,8,53,1,21,0,32,8,1,1,3,16,32,21,0,1,32,16,2,8,33,0,16,32,33,21,32,53,32,48,0]

theorem envBound41744 : H12AffineFastState.Bounded env41744 := by
  intro p hp
  have h : env41744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41743_41744 : H12AffineEnvironment.transform 5 33 env41743 = env41744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env41743 == env41744) = true)

theorem identity41744 : scanCanonicalize (H12AffineFastState.compose env41744 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41744 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41745 : List Nat := [2,4,8,16,0,1,8,21,1,21,0,0,8,1,1,3,16,0,21,0,1,0,16,2,8,1,0,16,0,1,21,0,21,0,16,0]

theorem envBound41745 : H12AffineFastState.Bounded env41745 := by
  intro p hp
  have h : env41745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41744_41745 : H12AffineEnvironment.transform 4 0 env41744 = env41745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41744 == env41745) = true)

theorem identity41745 : scanCanonicalize (H12AffineFastState.compose env41745 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41745 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41746 : List Nat := [2,4,8,0,0,1,8,5,1,5,0,0,8,1,1,3,0,0,5,0,1,0,0,2,8,1,0,0,0,1,5,0,5,0,0,0]

theorem envBound41746 : H12AffineFastState.Bounded env41746 := by
  intro p hp
  have h : env41746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41745_41746 : H12AffineEnvironment.transform 3 0 env41745 = env41746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41745 == env41746) = true)

def env41747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1024,32769,102814,98678,41413,41431,8328,64,10589,46277,77835,2556,99330,98814,256,32,46212,41940]

theorem envBound41747 : H12AffineFastState.Bounded env41747 := by
  intro p hp
  have h : env41747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41733_41747 : H12AffineEnvironment.transform 16 5393 env41733 = env41747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env41733 == env41747) = true)

def env41748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115871,119926,62660,41431,8328,64,158029,57796,91402,138476,119043,120062,256,21793,46212,63189]

theorem envBound41748 : H12AffineFastState.Bounded env41748 := by
  intro p hp
  have h : env41748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41720_41748 : H12AffineEnvironment.transform 17 10281 env41720 = env41748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41720 == env41748) = true)

def env41749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102815,98678,41412,41431,8328,64,146509,46276,77834,138476,99331,98814,256,33,46212,41941]

theorem envBound41749 : H12AffineFastState.Bounded env41749 := by
  intro p hp
  have h : env41749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41748_41749 : H12AffineEnvironment.transform 13 5376 env41748 = env41749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41748 == env41749) = true)

theorem identity41749 : scanCanonicalize (H12AffineFastState.compose env41749 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41749 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,78018,73771,153,138,8328,64,146509,5529,77834,138476,75102,73891,256,33,5593,648]

theorem envBound41750 : H12AffineFastState.Bounded env41750 := by
  intro p hp
  have h : env41750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41749_41750 : H12AffineEnvironment.transform 14 8541 env41749 = env41750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41749 == env41750) = true)

theorem identity41750 : scanCanonicalize (H12AffineFastState.compose env41750 (packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 13438) := by decide +kernel

theorem selectedBound41750 : packedSelected [0,2,3,5,6,7,11,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env41751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,13438,131072,10281,1024,8540,1212,5205,153,138,8328,64,146509,5529,1140,138476,4384,5341,256,33,5593,648]

theorem envBound41751 : H12AffineFastState.Bounded env41751 := by
  intro p hp
  have h : env41751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41750_41751 : H12AffineEnvironment.transform 15 13438 env41750 = env41751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13438 env41750 == env41751) = true)

theorem identity41751 : scanCanonicalize (H12AffineFastState.compose env41751 (packedSelected [1,2,4,6,8,10,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 9308) := by decide +kernel

theorem selectedBound41751 : packedSelected [1,2,4,6,8,10,15,20,22] rootPS < 2^1333 := by decide +kernel

def env41752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,13438,9308,10281,1024,8540,1212,5205,153,138,8328,64,6161,5529,1140,14512,4384,5341,256,33,5593,648]

theorem envBound41752 : H12AffineFastState.Bounded env41752 := by
  intro p hp
  have h : env41752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41751_41752 : H12AffineEnvironment.transform 16 9308 env41751 = env41752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 9308 env41751 == env41752) = true)

theorem identity41752 : scanCanonicalize (H12AffineFastState.compose env41752 (packedSelected [0,1,2,4,6,8,9,10,15,16,18,23,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41752 : packedSelected [0,1,2,4,6,8,9,10,15,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env41753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,17,8192,1297,8541,9327,9308,10281,1024,8540,1212,1092,153,138,8328,64,2048,1416,1140,10401,305,1228,256,33,1480,648]

theorem envBound41753 : H12AffineFastState.Bounded env41753 := by
  intro p hp
  have h : env41753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41752_41753 : H12AffineEnvironment.transform 11 17 env41752 = env41753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41752 == env41753) = true)

theorem identity41753 : scanCanonicalize (H12AffineFastState.compose env41753 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound41753 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env41754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,217,17,8192,1297,8541,9327,9308,8432,1024,8540,1212,1092,153,138,8328,64,217,1416,1140,8312,305,1228,256,33,1480,648]

theorem envBound41754 : H12AffineFastState.Bounded env41754 := by
  intro p hp
  have h : env41754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41753_41754 : H12AffineEnvironment.transform 10 217 env41753 = env41754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env41753 == env41754) = true)

theorem identity41754 : scanCanonicalize (H12AffineFastState.compose env41754 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41754 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env41755 : List Nat := [2,4,8,16,32,64,128,256,512,273,217,17,8192,0,8541,8574,8525,8432,273,8540,429,341,153,138,8328,64,217,153,357,8312,305,477,256,33,217,648]

theorem envBound41755 : H12AffineFastState.Bounded env41755 := by
  intro p hp
  have h : env41755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41754_41755 : H12AffineEnvironment.transform 9 273 env41754 = env41755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41754 == env41755) = true)

theorem identity41755 : scanCanonicalize (H12AffineFastState.compose env41755 (packedSelected [1,3,5,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound41755 : packedSelected [1,3,5,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env41756 : List Nat := [2,4,8,16,32,64,128,256,512,273,217,17,9,0,340,375,324,249,273,341,429,341,153,138,129,64,217,153,357,113,305,477,256,33,217,648]

theorem envBound41756 : H12AffineFastState.Bounded env41756 := by
  intro p hp
  have h : env41756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41755_41756 : H12AffineEnvironment.transform 12 9 env41755 = env41756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env41755 == env41756) = true)

theorem identity41756 : scanCanonicalize (H12AffineFastState.compose env41756 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound41756 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env41757 : List Nat := [2,4,8,16,32,64,41,256,512,273,112,17,9,0,340,375,324,80,273,341,260,341,48,35,40,64,112,48,357,113,305,372,256,33,112,545]

theorem envBound41757 : H12AffineFastState.Bounded env41757 := by
  intro p hp
  have h : env41757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41756_41757 : H12AffineEnvironment.transform 6 41 env41756 = env41757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env41756 == env41757) = true)

theorem identity41757 : scanCanonicalize (H12AffineFastState.compose env41757 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound41757 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41758 : List Nat := [2,4,8,16,32,64,41,256,276,273,112,17,9,0,340,375,324,80,273,341,260,341,48,35,40,64,112,48,357,113,305,372,256,33,112,309]

theorem envBound41758 : H12AffineFastState.Bounded env41758 := by
  intro p hp
  have h : env41758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41757_41758 : H12AffineEnvironment.transform 8 276 env41757 = env41758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env41757 == env41758) = true)

theorem identity41758 : scanCanonicalize (H12AffineFastState.compose env41758 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound41758 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env41759 : List Nat := [2,4,8,16,32,48,41,256,276,273,0,17,9,0,292,263,308,32,273,293,260,293,48,35,40,48,0,48,277,1,305,260,256,33,0,309]

theorem envBound41759 : H12AffineFastState.Bounded env41759 := by
  intro p hp
  have h : env41759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41758_41759 : H12AffineEnvironment.transform 5 48 env41758 = env41759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env41758 == env41759) = true)

theorem identity41759 : scanCanonicalize (H12AffineFastState.compose env41759 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41759 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env41760 : List Nat := [2,4,8,16,1,17,8,256,276,273,0,17,9,0,261,263,277,1,273,260,260,260,17,2,9,17,0,17,277,1,272,260,256,0,0,276]

theorem envBound41760 : H12AffineFastState.Bounded env41760 := by
  intro p hp
  have h : env41760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41759_41760 : H12AffineEnvironment.transform 4 1 env41759 = env41760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41759 == env41760) = true)

theorem identity41760 : scanCanonicalize (H12AffineFastState.compose env41760 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41760 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env41761 : List Nat := [2,4,8,16,1,17,8,4,16,21,0,17,9,0,1,3,17,1,21,0,0,0,17,2,9,17,0,17,17,1,20,0,4,0,0,16]

theorem envBound41761 : H12AffineFastState.Bounded env41761 := by
  intro p hp
  have h : env41761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41760_41761 : H12AffineEnvironment.transform 7 4 env41760 = env41761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41760 == env41761) = true)

theorem identity41761 : scanCanonicalize (H12AffineFastState.compose env41761 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41762 : List Nat := [2,4,8,1,1,0,8,4,1,4,0,0,9,0,1,3,0,1,4,0,0,0,0,2,9,0,0,0,0,1,5,0,4,0,0,1]

theorem envBound41762 : H12AffineFastState.Bounded env41762 := by
  intro p hp
  have h : env41762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41761_41762 : H12AffineEnvironment.transform 3 1 env41761 = env41762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41761 == env41762) = true)

theorem identity41762 : scanCanonicalize (H12AffineFastState.compose env41762 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound41762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41763 : List Nat := [2,4,6,1,1,0,6,4,1,4,0,0,7,0,1,3,0,1,4,0,0,0,0,2,7,0,0,0,0,1,5,0,4,0,0,1]

theorem envBound41763 : H12AffineFastState.Bounded env41763 := by
  intro p hp
  have h : env41763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41762_41763 : H12AffineEnvironment.transform 2 6 env41762 = env41763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env41762 == env41763) = true)

def env41764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102814,98679,41413,41431,8328,64,146508,46277,77835,138476,99330,98815,256,32,46212,41940]

theorem envBound41764 : H12AffineFastState.Bounded env41764 := by
  intro p hp
  have h : env41764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41748_41764 : H12AffineEnvironment.transform 13 5377 env41748 = env41764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41748 == env41764) = true)

theorem identity41764 : scanCanonicalize (H12AffineFastState.compose env41764 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound41764 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1024,8660,77899,73890,16,2,8328,64,146508,5392,77835,138476,75223,73770,256,32,5457,513]

theorem envBound41765 : H12AffineFastState.Bounded env41765 := by
  intro p hp
  have h : env41765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41764_41765 : H12AffineEnvironment.transform 14 8661 env41764 = env41765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env41764 == env41765) = true)

theorem identity41765 : scanCanonicalize (H12AffineFastState.compose env41765 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound41765 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79131,10281,1024,8660,77899,73890,16,2,8328,64,67927,5392,77835,76279,75223,73770,256,32,5457,513]

theorem envBound41766 : H12AffineFastState.Bounded env41766 := by
  intro p hp
  have h : env41766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41765_41766 : H12AffineEnvironment.transform 16 79131 env41765 = env41766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env41765 == env41766) = true)

theorem identity41766 : scanCanonicalize (H12AffineFastState.compose env41766 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound41766 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,9499,4096,10281,1024,8660,5456,1465,16,2,8328,64,11340,5392,5392,3308,204,1329,256,32,5457,513]

theorem envBound41767 : H12AffineFastState.Bounded env41767 := by
  intro p hp
  have h : env41767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41766_41767 : H12AffineEnvironment.transform 15 9499 env41766 = env41767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env41766 == env41767) = true)

theorem identity41767 : scanCanonicalize (H12AffineFastState.compose env41767 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41767 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env41768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5377,508,1330,4096,2048,1024,509,5456,1465,16,2,161,64,3173,5392,5392,3308,204,1329,256,32,5457,513]

theorem envBound41768 : H12AffineFastState.Bounded env41768 := by
  intro p hp
  have h : env41768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41767_41768 : H12AffineEnvironment.transform 12 41 env41767 = env41768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41767 == env41768) = true)

theorem identity41768 : scanCanonicalize (H12AffineFastState.compose env41768 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41768 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env41769 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,41,5157,216,1046,4096,2048,1024,217,5236,1181,16,2,161,64,3173,5172,5172,3308,204,1045,36,32,5237,513]

theorem envBound41769 : H12AffineFastState.Bounded env41769 := by
  intro p hp
  have h : env41769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41768_41769 : H12AffineEnvironment.transform 7 36 env41768 = env41769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41768 == env41769) = true)

theorem identity41769 : scanCanonicalize (H12AffineFastState.compose env41769 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound41769 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41770 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,545,41,1540,216,1046,545,2048,1024,217,1621,1181,16,2,161,64,3173,1557,1557,3308,204,1045,36,32,1620,513]

theorem envBound41770 : H12AffineFastState.Bounded env41770 := by
  intro p hp
  have h : env41770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41769_41770 : H12AffineEnvironment.transform 11 545 env41769 = env41770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env41769 == env41770) = true)

theorem identity41770 : scanCanonicalize (H12AffineFastState.compose env41770 (packedSelected [6,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound41770 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env41771 : List Nat := [2,4,8,16,32,64,40,36,512,1024,2048,545,41,1540,112,1046,545,2048,1024,113,1621,1077,16,2,9,64,3173,1557,1557,3140,100,1045,36,32,1620,513]

theorem envBound41771 : H12AffineFastState.Bounded env41771 := by
  intro p hp
  have h : env41771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41770_41771 : H12AffineEnvironment.transform 6 40 env41770 = env41771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env41770 == env41771) = true)

def env41772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62660,2188616,8328,64,158028,57796,2138517,406725,2102684,2373705,256,21793,46212,2175562]

theorem envBound41772 : H12AffineFastState.Bounded env41772 := by
  intro p hp
  have h : env41772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41718_41772 : H12AffineEnvironment.transform 21 2373825 env41718 = env41772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env41718 == env41772) = true)

theorem identity41772 : scanCanonicalize (H12AffineFastState.compose env41772 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound41772 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329866,62660,21763,8328,64,158028,57796,102878,406725,75223,329730,256,21793,46212,513]

theorem envBound41773 : H12AffineFastState.Bounded env41773 := by
  intro p hp
  have h : env41773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41772_41773 : H12AffineEnvironment.transform 20 77899 env41772 = env41773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env41772 == env41773) = true)

def env41774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329730,62540,21763,8192,64,158028,57676,102742,406605,75103,329730,256,21793,46092,513]

theorem envBound41774 : H12AffineFastState.Bounded env41774 := by
  intro p hp
  have h : env41774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41773_41774 : H12AffineEnvironment.transform 6 8 env41773 = env41774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41773 == env41774) = true)

theorem identity41774 : scanCanonicalize (H12AffineFastState.compose env41774 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound41774 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77899,329730,62540,21763,8192,64,67926,57676,102742,349271,75103,329730,256,21793,46092,513]

theorem envBound41775 : H12AffineFastState.Bounded env41775 := by
  intro p hp
  have h : env41775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41774_41775 : H12AffineEnvironment.transform 16 90138 env41774 = env41775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env41774 == env41775) = true)

def env41776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,77899,73770,62540,21763,8192,64,67926,57676,102742,97407,75103,73770,256,21793,46092,513]

theorem envBound41776 : H12AffineFastState.Bounded env41776 := by
  intro p hp
  have h : env41776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41775_41776 : H12AffineEnvironment.transform 17 10280 env41775 = env41776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41775 == env41776) = true)

theorem identity41776 : scanCanonicalize (H12AffineFastState.compose env41776 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound41776 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10280,1024,29789,77899,73770,16,21763,8192,64,67926,5392,91402,97407,75103,73770,256,21793,16464,513]

theorem envBound41777 : H12AffineFastState.Bounded env41777 := by
  intro p hp
  have h : env41777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41776_41777 : H12AffineEnvironment.transform 14 29788 env41776 = env41777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env41776 == env41777) = true)

theorem identity41777 : scanCanonicalize (H12AffineFastState.compose env41777 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31790) := by decide +kernel

theorem selectedBound41777 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,31790,7220,10280,1024,29789,19557,23556,16,21763,8192,64,30072,5392,6436,81,22897,23556,256,21793,16464,513]

theorem envBound41778 : H12AffineFastState.Bounded env41778 := by
  intro p hp
  have h : env41778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41777_41778 : H12AffineEnvironment.transform 15 31790 env41777 = env41778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31790 env41777 == env41778) = true)

theorem identity41778 : scanCanonicalize (H12AffineFastState.compose env41778 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,10543,7220,10280,1024,8540,6500,2309,16,2,8192,64,8313,5392,6436,81,3184,2309,256,32,5457,513]

theorem envBound41779 : H12AffineFastState.Bounded env41779 := by
  intro p hp
  have h : env41779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41778_41779 : H12AffineEnvironment.transform 13 5377 env41778 = env41779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41778 == env41779) = true)

theorem identity41779 : scanCanonicalize (H12AffineFastState.compose env41779 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound41779 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,1296,3426,7220,3173,1024,1297,6500,2309,16,2,1101,64,1076,5392,6436,81,3184,2309,256,32,5457,513]

theorem envBound41780 : H12AffineFastState.Bounded env41780 := by
  intro p hp
  have h : env41780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41779_41780 : H12AffineEnvironment.transform 12 1101 env41779 = env41780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env41779 == env41780) = true)

theorem identity41780 : scanCanonicalize (H12AffineFastState.compose env41780 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound41780 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,1101,5377,1296,34,4468,293,1024,1297,5156,1093,16,2,1101,64,1076,5392,5220,81,304,1093,256,32,5457,513]

theorem envBound41781 : H12AffineFastState.Bounded env41781 := by
  intro p hp
  have h : env41781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41780_41781 : H12AffineEnvironment.transform 10 1344 env41780 = env41781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env41780 == env41781) = true)

theorem identity41781 : scanCanonicalize (H12AffineFastState.compose env41781 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41781 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41782 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,4096,40,4452,373,34,4468,293,101,372,4161,32,16,2,40,64,81,4469,4097,81,304,32,256,32,4404,513]

theorem envBound41782 : H12AffineFastState.Bounded env41782 := by
  intro p hp
  have h : env41782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41781_41782 : H12AffineEnvironment.transform 9 101 env41781 = env41782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41781 == env41782) = true)

theorem identity41782 : scanCanonicalize (H12AffineFastState.compose env41782 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41782 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41783 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,4096,40,4404,293,34,4388,293,53,292,4113,32,16,2,40,16,1,4389,4097,1,304,32,256,32,4404,513]

theorem envBound41783 : H12AffineFastState.Bounded env41783 := by
  intro p hp
  have h : env41783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41782_41783 : H12AffineEnvironment.transform 5 16 env41782 = env41783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41782 == env41783) = true)

theorem identity41783 : scanCanonicalize (H12AffineFastState.compose env41783 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41783 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41784 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,4096,40,4113,0,34,4097,0,53,1,4113,32,16,2,40,16,1,4096,4097,1,21,32,37,32,4113,513]

theorem envBound41784 : H12AffineFastState.Bounded env41784 := by
  intro p hp
  have h : env41784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41783_41784 : H12AffineEnvironment.transform 7 37 env41783 = env41784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41783 == env41784) = true)

theorem identity41784 : scanCanonicalize (H12AffineFastState.compose env41784 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41785 : List Nat := [2,4,8,16,32,16,8,37,1,53,0,4096,40,4113,0,34,4097,0,53,1,4113,32,16,2,40,16,1,4096,4097,1,21,32,37,32,4113,0]

theorem envBound41785 : H12AffineFastState.Bounded env41785 := by
  intro p hp
  have h : env41785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41784_41785 : H12AffineEnvironment.transform 8 1 env41784 = env41785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41784 == env41785) = true)

theorem identity41785 : scanCanonicalize (H12AffineFastState.compose env41785 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41786 : List Nat := [2,4,8,16,11,16,8,14,1,30,0,4096,3,4113,0,9,4097,0,30,1,4113,11,16,2,3,16,1,4096,4097,1,21,11,14,11,4113,0]

theorem envBound41786 : H12AffineFastState.Bounded env41786 := by
  intro p hp
  have h : env41786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41785_41786 : H12AffineEnvironment.transform 4 11 env41785 = env41786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41785 == env41786) = true)

theorem identity41786 : scanCanonicalize (H12AffineFastState.compose env41786 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41786 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41787 : List Nat := [2,4,8,16,11,16,8,14,1,30,0,17,3,0,0,9,16,0,30,1,0,11,16,2,3,16,1,17,16,1,21,11,14,11,0,0]

theorem envBound41787 : H12AffineFastState.Bounded env41787 := by
  intro p hp
  have h : env41787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41786_41787 : H12AffineEnvironment.transform 11 17 env41786 = env41787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41786 == env41787) = true)

def env41788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,77899,73771,62540,21763,8192,64,67926,57676,102742,97406,75103,73771,256,21793,46092,513]

theorem envBound41788 : H12AffineFastState.Bounded env41788 := by
  intro p hp
  have h : env41788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41775_41788 : H12AffineEnvironment.transform 17 10281 env41775 = env41788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41775 == env41788) = true)

theorem identity41788 : scanCanonicalize (H12AffineFastState.compose env41788 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound41788 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,16465,20529,62540,21763,8192,64,31052,57676,57676,3172,21829,20529,256,21793,46092,513]

theorem envBound41789 : H12AffineFastState.Bounded env41789 := by
  intro p hp
  have h : env41789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41788_41789 : H12AffineEnvironment.transform 15 28698 env41788 = env41789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env41788 == env41789) = true)

theorem identity41789 : scanCanonicalize (H12AffineFastState.compose env41789 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41789 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10281,1024,8540,16465,20529,21777,21763,8192,64,31052,16401,16401,3172,21829,20529,256,21793,5457,513]

theorem envBound41790 : H12AffineFastState.Bounded env41790 := by
  intro p hp
  have h : env41790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41789_41790 : H12AffineEnvironment.transform 14 8541 env41789 = env41790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41789 == env41790) = true)

theorem identity41790 : scanCanonicalize (H12AffineFastState.compose env41790 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound41790 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env41791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,1344,21511,4096,3124,1024,1345,16465,20529,21777,21763,1053,64,23889,16401,16401,3172,21829,20529,256,21793,5457,513]

theorem envBound41791 : H12AffineFastState.Bounded env41791 := by
  intro p hp
  have h : env41791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41790_41791 : H12AffineEnvironment.transform 12 1053 env41790 = env41791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env41790 == env41791) = true)

theorem identity41791 : scanCanonicalize (H12AffineFastState.compose env41791 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41791 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41792 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,16384,293,20578,4096,2129,101,292,16465,20529,20852,20838,120,64,22836,16401,16401,2049,20768,20529,256,20804,4404,513]

theorem envBound41792 : H12AffineFastState.Bounded env41792 := by
  intro p hp
  have h : env41792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41791_41792 : H12AffineEnvironment.transform 9 101 env41791 = env41792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41791 == env41792) = true)

theorem identity41792 : scanCanonicalize (H12AffineFastState.compose env41792 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound41792 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env41793 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,16384,293,18546,2064,2129,101,292,16465,18465,18788,18806,120,64,16676,16401,16401,2049,18736,18465,256,18772,2340,513]

theorem envBound41793 : H12AffineFastState.Bounded env41793 := by
  intro p hp
  have h : env41793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41792_41793 : H12AffineEnvironment.transform 11 2064 env41792 = env41793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env41792 == env41793) = true)

theorem identity41793 : scanCanonicalize (H12AffineFastState.compose env41793 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound41793 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41794 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,2420,293,262,2064,2129,101,292,2341,341,16,2,120,64,2128,2405,2405,2049,68,341,256,32,2340,513]

theorem envBound41794 : H12AffineFastState.Bounded env41794 := by
  intro p hp
  have h : env41794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41793_41794 : H12AffineEnvironment.transform 13 2420 env41793 = env41794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env41793 == env41794) = true)

def env41795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77899,329731,62541,21763,8193,64,158028,57677,102743,406604,75102,329730,256,21793,46093,513]

theorem envBound41795 : H12AffineFastState.Bounded env41795 := by
  intro p hp
  have h : env41795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41773_41795 : H12AffineEnvironment.transform 6 9 env41773 = env41795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41773 == env41795) = true)

def env41796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77899,73771,62541,21763,8193,64,158028,57677,102743,138340,75102,73770,256,21793,46093,513]

theorem envBound41796 : H12AffineFastState.Bounded env41796 := by
  intro p hp
  have h : env41796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41795_41796 : H12AffineEnvironment.transform 17 10280 env41795 = env41796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41795 == env41796) = true)

def env41797 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62493,21763,8193,16,157980,57629,102663,138292,75022,73770,256,21793,46093,513]

theorem envBound41797 : H12AffineFastState.Bounded env41797 := by
  intro p hp
  have h : env41797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41796_41797 : H12AffineEnvironment.transform 5 16 env41796 = env41797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41796 == env41797) = true)

theorem identity41797 : scanCanonicalize (H12AffineFastState.compose env41797 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41797 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env41798 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10280,1024,0,77851,73771,29724,21763,8193,16,157980,24860,69894,138292,75022,73770,256,21793,13324,513]

theorem envBound41798 : H12AffineFastState.Bounded env41798 := by
  intro p hp
  have h : env41798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41797_41798 : H12AffineEnvironment.transform 14 1 env41797 = env41798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41797 == env41798) = true)

theorem identity41798 : scanCanonicalize (H12AffineFastState.compose env41798 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound41798 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env41799 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,16400,10280,1024,0,77851,73771,29724,21763,8193,16,10508,24860,69894,23588,75022,73770,256,21793,13324,513]

theorem envBound41799 : H12AffineFastState.Bounded env41799 := by
  intro p hp
  have h : env41799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41798_41799 : H12AffineEnvironment.transform 16 16400 env41798 = env41799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41798 == env41799) = true)

theorem identity41799 : scanCanonicalize (H12AffineFastState.compose env41799 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41799 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41800 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,16400,10280,1024,0,4113,33,29724,21763,8193,16,10508,24860,12556,23588,1284,32,256,21793,13324,513]

theorem envBound41800 : H12AffineFastState.Bounded env41800 := by
  intro p hp
  have h : env41800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41799_41800 : H12AffineEnvironment.transform 15 8202 env41799 = env41800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41799 == env41800) = true)

theorem identity41800 : scanCanonicalize (H12AffineFastState.compose env41800 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound41800 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41801 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,8202,13340,10280,1024,0,4113,33,16,8463,8193,16,10508,5392,12556,10280,1284,32,256,8493,13324,513]

theorem envBound41801 : H12AffineFastState.Bounded env41801 := by
  intro p hp
  have h : env41801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41800_41801 : H12AffineEnvironment.transform 13 13324 env41800 = env41801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env41800 == env41801) = true)

theorem identity41801 : scanCanonicalize (H12AffineFastState.compose env41801 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41801 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env41802 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5156,1,34,5172,2048,1024,0,4113,33,16,295,41,16,2340,5392,4388,2048,1284,32,256,261,5156,513]

theorem envBound41802 : H12AffineFastState.Bounded env41802 := by
  intro p hp
  have h : env41802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41801_41802 : H12AffineEnvironment.transform 12 40 env41801 = env41802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41801 == env41802) = true)

theorem identity41802 : scanCanonicalize (H12AffineFastState.compose env41802 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41802 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41803 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1024,0,4113,33,16,2,41,16,2049,5173,4097,2048,1057,32,37,32,5156,513]

theorem envBound41803 : H12AffineFastState.Bounded env41803 := by
  intro p hp
  have h : env41803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41802_41803 : H12AffineEnvironment.transform 7 37 env41802 = env41803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41802 == env41803) = true)

theorem identity41803 : scanCanonicalize (H12AffineFastState.compose env41803 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41803 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41804 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,34,4097,2048,53,0,4113,33,16,2,41,16,2049,4096,4097,2048,20,32,37,32,4113,513]

theorem envBound41804 : H12AffineFastState.Bounded env41804 := by
  intro p hp
  have h : env41804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41803_41804 : H12AffineEnvironment.transform 9 53 env41803 = env41804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41803 == env41804) = true)

theorem identity41804 : scanCanonicalize (H12AffineFastState.compose env41804 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound41804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41805 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2064,40,2049,1,34,2065,2048,53,0,2049,33,16,2,41,16,2049,2064,2065,2048,20,32,37,32,2049,513]

theorem envBound41805 : H12AffineFastState.Bounded env41805 := by
  intro p hp
  have h : env41805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41804_41805 : H12AffineEnvironment.transform 11 2064 env41804 = env41805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env41804 == env41805) = true)

theorem identity41805 : scanCanonicalize (H12AffineFastState.compose env41805 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41805 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41806 : List Nat := [2,4,8,10,32,10,9,37,512,47,2048,2058,40,2049,1,34,2059,2048,47,0,2049,33,10,2,41,10,2049,2058,2059,2048,14,32,37,32,2049,513]

theorem envBound41806 : H12AffineFastState.Bounded env41806 := by
  intro p hp
  have h : env41806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41805_41806 : H12AffineEnvironment.transform 3 10 env41805 = env41806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41805 == env41806) = true)

theorem identity41806 : scanCanonicalize (H12AffineFastState.compose env41806 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41806 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41807 : List Nat := [2,4,8,10,32,10,9,37,512,47,0,10,40,1,1,34,11,0,47,0,1,33,10,2,41,10,1,10,11,0,14,32,37,32,1,513]

theorem envBound41807 : H12AffineFastState.Bounded env41807 := by
  intro p hp
  have h : env41807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41806_41807 : H12AffineEnvironment.transform 10 0 env41806 = env41807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41806 == env41807) = true)

def env41808 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62492,21763,8193,17,157981,57628,102662,138293,75023,73770,256,21793,46093,513]

theorem envBound41808 : H12AffineFastState.Bounded env41808 := by
  intro p hp
  have h : env41808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41796_41808 : H12AffineEnvironment.transform 5 17 env41796 = env41808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41796 == env41808) = true)

theorem identity41808 : scanCanonicalize (H12AffineFastState.compose env41808 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41808 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env41809 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77850,73771,62492,21763,8193,17,67846,57628,102662,97326,75023,73770,256,21793,46093,513]

theorem envBound41809 : H12AffineFastState.Bounded env41809 := by
  intro p hp
  have h : env41809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41808_41809 : H12AffineEnvironment.transform 16 90139 env41808 = env41809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41808 == env41809) = true)

theorem identity41809 : scanCanonicalize (H12AffineFastState.compose env41809 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound41809 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41810 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,65536,90139,10280,1024,21760,77850,73771,8477,21763,8193,17,67846,13341,82951,97326,75023,73770,256,21793,24844,513]

theorem envBound41810 : H12AffineFastState.Bounded env41810 := by
  intro p hp
  have h : env41810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41809_41810 : H12AffineEnvironment.transform 14 21761 env41809 = env41810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env41809 == env41810) = true)

theorem identity41810 : scanCanonicalize (H12AffineFastState.compose env41810 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound41810 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41811 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,29963,5392,10280,1024,21760,17681,21792,8477,21763,8193,17,31757,13341,12556,2341,20484,21793,256,21793,24844,513]

theorem envBound41811 : H12AffineFastState.Bounded env41811 := by
  intro p hp
  have h : env41811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41810_41811 : H12AffineEnvironment.transform 15 29963 env41810 = env41811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env41810 == env41811) = true)

theorem identity41811 : scanCanonicalize (H12AffineFastState.compose env41811 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41811 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env41812 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,293,8495,5392,10280,1024,292,4405,260,8477,295,8193,17,10281,13341,12556,2341,1056,261,256,261,13608,513]

theorem envBound41812 : H12AffineFastState.Bounded env41812 := by
  intro p hp
  have h : env41812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41811_41812 : H12AffineEnvironment.transform 13 5156 env41811 = env41812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41811 == env41812) = true)

theorem identity41812 : scanCanonicalize (H12AffineFastState.compose env41812 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41812 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env41813 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,5156,0,8202,5173,10280,1024,1,4112,33,8248,2,8193,17,10281,13341,12329,2048,1056,32,37,32,13325,513]

theorem envBound41813 : H12AffineFastState.Bounded env41813 := by
  intro p hp
  have h : env41813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41812_41813 : H12AffineEnvironment.transform 7 37 env41812 = env41813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41812 == env41813) = true)

theorem identity41813 : scanCanonicalize (H12AffineFastState.compose env41813 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41813 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41814 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,16,8192,1076,0,8202,1061,10280,1024,1,0,33,8248,2,8193,17,10281,9229,8249,2048,1056,32,37,32,9245,513]

theorem envBound41814 : H12AffineFastState.Bounded env41814 := by
  intro p hp
  have h : env41814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41813_41814 : H12AffineEnvironment.transform 11 16 env41813 = env41814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41813 == env41814) = true)

theorem identity41814 : scanCanonicalize (H12AffineFastState.compose env41814 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound41814 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41815 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,16,8192,1076,0,8202,1061,9245,1024,1,0,33,8248,2,8193,17,9244,9229,8249,1077,1056,32,37,32,9245,513]

theorem envBound41815 : H12AffineFastState.Bounded env41815 := by
  intro p hp
  have h : env41815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41814_41815 : H12AffineEnvironment.transform 10 1077 env41814 = env41815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env41814 == env41815) = true)

theorem identity41815 : scanCanonicalize (H12AffineFastState.compose env41815 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41815 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41816 : List Nat := [2,4,8,16,32,17,9,37,512,20,33,16,8192,32,0,8202,49,8201,20,1,0,33,8248,2,8193,17,8200,8217,8249,33,52,32,37,32,8201,513]

theorem envBound41816 : H12AffineFastState.Bounded env41816 := by
  intro p hp
  have h : env41816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41815_41816 : H12AffineEnvironment.transform 9 20 env41815 = env41816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41815 == env41816) = true)

theorem identity41816 : scanCanonicalize (H12AffineFastState.compose env41816 (packedSelected [0,1,8] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound41816 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env41817 : List Nat := [2,4,8,4,32,5,9,37,512,0,33,4,8192,32,0,8202,37,8201,0,1,0,33,8236,2,8193,5,8200,8205,8237,33,32,32,37,32,8201,513]

theorem envBound41817 : H12AffineFastState.Bounded env41817 := by
  intro p hp
  have h : env41817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41816_41817 : H12AffineEnvironment.transform 3 4 env41816 = env41817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env41816 == env41817) = true)

theorem identity41817 : scanCanonicalize (H12AffineFastState.compose env41817 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41817 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env41818 : List Nat := [2,4,8,4,32,5,9,37,512,0,33,4,41,32,0,35,37,32,0,1,0,33,5,2,40,5,33,36,4,33,32,32,37,32,32,513]

theorem envBound41818 : H12AffineFastState.Bounded env41818 := by
  intro p hp
  have h : env41818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41817_41818 : H12AffineEnvironment.transform 12 41 env41817 = env41818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41817 == env41818) = true)

theorem identity41818 : scanCanonicalize (H12AffineFastState.compose env41818 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound41818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41819 : List Nat := [2,4,8,4,32,5,9,37,11,0,33,4,41,32,0,35,37,32,0,1,0,33,5,2,40,5,33,36,4,33,32,32,37,32,32,10]

theorem envBound41819 : H12AffineFastState.Bounded env41819 := by
  intro p hp
  have h : env41819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41818_41819 : H12AffineEnvironment.transform 8 11 env41818 = env41819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env41818 == env41819) = true)

theorem identity41819 : scanCanonicalize (H12AffineFastState.compose env41819 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound41819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41820 : List Nat := [2,4,8,4,13,5,9,8,11,0,12,4,4,13,0,14,8,13,0,1,0,12,5,2,5,5,12,9,4,12,13,13,8,13,13,10]

theorem envBound41820 : H12AffineFastState.Bounded env41820 := by
  intro p hp
  have h : env41820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41819_41820 : H12AffineEnvironment.transform 4 13 env41819 = env41820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env41819 == env41820) = true)

def env41821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77899,73770,62541,21763,8193,64,158028,57677,102743,138341,75102,73771,256,21793,46093,513]

theorem envBound41821 : H12AffineFastState.Bounded env41821 := by
  intro p hp
  have h : env41821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41795_41821 : H12AffineEnvironment.transform 17 10281 env41795 = env41821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41795 == env41821) = true)

theorem identity41821 : scanCanonicalize (H12AffineFastState.compose env41821 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41821 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,77899,73770,16,21763,8193,64,158028,5392,91402,138341,75102,73771,256,21793,16464,513]

theorem envBound41822 : H12AffineFastState.Bounded env41822 := by
  intro p hp
  have h : env41822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41821_41822 : H12AffineEnvironment.transform 14 29789 env41821 = env41822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41821 == env41822) = true)

theorem identity41822 : scanCanonicalize (H12AffineFastState.compose env41822 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound41822 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10281,1024,29788,77899,73770,16,21763,8193,64,67926,5392,91402,97407,75102,73771,256,21793,16464,513]

theorem envBound41823 : H12AffineFastState.Bounded env41823 := by
  intro p hp
  have h : env41823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41822_41823 : H12AffineEnvironment.transform 16 90138 env41822 = env41823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env41822 == env41823) = true)

theorem identity41823 : scanCanonicalize (H12AffineFastState.compose env41823 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound41823 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,28698,4096,10281,1024,29788,16465,20528,16,21763,8193,64,31052,5392,5392,3173,21828,20529,256,21793,16464,513]

theorem envBound41824 : H12AffineFastState.Bounded env41824 := by
  intro p hp
  have h : env41824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41823_41824 : H12AffineEnvironment.transform 15 28698 env41823 = env41824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env41823 == env41824) = true)

theorem identity41824 : scanCanonicalize (H12AffineFastState.compose env41824 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound41824 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16464,17431,4096,7204,1024,16465,16465,20528,16,21763,5132,64,19777,5392,5392,3173,21828,20529,256,21793,16464,513]

theorem envBound41825 : H12AffineFastState.Bounded env41825 := by
  intro p hp
  have h : env41825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41824_41825 : H12AffineEnvironment.transform 12 5133 env41824 = env41825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env41824 == env41825) = true)

theorem identity41825 : scanCanonicalize (H12AffineFastState.compose env41825 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound41825 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env41826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,16384,16464,17431,1061,2049,1024,16465,16465,17429,16,16678,41,64,19777,309,309,3173,16737,17428,256,16644,16464,513]

theorem envBound41826 : H12AffineFastState.Bounded env41826 := by
  intro p hp
  have h : env41826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41825_41826 : H12AffineEnvironment.transform 11 1061 env41825 = env41826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env41825 == env41826) = true)

theorem identity41826 : scanCanonicalize (H12AffineFastState.compose env41826 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound41826 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env41827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,2128,2048,3143,1061,2049,1024,2049,2049,3141,16,2422,41,64,1297,309,309,3173,2353,3140,256,2388,2048,513]

theorem envBound41827 : H12AffineFastState.Bounded env41827 := by
  intro p hp
  have h : env41827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41826_41827 : H12AffineEnvironment.transform 13 2128 env41826 = env41827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env41826 == env41827) = true)

theorem identity41827 : scanCanonicalize (H12AffineFastState.compose env41827 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41827 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env41828 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1061,40,2128,2048,3143,1061,2049,1024,2049,2049,3141,16,2050,41,64,1125,65,65,3173,2117,3140,116,2080,2048,513]

theorem envBound41828 : H12AffineFastState.Bounded env41828 := by
  intro p hp
  have h : env41828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41827_41828 : H12AffineEnvironment.transform 7 116 env41827 = env41828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41827 == env41828) = true)

theorem identity41828 : scanCanonicalize (H12AffineFastState.compose env41828 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound41828 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41829 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1077,1061,40,1125,1077,114,1061,1076,1024,1076,1076,112,16,1079,41,64,1125,65,65,80,1136,113,116,1045,1077,513]

theorem envBound41829 : H12AffineFastState.Bounded env41829 := by
  intro p hp
  have h : env41829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41828_41829 : H12AffineEnvironment.transform 10 1077 env41828 = env41829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env41828 == env41829) = true)

theorem identity41829 : scanCanonicalize (H12AffineFastState.compose env41829 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound41829 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41830 : List Nat := [2,4,8,16,32,64,9,116,512,100,81,65,40,1,81,114,65,80,100,80,80,112,16,83,41,64,1,65,65,80,20,113,116,113,81,513]

theorem envBound41830 : H12AffineFastState.Bounded env41830 := by
  intro p hp
  have h : env41830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41829_41830 : H12AffineEnvironment.transform 9 100 env41829 = env41830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env41829 == env41830) = true)

theorem identity41830 : scanCanonicalize (H12AffineFastState.compose env41830 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41830 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env41831 : List Nat := [2,4,8,16,16,64,9,68,512,84,81,65,24,1,81,66,65,80,84,80,80,64,16,83,25,64,1,65,65,80,20,65,68,65,81,513]

theorem envBound41831 : H12AffineFastState.Bounded env41831 := by
  intro p hp
  have h : env41831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41830_41831 : H12AffineEnvironment.transform 4 16 env41830 = env41831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41830 == env41831) = true)

theorem identity41831 : scanCanonicalize (H12AffineFastState.compose env41831 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41831 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41832 : List Nat := [2,4,8,16,16,64,9,68,1,84,81,65,24,1,81,66,65,80,84,80,80,64,16,83,25,64,1,65,65,80,20,65,68,65,81,0]

theorem envBound41832 : H12AffineFastState.Bounded env41832 := by
  intro p hp
  have h : env41832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41831_41832 : H12AffineEnvironment.transform 8 1 env41831 = env41832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41831 == env41832) = true)

theorem identity41832 : scanCanonicalize (H12AffineFastState.compose env41832 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41833 : List Nat := [2,4,8,16,16,17,9,21,1,5,0,16,24,1,0,19,16,1,5,1,1,17,16,2,25,17,1,16,16,1,20,16,21,16,0,0]

theorem envBound41833 : H12AffineFastState.Bounded env41833 := by
  intro p hp
  have h : env41833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41832_41833 : H12AffineEnvironment.transform 5 17 env41832 = env41833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41832 == env41833) = true)

theorem identity41833 : scanCanonicalize (H12AffineFastState.compose env41833 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41834 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,0,8,1,0,3,0,1,5,1,1,1,0,2,9,1,1,0,0,1,4,0,5,0,0,0]

theorem envBound41834 : H12AffineFastState.Bounded env41834 := by
  intro p hp
  have h : env41834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41833_41834 : H12AffineEnvironment.transform 3 0 env41833 = env41834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41833 == env41834) = true)

def env41835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62661,2188616,8328,64,6705548,57796,2138516,406724,2102685,4194440,256,21792,46213,2175563]

theorem envBound41835 : H12AffineFastState.Bounded env41835 := by
  intro p hp
  have h : env41835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41717_41835 : H12AffineEnvironment.transform 22 62661 env41717 = env41835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env41717 == env41835) = true)

def env41836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373824,62661,2188616,8328,64,158028,57796,2138516,406724,2102685,2373704,256,21792,46213,2175563]

theorem envBound41836 : H12AffineFastState.Bounded env41836 := by
  intro p hp
  have h : env41836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41835_41836 : H12AffineEnvironment.transform 21 2373824 env41835 = env41836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373824 env41835 == env41836) = true)

theorem identity41836 : scanCanonicalize (H12AffineFastState.compose env41836 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound41836 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env41837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329866,62661,21762,8328,64,158028,57796,102878,406724,75223,329730,256,21792,46213,513]

theorem envBound41837 : H12AffineFastState.Bounded env41837 := by
  intro p hp
  have h : env41837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41836_41837 : H12AffineEnvironment.transform 20 77898 env41836 = env41837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env41836 == env41837) = true)

def env41838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329730,62541,21762,8192,64,158028,57676,102742,406604,75103,329730,256,21792,46093,513]

theorem envBound41838 : H12AffineFastState.Bounded env41838 := by
  intro p hp
  have h : env41838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41837_41838 : H12AffineEnvironment.transform 6 8 env41837 = env41838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41837 == env41838) = true)

theorem identity41838 : scanCanonicalize (H12AffineFastState.compose env41838 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound41838 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,77898,329730,62541,21762,8192,64,67926,57676,102742,349270,75103,329730,256,21792,46093,513]

theorem envBound41839 : H12AffineFastState.Bounded env41839 := by
  intro p hp
  have h : env41839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41838_41839 : H12AffineEnvironment.transform 16 90138 env41838 = env41839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env41838 == env41839) = true)

def env41840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,77898,73770,62541,21762,8192,64,67926,57676,102742,97406,75103,73770,256,21792,46093,513]

theorem envBound41840 : H12AffineFastState.Bounded env41840 := by
  intro p hp
  have h : env41840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41839_41840 : H12AffineEnvironment.transform 17 10280 env41839 = env41840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41839 == env41840) = true)

theorem identity41840 : scanCanonicalize (H12AffineFastState.compose env41840 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41840 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,10280,1024,29788,77898,73770,16,21762,8192,64,67926,5393,91403,97406,75103,73770,256,21792,16464,513]

theorem envBound41841 : H12AffineFastState.Bounded env41841 := by
  intro p hp
  have h : env41841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41840_41841 : H12AffineEnvironment.transform 14 29789 env41840 = env41841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41840 == env41841) = true)

theorem identity41841 : scanCanonicalize (H12AffineFastState.compose env41841 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 31791) := by decide +kernel

theorem selectedBound41841 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,31791,7221,10280,1024,29788,19557,23557,16,21762,8192,64,30073,5393,6436,81,22896,23557,256,21792,16464,513]

theorem envBound41842 : H12AffineFastState.Bounded env41842 := by
  intro p hp
  have h : env41842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41841_41842 : H12AffineEnvironment.transform 15 31791 env41841 = env41842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31791 env41841 == env41842) = true)

theorem identity41842 : scanCanonicalize (H12AffineFastState.compose env41842 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41842 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,10543,7221,10280,1024,8540,6501,2309,16,2,8192,64,8313,5393,6436,81,3184,2309,256,32,5456,513]

theorem envBound41843 : H12AffineFastState.Bounded env41843 := by
  intro p hp
  have h : env41843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41842_41843 : H12AffineEnvironment.transform 13 5376 env41842 = env41843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41842 == env41843) = true)

theorem identity41843 : scanCanonicalize (H12AffineFastState.compose env41843 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound41843 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1297,3427,7221,3172,1024,1296,6501,2309,16,2,1100,64,1077,5393,6436,81,3184,2309,256,32,5456,513]

theorem envBound41844 : H12AffineFastState.Bounded env41844 := by
  intro p hp
  have h : env41844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41843_41844 : H12AffineEnvironment.transform 12 1100 env41843 = env41844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env41843 == env41844) = true)

theorem identity41844 : scanCanonicalize (H12AffineFastState.compose env41844 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound41844 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,1100,5376,1297,34,4468,293,1024,1296,5156,1092,16,2,1100,64,1077,5393,5221,81,305,1092,256,32,5456,513]

end H12CloudChart1