import H12CloudChart1Data082

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity20989 : scanCanonicalize (H12AffineFastState.compose env20989 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound20989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20990 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,1,0,3,16,2048,21,1,0,1,17,3,9,16,2049,16,16,2049,20,1,4,0,1,512]

theorem envBound20990 : H12AffineFastState.Bounded env20990 := by
  intro p hp
  have h : env20990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20989_20990 : H12AffineEnvironment.transform 9 20 env20989 = env20990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20989 == env20990) = true)

theorem identity20990 : scanCanonicalize (H12AffineFastState.compose env20990 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound20990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20991 : List Nat := [2,4,8,16,1,17,9,5,512,20,20,16,8,1,0,3,16,20,21,1,0,1,17,3,9,16,21,16,16,21,20,1,4,0,1,512]

theorem envBound20991 : H12AffineFastState.Bounded env20991 := by
  intro p hp
  have h : env20991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20990_20991 : H12AffineEnvironment.transform 10 20 env20990 = env20991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env20990 == env20991) = true)

def leafEnv20991 : List Nat := [2,4,8,16,1,17,9,5,512,20,20,16,8,1,0,3,16,20,21,1,0,1,17,3,21,9,1,16,21,16,16,21,20,1,4,0,5,2,1,512,1,0,0]

def active20991 : List Nat := [0,1,2,3,8]

def tree20991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20991 : H12WitnessSearch.Good tree20991 := H12GlobalWitnessIndex.good

theorem leafIdentity20991 : H12AffineFastState.composeSystem env20991 rootObs = leafEnv20991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20991 rootObs == leafEnv20991) = true)

theorem terminalChecked20991 : H12PackedTerminal.terminalCheckFast leafEnv20991 active20991 tree20991 = true := by decide +kernel

def env20992 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1044,0,3,1029,2048,1025,1,1,1,17,3,9,16,2049,1029,17,2049,1024,1,4,0,1044,512]

theorem envBound20992 : H12AffineFastState.Bounded env20992 := by
  intro p hp
  have h : env20992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20988_20992 : H12AffineEnvironment.transform 11 17 env20988 = env20992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20988 == env20992) = true)

def env20993 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,0,3,17,2048,21,1,1,1,17,3,9,16,2049,17,17,2049,20,1,4,0,0,512]

theorem envBound20993 : H12AffineFastState.Bounded env20993 := by
  intro p hp
  have h : env20993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20992_20993 : H12AffineEnvironment.transform 9 20 env20992 = env20993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20992 == env20993) = true)

theorem identity20993 : scanCanonicalize (H12AffineFastState.compose env20993 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound20993 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20994 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,17,8,0,0,3,17,21,21,1,1,1,17,3,9,16,20,17,17,20,20,1,4,0,0,512]

theorem envBound20994 : H12AffineFastState.Bounded env20994 := by
  intro p hp
  have h : env20994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20993_20994 : H12AffineEnvironment.transform 10 21 env20993 = env20994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env20993 == env20994) = true)

def leafEnv20994 : List Nat := [2,4,8,16,1,17,9,5,512,20,21,17,8,0,0,3,17,21,21,1,1,1,17,3,21,9,1,16,20,17,17,20,20,1,4,0,5,2,0,512,1,1,0]

def active20994 : List Nat := [0,1,2,3,8]

def tree20994 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20994 : H12WitnessSearch.Good tree20994 := H12GlobalWitnessIndex.good

theorem leafIdentity20994 : H12AffineFastState.composeSystem env20994 rootObs = leafEnv20994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20994 rootObs == leafEnv20994) = true)

theorem terminalChecked20994 : H12PackedTerminal.terminalCheckFast leafEnv20994 active20994 tree20994 = true := by decide +kernel

def env20995 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,1,0,3,16,2048,20,1,1,1,17,3,9,16,2049,16,17,2049,21,1,4,0,1,512]

theorem envBound20995 : H12AffineFastState.Bounded env20995 := by
  intro p hp
  have h : env20995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20992_20995 : H12AffineEnvironment.transform 9 21 env20992 = env20995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20992 == env20995) = true)

theorem identity20995 : scanCanonicalize (H12AffineFastState.compose env20995 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound20995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20996 : List Nat := [2,4,8,16,1,17,9,5,512,21,543,17,8,1,0,3,16,543,20,1,1,1,17,3,9,16,542,16,17,542,21,1,4,0,1,512]

theorem envBound20996 : H12AffineFastState.Bounded env20996 := by
  intro p hp
  have h : env20996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20995_20996 : H12AffineEnvironment.transform 10 543 env20995 = env20996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env20995 == env20996) = true)

def leafEnv20996 : List Nat := [2,4,8,16,1,17,9,5,512,21,543,17,8,1,0,3,16,543,20,1,1,1,17,3,20,9,1,16,542,16,17,542,21,1,4,0,5,2,1,512,1,1,0]

def active20996 : List Nat := [0,1,2,3,8]

def tree20996 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20996 : H12WitnessSearch.Good tree20996 := H12GlobalWitnessIndex.good

theorem leafIdentity20996 : H12AffineFastState.composeSystem env20996 rootObs = leafEnv20996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20996 rootObs == leafEnv20996) = true)

theorem terminalChecked20996 : H12PackedTerminal.terminalCheckFast leafEnv20996 active20996 tree20996 = true := by decide +kernel

def env20997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,98645,8193,65,4229153,2098513,2233681,2421,148805,6349852,257,2229617,2286685,221722]

theorem envBound20997 : H12AffineFastState.Bounded env20997 := by
  intro p hp
  have h : env20997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20964_20997 : H12AffineEnvironment.transform 22 147457 env20964 = env20997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env20964 == env20997) = true)

theorem identity20997 : scanCanonicalize (H12AffineFastState.compose env20997 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound20997 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,73754,98645,8193,65,4229153,2098513,2192714,2421,75102,6349852,257,2188650,2196550,513]

theorem envBound20998 : H12AffineFastState.Bounded env20998 := by
  intro p hp
  have h : env20998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20997_20998 : H12AffineEnvironment.transform 16 90139 env20997 = env20998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env20997 == env20998) = true)

theorem identity20998 : scanCanonicalize (H12AffineFastState.compose env20998 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound20998 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env20999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,98679,73754,98645,8193,65,67926,2098513,2192714,2421,75102,2188651,257,2188650,2196550,513]

theorem envBound20999 : H12AffineFastState.Bounded env20999 := by
  intro p hp
  have h : env20999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20998_20999 : H12AffineEnvironment.transform 21 98679 env20998 = env20999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env20998 == env20999) = true)

theorem identity20999 : scanCanonicalize (H12AffineFastState.compose env20999 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(20+1) ^^^ 38145) := by decide +kernel

theorem selectedBound20999 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env21000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,38145,98679,73754,98645,8193,65,67926,36944,122955,2421,75102,127082,257,127083,69959,513]

theorem envBound21000 : H12AffineFastState.Bounded env21000 := by
  intro p hp
  have h : env21000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20999_21000 : H12AffineEnvironment.transform 20 38145 env20999 = env21000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38145 env20999 == env21000) = true)

theorem identity21000 : scanCanonicalize (H12AffineFastState.compose env21000 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21000 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env21001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1025,8540,13404,73770,73754,73736,8193,65,67926,12557,82198,2421,75102,86327,257,86326,69959,513]

theorem envBound21001 : H12AffineFastState.Bounded env21001 := by
  intro p hp
  have h : env21001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21000_21001 : H12AffineEnvironment.transform 14 8541 env21000 = env21001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21000 == env21001) = true)

theorem identity21001 : scanCanonicalize (H12AffineFastState.compose env21001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound21001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,263,24860,10280,1025,8540,13404,8493,8477,8463,8193,65,2129,12557,16401,2421,9305,20528,257,20529,4160,513]

theorem envBound21002 : H12AffineFastState.Bounded env21002 := by
  intro p hp
  have h : env21002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21001_21002 : H12AffineEnvironment.transform 15 263 env21001 = env21002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env21001 == env21002) = true)

theorem identity21002 : scanCanonicalize (H12AffineFastState.compose env21002 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound21002 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env21003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,263,13672,10280,1025,8540,13404,8493,8477,8463,8193,65,2129,12557,5221,2421,9305,1092,257,1093,4160,513]

theorem envBound21003 : H12AffineFastState.Bounded env21003 := by
  intro p hp
  have h : env21003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21002_21003 : H12AffineEnvironment.transform 13 5236 env21002 = env21003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env21002 == env21003) = true)

theorem identity21003 : scanCanonicalize (H12AffineFastState.compose env21003 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound21003 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env21004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7544,5236,7205,263,2064,5456,1025,7204,2340,7253,7269,7287,7545,65,2129,3189,5221,2421,6433,1092,257,1093,4160,513]

theorem envBound21004 : H12AffineFastState.Bounded env21004 := by
  intro p hp
  have h : env21004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21003_21004 : H12AffineEnvironment.transform 12 7544 env21003 = env21004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env21003 == env21004) = true)

theorem identity21004 : scanCanonicalize (H12AffineFastState.compose env21004 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound21004 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,268,2048,81,263,2064,2340,1025,80,2340,33,17,3,269,65,2129,3189,2065,2421,1365,1092,257,1093,3124,513]

theorem envBound21005 : H12AffineFastState.Bounded env21005 := by
  intro p hp
  have h : env21005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21004_21005 : H12AffineEnvironment.transform 11 3188 env21004 = env21005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env21004 == env21005) = true)

theorem identity21005 : scanCanonicalize (H12AffineFastState.compose env21005 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21005 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21006 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,268,2048,1,263,2064,2340,1025,0,2340,33,17,3,269,17,2049,3109,2065,2341,1285,1044,257,1045,3124,513]

theorem envBound21006 : H12AffineFastState.Bounded env21006 := by
  intro p hp
  have h : env21006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21005_21006 : H12AffineEnvironment.transform 5 16 env21005 = env21006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21005 == env21006) = true)

def env21007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,536870912,1073741824,92374096,4294967296,525568,4308116845,620851224,25733062]

theorem envBound21007 : H12AffineFastState.Bounded env21007 := by
  intro p hp
  have h : env21007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9915_21007 : H12AffineEnvironment.transform 27 19497101 env9915 = env21007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497101 env9915 == env21007) = true)

def env21008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,4294967296,525568,4308116845,27337992,25733062]

theorem envBound21008 : H12AffineFastState.Bounded env21008 := by
  intro p hp
  have h : env21008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21007_21008 : H12AffineEnvironment.transform 28 77616400 env21007 = env21008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env21007 == env21008) = true)

def env21009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound21009 : H12AffineFastState.Bounded env21009 := by
  intro p hp
  have h : env21009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21008_21009 : H12AffineEnvironment.transform 31 145662400 env21008 = env21009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env21008 == env21009) = true)

def env21010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound21010 : H12AffineFastState.Bounded env21010 := by
  intro p hp
  have h : env21010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21009_21010 : H12AffineEnvironment.transform 29 155254784 env21009 = env21010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env21009 == env21010) = true)

def env21011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound21011 : H12AffineFastState.Bounded env21011 := by
  intro p hp
  have h : env21011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21010_21011 : H12AffineEnvironment.transform 25 64 env21010 = env21011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env21010 == env21011) = true)

def env21012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound21012 : H12AffineFastState.Bounded env21012 := by
  intro p hp
  have h : env21012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21011_21012 : H12AffineEnvironment.transform 26 30393344 env21011 = env21012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env21011 == env21012) = true)

def env21013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound21013 : H12AffineFastState.Bounded env21013 := by
  intro p hp
  have h : env21013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21012_21013 : H12AffineEnvironment.transform 18 1024 env21012 = env21013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21012 == env21013) = true)

theorem identity21013 : scanCanonicalize (H12AffineFastState.compose env21013 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2212871) := by decide +kernel

theorem selectedBound21013 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2212871,16777216,8328,64,23462919,18973837,102743,2556935,18890775,23160256,256,16777386,16834831,18966465]

theorem envBound21014 : H12AffineFastState.Bounded env21014 := by
  intro p hp
  have h : env21014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21013_21014 : H12AffineEnvironment.transform 22 2212871 env21013 = env21014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2212871 env21013 == env21014) = true)

def env21015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8328,64,17227835,18973837,102743,2556935,18890775,16876028,256,16777386,16834831,18966465]

theorem envBound21015 : H12AffineFastState.Bounded env21015 := by
  intro p hp
  have h : env21015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21014_21015 : H12AffineEnvironment.transform 21 2155580 env21014 = env21015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env21014 == env21015) = true)

def env21016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8192,64,17227835,18973701,102743,2556935,18890775,16875892,256,16777250,16834831,18966345]

theorem envBound21016 : H12AffineFastState.Bounded env21016 := by
  intro p hp
  have h : env21016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21015_21016 : H12AffineEnvironment.transform 6 8 env21015 = env21016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21015 == env21016) = true)

theorem identity21016 : scanCanonicalize (H12AffineFastState.compose env21016 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound21016 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,2188616,8192,64,2590067,57677,102743,2556935,75103,2155580,256,2188650,2196551,513]

theorem envBound21017 : H12AffineFastState.Bounded env21017 := by
  intro p hp
  have h : env21017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21016_21017 : H12AffineEnvironment.transform 23 2188616 env21016 = env21017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env21016 == env21017) = true)

def env21018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,2155580,2212871,2188616,8192,64,2338139,57677,102743,2305071,75103,2155580,256,2188650,2196551,513]

theorem envBound21018 : H12AffineFastState.Bounded env21018 := by
  intro p hp
  have h : env21018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21017_21018 : H12AffineEnvironment.transform 17 10280 env21017 = env21018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21017 == env21018) = true)

theorem identity21018 : scanCanonicalize (H12AffineFastState.compose env21018 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound21018 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env21019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,2155580,2212871,2188616,8192,64,2182167,57677,102743,2215267,75103,2155580,256,2188650,2196551,513]

theorem envBound21019 : H12AffineFastState.Bounded env21019 := by
  intro p hp
  have h : env21019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21018_21019 : H12AffineEnvironment.transform 16 57676 env21018 = env21019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env21018 == env21019) = true)

theorem identity21019 : scanCanonicalize (H12AffineFastState.compose env21019 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound21019 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,124186,65830,8477,32850,8192,64,43277,57677,102743,10361,75103,65830,256,32880,24925,513]

theorem envBound21020 : H12AffineFastState.Bounded env21020 := by
  intro p hp
  have h : env21020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21019_21020 : H12AffineEnvironment.transform 20 124186 env21019 = env21020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env21019 == env21020) = true)

theorem identity21020 : scanCanonicalize (H12AffineFastState.compose env21020 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21020 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env21021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57676,10280,1024,32769,58445,113,8477,32850,8192,64,43277,57677,36864,10361,9224,113,256,32880,24925,513]

theorem envBound21021 : H12AffineFastState.Bounded env21021 := by
  intro p hp
  have h : env21021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21020_21021 : H12AffineEnvironment.transform 15 343 env21020 = env21021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21020 == env21021) = true)

theorem identity21021 : scanCanonicalize (H12AffineFastState.compose env21021 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21021 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,343,49216,2340,1024,32769,50497,113,17,32850,268,64,34817,49217,36864,2421,1284,113,256,32880,16465,513]

theorem envBound21022 : H12AffineFastState.Bounded env21022 := by
  intro p hp
  have h : env21022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21021_21022 : H12AffineEnvironment.transform 12 268 env21021 = env21022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21021 == env21022) = true)

def env21023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,2155580,2212871,2188616,8192,64,2338138,57677,102743,2305070,75103,2155580,256,2188650,2196551,513]

theorem envBound21023 : H12AffineFastState.Bounded env21023 := by
  intro p hp
  have h : env21023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21017_21023 : H12AffineEnvironment.transform 17 10281 env21017 = env21023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21017 == env21023) = true)

theorem identity21023 : scanCanonicalize (H12AffineFastState.compose env21023 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21023 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,2097152,2155580,2212871,2188616,8192,64,2149696,57677,102743,2116660,75103,2155580,256,2188650,2196551,513]

theorem envBound21024 : H12AffineFastState.Bounded env21024 := by
  intro p hp
  have h : env21024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21023_21024 : H12AffineEnvironment.transform 16 90138 env21023 = env21024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21023 == env21024) = true)

theorem identity21024 : scanCanonicalize (H12AffineFastState.compose env21024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 46093) := by decide +kernel

theorem selectedBound21024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,46093,20529,94218,119109,8192,64,31053,57677,102743,63545,75103,20529,256,119143,77898,513]

theorem envBound21025 : H12AffineFastState.Bounded env21025 := by
  intro p hp
  have h : env21025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21024_21025 : H12AffineEnvironment.transform 20 46093 env21024 = env21025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46093 env21024 == env21025) = true)

theorem identity21025 : scanCanonicalize (H12AffineFastState.compose env21025 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound21025 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,46093,20529,16,41311,8192,64,31053,57677,57677,63545,21829,20529,256,41341,16464,513]

theorem envBound21026 : H12AffineFastState.Bounded env21026 := by
  intro p hp
  have h : env21026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21025_21026 : H12AffineEnvironment.transform 15 28698 env21025 = env21026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env21025 == env21026) = true)

theorem identity21026 : scanCanonicalize (H12AffineFastState.compose env21026 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound21026 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,16384,32768,17430,4096,7205,1024,32769,32769,20529,16,38227,5132,64,19777,54593,54593,52277,21829,20529,256,38257,16464,513]

theorem envBound21027 : H12AffineFastState.Bounded env21027 := by
  intro p hp
  have h : env21027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21026_21027 : H12AffineEnvironment.transform 12 5132 env21026 = env21027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env21026 == env21027) = true)

theorem identity21027 : scanCanonicalize (H12AffineFastState.compose env21027 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound21027 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env21028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,1077,32768,35,4096,7205,1024,32769,32769,5124,16,38227,5132,64,2420,37236,37236,34816,4464,5124,256,38257,1125,513]

theorem envBound21028 : H12AffineFastState.Bounded env21028 := by
  intro p hp
  have h : env21028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21027_21028 : H12AffineEnvironment.transform 13 1077 env21027 = env21028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env21027 == env21028) = true)

theorem identity21028 : scanCanonicalize (H12AffineFastState.compose env21028 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 5156) := by decide +kernel

theorem selectedBound21028 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env21029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,1077,5156,35,4096,7205,1024,5157,5157,5124,16,375,5132,64,2420,1360,1360,7204,4464,5124,256,341,1125,513]

theorem envBound21029 : H12AffineFastState.Bounded env21029 := by
  intro p hp
  have h : env21029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21028_21029 : H12AffineEnvironment.transform 14 5156 env21028 = env21029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5156 env21028 == env21029) = true)

theorem identity21029 : scanCanonicalize (H12AffineFastState.compose env21029 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21029 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env21030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,5132,1077,5156,35,4096,4404,1024,5157,5157,5124,16,375,5132,64,1125,1360,1360,4405,4464,5124,256,341,1125,513]

theorem envBound21030 : H12AffineFastState.Bounded env21030 := by
  intro p hp
  have h : env21030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21029_21030 : H12AffineEnvironment.transform 10 1297 env21029 = env21030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env21029 == env21030) = true)

theorem identity21030 : scanCanonicalize (H12AffineFastState.compose env21030 (packedSelected [0,1,2,4,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21030 : packedSelected [0,1,2,4,8,11,14] rootPS < 2^1333 := by decide +kernel

def env21031 : List Nat := [2,4,8,16,32,64,8,256,512,52,293,4096,4152,1,4112,35,4096,4404,52,4113,4113,4144,16,375,4152,64,81,356,356,4405,4464,4144,256,341,81,513]

theorem envBound21031 : H12AffineFastState.Bounded env21031 := by
  intro p hp
  have h : env21031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21030_21031 : H12AffineEnvironment.transform 9 52 env21030 = env21031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21030 == env21031) = true)

theorem identity21031 : scanCanonicalize (H12AffineFastState.compose env21031 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21031 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21032 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,4096,4152,1,4112,35,4096,4112,52,4113,4113,4144,16,83,4152,64,81,64,64,4113,4180,4144,36,113,81,513]

theorem envBound21032 : H12AffineFastState.Bounded env21032 := by
  intro p hp
  have h : env21032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21031_21032 : H12AffineEnvironment.transform 7 36 env21031 = env21032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21031 == env21032) = true)

theorem identity21032 : scanCanonicalize (H12AffineFastState.compose env21032 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound21032 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21033 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,64,120,1,80,35,64,80,52,81,81,112,16,83,120,64,81,64,64,81,20,112,36,113,81,513]

theorem envBound21033 : H12AffineFastState.Bounded env21033 := by
  intro p hp
  have h : env21033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21032_21033 : H12AffineEnvironment.transform 11 64 env21032 = env21033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env21032 == env21033) = true)

theorem identity21033 : scanCanonicalize (H12AffineFastState.compose env21033 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound21033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21034 : List Nat := [2,4,8,16,32,64,8,36,112,52,1,64,120,1,80,35,64,80,52,81,81,112,16,83,120,64,81,64,64,81,20,112,36,113,81,113]

theorem envBound21034 : H12AffineFastState.Bounded env21034 := by
  intro p hp
  have h : env21034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21033_21034 : H12AffineEnvironment.transform 8 112 env21033 = env21034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env21033 == env21034) = true)

theorem identity21034 : scanCanonicalize (H12AffineFastState.compose env21034 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21035 : List Nat := [2,4,8,16,32,16,8,36,32,52,1,16,40,1,0,35,16,0,52,1,1,32,16,3,40,16,1,16,16,1,20,32,36,33,1,33]

theorem envBound21035 : H12AffineFastState.Bounded env21035 := by
  intro p hp
  have h : env21035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21034_21035 : H12AffineEnvironment.transform 5 16 env21034 = env21035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21034 == env21035) = true)

def env21036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8193,64,17227835,18973700,102743,2556935,18890775,16875893,256,16777251,16834831,18966344]

theorem envBound21036 : H12AffineFastState.Bounded env21036 := by
  intro p hp
  have h : env21036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21015_21036 : H12AffineEnvironment.transform 6 9 env21015 = env21036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21015 == env21036) = true)

theorem identity21036 : scanCanonicalize (H12AffineFastState.compose env21036 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 206171) := by decide +kernel

theorem selectedBound21036 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246119,188764,16777216,8193,64,17227835,16949599,102743,270684,16999756,16875893,256,16777251,16834831,16925203]

theorem envBound21037 : H12AffineFastState.Bounded env21037 := by
  intro p hp
  have h : env21037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21036_21037 : H12AffineEnvironment.transform 20 206171 env21036 = env21037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206171 env21036 == env21037) = true)

def env21038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246119,188764,95496,8193,64,496947,250967,102743,270684,135236,62589,256,95531,103431,210715]

theorem envBound21038 : H12AffineFastState.Bounded env21038 := by
  intro p hp
  have h : env21038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21037_21038 : H12AffineEnvironment.transform 23 95496 env21037 = env21038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env21037 == env21038) = true)

theorem identity21038 : scanCanonicalize (H12AffineFastState.compose env21038 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21038 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,206171,234599,177244,73736,8193,64,496947,229719,102743,270684,135236,41341,256,73771,103431,210715]

theorem envBound21039 : H12AffineFastState.Bounded env21039 := by
  intro p hp
  have h : env21039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21038_21039 : H12AffineEnvironment.transform 13 5376 env21038 = env21039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21038 == env21039) = true)

theorem identity21039 : scanCanonicalize (H12AffineFastState.compose env21039 (packedSelected [0,1,3,5,8,9,10,11,12,14,15,18,19,21,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound21039 : packedSelected [0,1,3,5,8,9,10,11,12,14,15,18,19,21,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,262144,1024,32769,45340,32,73755,73736,8193,64,262516,5392,102743,270684,99331,41341,256,73771,103431,41820]

theorem envBound21040 : H12AffineFastState.Bounded env21040 := by
  intro p hp
  have h : env21040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21039_21040 : H12AffineEnvironment.transform 16 103495 env21039 = env21040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env21039 == env21040) = true)

theorem identity21040 : scanCanonicalize (H12AffineFastState.compose env21040 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound21040 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env21041 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103495,67619,1024,32769,45340,32,73755,73736,8193,64,67927,5392,102743,76159,99331,41341,256,73771,103431,41820]

theorem envBound21041 : H12AffineFastState.Bounded env21041 := by
  intro p hp
  have h : env21041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21040_21041 : H12AffineEnvironment.transform 17 67619 env21040 = env21041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env21040 == env21041) = true)

theorem identity21041 : scanCanonicalize (H12AffineFastState.compose env21041 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound21041 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env21042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,32802,5221,34817,1024,32769,45340,32,41017,41002,8193,64,35189,5392,4469,43357,1057,41341,256,40969,5157,41820]

theorem envBound21042 : H12AffineFastState.Bounded env21042 := by
  intro p hp
  have h : env21042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21041_21042 : H12AffineEnvironment.transform 15 32802 env21041 = env21042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env21041 == env21042) = true)

theorem identity21042 : scanCanonicalize (H12AffineFastState.compose env21042 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21042 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env21043 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,32768,32802,5221,34817,1024,32769,45160,32,41017,41002,8193,64,34817,5220,4097,43049,1057,40969,116,40969,5157,41512]

theorem envBound21043 : H12AffineFastState.Bounded env21043 := by
  intro p hp
  have h : env21043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21042_21043 : H12AffineEnvironment.transform 7 116 env21042 = env21043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21042 == env21043) = true)

theorem identity21043 : scanCanonicalize (H12AffineFastState.compose env21043 (packedSelected [0,2,3,6,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound21043 : packedSelected [0,2,3,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21044 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,32768,32802,5221,34817,1024,32769,36881,32,32832,32851,120,64,34817,5220,4097,34896,1057,32880,116,32880,5157,33361]

theorem envBound21044 : H12AffineFastState.Bounded env21044 := by
  intro p hp
  have h : env21044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21043_21044 : H12AffineEnvironment.transform 12 121 env21043 = env21044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env21043 == env21044) = true)

theorem identity21044 : scanCanonicalize (H12AffineFastState.compose env21044 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound21044 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env21045 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,1124,1094,5221,3173,1024,1125,5237,32,1060,1079,120,64,3173,5220,4097,3124,1057,1044,116,1044,5157,1589]

theorem envBound21045 : H12AffineFastState.Bounded env21045 := by
  intro p hp
  have h : env21045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21044_21045 : H12AffineEnvironment.transform 14 1124 env21044 = env21045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env21044 == env21045) = true)

def env21046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,206171,246119,188764,95497,8193,64,496946,250966,102743,270684,135237,62588,256,95530,103430,210714]

theorem envBound21046 : H12AffineFastState.Bounded env21046 := by
  intro p hp
  have h : env21046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21037_21046 : H12AffineEnvironment.transform 23 95497 env21037 = env21046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env21037 == env21046) = true)

theorem identity21046 : scanCanonicalize (H12AffineFastState.compose env21046 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21046 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,17729,41341,98630,95497,8193,64,324904,46156,102743,270684,94303,62588,256,95530,103430,22272]

theorem envBound21047 : H12AffineFastState.Bounded env21047 := by
  intro p hp
  have h : env21047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21046_21047 : H12AffineEnvironment.transform 16 90138 env21046 = env21047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21046 == env21047) = true)

theorem identity21047 : scanCanonicalize (H12AffineFastState.compose env21047 (packedSelected [0,3,4,7,10,11,12,15,16,18,20,21,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21047 : packedSelected [0,3,4,7,10,11,12,15,16,18,20,21,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env21048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,262144,1024,8540,17729,32,73755,95497,8193,64,283765,5393,77834,270684,94303,21793,256,95530,79195,22272]

theorem envBound21048 : H12AffineFastState.Bounded env21048 := by
  intro p hp
  have h : env21048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21047_21048 : H12AffineEnvironment.transform 14 8541 env21047 = env21048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21047 == env21048) = true)

theorem identity21048 : scanCanonicalize (H12AffineFastState.compose env21048 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21048 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env21049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79131,262144,1024,8540,4160,32,73755,73736,8193,64,262516,5393,77834,270684,75102,32,256,73771,79195,513]

theorem envBound21049 : H12AffineFastState.Bounded env21049 := by
  intro p hp
  have h : env21049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21048_21049 : H12AffineEnvironment.transform 13 5377 env21048 = env21049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21048 == env21049) = true)

theorem identity21049 : scanCanonicalize (H12AffineFastState.compose env21049 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 75867) := by decide +kernel

theorem selectedBound21049 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79131,75867,1024,8540,4160,32,73755,73736,8193,64,76079,5393,77834,67847,75102,32,256,73771,79195,513]

theorem envBound21050 : H12AffineFastState.Bounded env21050 := by
  intro p hp
  have h : env21050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21049_21050 : H12AffineEnvironment.transform 17 75867 env21049 = env21050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75867 env21049 == env21050) = true)

theorem identity21050 : scanCanonicalize (H12AffineFastState.compose env21050 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21050 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21051 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8541,65536,77834,75867,273,8540,4160,32,73755,73736,8193,64,76079,4096,77834,67847,73807,32,256,73771,77898,513]

theorem envBound21051 : H12AffineFastState.Bounded env21051 := by
  intro p hp
  have h : env21051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21050_21051 : H12AffineEnvironment.transform 9 273 env21050 = env21051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21050 == env21051) = true)

theorem identity21051 : scanCanonicalize (H12AffineFastState.compose env21051 (packedSelected [0,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound21051 : packedSelected [0,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21052 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2405,8192,2421,8541,65536,76143,75867,273,8540,2341,32,73755,73736,8193,64,76079,2405,76143,67847,73807,32,256,73771,76079,513]

theorem envBound21052 : H12AffineFastState.Bounded env21052 := by
  intro p hp
  have h : env21052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21051_21052 : H12AffineEnvironment.transform 11 2405 env21051 = env21052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env21051 == env21052) = true)

theorem identity21052 : scanCanonicalize (H12AffineFastState.compose env21052 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound21052 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env21053 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,8192,292,8541,65536,74046,73738,273,8540,372,32,73755,73736,8193,64,74110,308,74046,65878,73807,32,256,73771,74110,513]

theorem envBound21053 : H12AffineFastState.Bounded env21053 := by
  intro p hp
  have h : env21053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21052_21053 : H12AffineEnvironment.transform 10 81 env21052 = env21053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env21052 == env21053) = true)

theorem identity21053 : scanCanonicalize (H12AffineFastState.compose env21053 (packedSelected [0,2,3,6,7,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21053 : packedSelected [0,2,3,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env21054 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,8192,292,8541,262,8248,8460,273,8540,372,32,8477,8462,8193,64,8312,308,8248,80,8521,32,256,8493,8312,513]

theorem envBound21054 : H12AffineFastState.Bounded env21054 := by
  intro p hp
  have h : env21054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21053_21054 : H12AffineEnvironment.transform 15 262 env21053 = env21054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21053 == env21054) = true)

theorem identity21054 : scanCanonicalize (H12AffineFastState.compose env21054 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21054 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env21055 : List Nat := [2,4,8,16,32,64,9,256,512,273,81,308,348,292,1,262,356,80,273,0,372,32,65,82,349,64,292,308,356,80,21,32,256,113,292,513]

theorem envBound21055 : H12AffineFastState.Bounded env21055 := by
  intro p hp
  have h : env21055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21054_21055 : H12AffineEnvironment.transform 12 348 env21054 = env21055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21054 == env21055) = true)

theorem identity21055 : scanCanonicalize (H12AffineFastState.compose env21055 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21055 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21056 : List Nat := [2,4,8,16,32,64,9,37,512,52,81,17,121,1,1,35,65,80,52,0,81,32,65,82,120,64,1,17,65,80,21,32,37,113,1,513]

theorem envBound21056 : H12AffineFastState.Bounded env21056 := by
  intro p hp
  have h : env21056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21055_21056 : H12AffineEnvironment.transform 7 37 env21055 = env21056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21055 == env21056) = true)

theorem identity21056 : scanCanonicalize (H12AffineFastState.compose env21056 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21057 : List Nat := [2,4,8,16,32,48,9,37,512,52,33,17,9,1,1,35,49,32,52,0,33,32,49,34,8,48,1,17,49,32,21,32,37,1,1,513]

theorem envBound21057 : H12AffineFastState.Bounded env21057 := by
  intro p hp
  have h : env21057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21056_21057 : H12AffineEnvironment.transform 5 48 env21056 = env21057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21056 == env21057) = true)

theorem identity21057 : scanCanonicalize (H12AffineFastState.compose env21057 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21057 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21058 : List Nat := [2,4,8,16,1,17,9,4,512,21,0,17,9,1,1,2,16,1,21,0,0,1,16,3,8,17,1,17,16,1,21,1,4,1,1,513]

theorem envBound21058 : H12AffineFastState.Bounded env21058 := by
  intro p hp
  have h : env21058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21057_21058 : H12AffineEnvironment.transform 4 1 env21057 = env21058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21057 == env21058) = true)

theorem identity21058 : scanCanonicalize (H12AffineFastState.compose env21058 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21059 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,17,9,1,1,2,16,1,21,0,0,1,16,3,8,17,1,17,16,1,21,1,4,1,1,0]

theorem envBound21059 : H12AffineFastState.Bounded env21059 := by
  intro p hp
  have h : env21059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21058_21059 : H12AffineEnvironment.transform 8 1 env21058 = env21059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21058 == env21059) = true)

theorem identity21059 : scanCanonicalize (H12AffineFastState.compose env21059 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21060 : List Nat := [2,4,8,10,1,11,9,4,1,15,0,11,9,1,1,2,10,1,15,0,0,1,10,3,8,11,1,11,10,1,15,1,4,1,1,0]

theorem envBound21060 : H12AffineFastState.Bounded env21060 := by
  intro p hp
  have h : env21060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21059_21060 : H12AffineEnvironment.transform 3 10 env21059 = env21060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21059 == env21060) = true)

theorem identity21060 : scanCanonicalize (H12AffineFastState.compose env21060 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21060 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21061 : List Nat := [2,4,3,1,1,0,2,4,1,4,0,0,2,1,1,2,1,1,4,0,0,1,1,3,3,0,1,0,1,1,4,1,4,1,1,0]

theorem envBound21061 : H12AffineFastState.Bounded env21061 := by
  intro p hp
  have h : env21061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21060_21061 : H12AffineEnvironment.transform 2 3 env21060 = env21061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21060 == env21061) = true)

def env21062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8328,64,17227834,18973837,102743,2556935,18890775,16876029,256,16777386,16834831,18966465]

theorem envBound21062 : H12AffineFastState.Bounded env21062 := by
  intro p hp
  have h : env21062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21014_21062 : H12AffineEnvironment.transform 21 2155581 env21014 = env21062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env21014 == env21062) = true)

def env21063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8192,64,17227834,18973701,102743,2556935,18890775,16875893,256,16777250,16834831,18966345]

theorem envBound21063 : H12AffineFastState.Bounded env21063 := by
  intro p hp
  have h : env21063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21062_21063 : H12AffineEnvironment.transform 6 8 env21062 = env21063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21062 == env21063) = true)

theorem identity21063 : scanCanonicalize (H12AffineFastState.compose env21063 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound21063 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,41311,8192,64,409957,2172250,102743,2556935,2154824,73770,256,41341,16464,2213398]

theorem envBound21064 : H12AffineFastState.Bounded env21064 := by
  intro p hp
  have h : env21064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21063_21064 : H12AffineEnvironment.transform 23 41311 env21063 = env21064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env21063 == env21064) = true)

def env21065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62589,119879,41311,8192,64,409957,79130,102743,463943,61704,73770,256,41341,16464,120406]

theorem envBound21065 : H12AffineFastState.Bounded env21065 := by
  intro p hp
  have h : env21065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21064_21065 : H12AffineEnvironment.transform 20 4160 env21064 = env21065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21064 == env21065) = true)

theorem identity21065 : scanCanonicalize (H12AffineFastState.compose env21065 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound21065 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,62589,16,41311,8192,64,409957,57677,17664,442384,61704,62589,256,41341,16464,513]

theorem envBound21066 : H12AffineFastState.Bounded env21066 := by
  intro p hp
  have h : env21066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21065_21066 : H12AffineEnvironment.transform 15 54359 env21065 = env21066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env21065 == env21066) = true)

def env21067 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,62509,16,41231,8192,16,409909,57629,17664,442384,61704,62509,256,41261,16384,513]

theorem envBound21067 : H12AffineFastState.Bounded env21067 := by
  intro p hp
  have h : env21067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21066_21067 : H12AffineEnvironment.transform 5 16 env21066 = env21067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21066 == env21067) = true)

theorem identity21067 : scanCanonicalize (H12AffineFastState.compose env21067 (packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound21067 : packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env21068 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,262144,1024,32769,4112,62509,16,41231,8192,16,316453,57629,17664,283904,61704,62509,256,41261,16384,513]

theorem envBound21068 : H12AffineFastState.Bounded env21068 := by
  intro p hp
  have h : env21068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21067_21068 : H12AffineEnvironment.transform 16 38160 env21067 = env21068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21067 == env21068) = true)

theorem identity21068 : scanCanonicalize (H12AffineFastState.compose env21068 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21068 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21069 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,10280,1024,32769,4112,62509,16,41231,8192,16,64525,57629,17664,32040,61704,62509,256,41261,16384,513]

theorem envBound21069 : H12AffineFastState.Bounded env21069 := by
  intro p hp
  have h : env21069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21068_21069 : H12AffineEnvironment.transform 17 10280 env21068 = env21069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21068 == env21069) = true)

theorem identity21069 : scanCanonicalize (H12AffineFastState.compose env21069 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound21069 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env21070 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,29963,13340,10280,1024,8461,4112,21793,16,3,8192,16,23809,16401,17664,32040,20484,21793,256,33,16384,513]

theorem envBound21070 : H12AffineFastState.Bounded env21070 := by
  intro p hp
  have h : env21070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21069_21070 : H12AffineEnvironment.transform 14 8460 env21069 = env21070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env21069 == env21070) = true)

theorem identity21070 : scanCanonicalize (H12AffineFastState.compose env21070 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21070 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21071 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10280,1024,8461,4112,32,16,3,8192,16,2048,5392,4097,10281,1285,32,256,33,5377,513]

theorem envBound21071 : H12AffineFastState.Bounded env21071 := by
  intro p hp
  have h : env21071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21070_21071 : H12AffineEnvironment.transform 13 5377 env21070 = env21071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21070 == env21071) = true)

theorem identity21071 : scanCanonicalize (H12AffineFastState.compose env21071 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21071 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4112,32,16,3,269,16,2048,5392,4097,2340,1285,32,256,33,5377,513]

theorem envBound21072 : H12AffineFastState.Bounded env21072 := by
  intro p hp
  have h : env21072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21071_21072 : H12AffineEnvironment.transform 12 269 env21071 = env21072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21071 == env21072) = true)

theorem identity21072 : scanCanonicalize (H12AffineFastState.compose env21072 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound21072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21073 : List Nat := [2,4,8,16,32,16,8,256,512,36,2048,4096,269,4389,1,263,4405,2341,36,0,4112,32,16,3,269,16,2048,4404,4097,2340,289,32,256,33,4389,513]

theorem envBound21073 : H12AffineFastState.Bounded env21073 := by
  intro p hp
  have h : env21073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21072_21073 : H12AffineEnvironment.transform 9 36 env21072 = env21073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env21072 == env21073) = true)

theorem identity21073 : scanCanonicalize (H12AffineFastState.compose env21073 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound21073 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21074 : List Nat := [2,4,8,16,32,16,8,256,512,36,2048,820,269,529,1,263,513,2341,36,0,804,32,16,3,269,16,2048,512,821,2340,289,32,256,33,529,513]

theorem envBound21074 : H12AffineFastState.Bounded env21074 := by
  intro p hp
  have h : env21074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21073_21074 : H12AffineEnvironment.transform 11 820 env21073 = env21074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env21073 == env21074) = true)

theorem identity21074 : scanCanonicalize (H12AffineFastState.compose env21074 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound21074 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21075 : List Nat := [2,4,8,16,32,16,8,256,512,36,309,820,269,529,1,263,513,16,36,0,804,32,16,3,269,16,309,512,821,17,289,32,256,33,529,513]

theorem envBound21075 : H12AffineFastState.Bounded env21075 := by
  intro p hp
  have h : env21075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21074_21075 : H12AffineEnvironment.transform 10 309 env21074 = env21075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env21074 == env21075) = true)

def env21076 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,62508,16,41230,8192,17,409908,57628,17664,442384,61704,62508,256,41260,16385,513]

theorem envBound21076 : H12AffineFastState.Bounded env21076 := by
  intro p hp
  have h : env21076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21066_21076 : H12AffineEnvironment.transform 5 17 env21066 = env21076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21066 == env21076) = true)

theorem identity21076 : scanCanonicalize (H12AffineFastState.compose env21076 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21076 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env21077 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10280,1024,32769,4113,62508,16,41230,8192,17,157980,57628,17664,190520,61704,62508,256,41260,16385,513]

theorem envBound21077 : H12AffineFastState.Bounded env21077 := by
  intro p hp
  have h : env21077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21076_21077 : H12AffineEnvironment.transform 17 10280 env21076 = env21077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21076 == env21077) = true)

theorem identity21077 : scanCanonicalize (H12AffineFastState.compose env21077 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound21077 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21078 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,24860,10280,1024,32769,4113,62508,16,41230,8192,17,2048,57628,17664,35108,61704,62508,256,41260,16385,513]

theorem envBound21078 : H12AffineFastState.Bounded env21078 := by
  intro p hp
  have h : env21078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21077_21078 : H12AffineEnvironment.transform 16 24860 env21077 = env21078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env21077 == env21078) = true)

theorem identity21078 : scanCanonicalize (H12AffineFastState.compose env21078 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound21078 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29963,24860,10280,1024,8460,4113,21793,16,3,8192,17,2048,16401,17664,10281,20485,21793,256,33,16385,513]

theorem envBound21079 : H12AffineFastState.Bounded env21079 := by
  intro p hp
  have h : env21079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21078_21079 : H12AffineEnvironment.transform 14 8461 env21078 = env21079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env21078 == env21079) = true)

theorem identity21079 : scanCanonicalize (H12AffineFastState.compose env21079 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21079 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21080 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,21511,16400,2340,1024,0,4113,21793,16,3,268,17,2048,16401,17664,2341,20485,21793,256,33,16385,513]

theorem envBound21080 : H12AffineFastState.Bounded env21080 := by
  intro p hp
  have h : env21080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21079_21080 : H12AffineEnvironment.transform 12 268 env21079 = env21080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21079 == env21080) = true)

theorem identity21080 : scanCanonicalize (H12AffineFastState.compose env21080 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21080 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21081 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1024,0,4113,32,16,3,268,17,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound21081 : H12AffineFastState.Bounded env21081 := by
  intro p hp
  have h : env21081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21080_21081 : H12AffineEnvironment.transform 13 5377 env21080 = env21081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21080 == env21081) = true)

theorem identity21081 : scanCanonicalize (H12AffineFastState.compose env21081 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21082 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,4096,57,5172,1,51,5156,2065,1024,0,4113,32,16,3,57,17,2048,5157,4097,2064,1073,32,53,33,5173,513]

theorem envBound21082 : H12AffineFastState.Bounded env21082 := by
  intro p hp
  have h : env21082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21081_21082 : H12AffineEnvironment.transform 7 53 env21081 = env21082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21081 == env21082) = true)

theorem identity21082 : scanCanonicalize (H12AffineFastState.compose env21082 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound21082 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21083 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,512,57,1588,1,51,1572,2065,1024,0,529,32,16,3,57,17,2048,1573,513,2064,1073,32,53,33,1589,513]

theorem envBound21083 : H12AffineFastState.Bounded env21083 := by
  intro p hp
  have h : env21083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21082_21083 : H12AffineEnvironment.transform 11 512 env21082 = env21083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env21082 == env21083) = true)

theorem identity21083 : scanCanonicalize (H12AffineFastState.compose env21083 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound21083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21084 : List Nat := [2,4,8,16,32,17,8,53,512,1024,529,512,57,1588,1,51,1572,512,1024,0,529,32,16,3,57,17,529,1573,513,513,1073,32,53,33,1589,513]

theorem envBound21084 : H12AffineFastState.Bounded env21084 := by
  intro p hp
  have h : env21084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21083_21084 : H12AffineEnvironment.transform 10 529 env21083 = env21084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env21083 == env21084) = true)

theorem identity21084 : scanCanonicalize (H12AffineFastState.compose env21084 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound21084 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21085 : List Nat := [2,4,8,16,32,17,8,53,512,36,529,512,57,528,1,51,512,512,36,0,529,32,16,3,57,17,529,513,513,513,21,32,53,33,529,513]

theorem envBound21085 : H12AffineFastState.Bounded env21085 := by
  intro p hp
  have h : env21085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21084_21085 : H12AffineEnvironment.transform 9 36 env21084 = env21085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env21084 == env21085) = true)

theorem identity21085 : scanCanonicalize (H12AffineFastState.compose env21085 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21086 : List Nat := [2,4,8,16,17,17,8,4,512,21,529,512,8,528,1,2,512,512,21,0,529,17,16,3,8,17,529,513,513,513,21,17,4,16,529,513]

theorem envBound21086 : H12AffineFastState.Bounded env21086 := by
  intro p hp
  have h : env21086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21085_21086 : H12AffineEnvironment.transform 4 17 env21085 = env21086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21085 == env21086) = true)

theorem identity21086 : scanCanonicalize (H12AffineFastState.compose env21086 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21086 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env21087 : List Nat := [2,4,8,0,1,1,8,4,512,5,513,512,8,512,1,2,512,512,5,0,513,1,0,3,8,1,513,513,513,513,5,1,4,0,513,513]

theorem envBound21087 : H12AffineFastState.Bounded env21087 := by
  intro p hp
  have h : env21087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21086_21087 : H12AffineEnvironment.transform 3 0 env21086 = env21087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21086 == env21087) = true)

def env21088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62588,119878,41311,8192,64,409957,79131,102743,463942,61705,73770,256,41341,16464,120407]

theorem envBound21088 : H12AffineFastState.Bounded env21088 := by
  intro p hp
  have h : env21088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21064_21088 : H12AffineEnvironment.transform 20 4161 env21064 = env21088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21064 == env21088) = true)

def env21089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119878,41311,8192,64,158029,79131,102743,212078,61705,73770,256,41341,16464,120407]

theorem envBound21089 : H12AffineFastState.Bounded env21089 := by
  intro p hp
  have h : env21089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21088_21089 : H12AffineEnvironment.transform 17 10280 env21088 = env21089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21088 == env21089) = true)

theorem identity21089 : scanCanonicalize (H12AffineFastState.compose env21089 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound21089 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,4161,62588,16,41311,8192,64,158029,57677,17665,190520,61705,62588,256,41341,16464,513]

theorem envBound21090 : H12AffineFastState.Bounded env21090 := by
  intro p hp
  have h : env21090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21089_21090 : H12AffineEnvironment.transform 15 54358 env21089 = env21090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env21089 == env21090) = true)

theorem identity21090 : scanCanonicalize (H12AffineFastState.compose env21090 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21090 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env21091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10280,1024,29789,4161,32,16,21763,8192,64,158029,5393,17665,138340,1365,32,256,21793,16464,513]

theorem envBound21091 : H12AffineFastState.Bounded env21091 := by
  intro p hp
  have h : env21091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21090_21091 : H12AffineEnvironment.transform 14 29788 env21090 = env21091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21090 == env21091) = true)

theorem identity21091 : scanCanonicalize (H12AffineFastState.compose env21091 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound21091 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,13389,10280,1024,29789,4161,32,16,21763,8192,64,23808,5393,17665,10281,1365,32,256,21793,16464,513]

theorem envBound21092 : H12AffineFastState.Bounded env21092 := by
  intro p hp
  have h : env21092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21091_21092 : H12AffineEnvironment.transform 16 13389 env21091 = env21092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env21091 == env21092) = true)

theorem identity21092 : scanCanonicalize (H12AffineFastState.compose env21092 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21092 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13389,10280,1024,0,4161,32,16,8542,8192,64,10589,5393,12636,10281,1365,32,256,8572,13325,513]

theorem envBound21093 : H12AffineFastState.Bounded env21093 := by
  intro p hp
  have h : env21093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21092_21093 : H12AffineEnvironment.transform 13 13405 env21092 = env21093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21092 == env21093) = true)

theorem identity21093 : scanCanonicalize (H12AffineFastState.compose env21093 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21093 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4161,32,16,3,349,64,2048,5393,4097,2420,1365,32,256,33,5456,513]

theorem envBound21094 : H12AffineFastState.Bounded env21094 := by
  intro p hp
  have h : env21094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21093_21094 : H12AffineEnvironment.transform 12 349 env21093 = env21094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21093 == env21094) = true)

theorem identity21094 : scanCanonicalize (H12AffineFastState.compose env21094 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound21094 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,869,349,1637,1,343,1653,2421,1024,0,804,32,16,3,349,64,2048,1652,868,2420,1365,32,256,33,1589,513]

theorem envBound21095 : H12AffineFastState.Bounded env21095 := by
  intro p hp
  have h : env21095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21094_21095 : H12AffineEnvironment.transform 11 869 env21094 = env21095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env21094 == env21095) = true)

theorem identity21095 : scanCanonicalize (H12AffineFastState.compose env21095 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound21095 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,529,869,349,1637,1,343,1653,868,1024,0,804,32,16,3,349,64,529,1652,868,869,1365,32,256,33,1589,513]

theorem envBound21096 : H12AffineFastState.Bounded env21096 := by
  intro p hp
  have h : env21096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21095_21096 : H12AffineEnvironment.transform 10 529 env21095 = env21096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env21095 == env21096) = true)

def env21097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62588,119878,41311,8192,64,158028,79131,102743,212079,61705,73770,256,41341,16464,120407]

theorem envBound21097 : H12AffineFastState.Bounded env21097 := by
  intro p hp
  have h : env21097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21088_21097 : H12AffineEnvironment.transform 17 10281 env21088 = env21097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21088 == env21097) = true)

theorem identity21097 : scanCanonicalize (H12AffineFastState.compose env21097 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound21097 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46156,10281,1024,32769,4161,62588,119878,41311,8192,64,56576,79131,102743,100387,61705,73770,256,41341,16464,120407]

theorem envBound21098 : H12AffineFastState.Bounded env21098 := by
  intro p hp
  have h : env21098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21097_21098 : H12AffineEnvironment.transform 16 46156 env21097 = env21098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env21097 == env21098) = true)

theorem identity21098 : scanCanonicalize (H12AffineFastState.compose env21098 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound21098 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,46156,10281,1024,32769,4161,62588,42076,41311,8192,64,56576,17665,57677,63545,61705,20528,256,41341,16464,42573]

theorem envBound21099 : H12AffineFastState.Bounded env21099 := by
  intro p hp
  have h : env21099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21098_21099 : H12AffineEnvironment.transform 15 28698 env21098 = env21099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env21098 == env21099) = true)

theorem identity21099 : scanCanonicalize (H12AffineFastState.compose env21099 (packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21099 : packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env21100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,5392,10281,1024,8541,4161,21792,1280,3,8192,64,31836,17665,16401,22885,20565,20528,256,33,16464,1809]

theorem envBound21100 : H12AffineFastState.Bounded env21100 := by
  intro p hp
  have h : env21100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21099_21100 : H12AffineEnvironment.transform 14 8540 env21099 = env21100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21099 == env21100) = true)

theorem identity21100 : scanCanonicalize (H12AffineFastState.compose env21100 (packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound21100 : packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env21101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,1378,5392,10281,1024,8541,4161,8280,1280,3,8192,64,2340,12409,13673,11293,9517,9544,256,33,13608,1809]

theorem envBound21101 : H12AffineFastState.Bounded env21101 := by
  intro p hp
  have h : env21101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21100_21101 : H12AffineEnvironment.transform 13 13688 env21100 = env21101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env21100 == env21101) = true)

theorem identity21101 : scanCanonicalize (H12AffineFastState.compose env21101 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound21101 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env21102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4453,1345,1378,5392,3124,1024,1344,4161,1093,1280,3,1053,64,2340,5220,4468,2048,304,341,256,33,4405,1809]

theorem envBound21102 : H12AffineFastState.Bounded env21102 := by
  intro p hp
  have h : env21102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21101_21102 : H12AffineEnvironment.transform 12 1053 env21101 = env21102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env21101 == env21102) = true)

theorem identity21102 : scanCanonicalize (H12AffineFastState.compose env21102 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound21102 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env21103 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,301,4453,113,82,4128,2308,304,112,4161,373,48,3,301,64,2340,4436,4468,2048,304,341,256,33,4405,545]

theorem envBound21103 : H12AffineFastState.Bounded env21103 := by
  intro p hp
  have h : env21103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21102_21103 : H12AffineEnvironment.transform 9 304 env21102 = env21103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env21102 == env21103) = true)

theorem identity21103 : scanCanonicalize (H12AffineFastState.compose env21103 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21103 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21104 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,269,4421,81,82,4096,2308,272,80,4161,341,16,3,269,64,2308,4436,4436,2048,272,341,256,1,4373,513]

theorem envBound21104 : H12AffineFastState.Bounded env21104 := by
  intro p hp
  have h : env21104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21103_21104 : H12AffineEnvironment.transform 4 0 env21103 = env21104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21103 == env21104) = true)

theorem identity21104 : scanCanonicalize (H12AffineFastState.compose env21104 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21104 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env21105 : List Nat := [2,4,8,16,0,64,8,256,260,272,2048,4096,269,4421,81,82,4096,2308,272,80,4161,341,16,3,269,64,2308,4436,4436,2048,272,341,256,1,4373,261]

theorem envBound21105 : H12AffineFastState.Bounded env21105 := by
  intro p hp
  have h : env21105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21104_21105 : H12AffineEnvironment.transform 8 260 env21104 = env21105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21104 == env21105) = true)

theorem identity21105 : scanCanonicalize (H12AffineFastState.compose env21105 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21105 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21106 : List Nat := [2,4,8,16,0,64,8,4,0,20,2048,4096,9,4161,81,82,4096,2048,20,80,4161,81,16,3,9,64,2048,4176,4176,2048,20,81,4,1,4113,1]

theorem envBound21106 : H12AffineFastState.Bounded env21106 := by
  intro p hp
  have h : env21106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21105_21106 : H12AffineEnvironment.transform 7 4 env21105 = env21106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21105 == env21106) = true)

theorem identity21106 : scanCanonicalize (H12AffineFastState.compose env21106 (packedSelected [0,1,2] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound21106 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env21107 : List Nat := [2,4,8,16,0,64,8,4,0,20,2048,2065,9,2128,81,82,2065,2048,20,80,2128,81,16,3,9,64,2048,2113,2113,2048,20,81,4,1,2048,1]

theorem envBound21107 : H12AffineFastState.Bounded env21107 := by
  intro p hp
  have h : env21107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21106_21107 : H12AffineEnvironment.transform 11 2065 env21106 = env21107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env21106 == env21107) = true)

theorem identity21107 : scanCanonicalize (H12AffineFastState.compose env21107 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21107 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21108 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,2065,9,2049,0,3,2065,2048,20,1,2049,0,16,3,9,17,2048,2064,2064,2048,20,0,4,1,2048,1]

theorem envBound21108 : H12AffineFastState.Bounded env21108 := by
  intro p hp
  have h : env21108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21107_21108 : H12AffineEnvironment.transform 5 17 env21107 = env21108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21107 == env21108) = true)

theorem identity21108 : scanCanonicalize (H12AffineFastState.compose env21108 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21109 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,17,9,1,0,3,17,0,20,1,1,0,16,3,9,17,0,16,16,0,20,0,4,1,0,1]

theorem envBound21109 : H12AffineFastState.Bounded env21109 := by
  intro p hp
  have h : env21109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21108_21109 : H12AffineEnvironment.transform 10 0 env21108 = env21109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21108 == env21109) = true)

theorem identity21109 : scanCanonicalize (H12AffineFastState.compose env21109 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21110 : List Nat := [2,4,8,0,0,1,8,4,0,4,0,1,9,1,0,3,1,0,4,1,1,0,0,3,9,1,0,0,0,0,4,0,4,1,0,1]

theorem envBound21110 : H12AffineFastState.Bounded env21110 := by
  intro p hp
  have h : env21110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21109_21110 : H12AffineEnvironment.transform 3 0 env21109 = env21110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21109 == env21110) = true)

def env21111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8193,64,17227834,18973700,102743,2556935,18890775,16875892,256,16777251,16834831,18966344]

theorem envBound21111 : H12AffineFastState.Bounded env21111 := by
  intro p hp
  have h : env21111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21062_21111 : H12AffineEnvironment.transform 6 9 env21062 = env21111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21062 == env21111) = true)

theorem identity21111 : scanCanonicalize (H12AffineFastState.compose env21111 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound21111 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,2155581,2212871,16777216,8193,64,17039734,18973700,102743,2483531,18890775,16875892,256,16777251,16834831,18966344]

theorem envBound21112 : H12AffineFastState.Bounded env21112 := by
  intro p hp
  have h : env21112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21111_21112 : H12AffineEnvironment.transform 16 57676 env21111 = env21112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env21111 == env21112) = true)

theorem identity21112 : scanCanonicalize (H12AffineFastState.compose env21112 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound21112 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,262144,1024,32769,2097152,2155581,2114897,16777216,8193,64,17039734,18875730,4097,2384925,18890775,16777250,256,16777251,16834831,18933278]

theorem envBound21113 : H12AffineFastState.Bounded env21113 := by
  intro p hp
  have h : env21113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21112_21113 : H12AffineEnvironment.transform 15 33110 env21112 = env21113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env21112 == env21113) = true)

theorem identity21113 : scanCanonicalize (H12AffineFastState.compose env21113 (packedSelected [1,3,4,5,7,8,9,10,11,14,15,16,17,19,20,27,32,35,38] rootPS)) = affineNative (2^(23+1) ^^^ 2122831) := by decide +kernel

theorem selectedBound21113 : packedSelected [1,3,4,5,7,8,9,10,11,14,15,16,17,19,20,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env21114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,262144,1024,32769,2097152,2155581,2114897,2122831,8193,64,2385209,24861,4097,2384925,9304,2122861,256,2122860,2131264,33361]

theorem envBound21114 : H12AffineFastState.Bounded env21114 := by
  intro p hp
  have h : env21114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21113_21114 : H12AffineEnvironment.transform 23 2122831 env21113 = env21114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2122831 env21113 == env21114) = true)

theorem identity21114 : scanCanonicalize (H12AffineFastState.compose env21114 (packedSelected [3,10,17,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound21114 : packedSelected [3,10,17,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,43129,1024,32769,2097152,2155581,2114897,2122831,8193,64,2149696,24861,4097,2149476,9304,2122861,256,2122860,2131264,33361]

theorem envBound21115 : H12AffineFastState.Bounded env21115 := by
  intro p hp
  have h : env21115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21114_21115 : H12AffineEnvironment.transform 17 43129 env21114 = env21115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env21114 == env21115) = true)

theorem identity21115 : scanCanonicalize (H12AffineFastState.compose env21115 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound21115 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env21116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8283,16449,2420,1024,8460,2097152,2114864,2114897,2122831,8193,64,2124877,24861,4097,2125161,9304,2122861,256,2122860,2106445,9052]

theorem envBound21116 : H12AffineFastState.Bounded env21116 := by
  intro p hp
  have h : env21116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21115_21116 : H12AffineEnvironment.transform 14 8461 env21115 = env21116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env21115 == env21116) = true)

theorem identity21116 : scanCanonicalize (H12AffineFastState.compose env21116 (packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound21116 : packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env21117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8283,16449,2420,1024,8460,4405,21509,21604,30074,8193,64,32120,24861,4097,31836,9304,30040,256,30041,13688,9052]

theorem envBound21117 : H12AffineFastState.Bounded env21117 := by
  intro p hp
  have h : env21117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21116_21117 : H12AffineEnvironment.transform 20 4405 env21116 = env21117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env21116 == env21117) = true)

theorem identity21117 : scanCanonicalize (H12AffineFastState.compose env21117 (packedSelected [0,1,4,7,8,9,10,11,15,16,21] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound21117 : packedSelected [0,1,4,7,8,9,10,11,15,16,21] rootPS < 2^1333 := by decide +kernel

def env21118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8461,8283,13672,2420,1024,8460,4405,8492,8525,83,8193,64,2129,5172,4097,2421,9304,113,256,112,13688,9052]

theorem envBound21118 : H12AffineFastState.Bounded env21118 := by
  intro p hp
  have h : env21118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21117_21118 : H12AffineEnvironment.transform 13 13609 env21117 = env21118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env21117 == env21118) = true)

theorem identity21118 : scanCanonicalize (H12AffineFastState.compose env21118 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21118 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21119 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13609,8461,8203,13624,2340,1024,8460,4405,8492,8477,3,8193,16,2049,5172,4097,2341,9224,33,256,32,13608,8972]

theorem envBound21119 : H12AffineFastState.Bounded env21119 := by
  intro p hp
  have h : env21119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21118_21119 : H12AffineEnvironment.transform 5 16 env21118 = env21119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21118 == env21119) = true)

theorem identity21119 : scanCanonicalize (H12AffineFastState.compose env21119 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21119 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21120 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5376,292,34,5393,2340,1024,293,4405,261,308,3,40,16,2049,5172,4097,2341,1057,33,256,32,5377,805]

theorem envBound21120 : H12AffineFastState.Bounded env21120 := by
  intro p hp
  have h : env21120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21119_21120 : H12AffineEnvironment.transform 12 41 env21119 = env21120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21119 == env21120) = true)

theorem identity21120 : scanCanonicalize (H12AffineFastState.compose env21120 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21120 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env21121 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4113,33,16,3,40,16,2049,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound21121 : H12AffineFastState.Bounded env21121 := by
  intro p hp
  have h : env21121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21120_21121 : H12AffineEnvironment.transform 7 36 env21120 = env21121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21120 == env21121) = true)

def env21122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound21122 : H12AffineFastState.Bounded env21122 := by
  intro p hp
  have h : env21122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21012_21122 : H12AffineEnvironment.transform 18 1025 env21012 = env21122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21012 == env21122) = true)

theorem identity21122 : scanCanonicalize (H12AffineFastState.compose env21122 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237575) := by decide +kernel

theorem selectedBound21122 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237575,8328,64,15066246,237579,10507600,8830977,10723479,4407623,257,8642603,8585615,10651456]

theorem envBound21123 : H12AffineFastState.Bounded env21123 := by
  intro p hp
  have h : env21123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21122_21123 : H12AffineEnvironment.transform 23 2237575 env21122 = env21123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237575 env21122 == env21123) = true)

def env21124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066246,115151,10507600,8692165,10600787,4268163,257,8487407,8478795,10544772]

theorem envBound21124 : H12AffineFastState.Bounded env21124 := by
  intro p hp
  have h : env21124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21123_21124 : H12AffineEnvironment.transform 16 25028 env21123 = env21124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env21123 == env21124) = true)

def env21125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4584662,115151,17664,2404757,119043,4268163,257,2199999,2191387,63188]

theorem envBound21125 : H12AffineFastState.Bounded env21125 := by
  intro p hp
  have h : env21125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21124_21125 : H12AffineEnvironment.transform 22 2101328 env21124 = env21125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21124 == env21125) = true)

def env21126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,121942,115151,17664,2404757,119043,329731,257,2199999,2191387,63188]

theorem envBound21126 : H12AffineFastState.Bounded env21126 := by
  intro p hp
  have h : env21126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21125_21126 : H12AffineEnvironment.transform 21 272512 env21125 = env21126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21125 == env21126) = true)

theorem identity21126 : scanCanonicalize (H12AffineFastState.compose env21126 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound21126 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,77898,272512,73754,95497,8328,64,121942,115151,17664,360927,119043,329731,257,41461,16465,63188]

theorem envBound21127 : H12AffineFastState.Bounded env21127 := by
  intro p hp
  have h : env21127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21126_21127 : H12AffineEnvironment.transform 20 77898 env21126 = env21127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env21126 == env21127) = true)

def env21128 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,77850,272512,73754,95497,8328,16,121862,115103,17664,360847,119043,329731,257,41381,16385,63108]

theorem envBound21128 : H12AffineFastState.Bounded env21128 := by
  intro p hp
  have h : env21128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21127_21128 : H12AffineEnvironment.transform 5 16 env21127 = env21128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21127 == env21128) = true)

theorem identity21128 : scanCanonicalize (H12AffineFastState.compose env21128 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound21128 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env21129 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,100387,1025,32769,77850,106659,73754,95497,8328,16,121862,115103,17664,2476,119043,32800,257,41381,16385,63108]

theorem envBound21129 : H12AffineFastState.Bounded env21129 := by
  intro p hp
  have h : env21129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21128_21129 : H12AffineEnvironment.transform 17 100387 env21128 = env21129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env21128 == env21129) = true)

theorem identity21129 : scanCanonicalize (H12AffineFastState.compose env21129 (packedSelected [0,4,5,7,8,17,19,22,24,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound21129 : packedSelected [0,4,5,7,8,17,19,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env21130 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,24980,76079,1025,8461,77850,65967,73754,95497,8328,16,97546,90259,17664,2476,94223,8492,257,169,16385,22408]

theorem envBound21130 : H12AffineFastState.Bounded env21130 := by
  intro p hp
  have h : env21130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21129_21130 : H12AffineEnvironment.transform 14 8460 env21129 = env21130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env21129 == env21130) = true)

theorem identity21130 : scanCanonicalize (H12AffineFastState.compose env21130 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound21130 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env21131 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,29963,24980,23588,1025,8461,17681,29860,21777,2,8328,16,2049,5528,17664,2476,1284,8492,257,169,16385,22408]

theorem envBound21131 : H12AffineFastState.Bounded env21131 := by
  intro p hp
  have h : env21131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21130_21131 : H12AffineEnvironment.transform 15 29963 env21130 = env21131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env21130 == env21131) = true)

theorem identity21131 : scanCanonicalize (H12AffineFastState.compose env21131 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound21131 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env21132 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,8460,398,5393,10401,1025,8461,12692,33,8596,2,8328,16,2049,5528,12677,2476,1284,8492,257,169,13444,8973]

theorem envBound21132 : H12AffineFastState.Bounded env21132 := by
  intro p hp
  have h : env21132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21131_21132 : H12AffineEnvironment.transform 13 13445 env21131 = env21132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env21131 == env21132) = true)

theorem identity21132 : scanCanonicalize (H12AffineFastState.compose env21132 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21132 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21133 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,0,398,5393,2477,1025,1,4248,33,152,2,388,16,2049,5528,4233,2476,1284,32,257,169,5512,513]

theorem envBound21133 : H12AffineFastState.Bounded env21133 := by
  intro p hp
  have h : env21133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21132_21133 : H12AffineEnvironment.transform 12 268 env21132 = env21133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21132 == env21133) = true)

theorem identity21133 : scanCanonicalize (H12AffineFastState.compose env21133 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21133 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21134 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,40,5293,0,170,5173,2185,1025,1,4248,33,152,2,160,16,2049,5308,4233,2184,1056,32,37,169,5292,513]

theorem envBound21134 : H12AffineFastState.Bounded env21134 := by
  intro p hp
  have h : env21134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21133_21134 : H12AffineEnvironment.transform 7 36 env21133 = env21134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21133 == env21134) = true)

def env21135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,77851,272512,73754,95497,8328,17,121863,115102,17664,360846,119043,329731,257,41380,16384,63109]

theorem envBound21135 : H12AffineFastState.Bounded env21135 := by
  intro p hp
  have h : env21135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21127_21135 : H12AffineEnvironment.transform 5 17 env21127 = env21135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21127 == env21135) = true)

theorem identity21135 : scanCanonicalize (H12AffineFastState.compose env21135 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound21135 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env21136 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,2340,1025,32769,77851,8612,73754,95497,8328,17,121863,115102,17664,100522,119043,65831,257,41380,16384,63109]

theorem envBound21136 : H12AffineFastState.Bounded env21136 := by
  intro p hp
  have h : env21136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21135_21136 : H12AffineEnvironment.transform 17 2340 env21135 = env21136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env21135 == env21136) = true)

theorem identity21136 : scanCanonicalize (H12AffineFastState.compose env21136 (packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound21136 : packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21137 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,65536,24981,2340,1025,29708,77851,8612,73754,95497,8328,17,75786,79251,17664,97447,75022,65831,257,21929,16384,648]

theorem envBound21137 : H12AffineFastState.Bounded env21137 := by
  intro p hp
  have h : env21137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21136_21137 : H12AffineEnvironment.transform 14 29709 env21136 = env21137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env21136 == env21137) = true)

theorem identity21137 : scanCanonicalize (H12AffineFastState.compose env21137 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound21137 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env21138 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,24981,2340,1025,29708,4249,8612,152,21899,8328,17,2184,5393,17664,23589,1420,8613,257,21929,16384,648]

theorem envBound21138 : H12AffineFastState.Bounded env21138 := by
  intro p hp
  have h : env21138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21137_21138 : H12AffineEnvironment.transform 15 8322 env21137 = env21138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env21137 == env21138) = true)

theorem identity21138 : scanCanonicalize (H12AffineFastState.compose env21138 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21138 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21139 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21761,398,16537,2340,1025,21760,4249,168,152,21899,388,17,2184,5393,17664,23589,1420,169,257,21929,16384,648]

theorem envBound21139 : H12AffineFastState.Bounded env21139 := by
  intro p hp
  have h : env21139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21138_21139 : H12AffineEnvironment.transform 12 268 env21138 = env21139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21138 == env21139) = true)

theorem identity21139 : scanCanonicalize (H12AffineFastState.compose env21139 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21139 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21140 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,263,16400,2340,1025,21760,4112,33,17,21762,269,17,2049,5393,17664,23589,1285,32,257,21792,16384,513]

theorem envBound21140 : H12AffineFastState.Bounded env21140 := by
  intro p hp
  have h : env21140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21139_21140 : H12AffineEnvironment.transform 6 9 env21139 = env21140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21139 == env21140) = true)

theorem identity21140 : scanCanonicalize (H12AffineFastState.compose env21140 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21140 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21141 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4112,33,17,3,269,17,2049,5393,4097,2340,1285,32,257,33,5377,513]

theorem envBound21141 : H12AffineFastState.Bounded env21141 := by
  intro p hp
  have h : env21141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21140_21141 : H12AffineEnvironment.transform 13 5377 env21140 = env21141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21140 == env21141) = true)

theorem identity21141 : scanCanonicalize (H12AffineFastState.compose env21141 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21142 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,268,4357,0,263,4373,2340,5,1,4112,33,17,3,269,17,2049,4373,4097,2340,257,32,257,33,4357,513]

theorem envBound21142 : H12AffineFastState.Bounded env21142 := by
  intro p hp
  have h : env21142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21141_21142 : H12AffineEnvironment.transform 9 4 env21141 = env21142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21141 == env21142) = true)

theorem identity21142 : scanCanonicalize (H12AffineFastState.compose env21142 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2318) := by decide +kernel

theorem selectedBound21142 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21143 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,2318,268,2059,0,263,2075,2340,5,1,2334,33,17,3,269,17,2049,2075,2319,2340,257,32,257,33,2059,513]

theorem envBound21143 : H12AffineFastState.Bounded env21143 := by
  intro p hp
  have h : env21143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21142_21143 : H12AffineEnvironment.transform 11 2318 env21142 = env21143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2318 env21142 == env21143) = true)

theorem identity21143 : scanCanonicalize (H12AffineFastState.compose env21143 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound21143 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21144 : List Nat := [2,4,8,16,32,17,9,256,512,4,782,512,268,773,0,263,789,554,5,1,528,33,17,3,269,17,783,789,513,554,257,32,257,33,773,513]

theorem envBound21144 : H12AffineFastState.Bounded env21144 := by
  intro p hp
  have h : env21144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21143_21144 : H12AffineEnvironment.transform 10 782 env21143 = env21144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env21143 == env21144) = true)

theorem identity21144 : scanCanonicalize (H12AffineFastState.compose env21144 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21144 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21145 : List Nat := [2,4,8,16,32,17,9,37,512,4,555,512,41,544,0,34,560,554,5,1,528,33,17,3,40,17,554,560,513,554,36,32,36,33,544,513]

theorem envBound21145 : H12AffineFastState.Bounded env21145 := by
  intro p hp
  have h : env21145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21144_21145 : H12AffineEnvironment.transform 7 37 env21144 = env21145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21144 == env21145) = true)

theorem identity21145 : scanCanonicalize (H12AffineFastState.compose env21145 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21145 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21146 : List Nat := [2,4,8,10,32,11,9,37,512,4,555,512,41,544,0,34,554,554,5,1,522,33,11,3,40,11,554,554,513,554,36,32,36,33,544,513]

theorem envBound21146 : H12AffineFastState.Bounded env21146 := by
  intro p hp
  have h : env21146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21145_21146 : H12AffineEnvironment.transform 3 10 env21145 = env21146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21145 == env21146) = true)

theorem identity21146 : scanCanonicalize (H12AffineFastState.compose env21146 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound21146 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21147 : List Nat := [2,4,5,7,32,6,4,37,512,4,550,512,36,544,0,34,551,551,5,1,519,33,6,3,37,6,551,551,513,551,36,32,36,33,544,513]

theorem envBound21147 : H12AffineFastState.Bounded env21147 := by
  intro p hp
  have h : env21147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21146_21147 : H12AffineEnvironment.transform 2 5 env21146 = env21147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env21146 == env21147) = true)

theorem identity21147 : scanCanonicalize (H12AffineFastState.compose env21147 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21147 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env21148 : List Nat := [2,4,5,7,1,6,4,4,512,4,519,512,5,513,0,3,518,518,5,1,519,0,6,3,4,6,518,518,513,518,5,1,5,0,513,513]

theorem envBound21148 : H12AffineFastState.Bounded env21148 := by
  intro p hp
  have h : env21148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21147_21148 : H12AffineEnvironment.transform 4 1 env21147 = env21148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21147 == env21148) = true)

def env21149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,121943,115151,17664,2404757,119043,329730,257,2199999,2191387,63188]

theorem envBound21149 : H12AffineFastState.Bounded env21149 := by
  intro p hp
  have h : env21149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21125_21149 : H12AffineEnvironment.transform 21 272513 env21125 = env21149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21125 == env21149) = true)

theorem identity21149 : scanCanonicalize (H12AffineFastState.compose env21149 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21149 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,64604,57796,17664,2404757,61704,272393,257,2142644,2117648,63188]

theorem envBound21150 : H12AffineFastState.Bounded env21150 := by
  intro p hp
  have h : env21150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21149_21150 : H12AffineEnvironment.transform 15 8203 env21149 = env21150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21149 == env21150) = true)

def env21151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24908,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,64604,57676,17664,2404637,61704,272393,257,2142524,2117648,63068]

theorem envBound21151 : H12AffineFastState.Bounded env21151 := by
  intro p hp
  have h : env21151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21150_21151 : H12AffineEnvironment.transform 6 8 env21150 = env21151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21150 == env21151) = true)

theorem identity21151 : scanCanonicalize (H12AffineFastState.compose env21151 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound21151 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env21152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21621,8203,24908,262144,1025,21620,2097152,272393,2101328,2114883,8192,64,10281,13625,17664,2385256,9597,272393,257,2123081,2117648,8745]

theorem envBound21152 : H12AffineFastState.Bounded env21152 := by
  intro p hp
  have h : env21152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21151_21152 : H12AffineEnvironment.transform 14 21621 env21151 = env21152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env21151 == env21152) = true)

theorem identity21152 : scanCanonicalize (H12AffineFastState.compose env21152 (packedSelected [0,1,2,4,11,16,18,19,22,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound21152 : packedSelected [0,1,2,4,11,16,18,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8540,8203,5221,262144,1025,8541,2097152,272393,2101328,2109546,8192,64,10281,13625,12329,2363457,9597,272393,257,2101344,2106681,8745]

theorem envBound21153 : H12AffineFastState.Bounded env21153 := by
  intro p hp
  have h : env21153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21152_21153 : H12AffineEnvironment.transform 13 13609 env21152 = env21153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env21152 == env21153) = true)

theorem identity21153 : scanCanonicalize (H12AffineFastState.compose env21153 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21153 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env21154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,0,343,5221,262144,1025,1,2097152,264533,2101328,2101558,348,64,2421,5221,4469,2363457,1057,264533,257,2101344,2098277,885]

theorem envBound21154 : H12AffineFastState.Bounded env21154 := by
  intro p hp
  have h : env21154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21153_21154 : H12AffineEnvironment.transform 12 348 env21153 = env21154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21153 == env21154) = true)

theorem identity21154 : scanCanonicalize (H12AffineFastState.compose env21154 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound21154 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env21155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,0,343,5221,262144,1025,1,4405,264533,357,3,348,64,2421,5221,4469,262516,1057,264533,257,341,5456,885]

theorem envBound21155 : H12AffineFastState.Bounded env21155 := by
  intro p hp
  have h : env21155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21154_21155 : H12AffineEnvironment.transform 20 4405 env21154 = env21155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env21154 == env21155) = true)

theorem identity21155 : scanCanonicalize (H12AffineFastState.compose env21155 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound21155 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env21156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3173,348,2064,0,343,2048,262144,1025,1,3408,264533,357,3,348,64,2421,2048,3344,262516,1057,264533,257,341,2357,885]

theorem envBound21156 : H12AffineFastState.Bounded env21156 := by
  intro p hp
  have h : env21156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21155_21156 : H12AffineEnvironment.transform 11 3173 env21155 = env21156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env21155 == env21156) = true)

theorem identity21156 : scanCanonicalize (H12AffineFastState.compose env21156 (packedSelected [1,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2064) := by decide +kernel

theorem selectedBound21156 : packedSelected [1,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3173,348,2064,0,343,2048,2064,1025,1,3408,325,357,3,348,64,2421,2048,3344,2404,1057,325,257,341,2357,885]

theorem envBound21157 : H12AffineFastState.Bounded env21157 := by
  intro p hp
  have h : env21157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21156_21157 : H12AffineEnvironment.transform 17 2064 env21156 = env21157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2064 env21156 == env21157) = true)

theorem identity21157 : scanCanonicalize (H12AffineFastState.compose env21157 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound21157 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21158 : List Nat := [2,4,8,16,32,64,8,256,512,117,2048,2064,348,2064,0,343,2048,2064,116,1,2341,325,357,3,348,64,2421,2048,2405,2404,84,325,257,341,2357,885]

theorem envBound21158 : H12AffineFastState.Bounded env21158 := by
  intro p hp
  have h : env21158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21157_21158 : H12AffineEnvironment.transform 9 117 env21157 = env21158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env21157 == env21158) = true)

theorem identity21158 : scanCanonicalize (H12AffineFastState.compose env21158 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound21158 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21159 : List Nat := [2,4,8,16,32,64,8,101,512,117,2048,2064,57,2064,0,50,2048,2064,116,1,2112,32,0,3,57,64,2064,2048,2048,2049,84,32,100,48,2128,528]

theorem envBound21159 : H12AffineFastState.Bounded env21159 := by
  intro p hp
  have h : env21159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21158_21159 : H12AffineEnvironment.transform 7 101 env21158 = env21159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env21158 == env21159) = true)

def env21160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,64604,57677,17664,2404636,61704,272393,257,2142525,2117648,63069]

theorem envBound21160 : H12AffineFastState.Bounded env21160 := by
  intro p hp
  have h : env21160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21150_21160 : H12AffineEnvironment.transform 6 9 env21150 = env21160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21150 == env21160) = true)

theorem identity21160 : scanCanonicalize (H12AffineFastState.compose env21160 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(20+1) ^^^ 314420) := by decide +kernel

theorem selectedBound21160 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env21161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,314420,272392,318564,297335,8193,64,64604,57677,17664,32040,61704,272393,257,294153,302116,63069]

theorem envBound21161 : H12AffineFastState.Bounded env21161 := by
  intro p hp
  have h : env21161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21160_21161 : H12AffineEnvironment.transform 20 314420 env21160 = env21161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314420 env21160 == env21161) = true)

theorem identity21161 : scanCanonicalize (H12AffineFastState.compose env21161 (packedSelected [0,3,5,8,9,10,16,17,20,22,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound21161 : packedSelected [0,3,5,8,9,10,16,17,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,32041,1025,32769,45341,21793,41293,62558,8193,64,64604,57677,17664,32040,61704,21792,257,32,57613,63069]

theorem envBound21162 : H12AffineFastState.Bounded env21162 := by
  intro p hp
  have h : env21162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21161_21162 : H12AffineEnvironment.transform 17 32041 env21161 = env21162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env21161 == env21162) = true)

theorem identity21162 : scanCanonicalize (H12AffineFastState.compose env21162 (packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21162 : packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,5392,2420,1025,32769,45341,8572,41293,32771,8193,64,34817,38160,12637,2421,34133,8573,257,32,38224,33280]

theorem envBound21163 : H12AffineFastState.Bounded env21163 := by
  intro p hp
  have h : env21163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21162_21163 : H12AffineEnvironment.transform 13 13405 env21162 = env21163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21162 == env21163) = true)

theorem identity21163 : scanCanonicalize (H12AffineFastState.compose env21163 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21163 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,5392,2420,1025,0,12572,8572,8524,2,8193,64,2048,5393,12637,2421,1364,8573,257,32,5457,513]

theorem envBound21164 : H12AffineFastState.Bounded env21164 := by
  intro p hp
  have h : env21164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21163_21164 : H12AffineEnvironment.transform 14 1 env21163 = env21164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21163 == env21164) = true)

theorem identity21164 : scanCanonicalize (H12AffineFastState.compose env21164 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 6185) := by decide +kernel

theorem selectedBound21164 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env21165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6185,3188,1,6178,5392,2420,1025,0,2357,6485,6501,2,6184,64,2048,5393,2420,2421,1364,6484,257,32,5457,513]

theorem envBound21165 : H12AffineFastState.Bounded env21165 := by
  intro p hp
  have h : env21165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21164_21165 : H12AffineEnvironment.transform 12 6185 env21164 = env21165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6185 env21164 == env21165) = true)

def env21166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4584663,115151,17665,2404756,119042,4268163,257,2199998,2191386,63189]

theorem envBound21166 : H12AffineFastState.Bounded env21166 := by
  intro p hp
  have h : env21166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21124_21166 : H12AffineEnvironment.transform 22 2101329 env21124 = env21166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21124 == env21166) = true)

def env21167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,121943,115151,17665,2404756,119042,329731,257,2199998,2191386,63189]

theorem envBound21167 : H12AffineFastState.Bounded env21167 := by
  intro p hp
  have h : env21167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21166_21167 : H12AffineEnvironment.transform 21 272512 env21166 = env21167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21166 == env21167) = true)

theorem identity21167 : scanCanonicalize (H12AffineFastState.compose env21167 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound21167 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,115871,272512,120014,98780,8328,64,121943,115151,17665,357643,119042,329731,257,21793,46213,63189]

theorem envBound21168 : H12AffineFastState.Bounded env21168 := by
  intro p hp
  have h : env21168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21167_21168 : H12AffineEnvironment.transform 20 115871 env21167 = env21168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env21167 == env21168) = true)

def env21169 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,115871,272512,119966,98700,8328,16,121863,115103,17665,357643,119042,329731,257,21793,46213,63109]

theorem envBound21169 : H12AffineFastState.Bounded env21169 := by
  intro p hp
  have h : env21169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21168_21169 : H12AffineEnvironment.transform 5 16 env21168 = env21169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21168 == env21169) = true)

theorem identity21169 : scanCanonicalize (H12AffineFastState.compose env21169 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound21169 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21170 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,23589,1025,32769,115871,29861,119966,98700,8328,16,121863,115103,17665,76078,119042,87078,257,21793,46213,63109]

theorem envBound21170 : H12AffineFastState.Bounded env21170 := by
  intro p hp
  have h : env21170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21169_21170 : H12AffineEnvironment.transform 17 23589 env21169 = env21170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env21169 == env21170) = true)

theorem identity21170 : scanCanonicalize (H12AffineFastState.compose env21170 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound21170 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env21171 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,65536,24980,23589,1025,21897,69911,29861,65814,87044,8328,16,67983,70679,17665,76078,66698,87078,257,21793,24845,8973]

theorem envBound21171 : H12AffineFastState.Bounded env21171 := by
  intro p hp
  have h : env21171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21170_21171 : H12AffineEnvironment.transform 14 21896 env21170 = env21171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env21170 == env21171) = true)

theorem identity21171 : scanCanonicalize (H12AffineFastState.compose env21171 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound21171 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21172 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,29962,24980,23589,1025,21897,25629,29861,29724,8462,8328,16,31877,24861,17665,23588,29056,8492,257,21793,24845,8973]

theorem envBound21172 : H12AffineFastState.Bounded env21172 := by
  intro p hp
  have h : env21172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21171_21172 : H12AffineEnvironment.transform 15 29962 env21171 = env21172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env21171 == env21172) = true)

theorem identity21172 : scanCanonicalize (H12AffineFastState.compose env21172 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21172 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21173 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21896,21510,16536,23589,1025,21897,17681,21929,21776,2,388,16,23945,16401,17665,23588,20620,32,257,21793,16385,513]

theorem envBound21173 : H12AffineFastState.Bounded env21173 := by
  intro p hp
  have h : env21173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21172_21173 : H12AffineEnvironment.transform 12 268 env21172 = env21173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21172 == env21173) = true)

theorem identity21173 : scanCanonicalize (H12AffineFastState.compose env21173 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21173 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21174 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,1,399,5393,2476,1025,0,4248,32,153,2,388,16,2048,5528,4232,2477,1285,32,257,168,5512,513]

theorem envBound21174 : H12AffineFastState.Bounded env21174 := by
  intro p hp
  have h : env21174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21173_21174 : H12AffineEnvironment.transform 13 5513 env21173 = env21174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21173 == env21174) = true)

theorem identity21174 : scanCanonicalize (H12AffineFastState.compose env21174 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3239) := by decide +kernel

theorem selectedBound21174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21175 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3239,268,2350,1,399,2486,2476,1025,0,3135,32,153,2,388,16,2048,2367,3119,2477,1285,32,257,168,2351,513]

theorem envBound21175 : H12AffineFastState.Bounded env21175 := by
  intro p hp
  have h : env21175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21174_21175 : H12AffineEnvironment.transform 11 3239 env21174 = env21175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3239 env21174 == env21175) = true)

theorem identity21175 : scanCanonicalize (H12AffineFastState.compose env21175 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21175 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21176 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3119,268,2350,1,263,2366,2340,1025,0,3135,32,17,2,268,16,2048,2367,3119,2341,1285,32,257,32,2351,513]

theorem envBound21176 : H12AffineFastState.Bounded env21176 := by
  intro p hp
  have h : env21176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21175_21176 : H12AffineEnvironment.transform 6 8 env21175 = env21176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21175 == env21176) = true)

theorem identity21176 : scanCanonicalize (H12AffineFastState.compose env21176 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21177 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,3102,268,2335,1,263,2319,2325,1025,0,3086,17,17,2,268,16,2048,2318,3102,2324,1285,17,257,17,2334,513]

theorem envBound21177 : H12AffineFastState.Bounded env21177 := by
  intro p hp
  have h : env21177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21176_21177 : H12AffineEnvironment.transform 4 17 env21176 = env21177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21176 == env21177) = true)

theorem identity21177 : scanCanonicalize (H12AffineFastState.compose env21177 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound21177 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21178 : List Nat := [2,4,8,16,17,16,8,256,512,1024,1557,523,268,1802,1,263,1818,1792,1025,0,539,17,17,2,268,16,1557,1819,523,1793,1285,17,257,17,1803,513]

theorem envBound21178 : H12AffineFastState.Bounded env21178 := by
  intro p hp
  have h : env21178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21177_21178 : H12AffineEnvironment.transform 10 1557 env21177 = env21178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env21177 == env21178) = true)

theorem identity21178 : scanCanonicalize (H12AffineFastState.compose env21178 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound21178 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21179 : List Nat := [2,4,8,16,17,16,8,31,512,1024,1557,523,19,1557,1,24,1541,1567,1025,0,539,17,17,2,19,16,1557,1540,523,1566,1050,17,30,17,1556,513]

theorem envBound21179 : H12AffineFastState.Bounded env21179 := by
  intro p hp
  have h : env21179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21178_21179 : H12AffineEnvironment.transform 7 31 env21178 = env21179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env21178 == env21179) = true)

theorem identity21179 : scanCanonicalize (H12AffineFastState.compose env21179 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound21179 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21180 : List Nat := [2,4,8,11,10,11,8,4,512,1024,1550,523,8,1550,1,3,1541,1540,1025,0,512,10,10,2,8,11,1550,1540,523,1541,1025,10,5,10,1551,513]

theorem envBound21180 : H12AffineFastState.Bounded env21180 := by
  intro p hp
  have h : env21180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21179_21180 : H12AffineEnvironment.transform 3 11 env21179 = env21180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env21179 == env21180) = true)

theorem identity21180 : scanCanonicalize (H12AffineFastState.compose env21180 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21180 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21181 : List Nat := [2,4,2,1,0,1,2,4,512,1024,1540,513,2,1540,1,3,1541,1540,1025,0,512,0,0,2,2,1,1540,1540,513,1541,1025,0,5,0,1541,513]

theorem envBound21181 : H12AffineFastState.Bounded env21181 := by
  intro p hp
  have h : env21181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21180_21181 : H12AffineEnvironment.transform 2 2 env21180 = env21181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21180 == env21181) = true)

theorem identity21181 : scanCanonicalize (H12AffineFastState.compose env21181 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound21181 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21182 : List Nat := [2,4,2,1,0,1,2,4,512,3,519,513,2,519,1,3,518,519,2,0,512,0,0,2,2,1,519,519,513,518,2,0,5,0,518,513]

theorem envBound21182 : H12AffineFastState.Bounded env21182 := by
  intro p hp
  have h : env21182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21181_21182 : H12AffineEnvironment.transform 9 3 env21181 = env21182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env21181 == env21182) = true)

theorem identity21182 : scanCanonicalize (H12AffineFastState.compose env21182 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound21182 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21183 : List Nat := [2,4,2,1,0,1,2,4,7,3,0,6,2,0,1,3,1,0,2,0,7,0,0,2,2,1,0,0,6,1,2,0,5,0,1,6]

theorem envBound21183 : H12AffineFastState.Bounded env21183 := by
  intro p hp
  have h : env21183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21182_21183 : H12AffineEnvironment.transform 8 7 env21182 = env21183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env21182 == env21183) = true)

theorem identity21183 : scanCanonicalize (H12AffineFastState.compose env21183 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound21183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21184 : List Nat := [1,4,1,1,0,1,1,4,4,0,0,5,1,0,1,0,1,0,1,0,4,0,0,1,1,1,0,0,5,1,1,0,5,0,1,5]

theorem envBound21184 : H12AffineFastState.Bounded env21184 := by
  intro p hp
  have h : env21184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21183_21184 : H12AffineEnvironment.transform 0 1 env21183 = env21184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env21183 == env21184) = true)

theorem identity21184 : scanCanonicalize (H12AffineFastState.compose env21184 (packedSelected [14] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound21184 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env21185 : List Nat := [1,1,1,1,0,1,1,1,1,0,0,0,1,0,1,0,1,0,1,0,1,0,0,1,1,1,0,0,0,1,1,0,0,0,1,0]

theorem envBound21185 : H12AffineFastState.Bounded env21185 := by
  intro p hp
  have h : env21185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21184_21185 : H12AffineEnvironment.transform 1 1 env21184 = env21185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env21184 == env21185) = true)

def env21186 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,115871,272512,119967,98701,8328,17,121862,115102,17665,357643,119042,329731,257,21793,46213,63108]

theorem envBound21186 : H12AffineFastState.Bounded env21186 := by
  intro p hp
  have h : env21186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21168_21186 : H12AffineEnvironment.transform 5 17 env21168 = env21186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21168 == env21186) = true)

theorem identity21186 : scanCanonicalize (H12AffineFastState.compose env21186 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound21186 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21187 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,2477,1025,32769,115871,8493,119967,98701,8328,17,121862,115102,17665,97446,119042,65966,257,21793,46213,63108]

theorem envBound21187 : H12AffineFastState.Bounded env21187 := by
  intro p hp
  have h : env21187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21186_21187 : H12AffineEnvironment.transform 17 2477 env21186 = env21187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env21186 == env21187) = true)

theorem identity21187 : scanCanonicalize (H12AffineFastState.compose env21187 (packedSelected [0,3,9,10,17,19,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound21187 : packedSelected [0,3,9,10,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env21188 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,65536,24981,2477,1025,29709,77971,8493,73875,95617,8328,17,75786,79250,17665,97446,75022,65966,257,21793,16521,648]

theorem envBound21188 : H12AffineFastState.Bounded env21188 := by
  intro p hp
  have h : env21188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21187_21188 : H12AffineEnvironment.transform 14 29708 env21187 = env21188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env21187 == env21188) = true)

theorem identity21188 : scanCanonicalize (H12AffineFastState.compose env21188 (packedSelected [1,2,3,4,5,6,8,10,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21188 : packedSelected [1,2,3,4,5,6,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21189 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,65536,24860,2340,1025,29709,77850,8493,73754,95496,8193,17,75786,79131,17665,97327,75022,65831,257,21793,16384,513]

theorem envBound21189 : H12AffineFastState.Bounded env21189 := by
  intro p hp
  have h : env21189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21188_21189 : H12AffineEnvironment.transform 6 9 env21188 = env21189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21188 == env21189) = true)

theorem identity21189 : scanCanonicalize (H12AffineFastState.compose env21189 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21189 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env21190 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,65536,16400,2340,1025,21761,69910,33,65814,87044,269,17,67846,70679,17665,89379,66562,65831,257,21793,16384,513]

theorem envBound21190 : H12AffineFastState.Bounded env21190 := by
  intro p hp
  have h : env21190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21189_21190 : H12AffineEnvironment.transform 12 268 env21189 = env21190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21189 == env21190) = true)

theorem identity21190 : scanCanonicalize (H12AffineFastState.compose env21190 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound21190 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21191 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,21511,16400,2340,1025,21761,17681,33,21777,3,269,17,23809,16400,17665,2340,20485,21792,257,21793,16384,513]

theorem envBound21191 : H12AffineFastState.Bounded env21191 := by
  intro p hp
  have h : env21191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21190_21191 : H12AffineEnvironment.transform 15 21511 env21190 = env21191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env21190 == env21191) = true)

theorem identity21191 : scanCanonicalize (H12AffineFastState.compose env21191 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21191 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21192 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2340,1025,1,4113,33,17,3,269,17,2049,5392,4097,2340,1285,32,257,33,5376,513]

theorem envBound21192 : H12AffineFastState.Bounded env21192 := by
  intro p hp
  have h : env21192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21191_21192 : H12AffineEnvironment.transform 13 5376 env21191 = env21192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21191 == env21192) = true)

theorem identity21192 : scanCanonicalize (H12AffineFastState.compose env21192 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21192 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21193 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,4096,268,4356,0,263,4372,2340,5,1,4113,33,17,3,269,17,2049,4372,4097,2340,257,32,257,33,4356,513]

theorem envBound21193 : H12AffineFastState.Bounded env21193 := by
  intro p hp
  have h : env21193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21192_21193 : H12AffineEnvironment.transform 9 4 env21192 = env21193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21192 == env21193) = true)

theorem identity21193 : scanCanonicalize (H12AffineFastState.compose env21193 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2319) := by decide +kernel

theorem selectedBound21193 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21194 : List Nat := [2,4,8,16,32,17,9,256,512,4,2048,2319,268,2059,0,263,2075,2340,5,1,2334,33,17,3,269,17,2049,2075,2318,2340,257,32,257,33,2059,513]

theorem envBound21194 : H12AffineFastState.Bounded env21194 := by
  intro p hp
  have h : env21194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21193_21194 : H12AffineEnvironment.transform 11 2319 env21193 = env21194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2319 env21193 == env21194) = true)

theorem identity21194 : scanCanonicalize (H12AffineFastState.compose env21194 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound21194 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21195 : List Nat := [2,4,8,16,32,17,9,256,512,4,783,512,268,772,0,263,788,555,5,1,529,33,17,3,269,17,782,788,513,555,257,32,257,33,772,513]

theorem envBound21195 : H12AffineFastState.Bounded env21195 := by
  intro p hp
  have h : env21195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21194_21195 : H12AffineEnvironment.transform 10 783 env21194 = env21195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env21194 == env21195) = true)

theorem identity21195 : scanCanonicalize (H12AffineFastState.compose env21195 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21195 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21196 : List Nat := [2,4,8,16,32,17,9,37,512,4,554,512,41,545,0,34,561,555,5,1,529,33,17,3,40,17,555,561,513,555,36,32,36,33,545,513]

theorem envBound21196 : H12AffineFastState.Bounded env21196 := by
  intro p hp
  have h : env21196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21195_21196 : H12AffineEnvironment.transform 7 37 env21195 = env21196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21195 == env21196) = true)

theorem identity21196 : scanCanonicalize (H12AffineFastState.compose env21196 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound21196 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21197 : List Nat := [2,4,8,11,32,10,9,37,512,4,554,512,41,545,0,34,554,555,5,1,522,33,10,3,40,10,555,554,513,555,36,32,36,33,545,513]

theorem envBound21197 : H12AffineFastState.Bounded env21197 := by
  intro p hp
  have h : env21197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21196_21197 : H12AffineEnvironment.transform 3 11 env21196 = env21197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env21196 == env21197) = true)

theorem identity21197 : scanCanonicalize (H12AffineFastState.compose env21197 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound21197 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21198 : List Nat := [2,2,8,11,32,10,9,35,512,2,554,512,41,545,0,34,554,555,3,1,522,33,10,3,40,10,555,554,513,555,34,32,34,33,545,513]

theorem envBound21198 : H12AffineFastState.Bounded env21198 := by
  intro p hp
  have h : env21198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21197_21198 : H12AffineEnvironment.transform 1 2 env21197 = env21198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env21197 == env21198) = true)

theorem identity21198 : scanCanonicalize (H12AffineFastState.compose env21198 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21198 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env21199 : List Nat := [2,2,8,11,0,10,9,3,512,2,522,512,9,513,0,2,522,523,3,1,522,1,10,3,8,10,523,522,513,523,2,0,2,1,513,513]

theorem envBound21199 : H12AffineFastState.Bounded env21199 := by
  intro p hp
  have h : env21199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21198_21199 : H12AffineEnvironment.transform 4 0 env21198 = env21199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21198 == env21199) = true)

def env21200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,121942,115151,17665,2404756,119042,329730,257,2199998,2191386,63189]

theorem envBound21200 : H12AffineFastState.Bounded env21200 := by
  intro p hp
  have h : env21200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21166_21200 : H12AffineEnvironment.transform 21 272513 env21166 = env21200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21166 == env21200) = true)

theorem identity21200 : scanCanonicalize (H12AffineFastState.compose env21200 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound21200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,25028,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,2185,5392,17665,2404756,1501,318685,257,2114913,2139333,63189]

theorem envBound21201 : H12AffineFastState.Bounded env21201 := by
  intro p hp
  have h : env21201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21200_21201 : H12AffineEnvironment.transform 15 54495 env21200 = env21201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env21200 == env21201) = true)

theorem identity21201 : scanCanonicalize (H12AffineFastState.compose env21201 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21201 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25028,262144,1025,29909,2097152,272513,2101329,2114883,8328,64,2185,5392,17665,2377024,1501,272393,257,2114913,2117649,513]

theorem envBound21202 : H12AffineFastState.Bounded env21202 := by
  intro p hp
  have h : env21202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21201_21202 : H12AffineEnvironment.transform 14 29908 env21201 = env21202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21201 == env21202) = true)

theorem identity21202 : scanCanonicalize (H12AffineFastState.compose env21202 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound21202 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env21203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25028,262144,1025,29909,25629,272513,29772,8542,8328,64,2185,5392,17665,270685,1501,272393,257,8572,13324,513]

theorem envBound21203 : H12AffineFastState.Bounded env21203 := by
  intro p hp
  have h : env21203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21202_21203 : H12AffineEnvironment.transform 20 25629 env21202 = env21203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env21202 == env21203) = true)

theorem identity21203 : scanCanonicalize (H12AffineFastState.compose env21203 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 23805) := by decide +kernel

theorem selectedBound21203 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env21204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,25028,23805,1025,29909,25629,29820,29772,8542,8328,64,2185,5392,17665,32160,1501,29940,257,8572,13324,513]

theorem envBound21204 : H12AffineFastState.Bounded env21204 := by
  intro p hp
  have h : env21204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21203_21204 : H12AffineEnvironment.transform 17 23805 env21203 = env21204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23805 env21203 == env21204) = true)

theorem identity21204 : scanCanonicalize (H12AffineFastState.compose env21204 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound21204 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env21205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,478,16401,23805,1025,21760,17864,21929,21913,139,349,64,2185,5392,17665,23669,1501,21793,257,169,5593,513]

theorem envBound21205 : H12AffineFastState.Bounded env21205 := by
  intro p hp
  have h : env21205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21204_21205 : H12AffineEnvironment.transform 12 469 env21204 = env21205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env21204 == env21205) = true)

theorem identity21205 : scanCanonicalize (H12AffineFastState.compose env21205 (packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21205 : packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env21206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,478,5529,2421,1025,136,4160,33,17,139,349,64,2185,5392,4233,2557,1501,169,257,169,5593,513]

theorem envBound21206 : H12AffineFastState.Bounded env21206 := by
  intro p hp
  have h : env21206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21205_21206 : H12AffineEnvironment.transform 13 5512 env21205 = env21206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21205 == env21206) = true)

def env21207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066246,115150,10507600,8692164,10600786,4268162,257,8487406,8478794,10544773]

theorem envBound21207 : H12AffineFastState.Bounded env21207 := by
  intro p hp
  have h : env21207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21123_21207 : H12AffineEnvironment.transform 16 25029 env21123 = env21207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env21123 == env21207) = true)

def env21208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4584662,115150,17664,2404756,119042,4268162,257,2199998,2191386,63189]

theorem envBound21208 : H12AffineFastState.Bounded env21208 := by
  intro p hp
  have h : env21208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21207_21208 : H12AffineEnvironment.transform 22 2101328 env21207 = env21208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21207 == env21208) = true)

def env21209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,121942,115150,17664,2404756,119042,329730,257,2199998,2191386,63189]

theorem envBound21209 : H12AffineFastState.Bounded env21209 := by
  intro p hp
  have h : env21209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21208_21209 : H12AffineEnvironment.transform 21 272512 env21208 = env21209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21208 == env21209) = true)

theorem identity21209 : scanCanonicalize (H12AffineFastState.compose env21209 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21209 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,262144,1025,29909,2097152,272512,2101328,2114882,8328,64,75906,79130,17664,2377024,75222,329730,257,2188650,2191386,513]

theorem envBound21210 : H12AffineFastState.Bounded env21210 := by
  intro p hp
  have h : env21210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21209_21210 : H12AffineEnvironment.transform 14 29908 env21209 = env21210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21209 == env21210) = true)

def env21211 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,2097152,272512,2101248,2114834,8328,16,75906,79130,17664,2376976,75142,329730,257,2188602,2191386,513]

theorem envBound21211 : H12AffineFastState.Bounded env21211 := by
  intro p hp
  have h : env21211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21210_21211 : H12AffineEnvironment.transform 5 16 env21210 = env21211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21210 == env21211) = true)

def env21212 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,24861,262144,1025,29709,2097152,272392,2101248,2114834,8192,16,75786,79130,17664,2376976,75022,329730,257,2188602,2191386,513]

theorem envBound21212 : H12AffineFastState.Bounded env21212 := by
  intro p hp
  have h : env21212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21211_21212 : H12AffineEnvironment.transform 6 8 env21211 = env21212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21211 == env21212) = true)

theorem identity21212 : scanCanonicalize (H12AffineFastState.compose env21212 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21212 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env21213 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29708,65536,24633,262144,1025,29709,2097152,272392,2101248,2114614,8192,16,75786,78910,17444,2376756,74794,329730,37,2188318,2191386,513]

theorem envBound21213 : H12AffineFastState.Bounded env21213 := by
  intro p hp
  have h : env21213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21212_21213 : H12AffineEnvironment.transform 7 36 env21212 = env21213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21212 == env21213) = true)

theorem identity21213 : scanCanonicalize (H12AffineFastState.compose env21213 (packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound21213 : packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env21214 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29708,35,24633,262144,1025,29709,2097152,272392,2101248,2114614,8192,16,10281,13341,17444,2376756,9225,264225,37,2122813,2125881,513]

theorem envBound21214 : H12AffineFastState.Bounded env21214 := by
  intro p hp
  have h : env21214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21213_21214 : H12AffineEnvironment.transform 15 35 env21213 = env21214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env21213 == env21214) = true)

theorem identity21214 : scanCanonicalize (H12AffineFastState.compose env21214 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 288808) := by decide +kernel

theorem selectedBound21214 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21215 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,29708,35,24633,262144,1025,29709,288808,272392,292904,273438,8192,16,10281,13341,17444,11292,9225,264225,37,265237,268305,513]

theorem envBound21215 : H12AffineFastState.Bounded env21215 := by
  intro p hp
  have h : env21215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21214_21215 : H12AffineEnvironment.transform 20 288808 env21214 = env21215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 288808 env21214 == env21215) = true)

theorem identity21215 : scanCanonicalize (H12AffineFastState.compose env21215 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound21215 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env21216 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,16384,20496,35,17445,262144,1025,20497,281652,265236,285748,264194,1052,16,3125,4097,17444,2048,21,264225,37,265237,268305,513]

theorem envBound21216 : H12AffineFastState.Bounded env21216 := by
  intro p hp
  have h : env21216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21215_21216 : H12AffineEnvironment.transform 12 1052 env21215 = env21216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env21215 == env21216) = true)

theorem identity21216 : scanCanonicalize (H12AffineFastState.compose env21216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 22544) := by decide +kernel

theorem selectedBound21216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21217 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,16384,20496,35,17445,22544,1025,20497,5156,21508,1060,20498,1052,16,3125,4097,17444,2048,21,20529,37,21509,16385,513]

theorem envBound21217 : H12AffineFastState.Bounded env21217 := by
  intro p hp
  have h : env21217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21216_21217 : H12AffineEnvironment.transform 17 22544 env21216 = env21217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22544 env21216 == env21217) = true)

theorem identity21217 : scanCanonicalize (H12AffineFastState.compose env21217 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 7220) := by decide +kernel

theorem selectedBound21217 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env21218 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,7220,3108,35,6161,1060,1025,3109,5156,2096,1060,3110,1052,16,3125,4097,6160,2048,21,3077,37,2097,7221,513]

theorem envBound21218 : H12AffineFastState.Bounded env21218 := by
  intro p hp
  have h : env21218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21217_21218 : H12AffineEnvironment.transform 13 7220 env21217 = env21218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7220 env21217 == env21218) = true)

theorem identity21218 : scanCanonicalize (H12AffineFastState.compose env21218 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21218 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21219 : List Nat := [2,4,8,0,32,0,8,36,512,1024,2048,4096,1036,7204,3108,35,6145,1060,1025,3109,5156,2080,1060,3110,1036,0,3109,4097,6144,2048,5,3077,37,2081,7205,513]

theorem envBound21219 : H12AffineFastState.Bounded env21219 := by
  intro p hp
  have h : env21219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21218_21219 : H12AffineEnvironment.transform 3 0 env21218 = env21219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21218 == env21219) = true)

theorem identity21219 : scanCanonicalize (H12AffineFastState.compose env21219 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound21219 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21220 : List Nat := [2,4,8,0,32,0,8,36,512,1024,2048,3108,1036,0,3108,35,1061,1060,1025,3109,2048,2080,1060,3110,1036,0,3109,3109,1060,2048,5,3077,37,2081,1,513]

theorem envBound21220 : H12AffineFastState.Bounded env21220 := by
  intro p hp
  have h : env21220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21219_21220 : H12AffineEnvironment.transform 11 3108 env21219 = env21220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env21219 == env21220) = true)

theorem identity21220 : scanCanonicalize (H12AffineFastState.compose env21220 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound21220 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env21221 : List Nat := [2,4,8,0,32,0,8,36,512,1024,513,1573,1036,0,1573,35,1061,1060,1025,1572,513,545,1060,1575,1036,0,1572,1572,1060,513,5,1540,37,544,1,513]

theorem envBound21221 : H12AffineFastState.Bounded env21221 := by
  intro p hp
  have h : env21221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21220_21221 : H12AffineEnvironment.transform 10 513 env21220 = env21221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env21220 == env21221) = true)

def env21222 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,24860,262144,1025,29708,2097152,272393,2101248,2114834,8193,16,75787,79130,17664,2376976,75023,329730,257,2188602,2191386,513]

theorem envBound21222 : H12AffineFastState.Bounded env21222 := by
  intro p hp
  have h : env21222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21211_21222 : H12AffineEnvironment.transform 6 9 env21211 = env21222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21211 == env21222) = true)

theorem identity21222 : scanCanonicalize (H12AffineFastState.compose env21222 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound21222 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env21223 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,29963,24860,262144,1025,29708,2097152,272393,2101248,2114834,8193,16,23808,16401,17664,2376976,20484,294153,257,2101297,2098449,513]

theorem envBound21223 : H12AffineFastState.Bounded env21223 := by
  intro p hp
  have h : env21223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21222_21223 : H12AffineEnvironment.transform 15 29963 env21222 = env21223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env21222 == env21223) = true)

theorem identity21223 : scanCanonicalize (H12AffineFastState.compose env21223 (packedSelected [0,3,4,5,7,9,10,12,14,15,17,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 290104) := by decide +kernel

theorem selectedBound21223 : packedSelected [0,3,4,5,7,9,10,12,14,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env21224 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,29963,24860,262144,1025,29708,290104,272393,294200,272426,8193,16,23808,16401,17664,10280,20484,294153,257,294153,288809,513]

theorem envBound21224 : H12AffineFastState.Bounded env21224 := by
  intro p hp
  have h : env21224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21223_21224 : H12AffineEnvironment.transform 20 290104 env21223 = env21224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290104 env21223 == env21224) = true)

theorem identity21224 : scanCanonicalize (H12AffineFastState.compose env21224 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound21224 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21225 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,29963,24860,2341,1025,29708,25629,8492,29725,8463,8193,16,23808,16401,17664,10280,20484,29740,257,29740,24844,513]

theorem envBound21225 : H12AffineFastState.Bounded env21225 := by
  intro p hp
  have h : env21225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21224_21225 : H12AffineEnvironment.transform 17 2341 env21224 = env21225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env21224 == env21225) = true)

theorem identity21225 : scanCanonicalize (H12AffineFastState.compose env21225 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21225 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21226 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,263,5392,2341,1025,0,4113,8492,17,8463,8193,16,10508,13341,12556,10280,9224,32,257,32,5376,513]

theorem envBound21226 : H12AffineFastState.Bounded env21226 := by
  intro p hp
  have h : env21226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21225_21226 : H12AffineEnvironment.transform 13 13324 env21225 = env21226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21225 == env21226) = true)

def env21227 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,2097152,272512,2101249,2114835,8328,17,75906,79130,17664,2376977,75143,329730,257,2188603,2191386,513]

theorem envBound21227 : H12AffineFastState.Bounded env21227 := by
  intro p hp
  have h : env21227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21210_21227 : H12AffineEnvironment.transform 5 17 env21210 = env21227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21210 == env21227) = true)

theorem identity21227 : scanCanonicalize (H12AffineFastState.compose env21227 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21227 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env21228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,10280,1025,29828,2097152,168,2101249,2114835,8328,17,75906,79130,17664,2125113,75143,73770,257,2188603,2191386,513]

theorem envBound21228 : H12AffineFastState.Bounded env21228 := by
  intro p hp
  have h : env21228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21227_21228 : H12AffineEnvironment.transform 17 10280 env21227 = env21228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21227 == env21228) = true)

theorem identity21228 : scanCanonicalize (H12AffineFastState.compose env21228 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound21228 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env21229 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21760,65536,16401,2477,1025,21761,2097152,168,2101249,2114835,269,17,67847,70815,17664,2116796,66562,65967,257,2180286,2183583,513]

theorem envBound21229 : H12AffineFastState.Bounded env21229 := by
  intro p hp
  have h : env21229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21228_21229 : H12AffineEnvironment.transform 12 389 env21228 = env21229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env21228 == env21229) = true)

theorem identity21229 : scanCanonicalize (H12AffineFastState.compose env21229 (packedSelected [2,6,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21229 : packedSelected [2,6,16,17,20] rootPS < 2^1333 := by decide +kernel

def env21230 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,65536,5393,2477,1025,1,2097152,168,2101249,2101267,269,17,67847,70815,4096,2103740,66562,65967,257,2167230,2163871,513]

theorem envBound21230 : H12AffineFastState.Bounded env21230 := by
  intro p hp
  have h : env21230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21229_21230 : H12AffineEnvironment.transform 13 5376 env21229 = env21230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21229 == env21230) = true)

theorem identity21230 : scanCanonicalize (H12AffineFastState.compose env21230 (packedSelected [2,6,17] rootPS)) = affineNative (2^(20+1) ^^^ 4249) := by decide +kernel

theorem selectedBound21230 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env21231 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,65536,5393,2477,1025,1,4249,168,152,138,269,17,67847,70815,4096,2341,66562,65967,257,65831,70662,513]

theorem envBound21231 : H12AffineFastState.Bounded env21231 := by
  intro p hp
  have h : env21231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21230_21231 : H12AffineEnvironment.transform 20 4249 env21230 = env21231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4249 env21230 == env21231) = true)

theorem identity21231 : scanCanonicalize (H12AffineFastState.compose env21231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21232 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,262,5393,2477,1025,1,4249,168,152,138,269,17,2049,5529,4096,2341,1284,169,257,33,5376,513]

theorem envBound21232 : H12AffineFastState.Bounded env21232 := by
  intro p hp
  have h : env21232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21231_21232 : H12AffineEnvironment.transform 15 262 env21231 = env21232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21231 == env21232) = true)

theorem identity21232 : scanCanonicalize (H12AffineFastState.compose env21232 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound21232 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env21233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2325,389,3093,0,262,3076,2477,1025,1,2444,168,152,138,269,17,2049,3212,2325,2341,1284,169,257,33,3093,513]

theorem envBound21233 : H12AffineFastState.Bounded env21233 := by
  intro p hp
  have h : env21233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21232_21233 : H12AffineEnvironment.transform 11 2325 env21232 = env21233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env21232 == env21233) = true)

theorem identity21233 : scanCanonicalize (H12AffineFastState.compose env21233 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21233 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21234 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2325,389,2081,0,262,2096,2477,53,1,2444,168,152,138,269,17,2049,2232,2325,2341,304,169,257,33,2081,513]

theorem envBound21234 : H12AffineFastState.Bounded env21234 := by
  intro p hp
  have h : env21234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21233_21234 : H12AffineEnvironment.transform 9 52 env21233 = env21234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21233 == env21234) = true)

def env21235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,121943,115150,17664,2404756,119042,329731,257,2199998,2191386,63189]

theorem envBound21235 : H12AffineFastState.Bounded env21235 := by
  intro p hp
  have h : env21235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21208_21235 : H12AffineEnvironment.transform 21 272513 env21208 = env21235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21208 == env21235) = true)

theorem identity21235 : scanCanonicalize (H12AffineFastState.compose env21235 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound21235 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,58517,272513,62661,41431,8328,64,121943,115150,17664,283905,119042,329731,257,95531,103567,63189]

theorem envBound21236 : H12AffineFastState.Bounded env21236 := by
  intro p hp
  have h : env21236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21235_21236 : H12AffineEnvironment.transform 20 58517 env21235 = env21236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env21235 == env21236) = true)

def env21237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4584663,115150,17665,2404757,119043,4268162,257,2199999,2191387,63188]

theorem envBound21237 : H12AffineFastState.Bounded env21237 := by
  intro p hp
  have h : env21237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21207_21237 : H12AffineEnvironment.transform 22 2101329 env21207 = env21237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21207 == env21237) = true)

def env21238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,121943,115150,17665,2404757,119043,329730,257,2199999,2191387,63188]

theorem envBound21238 : H12AffineFastState.Bounded env21238 := by
  intro p hp
  have h : env21238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21237_21238 : H12AffineEnvironment.transform 21 272512 env21237 = env21238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21237 == env21238) = true)

def env21239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,121943,115014,17665,2404637,119043,329730,257,2199863,2191387,63068]

theorem envBound21239 : H12AffineFastState.Bounded env21239 := by
  intro p hp
  have h : env21239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21238_21239 : H12AffineEnvironment.transform 6 8 env21238 = env21239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21238 == env21239) = true)

def env21240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272392,17,21762,8192,64,121943,115014,17665,303453,119043,329730,257,98679,90203,63068]

theorem envBound21240 : H12AffineFastState.Bounded env21240 := by
  intro p hp
  have h : env21240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21239_21240 : H12AffineEnvironment.transform 20 4160 env21239 = env21240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21239 == env21240) = true)

theorem identity21240 : scanCanonicalize (H12AffineFastState.compose env21240 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound21240 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32040,1025,32769,4160,21792,17,21762,8192,64,121943,115014,17665,56437,119043,95530,257,98679,90203,63068]

theorem envBound21241 : H12AffineFastState.Bounded env21241 := by
  intro p hp
  have h : env21241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21240_21241 : H12AffineEnvironment.transform 17 32040 env21240 = env21241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env21240 == env21241) = true)

theorem identity21241 : scanCanonicalize (H12AffineFastState.compose env21241 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound21241 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,24909,32040,1025,32769,4160,21792,17,21762,8192,64,31836,24909,17665,56437,28936,54561,257,8572,49232,63068]

theorem envBound21242 : H12AffineFastState.Bounded env21242 := by
  intro p hp
  have h : env21242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21241_21242 : H12AffineEnvironment.transform 15 40971 env21241 = env21242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env21241 == env21242) = true)

theorem identity21242 : scanCanonicalize (H12AffineFastState.compose env21242 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21242 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env21243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,24909,32040,1025,8541,4160,21792,17,21762,8192,64,31836,24909,17665,32041,28936,29821,257,8572,24844,22272]

theorem envBound21243 : H12AffineFastState.Bounded env21243 := by
  intro p hp
  have h : env21243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21242_21243 : H12AffineEnvironment.transform 14 8540 env21242 = env21243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21242 == env21243) = true)

theorem identity21243 : scanCanonicalize (H12AffineFastState.compose env21243 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21243 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env21244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,343,5392,2421,1025,8541,4160,8573,17,8543,8192,64,2049,5392,12636,2420,1365,32,257,8572,5457,9053]

theorem envBound21244 : H12AffineFastState.Bounded env21244 := by
  intro p hp
  have h : env21244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21243_21244 : H12AffineEnvironment.transform 13 13405 env21243 = env21244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21243 == env21244) = true)

theorem identity21244 : scanCanonicalize (H12AffineFastState.compose env21244 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21244 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1025,0,4160,32,17,2,349,64,2049,5392,4097,2420,1365,32,257,33,5457,512]

theorem envBound21245 : H12AffineFastState.Bounded env21245 := by
  intro p hp
  have h : env21245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21244_21245 : H12AffineEnvironment.transform 12 349 env21244 = env21245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21244 == env21245) = true)

theorem identity21245 : scanCanonicalize (H12AffineFastState.compose env21245 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound21245 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,863,4096,349,5376,1,343,5392,554,1025,0,4160,32,17,2,349,64,862,5392,4097,555,1365,32,257,33,5457,512]

theorem envBound21246 : H12AffineFastState.Bounded env21246 := by
  intro p hp
  have h : env21246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21245_21246 : H12AffineEnvironment.transform 10 863 env21245 = env21246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env21245 == env21246) = true)

theorem identity21246 : scanCanonicalize (H12AffineFastState.compose env21246 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21246 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21247 : List Nat := [2,4,8,16,32,49,8,256,512,1024,814,4096,300,5376,1,294,5392,554,1025,0,4145,32,17,2,300,49,815,5392,4097,555,1316,32,257,33,5408,512]

end H12CloudChart1