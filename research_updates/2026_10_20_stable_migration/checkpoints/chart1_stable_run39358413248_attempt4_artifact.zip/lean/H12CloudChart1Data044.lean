import H12CloudChart1Data043

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity10995 : scanCanonicalize (H12AffineFastState.compose env10995 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10995 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10996 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,32,65536,131072,67619,1025,33,4161,65539,65555,3,41,65,138340,70758,69635,138340,1057,32,116,33,5124,66083]

theorem envBound10996 : H12AffineFastState.Bounded env10996 := by
  intro p hp
  have h : env10996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10995_10996 : H12AffineEnvironment.transform 7 117 env10995 = env10996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10995 == env10996) = true)

theorem identity10996 : scanCanonicalize (H12AffineFastState.compose env10996 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10996 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10997 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,32,65536,131072,67619,1025,33,4113,65539,65555,3,41,17,138292,70710,69635,138292,1057,32,36,33,5124,66083]

theorem envBound10997 : H12AffineFastState.Bounded env10997 := by
  intro p hp
  have h : env10997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10996_10997 : H12AffineEnvironment.transform 5 16 env10996 = env10997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10996 == env10997) = true)

theorem identity10997 : scanCanonicalize (H12AffineFastState.compose env10997 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound10997 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10998 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,32,35,131072,2048,1025,33,4113,32,48,3,41,17,138292,5141,4128,138292,1057,32,36,33,5124,512]

theorem envBound10998 : H12AffineFastState.Bounded env10998 := by
  intro p hp
  have h : env10998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10997_10998 : H12AffineEnvironment.transform 15 35 env10997 = env10998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env10997 == env10998) = true)

theorem identity10998 : scanCanonicalize (H12AffineFastState.compose env10998 (packedSelected [0,2,7] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound10998 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10999 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,32,35,5140,2048,1025,33,4113,32,48,3,41,17,2080,5141,4128,2080,1057,32,36,33,5124,512]

theorem envBound10999 : H12AffineFastState.Bounded env10999 := by
  intro p hp
  have h : env10999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10998_10999 : H12AffineEnvironment.transform 16 5140 env10998 = env10999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env10998 == env10999) = true)

theorem identity10999 : scanCanonicalize (H12AffineFastState.compose env10999 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10999 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11000 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,1,2,5140,2048,1025,0,4113,1,17,3,8,17,2049,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound11000 : H12AffineFastState.Bounded env11000 := by
  intro p hp
  have h : env11000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10999_11000 : H12AffineEnvironment.transform 4 1 env10999 = env11000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10999 == env11000) = true)

def env11001 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,1,2,1028,2048,1025,0,1,1,17,3,8,17,2049,1029,17,2049,1024,1,5,0,1044,512]

theorem envBound11001 : H12AffineFastState.Bounded env11001 := by
  intro p hp
  have h : env11001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11000_11001 : H12AffineEnvironment.transform 11 16 env11000 = env11001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11000 == env11001) = true)

theorem identity11001 : scanCanonicalize (H12AffineFastState.compose env11001 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11002 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,9,1,1,2,17,2048,20,0,1,1,17,3,8,17,2049,16,17,2049,21,1,5,0,1,512]

theorem envBound11002 : H12AffineFastState.Bounded env11002 := by
  intro p hp
  have h : env11002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11001_11002 : H12AffineEnvironment.transform 9 21 env11001 = env11002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11001 == env11002) = true)

theorem identity11002 : scanCanonicalize (H12AffineFastState.compose env11002 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound11002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11003 : List Nat := [2,4,8,16,1,16,9,4,512,21,542,16,9,1,1,2,17,542,20,0,1,1,17,3,8,17,543,16,17,543,21,1,5,0,1,512]

theorem envBound11003 : H12AffineFastState.Bounded env11003 := by
  intro p hp
  have h : env11003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11002_11003 : H12AffineEnvironment.transform 10 542 env11002 = env11003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env11002 == env11003) = true)

def leafEnv11003 : List Nat := [2,4,8,16,1,16,9,4,512,21,542,16,9,1,1,2,17,542,20,0,1,1,17,3,20,8,1,17,543,16,17,543,21,1,5,0,5,3,1,512,1,1,0]

def active11003 : List Nat := [0,1,2,3,8]

def tree11003 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11003 : H12WitnessSearch.Good tree11003 := H12GlobalWitnessIndex.good

theorem leafIdentity11003 : H12AffineFastState.composeSystem env11003 rootObs = leafEnv11003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11003 rootObs == leafEnv11003) = true)

theorem terminalChecked11003 : H12PackedTerminal.terminalCheckFast leafEnv11003 active11003 tree11003 = true := by decide +kernel

def env11004 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,1,2,1029,2048,1025,0,0,1,17,3,8,17,2049,1028,16,2049,1024,1,5,0,1045,512]

theorem envBound11004 : H12AffineFastState.Bounded env11004 := by
  intro p hp
  have h : env11004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11000_11004 : H12AffineEnvironment.transform 11 17 env11000 = env11004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11000 == env11004) = true)

def env11005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound11005 : H12AffineFastState.Bounded env11005 := by
  intro p hp
  have h : env11005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10628_11005 : H12AffineEnvironment.transform 26 30393345 env10628 = env11005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env10628 == env11005) = true)

def env11006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound11006 : H12AffineFastState.Bounded env11006 := by
  intro p hp
  have h : env11006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11005_11006 : H12AffineEnvironment.transform 18 1024 env11005 = env11006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11005 == env11006) = true)

theorem identity11006 : scanCanonicalize (H12AffineFastState.compose env11006 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898729) := by decide +kernel

theorem selectedBound11006 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898729,8328,65,4196520,10898469,10507601,8830977,412856,15117672,256,2493445,2551201,486255]

theorem envBound11007 : H12AffineFastState.Bounded env11007 := by
  intro p hp
  have h : env11007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11006_11007 : H12AffineEnvironment.transform 23 8898729 env11006 = env11007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898729 env11006 == env11007) = true)

def env11008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,8388608,8898729,8328,65,4196520,8393985,8785013,8830977,412856,12645452,256,21793,46213,486255]

theorem envBound11008 : H12AffineFastState.Bounded env11008 := by
  intro p hp
  have h : env11008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11007_11008 : H12AffineEnvironment.transform 20 416036 env11007 = env11008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416036 env11007 == env11008) = true)

def env11009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441760,95497,8328,65,4196520,436385,45525,32161,412856,4606444,256,21793,46213,486255]

theorem envBound11009 : H12AffineFastState.Bounded env11009 := by
  intro p hp
  have h : env11009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11008_11009 : H12AffineEnvironment.transform 22 441760 env11008 = env11009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env11008 == env11009) = true)

def env11010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441760,95497,8328,65,270376,436385,45525,32161,412856,156012,256,21793,46213,486255]

theorem envBound11010 : H12AffineFastState.Bounded env11010 := by
  intro p hp
  have h : env11010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11009_11010 : H12AffineEnvironment.transform 21 272512 env11009 = env11010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11009 == env11010) = true)

theorem identity11010 : scanCanonicalize (H12AffineFastState.compose env11010 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound11010 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,156132,62660,95497,8328,65,158028,57797,45525,32161,1500,156012,256,21793,46213,74251]

theorem envBound11011 : H12AffineFastState.Bounded env11011 := by
  intro p hp
  have h : env11011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11010_11011 : H12AffineEnvironment.transform 17 149860 env11010 = env11011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env11010 == env11011) = true)

theorem identity11011 : scanCanonicalize (H12AffineFastState.compose env11011 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11011 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env11012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,156132,62660,21763,8328,65,158028,57797,45525,32161,1500,156012,256,21793,46213,513]

theorem envBound11012 : H12AffineFastState.Bounded env11012 := by
  intro p hp
  have h : env11012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11011_11012 : H12AffineEnvironment.transform 15 8202 env11011 = env11012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11011 == env11012) = true)

theorem identity11012 : scanCanonicalize (H12AffineFastState.compose env11012 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound11012 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env11013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5528,23804,1024,32769,4160,29820,62660,21763,8328,65,31956,57797,45525,32161,1500,29940,256,21793,46213,513]

theorem envBound11013 : H12AffineFastState.Bounded env11013 := by
  intro p hp
  have h : env11013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11012_11013 : H12AffineEnvironment.transform 16 5528 env11012 = env11013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env11012 == env11013) = true)

theorem identity11013 : scanCanonicalize (H12AffineFastState.compose env11013 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound11013 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env11014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,479,5528,23804,1024,32769,4160,21929,54545,21763,349,65,23809,49168,36864,23668,1500,21793,256,21793,38224,513]

theorem envBound11014 : H12AffineFastState.Bounded env11014 := by
  intro p hp
  have h : env11014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11013_11014 : H12AffineEnvironment.transform 12 469 env11013 = env11014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env11013 == env11014) = true)

theorem identity11014 : scanCanonicalize (H12AffineFastState.compose env11014 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound11014 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env11015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5372,32768,479,5528,2048,1024,32769,4160,341,33261,511,349,65,2557,38124,36864,2184,1500,477,256,477,38224,513]

theorem envBound11015 : H12AffineFastState.Bounded env11015 := by
  intro p hp
  have h : env11015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11014_11015 : H12AffineEnvironment.transform 13 5372 env11014 = env11015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env11014 == env11015) = true)

theorem identity11015 : scanCanonicalize (H12AffineFastState.compose env11015 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound11015 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env11016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5372,373,479,5528,2048,1024,372,4160,341,152,511,349,65,2557,5529,4469,2184,1500,477,256,477,5157,513]

theorem envBound11016 : H12AffineFastState.Bounded env11016 := by
  intro p hp
  have h : env11016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11015_11016 : H12AffineEnvironment.transform 14 373 env11015 = env11016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env11015 == env11016) = true)

theorem identity11016 : scanCanonicalize (H12AffineFastState.compose env11016 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11016 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,373,343,5392,2048,1024,372,4160,341,16,375,349,65,2421,5393,4469,2048,1364,341,256,341,5157,513]

theorem envBound11017 : H12AffineFastState.Bounded env11017 := by
  intro p hp
  have h : env11017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11016_11017 : H12AffineEnvironment.transform 6 8 env11016 = env11017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11016 == env11017) = true)

theorem identity11017 : scanCanonicalize (H12AffineFastState.compose env11017 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11017 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11018 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,34,5221,2048,1024,1,4160,32,16,2,40,65,2048,5220,4096,2048,1057,32,117,32,5157,513]

theorem envBound11018 : H12AffineFastState.Bounded env11018 := by
  intro p hp
  have h : env11018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11017_11018 : H12AffineEnvironment.transform 7 117 env11017 = env11018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11017 == env11018) = true)

theorem identity11018 : scanCanonicalize (H12AffineFastState.compose env11018 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound11018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11019 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5236,0,34,5221,1134,1024,1,4160,32,16,2,40,65,1134,5220,4096,1134,1057,32,117,32,5157,513]

theorem envBound11019 : H12AffineFastState.Bounded env11019 := by
  intro p hp
  have h : env11019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11018_11019 : H12AffineEnvironment.transform 10 1134 env11018 = env11019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env11018 == env11019) = true)

theorem identity11019 : scanCanonicalize (H12AffineFastState.compose env11019 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound11019 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11020 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,1124,40,16,0,34,1,1134,1024,1,1060,32,16,2,40,65,1134,0,1124,1134,1057,32,117,32,65,513]

theorem envBound11020 : H12AffineFastState.Bounded env11020 := by
  intro p hp
  have h : env11020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11019_11020 : H12AffineEnvironment.transform 11 1124 env11019 = env11020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env11019 == env11020) = true)

theorem identity11020 : scanCanonicalize (H12AffineFastState.compose env11020 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound11020 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11021 : List Nat := [2,4,8,16,32,64,8,117,512,111,1,11,40,16,0,34,1,1,111,1,75,32,16,2,40,65,1,0,11,1,78,32,117,32,65,513]

theorem envBound11021 : H12AffineFastState.Bounded env11021 := by
  intro p hp
  have h : env11021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11020_11021 : H12AffineEnvironment.transform 9 111 env11020 = env11021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env11020 == env11021) = true)

theorem identity11021 : scanCanonicalize (H12AffineFastState.compose env11021 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11021 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11022 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,11,2,16,0,8,1,1,69,1,75,10,16,2,2,65,1,0,11,1,78,10,95,10,65,513]

theorem envBound11022 : H12AffineFastState.Bounded env11022 := by
  intro p hp
  have h : env11022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11021_11022 : H12AffineEnvironment.transform 4 10 env11021 = env11022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11021 == env11022) = true)

theorem identity11022 : scanCanonicalize (H12AffineFastState.compose env11022 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11022 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env11023 : List Nat := [2,4,8,16,10,17,8,14,512,20,1,11,2,16,0,8,1,1,20,1,26,10,16,2,2,16,1,0,11,1,31,10,14,10,16,513]

theorem envBound11023 : H12AffineFastState.Bounded env11023 := by
  intro p hp
  have h : env11023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11022_11023 : H12AffineEnvironment.transform 5 17 env11022 = env11023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11022 == env11023) = true)

theorem identity11023 : scanCanonicalize (H12AffineFastState.compose env11023 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11024 : List Nat := [2,4,8,11,10,10,8,14,512,15,1,11,2,11,0,8,1,1,15,1,1,10,11,2,2,11,1,0,11,1,4,10,14,10,11,513]

theorem envBound11024 : H12AffineFastState.Bounded env11024 := by
  intro p hp
  have h : env11024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11023_11024 : H12AffineEnvironment.transform 3 11 env11023 = env11024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11023 == env11024) = true)

theorem identity11024 : scanCanonicalize (H12AffineFastState.compose env11024 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound11024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11025 : List Nat := [2,4,6,5,4,4,6,0,512,1,1,5,2,5,0,6,1,1,1,1,1,4,5,2,2,5,1,0,5,1,4,4,0,4,5,513]

theorem envBound11025 : H12AffineFastState.Bounded env11025 := by
  intro p hp
  have h : env11025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11024_11025 : H12AffineEnvironment.transform 2 6 env11024 = env11025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env11024 == env11025) = true)

def env11026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441760,95497,8328,65,270377,436385,45525,32161,412856,156013,256,21793,46213,486255]

theorem envBound11026 : H12AffineFastState.Bounded env11026 := by
  intro p hp
  have h : env11026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11009_11026 : H12AffineEnvironment.transform 21 272513 env11009 = env11026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11009 == env11026) = true)

theorem identity11026 : scanCanonicalize (H12AffineFastState.compose env11026 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound11026 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416036,272513,412020,95497,8328,65,270377,416885,17665,32161,412856,156013,256,21793,16465,486255]

theorem envBound11027 : H12AffineFastState.Bounded env11027 := by
  intro p hp
  have h : env11027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11026_11027 : H12AffineEnvironment.transform 14 29908 env11026 = env11027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env11026 == env11027) = true)

def env11028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,160132,33,156116,95497,8328,65,2185,160981,17665,32161,156696,156013,256,21793,16465,213967]

theorem envBound11028 : H12AffineFastState.Bounded env11028 := by
  intro p hp
  have h : env11028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11027_11028 : H12AffineEnvironment.transform 17 10400 env11027 = env11028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11027 == env11028) = true)

theorem identity11028 : scanCanonicalize (H12AffineFastState.compose env11028 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound11028 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env11029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,10400,1024,29909,4161,33,17,95497,8328,65,2185,5392,17665,32161,1501,168,256,21793,16465,74250]

theorem envBound11029 : H12AffineFastState.Bounded env11029 := by
  intro p hp
  have h : env11029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11028_11029 : H12AffineEnvironment.transform 16 25029 env11028 = env11029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env11028 == env11029) = true)

theorem identity11029 : scanCanonicalize (H12AffineFastState.compose env11029 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound11029 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,65536,16401,2420,1024,21761,4161,33,17,87261,348,65,2185,5392,17665,23669,1501,168,256,21793,16465,66526]

theorem envBound11030 : H12AffineFastState.Bounded env11030 := by
  intro p hp
  have h : env11030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11029_11030 : H12AffineEnvironment.transform 12 468 env11029 = env11030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env11029 == env11030) = true)

def env11031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,160133,32,156117,95497,8328,65,2184,160980,17665,32161,156697,156013,256,21793,16465,213966]

theorem envBound11031 : H12AffineFastState.Bounded env11031 := by
  intro p hp
  have h : env11031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11027_11031 : H12AffineEnvironment.transform 17 10401 env11027 = env11031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11027 == env11031) = true)

theorem identity11031 : scanCanonicalize (H12AffineFastState.compose env11031 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound11031 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env11032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13625,10401,1024,29909,17596,32,21740,95497,8328,65,2184,16877,17665,32161,20768,21588,256,21793,16465,95991]

theorem envBound11032 : H12AffineFastState.Bounded env11032 := by
  intro p hp
  have h : env11032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11031_11032 : H12AffineEnvironment.transform 16 13625 env11031 = env11032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env11031 == env11032) = true)

theorem identity11032 : scanCanonicalize (H12AffineFastState.compose env11032 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound11032 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env11033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8232,65536,13625,10401,1024,8233,4160,32,16,74229,8328,65,2184,5393,4605,10589,1500,168,256,477,5293,74251]

theorem envBound11033 : H12AffineFastState.Bounded env11033 := by
  intro p hp
  have h : env11033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11032_11033 : H12AffineEnvironment.transform 13 5372 env11032 = env11033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env11032 == env11033) = true)

theorem identity11033 : scanCanonicalize (H12AffineFastState.compose env11033 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound11033 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env11034 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5372,8232,65536,13541,10401,1024,8233,4160,32,16,73769,8328,65,2184,5325,4129,10369,1024,168,220,1,5293,74251]

theorem envBound11034 : H12AffineFastState.Bounded env11034 := by
  intro p hp
  have h : env11034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11033_11034 : H12AffineEnvironment.transform 7 220 env11033 = env11034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env11033 == env11034) = true)

theorem identity11034 : scanCanonicalize (H12AffineFastState.compose env11034 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound11034 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env11035 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5372,8232,34,13541,10401,1024,8233,4160,32,16,8203,8328,65,2184,5325,4129,10369,1024,168,220,1,5293,8745]

theorem envBound11035 : H12AffineFastState.Bounded env11035 := by
  intro p hp
  have h : env11035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11034_11035 : H12AffineEnvironment.transform 15 34 env11034 = env11035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env11034 == env11035) = true)

theorem identity11035 : scanCanonicalize (H12AffineFastState.compose env11035 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11035 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env11036 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5341,8201,3,13508,10368,1024,8200,4160,1,16,8203,8328,65,2184,5325,4096,10369,1024,137,220,1,5260,8712]

theorem envBound11036 : H12AffineFastState.Bounded env11036 := by
  intro p hp
  have h : env11036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11035_11036 : H12AffineEnvironment.transform 4 1 env11035 = env11036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11035 == env11036) = true)

theorem identity11036 : scanCanonicalize (H12AffineFastState.compose env11036 (packedSelected [2,4,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11036 : packedSelected [2,4,9,12] rootPS < 2^1333 := by decide +kernel

def env11037 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8192,5204,8201,3,13389,10249,1024,8200,4160,1,16,8203,8193,65,2049,5188,4096,10248,1024,0,85,1,5125,8712]

theorem envBound11037 : H12AffineFastState.Bounded env11037 := by
  intro p hp
  have h : env11037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11036_11037 : H12AffineEnvironment.transform 6 9 env11036 = env11037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11036 == env11037) = true)

theorem identity11037 : scanCanonicalize (H12AffineFastState.compose env11037 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound11037 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11038 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8,5204,1,3,5189,2049,1024,0,4160,1,16,3,9,65,2049,5188,4096,2048,1024,0,85,1,5125,512]

theorem envBound11038 : H12AffineFastState.Bounded env11038 := by
  intro p hp
  have h : env11038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11037_11038 : H12AffineEnvironment.transform 12 8 env11037 = env11038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env11037 == env11038) = true)

theorem identity11038 : scanCanonicalize (H12AffineFastState.compose env11038 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound11038 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11039 : List Nat := [2,4,8,16,1,64,9,85,512,1024,523,4096,8,5204,1,3,5189,522,1024,0,4160,1,16,3,9,65,522,5188,4096,523,1024,0,85,1,5125,512]

theorem envBound11039 : H12AffineFastState.Bounded env11039 := by
  intro p hp
  have h : env11039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11038_11039 : H12AffineEnvironment.transform 10 523 env11038 = env11039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env11038 == env11039) = true)

theorem identity11039 : scanCanonicalize (H12AffineFastState.compose env11039 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11039 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11040 : List Nat := [2,4,8,16,1,17,9,4,512,1024,523,4096,8,5125,1,3,5140,522,1024,0,4113,1,16,3,9,16,522,5141,4096,523,1024,0,4,1,5125,512]

theorem envBound11040 : H12AffineFastState.Bounded env11040 := by
  intro p hp
  have h : env11040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11039_11040 : H12AffineEnvironment.transform 5 17 env11039 = env11040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11039 == env11040) = true)

theorem identity11040 : scanCanonicalize (H12AffineFastState.compose env11040 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11040 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11041 : List Nat := [2,4,8,16,1,17,9,4,512,20,523,4096,8,4113,1,3,4096,522,20,0,4113,1,16,3,9,16,522,4097,4096,523,20,0,4,1,4113,512]

theorem envBound11041 : H12AffineFastState.Bounded env11041 := by
  intro p hp
  have h : env11041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11040_11041 : H12AffineEnvironment.transform 9 20 env11040 = env11041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11040 == env11041) = true)

theorem identity11041 : scanCanonicalize (H12AffineFastState.compose env11041 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 31) := by decide +kernel

theorem selectedBound11041 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11042 : List Nat := [2,4,8,16,1,17,9,4,512,20,523,31,8,14,1,3,31,522,20,0,14,1,16,3,9,16,522,30,31,523,20,0,4,1,14,512]

theorem envBound11042 : H12AffineFastState.Bounded env11042 := by
  intro p hp
  have h : env11042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11041_11042 : H12AffineEnvironment.transform 11 31 env11041 = env11042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 31 env11041 == env11042) = true)

theorem identity11042 : scanCanonicalize (H12AffineFastState.compose env11042 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11043 : List Nat := [1,4,8,16,1,17,9,4,512,20,520,28,8,13,1,0,28,521,20,0,13,1,16,0,9,16,521,29,28,520,20,0,4,1,13,512]

theorem envBound11043 : H12AffineFastState.Bounded env11043 := by
  intro p hp
  have h : env11043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11042_11043 : H12AffineEnvironment.transform 0 1 env11042 = env11043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11042 == env11043) = true)

theorem identity11043 : scanCanonicalize (H12AffineFastState.compose env11043 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound11043 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11044 : List Nat := [1,4,5,16,1,17,4,4,512,20,517,17,5,0,1,0,17,516,20,0,0,1,16,0,4,16,516,16,17,517,20,0,4,1,0,512]

theorem envBound11044 : H12AffineFastState.Bounded env11044 := by
  intro p hp
  have h : env11044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11043_11044 : H12AffineEnvironment.transform 2 5 env11043 = env11044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env11043 == env11044) = true)

theorem identity11044 : scanCanonicalize (H12AffineFastState.compose env11044 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound11044 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11045 : List Nat := [1,4,5,16,1,17,4,4,5,20,0,17,5,0,1,0,17,1,20,0,0,1,16,0,4,16,1,16,17,0,20,0,4,1,0,5]

theorem envBound11045 : H12AffineFastState.Bounded env11045 := by
  intro p hp
  have h : env11045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11044_11045 : H12AffineEnvironment.transform 8 5 env11044 = env11045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env11044 == env11045) = true)

def env11046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441761,95496,8328,65,4196520,436384,45524,32160,412856,4606445,256,21793,46213,486255]

theorem envBound11046 : H12AffineFastState.Bounded env11046 := by
  intro p hp
  have h : env11046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11008_11046 : H12AffineEnvironment.transform 22 441761 env11008 = env11046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env11008 == env11046) = true)

def env11047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441761,95496,8328,65,270376,436384,45524,32160,412856,156013,256,21793,46213,486255]

theorem envBound11047 : H12AffineFastState.Bounded env11047 := by
  intro p hp
  have h : env11047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11046_11047 : H12AffineEnvironment.transform 21 272512 env11046 = env11047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11046 == env11047) = true)

theorem identity11047 : scanCanonicalize (H12AffineFastState.compose env11047 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound11047 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,58517,169265,16,95496,8328,65,171417,5393,45524,32160,61705,156013,256,21793,46213,120542]

theorem envBound11048 : H12AffineFastState.Bounded env11048 := by
  intro p hp
  have h : env11048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11047_11048 : H12AffineEnvironment.transform 17 179633 env11047 = env11048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env11047 == env11048) = true)

def env11049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169265,16,95496,8192,65,171281,5393,45404,32040,61705,156013,256,21793,46093,120406]

theorem envBound11049 : H12AffineFastState.Bounded env11049 := by
  intro p hp
  have h : env11049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11048_11049 : H12AffineEnvironment.transform 6 8 env11048 = env11049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11048 == env11049) = true)

theorem identity11049 : scanCanonicalize (H12AffineFastState.compose env11049 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound11049 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130175,1024,32769,58397,119927,16,95496,8192,65,121943,5393,45404,32040,61705,73771,256,21793,46093,120406]

theorem envBound11050 : H12AffineFastState.Bounded env11050 := by
  intro p hp
  have h : env11050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11049_11050 : H12AffineEnvironment.transform 16 82246 env11049 = env11050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env11049 == env11050) = true)

theorem identity11050 : scanCanonicalize (H12AffineFastState.compose env11050 (packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11050 : packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS < 2^1333 := by decide +kernel

def env11051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,122146,1024,32769,50496,119927,16,87125,349,65,121943,5393,36865,23669,53332,65910,256,21793,38224,120406]

theorem envBound11051 : H12AffineFastState.Bounded env11051 := by
  intro p hp
  have h : env11051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11050_11051 : H12AffineEnvironment.transform 12 349 env11050 = env11051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11050 == env11051) = true)

def env11052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169265,16,95496,8193,65,171280,5393,45405,32041,61705,156013,256,21793,46092,120407]

theorem envBound11052 : H12AffineFastState.Bounded env11052 := by
  intro p hp
  have h : env11052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11048_11052 : H12AffineEnvironment.transform 6 9 env11048 = env11052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11048 == env11052) = true)

theorem identity11052 : scanCanonicalize (H12AffineFastState.compose env11052 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound11052 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,89379,1024,32769,58396,95530,16,95496,8193,65,97547,5393,45405,32041,61705,98678,256,21793,46092,120407]

theorem envBound11053 : H12AffineFastState.Bounded env11053 := by
  intro p hp
  have h : env11053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11052_11053 : H12AffineEnvironment.transform 16 122907 env11052 = env11053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env11052 == env11053) = true)

theorem identity11053 : scanCanonicalize (H12AffineFastState.compose env11053 (packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound11053 : packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29822,37989,10589,1024,32769,58396,340,16,374,8193,65,2421,5393,45405,32041,61705,62728,256,21793,46092,41513]

theorem envBound11054 : H12AffineFastState.Bounded env11054 := by
  intro p hp
  have h : env11054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11053_11054 : H12AffineEnvironment.transform 15 29822 env11053 = env11054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env11053 == env11054) = true)

theorem identity11054 : scanCanonicalize (H12AffineFastState.compose env11054 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11054 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env11055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,21591,37989,2420,1024,32769,50229,340,16,374,40,65,2421,5393,37236,23808,53536,54561,256,21793,37925,33280]

theorem envBound11055 : H12AffineFastState.Bounded env11055 := by
  intro p hp
  have h : env11055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11054_11055 : H12AffineEnvironment.transform 12 41 env11054 = env11055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11054 == env11055) = true)

theorem identity11055 : scanCanonicalize (H12AffineFastState.compose env11055 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11055 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,21591,5220,2420,1024,0,17460,340,16,374,40,65,2421,5393,4469,23808,20769,21792,256,21793,5156,513]

theorem envBound11056 : H12AffineFastState.Bounded env11056 := by
  intro p hp
  have h : env11056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11055_11056 : H12AffineEnvironment.transform 14 1 env11055 = env11056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11055 == env11056) = true)

theorem identity11056 : scanCanonicalize (H12AffineFastState.compose env11056 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound11056 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11057 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,16384,1,20531,4096,2420,100,0,16464,340,16,374,40,65,2421,4469,4469,22884,20769,20804,256,20805,4160,513]

theorem envBound11057 : H12AffineFastState.Bounded env11057 := by
  intro p hp
  have h : env11057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11056_11057 : H12AffineEnvironment.transform 9 100 env11056 = env11057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env11056 == env11057) = true)

theorem identity11057 : scanCanonicalize (H12AffineFastState.compose env11057 (packedSelected [11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound11057 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env11058 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,4453,1,342,4096,2420,100,0,4405,340,16,374,40,65,2421,4469,4469,2049,68,33,256,32,4160,513]

theorem envBound11058 : H12AffineFastState.Bounded env11058 := by
  intro p hp
  have h : env11058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11057_11058 : H12AffineEnvironment.transform 13 4453 env11057 = env11058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env11057 == env11058) = true)

theorem identity11058 : scanCanonicalize (H12AffineFastState.compose env11058 (packedSelected [1,2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound11058 : packedSelected [1,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env11059 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2576,41,2933,1,342,2576,2420,100,0,2853,340,16,374,40,65,2421,2917,2917,2049,68,33,256,32,2640,513]

theorem envBound11059 : H12AffineFastState.Bounded env11059 := by
  intro p hp
  have h : env11059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11058_11059 : H12AffineEnvironment.transform 11 2576 env11058 = env11059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env11058 == env11059) = true)

theorem identity11059 : scanCanonicalize (H12AffineFastState.compose env11059 (packedSelected [0,1,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound11059 : packedSelected [0,1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env11060 : List Nat := [2,4,8,16,32,64,9,256,512,100,49,545,41,836,1,342,545,325,100,0,788,340,16,374,40,65,324,852,852,48,68,33,256,32,609,513]

theorem envBound11060 : H12AffineFastState.Bounded env11060 := by
  intro p hp
  have h : env11060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11059_11060 : H12AffineEnvironment.transform 10 49 env11059 = env11060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env11059 == env11060) = true)

theorem identity11060 : scanCanonicalize (H12AffineFastState.compose env11060 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11060 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11061 : List Nat := [2,4,8,16,32,64,9,256,1,100,49,32,41,325,1,342,32,325,100,0,277,340,16,374,40,65,324,341,341,48,68,33,256,32,96,0]

theorem envBound11061 : H12AffineFastState.Bounded env11061 := by
  intro p hp
  have h : env11061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11060_11061 : H12AffineEnvironment.transform 8 1 env11060 = env11061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11060 == env11061) = true)

theorem identity11061 : scanCanonicalize (H12AffineFastState.compose env11061 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11061 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env11062 : List Nat := [2,4,8,16,32,64,9,117,1,100,49,32,41,48,1,35,32,48,100,0,96,33,16,3,40,65,49,32,32,48,68,33,117,32,96,0]

theorem envBound11062 : H12AffineFastState.Bounded env11062 := by
  intro p hp
  have h : env11062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11061_11062 : H12AffineEnvironment.transform 7 117 env11061 = env11062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11061 == env11062) = true)

theorem identity11062 : scanCanonicalize (H12AffineFastState.compose env11062 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound11062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11063 : List Nat := [2,4,8,16,32,33,9,20,1,5,49,32,41,48,1,35,32,48,5,0,1,33,16,3,40,32,49,32,32,48,37,33,20,32,1,0]

theorem envBound11063 : H12AffineFastState.Bounded env11063 := by
  intro p hp
  have h : env11063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11062_11063 : H12AffineEnvironment.transform 5 33 env11062 = env11063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env11062 == env11063) = true)

def env11064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441761,95496,8328,65,270377,436384,45524,32160,412856,156012,256,21793,46213,486255]

theorem envBound11064 : H12AffineFastState.Bounded env11064 := by
  intro p hp
  have h : env11064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11046_11064 : H12AffineEnvironment.transform 21 272513 env11046 = env11064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11046 == env11064) = true)

def env11065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441641,95496,8192,65,270377,436264,45404,32040,412720,156012,256,21793,46093,486255]

theorem envBound11065 : H12AffineFastState.Bounded env11065 := by
  intro p hp
  have h : env11065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11064_11065 : H12AffineEnvironment.transform 6 8 env11064 = env11065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11064 == env11065) = true)

def env11066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272441,95496,8192,65,270377,277816,45404,32040,317728,62588,256,21793,46093,392831]

theorem envBound11066 : H12AffineFastState.Bounded env11066 := by
  intro p hp
  have h : env11066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11065_11066 : H12AffineEnvironment.transform 16 38160 env11065 = env11066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11065 == env11066) = true)

theorem identity11066 : scanCanonicalize (H12AffineFastState.compose env11066 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound11066 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1024,32769,314420,272393,272441,41310,8192,65,270377,277816,45404,32040,317728,62588,256,21793,46093,272937]

theorem envBound11067 : H12AffineFastState.Bounded env11067 := by
  intro p hp
  have h : env11067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11066_11067 : H12AffineEnvironment.transform 15 54358 env11066 = env11067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env11066 == env11067) = true)

theorem identity11067 : scanCanonicalize (H12AffineFastState.compose env11067 (packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11067 : packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env11068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,5393,262144,1024,0,281653,272393,272441,8543,8192,65,270377,277816,12637,32040,284961,29821,256,21793,13324,272937]

theorem envBound11068 : H12AffineFastState.Bounded env11068 := by
  intro p hp
  have h : env11068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11067_11068 : H12AffineEnvironment.transform 14 1 env11067 = env11068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11067 == env11068) = true)

theorem identity11068 : scanCanonicalize (H12AffineFastState.compose env11068 (packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound11068 : packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env11069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8203,5393,262144,1024,0,276585,272393,272441,8543,8192,65,270377,277816,12637,2420,273789,33,256,8573,13324,272937]

theorem envBound11069 : H12AffineFastState.Bounded env11069 := by
  intro p hp
  have h : env11069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11068_11069 : H12AffineEnvironment.transform 13 13404 env11068 = env11069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env11068 == env11069) = true)

theorem identity11069 : scanCanonicalize (H12AffineFastState.compose env11069 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound11069 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8203,5393,10361,1024,0,4112,112,64,8543,8192,65,2128,5441,12637,2420,1284,33,256,8573,13324,592]

theorem envBound11070 : H12AffineFastState.Bounded env11070 := by
  intro p hp
  have h : env11070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11069_11070 : H12AffineEnvironment.transform 17 10361 env11069 = env11070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env11069 == env11070) = true)

theorem identity11070 : scanCanonicalize (H12AffineFastState.compose env11070 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound11070 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,10509,1,8203,2112,10361,1024,0,3393,112,64,8543,8192,65,2128,2064,11276,2420,1284,33,256,8573,10589,592]

theorem envBound11071 : H12AffineFastState.Bounded env11071 := by
  intro p hp
  have h : env11071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11070_11071 : H12AffineEnvironment.transform 11 3409 env11070 = env11071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env11070 == env11071) = true)

theorem identity11071 : scanCanonicalize (H12AffineFastState.compose env11071 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11071 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env11072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,349,2128,1,342,2112,2340,1024,0,3393,112,64,2,349,65,2128,2064,3409,2420,1284,33,256,32,2048,592]

theorem envBound11072 : H12AffineFastState.Bounded env11072 := by
  intro p hp
  have h : env11072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11071_11072 : H12AffineEnvironment.transform 12 349 env11071 = env11072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11071 == env11072) = true)

theorem identity11072 : scanCanonicalize (H12AffineFastState.compose env11072 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound11072 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1329,96,349,1377,1,342,1393,1045,1024,0,112,112,64,2,349,65,1377,1313,96,1093,1284,33,256,32,1329,592]

theorem envBound11073 : H12AffineFastState.Bounded env11073 := by
  intro p hp
  have h : env11073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11072_11073 : H12AffineEnvironment.transform 10 1329 env11072 = env11073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env11072 == env11073) = true)

def env11074 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272440,95496,8192,65,270377,277817,45404,32040,317729,62589,256,21793,46093,392830]

theorem envBound11074 : H12AffineFastState.Bounded env11074 := by
  intro p hp
  have h : env11074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11065_11074 : H12AffineEnvironment.transform 16 38161 env11065 = env11074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11065 == env11074) = true)

theorem identity11074 : scanCanonicalize (H12AffineFastState.compose env11074 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound11074 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130175,1024,32769,77898,119926,119879,95496,8192,65,121942,115014,45404,32040,75102,62589,256,21793,46093,513]

theorem envBound11075 : H12AffineFastState.Bounded env11075 := by
  intro p hp
  have h : env11075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11074_11075 : H12AffineEnvironment.transform 17 130175 env11074 = env11075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env11074 == env11075) = true)

theorem identity11075 : scanCanonicalize (H12AffineFastState.compose env11075 (packedSelected [1,2,6,10,18,19,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound11075 : packedSelected [1,2,6,10,18,19,23,28] rootPS < 2^1333 := by decide +kernel

def env11076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,13340,89458,1024,8460,77898,95611,95562,95496,8192,65,97627,90187,4177,32040,75102,21872,256,21793,5376,513]

theorem envBound11076 : H12AffineFastState.Bounded env11076 := by
  intro p hp
  have h : env11076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11075_11076 : H12AffineEnvironment.transform 14 8461 env11075 = env11076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env11075 == env11076) = true)

theorem identity11076 : scanCanonicalize (H12AffineFastState.compose env11076 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound11076 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21591,13340,2341,1024,8460,25629,8492,8477,8543,8192,65,10508,13340,4177,32040,28937,21872,256,21793,5376,513]

theorem envBound11077 : H12AffineFastState.Bounded env11077 := by
  intro p hp
  have h : env11077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11076_11077 : H12AffineEnvironment.transform 15 21591 env11076 = env11077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env11076 == env11077) = true)

theorem identity11077 : scanCanonicalize (H12AffineFastState.compose env11077 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11077 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,343,13340,2341,1024,8460,12573,8492,8477,8543,8192,65,10508,13340,4177,10280,9225,112,256,33,5376,513]

theorem envBound11078 : H12AffineFastState.Bounded env11078 := by
  intro p hp
  have h : env11078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11077_11078 : H12AffineEnvironment.transform 13 5376 env11077 = env11078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11077 == env11078) = true)

theorem identity11078 : scanCanonicalize (H12AffineFastState.compose env11078 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11078 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,262,13340,2341,1024,8460,12573,8492,8477,8462,8192,16,10508,13340,4096,10280,9225,33,256,33,5376,513]

theorem envBound11079 : H12AffineFastState.Bounded env11079 := by
  intro p hp
  have h : env11079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11078_11079 : H12AffineEnvironment.transform 5 17 env11078 = env11079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11078 == env11079) = true)

theorem identity11079 : scanCanonicalize (H12AffineFastState.compose env11079 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2616) := by decide +kernel

theorem selectedBound11079 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env11080 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2616,5376,2869,262,7716,2341,1024,2868,6949,2836,2853,2870,2616,16,820,7716,4096,528,3633,33,256,33,5376,513]

theorem envBound11080 : H12AffineFastState.Bounded env11080 := by
  intro p hp
  have h : env11080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11079_11080 : H12AffineEnvironment.transform 12 2616 env11079 = env11080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2616 env11079 == env11080) = true)

theorem identity11080 : scanCanonicalize (H12AffineFastState.compose env11080 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11080 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env11081 : List Nat := [2,4,8,16,32,17,8,256,512,1024,528,4096,40,5376,293,262,5172,821,1024,292,4405,260,309,294,40,16,820,5172,4096,528,1057,33,256,33,5376,513]

theorem envBound11081 : H12AffineFastState.Bounded env11081 := by
  intro p hp
  have h : env11081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11080_11081 : H12AffineEnvironment.transform 10 528 env11080 = env11081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11080 == env11081) = true)

theorem identity11081 : scanCanonicalize (H12AffineFastState.compose env11081 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound11081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11082 : List Nat := [2,4,8,16,32,17,8,256,512,1024,528,821,40,1589,293,262,1793,821,1024,292,512,260,309,294,40,16,820,1793,821,528,1057,33,256,33,1589,513]

theorem envBound11082 : H12AffineFastState.Bounded env11082 := by
  intro p hp
  have h : env11082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11081_11082 : H12AffineEnvironment.transform 11 821 env11081 = env11082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env11081 == env11082) = true)

theorem identity11082 : scanCanonicalize (H12AffineFastState.compose env11082 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound11082 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env11083 : List Nat := [2,4,8,16,32,17,8,53,512,1024,528,512,40,1589,16,51,1588,512,1024,17,512,49,0,19,40,16,513,1588,512,528,1057,33,53,33,1589,513]

theorem envBound11083 : H12AffineFastState.Bounded env11083 := by
  intro p hp
  have h : env11083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11082_11083 : H12AffineEnvironment.transform 7 53 env11082 = env11083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env11082 == env11083) = true)

theorem identity11083 : scanCanonicalize (H12AffineFastState.compose env11083 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11084 : List Nat := [2,4,8,0,32,1,8,37,512,1024,512,512,40,1573,0,35,1572,512,1024,1,512,33,0,3,40,0,513,1572,512,512,1057,33,37,33,1573,513]

theorem envBound11084 : H12AffineFastState.Bounded env11084 := by
  intro p hp
  have h : env11084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11083_11084 : H12AffineEnvironment.transform 3 0 env11083 = env11084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11083 == env11084) = true)

theorem identity11084 : scanCanonicalize (H12AffineFastState.compose env11084 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound11084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11085 : List Nat := [2,4,8,0,32,1,8,37,512,548,512,512,40,1,0,35,0,512,548,1,512,33,0,3,40,0,513,0,512,512,517,33,37,33,1,513]

theorem envBound11085 : H12AffineFastState.Bounded env11085 := by
  intro p hp
  have h : env11085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11084_11085 : H12AffineEnvironment.transform 9 548 env11084 = env11085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env11084 == env11085) = true)

def env11086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272392,441640,95496,8193,65,270377,436265,45405,32041,412721,156012,256,21793,46092,486255]

theorem envBound11086 : H12AffineFastState.Bounded env11086 := by
  intro p hp
  have h : env11086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11064_11086 : H12AffineEnvironment.transform 6 9 env11064 = env11086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11064 == env11086) = true)

def env11087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272392,272440,95496,8193,65,270377,277817,45405,32041,317729,62588,256,21793,46092,392831]

theorem envBound11087 : H12AffineFastState.Bounded env11087 := by
  intro p hp
  have h : env11087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11086_11087 : H12AffineEnvironment.transform 16 38160 env11086 = env11087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11086 == env11087) = true)

theorem identity11087 : scanCanonicalize (H12AffineFastState.compose env11087 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11087 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,38160,262144,1024,32769,314420,272392,272440,3,8193,65,270377,277817,45405,32041,317729,62588,256,21793,46092,297844]

theorem envBound11088 : H12AffineFastState.Bounded env11088 := by
  intro p hp
  have h : env11088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11087_11088 : H12AffineEnvironment.transform 15 29963 env11087 = env11088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11087 == env11088) = true)

theorem identity11088 : scanCanonicalize (H12AffineFastState.compose env11088 (packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound11088 : packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env11089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,35,38160,262144,1024,32769,309532,272392,272440,3,8193,65,270377,277817,45405,2049,306185,33108,256,8201,46092,297844]

theorem envBound11089 : H12AffineFastState.Bounded env11089 := by
  intro p hp
  have h : env11089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11088_11089 : H12AffineEnvironment.transform 13 13608 env11088 = env11089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env11088 == env11089) = true)

theorem identity11089 : scanCanonicalize (H12AffineFastState.compose env11089 (packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11089 : packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,1,35,5393,262144,1024,0,276765,272392,272440,3,8193,65,270377,277817,12636,2049,273416,341,256,8201,13325,265077]

theorem envBound11090 : H12AffineFastState.Bounded env11090 := by
  intro p hp
  have h : env11090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11089_11090 : H12AffineEnvironment.transform 14 1 env11089 = env11090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11089 == env11090) = true)

theorem identity11090 : scanCanonicalize (H12AffineFastState.compose env11090 (packedSelected [0,1,2,3,6,7,8,10,11,12,15,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11090 : packedSelected [0,1,2,3,6,7,8,10,11,12,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env11091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,1,35,5393,262144,1024,0,268597,264224,264208,3,41,65,262145,269585,4468,2049,265248,341,256,33,5157,265077]

theorem envBound11091 : H12AffineFastState.Bounded env11091 := by
  intro p hp
  have h : env11091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11090_11091 : H12AffineEnvironment.transform 12 40 env11090 = env11091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11090 == env11091) = true)

theorem identity11091 : scanCanonicalize (H12AffineFastState.compose env11091 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11091 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11092 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,1,35,5393,262144,1024,0,268597,264224,264208,3,41,16,262145,269585,4389,2049,265248,260,256,33,5157,264996]

theorem envBound11092 : H12AffineFastState.Bounded env11092 := by
  intro p hp
  have h : env11092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11091_11092 : H12AffineEnvironment.transform 5 17 env11091 = env11092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11091 == env11092) = true)

theorem identity11092 : scanCanonicalize (H12AffineFastState.compose env11092 (packedSelected [1,2,8,10,14] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound11092 : packedSelected [1,2,8,10,14] rootPS < 2^1333 := by decide +kernel

def env11093 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,1,35,5393,2048,1024,0,4405,32,16,3,41,16,2049,5393,4389,2049,1056,260,256,33,5157,804]

theorem envBound11093 : H12AffineFastState.Bounded env11093 := by
  intro p hp
  have h : env11093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11092_11093 : H12AffineEnvironment.transform 17 2048 env11092 = env11093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env11092 == env11093) = true)

theorem identity11093 : scanCanonicalize (H12AffineFastState.compose env11093 (packedSelected [0,3,5,6,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11093 : packedSelected [0,3,5,6,7,18] rootPS < 2^1333 := by decide +kernel

def env11094 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,35,5173,2048,1024,0,4113,32,16,3,41,16,2049,5173,4097,2049,1056,32,36,33,5157,512]

theorem envBound11094 : H12AffineFastState.Bounded env11094 := by
  intro p hp
  have h : env11094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11093_11094 : H12AffineEnvironment.transform 7 36 env11093 = env11094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11093 == env11094) = true)

theorem identity11094 : scanCanonicalize (H12AffineFastState.compose env11094 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11094 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11095 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,1,3,5141,2048,1024,0,4113,0,16,3,9,16,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound11095 : H12AffineFastState.Bounded env11095 := by
  intro p hp
  have h : env11095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11094_11095 : H12AffineEnvironment.transform 4 0 env11094 = env11095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11094 == env11095) = true)

theorem identity11095 : scanCanonicalize (H12AffineFastState.compose env11095 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound11095 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11096 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,8,5124,1,3,5141,523,1024,0,4113,0,16,3,9,16,522,5141,4097,522,1024,0,4,1,5125,512]

theorem envBound11096 : H12AffineFastState.Bounded env11096 := by
  intro p hp
  have h : env11096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11095_11096 : H12AffineEnvironment.transform 10 523 env11095 = env11096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env11095 == env11096) = true)

def env11097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272392,272441,95496,8193,65,270377,277816,45405,32041,317728,62589,256,21793,46092,392830]

theorem envBound11097 : H12AffineFastState.Bounded env11097 := by
  intro p hp
  have h : env11097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11086_11097 : H12AffineEnvironment.transform 16 38161 env11086 = env11097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11086 == env11097) = true)

theorem identity11097 : scanCanonicalize (H12AffineFastState.compose env11097 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound11097 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89379,1024,32769,102678,95531,95514,95496,8193,65,97546,90139,45405,32041,99331,62589,256,21793,46092,41821]

theorem envBound11098 : H12AffineFastState.Bounded env11098 := by
  intro p hp
  have h : env11098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11097_11098 : H12AffineEnvironment.transform 17 89379 env11097 = env11098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env11097 == env11098) = true)

theorem identity11098 : scanCanonicalize (H12AffineFastState.compose env11098 (packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11098 : packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env11099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,65536,38161,89379,1024,32769,102678,87299,87346,87328,41,65,89378,81971,37237,23809,99331,54357,256,21793,37924,33653]

theorem envBound11099 : H12AffineFastState.Bounded env11099 := by
  intro p hp
  have h : env11099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11098_11099 : H12AffineEnvironment.transform 12 40 env11098 = env11099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11098 == env11099) = true)

theorem identity11099 : scanCanonicalize (H12AffineFastState.compose env11099 (packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound11099 : packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env11100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,54358,38161,35189,1024,32769,17728,33109,33124,33142,41,65,35188,37989,37237,23809,20565,54357,256,21793,37924,33653]

theorem envBound11100 : H12AffineFastState.Bounded env11100 := by
  intro p hp
  have h : env11100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11099_11100 : H12AffineEnvironment.transform 15 54358 env11099 = env11100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env11099 == env11100) = true)

theorem identity11100 : scanCanonicalize (H12AffineFastState.compose env11100 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11100 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env11101 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,32768,54358,37940,34896,1024,32769,17509,32880,32833,32851,41,65,34897,37989,36944,23588,20565,54357,37,21508,37924,33360]

theorem envBound11101 : H12AffineFastState.Bounded env11101 := by
  intro p hp
  have h : env11101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11100_11101 : H12AffineEnvironment.transform 7 37 env11100 = env11101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11100 == env11101) = true)

theorem identity11101 : scanCanonicalize (H12AffineFastState.compose env11101 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11101 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env11102 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,1,21591,5173,2129,1024,0,17509,113,64,82,41,65,2128,5220,4177,23588,20565,21588,37,21508,5157,593]

theorem envBound11102 : H12AffineFastState.Bounded env11102 := by
  intro p hp
  have h : env11102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11101_11102 : H12AffineEnvironment.transform 14 1 env11101 = env11102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11101 == env11102) = true)

theorem identity11102 : scanCanonicalize (H12AffineFastState.compose env11102 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound11102 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env11103 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,1,114,5173,2129,1024,0,4160,113,64,82,41,65,2128,5220,4177,2049,1136,113,37,33,5157,593]

theorem envBound11103 : H12AffineFastState.Bounded env11103 := by
  intro p hp
  have h : env11103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11102_11103 : H12AffineEnvironment.transform 13 5157 env11102 = env11103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env11102 == env11103) = true)

theorem identity11103 : scanCanonicalize (H12AffineFastState.compose env11103 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11103 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env11104 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,1,35,5173,2048,1024,0,4113,32,17,3,41,16,2049,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound11104 : H12AffineFastState.Bounded env11104 := by
  intro p hp
  have h : env11104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11103_11104 : H12AffineEnvironment.transform 5 17 env11103 = env11104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11103 == env11104) = true)

theorem identity11104 : scanCanonicalize (H12AffineFastState.compose env11104 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11105 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5125,1,3,5141,2048,1024,0,4113,0,17,3,9,16,2049,5141,4096,2049,1025,0,5,1,5125,512]

theorem envBound11105 : H12AffineFastState.Bounded env11105 := by
  intro p hp
  have h : env11105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11104_11105 : H12AffineEnvironment.transform 4 0 env11104 = env11105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11104 == env11105) = true)

def env11106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,8388608,8898729,8328,65,4196520,8393984,8785012,8830977,412856,12645453,256,21792,46212,486255]

theorem envBound11106 : H12AffineFastState.Bounded env11106 := by
  intro p hp
  have h : env11106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11007_11106 : H12AffineEnvironment.transform 20 416037 env11007 = env11106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416037 env11007 == env11106) = true)

def env11107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441760,95497,8328,65,4196520,436384,45524,32161,412856,4606445,256,21792,46212,486255]

theorem envBound11107 : H12AffineFastState.Bounded env11107 := by
  intro p hp
  have h : env11107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11106_11107 : H12AffineEnvironment.transform 22 441760 env11106 = env11107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env11106 == env11107) = true)

def env11108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441760,95497,8328,65,270376,436384,45524,32161,412856,156013,256,21792,46212,486255]

theorem envBound11108 : H12AffineFastState.Bounded env11108 := by
  intro p hp
  have h : env11108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11107_11108 : H12AffineEnvironment.transform 21 272512 env11107 = env11108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11107 == env11108) = true)

theorem identity11108 : scanCanonicalize (H12AffineFastState.compose env11108 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound11108 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,416037,272512,441760,41431,8328,65,270376,436384,45524,32161,412856,156013,256,21792,46212,442289]

theorem envBound11109 : H12AffineFastState.Bounded env11109 := by
  intro p hp
  have h : env11109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11108_11109 : H12AffineEnvironment.transform 15 54494 env11108 = env11109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env11108 == env11109) = true)

def env11110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,416037,272392,441640,41311,8192,65,270376,436264,45404,32041,412720,156013,256,21792,46092,442169]

theorem envBound11110 : H12AffineFastState.Bounded env11110 := by
  intro p hp
  have h : env11110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11109_11110 : H12AffineEnvironment.transform 6 8 env11109 = env11110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11109 == env11110) = true)

theorem identity11110 : scanCanonicalize (H12AffineFastState.compose env11110 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound11110 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env11111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,262144,1024,32769,290153,272392,297316,41311,8192,65,270376,302180,45404,32041,292988,21793,256,21792,46092,297845]

theorem envBound11111 : H12AffineFastState.Bounded env11111 := by
  intro p hp
  have h : env11111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11110_11111 : H12AffineEnvironment.transform 16 13388 env11110 = env11111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env11110 == env11111) = true)

theorem identity11111 : scanCanonicalize (H12AffineFastState.compose env11111 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound11111 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env11112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,64809,1024,32769,36928,54561,29773,41311,8192,65,56577,24909,45404,32041,34133,21793,256,21792,46092,30300]

theorem envBound11112 : H12AffineFastState.Bounded env11112 := by
  intro p hp
  have h : env11112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11111_11112 : H12AffineEnvironment.transform 17 64809 env11111 = env11112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env11111 == env11112) = true)

theorem identity11112 : scanCanonicalize (H12AffineFastState.compose env11112 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11112 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env11113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54358,5441,56356,1024,32769,36928,54561,21824,32850,269,65,56577,16448,36945,23588,34133,21793,256,21792,38145,22353]

theorem envBound11113 : H12AffineFastState.Bounded env11113 := by
  intro p hp
  have h : env11113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11112_11113 : H12AffineEnvironment.transform 12 269 env11112 = env11113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11112 == env11113) = true)

theorem identity11113 : scanCanonicalize (H12AffineFastState.compose env11113 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound11113 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,32768,33030,5441,35188,1024,32769,36928,32881,16,32850,269,65,34897,5392,36945,2420,34133,113,256,112,38145,513]

theorem envBound11114 : H12AffineFastState.Bounded env11114 := by
  intro p hp
  have h : env11114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11113_11114 : H12AffineEnvironment.transform 13 5456 env11113 = env11114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env11113 == env11114) = true)

theorem identity11114 : scanCanonicalize (H12AffineFastState.compose env11114 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11114 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env11115 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,33030,5393,35108,1024,32769,36880,32801,16,32770,269,17,34817,5392,36865,2340,34053,33,256,32,38145,513]

theorem envBound11115 : H12AffineFastState.Bounded env11115 := by
  intro p hp
  have h : env11115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11114_11115 : H12AffineEnvironment.transform 5 16 env11114 = env11115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11114 == env11115) = true)

theorem identity11115 : scanCanonicalize (H12AffineFastState.compose env11115 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11115 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11116 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,263,5393,2341,1024,0,4113,32,16,3,269,17,2048,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound11116 : H12AffineFastState.Bounded env11116 := by
  intro p hp
  have h : env11116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11115_11116 : H12AffineEnvironment.transform 14 1 env11115 = env11116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11115 == env11116) = true)

theorem identity11116 : scanCanonicalize (H12AffineFastState.compose env11116 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound11116 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11117 : List Nat := [2,4,8,16,32,16,8,52,512,1024,2048,4096,57,5172,1,51,5157,2065,1024,0,4113,32,16,3,57,17,2048,5156,4096,2064,1072,33,52,32,5172,513]

theorem envBound11117 : H12AffineFastState.Bounded env11117 := by
  intro p hp
  have h : env11117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11116_11117 : H12AffineEnvironment.transform 7 52 env11116 = env11117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env11116 == env11117) = true)

theorem identity11117 : scanCanonicalize (H12AffineFastState.compose env11117 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound11117 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11118 : List Nat := [2,4,8,16,32,16,8,52,512,1024,2048,2059,57,3135,1,51,3118,2065,1024,0,2074,32,16,3,57,17,2048,3119,2059,2064,1072,33,52,32,3135,513]

theorem envBound11118 : H12AffineFastState.Bounded env11118 := by
  intro p hp
  have h : env11118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11117_11118 : H12AffineEnvironment.transform 11 2059 env11117 = env11118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env11117 == env11118) = true)

theorem identity11118 : scanCanonicalize (H12AffineFastState.compose env11118 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11118 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11119 : List Nat := [2,4,8,16,11,16,8,31,512,1024,2048,2059,18,3092,1,24,3077,2065,1024,0,2074,11,16,3,18,17,2048,3076,2059,2064,1051,10,31,11,3092,513]

theorem envBound11119 : H12AffineFastState.Bounded env11119 := by
  intro p hp
  have h : env11119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11118_11119 : H12AffineEnvironment.transform 4 11 env11118 = env11119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11118 == env11119) = true)

theorem identity11119 : scanCanonicalize (H12AffineFastState.compose env11119 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11119 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11120 : List Nat := [2,4,8,16,11,16,8,31,512,20,2048,2059,18,2048,1,24,2065,2065,20,0,2074,11,16,3,18,17,2048,2064,2059,2064,15,10,31,11,2048,513]

theorem envBound11120 : H12AffineFastState.Bounded env11120 := by
  intro p hp
  have h : env11120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11119_11120 : H12AffineEnvironment.transform 9 20 env11119 = env11120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11119 == env11120) = true)

theorem identity11120 : scanCanonicalize (H12AffineFastState.compose env11120 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11120 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11121 : List Nat := [2,4,8,10,11,10,8,5,512,14,2048,2059,8,2048,1,2,2059,2059,14,0,2048,11,10,3,8,11,2048,2058,2059,2058,15,10,5,11,2048,513]

theorem envBound11121 : H12AffineFastState.Bounded env11121 := by
  intro p hp
  have h : env11121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11120_11121 : H12AffineEnvironment.transform 3 10 env11120 = env11121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11120 == env11121) = true)

theorem identity11121 : scanCanonicalize (H12AffineFastState.compose env11121 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound11121 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11122 : List Nat := [2,4,8,10,11,10,8,5,2,14,2048,2059,8,2048,1,2,2059,2059,14,0,2048,11,10,3,8,11,2048,2058,2059,2058,15,10,5,11,2048,3]

theorem envBound11122 : H12AffineFastState.Bounded env11122 := by
  intro p hp
  have h : env11122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11121_11122 : H12AffineEnvironment.transform 8 2 env11121 = env11122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env11121 == env11122) = true)

def env11123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,416037,272393,441641,41310,8193,65,270376,436265,45405,32040,412721,156013,256,21792,46093,442168]

theorem envBound11123 : H12AffineFastState.Bounded env11123 := by
  intro p hp
  have h : env11123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11109_11123 : H12AffineEnvironment.transform 6 9 env11109 = env11123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11109 == env11123) = true)

theorem identity11123 : scanCanonicalize (H12AffineFastState.compose env11123 (packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound11123 : packedSelected [0,1,4,8,12,16,17,19,22,27,35,38] rootPS < 2^1333 := by decide +kernel

def env11124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16740,262144,1024,32769,268353,272393,326733,41310,8193,65,270376,321869,45405,32040,265557,8201,256,21792,46093,327260]

theorem envBound11124 : H12AffineFastState.Bounded env11124 := by
  intro p hp
  have h : env11124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11123_11124 : H12AffineEnvironment.transform 16 16740 env11123 = env11124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env11123 == env11124) = true)

theorem identity11124 : scanCanonicalize (H12AffineFastState.compose env11124 (packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound11124 : packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env11125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16740,35189,1024,32769,37172,41340,30008,41310,8193,65,43357,24632,45405,32040,33824,8201,256,21792,46093,30505]

theorem envBound11125 : H12AffineFastState.Bounded env11125 := by
  intro p hp
  have h : env11125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11124_11125 : H12AffineEnvironment.transform 17 35189 env11124 = env11125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env11124 == env11125) = true)

theorem identity11125 : scanCanonicalize (H12AffineFastState.compose env11125 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound11125 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env11126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,13625,35189,1024,32769,37172,41340,357,41310,8193,65,43357,5221,45405,2421,33824,8201,256,8573,46093,884]

theorem envBound11126 : H12AffineFastState.Bounded env11126 := by
  intro p hp
  have h : env11126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11125_11126 : H12AffineEnvironment.transform 13 13405 env11125 = env11126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env11125 == env11126) = true)

theorem identity11126 : scanCanonicalize (H12AffineFastState.compose env11126 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11126 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11127 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,32768,40970,13389,34817,1024,32769,36928,40968,17,41002,8193,65,43049,5221,45097,2049,33824,8201,116,8201,46093,512]

theorem envBound11127 : H12AffineFastState.Bounded env11127 := by
  intro p hp
  have h : env11127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11126_11127 : H12AffineEnvironment.transform 7 116 env11126 = env11127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11126 == env11127) = true)

theorem identity11127 : scanCanonicalize (H12AffineFastState.compose env11127 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11127 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11128 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,5157,32768,32882,5173,34817,1024,32769,36928,32880,17,32850,121,65,34897,5221,36945,2049,33824,113,116,113,38005,512]

theorem envBound11128 : H12AffineFastState.Bounded env11128 := by
  intro p hp
  have h : env11128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11127_11128 : H12AffineEnvironment.transform 12 120 env11127 = env11128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11127 == env11128) = true)

theorem identity11128 : scanCanonicalize (H12AffineFastState.compose env11128 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound11128 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env11129 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2128,32768,32882,2112,34817,1024,32769,35893,32880,17,32850,121,65,34897,2064,35876,2049,33824,113,116,113,34816,512]

theorem envBound11129 : H12AffineFastState.Bounded env11129 := by
  intro p hp
  have h : env11129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11128_11129 : H12AffineEnvironment.transform 11 3189 env11128 = env11129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env11128 == env11129) = true)

theorem identity11129 : scanCanonicalize (H12AffineFastState.compose env11129 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound11129 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env11130 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2128,113,3,2112,2160,1024,112,3140,1,17,35,121,65,2080,2064,3157,2049,1105,113,116,113,2161,512]

theorem envBound11130 : H12AffineFastState.Bounded env11130 := by
  intro p hp
  have h : env11130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11129_11130 : H12AffineEnvironment.transform 14 113 env11129 = env11130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env11129 == env11130) = true)

theorem identity11130 : scanCanonicalize (H12AffineFastState.compose env11130 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11130 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11131 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,3157,88,2128,81,3,2112,2128,1024,80,3140,1,17,3,89,65,2048,2064,3157,2049,1105,81,84,81,2129,512]

theorem envBound11131 : H12AffineFastState.Bounded env11131 := by
  intro p hp
  have h : env11131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11130_11131 : H12AffineEnvironment.transform 4 0 env11130 = env11131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11130 == env11131) = true)

theorem identity11131 : scanCanonicalize (H12AffineFastState.compose env11131 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11131 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11132 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3077,8,2048,1,3,2064,2048,1024,0,3092,1,17,3,9,17,2048,2064,3077,2049,1025,1,4,1,2049,512]

theorem envBound11132 : H12AffineFastState.Bounded env11132 := by
  intro p hp
  have h : env11132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11131_11132 : H12AffineEnvironment.transform 5 16 env11131 = env11132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11131 == env11132) = true)

theorem identity11132 : scanCanonicalize (H12AffineFastState.compose env11132 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11132 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11133 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,2065,8,2048,1,3,2064,2048,20,0,2048,1,17,3,9,17,2048,2064,2065,2049,21,1,4,1,2049,512]

theorem envBound11133 : H12AffineFastState.Bounded env11133 := by
  intro p hp
  have h : env11133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11132_11133 : H12AffineEnvironment.transform 9 20 env11132 = env11133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11132 == env11133) = true)

theorem identity11133 : scanCanonicalize (H12AffineFastState.compose env11133 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11134 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,513,8,528,1,3,512,528,20,0,528,1,17,3,9,17,528,512,513,529,21,1,4,1,529,512]

theorem envBound11134 : H12AffineFastState.Bounded env11134 := by
  intro p hp
  have h : env11134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11133_11134 : H12AffineEnvironment.transform 10 528 env11133 = env11134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11133 == env11134) = true)

theorem identity11134 : scanCanonicalize (H12AffineFastState.compose env11134 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound11134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11135 : List Nat := [2,4,8,16,0,16,9,4,20,20,4,21,8,4,1,3,20,4,20,0,4,1,17,3,9,17,4,20,21,5,21,1,4,1,5,20]

theorem envBound11135 : H12AffineFastState.Bounded env11135 := by
  intro p hp
  have h : env11135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11134_11135 : H12AffineEnvironment.transform 8 20 env11134 = env11135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env11134 == env11135) = true)

theorem identity11135 : scanCanonicalize (H12AffineFastState.compose env11135 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11135 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11136 : List Nat := [2,0,8,16,0,16,9,0,16,16,0,17,8,0,1,3,16,0,16,0,0,1,17,3,9,17,0,16,17,1,17,1,0,1,1,16]

theorem envBound11136 : H12AffineFastState.Bounded env11136 := by
  intro p hp
  have h : env11136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11135_11136 : H12AffineEnvironment.transform 1 0 env11135 = env11136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11135 == env11136) = true)

theorem identity11136 : scanCanonicalize (H12AffineFastState.compose env11136 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11136 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11137 : List Nat := [2,0,8,0,0,0,9,0,0,0,0,1,8,0,1,3,0,0,0,0,0,1,1,3,9,1,0,0,1,1,1,1,0,1,1,0]

theorem envBound11137 : H12AffineFastState.Bounded env11137 := by
  intro p hp
  have h : env11137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11136_11137 : H12AffineEnvironment.transform 3 0 env11136 = env11137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11136 == env11137) = true)

def env11138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441760,95497,8328,65,270377,436384,45524,32161,412856,156012,256,21792,46212,486255]

theorem envBound11138 : H12AffineFastState.Bounded env11138 := by
  intro p hp
  have h : env11138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11107_11138 : H12AffineEnvironment.transform 21 272513 env11107 = env11138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11107 == env11138) = true)

theorem identity11138 : scanCanonicalize (H12AffineFastState.compose env11138 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound11138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213487,120014,95497,8328,65,215367,115150,45524,32161,75222,156012,256,21792,46212,513]

theorem envBound11139 : H12AffineFastState.Bounded env11139 := by
  intro p hp
  have h : env11139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11138_11139 : H12AffineEnvironment.transform 17 223598 env11138 = env11139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env11138 == env11139) = true)

def env11140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213351,119878,95497,8192,65,215367,115014,45404,32041,75102,156012,256,21792,46092,513]

theorem envBound11140 : H12AffineFastState.Bounded env11140 := by
  intro p hp
  have h : env11140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11139_11140 : H12AffineEnvironment.transform 6 8 env11139 = env11140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11139 == env11140) = true)

theorem identity11140 : scanCanonicalize (H12AffineFastState.compose env11140 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound11140 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env11141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,77899,33,119878,95497,8192,65,2049,115014,45404,32041,75102,73770,256,21792,46092,513]

theorem envBound11141 : H12AffineFastState.Bounded env11141 := by
  intro p hp
  have h : env11141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11140_11141 : H12AffineEnvironment.transform 16 82246 env11140 = env11141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env11140 == env11141) = true)

theorem identity11141 : scanCanonicalize (H12AffineFastState.compose env11141 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound11141 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env11142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,5393,10280,1024,32769,25628,33,32785,8542,8192,65,2049,38161,45404,32041,28937,29821,256,21792,46092,513]

theorem envBound11142 : H12AffineFastState.Bounded env11142 := by
  intro p hp
  have h : env11142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11141_11142 : H12AffineEnvironment.transform 15 21591 env11141 = env11142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env11141 == env11142) = true)

theorem identity11142 : scanCanonicalize (H12AffineFastState.compose env11142 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11142 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env11143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21591,5393,10280,1024,1,25628,33,17,8542,8192,65,2049,5393,12636,32041,28937,29821,256,21792,13324,513]

theorem envBound11143 : H12AffineFastState.Bounded env11143 := by
  intro p hp
  have h : env11143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11142_11143 : H12AffineEnvironment.transform 14 0 env11142 = env11143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11142 == env11143) = true)

theorem identity11143 : scanCanonicalize (H12AffineFastState.compose env11143 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11143 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,0,21591,5393,2340,1024,1,17680,33,17,82,268,65,2049,5393,4176,23589,20485,21873,256,21792,5376,513]

theorem envBound11144 : H12AffineFastState.Bounded env11144 := by
  intro p hp
  have h : env11144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11143_11144 : H12AffineEnvironment.transform 12 268 env11143 = env11144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11143 == env11144) = true)

theorem identity11144 : scanCanonicalize (H12AffineFastState.compose env11144 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11144 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,0,342,5393,2340,1024,1,4113,33,17,82,268,65,2049,5393,4176,2340,1284,112,256,33,5376,513]

theorem envBound11145 : H12AffineFastState.Bounded env11145 := by
  intro p hp
  have h : env11145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11144_11145 : H12AffineEnvironment.transform 13 5377 env11144 = env11145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11144 == env11145) = true)

def env11146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,77899,213350,119879,95497,8193,65,215367,115015,45405,32040,75103,156012,256,21792,46093,513]

theorem envBound11146 : H12AffineFastState.Bounded env11146 := by
  intro p hp
  have h : env11146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11139_11146 : H12AffineEnvironment.transform 6 9 env11139 = env11146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11139 == env11146) = true)

theorem identity11146 : scanCanonicalize (H12AffineFastState.compose env11146 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound11146 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,2420,1024,32769,77899,8572,119879,95497,8193,65,10589,115015,45405,32040,75103,65910,256,21792,46093,513]

theorem envBound11147 : H12AffineFastState.Bounded env11147 := by
  intro p hp
  have h : env11147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11146_11147 : H12AffineEnvironment.transform 16 90138 env11146 = env11147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env11146 == env11147) = true)

theorem identity11147 : scanCanonicalize (H12AffineFastState.compose env11147 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound11147 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env11148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,65536,90138,2420,1024,21841,77899,8572,65815,95497,8193,65,10589,70679,25613,32040,75103,65910,256,21792,24925,513]

theorem envBound11148 : H12AffineFastState.Bounded env11148 := by
  intro p hp
  have h : env11148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11147_11148 : H12AffineEnvironment.transform 14 21840 env11147 = env11148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env11147 == env11148) = true)

theorem identity11148 : scanCanonicalize (H12AffineFastState.compose env11148 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound11148 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,21794,13624,2420,1024,21841,25961,8572,21557,8235,8193,65,10589,16693,25613,32040,28797,21588,256,21792,24925,513]

theorem envBound11149 : H12AffineFastState.Bounded env11149 := by
  intro p hp
  have h : env11149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11148_11149 : H12AffineEnvironment.transform 15 21794 env11148 = env11149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env11148 == env11149) = true)

theorem identity11149 : scanCanonicalize (H12AffineFastState.compose env11149 (packedSelected [0,4,7,9,11,14,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11149 : packedSelected [0,4,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env11150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21840,21794,5440,2420,1024,21841,17681,260,21557,83,121,65,2341,16693,17525,23888,20485,21588,256,21792,16677,513]

theorem envBound11150 : H12AffineFastState.Bounded env11150 := by
  intro p hp
  have h : env11150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11149_11150 : H12AffineEnvironment.transform 12 120 env11149 = env11150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11149 == env11150) = true)

theorem identity11150 : scanCanonicalize (H12AffineFastState.compose env11150 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound11150 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env11151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5236,292,342,5440,2420,1024,293,4453,260,65,83,121,65,2341,5441,4097,2340,1137,32,256,340,5457,513]

theorem envBound11151 : H12AffineFastState.Bounded env11151 := by
  intro p hp
  have h : env11151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11150_11151 : H12AffineEnvironment.transform 13 5236 env11150 = env11151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env11150 == env11151) = true)

theorem identity11151 : scanCanonicalize (H12AffineFastState.compose env11151 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11151 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11152 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,120,4161,292,342,4469,2420,53,293,4453,260,65,83,121,65,2341,4468,4097,2340,68,32,256,340,4452,513]

theorem envBound11152 : H12AffineFastState.Bounded env11152 := by
  intro p hp
  have h : env11152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11151_11152 : H12AffineEnvironment.transform 9 53 env11151 = env11152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11151 == env11152) = true)

theorem identity11152 : scanCanonicalize (H12AffineFastState.compose env11152 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11152 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11153 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,4096,120,4161,81,35,4096,2049,53,80,4112,113,65,83,121,65,2128,4097,4097,2129,68,32,117,33,4113,513]

theorem envBound11153 : H12AffineFastState.Bounded env11153 := by
  intro p hp
  have h : env11153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11152_11153 : H12AffineEnvironment.transform 7 117 env11152 = env11153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11152 == env11153) = true)

theorem identity11153 : scanCanonicalize (H12AffineFastState.compose env11153 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11153 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11154 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,35,4096,2049,53,0,4112,33,17,3,41,17,2048,4097,4097,2049,20,32,37,33,4113,513]

theorem envBound11154 : H12AffineFastState.Bounded env11154 := by
  intro p hp
  have h : env11154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11153_11154 : H12AffineEnvironment.transform 5 16 env11153 = env11154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11153 == env11154) = true)

def env11155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441761,95496,8328,65,4196520,436385,45525,32160,412856,4606444,256,21792,46212,486255]

theorem envBound11155 : H12AffineFastState.Bounded env11155 := by
  intro p hp
  have h : env11155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11106_11155 : H12AffineEnvironment.transform 22 441761 env11106 = env11155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env11106 == env11155) = true)

def env11156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441761,95496,8328,65,270376,436385,45525,32160,412856,156012,256,21792,46212,486255]

theorem envBound11156 : H12AffineFastState.Bounded env11156 := by
  intro p hp
  have h : env11156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11155_11156 : H12AffineEnvironment.transform 21 272512 env11155 = env11156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11155 == env11156) = true)

theorem identity11156 : scanCanonicalize (H12AffineFastState.compose env11156 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11156 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272512,441761,21762,8328,65,270376,436385,45525,32160,412856,156012,256,21792,46212,412517]

theorem envBound11157 : H12AffineFastState.Bounded env11157 := by
  intro p hp
  have h : env11157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11156_11157 : H12AffineEnvironment.transform 15 8202 env11156 = env11157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11156 == env11157) = true)

def env11158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272392,441641,21762,8192,65,270376,436265,45405,32040,412720,156012,256,21792,46092,412517]

theorem envBound11158 : H12AffineFastState.Bounded env11158 := by
  intro p hp
  have h : env11158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11157_11158 : H12AffineEnvironment.transform 6 8 env11157 = env11158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11157 == env11158) = true)

theorem identity11158 : scanCanonicalize (H12AffineFastState.compose env11158 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound11158 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env11159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157753,1024,32769,12572,147505,54544,21762,8192,65,149521,49168,45405,32040,9225,156012,256,21792,46092,9052]

theorem envBound11159 : H12AffineFastState.Bounded env11159 := by
  intro p hp
  have h : env11159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11158_11159 : H12AffineEnvironment.transform 17 157753 env11158 = env11159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env11158 == env11159) = true)

theorem identity11159 : scanCanonicalize (H12AffineFastState.compose env11159 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound11159 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env11160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,56437,1024,32769,12572,62589,54544,21762,8192,65,64605,49168,45405,32040,9225,54560,256,21792,46092,9052]

theorem envBound11160 : H12AffineFastState.Bounded env11160 := by
  intro p hp
  have h : env11160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11159_11160 : H12AffineEnvironment.transform 16 46156 env11159 = env11160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env11159 == env11160) = true)

theorem identity11160 : scanCanonicalize (H12AffineFastState.compose env11160 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11160 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env11161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,13388,23669,1024,1,12572,29821,21776,21762,8192,65,31837,16400,12637,32040,9225,21792,256,21792,13324,9052]

theorem envBound11161 : H12AffineFastState.Bounded env11161 := by
  intro p hp
  have h : env11161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11160_11161 : H12AffineEnvironment.transform 14 0 env11160 = env11161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11160 == env11161) = true)

theorem identity11161 : scanCanonicalize (H12AffineFastState.compose env11161 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11161 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,34,5220,23669,1024,1,4404,21589,21776,21762,40,65,23669,16400,4469,23808,1057,21792,256,21792,5156,884]

theorem envBound11162 : H12AffineFastState.Bounded env11162 := by
  intro p hp
  have h : env11162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11161_11162 : H12AffineEnvironment.transform 12 40 env11161 = env11162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11161 == env11162) = true)

theorem identity11162 : scanCanonicalize (H12AffineFastState.compose env11162 (packedSelected [2,3,5,10,11,12,14,15,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11162 : packedSelected [2,3,5,10,11,12,14,15,17,23] rootPS < 2^1333 := by decide +kernel

def env11163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,0,34,5220,2421,1024,1,4404,341,16,2,40,65,2421,5392,4469,2048,1057,32,256,32,5156,884]

theorem envBound11163 : H12AffineFastState.Bounded env11163 := by
  intro p hp
  have h : env11163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11162_11163 : H12AffineEnvironment.transform 13 5376 env11162 = env11163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11162 == env11163) = true)

theorem identity11163 : scanCanonicalize (H12AffineFastState.compose env11163 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound11163 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env11164 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2059,40,3339,0,34,3183,2421,1024,1,2367,341,16,2,40,65,2421,3355,2430,2048,1057,32,256,32,3119,884]

theorem envBound11164 : H12AffineFastState.Bounded env11164 := by
  intro p hp
  have h : env11164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11163_11164 : H12AffineEnvironment.transform 11 2059 env11163 = env11164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env11163 == env11164) = true)

theorem identity11164 : scanCanonicalize (H12AffineFastState.compose env11164 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11164 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11165 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,10,40,1290,0,34,1134,372,1024,1,318,341,16,2,40,65,372,1306,383,1,1057,32,256,32,1070,884]

theorem envBound11165 : H12AffineFastState.Bounded env11165 := by
  intro p hp
  have h : env11165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11164_11165 : H12AffineEnvironment.transform 10 1 env11164 = env11165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11164 == env11165) = true)

theorem identity11165 : scanCanonicalize (H12AffineFastState.compose env11165 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound11165 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env11166 : List Nat := [2,4,8,16,32,64,8,256,512,69,1,10,40,335,0,34,43,372,69,1,318,341,16,2,40,65,372,351,383,1,100,32,256,32,107,884]

theorem envBound11166 : H12AffineFastState.Bounded env11166 := by
  intro p hp
  have h : env11166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11165_11166 : H12AffineEnvironment.transform 9 69 env11165 = env11166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env11165 == env11166) = true)

theorem identity11166 : scanCanonicalize (H12AffineFastState.compose env11166 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound11166 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11167 : List Nat := [2,4,8,16,32,64,8,95,512,69,1,10,40,16,0,34,43,43,69,1,97,10,16,2,40,65,43,0,32,1,100,32,95,32,107,555]

theorem envBound11167 : H12AffineFastState.Bounded env11167 := by
  intro p hp
  have h : env11167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11166_11167 : H12AffineEnvironment.transform 7 95 env11166 = env11167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env11166 == env11167) = true)

theorem identity11167 : scanCanonicalize (H12AffineFastState.compose env11167 (packedSelected [2,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11167 : packedSelected [2,6,10] rootPS < 2^1333 := by decide +kernel

def env11168 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,10,2,16,0,8,1,1,69,1,75,10,16,2,2,65,1,0,10,1,78,10,95,10,65,513]

theorem envBound11168 : H12AffineFastState.Bounded env11168 := by
  intro p hp
  have h : env11168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11167_11168 : H12AffineEnvironment.transform 4 10 env11167 = env11168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11167 == env11168) = true)

theorem identity11168 : scanCanonicalize (H12AffineFastState.compose env11168 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11168 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env11169 : List Nat := [2,4,8,16,10,17,8,14,512,20,1,10,2,16,0,8,1,1,20,1,26,10,16,2,2,16,1,0,10,1,31,10,14,10,16,513]

theorem envBound11169 : H12AffineFastState.Bounded env11169 := by
  intro p hp
  have h : env11169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11168_11169 : H12AffineEnvironment.transform 5 17 env11168 = env11169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11168 == env11169) = true)

theorem identity11169 : scanCanonicalize (H12AffineFastState.compose env11169 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11170 : List Nat := [2,4,8,10,10,11,8,14,512,14,1,10,2,10,0,8,1,1,14,1,0,10,10,2,2,10,1,0,10,1,5,10,14,10,10,513]

theorem envBound11170 : H12AffineFastState.Bounded env11170 := by
  intro p hp
  have h : env11170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11169_11170 : H12AffineEnvironment.transform 3 10 env11169 = env11170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11169 == env11170) = true)

theorem identity11170 : scanCanonicalize (H12AffineFastState.compose env11170 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound11170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11171 : List Nat := [2,4,7,5,5,4,7,1,512,1,1,5,2,5,0,7,1,1,1,1,0,5,5,2,2,5,1,0,5,1,5,5,1,5,5,513]

theorem envBound11171 : H12AffineFastState.Bounded env11171 := by
  intro p hp
  have h : env11171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11170_11171 : H12AffineEnvironment.transform 2 7 env11170 = env11171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env11170 == env11171) = true)

def env11172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272393,441640,21762,8193,65,270376,436264,45404,32041,412721,156012,256,21792,46093,412517]

theorem envBound11172 : H12AffineFastState.Bounded env11172 := by
  intro p hp
  have h : env11172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11157_11172 : H12AffineEnvironment.transform 6 9 env11157 = env11172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11157 == env11172) = true)

theorem identity11172 : scanCanonicalize (H12AffineFastState.compose env11172 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound11172 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env11173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16740,262144,1024,32769,268353,272393,326732,21762,8193,65,270376,321868,45404,32041,265557,8200,256,21792,46093,264705]

theorem envBound11173 : H12AffineFastState.Bounded env11173 := by
  intro p hp
  have h : env11173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11172_11173 : H12AffineEnvironment.transform 16 16740 env11172 = env11173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env11172 == env11173) = true)

theorem identity11173 : scanCanonicalize (H12AffineFastState.compose env11173 (packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound11173 : packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS < 2^1333 := by decide +kernel

def env11174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16740,43357,1024,32769,45340,33108,21777,21762,8193,65,35189,16401,45404,32041,41992,8200,256,21792,46093,41820]

theorem envBound11174 : H12AffineFastState.Bounded env11174 := by
  intro p hp
  have h : env11174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11173_11174 : H12AffineEnvironment.transform 17 43357 env11173 = env11174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env11173 == env11174) = true)

theorem identity11174 : scanCanonicalize (H12AffineFastState.compose env11174 (packedSelected [6,9,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11174 : packedSelected [6,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,16740,35188,1024,32769,37173,33108,21777,21762,40,65,35189,16401,37237,23808,33825,33,256,21792,37924,33653]

theorem envBound11175 : H12AffineFastState.Bounded env11175 := by
  intro p hp
  have h : env11175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11174_11175 : H12AffineEnvironment.transform 12 41 env11174 = env11175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11174 == env11175) = true)

theorem identity11175 : scanCanonicalize (H12AffineFastState.compose env11175 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound11175 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env11176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,32768,35,5392,35188,1024,32769,37173,33108,357,374,40,65,35189,5221,37237,2420,33825,33,256,340,37924,33653]

theorem envBound11176 : H12AffineFastState.Bounded env11176 := by
  intro p hp
  have h : env11176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11175_11176 : H12AffineEnvironment.transform 13 5236 env11175 = env11176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env11175 == env11176) = true)

theorem identity11176 : scanCanonicalize (H12AffineFastState.compose env11176 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11176 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11177 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5236,32768,35,5220,34816,1024,32769,36929,32800,17,2,40,65,34817,5221,36865,2048,33825,33,116,32,37924,33281]

theorem envBound11177 : H12AffineFastState.Bounded env11177 := by
  intro p hp
  have h : env11177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11176_11177 : H12AffineEnvironment.transform 7 116 env11176 = env11177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11176 == env11177) = true)

theorem identity11177 : scanCanonicalize (H12AffineFastState.compose env11177 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound11177 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11178 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3109,41,2129,32768,35,2113,34816,1024,32769,35940,32800,17,2,40,65,34817,2112,35876,2048,33825,33,116,32,34817,33281]

theorem envBound11178 : H12AffineFastState.Bounded env11178 := by
  intro p hp
  have h : env11178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11177_11178 : H12AffineEnvironment.transform 11 3109 env11177 = env11178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env11177 == env11178) = true)

theorem identity11178 : scanCanonicalize (H12AffineFastState.compose env11178 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11178 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env11179 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2065,41,2129,32768,35,2113,34816,52,32769,34896,32800,17,2,40,65,34817,2112,34832,2048,32789,33,116,32,34817,33281]

theorem envBound11179 : H12AffineFastState.Bounded env11179 := by
  intro p hp
  have h : env11179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11178_11179 : H12AffineEnvironment.transform 9 52 env11178 = env11179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11178 == env11179) = true)

theorem identity11179 : scanCanonicalize (H12AffineFastState.compose env11179 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound11179 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env11180 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2065,41,2129,80,35,2113,2128,52,81,2048,112,17,2,40,65,2129,2112,2112,2048,69,33,116,32,2129,593]

theorem envBound11180 : H12AffineFastState.Bounded env11180 := by
  intro p hp
  have h : env11180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11179_11180 : H12AffineEnvironment.transform 14 80 env11179 = env11180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env11179 == env11180) = true)

theorem identity11180 : scanCanonicalize (H12AffineFastState.compose env11180 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11180 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11181 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,41,2049,0,35,2065,2048,52,1,2048,32,17,2,40,17,2049,2064,2064,2048,21,33,36,32,2049,513]

theorem envBound11181 : H12AffineFastState.Bounded env11181 := by
  intro p hp
  have h : env11181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11180_11181 : H12AffineEnvironment.transform 5 16 env11180 = env11181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11180 == env11181) = true)

theorem identity11181 : scanCanonicalize (H12AffineFastState.compose env11181 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11181 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11182 : List Nat := [2,4,8,10,32,10,9,36,512,46,2048,2059,41,2049,0,35,2059,2048,46,1,2048,32,11,2,40,11,2049,2058,2058,2048,15,33,36,32,2049,513]

theorem envBound11182 : H12AffineFastState.Bounded env11182 := by
  intro p hp
  have h : env11182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11181_11182 : H12AffineEnvironment.transform 3 10 env11181 = env11182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11181 == env11182) = true)

theorem identity11182 : scanCanonicalize (H12AffineFastState.compose env11182 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11182 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11183 : List Nat := [2,4,3,1,32,1,2,36,512,37,2048,2048,34,2049,0,35,2048,2048,37,1,2048,32,0,2,35,0,2049,2049,2049,2048,4,33,36,32,2049,513]

theorem envBound11183 : H12AffineFastState.Bounded env11183 := by
  intro p hp
  have h : env11183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11182_11183 : H12AffineEnvironment.transform 2 3 env11182 = env11183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11182 == env11183) = true)

theorem identity11183 : scanCanonicalize (H12AffineFastState.compose env11183 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound11183 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11184 : List Nat := [2,4,3,1,32,1,2,36,512,37,512,512,34,513,0,35,512,512,37,1,512,32,0,2,35,0,513,513,513,512,4,33,36,32,513,513]

theorem envBound11184 : H12AffineFastState.Bounded env11184 := by
  intro p hp
  have h : env11184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11183_11184 : H12AffineEnvironment.transform 10 512 env11183 = env11184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env11183 == env11184) = true)

def env11185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272513,441761,95496,8328,65,270377,436385,45525,32160,412856,156013,256,21792,46212,486255]

theorem envBound11185 : H12AffineFastState.Bounded env11185 := by
  intro p hp
  have h : env11185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11155_11185 : H12AffineEnvironment.transform 21 272513 env11155 = env11185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11155 == env11185) = true)

theorem identity11185 : scanCanonicalize (H12AffineFastState.compose env11185 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound11185 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,115870,243002,73754,95496,8328,65,245138,79130,45525,32160,119043,156013,256,21792,46212,63188]

theorem envBound11186 : H12AffineFastState.Bounded env11186 := by
  intro p hp
  have h : env11186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11185_11186 : H12AffineEnvironment.transform 17 236987 env11185 = env11186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env11185 == env11186) = true)

def env11187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67755,1024,32769,115870,73770,73754,95496,8328,65,75906,79130,45525,32160,119043,62589,256,21792,46212,63188]

theorem envBound11187 : H12AffineFastState.Bounded env11187 := by
  intro p hp
  have h : env11187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11186_11187 : H12AffineEnvironment.transform 16 38160 env11186 = env11187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11186 == env11187) = true)

theorem identity11187 : scanCanonicalize (H12AffineFastState.compose env11187 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11187 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env11188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10401,1024,32769,58516,32,16,21762,8328,65,2184,5392,45525,32160,61705,62589,256,21792,46212,63188]

theorem envBound11188 : H12AffineFastState.Bounded env11188 := by
  intro p hp
  have h : env11188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11187_11188 : H12AffineEnvironment.transform 15 8202 env11187 = env11188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11187 == env11188) = true)

theorem identity11188 : scanCanonicalize (H12AffineFastState.compose env11188 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound11188 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env11189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,38160,10401,1024,32769,36929,32,16,8663,8328,65,2184,5392,45525,2421,34268,32936,256,8693,46212,33281]

theorem envBound11189 : H12AffineFastState.Bounded env11189 := by
  intro p hp
  have h : env11189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11188_11189 : H12AffineEnvironment.transform 13 13525 env11188 = env11189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env11188 == env11189) = true)

theorem identity11189 : scanCanonicalize (H12AffineFastState.compose env11189 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11189 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env11190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,8202,5393,10401,1024,0,4160,32,16,8663,8328,65,2184,5392,12756,2421,1501,169,256,8693,13445,512]

theorem envBound11190 : H12AffineFastState.Bounded env11190 := by
  intro p hp
  have h : env11190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11189_11190 : H12AffineEnvironment.transform 14 1 env11189 = env11190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11189 == env11190) = true)

theorem identity11190 : scanCanonicalize (H12AffineFastState.compose env11190 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11190 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11191 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13525,1,8202,5393,10368,1024,0,4160,1,16,8663,8328,65,2184,5392,12756,2388,1501,136,256,8660,13445,512]

theorem envBound11191 : H12AffineFastState.Bounded env11191 := by
  intro p hp
  have h : env11191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11190_11191 : H12AffineEnvironment.transform 4 1 env11190 = env11191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11190 == env11191) = true)

theorem identity11191 : scanCanonicalize (H12AffineFastState.compose env11191 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound11191 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11192 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8192,13525,1,8202,5189,10368,1024,0,4160,1,16,8323,8328,65,2184,5188,12416,2048,1161,136,84,8320,13445,512]

theorem envBound11192 : H12AffineFastState.Bounded env11192 := by
  intro p hp
  have h : env11192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11191_11192 : H12AffineEnvironment.transform 7 84 env11191 = env11192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env11191 == env11192) = true)

theorem identity11192 : scanCanonicalize (H12AffineFastState.compose env11192 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound11192 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env11193 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,129,5204,1,139,5189,2049,1024,0,4160,1,16,2,9,65,2184,5188,4097,2048,1161,136,84,1,5124,512]

theorem envBound11193 : H12AffineFastState.Bounded env11193 := by
  intro p hp
  have h : env11193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11192_11193 : H12AffineEnvironment.transform 12 129 env11192 = env11193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env11192 == env11193) = true)

theorem identity11193 : scanCanonicalize (H12AffineFastState.compose env11193 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound11193 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11194 : List Nat := [2,4,8,16,1,64,128,84,512,1024,136,4096,129,5204,1,139,5189,137,1024,0,4160,1,16,2,9,65,0,5188,4097,136,1161,136,84,1,5124,512]

theorem envBound11194 : H12AffineFastState.Bounded env11194 := by
  intro p hp
  have h : env11194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11193_11194 : H12AffineEnvironment.transform 10 136 env11193 = env11194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env11193 == env11194) = true)

theorem identity11194 : scanCanonicalize (H12AffineFastState.compose env11194 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11194 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11195 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1,4096,8,5204,1,2,5189,0,1024,0,4160,1,16,2,9,65,0,5188,4097,1,1024,1,84,1,5124,512]

theorem envBound11195 : H12AffineFastState.Bounded env11195 := by
  intro p hp
  have h : env11195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11194_11195 : H12AffineEnvironment.transform 6 9 env11194 = env11195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11194 == env11195) = true)

theorem identity11195 : scanCanonicalize (H12AffineFastState.compose env11195 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound11195 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11196 : List Nat := [2,4,8,16,1,64,9,84,512,69,1,4096,8,4113,1,2,4096,0,69,0,4160,1,16,2,9,65,0,4097,4097,1,69,1,84,1,4161,512]

theorem envBound11196 : H12AffineFastState.Bounded env11196 := by
  intro p hp
  have h : env11196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11195_11196 : H12AffineEnvironment.transform 9 69 env11195 = env11196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env11195 == env11196) = true)

theorem identity11196 : scanCanonicalize (H12AffineFastState.compose env11196 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound11196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11197 : List Nat := [2,4,8,16,1,4,9,16,512,1,1,4096,8,4113,1,2,4096,0,1,0,4100,1,16,2,9,5,0,4097,4097,1,1,1,16,1,4101,512]

theorem envBound11197 : H12AffineFastState.Bounded env11197 := by
  intro p hp
  have h : env11197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11196_11197 : H12AffineEnvironment.transform 5 4 env11196 = env11197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env11196 == env11197) = true)

theorem identity11197 : scanCanonicalize (H12AffineFastState.compose env11197 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound11197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11198 : List Nat := [2,4,8,16,1,4,9,16,512,1,1,17,8,0,1,2,17,0,1,0,21,1,16,2,9,5,0,16,16,1,1,1,16,1,20,512]

theorem envBound11198 : H12AffineFastState.Bounded env11198 := by
  intro p hp
  have h : env11198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11197_11198 : H12AffineEnvironment.transform 11 17 env11197 = env11198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11197 == env11198) = true)

theorem identity11198 : scanCanonicalize (H12AffineFastState.compose env11198 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound11198 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11199 : List Nat := [2,4,8,16,1,4,9,16,5,1,1,17,8,0,1,2,17,0,1,0,21,1,16,2,9,5,0,16,16,1,1,1,16,1,20,5]

theorem envBound11199 : H12AffineFastState.Bounded env11199 := by
  intro p hp
  have h : env11199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11198_11199 : H12AffineEnvironment.transform 8 5 env11198 = env11199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env11198 == env11199) = true)

theorem identity11199 : scanCanonicalize (H12AffineFastState.compose env11199 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound11199 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11200 : List Nat := [2,0,8,16,1,0,9,16,1,1,1,17,8,0,1,2,17,0,1,0,17,1,16,2,9,1,0,16,16,1,1,1,16,1,16,1]

theorem envBound11200 : H12AffineFastState.Bounded env11200 := by
  intro p hp
  have h : env11200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11199_11200 : H12AffineEnvironment.transform 1 0 env11199 = env11200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env11199 == env11200) = true)

theorem identity11200 : scanCanonicalize (H12AffineFastState.compose env11200 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11200 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11201 : List Nat := [2,0,8,0,1,0,9,0,1,1,1,1,8,0,1,2,1,0,1,0,1,1,0,2,9,1,0,0,0,1,1,1,0,1,0,1]

theorem envBound11201 : H12AffineFastState.Bounded env11201 := by
  intro p hp
  have h : env11201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11200_11201 : H12AffineEnvironment.transform 3 0 env11200 = env11201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11200 == env11201) = true)

def env11202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,67754,1024,32769,115870,73771,73754,95496,8328,65,75907,79130,45525,32160,119043,62588,256,21792,46212,63188]

theorem envBound11202 : H12AffineFastState.Bounded env11202 := by
  intro p hp
  have h : env11202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11186_11202 : H12AffineEnvironment.transform 16 38161 env11186 = env11202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11186 == env11202) = true)

theorem identity11202 : scanCanonicalize (H12AffineFastState.compose env11202 (packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound11202 : packedSelected [1,3,4,7,9,10,11,14,18,19,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env11203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38161,56437,1024,32769,4161,62708,62661,41431,8328,65,64604,57797,45525,32160,1500,62588,256,21792,46212,63188]

theorem envBound11203 : H12AffineFastState.Bounded env11203 := by
  intro p hp
  have h : env11203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11202_11203 : H12AffineEnvironment.transform 15 54495 env11202 = env11203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env11202 == env11203) = true)

theorem identity11203 : scanCanonicalize (H12AffineFastState.compose env11203 (packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11203 : packedSelected [0,1,3,8,12,16,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env11204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,21726,5392,23668,1024,0,4161,29941,29892,8662,8328,65,31837,25028,12756,32160,1500,29821,256,21792,13445,30421]

theorem envBound11204 : H12AffineFastState.Bounded env11204 := by
  intro p hp
  have h : env11204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11203_11204 : H12AffineEnvironment.transform 14 1 env11203 = env11204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11203 == env11204) = true)

theorem identity11204 : scanCanonicalize (H12AffineFastState.compose env11204 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound11204 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env11205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,1,21726,5392,23668,1024,0,4161,21792,21777,3,349,65,23944,16401,4097,23669,1500,21928,256,21792,5456,22272]

theorem envBound11205 : H12AffineFastState.Bounded env11205 := by
  intro p hp
  have h : env11205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11204_11205 : H12AffineEnvironment.transform 12 469 env11204 = env11205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env11204 == env11205) = true)

theorem identity11205 : scanCanonicalize (H12AffineFastState.compose env11205 (packedSelected [0,1,3,4,5,6,7,8,9,11,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound11205 : packedSelected [0,1,3,4,5,6,7,8,9,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env11206 : List Nat := [2,4,8,16,32,64,128,141,512,1024,2048,4096,88,16384,1,21726,5277,23668,1024,0,4161,21677,21660,3,208,65,23557,16401,4097,23669,1105,21541,141,21677,5341,22157]

theorem envBound11206 : H12AffineFastState.Bounded env11206 := by
  intro p hp
  have h : env11206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11205_11206 : H12AffineEnvironment.transform 7 141 env11205 = env11206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env11205 == env11206) = true)

theorem identity11206 : scanCanonicalize (H12AffineFastState.compose env11206 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5341) := by decide +kernel

theorem selectedBound11206 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11207 : List Nat := [2,4,8,16,32,64,128,141,512,1024,2048,4096,88,5341,1,3,5277,2217,1024,0,4161,112,65,3,208,65,2264,5324,4097,2216,1105,248,141,112,5341,592]

theorem envBound11207 : H12AffineFastState.Bounded env11207 := by
  intro p hp
  have h : env11207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11206_11207 : H12AffineEnvironment.transform 13 5341 env11206 = env11207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5341 env11206 == env11207) = true)

theorem identity11207 : scanCanonicalize (H12AffineFastState.compose env11207 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11207 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11208 : List Nat := [2,4,8,16,32,64,89,84,512,1024,2048,4096,88,5124,1,3,5188,2160,1024,0,4161,112,65,3,9,65,2049,5141,4097,2161,1105,33,84,112,5124,592]

theorem envBound11208 : H12AffineFastState.Bounded env11208 := by
  intro p hp
  have h : env11208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11207_11208 : H12AffineEnvironment.transform 6 89 env11207 = env11208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11207 == env11208) = true)

theorem identity11208 : scanCanonicalize (H12AffineFastState.compose env11208 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11208 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env11209 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5124,1,3,5140,2080,1024,0,4113,32,17,3,9,17,2049,5141,4097,2081,1025,33,4,32,5124,512]

theorem envBound11209 : H12AffineFastState.Bounded env11209 := by
  intro p hp
  have h : env11209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11208_11209 : H12AffineEnvironment.transform 5 16 env11208 = env11209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11208 == env11209) = true)

theorem identity11209 : scanCanonicalize (H12AffineFastState.compose env11209 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11210 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,1,3,5140,2049,1024,0,4113,1,17,3,9,17,2049,5141,4097,2048,1025,0,4,1,5124,512]

theorem envBound11210 : H12AffineFastState.Bounded env11210 := by
  intro p hp
  have h : env11210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11209_11210 : H12AffineEnvironment.transform 4 1 env11209 = env11210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11209 == env11210) = true)

def env11211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound11211 : H12AffineFastState.Bounded env11211 := by
  intro p hp
  have h : env11211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11005_11211 : H12AffineEnvironment.transform 18 1025 env11005 = env11211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11005 == env11211) = true)

theorem identity11211 : scanCanonicalize (H12AffineFastState.compose env11211 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound11211 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616168,18973837,10507601,8579112,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound11212 : H12AffineFastState.Bounded env11212 := by
  intro p hp
  have h : env11212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11211_11212 : H12AffineEnvironment.transform 17 10280 env11211 = env11212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11211 == env11212) = true)

def env11213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616168,18973701,10507601,8579112,25265169,23160137,257,27378725,27337992,25207631]

theorem envBound11213 : H12AffineFastState.Bounded env11213 := by
  intro p hp
  have h : env11213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11212_11213 : H12AffineEnvironment.transform 6 8 env11212 = env11213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11212 == env11213) = true)

theorem identity11213 : scanCanonicalize (H12AffineFastState.compose env11213 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound11213 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,2,8192,65,12838954,2196487,10507601,8579112,8487955,6382923,257,10601511,10560778,8430413]

theorem envBound11214 : H12AffineFastState.Bounded env11214 := by
  intro p hp
  have h : env11214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11213_11214 : H12AffineEnvironment.transform 23 2 env11213 = env11214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env11213 == env11214) = true)

theorem identity11214 : scanCanonicalize (H12AffineFastState.compose env11214 (packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound11214 : packedSelected [1,4,5,7,8,9,12,14,15,16,19,20,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env11215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,8388608,2,8192,65,8570880,2196487,10507601,8579112,8487955,2114913,257,10601511,10560778,8430413]

theorem envBound11215 : H12AffineFastState.Bounded env11215 := by
  intro p hp
  have h : env11215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11214_11215 : H12AffineEnvironment.transform 21 73770 env11214 = env11215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env11214 == env11215) = true)

def env11216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,147456,2,8192,65,34816,2196487,2233681,43048,246803,2114913,257,2327591,2319626,189261]

theorem envBound11216 : H12AffineFastState.Bounded env11216 := by
  intro p hp
  have h : env11216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11215_11216 : H12AffineEnvironment.transform 22 147456 env11215 = env11216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env11215 == env11216) = true)

theorem identity11216 : scanCanonicalize (H12AffineFastState.compose env11216 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound11216 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env11217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,2097152,73770,8524,2,8192,65,34816,2196487,2126877,43048,107871,2114913,257,2221419,2163782,33281]

theorem envBound11217 : H12AffineFastState.Bounded env11217 := by
  intro p hp
  have h : env11217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11216_11217 : H12AffineEnvironment.transform 16 24908 env11216 = env11217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env11216 == env11217) = true)

theorem identity11217 : scanCanonicalize (H12AffineFastState.compose env11217 (packedSelected [1,4,8,9,11,12,14,15,16,17,18,19,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound11217 : packedSelected [1,4,8,9,11,12,14,15,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env11218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,91198,73770,8524,2,8192,65,34816,57401,69667,43048,107871,74079,257,33109,24696,33281]

theorem envBound11218 : H12AffineFastState.Bounded env11218 := by
  intro p hp
  have h : env11218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11217_11218 : H12AffineEnvironment.transform 20 91198 env11217 = env11218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env11217 == env11218) = true)

theorem identity11218 : scanCanonicalize (H12AffineFastState.compose env11218 (packedSelected [3,4,9,10,14,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11218 : packedSelected [3,4,9,10,14,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env11219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,24908,10280,1025,0,91198,73770,8524,2,8192,65,2049,24632,69667,10281,75102,74079,257,340,24696,512]

theorem envBound11219 : H12AffineFastState.Bounded env11219 := by
  intro p hp
  have h : env11219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11218_11219 : H12AffineEnvironment.transform 14 1 env11218 = env11219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11218 == env11219) = true)

theorem identity11219 : scanCanonicalize (H12AffineFastState.compose env11219 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 29791) := by decide +kernel

theorem selectedBound11219 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,29791,24908,10280,1025,0,4193,21621,8524,2,8192,65,2049,24632,25724,10281,20737,21760,257,340,24696,512]

theorem envBound11220 : H12AffineFastState.Bounded env11220 := by
  intro p hp
  have h : env11220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11219_11220 : H12AffineEnvironment.transform 15 29791 env11219 = env11220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29791 env11219 == env11220) = true)

theorem identity11220 : scanCanonicalize (H12AffineFastState.compose env11220 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11220 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env11221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,1,21622,16741,2049,1025,0,4193,21621,357,2,41,65,2049,16401,17493,2048,20737,21760,257,340,16465,512]

theorem envBound11221 : H12AffineFastState.Bounded env11221 := by
  intro p hp
  have h : env11221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11220_11221 : H12AffineEnvironment.transform 12 41 env11220 = env11221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11220 == env11221) = true)

theorem identity11221 : scanCanonicalize (H12AffineFastState.compose env11221 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11221 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env11222 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,1,21622,16401,2049,1025,0,4193,21621,17,2,41,65,2049,16401,17493,2048,20597,21620,117,32,16465,512]

theorem envBound11222 : H12AffineFastState.Bounded env11222 := by
  intro p hp
  have h : env11222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11221_11222 : H12AffineEnvironment.transform 7 116 env11221 = env11222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11221 == env11222) = true)

theorem identity11222 : scanCanonicalize (H12AffineFastState.compose env11222 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11222 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env11223 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,16384,1,21590,16401,2049,1025,0,4161,21589,17,2,9,65,2049,16401,17493,2048,20565,21588,85,0,16465,512]

theorem envBound11223 : H12AffineFastState.Bounded env11223 := by
  intro p hp
  have h : env11223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11222_11223 : H12AffineEnvironment.transform 4 0 env11222 = env11223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11222 == env11223) = true)

theorem identity11223 : scanCanonicalize (H12AffineFastState.compose env11223 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound11223 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11224 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,5205,1,3,5188,2049,1025,0,4161,0,17,2,9,65,2049,5188,4096,2048,1024,1,85,0,5124,512]

theorem envBound11224 : H12AffineFastState.Bounded env11224 := by
  intro p hp
  have h : env11224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11223_11224 : H12AffineEnvironment.transform 13 5205 env11223 = env11224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env11223 == env11224) = true)

theorem identity11224 : scanCanonicalize (H12AffineFastState.compose env11224 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11224 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11225 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,1,3,5141,2049,1025,0,4112,0,17,2,9,16,2049,5141,4096,2048,1024,1,4,0,5124,512]

theorem envBound11225 : H12AffineFastState.Bounded env11225 := by
  intro p hp
  have h : env11225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11224_11225 : H12AffineEnvironment.transform 5 17 env11224 = env11225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11224 == env11225) = true)

def env11226 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1044,1,3,1029,2049,1025,0,0,0,17,2,9,16,2049,1029,16,2048,1024,1,4,0,1044,512]

theorem envBound11226 : H12AffineFastState.Bounded env11226 := by
  intro p hp
  have h : env11226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11225_11226 : H12AffineEnvironment.transform 11 16 env11225 = env11226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11225 == env11226) = true)

theorem identity11226 : scanCanonicalize (H12AffineFastState.compose env11226 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11227 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,9,1044,1,3,1029,1,1025,0,0,0,17,2,9,16,1,1029,16,0,1024,1,4,0,1044,512]

theorem envBound11227 : H12AffineFastState.Bounded env11227 := by
  intro p hp
  have h : env11227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11226_11227 : H12AffineEnvironment.transform 10 0 env11226 = env11227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11226 == env11227) = true)

def env11228 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,1,3,17,1,21,0,0,0,17,2,9,16,1,17,16,0,20,1,4,0,0,512]

theorem envBound11228 : H12AffineFastState.Bounded env11228 := by
  intro p hp
  have h : env11228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11227_11228 : H12AffineEnvironment.transform 9 20 env11227 = env11228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11227 == env11228) = true)

theorem identity11228 : scanCanonicalize (H12AffineFastState.compose env11228 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound11228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11229 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,9,0,1,3,17,1,21,0,0,0,17,2,9,16,1,17,16,0,20,1,4,0,0,30]

theorem envBound11229 : H12AffineFastState.Bounded env11229 := by
  intro p hp
  have h : env11229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11228_11229 : H12AffineEnvironment.transform 8 30 env11228 = env11229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env11228 == env11229) = true)

def leafEnv11229 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,9,0,1,3,17,1,21,0,0,0,17,2,21,9,1,16,1,17,16,0,20,1,4,0,5,3,0,30,1,0,0]

def active11229 : List Nat := [0,1,2,3]

def tree11229 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11229 : H12WitnessSearch.Good tree11229 := H12GlobalWitnessIndex.good

theorem leafIdentity11229 : H12AffineFastState.composeSystem env11229 rootObs = leafEnv11229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11229 rootObs == leafEnv11229) = true)

theorem terminalChecked11229 : H12PackedTerminal.terminalCheckFast leafEnv11229 active11229 tree11229 = true := by decide +kernel

def env11230 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,1,1,3,16,1,20,0,0,0,17,2,9,16,1,16,16,0,21,1,4,0,1,512]

theorem envBound11230 : H12AffineFastState.Bounded env11230 := by
  intro p hp
  have h : env11230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11227_11230 : H12AffineEnvironment.transform 9 21 env11227 = env11230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11227 == env11230) = true)

theorem identity11230 : scanCanonicalize (H12AffineFastState.compose env11230 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound11230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11231 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,1,3,4,1,0,0,0,0,5,2,9,4,1,4,4,0,1,1,4,0,1,512]

theorem envBound11231 : H12AffineFastState.Bounded env11231 := by
  intro p hp
  have h : env11231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11230_11231 : H12AffineEnvironment.transform 3 4 env11230 = env11231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11230 == env11231) = true)

def leafEnv11231 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,1,3,4,1,0,0,0,0,5,2,0,9,1,4,1,4,4,0,1,1,4,0,5,3,1,512,1,0,0]

def active11231 : List Nat := [0,1,2,8]

def tree11231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11231 : H12WitnessSearch.Good tree11231 := H12GlobalWitnessIndex.good

theorem leafIdentity11231 : H12AffineFastState.composeSystem env11231 rootObs = leafEnv11231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11231 rootObs == leafEnv11231) = true)

theorem terminalChecked11231 : H12PackedTerminal.terminalCheckFast leafEnv11231 active11231 tree11231 = true := by decide +kernel

def env11232 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1045,1,3,1028,2049,1025,0,1,0,17,2,9,16,2049,1028,17,2048,1024,1,4,0,1045,512]

theorem envBound11232 : H12AffineFastState.Bounded env11232 := by
  intro p hp
  have h : env11232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11225_11232 : H12AffineEnvironment.transform 11 17 env11225 = env11232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11225 == env11232) = true)

theorem identity11232 : scanCanonicalize (H12AffineFastState.compose env11232 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound11232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11233 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,9,1045,1,3,1028,1044,1025,0,1,0,17,2,9,16,1044,1028,17,1045,1024,1,4,0,1045,512]

theorem envBound11233 : H12AffineFastState.Bounded env11233 := by
  intro p hp
  have h : env11233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11232_11233 : H12AffineEnvironment.transform 10 1045 env11232 = env11233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env11232 == env11233) = true)

def env11234 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,9,1,1,3,16,0,21,0,1,0,17,2,9,16,0,16,17,1,20,1,4,0,1,512]

theorem envBound11234 : H12AffineFastState.Bounded env11234 := by
  intro p hp
  have h : env11234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11233_11234 : H12AffineEnvironment.transform 9 20 env11233 = env11234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11233 == env11234) = true)

theorem identity11234 : scanCanonicalize (H12AffineFastState.compose env11234 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound11234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11235 : List Nat := [2,4,8,16,0,17,8,5,31,20,1,17,9,1,1,3,16,0,21,0,1,0,17,2,9,16,0,16,17,1,20,1,4,0,1,31]

theorem envBound11235 : H12AffineFastState.Bounded env11235 := by
  intro p hp
  have h : env11235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11234_11235 : H12AffineEnvironment.transform 8 31 env11234 = env11235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env11234 == env11235) = true)

def leafEnv11235 : List Nat := [2,4,8,16,0,17,8,5,31,20,1,17,9,1,1,3,16,0,21,0,1,0,17,2,21,9,1,16,0,16,17,1,20,1,4,0,5,3,1,31,1,1,0]

def active11235 : List Nat := [0,1,2,3]

def tree11235 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11235 : H12WitnessSearch.Good tree11235 := H12GlobalWitnessIndex.good

theorem leafIdentity11235 : H12AffineFastState.composeSystem env11235 rootObs = leafEnv11235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11235 rootObs == leafEnv11235) = true)

theorem terminalChecked11235 : H12PackedTerminal.terminalCheckFast leafEnv11235 active11235 tree11235 = true := by decide +kernel

def env11236 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,0,1,3,17,1,20,0,1,0,17,2,9,16,1,17,17,0,21,1,4,0,0,512]

theorem envBound11236 : H12AffineFastState.Bounded env11236 := by
  intro p hp
  have h : env11236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11233_11236 : H12AffineEnvironment.transform 9 21 env11233 = env11236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11233 == env11236) = true)

theorem identity11236 : scanCanonicalize (H12AffineFastState.compose env11236 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound11236 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11237 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,5,9,0,1,3,5,1,0,0,1,0,5,2,9,4,1,5,5,0,1,1,4,0,0,512]

theorem envBound11237 : H12AffineFastState.Bounded env11237 := by
  intro p hp
  have h : env11237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11236_11237 : H12AffineEnvironment.transform 3 4 env11236 = env11237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env11236 == env11237) = true)

def leafEnv11237 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,5,9,0,1,3,5,1,0,0,1,0,5,2,0,9,1,4,1,5,5,0,1,1,4,0,5,3,0,512,1,1,0]

def active11237 : List Nat := [0,1,2,8]

def tree11237 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11237 : H12WitnessSearch.Good tree11237 := H12GlobalWitnessIndex.good

theorem leafIdentity11237 : H12AffineFastState.composeSystem env11237 rootObs = leafEnv11237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11237 rootObs == leafEnv11237) = true)

theorem terminalChecked11237 : H12PackedTerminal.terminalCheckFast leafEnv11237 active11237 tree11237 = true := by decide +kernel

def env11238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,73770,147457,2,8192,65,34817,2196487,2233680,43049,246802,2114913,257,2327590,2319627,189260]

theorem envBound11238 : H12AffineFastState.Bounded env11238 := by
  intro p hp
  have h : env11238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11215_11238 : H12AffineEnvironment.transform 22 147457 env11215 = env11238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env11215 == env11238) = true)

theorem identity11238 : scanCanonicalize (H12AffineFastState.compose env11238 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound11238 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env11239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,2097152,73770,65863,2,8192,65,34817,2196487,2184214,43049,34132,2114913,257,2147680,2106445,107018]

theorem envBound11239 : H12AffineFastState.Bounded env11239 := by
  intro p hp
  have h : env11239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11238_11239 : H12AffineEnvironment.transform 16 82246 env11238 = env11239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env11238 == env11239) = true)

theorem identity11239 : scanCanonicalize (H12AffineFastState.compose env11239 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound11239 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env11240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57677,10280,1025,32769,2097152,32801,41292,2,8192,65,34817,2106380,2159645,43049,34132,2114913,257,2147680,2106445,513]

theorem envBound11240 : H12AffineFastState.Bounded env11240 := by
  intro p hp
  have h : env11240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11239_11240 : H12AffineEnvironment.transform 15 40971 env11239 = env11240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env11239 == env11240) = true)

theorem identity11240 : scanCanonicalize (H12AffineFastState.compose env11240 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11240 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env11241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,40971,45405,10280,1025,32769,2097152,32801,41292,2,8192,65,34817,2106380,2139149,43049,34132,2102641,257,2135408,2106445,513]

theorem envBound11241 : H12AffineFastState.Bounded env11241 := by
  intro p hp
  have h : env11241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11240_11241 : H12AffineEnvironment.transform 13 4112 env11240 = env11241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11240 == env11241) = true)

theorem identity11241 : scanCanonicalize (H12AffineFastState.compose env11241 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound11241 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env11242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,40971,45405,10280,1025,32769,13689,32801,41292,2,8192,65,34817,4469,37236,43049,34132,8200,257,40969,4404,513]

theorem envBound11242 : H12AffineFastState.Bounded env11242 := by
  intro p hp
  have h : env11242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11241_11242 : H12AffineEnvironment.transform 20 13689 env11241 = env11242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env11241 == env11242) = true)

theorem identity11242 : scanCanonicalize (H12AffineFastState.compose env11242 (packedSelected [2,4,6,9,11,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11242 : packedSelected [2,4,6,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env11243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,4112,12315,8525,10280,1025,4113,13689,4145,12636,2,8192,65,6161,4469,356,14393,5444,8200,257,12313,4404,513]

theorem envBound11243 : H12AffineFastState.Bounded env11243 := by
  intro p hp
  have h : env11243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11242_11243 : H12AffineEnvironment.transform 14 4112 env11242 = env11243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env11242 == env11243) = true)

theorem identity11243 : scanCanonicalize (H12AffineFastState.compose env11243 (packedSelected [0,2,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound11243 : packedSelected [0,2,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env11244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,8192,372,372,8575,8525,10280,1025,373,9245,341,8248,2,8192,65,2421,17,356,10589,1056,8200,257,8573,80,513]

theorem envBound11244 : H12AffineFastState.Bounded env11244 := by
  intro p hp
  have h : env11244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11243_11244 : H12AffineEnvironment.transform 11 356 env11243 = env11244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env11243 == env11244) = true)

theorem identity11244 : scanCanonicalize (H12AffineFastState.compose env11244 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11244 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,349,372,372,34,16,2421,1025,373,1344,341,357,2,349,65,2421,17,356,2048,1056,341,257,32,80,513]

theorem envBound11245 : H12AffineFastState.Bounded env11245 := by
  intro p hp
  have h : env11245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11244_11245 : H12AffineEnvironment.transform 12 349 env11244 = env11245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11244 == env11245) = true)

theorem identity11245 : scanCanonicalize (H12AffineFastState.compose env11245 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11245 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11246 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,17,40,1,1,34,16,2048,1025,0,1077,32,16,2,40,65,2048,17,17,2048,1056,32,116,32,80,513]

theorem envBound11246 : H12AffineFastState.Bounded env11246 := by
  intro p hp
  have h : env11246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11245_11246 : H12AffineEnvironment.transform 7 117 env11245 = env11246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11245 == env11246) = true)

theorem identity11246 : scanCanonicalize (H12AffineFastState.compose env11246 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound11246 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11247 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1646,17,40,1,1,34,16,1646,1025,0,1077,32,16,2,40,65,1646,17,17,1646,1056,32,116,32,80,513]

theorem envBound11247 : H12AffineFastState.Bounded env11247 := by
  intro p hp
  have h : env11247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11246_11247 : H12AffineEnvironment.transform 10 1646 env11246 = env11247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env11246 == env11247) = true)

theorem identity11247 : scanCanonicalize (H12AffineFastState.compose env11247 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11247 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1