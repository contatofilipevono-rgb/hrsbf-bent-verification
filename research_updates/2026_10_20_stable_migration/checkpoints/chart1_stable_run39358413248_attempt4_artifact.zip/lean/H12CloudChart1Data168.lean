import H12CloudChart1Data167

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def leafEnv42599 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,16,8,1,1,2,16,523,20,0,0,0,17,3,20,9,1,17,522,17,17,523,20,0,5,1,4,3,1,513,1,0,0]

def active42599 : List Nat := [0,1,2,3,8]

def tree42599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42599 : H12WitnessSearch.Good tree42599 := H12GlobalWitnessIndex.good

theorem leafIdentity42599 : H12AffineFastState.composeSystem env42599 rootObs = leafEnv42599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42599 rootObs == leafEnv42599) = true)

theorem terminalChecked42599 : H12PackedTerminal.terminalCheckFast leafEnv42599 active42599 tree42599 = true := by decide +kernel

def env42600 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,8,0,1,2,17,2049,21,0,0,0,17,3,9,17,2048,16,17,2049,21,0,5,1,0,513]

theorem envBound42600 : H12AffineFastState.Bounded env42600 := by
  intro p hp
  have h : env42600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42597_42600 : H12AffineEnvironment.transform 9 21 env42597 = env42600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42597 == env42600) = true)

theorem identity42600 : scanCanonicalize (H12AffineFastState.compose env42600 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42601 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,8,0,1,2,17,1,21,0,0,0,17,3,9,17,0,16,17,1,21,0,5,1,0,513]

theorem envBound42601 : H12AffineFastState.Bounded env42601 := by
  intro p hp
  have h : env42601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42600_42601 : H12AffineEnvironment.transform 10 0 env42600 = env42601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42600 == env42601) = true)

def leafEnv42601 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,8,0,1,2,17,1,21,0,0,0,17,3,21,9,1,17,0,16,17,1,21,0,5,1,4,3,0,513,1,0,0]

def active42601 : List Nat := [0,1,2,3,8]

def tree42601 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42601 : H12WitnessSearch.Good tree42601 := H12GlobalWitnessIndex.good

theorem leafIdentity42601 : H12AffineFastState.composeSystem env42601 rootObs = leafEnv42601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42601 rootObs == leafEnv42601) = true)

theorem terminalChecked42601 : H12PackedTerminal.terminalCheckFast leafEnv42601 active42601 tree42601 = true := by decide +kernel

def env42602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98780,8328,65,4259061,5393,17665,32041,1501,4256861,256,21792,46213,74250]

theorem envBound42602 : H12AffineFastState.Bounded env42602 := by
  intro p hp
  have h : env42602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42579_42602 : H12AffineEnvironment.transform 20 4161 env42579 = env42602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42579 == env42602) = true)

def env42603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98644,8192,65,4258941,5393,17665,32041,1365,4256861,256,21792,46093,74250]

theorem envBound42603 : H12AffineFastState.Bounded env42603 := by
  intro p hp
  have h : env42603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42602_42603 : H12AffineEnvironment.transform 6 8 env42602 = env42603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42602 == env42603) = true)

theorem identity42603 : scanCanonicalize (H12AffineFastState.compose env42603 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound42603 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35189,1024,32769,4161,4194304,16,98644,8192,65,4258941,5393,17665,32041,1365,4256861,256,21792,46093,74250]

theorem envBound42604 : H12AffineFastState.Bounded env42604 := by
  intro p hp
  have h : env42604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42603_42604 : H12AffineEnvironment.transform 16 13389 env42603 = env42604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env42603 == env42604) = true)

theorem identity42604 : scanCanonicalize (H12AffineFastState.compose env42604 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42604 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env42605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,13389,35189,1024,32769,4161,4194304,16,98644,8192,65,4229152,5393,12636,2420,1365,4227072,256,8573,46093,74250]

theorem envBound42605 : H12AffineFastState.Bounded env42605 := by
  intro p hp
  have h : env42605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42604_42605 : H12AffineEnvironment.transform 13 13405 env42604 = env42605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42604 == env42605) = true)

theorem identity42605 : scanCanonicalize (H12AffineFastState.compose env42605 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42605 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8203,13389,35189,1024,32769,4161,4194304,16,41311,8192,65,4229152,5393,12636,2420,1365,4227072,256,8573,46093,513]

theorem envBound42606 : H12AffineFastState.Bounded env42606 := by
  intro p hp
  have h : env42606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42605_42606 : H12AffineEnvironment.transform 15 8203 env42605 = env42606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42605 == env42606) = true)

theorem identity42606 : scanCanonicalize (H12AffineFastState.compose env42606 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound42606 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,9293,8203,13389,11576,1024,9292,4161,4194304,16,1298,8192,65,4205677,5393,12636,2420,1365,4203597,256,8573,4160,513]

theorem envBound42607 : H12AffineFastState.Bounded env42607 := by
  intro p hp
  have h : env42607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42606_42607 : H12AffineEnvironment.transform 14 9293 env42606 = env42607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env42606 == env42607) = true)

theorem identity42607 : scanCanonicalize (H12AffineFastState.compose env42607 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound42607 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env42608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5416,373,4453,5411,357,6160,1024,4452,4161,4194304,16,1298,5416,65,4200773,5393,1140,2420,1365,4198757,256,5205,4160,513]

theorem envBound42608 : H12AffineFastState.Bounded env42608 := by
  intro p hp
  have h : env42608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42607_42608 : H12AffineEnvironment.transform 12 5416 env42607 = env42608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env42607 == env42608) = true)

theorem identity42608 : scanCanonicalize (H12AffineFastState.compose env42608 (packedSelected [0,27] rootPS)) = affineNative (2^(21+1) ^^^ 1328) := by decide +kernel

theorem selectedBound42608 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env42609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5416,373,4453,5411,357,6160,1024,4452,4161,1328,16,1298,5416,65,7285,5393,1140,2420,1365,5205,256,5205,4160,513]

theorem envBound42609 : H12AffineFastState.Bounded env42609 := by
  intro p hp
  have h : env42609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42608_42609 : H12AffineEnvironment.transform 21 1328 env42608 = env42609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1328 env42608 == env42609) = true)

theorem identity42609 : scanCanonicalize (H12AffineFastState.compose env42609 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42609 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42610 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,4153,373,4453,4146,357,6160,273,4452,4161,33,16,3,4153,65,6500,4096,357,2420,68,4420,256,4420,4160,513]

theorem envBound42610 : H12AffineFastState.Bounded env42610 := by
  intro p hp
  have h : env42610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42609_42610 : H12AffineEnvironment.transform 9 273 env42609 = env42610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42609 == env42610) = true)

theorem identity42610 : scanCanonicalize (H12AffineFastState.compose env42610 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42611 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,4096,4120,340,4420,4115,324,6160,273,4421,4161,0,16,3,4120,65,6469,4096,324,2389,68,4420,256,4420,4160,513]

theorem envBound42611 : H12AffineFastState.Bounded env42611 := by
  intro p hp
  have h : env42611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42610_42611 : H12AffineEnvironment.transform 4 1 env42610 = env42611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42610 == env42611) = true)

theorem identity42611 : scanCanonicalize (H12AffineFastState.compose env42611 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound42611 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42612 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,324,348,340,0,343,324,2388,273,1,261,0,16,3,348,65,2049,324,324,2389,68,0,256,0,260,513]

theorem envBound42612 : H12AffineFastState.Bounded env42612 := by
  intro p hp
  have h : env42612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42611_42612 : H12AffineEnvironment.transform 11 324 env42611 = env42612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env42611 == env42612) = true)

theorem identity42612 : scanCanonicalize (H12AffineFastState.compose env42612 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42612 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42613 : List Nat := [2,4,8,16,1,64,8,5,512,20,2048,65,89,81,0,82,65,2129,20,1,0,0,16,3,89,65,2049,65,65,2128,68,0,5,0,1,513]

theorem envBound42613 : H12AffineFastState.Bounded env42613 := by
  intro p hp
  have h : env42613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42612_42613 : H12AffineEnvironment.transform 7 5 env42612 = env42613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42612 == env42613) = true)

theorem identity42613 : scanCanonicalize (H12AffineFastState.compose env42613 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound42613 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42614 : List Nat := [2,4,8,16,1,64,8,5,512,20,592,65,89,81,0,82,65,513,20,1,0,0,16,3,89,65,593,65,65,512,68,0,5,0,1,513]

theorem envBound42614 : H12AffineFastState.Bounded env42614 := by
  intro p hp
  have h : env42614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42613_42614 : H12AffineEnvironment.transform 10 592 env42613 = env42614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env42613 == env42614) = true)

theorem identity42614 : scanCanonicalize (H12AffineFastState.compose env42614 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound42614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42615 : List Nat := [2,4,8,16,1,64,8,5,81,20,1,65,89,81,0,82,65,80,20,1,0,0,16,3,89,65,0,65,65,81,68,0,5,0,1,80]

theorem envBound42615 : H12AffineFastState.Bounded env42615 := by
  intro p hp
  have h : env42615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42614_42615 : H12AffineEnvironment.transform 8 81 env42614 = env42615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env42614 == env42615) = true)

theorem identity42615 : scanCanonicalize (H12AffineFastState.compose env42615 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42615 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42616 : List Nat := [2,4,8,1,1,64,8,5,64,5,1,65,72,64,0,67,65,65,5,1,0,0,1,3,72,65,0,65,65,64,68,0,5,0,1,65]

theorem envBound42616 : H12AffineFastState.Bounded env42616 := by
  intro p hp
  have h : env42616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42615_42616 : H12AffineEnvironment.transform 3 1 env42615 = env42616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42615 == env42616) = true)

theorem identity42616 : scanCanonicalize (H12AffineFastState.compose env42616 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42617 : List Nat := [2,4,8,1,1,1,8,5,1,5,1,0,9,1,0,2,0,0,5,1,0,0,1,3,9,0,0,0,0,1,5,0,5,0,1,0]

theorem envBound42617 : H12AffineFastState.Bounded env42617 := by
  intro p hp
  have h : env42617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42616_42617 : H12AffineEnvironment.transform 5 1 env42616 = env42617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42616 == env42617) = true)

def env42618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98645,8193,65,4258940,5393,17665,32041,1364,4256861,256,21792,46092,74250]

theorem envBound42618 : H12AffineFastState.Bounded env42618 := by
  intro p hp
  have h : env42618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42602_42618 : H12AffineEnvironment.transform 6 9 env42602 = env42618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42602 == env42618) = true)

theorem identity42618 : scanCanonicalize (H12AffineFastState.compose env42618 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound42618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,4194304,16,98645,8193,65,4258940,5393,17665,32041,1364,4256861,256,21792,46092,74250]

theorem envBound42619 : H12AffineFastState.Bounded env42619 := by
  intro p hp
  have h : env42619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42618_42619 : H12AffineEnvironment.transform 16 38160 env42618 = env42619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42618 == env42619) = true)

theorem identity42619 : scanCanonicalize (H12AffineFastState.compose env42619 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound42619 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,33,16,98645,8193,65,64605,5393,17665,32041,1364,62588,256,21792,46092,74250]

theorem envBound42620 : H12AffineFastState.Bounded env42620 := by
  intro p hp
  have h : env42620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42619_42620 : H12AffineEnvironment.transform 21 33 env42619 = env42620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env42619 == env42620) = true)

theorem identity42620 : scanCanonicalize (H12AffineFastState.compose env42620 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42620 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env42621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10280,1024,32769,4161,33,16,98645,8193,65,43357,5393,4097,10281,1364,41340,256,32,46092,74250]

theorem envBound42621 : H12AffineFastState.Bounded env42621 := by
  intro p hp
  have h : env42621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42620_42621 : H12AffineEnvironment.transform 13 5376 env42620 = env42621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42620 == env42621) = true)

theorem identity42621 : scanCanonicalize (H12AffineFastState.compose env42621 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound42621 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env42622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40971,38160,10280,1024,32769,4161,33,16,8542,8193,65,43357,5393,4097,10281,1364,41340,256,32,46092,33281]

theorem envBound42622 : H12AffineFastState.Bounded env42622 := by
  intro p hp
  have h : env42622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42621_42622 : H12AffineEnvironment.transform 15 40971 env42621 = env42622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env42621 == env42622) = true)

theorem identity42622 : scanCanonicalize (H12AffineFastState.compose env42622 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound42622 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env42623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,8283,5440,10280,1024,81,4161,33,16,8542,8193,65,10509,5393,4097,10281,1364,8492,256,32,13404,593]

theorem envBound42623 : H12AffineFastState.Bounded env42623 := by
  intro p hp
  have h : env42623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42622_42623 : H12AffineEnvironment.transform 14 80 env42622 = env42623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env42622 == env42623) = true)

theorem identity42623 : scanCanonicalize (H12AffineFastState.compose env42623 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound42623 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env42624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5416,5376,80,5491,5440,7424,1024,81,4161,33,16,5238,5417,65,7205,5393,4097,7425,1364,5124,256,32,372,593]

theorem envBound42624 : H12AffineFastState.Bounded env42624 := by
  intro p hp
  have h : env42624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42623_42624 : H12AffineEnvironment.transform 12 5416 env42623 = env42624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env42623 == env42624) = true)

theorem identity42624 : scanCanonicalize (H12AffineFastState.compose env42624 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound42624 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env42625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,2397,2421,80,2310,2357,373,1024,81,3124,33,16,2051,2396,65,80,2404,3188,372,1364,2161,256,32,372,593]

theorem envBound42625 : H12AffineFastState.Bounded env42625 := by
  intro p hp
  have h : env42625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42624_42625 : H12AffineEnvironment.transform 11 3189 env42624 = env42625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env42624 == env42625) = true)

def env42626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101328,98781,8328,65,6352053,2098513,17664,2125160,2102684,6349853,256,21792,46213,2175563]

theorem envBound42626 : H12AffineFastState.Bounded env42626 := by
  intro p hp
  have h : env42626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42626 : H12AffineEnvironment.transform 17 179513 env42578 = env42626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env42578 == env42626) = true)

def env42627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98781,8328,65,4259061,5393,17664,32040,1500,4256861,256,21792,46213,74251]

theorem envBound42627 : H12AffineFastState.Bounded env42627 := by
  intro p hp
  have h : env42627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42626_42627 : H12AffineEnvironment.transform 20 4160 env42626 = env42627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42626 == env42627) = true)

theorem identity42627 : scanCanonicalize (H12AffineFastState.compose env42627 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound42627 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149996,1024,29908,4160,4194304,16,95496,8328,65,4196384,5393,17664,32040,1500,4194440,256,21792,16464,74251]

theorem envBound42628 : H12AffineFastState.Bounded env42628 := by
  intro p hp
  have h : env42628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42627_42628 : H12AffineEnvironment.transform 14 29909 env42627 = env42628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env42627 == env42628) = true)

def env42629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138476,1024,8660,4160,4194304,16,73736,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,74251]

theorem envBound42629 : H12AffineFastState.Bounded env42629 := by
  intro p hp
  have h : env42629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42628_42629 : H12AffineEnvironment.transform 13 5376 env42628 = env42629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42628 == env42629) = true)

theorem identity42629 : scanCanonicalize (H12AffineFastState.compose env42629 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound42629 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,10280,1024,8660,4160,4194304,16,73736,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,74251]

theorem envBound42630 : H12AffineFastState.Bounded env42630 := by
  intro p hp
  have h : env42630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42629_42630 : H12AffineEnvironment.transform 16 13508 env42629 = env42630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env42629 == env42630) = true)

theorem identity42630 : scanCanonicalize (H12AffineFastState.compose env42630 (packedSelected [0,2,4,6,9,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound42630 : packedSelected [0,2,4,6,9,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env42631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,478,13508,10280,1024,8660,4160,4194304,16,8662,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5456,9173]

theorem envBound42631 : H12AffineFastState.Bounded env42631 := by
  intro p hp
  have h : env42631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42630_42631 : H12AffineEnvironment.transform 15 478 env42630 = env42631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env42630 == env42631) = true)

theorem identity42631 : scanCanonicalize (H12AffineFastState.compose env42631 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42631 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env42632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,343,13389,10280,1024,8541,4160,4194304,16,8543,8193,65,4196384,5393,4096,10280,1365,4194305,256,32,5456,9052]

theorem envBound42632 : H12AffineFastState.Bounded env42632 := by
  intro p hp
  have h : env42632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42631_42632 : H12AffineEnvironment.transform 6 9 env42631 = env42632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42631 == env42632) = true)

theorem identity42632 : scanCanonicalize (H12AffineFastState.compose env42632 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42632 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4160,4194304,16,2,348,65,4196384,5393,4096,2421,1365,4194305,256,32,5456,513]

theorem envBound42633 : H12AffineFastState.Bounded env42633 := by
  intro p hp
  have h : env42633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42632_42633 : H12AffineEnvironment.transform 12 349 env42632 = env42633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42632 == env42633) = true)

theorem identity42633 : scanCanonicalize (H12AffineFastState.compose env42633 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound42633 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4160,113,16,2,348,65,2129,5393,4096,2421,1365,112,256,32,5456,513]

theorem envBound42634 : H12AffineFastState.Bounded env42634 := by
  intro p hp
  have h : env42634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42633_42634 : H12AffineEnvironment.transform 21 113 env42633 = env42634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env42633 == env42634) = true)

def env42635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138477,1024,8661,4160,4194304,16,73737,8328,65,4196384,5393,4097,10281,1500,4194440,256,33,5457,74251]

theorem envBound42635 : H12AffineFastState.Bounded env42635 := by
  intro p hp
  have h : env42635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42628_42635 : H12AffineEnvironment.transform 13 5377 env42628 = env42635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42628 == env42635) = true)

theorem identity42635 : scanCanonicalize (H12AffineFastState.compose env42635 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound42635 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,10401,1024,8661,4160,4194304,16,73737,8328,65,4196384,5393,4097,10281,1500,4194440,256,33,5457,74251]

theorem envBound42636 : H12AffineFastState.Bounded env42636 := by
  intro p hp
  have h : env42636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42635_42636 : H12AffineEnvironment.transform 16 13388 env42635 = env42636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env42635 == env42636) = true)

theorem identity42636 : scanCanonicalize (H12AffineFastState.compose env42636 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound42636 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env42637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,10401,1024,8661,4160,169,16,73737,8328,65,2185,5393,4097,10281,1500,33,256,33,5457,74251]

theorem envBound42637 : H12AffineFastState.Bounded env42637 := by
  intro p hp
  have h : env42637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42636_42637 : H12AffineEnvironment.transform 21 169 env42636 = env42637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env42636 == env42637) = true)

theorem identity42637 : scanCanonicalize (H12AffineFastState.compose env42637 (packedSelected [0,2,3,5,6,10,11,12,14,15,16,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound42637 : packedSelected [0,2,3,5,6,10,11,12,14,15,16,20,23,27] rootPS < 2^1333 := by decide +kernel

def env42638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,13388,10401,1024,8661,4160,169,16,138,8328,65,2185,5393,4097,10281,1500,33,256,33,5457,648]

theorem envBound42638 : H12AffineFastState.Bounded env42638 := by
  intro p hp
  have h : env42638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42637_42638 : H12AffineEnvironment.transform 15 8323 env42637 = env42638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env42637 == env42638) = true)

theorem identity42638 : scanCanonicalize (H12AffineFastState.compose env42638 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound42638 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42639 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,8192,5340,8201,8323,13388,10401,1024,8200,4160,169,16,138,8328,65,2185,5324,4097,10281,1025,33,221,33,5260,648]

theorem envBound42639 : H12AffineFastState.Bounded env42639 := by
  intro p hp
  have h : env42639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42638_42639 : H12AffineEnvironment.transform 7 221 env42638 = env42639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env42638 == env42639) = true)

theorem identity42639 : scanCanonicalize (H12AffineFastState.compose env42639 (packedSelected [3,4,5,6,9,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound42639 : packedSelected [3,4,5,6,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env42640 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5340,136,2,5325,2080,1024,137,4160,169,16,138,9,65,2185,5324,4097,2216,1025,33,221,33,5260,648]

theorem envBound42640 : H12AffineFastState.Bounded env42640 := by
  intro p hp
  have h : env42640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42639_42640 : H12AffineEnvironment.transform 12 129 env42639 = env42640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env42639 == env42640) = true)

theorem identity42640 : scanCanonicalize (H12AffineFastState.compose env42640 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42640 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42641 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5205,1,2,5188,2080,1024,0,4160,32,16,3,9,65,2048,5189,4097,2081,1025,33,84,33,5125,513]

theorem envBound42641 : H12AffineFastState.Bounded env42641 := by
  intro p hp
  have h : env42641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42640_42641 : H12AffineEnvironment.transform 6 9 env42640 = env42641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42640 == env42641) = true)

theorem identity42641 : scanCanonicalize (H12AffineFastState.compose env42641 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1620) := by decide +kernel

theorem selectedBound42641 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42642 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,1620,8,513,1,2,528,2080,1024,0,1556,32,16,3,9,65,2048,529,1621,2081,1025,33,84,33,593,513]

theorem envBound42642 : H12AffineFastState.Bounded env42642 := by
  intro p hp
  have h : env42642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42641_42642 : H12AffineEnvironment.transform 11 1620 env42641 = env42642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1620 env42641 == env42642) = true)

theorem identity42642 : scanCanonicalize (H12AffineFastState.compose env42642 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42643 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,1541,8,513,1,2,528,2080,1024,0,1556,32,16,3,9,16,2048,529,1540,2081,1025,33,5,33,512,513]

theorem envBound42643 : H12AffineFastState.Bounded env42643 := by
  intro p hp
  have h : env42643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42642_42643 : H12AffineEnvironment.transform 5 17 env42642 = env42643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42642 == env42643) = true)

theorem identity42643 : scanCanonicalize (H12AffineFastState.compose env42643 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound42643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42644 : List Nat := [2,4,8,16,32,17,9,5,512,549,2048,32,8,513,1,2,528,2080,549,0,49,32,16,3,9,16,2048,529,33,2081,548,33,5,33,512,513]

theorem envBound42644 : H12AffineFastState.Bounded env42644 := by
  intro p hp
  have h : env42644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42643_42644 : H12AffineEnvironment.transform 9 549 env42643 = env42644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env42643 == env42644) = true)

theorem identity42644 : scanCanonicalize (H12AffineFastState.compose env42644 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42644 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42645 : List Nat := [2,4,8,16,32,17,9,5,512,549,0,32,8,513,1,2,528,32,549,0,49,32,16,3,9,16,0,529,33,33,548,33,5,33,512,513]

theorem envBound42645 : H12AffineFastState.Bounded env42645 := by
  intro p hp
  have h : env42645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42644_42645 : H12AffineEnvironment.transform 10 0 env42644 = env42645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42644 == env42645) = true)

theorem identity42645 : scanCanonicalize (H12AffineFastState.compose env42645 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42645 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42646 : List Nat := [2,4,8,16,32,17,9,5,17,52,0,32,8,16,1,2,1,32,52,0,49,32,16,3,9,16,0,0,33,33,53,33,5,33,17,16]

theorem envBound42646 : H12AffineFastState.Bounded env42646 := by
  intro p hp
  have h : env42646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42645_42646 : H12AffineEnvironment.transform 8 17 env42645 = env42646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42645 == env42646) = true)

theorem identity42646 : scanCanonicalize (H12AffineFastState.compose env42646 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42647 : List Nat := [2,4,8,1,32,0,9,5,0,37,0,32,8,1,1,2,1,32,37,0,32,32,1,3,9,1,0,0,33,33,36,33,5,33,0,1]

theorem envBound42647 : H12AffineFastState.Bounded env42647 := by
  intro p hp
  have h : env42647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42646_42647 : H12AffineEnvironment.transform 3 1 env42646 = env42647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42646 == env42647) = true)

def env42648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,17,98781,8328,65,4259060,5392,17664,32041,1501,4256860,256,21792,46213,74250]

theorem envBound42648 : H12AffineFastState.Bounded env42648 := by
  intro p hp
  have h : env42648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42626_42648 : H12AffineEnvironment.transform 20 4161 env42626 = env42648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42626 == env42648) = true)

theorem identity42648 : scanCanonicalize (H12AffineFastState.compose env42648 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound42648 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,17,98781,8328,65,171416,5392,17664,32041,1501,169264,256,21792,46213,74250]

theorem envBound42649 : H12AffineFastState.Bounded env42649 := by
  intro p hp
  have h : env42649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42648_42649 : H12AffineEnvironment.transform 21 156012 env42648 = env42649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env42648 == env42649) = true)

def env42650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,17,98645,8192,65,171280,5392,17664,32041,1365,169264,256,21792,46093,74250]

theorem envBound42650 : H12AffineFastState.Bounded env42650 := by
  intro p hp
  have h : env42650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42649_42650 : H12AffineEnvironment.transform 6 8 env42649 = env42650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42649 == env42650) = true)

theorem identity42650 : scanCanonicalize (H12AffineFastState.compose env42650 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42650 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138341,1024,8541,4161,156012,17,73737,8192,65,146508,5392,17664,32041,1365,144492,256,21792,5457,74250]

theorem envBound42651 : H12AffineFastState.Bounded env42651 := by
  intro p hp
  have h : env42651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42650_42651 : H12AffineEnvironment.transform 14 8540 env42650 = env42651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42650 == env42651) = true)

theorem identity42651 : scanCanonicalize (H12AffineFastState.compose env42651 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound42651 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,82198,89459,1024,8541,4161,73850,17,73737,8192,65,97626,5392,17664,32041,1365,95610,256,21792,5457,74250]

theorem envBound42652 : H12AffineFastState.Bounded env42652 := by
  intro p hp
  have h : env42652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42651_42652 : H12AffineEnvironment.transform 16 82198 env42651 = env42652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env42651 == env42652) = true)

theorem identity42652 : scanCanonicalize (H12AffineFastState.compose env42652 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound42652 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env42653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30042,13388,10281,1024,8541,4161,21792,17,21843,8192,65,2048,5392,17664,32041,1365,32,256,21792,5457,22352]

theorem envBound42653 : H12AffineFastState.Bounded env42653 := by
  intro p hp
  have h : env42653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42652_42653 : H12AffineEnvironment.transform 15 30042 env42652 = env42653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env42652 == env42653) = true)

theorem identity42653 : scanCanonicalize (H12AffineFastState.compose env42653 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound42653 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env42654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,8540,9499,13388,10281,1024,8541,4161,1377,17,1298,8192,65,2048,5392,5441,11624,1365,32,256,1377,5457,1809]

theorem envBound42654 : H12AffineFastState.Bounded env42654 := by
  intro p hp
  have h : env42654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42653_42654 : H12AffineEnvironment.transform 13 4161 env42653 = env42654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env42653 == env42654) = true)

theorem identity42654 : scanCanonicalize (H12AffineFastState.compose env42654 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42654 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env42655 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4161,8232,9327,13388,10281,1024,8233,4161,1045,17,1126,8192,65,2048,5220,5173,11292,1057,32,116,1045,5157,1637]

theorem envBound42655 : H12AffineFastState.Bounded env42655 := by
  intro p hp
  have h : env42655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42654_42655 : H12AffineEnvironment.transform 7 116 env42654 = env42655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42654 == env42655) = true)

theorem identity42655 : scanCanonicalize (H12AffineFastState.compose env42655 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound42655 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env42656 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,4161,80,1047,5172,2129,1024,81,4161,1045,17,1126,120,65,2048,5220,5173,3172,1057,32,116,1045,5157,1637]

theorem envBound42656 : H12AffineFastState.Bounded env42656 := by
  intro p hp
  have h : env42656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42655_42656 : H12AffineEnvironment.transform 12 120 env42655 = env42656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env42655 == env42656) = true)

theorem identity42656 : scanCanonicalize (H12AffineFastState.compose env42656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound42656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42657 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,120,4161,80,114,4177,2129,101,81,4161,112,17,3,120,65,2048,4097,4176,2049,68,32,116,112,4160,512]

theorem envBound42657 : H12AffineFastState.Bounded env42657 := by
  intro p hp
  have h : env42657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42656_42657 : H12AffineEnvironment.transform 9 101 env42656 = env42657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env42656 == env42657) = true)

theorem identity42657 : scanCanonicalize (H12AffineFastState.compose env42657 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42658 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,4096,88,4161,80,82,4177,2129,69,81,4161,80,17,3,88,65,2048,4097,4176,2049,68,0,84,80,4160,512]

theorem envBound42658 : H12AffineFastState.Bounded env42658 := by
  intro p hp
  have h : env42658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42657_42658 : H12AffineEnvironment.transform 4 0 env42657 = env42658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42657 == env42658) = true)

def env42659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,17,98644,8193,65,171281,5392,17664,32041,1364,169264,256,21792,46092,74250]

theorem envBound42659 : H12AffineFastState.Bounded env42659 := by
  intro p hp
  have h : env42659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42649_42659 : H12AffineEnvironment.transform 6 9 env42649 = env42659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42649 == env42659) = true)

theorem identity42659 : scanCanonicalize (H12AffineFastState.compose env42659 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound42659 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,179513,1024,32769,4161,156012,17,62559,8193,65,171281,5392,17664,32041,1364,169264,256,21792,46092,22273]

theorem envBound42660 : H12AffineFastState.Bounded env42660 := by
  intro p hp
  have h : env42660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42659_42660 : H12AffineEnvironment.transform 15 29963 env42659 = env42660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env42659 == env42660) = true)

theorem identity42660 : scanCanonicalize (H12AffineFastState.compose env42660 (packedSelected [1,16,19,20,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42660 : packedSelected [1,16,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env42661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21590,131072,171108,1024,32769,4161,147505,17,54530,348,65,171281,5392,17664,23668,1364,169264,256,21792,38225,22273]

theorem envBound42661 : H12AffineFastState.Bounded env42661 := by
  intro p hp
  have h : env42661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42660_42661 : H12AffineEnvironment.transform 12 349 env42660 = env42661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42660 == env42661) = true)

theorem identity42661 : scanCanonicalize (H12AffineFastState.compose env42661 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42661 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env42662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21590,131072,149860,1024,21761,4161,147505,17,2,348,65,149521,5392,17664,23668,1364,147504,256,21792,16465,22273]

theorem envBound42662 : H12AffineFastState.Bounded env42662 := by
  intro p hp
  have h : env42662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42661_42662 : H12AffineEnvironment.transform 14 21760 env42661 = env42662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42661 == env42662) = true)

theorem identity42662 : scanCanonicalize (H12AffineFastState.compose env42662 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound42662 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env42663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,263,131072,138293,1024,80,4161,136544,17,2,348,65,138560,5392,4177,2341,1364,136545,256,113,5376,592]

theorem envBound42663 : H12AffineFastState.Bounded env42663 := by
  intro p hp
  have h : env42663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42662_42663 : H12AffineEnvironment.transform 13 5457 env42662 = env42663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env42662 == env42663) = true)

theorem identity42663 : scanCanonicalize (H12AffineFastState.compose env42663 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42663 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42664 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,131072,138293,1024,1,4112,136497,17,2,269,16,138513,5392,4096,2341,1285,136496,256,32,5376,513]

theorem envBound42664 : H12AffineFastState.Bounded env42664 := by
  intro p hp
  have h : env42664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42663_42664 : H12AffineEnvironment.transform 5 17 env42663 = env42664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42663 == env42664) = true)

theorem identity42664 : scanCanonicalize (H12AffineFastState.compose env42664 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound42664 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42665 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4112,33,17,2,269,16,2049,5392,4096,2341,1285,32,256,32,5376,513]

theorem envBound42665 : H12AffineFastState.Bounded env42665 := by
  intro p hp
  have h : env42665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42664_42665 : H12AffineEnvironment.transform 16 5392 env42664 = env42665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env42664 == env42665) = true)

theorem identity42665 : scanCanonicalize (H12AffineFastState.compose env42665 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound42665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42666 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,56,5172,0,51,5156,2065,1024,1,4112,33,17,2,57,16,2049,5156,4096,2065,1073,32,52,32,5172,513]

theorem envBound42666 : H12AffineFastState.Bounded env42666 := by
  intro p hp
  have h : env42666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42665_42666 : H12AffineEnvironment.transform 7 52 env42665 = env42666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env42665 == env42666) = true)

theorem identity42666 : scanCanonicalize (H12AffineFastState.compose env42666 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound42666 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42667 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,1588,56,512,0,51,528,2065,1024,1,1572,33,17,2,57,16,2049,528,1588,2065,1073,32,52,32,512,513]

theorem envBound42667 : H12AffineFastState.Bounded env42667 := by
  intro p hp
  have h : env42667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42666_42667 : H12AffineEnvironment.transform 11 1588 env42666 = env42667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env42666 == env42667) = true)

theorem identity42667 : scanCanonicalize (H12AffineFastState.compose env42667 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42667 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42668 : List Nat := [2,4,8,1,32,0,9,37,512,1024,2048,1573,41,512,0,34,513,2048,1024,1,1572,33,0,2,40,1,2049,513,1573,2048,1056,32,37,32,512,513]

theorem envBound42668 : H12AffineFastState.Bounded env42668 := by
  intro p hp
  have h : env42668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42667_42668 : H12AffineEnvironment.transform 3 1 env42667 = env42668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42667 == env42668) = true)

theorem identity42668 : scanCanonicalize (H12AffineFastState.compose env42668 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound42668 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42669 : List Nat := [2,4,8,1,32,0,9,37,512,1024,513,1573,41,512,0,34,513,513,1024,1,1572,33,0,2,40,1,512,513,1573,513,1056,32,37,32,512,513]

theorem envBound42669 : H12AffineFastState.Bounded env42669 := by
  intro p hp
  have h : env42669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42668_42669 : H12AffineEnvironment.transform 10 513 env42668 = env42669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env42668 == env42669) = true)

def env42670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534761,474341,8328,65,6705549,2537577,456761,2125160,2102685,6707493,256,21793,46212,2175562]

theorem envBound42670 : H12AffineFastState.Bounded env42670 := by
  intro p hp
  have h : env42670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42577_42670 : H12AffineEnvironment.transform 23 474341 env42577 = env42670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474341 env42577 == env42670) = true)

def env42671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101329,98781,8328,65,6352053,2098513,17665,2125160,2102685,6349853,256,21793,46212,2175562]

theorem envBound42671 : H12AffineFastState.Bounded env42671 := by
  intro p hp
  have h : env42671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42670_42671 : H12AffineEnvironment.transform 17 179512 env42670 = env42671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env42670 == env42671) = true)

def env42672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,17,98781,8328,65,4259061,5393,17665,32040,1501,4256861,256,21793,46212,74250]

theorem envBound42672 : H12AffineFastState.Bounded env42672 := by
  intro p hp
  have h : env42672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42671_42672 : H12AffineEnvironment.transform 20 4160 env42671 = env42672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42671 == env42672) = true)

theorem identity42672 : scanCanonicalize (H12AffineFastState.compose env42672 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound42672 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,213351,17,98781,8328,65,245138,5393,17665,32040,1501,243002,256,21793,46212,74250]

theorem envBound42673 : H12AffineFastState.Bounded env42673 := by
  intro p hp
  have h : env42673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42672_42673 : H12AffineEnvironment.transform 21 213351 env42672 = env42673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env42672 == env42673) = true)

def env42674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,213351,17,98645,8192,65,245018,5393,17665,32040,1365,243002,256,21793,46092,74250]

theorem envBound42674 : H12AffineFastState.Bounded env42674 := by
  intro p hp
  have h : env42674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42673_42674 : H12AffineEnvironment.transform 6 8 env42673 = env42674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42673 == env42674) = true)

theorem identity42674 : scanCanonicalize (H12AffineFastState.compose env42674 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138340,1024,8541,4160,213351,17,73737,8192,65,203846,5393,17665,32040,1365,201830,256,21793,5456,74250]

theorem envBound42675 : H12AffineFastState.Bounded env42675 := by
  intro p hp
  have h : env42675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42674_42675 : H12AffineEnvironment.transform 14 8540 env42674 = env42675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42674 == env42675) = true)

theorem identity42675 : scanCanonicalize (H12AffineFastState.compose env42675 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42675 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,81,65536,131072,138340,1024,80,4160,213351,17,65796,269,65,203846,5393,17665,23589,1365,201830,256,21793,5456,66311]

theorem envBound42676 : H12AffineFastState.Bounded env42676 := by
  intro p hp
  have h : env42676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42675_42676 : H12AffineEnvironment.transform 12 269 env42675 = env42676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42675 == env42676) = true)

theorem identity42676 : scanCanonicalize (H12AffineFastState.compose env42676 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42676 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,81,65536,131072,138340,1024,80,4160,201783,17,65796,269,65,203846,5393,4177,2421,1365,201830,256,113,5456,66311]

theorem envBound42677 : H12AffineFastState.Bounded env42677 := by
  intro p hp
  have h : env42677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42676_42677 : H12AffineEnvironment.transform 13 5456 env42676 = env42677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42676 == env42677) = true)

theorem identity42677 : scanCanonicalize (H12AffineFastState.compose env42677 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound42677 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env42678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,81,35,131072,138340,1024,80,4160,136212,17,295,269,65,138341,5393,4177,2421,1365,136261,256,113,5456,804]

theorem envBound42678 : H12AffineFastState.Bounded env42678 := by
  intro p hp
  have h : env42678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42677_42678 : H12AffineEnvironment.transform 15 35 env42677 = env42678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env42677 == env42678) = true)

theorem identity42678 : scanCanonicalize (H12AffineFastState.compose env42678 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound42678 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,81,35,5440,2340,1024,80,4160,340,17,295,269,65,2341,5393,4177,2421,1365,261,256,113,5456,804]

theorem envBound42679 : H12AffineFastState.Bounded env42679 := by
  intro p hp
  have h : env42679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42678_42679 : H12AffineEnvironment.transform 16 5440 env42678 = env42679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env42678 == env42679) = true)

theorem identity42679 : scanCanonicalize (H12AffineFastState.compose env42679 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42679 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42680 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,5157,81,35,5173,2129,1024,80,4160,33,17,82,120,65,2128,5220,4177,2048,1056,112,117,113,5157,593]

theorem envBound42680 : H12AffineFastState.Bounded env42680 := by
  intro p hp
  have h : env42680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42679_42680 : H12AffineEnvironment.transform 7 117 env42679 = env42680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42679 == env42680) = true)

theorem identity42680 : scanCanonicalize (H12AffineFastState.compose env42680 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound42680 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42681 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3188,120,2129,81,35,2113,2129,1024,80,3124,33,17,82,120,65,2128,2064,3109,2048,1056,112,117,113,2129,593]

theorem envBound42681 : H12AffineFastState.Bounded env42681 := by
  intro p hp
  have h : env42681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42680_42681 : H12AffineEnvironment.transform 11 3188 env42680 = env42681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env42680 == env42681) = true)

theorem identity42681 : scanCanonicalize (H12AffineFastState.compose env42681 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42681 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env42682 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,40,2049,1,35,2065,2049,1024,0,3124,33,17,2,40,17,2048,2064,3109,2048,1056,32,37,33,2049,513]

theorem envBound42682 : H12AffineFastState.Bounded env42682 := by
  intro p hp
  have h : env42682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42681_42682 : H12AffineEnvironment.transform 5 16 env42681 = env42682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42681 == env42682) = true)

theorem identity42682 : scanCanonicalize (H12AffineFastState.compose env42682 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42683 : List Nat := [2,4,8,16,32,16,8,37,512,5,2048,2081,40,2049,1,35,2065,2049,5,0,2097,33,17,2,40,17,2048,2064,2080,2048,37,32,37,33,2049,513]

theorem envBound42683 : H12AffineFastState.Bounded env42683 := by
  intro p hp
  have h : env42683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42682_42683 : H12AffineEnvironment.transform 9 5 env42682 = env42683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42682 == env42683) = true)

theorem identity42683 : scanCanonicalize (H12AffineFastState.compose env42683 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound42683 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42684 : List Nat := [2,4,8,16,32,16,8,37,512,5,513,544,40,512,1,35,528,512,5,0,560,33,17,2,40,17,513,529,545,513,37,32,37,33,512,513]

theorem envBound42684 : H12AffineFastState.Bounded env42684 := by
  intro p hp
  have h : env42684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42683_42684 : H12AffineEnvironment.transform 10 513 env42683 = env42684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env42683 == env42684) = true)

theorem identity42684 : scanCanonicalize (H12AffineFastState.compose env42684 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42684 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42685 : List Nat := [2,4,8,16,0,16,8,5,512,5,513,512,8,512,1,3,528,512,5,0,528,1,17,2,8,17,513,529,513,513,5,0,5,1,512,513]

theorem envBound42685 : H12AffineFastState.Bounded env42685 := by
  intro p hp
  have h : env42685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42684_42685 : H12AffineEnvironment.transform 4 0 env42684 = env42685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42684 == env42685) = true)

theorem identity42685 : scanCanonicalize (H12AffineFastState.compose env42685 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42685 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42686 : List Nat := [2,4,8,0,0,0,8,5,512,5,513,512,8,512,1,3,512,512,5,0,512,1,1,2,8,1,513,513,513,513,5,0,5,1,512,513]

theorem envBound42686 : H12AffineFastState.Bounded env42686 := by
  intro p hp
  have h : env42686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42685_42686 : H12AffineEnvironment.transform 3 0 env42685 = env42686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42685 == env42686) = true)

theorem identity42686 : scanCanonicalize (H12AffineFastState.compose env42686 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42687 : List Nat := [2,4,8,0,0,0,8,5,1,5,0,1,8,1,1,3,1,1,5,0,1,1,1,2,8,1,0,0,0,0,5,0,5,1,1,0]

theorem envBound42687 : H12AffineFastState.Bounded env42687 := by
  intro p hp
  have h : env42687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42686_42687 : H12AffineEnvironment.transform 8 1 env42686 = env42687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42686 == env42687) = true)

theorem identity42687 : scanCanonicalize (H12AffineFastState.compose env42687 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42688 : List Nat := [2,4,3,0,0,0,3,5,1,5,0,1,3,1,1,3,1,1,5,0,1,1,1,2,3,1,0,0,0,0,5,0,5,1,1,0]

theorem envBound42688 : H12AffineFastState.Bounded env42688 := by
  intro p hp
  have h : env42688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42687_42688 : H12AffineEnvironment.transform 2 3 env42687 = env42688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42687 == env42688) = true)

def env42689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,213351,17,98644,8193,65,245019,5393,17665,32040,1364,243002,256,21793,46093,74250]

theorem envBound42689 : H12AffineFastState.Bounded env42689 := by
  intro p hp
  have h : env42689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42673_42689 : H12AffineEnvironment.transform 6 9 env42673 = env42689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42673 == env42689) = true)

theorem identity42689 : scanCanonicalize (H12AffineFastState.compose env42689 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42689 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env42690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179512,1024,32769,4160,201830,17,98644,8193,65,245019,5393,4096,10281,1364,243002,256,32,46093,74250]

theorem envBound42690 : H12AffineFastState.Bounded env42690 := by
  intro p hp
  have h : env42690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42689_42690 : H12AffineEnvironment.transform 13 5377 env42689 = env42690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42689 == env42690) = true)

theorem identity42690 : scanCanonicalize (H12AffineFastState.compose env42690 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42690 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,65536,131072,171109,1024,32769,4160,201830,17,98644,348,65,236614,5393,4096,2420,1364,234599,256,32,38224,66391]

theorem envBound42691 : H12AffineFastState.Bounded env42691 := by
  intro p hp
  have h : env42691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42690_42691 : H12AffineEnvironment.transform 12 349 env42690 = env42691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42690 == env42691) = true)

theorem identity42691 : scanCanonicalize (H12AffineFastState.compose env42691 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42691 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env42692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,131072,138341,1024,1,4160,201830,17,65876,348,65,203846,5393,4096,2420,1364,201831,256,32,5456,66391]

theorem envBound42692 : H12AffineFastState.Bounded env42692 := by
  intro p hp
  have h : env42692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42691_42692 : H12AffineEnvironment.transform 14 0 env42691 = env42692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42691 == env42692) = true)

theorem identity42692 : scanCanonicalize (H12AffineFastState.compose env42692 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound42692 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env42693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,70726,67619,1024,1,4160,32,17,65876,348,65,2048,5393,4096,2420,1364,33,256,32,5456,66391]

theorem envBound42693 : H12AffineFastState.Bounded env42693 := by
  intro p hp
  have h : env42693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42692_42693 : H12AffineEnvironment.transform 16 70726 env42692 = env42693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env42692 == env42693) = true)

def env42694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98781,8328,65,4259060,5392,17665,32041,1500,4256860,256,21793,46212,74251]

theorem envBound42694 : H12AffineFastState.Bounded env42694 := by
  intro p hp
  have h : env42694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42671_42694 : H12AffineEnvironment.transform 20 4161 env42671 = env42694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42671 == env42694) = true)

theorem identity42694 : scanCanonicalize (H12AffineFastState.compose env42694 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound42694 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179512,1024,32769,4161,4194304,16,21763,8328,65,4259060,5392,17665,32041,1500,4256860,256,21793,46212,63189]

theorem envBound42695 : H12AffineFastState.Bounded env42695 := by
  intro p hp
  have h : env42695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42694_42695 : H12AffineEnvironment.transform 15 54494 env42694 = env42695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env42694 == env42695) = true)

def env42696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,4194304,16,21763,8192,65,4258940,5392,17665,32041,1364,4256860,256,21793,46092,63069]

theorem envBound42696 : H12AffineFastState.Bounded env42696 := by
  intro p hp
  have h : env42696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42695_42696 : H12AffineEnvironment.transform 6 8 env42695 = env42696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42695 == env42696) = true)

theorem identity42696 : scanCanonicalize (H12AffineFastState.compose env42696 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound42696 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35189,1024,32769,4161,4194304,16,21763,8192,65,4258940,5392,17665,32041,1364,4256860,256,21793,46092,63069]

theorem envBound42697 : H12AffineFastState.Bounded env42697 := by
  intro p hp
  have h : env42697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42696_42697 : H12AffineEnvironment.transform 16 13389 env42696 = env42697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env42696 == env42697) = true)

theorem identity42697 : scanCanonicalize (H12AffineFastState.compose env42697 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound42697 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35189,1024,32769,4161,62588,16,21763,8192,65,2048,5392,17665,32041,1364,32,256,21793,46092,63069]

theorem envBound42698 : H12AffineFastState.Bounded env42698 := by
  intro p hp
  have h : env42698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42697_42698 : H12AffineEnvironment.transform 21 62588 env42697 = env42698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env42697 == env42698) = true)

theorem identity42698 : scanCanonicalize (H12AffineFastState.compose env42698 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42698 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54358,5392,35189,1024,32769,4161,54561,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,38225,55040]

theorem envBound42699 : H12AffineFastState.Bounded env42699 := by
  intro p hp
  have h : env42699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42698_42699 : H12AffineEnvironment.transform 12 349 env42698 = env42699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42698 == env42699) = true)

theorem identity42699 : scanCanonicalize (H12AffineFastState.compose env42699 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42699 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21590,5392,2421,1024,1,4161,21793,16,21763,349,65,2048,5392,17665,23668,1364,32,256,21793,5457,22272]

theorem envBound42700 : H12AffineFastState.Bounded env42700 := by
  intro p hp
  have h : env42700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42699_42700 : H12AffineEnvironment.transform 14 0 env42699 = env42700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42699 == env42700) = true)

theorem identity42700 : scanCanonicalize (H12AffineFastState.compose env42700 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42700 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5392,2421,1024,1,4161,32,16,2,349,65,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound42701 : H12AffineFastState.Bounded env42701 := by
  intro p hp
  have h : env42701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42700_42701 : H12AffineEnvironment.transform 13 5377 env42700 = env42701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42700 == env42701) = true)

theorem identity42701 : scanCanonicalize (H12AffineFastState.compose env42701 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound42701 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42702 : List Nat := [2,4,8,16,32,64,8,256,512,613,2048,4096,349,4964,0,343,4981,2421,613,1,4161,32,16,2,349,65,2048,4981,4096,2421,817,32,256,32,4916,513]

theorem envBound42702 : H12AffineFastState.Bounded env42702 := by
  intro p hp
  have h : env42702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42701_42702 : H12AffineEnvironment.transform 9 613 env42701 = env42702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env42701 == env42702) = true)

theorem identity42702 : scanCanonicalize (H12AffineFastState.compose env42702 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42702 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42703 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,4096,268,4917,0,262,4900,2340,564,1,4112,32,16,2,268,16,2048,4900,4096,2340,817,32,256,32,4916,513]

theorem envBound42703 : H12AffineFastState.Bounded env42703 := by
  intro p hp
  have h : env42703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42702_42703 : H12AffineEnvironment.transform 5 17 env42702 = env42703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42702 == env42703) = true)

theorem identity42703 : scanCanonicalize (H12AffineFastState.compose env42703 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound42703 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42704 : List Nat := [2,4,8,16,32,17,8,256,512,564,2048,0,268,821,0,262,804,2340,564,1,16,32,16,2,268,16,2048,804,0,2340,817,32,256,32,820,513]

theorem envBound42704 : H12AffineFastState.Bounded env42704 := by
  intro p hp
  have h : env42704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42703_42704 : H12AffineEnvironment.transform 11 0 env42703 = env42704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42703 == env42704) = true)

theorem identity42704 : scanCanonicalize (H12AffineFastState.compose env42704 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound42704 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42705 : List Nat := [2,4,8,16,32,17,8,52,512,564,2048,0,56,513,0,50,528,2064,564,1,16,32,16,2,56,16,2048,528,0,2064,517,32,52,32,512,513]

theorem envBound42705 : H12AffineFastState.Bounded env42705 := by
  intro p hp
  have h : env42705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42704_42705 : H12AffineEnvironment.transform 7 52 env42704 = env42705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env42704 == env42705) = true)

theorem identity42705 : scanCanonicalize (H12AffineFastState.compose env42705 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound42705 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42706 : List Nat := [2,4,8,16,32,17,8,52,512,564,529,0,56,513,0,50,528,513,564,1,16,32,16,2,56,16,529,528,0,513,517,32,52,32,512,513]

theorem envBound42706 : H12AffineFastState.Bounded env42706 := by
  intro p hp
  have h : env42706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42705_42706 : H12AffineEnvironment.transform 10 529 env42705 = env42706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env42705 == env42706) = true)

theorem identity42706 : scanCanonicalize (H12AffineFastState.compose env42706 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42707 : List Nat := [2,4,8,0,32,1,8,36,512,548,513,0,40,513,0,34,512,513,548,1,0,32,0,2,40,0,513,512,0,513,517,32,36,32,512,513]

theorem envBound42707 : H12AffineFastState.Bounded env42707 := by
  intro p hp
  have h : env42707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42706_42707 : H12AffineEnvironment.transform 3 0 env42706 = env42707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42706 == env42707) = true)

def env42708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4161,4194304,16,21763,8193,65,4258941,5392,17665,32041,1365,4256860,256,21793,46093,63068]

theorem envBound42708 : H12AffineFastState.Bounded env42708 := by
  intro p hp
  have h : env42708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42695_42708 : H12AffineEnvironment.transform 6 9 env42695 = env42708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42695 == env42708) = true)

theorem identity42708 : scanCanonicalize (H12AffineFastState.compose env42708 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound42708 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10280,1024,32769,4161,4194304,16,21763,8193,65,4258941,5392,17665,32041,1365,4256860,256,21793,46093,63068]

theorem envBound42709 : H12AffineFastState.Bounded env42709 := by
  intro p hp
  have h : env42709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42708_42709 : H12AffineEnvironment.transform 16 38160 env42708 = env42709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42708 == env42709) = true)

theorem identity42709 : scanCanonicalize (H12AffineFastState.compose env42709 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound42709 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env42710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10280,1024,32769,4161,29741,16,21763,8193,65,34896,5392,17665,32041,1365,32881,256,21793,46093,63068]

theorem envBound42710 : H12AffineFastState.Bounded env42710 := by
  intro p hp
  have h : env42710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42709_42710 : H12AffineEnvironment.transform 21 29741 env42709 = env42710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env42709 == env42710) = true)

theorem identity42710 : scanCanonicalize (H12AffineFastState.compose env42710 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42710 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,5393,10280,1024,0,4161,29741,16,21763,8193,65,2129,5392,17665,32041,1365,112,256,21793,13324,30301]

theorem envBound42711 : H12AffineFastState.Bounded env42711 := by
  intro p hp
  have h : env42711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42710_42711 : H12AffineEnvironment.transform 14 1 env42710 = env42711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42710 == env42711) = true)

theorem identity42711 : scanCanonicalize (H12AffineFastState.compose env42711 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42711 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,342,5393,10280,1024,0,4161,8493,16,3,8193,65,2129,5392,4097,10281,1365,112,256,33,13324,9053]

theorem envBound42712 : H12AffineFastState.Bounded env42712 := by
  intro p hp
  have h : env42712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42711_42712 : H12AffineEnvironment.transform 13 5376 env42711 = env42712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42711 == env42712) = true)

theorem identity42712 : scanCanonicalize (H12AffineFastState.compose env42712 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42712 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env42713 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,5393,10280,1024,0,4112,8493,16,3,8193,16,2048,5392,4097,10281,1284,33,256,33,13324,8972]

theorem envBound42713 : H12AffineFastState.Bounded env42713 := by
  intro p hp
  have h : env42713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42712_42713 : H12AffineEnvironment.transform 5 17 env42712 = env42713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42712 == env42713) = true)

theorem identity42713 : scanCanonicalize (H12AffineFastState.compose env42713 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42713 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42714 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,1,3,5141,10280,1024,0,4112,8233,16,3,8193,16,2048,5140,4097,10281,1024,33,4,33,13324,8712]

theorem envBound42714 : H12AffineFastState.Bounded env42714 := by
  intro p hp
  have h : env42714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42713_42714 : H12AffineEnvironment.transform 7 4 env42713 = env42714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42713 == env42714) = true)

theorem identity42714 : scanCanonicalize (H12AffineFastState.compose env42714 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 5692) := by decide +kernel

theorem selectedBound42714 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env42715 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,5692,5124,1,3,5141,7700,1024,0,4112,5653,16,3,5693,16,2048,5140,4097,7701,1024,33,4,33,560,5172]

theorem envBound42715 : H12AffineFastState.Bounded env42715 := by
  intro p hp
  have h : env42715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42714_42715 : H12AffineEnvironment.transform 12 5692 env42714 = env42715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5692 env42714 == env42715) = true)

theorem identity42715 : scanCanonicalize (H12AffineFastState.compose env42715 (packedSelected [1,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound42715 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env42716 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1029,4096,5692,5124,1,3,5141,4625,1024,0,4112,5653,16,3,5693,16,1029,5140,4097,4624,1024,33,4,33,560,5172]

theorem envBound42716 : H12AffineFastState.Bounded env42716 := by
  intro p hp
  have h : env42716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42715_42716 : H12AffineEnvironment.transform 10 1029 env42715 = env42716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env42715 == env42716) = true)

theorem identity42716 : scanCanonicalize (H12AffineFastState.compose env42716 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound42716 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42717 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1029,17,1581,1045,1,3,1028,512,1024,0,1,1540,16,3,1580,16,1029,1029,16,513,1024,33,4,33,560,1061]

theorem envBound42717 : H12AffineFastState.Bounded env42717 := by
  intro p hp
  have h : env42717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42716_42717 : H12AffineEnvironment.transform 11 17 env42716 = env42717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42716 == env42717) = true)

theorem identity42717 : scanCanonicalize (H12AffineFastState.compose env42717 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42718 : List Nat := [2,4,8,16,32,17,9,4,0,1024,1029,17,1069,1045,1,3,1028,0,1024,0,1,1028,16,3,1068,16,1029,1029,16,1,1024,33,4,33,48,1061]

theorem envBound42718 : H12AffineFastState.Bounded env42718 := by
  intro p hp
  have h : env42718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42717_42718 : H12AffineEnvironment.transform 8 0 env42717 = env42718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42717 == env42718) = true)

theorem identity42718 : scanCanonicalize (H12AffineFastState.compose env42718 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42718 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42719 : List Nat := [2,4,8,0,32,1,9,4,0,1024,1029,1,1069,1029,1,3,1028,0,1024,0,1,1028,0,3,1068,0,1029,1029,0,1,1024,33,4,33,32,1061]

theorem envBound42719 : H12AffineFastState.Bounded env42719 := by
  intro p hp
  have h : env42719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42718_42719 : H12AffineEnvironment.transform 3 0 env42718 = env42719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42718 == env42719) = true)

theorem identity42719 : scanCanonicalize (H12AffineFastState.compose env42719 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42719 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42720 : List Nat := [2,4,8,0,32,1,9,4,0,5,0,1,40,0,1,3,1,0,5,0,1,1,0,3,41,0,0,0,0,1,5,33,4,33,32,32]

theorem envBound42720 : H12AffineFastState.Bounded env42720 := by
  intro p hp
  have h : env42720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42719_42720 : H12AffineEnvironment.transform 9 5 env42719 = env42720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42719 == env42720) = true)

theorem identity42720 : scanCanonicalize (H12AffineFastState.compose env42720 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42720 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env42721 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,8,0,1,3,1,0,5,0,1,1,0,3,9,0,0,0,0,1,5,1,4,1,0,0]

theorem envBound42721 : H12AffineFastState.Bounded env42721 := by
  intro p hp
  have h : env42721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42720_42721 : H12AffineEnvironment.transform 4 0 env42720 = env42721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42720 == env42721) = true)

theorem identity42721 : scanCanonicalize (H12AffineFastState.compose env42721 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42722 : List Nat := [2,1,8,0,0,1,9,1,0,0,0,1,8,0,1,3,1,0,0,0,1,1,0,3,9,0,0,0,0,1,0,1,1,1,0,0]

theorem envBound42722 : H12AffineFastState.Bounded env42722 := by
  intro p hp
  have h : env42722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42721_42722 : H12AffineEnvironment.transform 1 1 env42721 = env42722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42721 == env42722) = true)

def env42723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101328,98780,8328,65,6352052,2098512,17664,2125160,2102685,6349852,256,21793,46212,2175562]

theorem envBound42723 : H12AffineFastState.Bounded env42723 := by
  intro p hp
  have h : env42723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42670_42723 : H12AffineEnvironment.transform 17 179513 env42670 = env42723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env42670 == env42723) = true)

def env42724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98780,8328,65,4259060,5392,17664,32040,1501,4256860,256,21793,46212,74250]

theorem envBound42724 : H12AffineFastState.Bounded env42724 := by
  intro p hp
  have h : env42724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42723_42724 : H12AffineEnvironment.transform 20 4160 env42723 = env42724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42723 == env42724) = true)

theorem identity42724 : scanCanonicalize (H12AffineFastState.compose env42724 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42724 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,4194304,16,41431,8328,65,4259060,5392,17664,32040,1501,4256860,256,21793,46212,513]

theorem envBound42725 : H12AffineFastState.Bounded env42725 := by
  intro p hp
  have h : env42725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42724_42725 : H12AffineEnvironment.transform 15 8203 env42724 = env42725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42724 == env42725) = true)

theorem identity42725 : scanCanonicalize (H12AffineFastState.compose env42725 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound42725 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,169401,16,41431,8328,65,158029,5392,17664,32040,1501,156133,256,21793,46212,513]

theorem envBound42726 : H12AffineFastState.Bounded env42726 := by
  intro p hp
  have h : env42726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42725_42726 : H12AffineEnvironment.transform 21 169401 env42725 = env42726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env42725 == env42726) = true)

theorem identity42726 : scanCanonicalize (H12AffineFastState.compose env42726 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42726 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env42727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,169264,16,41310,8193,65,158029,5392,17664,32040,1364,156012,256,21793,46093,513]

theorem envBound42727 : H12AffineFastState.Bounded env42727 := by
  intro p hp
  have h : env42727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42726_42727 : H12AffineEnvironment.transform 6 9 env42726 = env42727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42726 == env42727) = true)

theorem identity42727 : scanCanonicalize (H12AffineFastState.compose env42727 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound42727 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10280,1024,32769,4160,33,16,41310,8193,65,64604,5392,17664,32040,1364,62589,256,21793,46093,513]

theorem envBound42728 : H12AffineFastState.Bounded env42728 := by
  intro p hp
  have h : env42728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42727_42728 : H12AffineEnvironment.transform 16 38161 env42727 = env42728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42727 == env42728) = true)

theorem identity42728 : scanCanonicalize (H12AffineFastState.compose env42728 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42728 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,5392,10280,1024,0,4160,33,16,8543,8193,65,31837,5392,17664,32040,1364,29820,256,21793,13324,513]

theorem envBound42729 : H12AffineFastState.Bounded env42729 := by
  intro p hp
  have h : env42729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42728_42729 : H12AffineEnvironment.transform 14 1 env42728 = env42729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42728 == env42729) = true)

theorem identity42729 : scanCanonicalize (H12AffineFastState.compose env42729 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42729 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,343,5392,2420,1024,0,4160,33,16,3,349,65,23809,5392,17664,23668,1364,21792,256,21793,5456,513]

theorem envBound42730 : H12AffineFastState.Bounded env42730 := by
  intro p hp
  have h : env42730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42729_42730 : H12AffineEnvironment.transform 12 348 env42729 = env42730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42729 == env42730) = true)

theorem identity42730 : scanCanonicalize (H12AffineFastState.compose env42730 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound42730 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5408,1,343,5392,2420,1024,0,4160,33,16,3,349,65,2081,5392,4128,2388,1364,0,256,1,5456,513]

theorem envBound42731 : H12AffineFastState.Bounded env42731 := by
  intro p hp
  have h : env42731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42730_42731 : H12AffineEnvironment.transform 13 5408 env42730 = env42731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env42730 == env42731) = true)

theorem identity42731 : scanCanonicalize (H12AffineFastState.compose env42731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42732 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,348,5376,1,343,5392,2388,1024,0,4160,1,16,3,349,65,2049,5392,4096,2388,1364,0,256,1,5456,513]

theorem envBound42732 : H12AffineFastState.Bounded env42732 := by
  intro p hp
  have h : env42732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42731_42732 : H12AffineEnvironment.transform 4 0 env42731 = env42732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42731 == env42732) = true)

theorem identity42732 : scanCanonicalize (H12AffineFastState.compose env42732 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound42732 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42733 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1028,348,260,1,343,276,2388,1024,0,1092,1,16,3,349,65,2049,276,1028,2388,1364,0,256,1,340,513]

theorem envBound42733 : H12AffineFastState.Bounded env42733 := by
  intro p hp
  have h : env42733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42732_42733 : H12AffineEnvironment.transform 11 1028 env42732 = env42733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env42732 == env42733) = true)

theorem identity42733 : scanCanonicalize (H12AffineFastState.compose env42733 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42733 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42734 : List Nat := [2,4,8,16,0,64,9,256,512,1024,0,1028,348,260,1,343,276,340,1024,0,1092,1,16,3,349,65,1,276,1028,340,1364,0,256,1,340,513]

theorem envBound42734 : H12AffineFastState.Bounded env42734 := by
  intro p hp
  have h : env42734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42733_42734 : H12AffineEnvironment.transform 10 0 env42733 = env42734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42733 == env42734) = true)

theorem identity42734 : scanCanonicalize (H12AffineFastState.compose env42734 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound42734 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42735 : List Nat := [2,4,8,16,0,64,9,256,512,257,0,261,348,260,1,343,276,340,257,0,325,1,16,3,349,65,1,276,261,340,85,0,256,1,340,513]

theorem envBound42735 : H12AffineFastState.Bounded env42735 := by
  intro p hp
  have h : env42735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42734_42735 : H12AffineEnvironment.transform 9 257 env42734 = env42735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env42734 == env42735) = true)

theorem identity42735 : scanCanonicalize (H12AffineFastState.compose env42735 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound42735 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env42736 : List Nat := [2,4,8,16,0,64,9,256,341,257,0,261,348,260,1,343,276,340,257,0,325,1,16,3,349,65,1,276,261,340,85,0,256,1,340,340]

theorem envBound42736 : H12AffineFastState.Bounded env42736 := by
  intro p hp
  have h : env42736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42735_42736 : H12AffineEnvironment.transform 8 341 env42735 = env42736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env42735 == env42736) = true)

theorem identity42736 : scanCanonicalize (H12AffineFastState.compose env42736 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42736 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env42737 : List Nat := [2,4,8,0,0,64,9,256,325,257,0,261,332,260,1,327,260,324,257,0,325,1,0,3,333,65,1,260,261,324,69,0,256,1,324,324]

theorem envBound42737 : H12AffineFastState.Bounded env42737 := by
  intro p hp
  have h : env42737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42736_42737 : H12AffineEnvironment.transform 3 0 env42736 = env42737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42736 == env42737) = true)

theorem identity42737 : scanCanonicalize (H12AffineFastState.compose env42737 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound42737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42738 : List Nat := [2,4,8,0,0,64,9,14,75,15,0,11,66,10,1,73,10,74,15,0,75,1,0,3,67,65,1,10,11,74,69,0,14,1,74,74]

theorem envBound42738 : H12AffineFastState.Bounded env42738 := by
  intro p hp
  have h : env42738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42737_42738 : H12AffineEnvironment.transform 7 14 env42737 = env42738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env42737 == env42738) = true)

theorem identity42738 : scanCanonicalize (H12AffineFastState.compose env42738 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42739 : List Nat := [2,4,8,0,0,1,9,14,10,15,0,11,3,10,1,8,10,11,15,0,10,1,0,3,2,0,1,10,11,11,4,0,14,1,11,11]

theorem envBound42739 : H12AffineFastState.Bounded env42739 := by
  intro p hp
  have h : env42739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42738_42739 : H12AffineEnvironment.transform 5 1 env42738 = env42739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42738 == env42739) = true)

def env42740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,17,98780,8328,65,4259061,5393,17664,32041,1500,4256861,256,21793,46212,74251]

theorem envBound42740 : H12AffineFastState.Bounded env42740 := by
  intro p hp
  have h : env42740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42723_42740 : H12AffineEnvironment.transform 20 4161 env42723 = env42740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42723 == env42740) = true)

theorem identity42740 : scanCanonicalize (H12AffineFastState.compose env42740 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound42740 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,243123,17,98780,8328,65,215366,5393,17664,32041,1500,213486,256,21793,46212,74251]

theorem envBound42741 : H12AffineFastState.Bounded env42741 := by
  intro p hp
  have h : env42741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42740_42741 : H12AffineEnvironment.transform 21 243123 env42740 = env42741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env42740 == env42741) = true)

def env42742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,243003,17,98644,8192,65,215366,5393,17664,32041,1364,213350,256,21793,46092,74251]

theorem envBound42742 : H12AffineFastState.Bounded env42742 := by
  intro p hp
  have h : env42742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42741_42742 : H12AffineEnvironment.transform 6 8 env42741 = env42742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42741 == env42742) = true)

theorem identity42742 : scanCanonicalize (H12AffineFastState.compose env42742 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138341,1024,8541,4161,201831,17,73736,8192,65,215366,5393,17664,32041,1364,213350,256,21793,5456,74251]

theorem envBound42743 : H12AffineFastState.Bounded env42743 := by
  intro p hp
  have h : env42743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42742_42743 : H12AffineEnvironment.transform 14 8540 env42742 = env42743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42742 == env42743) = true)

theorem identity42743 : scanCanonicalize (H12AffineFastState.compose env42743 (packedSelected [0,1,6,7,10,14,20,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound42743 : packedSelected [0,1,6,7,10,14,20,26,28] rootPS < 2^1333 := by decide +kernel

def env42744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8495,131072,138341,1024,8541,4161,144712,17,295,8192,65,157801,5393,17664,32041,1364,155721,256,21793,5456,804]

theorem envBound42744 : H12AffineFastState.Bounded env42744 := by
  intro p hp
  have h : env42744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42743_42744 : H12AffineEnvironment.transform 15 8495 env42743 = env42744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env42743 == env42744) = true)

theorem identity42744 : scanCanonicalize (H12AffineFastState.compose env42744 (packedSelected [0,2,3,4,5,10,11,12,15,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound42744 : packedSelected [0,2,3,4,5,10,11,12,15,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env42745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8495,5221,2048,1024,8541,4161,8493,17,295,8192,65,31756,5393,17664,32041,1364,29740,256,21793,5456,804]

theorem envBound42745 : H12AffineFastState.Bounded env42745 := by
  intro p hp
  have h : env42745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42744_42745 : H12AffineEnvironment.transform 16 5221 env42744 = env42745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env42744 == env42745) = true)

theorem identity42745 : scanCanonicalize (H12AffineFastState.compose env42745 (packedSelected [4,6,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42745 : packedSelected [4,6,14,20,22] rootPS < 2^1333 := by decide +kernel

def env42746 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,8282,5221,2048,1024,8232,4161,8280,17,82,8192,65,31756,5220,17525,31836,1057,29740,117,21588,5157,593]

theorem envBound42746 : H12AffineFastState.Bounded env42746 := by
  intro p hp
  have h : env42746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42745_42746 : H12AffineEnvironment.transform 7 117 env42745 = env42746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42745 == env42746) = true)

theorem identity42746 : scanCanonicalize (H12AffineFastState.compose env42746 (packedSelected [0,1,3,4,5,6,7,8,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound42746 : packedSelected [0,1,3,4,5,6,7,8,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env42747 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,16384,1124,1047,5221,2048,1024,1125,4161,1045,17,82,1101,65,22593,5220,17525,22545,1057,20577,117,21588,5157,593]

theorem envBound42747 : H12AffineFastState.Bounded env42747 := by
  intro p hp
  have h : env42747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42746_42747 : H12AffineEnvironment.transform 12 1101 env42746 = env42747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env42746 == env42747) = true)

def env42748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,243002,17,98645,8193,65,215366,5393,17664,32041,1365,213351,256,21793,46093,74251]

theorem envBound42748 : H12AffineFastState.Bounded env42748 := by
  intro p hp
  have h : env42748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42741_42748 : H12AffineEnvironment.transform 6 9 env42741 = env42748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42741 == env42748) = true)

theorem identity42748 : scanCanonicalize (H12AffineFastState.compose env42748 (packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound42748 : packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS < 2^1333 := by decide +kernel

def env42749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,114967,97326,1024,32769,4161,29741,17,98645,8193,65,34897,5393,17664,32041,1365,32880,256,21793,46093,74251]

theorem envBound42749 : H12AffineFastState.Bounded env42749 := by
  intro p hp
  have h : env42749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42748_42749 : H12AffineEnvironment.transform 16 114967 env42748 = env42749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env42748 == env42749) = true)

theorem identity42749 : scanCanonicalize (H12AffineFastState.compose env42749 (packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42749 : packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS < 2^1333 := by decide +kernel

def env42750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,57629,23588,1024,32769,4161,29741,17,41311,8193,65,34897,5393,17664,32041,1365,32880,256,21793,46093,513]

theorem envBound42750 : H12AffineFastState.Bounded env42750 := by
  intro p hp
  have h : env42750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42749_42750 : H12AffineEnvironment.transform 15 8202 env42749 = env42750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42749 == env42750) = true)

theorem identity42750 : scanCanonicalize (H12AffineFastState.compose env42750 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound42750 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8202,16401,23588,1024,8461,4161,29741,17,83,8193,65,10589,5393,17664,32041,1365,8572,256,21793,5377,513]

theorem envBound42751 : H12AffineFastState.Bounded env42751 := by
  intro p hp
  have h : env42751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42750_42751 : H12AffineEnvironment.transform 14 8460 env42750 = env42751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env42750 == env42751) = true)

theorem identity42751 : scanCanonicalize (H12AffineFastState.compose env42751 (packedSelected [0,2,9,10,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound42751 : packedSelected [0,2,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env42752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8460,8202,5173,2048,1024,8461,4161,8201,17,83,8193,65,10589,5393,4388,10509,1365,8572,256,261,5377,513]

theorem envBound42752 : H12AffineFastState.Bounded env42752 := by
  intro p hp
  have h : env42752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42751_42752 : H12AffineEnvironment.transform 13 5156 env42751 = env42752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env42751 == env42752) = true)

theorem identity42752 : scanCanonicalize (H12AffineFastState.compose env42752 (packedSelected [3,4,5,7,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound42752 : packedSelected [3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env42753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5156,372,114,5173,2048,1024,373,4161,113,17,83,121,65,2341,5393,4388,2421,1365,260,256,261,5377,513]

theorem envBound42753 : H12AffineFastState.Bounded env42753 := by
  intro p hp
  have h : env42753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42752_42753 : H12AffineEnvironment.transform 12 120 env42752 = env42753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env42752 == env42753) = true)

theorem identity42753 : scanCanonicalize (H12AffineFastState.compose env42753 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42753 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env42754 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5156,292,34,5173,2048,1024,293,4113,33,17,3,41,17,2341,5393,4388,2341,1285,260,256,261,5377,513]

theorem envBound42754 : H12AffineFastState.Bounded env42754 := by
  intro p hp
  have h : env42754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42753_42754 : H12AffineEnvironment.transform 5 16 env42753 = env42754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42753 == env42754) = true)

theorem identity42754 : scanCanonicalize (H12AffineFastState.compose env42754 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42754 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42755 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5173,2048,1024,0,4113,33,17,3,41,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound42755 : H12AffineFastState.Bounded env42755 := by
  intro p hp
  have h : env42755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42754_42755 : H12AffineEnvironment.transform 7 37 env42754 = env42755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42754 == env42755) = true)

def env42756 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,1,34,1029,2048,1024,0,33,33,17,3,41,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound42756 : H12AffineFastState.Bounded env42756 := by
  intro p hp
  have h : env42756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42755_42756 : H12AffineEnvironment.transform 11 48 env42755 = env42756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42755 == env42756) = true)

theorem identity42756 : scanCanonicalize (H12AffineFastState.compose env42756 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound42756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42757 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,48,40,1044,1,34,1029,560,1024,0,33,33,17,3,41,17,560,1028,49,560,1056,33,37,32,1044,513]

theorem envBound42757 : H12AffineFastState.Bounded env42757 := by
  intro p hp
  have h : env42757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42756_42757 : H12AffineEnvironment.transform 10 560 env42756 = env42757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env42756 == env42757) = true)

def env42758 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,40,32,1,34,49,560,52,0,33,33,17,3,41,17,560,48,49,560,20,33,37,32,32,513]

theorem envBound42758 : H12AffineFastState.Bounded env42758 := by
  intro p hp
  have h : env42758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42757_42758 : H12AffineEnvironment.transform 9 52 env42757 = env42758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42757 == env42758) = true)

theorem identity42758 : scanCanonicalize (H12AffineFastState.compose env42758 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42759 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,48,40,32,1,34,49,32,52,0,33,33,17,3,41,17,32,48,49,32,20,33,37,32,32,17]

theorem envBound42759 : H12AffineFastState.Bounded env42759 := by
  intro p hp
  have h : env42759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42758_42759 : H12AffineEnvironment.transform 8 16 env42758 = env42759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42758 == env42759) = true)

def leafEnv42759 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,48,40,32,1,34,49,32,52,0,33,33,17,3,20,41,1,17,32,48,49,32,20,33,37,32,4,35,32,17,1,33,0]

def active42759 : List Nat := [0,1,2,3,4]

def tree42759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42759 : H12WitnessSearch.Good tree42759 := H12GlobalWitnessIndex.good

theorem leafIdentity42759 : H12AffineFastState.composeSystem env42759 rootObs = leafEnv42759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42759 rootObs == leafEnv42759) = true)

theorem terminalChecked42759 : H12PackedTerminal.terminalCheckFast leafEnv42759 active42759 tree42759 = true := by decide +kernel

def env42760 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,40,33,1,34,48,560,53,0,33,33,17,3,41,17,560,49,49,560,21,33,37,32,33,513]

theorem envBound42760 : H12AffineFastState.Bounded env42760 := by
  intro p hp
  have h : env42760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42757_42760 : H12AffineEnvironment.transform 9 53 env42757 = env42760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42757 == env42760) = true)

theorem identity42760 : scanCanonicalize (H12AffineFastState.compose env42760 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound42760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42761 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,11,19,26,1,25,11,523,14,0,26,26,17,3,18,17,523,10,10,523,21,26,30,27,26,513]

theorem envBound42761 : H12AffineFastState.Bounded env42761 := by
  intro p hp
  have h : env42761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42760_42761 : H12AffineEnvironment.transform 4 27 env42760 = env42761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env42760 == env42761) = true)

def leafEnv42761 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,11,19,26,1,25,11,523,14,0,26,26,17,3,21,18,1,17,523,10,10,523,21,26,30,27,4,24,26,513,1,26,0]

def active42761 : List Nat := [0,1,2,3,8]

def tree42761 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42761 : H12WitnessSearch.Good tree42761 := H12GlobalWitnessIndex.good

theorem leafIdentity42761 : H12AffineFastState.composeSystem env42761 rootObs = leafEnv42761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42761 rootObs == leafEnv42761) = true)

theorem terminalChecked42761 : H12PackedTerminal.terminalCheckFast leafEnv42761 active42761 tree42761 = true := by decide +kernel

def env42762 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,1,34,1028,2048,1024,0,32,33,17,3,41,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound42762 : H12AffineFastState.Bounded env42762 := by
  intro p hp
  have h : env42762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42755_42762 : H12AffineEnvironment.transform 11 49 env42755 = env42762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42755 == env42762) = true)

theorem identity42762 : scanCanonicalize (H12AffineFastState.compose env42762 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound42762 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42763 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,49,40,1045,1,34,1028,1540,1024,0,32,33,17,3,41,17,1540,1029,48,1540,1056,33,37,32,1045,513]

theorem envBound42763 : H12AffineFastState.Bounded env42763 := by
  intro p hp
  have h : env42763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42762_42763 : H12AffineEnvironment.transform 10 1540 env42762 = env42763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env42762 == env42763) = true)

def env42764 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,40,33,1,34,48,560,52,0,32,33,17,3,41,17,560,49,48,560,20,33,37,32,33,513]

theorem envBound42764 : H12AffineFastState.Bounded env42764 := by
  intro p hp
  have h : env42764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42763_42764 : H12AffineEnvironment.transform 9 52 env42763 = env42764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42763 == env42764) = true)

theorem identity42764 : scanCanonicalize (H12AffineFastState.compose env42764 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42765 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,49,40,33,1,34,48,33,52,0,32,33,17,3,41,17,33,49,48,33,20,33,37,32,33,16]

theorem envBound42765 : H12AffineFastState.Bounded env42765 := by
  intro p hp
  have h : env42765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42764_42765 : H12AffineEnvironment.transform 8 17 env42764 = env42765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42764 == env42765) = true)

def leafEnv42765 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,49,40,33,1,34,48,33,52,0,32,33,17,3,20,41,1,17,33,49,48,33,20,33,37,32,4,35,33,16,1,32,0]

def active42765 : List Nat := [0,1,2,3,4]

def tree42765 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42765 : H12WitnessSearch.Good tree42765 := H12GlobalWitnessIndex.good

theorem leafIdentity42765 : H12AffineFastState.composeSystem env42765 rootObs = leafEnv42765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42765 rootObs == leafEnv42765) = true)

theorem terminalChecked42765 : H12PackedTerminal.terminalCheckFast leafEnv42765 active42765 tree42765 = true := by decide +kernel

def env42766 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,40,32,1,34,49,561,53,0,32,33,17,3,41,17,561,48,48,561,21,33,37,32,32,513]

theorem envBound42766 : H12AffineFastState.Bounded env42766 := by
  intro p hp
  have h : env42766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42763_42766 : H12AffineEnvironment.transform 9 53 env42763 = env42766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42763 == env42766) = true)

theorem identity42766 : scanCanonicalize (H12AffineFastState.compose env42766 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound42766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42767 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,11,18,26,1,24,11,523,15,0,26,27,17,3,19,17,523,10,10,523,21,27,31,26,26,513]

theorem envBound42767 : H12AffineFastState.Bounded env42767 := by
  intro p hp
  have h : env42767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42766_42767 : H12AffineEnvironment.transform 4 26 env42766 = env42767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env42766 == env42767) = true)

def leafEnv42767 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,11,18,26,1,24,11,523,15,0,26,27,17,3,21,19,1,17,523,10,10,523,21,27,31,26,4,25,26,513,1,26,0]

def active42767 : List Nat := [0,1,2,3,8]

def tree42767 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42767 : H12WitnessSearch.Good tree42767 := H12GlobalWitnessIndex.good

theorem leafIdentity42767 : H12AffineFastState.composeSystem env42767 rootObs = leafEnv42767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42767 rootObs == leafEnv42767) = true)

theorem terminalChecked42767 : H12PackedTerminal.terminalCheckFast leafEnv42767 active42767 tree42767 = true := by decide +kernel

def env42768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound42768 : H12AffineFastState.Bounded env42768 := by
  intro p hp
  have h : env42768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42575_42768 : H12AffineEnvironment.transform 18 1025 env42575 = env42768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42575 == env42768) = true)

theorem identity42768 : scanCanonicalize (H12AffineFastState.compose env42768 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444776) := by decide +kernel

theorem selectedBound42768 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444776,8328,65,14847464,313701,10507600,8830976,10799609,4466728,257,8685892,8677600,10874415]

theorem envBound42769 : H12AffineFastState.Bounded env42769 := by
  intro p hp
  have h : env42769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42768_42769 : H12AffineEnvironment.transform 23 2444776 env42768 = env42769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444776 env42768 == env42769) = true)

def env42770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444776,8328,65,6705548,313701,2394420,138340,2102685,4466728,257,21792,46212,2175563]

theorem envBound42770 : H12AffineFastState.Bounded env42770 := by
  intro p hp
  have h : env42770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42769_42770 : H12AffineEnvironment.transform 22 318564 env42769 = env42770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318564 env42769 == env42770) = true)

def env42771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444640,8192,65,6705412,313701,2394420,138340,2102549,4466728,257,21792,46092,2175563]

theorem envBound42771 : H12AffineFastState.Bounded env42771 := by
  intro p hp
  have h : env42771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42770_42771 : H12AffineEnvironment.transform 6 8 env42770 = env42771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42770 == env42771) = true)

def env42772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318564,2444640,8192,65,158028,313701,2394420,138340,2102549,2101344,257,21792,46092,2175563]

theorem envBound42772 : H12AffineFastState.Bounded env42772 := by
  intro p hp
  have h : env42772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42771_42772 : H12AffineEnvironment.transform 21 2373704 env42771 = env42772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env42771 == env42772) = true)

theorem identity42772 : scanCanonicalize (H12AffineFastState.compose env42772 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound42772 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,329730,318564,294186,8192,65,158028,313701,375166,138340,75103,73770,257,21792,46092,513]

theorem envBound42773 : H12AffineFastState.Bounded env42773 := by
  intro p hp
  have h : env42773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42772_42773 : H12AffineEnvironment.transform 20 77898 env42772 = env42773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env42772 == env42773) = true)

def env42774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77898,73770,62540,21762,8192,65,158028,57677,102742,138340,75103,73770,257,21792,46092,513]

theorem envBound42774 : H12AffineFastState.Bounded env42774 := by
  intro p hp
  have h : env42774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42773_42774 : H12AffineEnvironment.transform 17 10280 env42773 = env42774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42773 == env42774) = true)

def env42775 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77850,73770,62492,21762,8192,17,157980,57629,102662,138292,75023,73770,257,21792,46092,513]

theorem envBound42775 : H12AffineFastState.Bounded env42775 := by
  intro p hp
  have h : env42775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42774_42775 : H12AffineEnvironment.transform 5 16 env42774 = env42775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42774 == env42775) = true)

theorem identity42775 : scanCanonicalize (H12AffineFastState.compose env42775 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound42775 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env42776 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77850,73770,62492,21762,8192,17,67846,57629,102662,97326,75023,73770,257,21792,46092,513]

theorem envBound42776 : H12AffineFastState.Bounded env42776 := by
  intro p hp
  have h : env42776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42775_42776 : H12AffineEnvironment.transform 16 90138 env42775 = env42776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env42775 == env42776) = true)

theorem identity42776 : scanCanonicalize (H12AffineFastState.compose env42776 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42776 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42777 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,65536,90138,10280,1025,21760,77850,73770,8477,21762,8192,17,67846,13340,82951,97326,75023,73770,257,21792,24845,513]

theorem envBound42777 : H12AffineFastState.Bounded env42777 := by
  intro p hp
  have h : env42777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42776_42777 : H12AffineEnvironment.transform 14 21761 env42776 = env42777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42776 == env42777) = true)

theorem identity42777 : scanCanonicalize (H12AffineFastState.compose env42777 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound42777 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42778 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21761,29962,5392,10280,1025,21760,17680,21792,8477,21762,8192,17,31756,13340,12557,2340,20485,21792,257,21792,24845,513]

theorem envBound42778 : H12AffineFastState.Bounded env42778 := by
  intro p hp
  have h : env42778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42777_42778 : H12AffineEnvironment.transform 15 29962 env42777 = env42778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env42777 == env42778) = true)

theorem identity42778 : scanCanonicalize (H12AffineFastState.compose env42778 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42778 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env42779 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,16384,21761,21794,5392,2048,1025,21760,17680,21792,309,21762,40,17,23588,5172,4389,2340,20485,21792,257,21792,16677,513]

theorem envBound42779 : H12AffineFastState.Bounded env42779 := by
  intro p hp
  have h : env42779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42778_42779 : H12AffineEnvironment.transform 12 40 env42778 = env42779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42778 == env42779) = true)

theorem identity42779 : scanCanonicalize (H12AffineFastState.compose env42779 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42779 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env42780 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,0,35,5392,2048,1025,1,4113,33,309,3,40,17,2341,5172,4389,2340,1284,33,257,33,5156,513]

theorem envBound42780 : H12AffineFastState.Bounded env42780 := by
  intro p hp
  have h : env42780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42779_42780 : H12AffineEnvironment.transform 13 5377 env42779 = env42780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42779 == env42780) = true)

theorem identity42780 : scanCanonicalize (H12AffineFastState.compose env42780 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound42780 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42781 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,40,1077,0,35,1060,2048,1025,1,293,33,309,3,40,17,2341,1280,17,2340,1284,33,257,33,1296,513]

theorem envBound42781 : H12AffineFastState.Bounded env42781 := by
  intro p hp
  have h : env42781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42780_42781 : H12AffineEnvironment.transform 11 308 env42780 = env42781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env42780 == env42781) = true)

theorem identity42781 : scanCanonicalize (H12AffineFastState.compose env42781 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound42781 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42782 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,308,40,1077,0,35,1060,1076,1025,1,293,33,309,3,40,17,1297,1280,17,1296,1284,33,257,33,1296,513]

theorem envBound42782 : H12AffineFastState.Bounded env42782 := by
  intro p hp
  have h : env42782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42781_42782 : H12AffineEnvironment.transform 10 1076 env42781 = env42782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env42781 == env42782) = true)

theorem identity42782 : scanCanonicalize (H12AffineFastState.compose env42782 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound42782 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42783 : List Nat := [2,4,8,16,32,16,8,256,512,304,260,308,40,261,0,35,276,260,305,1,293,33,309,3,40,17,33,48,17,32,52,33,257,33,32,513]

theorem envBound42783 : H12AffineFastState.Bounded env42783 := by
  intro p hp
  have h : env42783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42782_42783 : H12AffineEnvironment.transform 9 304 env42782 = env42783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env42782 == env42783) = true)

theorem identity42783 : scanCanonicalize (H12AffineFastState.compose env42783 (packedSelected [0,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound42783 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env42784 : List Nat := [2,4,8,16,32,16,8,256,63,304,260,308,40,261,0,35,276,260,305,1,293,33,309,3,40,17,33,48,17,32,52,33,257,33,32,62]

theorem envBound42784 : H12AffineFastState.Bounded env42784 := by
  intro p hp
  have h : env42784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42783_42784 : H12AffineEnvironment.transform 8 63 env42783 = env42784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env42783 == env42784) = true)

theorem identity42784 : scanCanonicalize (H12AffineFastState.compose env42784 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42784 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42785 : List Nat := [2,4,8,16,32,16,8,37,63,21,33,17,40,32,0,35,49,33,20,1,0,33,16,3,40,17,33,48,17,32,52,33,36,33,32,62]

theorem envBound42785 : H12AffineFastState.Bounded env42785 := by
  intro p hp
  have h : env42785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42784_42785 : H12AffineEnvironment.transform 7 37 env42784 = env42785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42784 == env42785) = true)

theorem identity42785 : scanCanonicalize (H12AffineFastState.compose env42785 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound42785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42786 : List Nat := [2,4,8,16,20,16,8,17,11,21,21,17,28,20,0,23,5,21,20,1,0,21,16,3,28,17,21,4,17,20,0,21,16,21,20,10]

theorem envBound42786 : H12AffineFastState.Bounded env42786 := by
  intro p hp
  have h : env42786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42785_42786 : H12AffineEnvironment.transform 4 20 env42785 = env42786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env42785 == env42786) = true)

theorem identity42786 : scanCanonicalize (H12AffineFastState.compose env42786 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound42786 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42787 : List Nat := [2,4,8,8,12,8,8,9,11,13,13,9,4,12,0,15,5,13,12,1,0,13,8,3,4,9,13,4,9,12,0,13,8,13,12,10]

theorem envBound42787 : H12AffineFastState.Bounded env42787 := by
  intro p hp
  have h : env42787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42786_42787 : H12AffineEnvironment.transform 3 8 env42786 = env42787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env42786 == env42787) = true)

def env42788 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77851,73770,62493,21762,8192,16,157981,57628,102663,138293,75022,73770,257,21792,46092,513]

theorem envBound42788 : H12AffineFastState.Bounded env42788 := by
  intro p hp
  have h : env42788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42774_42788 : H12AffineEnvironment.transform 5 17 env42774 = env42788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42774 == env42788) = true)

theorem identity42788 : scanCanonicalize (H12AffineFastState.compose env42788 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42788 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env42789 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,131072,10280,1025,0,77851,73770,29724,21762,8192,16,157981,24861,69894,138293,75022,73770,257,21792,13325,513]

theorem envBound42789 : H12AffineFastState.Bounded env42789 := by
  intro p hp
  have h : env42789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42788_42789 : H12AffineEnvironment.transform 14 1 env42788 = env42789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42788 == env42789) = true)

theorem identity42789 : scanCanonicalize (H12AffineFastState.compose env42789 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound42789 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env42790 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,10280,1025,0,77851,73770,29724,21762,8192,16,10509,24861,69894,23589,75022,73770,257,21792,13325,513]

theorem envBound42790 : H12AffineFastState.Bounded env42790 := by
  intro p hp
  have h : env42790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42789_42790 : H12AffineEnvironment.transform 16 16400 env42789 = env42790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42789 == env42790) = true)

theorem identity42790 : scanCanonicalize (H12AffineFastState.compose env42790 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42790 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42791 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1025,0,4112,33,29724,21762,8192,16,10509,24861,12557,23589,1285,33,257,21792,13325,513]

theorem envBound42791 : H12AffineFastState.Bounded env42791 := by
  intro p hp
  have h : env42791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42790_42791 : H12AffineEnvironment.transform 15 8203 env42790 = env42791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42790 == env42791) = true)

theorem identity42791 : scanCanonicalize (H12AffineFastState.compose env42791 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42791 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42792 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,1,8203,13341,10280,1025,0,4112,33,17,8463,8192,16,10509,5392,12557,10280,1285,33,257,8493,13325,513]

theorem envBound42792 : H12AffineFastState.Bounded env42792 := by
  intro p hp
  have h : env42792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42791_42792 : H12AffineEnvironment.transform 13 13325 env42791 = env42792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42791 == env42792) = true)

theorem identity42792 : scanCanonicalize (H12AffineFastState.compose env42792 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42792 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42793 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5392,2341,1025,0,4112,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound42793 : H12AffineFastState.Bounded env42793 := by
  intro p hp
  have h : env42793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42792_42793 : H12AffineEnvironment.transform 12 269 env42792 = env42793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42792 == env42793) = true)

theorem identity42793 : scanCanonicalize (H12AffineFastState.compose env42793 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42794 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5173,2048,1025,0,4112,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound42794 : H12AffineFastState.Bounded env42794 := by
  intro p hp
  have h : env42794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42793_42794 : H12AffineEnvironment.transform 7 37 env42793 = env42794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42793 == env42794) = true)

def env42795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77898,73771,62541,21763,8192,65,158028,57676,102743,138340,75103,73770,257,21792,46092,513]

theorem envBound42795 : H12AffineFastState.Bounded env42795 := by
  intro p hp
  have h : env42795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42773_42795 : H12AffineEnvironment.transform 17 10281 env42773 = env42795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42773 == env42795) = true)

theorem identity42795 : scanCanonicalize (H12AffineFastState.compose env42795 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42795 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,4161,32,62541,21763,8192,65,158028,57676,45404,138340,1364,33,257,21792,46092,513]

theorem envBound42796 : H12AffineFastState.Bounded env42796 := by
  intro p hp
  have h : env42796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42795_42796 : H12AffineEnvironment.transform 15 8203 env42795 = env42796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42795 == env42796) = true)

theorem identity42796 : scanCanonicalize (H12AffineFastState.compose env42796 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 16693) := by decide +kernel

theorem selectedBound42796 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env42797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16693,10281,1025,32769,4161,32,62541,21763,8192,65,10361,57676,45404,23889,1364,33,257,21792,46092,513]

theorem envBound42797 : H12AffineFastState.Bounded env42797 := by
  intro p hp
  have h : env42797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42796_42797 : H12AffineEnvironment.transform 16 16693 env42796 = env42797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16693 env42796 == env42797) = true)

theorem identity42797 : scanCanonicalize (H12AffineFastState.compose env42797 (packedSelected [2,4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound42797 : packedSelected [2,4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env42798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,32768,2162,16693,80,1025,32769,4161,32,56372,21763,2169,65,0,51509,39205,23889,1364,33,257,21792,40053,513]

theorem envBound42798 : H12AffineFastState.Bounded env42798 := by
  intro p hp
  have h : env42798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42797_42798 : H12AffineEnvironment.transform 12 2169 env42797 = env42798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env42797 == env42798) = true)

theorem identity42798 : scanCanonicalize (H12AffineFastState.compose env42798 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 23589) := by decide +kernel

theorem selectedBound42798 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,16384,23589,2162,16693,80,1025,23588,4161,32,17,21763,2169,65,0,5392,17664,23889,1364,33,257,21792,16464,513]

theorem envBound42799 : H12AffineFastState.Bounded env42799 := by
  intro p hp
  have h : env42799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42798_42799 : H12AffineEnvironment.transform 14 23589 env42798 = env42799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23589 env42798 == env42799) = true)

theorem identity42799 : scanCanonicalize (H12AffineFastState.compose env42799 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound42799 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env42800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,7285,80,2162,7488,80,1025,81,4161,32,17,2422,2169,65,0,5392,6517,292,1364,33,257,2389,7205,513]

theorem envBound42800 : H12AffineFastState.Bounded env42800 := by
  intro p hp
  have h : env42800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42799_42800 : H12AffineEnvironment.transform 13 7285 env42799 = env42800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env42799 == env42800) = true)

theorem identity42800 : scanCanonicalize (H12AffineFastState.compose env42800 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound42800 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1360,2169,2341,80,2162,2064,80,1025,81,1297,32,17,2422,2169,65,0,64,3109,292,1364,33,257,2389,2421,513]

theorem envBound42801 : H12AffineFastState.Bounded env42801 := by
  intro p hp
  have h : env42801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42800_42801 : H12AffineEnvironment.transform 11 1360 env42800 = env42801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env42800 == env42801) = true)

theorem identity42801 : scanCanonicalize (H12AffineFastState.compose env42801 (packedSelected [0,1,4,6,7,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42801 : packedSelected [0,1,4,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env42802 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,65,2169,2341,80,2162,2064,80,272,81,0,32,17,2422,2169,65,0,64,2356,292,69,33,257,2389,2421,513]

theorem envBound42802 : H12AffineFastState.Bounded env42802 := by
  intro p hp
  have h : env42802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42801_42802 : H12AffineEnvironment.transform 9 273 env42801 = env42802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42801 == env42802) = true)

def env42803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318564,2444640,8192,65,158029,313701,2394420,138340,2102549,2101345,257,21792,46092,2175563]

theorem envBound42803 : H12AffineFastState.Bounded env42803 := by
  intro p hp
  have h : env42803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42771_42803 : H12AffineEnvironment.transform 21 2373705 env42771 = env42803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env42771 == env42803) = true)

def env42804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318564,351520,8192,65,158029,313701,301428,138340,1365,33,257,21792,46092,74251]

theorem envBound42804 : H12AffineFastState.Bounded env42804 := by
  intro p hp
  have h : env42804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42803_42804 : H12AffineEnvironment.transform 20 4160 env42803 = env42804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42803 == env42804) = true)

theorem identity42804 : scanCanonicalize (H12AffineFastState.compose env42804 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound42804 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,4160,272393,318564,297335,8192,65,158029,313701,301428,138340,1365,33,257,21792,46092,63068]

theorem envBound42805 : H12AffineFastState.Bounded env42805 := by
  intro p hp
  have h : env42805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42804_42805 : H12AffineEnvironment.transform 15 54359 env42804 = env42805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env42804 == env42805) = true)

def env42806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1025,32769,4160,33,62540,41311,8192,65,158029,57677,45404,138340,1365,33,257,21792,46092,63068]

theorem envBound42806 : H12AffineFastState.Bounded env42806 := by
  intro p hp
  have h : env42806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42805_42806 : H12AffineEnvironment.transform 17 10280 env42805 = env42806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42805 == env42806) = true)

theorem identity42806 : scanCanonicalize (H12AffineFastState.compose env42806 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound42806 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,57677,10280,1025,32769,4160,33,62540,41311,8192,65,34816,57677,45404,64809,1365,33,257,21792,46092,63068]

theorem envBound42807 : H12AffineFastState.Bounded env42807 := by
  intro p hp
  have h : env42807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42806_42807 : H12AffineEnvironment.transform 16 57677 env42806 = env42807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env42806 == env42807) = true)

def env42808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,32,62541,41310,8192,65,158029,57676,45405,138340,1365,33,257,21792,46092,63068]

theorem envBound42808 : H12AffineFastState.Bounded env42808 := by
  intro p hp
  have h : env42808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42805_42808 : H12AffineEnvironment.transform 17 10281 env42805 = env42808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42805 == env42808) = true)

theorem identity42808 : scanCanonicalize (H12AffineFastState.compose env42808 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound42808 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1025,29789,4160,32,17,21762,8192,65,158029,5392,17665,138340,1365,33,257,21792,16464,512]

theorem envBound42809 : H12AffineFastState.Bounded env42809 := by
  intro p hp
  have h : env42809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42808_42809 : H12AffineEnvironment.transform 14 29788 env42808 = env42809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42808 == env42809) = true)

theorem identity42809 : scanCanonicalize (H12AffineFastState.compose env42809 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 10265) := by decide +kernel

theorem selectedBound42809 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,10265,10281,1025,29789,4160,32,17,21762,8192,65,16724,5392,17665,13437,1365,33,257,21792,16464,512]

theorem envBound42810 : H12AffineFastState.Bounded env42810 := by
  intro p hp
  have h : env42810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42809_42810 : H12AffineEnvironment.transform 16 10265 env42809 = env42810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10265 env42809 == env42810) = true)

theorem identity42810 : scanCanonicalize (H12AffineFastState.compose env42810 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 3425) := by decide +kernel

theorem selectedBound42810 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,3425,14653,8203,10265,10281,1025,14652,4160,32,17,6243,8192,65,3125,5392,2144,13437,1365,33,257,6209,3377,512]

theorem envBound42811 : H12AffineFastState.Bounded env42811 := by
  intro p hp
  have h : env42811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42810_42811 : H12AffineEnvironment.transform 13 3425 env42810 = env42811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3425 env42810 == env42811) = true)

theorem identity42811 : scanCanonicalize (H12AffineFastState.compose env42811 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound42811 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env42812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,3425,260,6194,4128,4112,1025,261,4160,32,17,6243,6201,65,3125,5392,2144,3140,1365,33,257,6209,3377,512]

theorem envBound42812 : H12AffineFastState.Bounded env42812 := by
  intro p hp
  have h : env42812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42811_42812 : H12AffineEnvironment.transform 12 6201 env42811 = env42812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env42811 == env42812) = true)

theorem identity42812 : scanCanonicalize (H12AffineFastState.compose env42812 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound42812 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env42813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,3425,260,1047,3077,3125,1025,261,3173,32,17,1094,1052,65,3125,2357,2144,3140,1365,33,257,1124,3377,512]

theorem envBound42813 : H12AffineFastState.Bounded env42813 := by
  intro p hp
  have h : env42813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42812_42813 : H12AffineEnvironment.transform 11 3109 env42812 = env42813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env42812 == env42813) = true)

theorem identity42813 : scanCanonicalize (H12AffineFastState.compose env42813 (packedSelected [0,1,3,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42813 : packedSelected [0,1,3,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42814 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,3109,1052,3344,260,1047,3077,3125,1025,261,3092,32,17,1079,1052,48,3125,2357,2065,3125,1316,33,257,1045,3377,512]

theorem envBound42814 : H12AffineFastState.Bounded env42814 := by
  intro p hp
  have h : env42814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42813_42814 : H12AffineEnvironment.transform 5 49 env42813 = env42814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42813 == env42814) = true)

theorem identity42814 : scanCanonicalize (H12AffineFastState.compose env42814 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42814 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42815 : List Nat := [2,4,8,16,32,49,8,256,512,21,2048,2096,9,2309,260,2,2064,2080,20,261,2049,32,17,34,9,48,2080,2357,2065,2080,305,33,257,0,2340,512]

theorem envBound42815 : H12AffineFastState.Bounded env42815 := by
  intro p hp
  have h : env42815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42814_42815 : H12AffineEnvironment.transform 9 21 env42814 = env42815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42814 == env42815) = true)

theorem identity42815 : scanCanonicalize (H12AffineFastState.compose env42815 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42815 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42816 : List Nat := [2,4,8,16,32,49,8,36,512,21,2048,2096,9,2081,32,2,2064,2080,20,33,2049,32,17,34,9,48,2080,2065,2065,2080,21,33,37,0,2048,512]

theorem envBound42816 : H12AffineFastState.Bounded env42816 := by
  intro p hp
  have h : env42816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42815_42816 : H12AffineEnvironment.transform 7 36 env42815 = env42816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42815 == env42816) = true)

theorem identity42816 : scanCanonicalize (H12AffineFastState.compose env42816 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42816 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42817 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,2065,9,2048,1,2,2064,2049,20,0,2049,1,17,3,9,17,2049,2065,2065,2049,21,0,4,0,2048,512]

theorem envBound42817 : H12AffineFastState.Bounded env42817 := by
  intro p hp
  have h : env42817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42816_42817 : H12AffineEnvironment.transform 4 1 env42816 = env42817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42816 == env42817) = true)

theorem identity42817 : scanCanonicalize (H12AffineFastState.compose env42817 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound42817 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42818 : List Nat := [2,4,8,16,1,16,8,5,512,21,4,21,9,4,1,2,20,5,20,0,5,1,17,3,9,17,5,21,21,5,21,0,4,0,4,512]

theorem envBound42818 : H12AffineFastState.Bounded env42818 := by
  intro p hp
  have h : env42818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42817_42818 : H12AffineEnvironment.transform 10 4 env42817 = env42818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env42817 == env42818) = true)

theorem identity42818 : scanCanonicalize (H12AffineFastState.compose env42818 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42819 : List Nat := [2,4,8,7,1,7,8,5,512,2,4,2,9,4,1,2,3,5,3,0,5,1,6,3,9,6,5,2,2,5,2,0,4,0,4,512]

theorem envBound42819 : H12AffineFastState.Bounded env42819 := by
  intro p hp
  have h : env42819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42818_42819 : H12AffineEnvironment.transform 3 7 env42818 = env42819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42818 == env42819) = true)

theorem identity42819 : scanCanonicalize (H12AffineFastState.compose env42819 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound42819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42820 : List Nat := [1,4,8,4,1,4,8,5,512,1,4,1,9,4,1,1,0,5,0,0,5,1,5,0,9,5,5,1,1,5,1,0,4,0,4,512]

theorem envBound42820 : H12AffineFastState.Bounded env42820 := by
  intro p hp
  have h : env42820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42819_42820 : H12AffineEnvironment.transform 0 1 env42819 = env42820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env42819 == env42820) = true)

theorem identity42820 : scanCanonicalize (H12AffineFastState.compose env42820 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound42820 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42821 : List Nat := [1,4,0,4,1,4,0,5,512,1,4,1,1,4,1,1,0,5,0,0,5,1,5,0,1,5,5,1,1,5,1,0,4,0,4,512]

theorem envBound42821 : H12AffineFastState.Bounded env42821 := by
  intro p hp
  have h : env42821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42820_42821 : H12AffineEnvironment.transform 2 0 env42820 = env42821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env42820 == env42821) = true)

theorem identity42821 : scanCanonicalize (H12AffineFastState.compose env42821 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42821 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42822 : List Nat := [1,1,0,1,1,1,0,0,512,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,1,0,0,1,1,0,1,0,1,0,1,512]

theorem envBound42822 : H12AffineFastState.Bounded env42822 := by
  intro p hp
  have h : env42822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42821_42822 : H12AffineEnvironment.transform 1 1 env42821 = env42822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42821 == env42822) = true)

def env42823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318564,351521,8192,65,158029,313701,301429,138340,1364,32,257,21792,46092,74250]

theorem envBound42823 : H12AffineFastState.Bounded env42823 := by
  intro p hp
  have h : env42823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42803_42823 : H12AffineEnvironment.transform 20 4161 env42803 = env42823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42803 == env42823) = true)

theorem identity42823 : scanCanonicalize (H12AffineFastState.compose env42823 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound42823 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,130174,1025,32769,4161,119926,73754,41311,8192,65,158029,79131,91403,138340,1364,32,257,21792,46092,74250]

theorem envBound42824 : H12AffineFastState.Bounded env42824 := by
  intro p hp
  have h : env42824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42823_42824 : H12AffineEnvironment.transform 17 130174 env42823 = env42824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env42823 == env42824) = true)

def env42825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67618,1025,29789,4161,73770,73754,21763,8192,65,158029,79131,91403,138340,1364,32,257,21792,16464,74250]

theorem envBound42825 : H12AffineFastState.Bounded env42825 := by
  intro p hp
  have h : env42825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42824_42825 : H12AffineEnvironment.transform 14 29788 env42824 = env42825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42824 == env42825) = true)

theorem identity42825 : scanCanonicalize (H12AffineFastState.compose env42825 (packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42825 : packedSelected [0,2,3,6,10,11,14,16,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42826 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29788,65536,131072,67618,1025,29789,4161,73770,73754,21543,8192,65,157801,78911,91183,138340,1136,32,37,21508,16464,74250]

theorem envBound42826 : H12AffineFastState.Bounded env42826 := by
  intro p hp
  have h : env42826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42825_42826 : H12AffineEnvironment.transform 7 36 env42825 = env42826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42825 == env42826) = true)

theorem identity42826 : scanCanonicalize (H12AffineFastState.compose env42826 (packedSelected [0,3,4,5,6,7,9,11,12,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 31852) := by decide +kernel

theorem selectedBound42826 : packedSelected [0,3,4,5,6,7,9,11,12,14,19,20] rootPS < 2^1333 := by decide +kernel

def env42827 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29788,65536,31852,67618,1025,29789,4161,73770,73754,21543,8192,65,5125,78911,91183,24584,1136,32,37,21508,16464,74250]

theorem envBound42827 : H12AffineFastState.Bounded env42827 := by
  intro p hp
  have h : env42827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42826_42827 : H12AffineEnvironment.transform 16 31852 env42826 = env42827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 31852 env42826 == env42827) = true)

theorem identity42827 : scanCanonicalize (H12AffineFastState.compose env42827 (packedSelected [2,3,4,5,6,9,12,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 31839) := by decide +kernel

theorem selectedBound42827 : packedSelected [2,3,4,5,6,9,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env42828 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29788,31839,31852,29821,1025,29789,4161,23669,23621,21543,8192,65,5125,18528,6256,24584,1136,32,37,21508,16464,24149]

theorem envBound42828 : H12AffineFastState.Bounded env42828 := by
  intro p hp
  have h : env42828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42827_42828 : H12AffineEnvironment.transform 15 31839 env42827 = env42828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31839 env42827 == env42828) = true)

theorem identity42828 : scanCanonicalize (H12AffineFastState.compose env42828 (packedSelected [0,1,3,4,7,8,9,11,12,14,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 7213) := by decide +kernel

theorem selectedBound42828 : packedSelected [0,1,3,4,7,8,9,11,12,14,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42829 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,7213,16384,18545,16498,16449,18512,1025,18544,4161,23669,23621,21543,7213,65,5125,18528,6256,23589,1136,32,37,21508,16464,24149]

theorem envBound42829 : H12AffineFastState.Bounded env42829 := by
  intro p hp
  have h : env42829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42828_42829 : H12AffineEnvironment.transform 12 7213 env42828 = env42829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7213 env42828 == env42829) = true)

theorem identity42829 : scanCanonicalize (H12AffineFastState.compose env42829 (packedSelected [0,2,4,7,9,12,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 3092) := by decide +kernel

theorem selectedBound42829 : packedSelected [0,2,4,7,9,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env42830 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,7213,3092,1125,3174,3157,1092,1025,1124,4161,4193,4177,6195,7213,65,5125,1140,6256,4145,1136,32,37,6160,3140,4673]

theorem envBound42830 : H12AffineFastState.Bounded env42830 := by
  intro p hp
  have h : env42830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42829_42830 : H12AffineEnvironment.transform 13 3092 env42829 = env42830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3092 env42829 == env42830) = true)

theorem identity42830 : scanCanonicalize (H12AffineFastState.compose env42830 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound42830 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42831 : List Nat := [2,4,8,16,32,64,8,36,512,1024,112,4096,5213,1124,1125,1046,1061,1092,1025,1124,4161,4193,4177,4163,5213,65,5125,1140,4096,4145,1136,32,37,4192,1076,4673]

theorem envBound42831 : H12AffineFastState.Bounded env42831 := by
  intro p hp
  have h : env42831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42830_42831 : H12AffineEnvironment.transform 10 112 env42830 = env42831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env42830 == env42831) = true)

theorem identity42831 : scanCanonicalize (H12AffineFastState.compose env42831 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42831 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env42832 : List Nat := [2,4,8,16,32,64,8,36,512,53,112,4096,4200,81,80,35,16,113,52,81,4161,4193,4177,4163,4200,65,4144,65,4096,4145,69,32,37,4192,1,4673]

theorem envBound42832 : H12AffineFastState.Bounded env42832 := by
  intro p hp
  have h : env42832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42831_42832 : H12AffineEnvironment.transform 9 53 env42831 = env42832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42831 == env42832) = true)

theorem identity42832 : scanCanonicalize (H12AffineFastState.compose env42832 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound42832 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env42833 : List Nat := [2,4,8,16,32,64,8,36,512,53,112,48,88,81,80,35,16,113,52,81,113,81,97,115,88,65,0,65,48,1,69,32,37,80,1,625]

theorem envBound42833 : H12AffineFastState.Bounded env42833 := by
  intro p hp
  have h : env42833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42832_42833 : H12AffineEnvironment.transform 11 48 env42832 = env42833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42832 == env42833) = true)

theorem identity42833 : scanCanonicalize (H12AffineFastState.compose env42833 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42833 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42834 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,8,1,0,35,16,33,52,1,33,1,49,35,8,17,0,17,48,1,21,32,37,0,1,545]

theorem envBound42834 : H12AffineFastState.Bounded env42834 := by
  intro p hp
  have h : env42834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42833_42834 : H12AffineEnvironment.transform 5 16 env42833 = env42834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42833 == env42834) = true)

theorem identity42834 : scanCanonicalize (H12AffineFastState.compose env42834 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42835 : List Nat := [2,4,8,1,32,1,8,36,512,36,32,33,8,1,0,35,1,33,37,1,33,1,32,35,8,0,0,0,33,1,4,32,37,0,1,545]

theorem envBound42835 : H12AffineFastState.Bounded env42835 := by
  intro p hp
  have h : env42835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42834_42835 : H12AffineEnvironment.transform 3 1 env42834 = env42835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42834 == env42835) = true)

theorem identity42835 : scanCanonicalize (H12AffineFastState.compose env42835 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42835 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42836 : List Nat := [2,4,8,1,10,1,8,14,512,14,10,11,8,1,0,9,1,11,15,1,11,1,10,9,8,0,0,0,11,1,4,10,15,0,1,523]

theorem envBound42836 : H12AffineFastState.Bounded env42836 := by
  intro p hp
  have h : env42836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42835_42836 : H12AffineEnvironment.transform 4 10 env42835 = env42836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42835 == env42836) = true)

theorem identity42836 : scanCanonicalize (H12AffineFastState.compose env42836 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42836 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42837 : List Nat := [2,0,8,1,10,1,8,10,512,10,10,11,8,1,0,9,1,11,11,1,11,1,10,9,8,0,0,0,11,1,0,10,11,0,1,523]

theorem envBound42837 : H12AffineFastState.Bounded env42837 := by
  intro p hp
  have h : env42837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42836_42837 : H12AffineEnvironment.transform 1 0 env42836 = env42837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42836 == env42837) = true)

theorem identity42837 : scanCanonicalize (H12AffineFastState.compose env42837 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound42837 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42838 : List Nat := [2,0,8,1,10,1,8,10,2,10,10,11,8,1,0,9,1,11,11,1,11,1,10,9,8,0,0,0,11,1,0,10,11,0,1,9]

theorem envBound42838 : H12AffineFastState.Bounded env42838 := by
  intro p hp
  have h : env42838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42837_42838 : H12AffineEnvironment.transform 8 2 env42837 = env42838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env42837 == env42838) = true)

def env42839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,67619,1025,29788,4161,73771,73754,21762,8192,65,158029,79131,91403,138340,1364,32,257,21792,16465,74250]

theorem envBound42839 : H12AffineFastState.Bounded env42839 := by
  intro p hp
  have h : env42839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42824_42839 : H12AffineEnvironment.transform 14 29789 env42824 = env42839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42824 == env42839) = true)

theorem identity42839 : scanCanonicalize (H12AffineFastState.compose env42839 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42839 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10280,1025,29788,4161,32,17,21762,8192,65,158029,5392,17664,138340,1364,32,257,21792,16465,513]

theorem envBound42840 : H12AffineFastState.Bounded env42840 := by
  intro p hp
  have h : env42840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42839_42840 : H12AffineEnvironment.transform 15 8203 env42839 = env42840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42839 == env42840) = true)

theorem identity42840 : scanCanonicalize (H12AffineFastState.compose env42840 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42840 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env42841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8203,131072,10280,1025,81,4161,32,17,8463,8192,65,138560,5392,12557,138340,1364,32,257,8493,13404,513]

theorem envBound42841 : H12AffineFastState.Bounded env42841 := by
  intro p hp
  have h : env42841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42840_42841 : H12AffineEnvironment.transform 13 13325 env42840 = env42841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42840 == env42841) = true)

theorem identity42841 : scanCanonicalize (H12AffineFastState.compose env42841 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound42841 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8203,13388,10280,1025,81,4161,32,17,8463,8192,65,10508,5392,12557,10280,1364,32,257,8493,13404,513]

theorem envBound42842 : H12AffineFastState.Bounded env42842 := by
  intro p hp
  have h : env42842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42841_42842 : H12AffineEnvironment.transform 16 13388 env42841 = env42842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env42841 == env42842) = true)

theorem identity42842 : scanCanonicalize (H12AffineFastState.compose env42842 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42842 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,80,262,5441,2341,1025,81,4161,32,17,2,269,65,2049,5392,4096,2341,1364,32,257,32,5457,513]

theorem envBound42843 : H12AffineFastState.Bounded env42843 := by
  intro p hp
  have h : env42843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42842_42843 : H12AffineEnvironment.transform 12 269 env42842 = env42843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42842 == env42843) = true)

theorem identity42843 : scanCanonicalize (H12AffineFastState.compose env42843 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42843 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42844 : List Nat := [2,4,8,16,32,64,8,256,16,1024,2048,4096,269,5376,80,262,5441,2341,1025,81,4161,32,17,2,269,65,2049,5392,4096,2341,1364,32,257,32,5457,17]

theorem envBound42844 : H12AffineFastState.Bounded env42844 := by
  intro p hp
  have h : env42844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42843_42844 : H12AffineEnvironment.transform 8 16 env42843 = env42844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42843 == env42844) = true)

theorem identity42844 : scanCanonicalize (H12AffineFastState.compose env42844 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42844 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42845 : List Nat := [2,4,8,16,32,17,8,256,16,1024,2048,4096,269,5376,1,262,5392,2341,1025,0,4112,32,17,2,269,16,2049,5392,4096,2341,1285,32,257,32,5376,17]

theorem envBound42845 : H12AffineFastState.Bounded env42845 := by
  intro p hp
  have h : env42845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42844_42845 : H12AffineEnvironment.transform 5 17 env42844 = env42845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42844 == env42845) = true)

theorem identity42845 : scanCanonicalize (H12AffineFastState.compose env42845 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42846 : List Nat := [2,4,8,16,1,17,8,256,16,1024,2048,4096,269,5376,1,262,5392,2308,1025,0,4112,1,17,2,269,16,2049,5392,4096,2308,1285,1,257,1,5376,17]

theorem envBound42846 : H12AffineFastState.Bounded env42846 := by
  intro p hp
  have h : env42846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42845_42846 : H12AffineEnvironment.transform 4 1 env42845 = env42846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42845 == env42846) = true)

theorem identity42846 : scanCanonicalize (H12AffineFastState.compose env42846 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound42846 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42847 : List Nat := [2,4,8,16,1,17,8,256,16,1024,2048,17,269,1297,1,262,1281,2308,1025,0,1,1,17,2,269,16,2049,1281,17,2308,1285,1,257,1,1297,17]

theorem envBound42847 : H12AffineFastState.Bounded env42847 := by
  intro p hp
  have h : env42847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42846_42847 : H12AffineEnvironment.transform 11 17 env42846 = env42847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42846 == env42847) = true)

theorem identity42847 : scanCanonicalize (H12AffineFastState.compose env42847 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42847 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42848 : List Nat := [2,4,8,1,1,0,8,256,1,1024,2048,0,269,1280,1,262,1281,2308,1025,0,1,1,0,2,269,1,2049,1281,0,2308,1285,1,257,1,1280,0]

theorem envBound42848 : H12AffineFastState.Bounded env42848 := by
  intro p hp
  have h : env42848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42847_42848 : H12AffineEnvironment.transform 3 1 env42847 = env42848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42847 == env42848) = true)

theorem identity42848 : scanCanonicalize (H12AffineFastState.compose env42848 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42848 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42849 : List Nat := [2,4,8,1,1,0,8,256,1,1024,1,0,269,1280,1,262,1281,261,1025,0,1,1,0,2,269,1,0,1281,0,261,1285,1,257,1,1280,0]

theorem envBound42849 : H12AffineFastState.Bounded env42849 := by
  intro p hp
  have h : env42849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42848_42849 : H12AffineEnvironment.transform 10 1 env42848 = env42849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42848 == env42849) = true)

def env42850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318564,2444641,8193,65,6705413,313701,2394420,138340,2102548,4466728,257,21792,46093,2175563]

theorem envBound42850 : H12AffineFastState.Bounded env42850 := by
  intro p hp
  have h : env42850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42770_42850 : H12AffineEnvironment.transform 6 9 env42770 = env42850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42770 == env42850) = true)

theorem identity42850 : scanCanonicalize (H12AffineFastState.compose env42850 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

end H12CloudChart1