import H12CloudChart1Data153

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound39051 : H12AffineFastState.Bounded env39051 := by
  intro p hp
  have h : env39051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39050_39051 : H12AffineEnvironment.transform 10 32 env39050 = env39051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env39050 == env39051) = true)

def env39052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,20924,1466,16400,2477,1024,20925,4161,1181,17,21979,1337,65,3308,5392,17664,22544,1501,1228,256,21792,16520,513]

theorem envBound39052 : H12AffineFastState.Bounded env39052 := by
  intro p hp
  have h : env39052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39044_39052 : H12AffineEnvironment.transform 12 1457 env39044 = env39052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env39044 == env39052) = true)

theorem identity39052 : scanCanonicalize (H12AffineFastState.compose env39052 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound39052 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39053 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1052,16384,20497,1047,16400,2048,1024,20496,4161,1181,17,21622,1172,65,3308,5309,17581,22544,1136,1228,173,21645,16520,513]

theorem envBound39053 : H12AffineFastState.Bounded env39053 := by
  intro p hp
  have h : env39053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39052_39053 : H12AffineEnvironment.transform 7 173 env39052 = env39053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39052 == env39053) = true)

theorem identity39053 : scanCanonicalize (H12AffineFastState.compose env39053 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound39053 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env39054 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,4096,120,16384,20497,115,16400,2048,100,20496,4161,249,17,20498,240,65,2184,4313,16585,22544,20,168,173,20713,16520,513]

theorem envBound39054 : H12AffineFastState.Bounded env39054 := by
  intro p hp
  have h : env39054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39053_39054 : H12AffineEnvironment.transform 9 100 env39053 = env39054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env39053 == env39054) = true)

theorem identity39054 : scanCanonicalize (H12AffineFastState.compose env39054 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound39054 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39055 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,4096,120,4248,137,115,4232,2048,100,136,4161,249,17,138,240,65,2184,4313,4177,2184,20,168,173,113,4112,513]

theorem envBound39055 : H12AffineFastState.Bounded env39055 := by
  intro p hp
  have h : env39055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39054_39055 : H12AffineEnvironment.transform 13 4248 env39054 = env39055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env39054 == env39055) = true)

theorem identity39055 : scanCanonicalize (H12AffineFastState.compose env39055 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound39055 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39056 : List Nat := [2,4,8,16,32,64,88,117,512,100,2048,4096,120,4160,81,115,4176,2048,100,80,4161,33,17,82,40,65,2128,4097,4177,2128,20,112,117,113,4112,513]

theorem envBound39056 : H12AffineFastState.Bounded env39056 := by
  intro p hp
  have h : env39056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39055_39056 : H12AffineEnvironment.transform 6 88 env39055 = env39056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env39055 == env39056) = true)

def env39057 : List Nat := [2,4,8,16,32,64,88,117,512,100,96,4096,120,4160,81,115,4176,96,100,80,4161,33,17,82,40,65,48,4097,4177,48,20,112,117,113,4112,513]

theorem envBound39057 : H12AffineFastState.Bounded env39057 := by
  intro p hp
  have h : env39057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39056_39057 : H12AffineEnvironment.transform 10 96 env39056 = env39057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env39056 == env39057) = true)

theorem identity39057 : scanCanonicalize (H12AffineFastState.compose env39057 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound39057 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39058 : List Nat := [2,4,8,16,32,64,88,117,512,100,96,32,120,96,81,115,112,96,100,80,97,33,17,82,40,65,48,33,113,48,20,112,117,113,48,513]

theorem envBound39058 : H12AffineFastState.Bounded env39058 := by
  intro p hp
  have h : env39058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39057_39058 : H12AffineEnvironment.transform 11 32 env39057 = env39058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env39057 == env39058) = true)

def env39059 : List Nat := [2,4,8,16,32,16,8,37,512,52,48,32,40,48,1,35,32,48,52,0,49,33,17,2,40,17,48,33,33,48,20,32,37,33,48,513]

theorem envBound39059 : H12AffineFastState.Bounded env39059 := by
  intro p hp
  have h : env39059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39058_39059 : H12AffineEnvironment.transform 5 16 env39058 = env39059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39058 == env39059) = true)

theorem identity39059 : scanCanonicalize (H12AffineFastState.compose env39059 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound39059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39060 : List Nat := [2,4,8,16,32,16,8,37,59,52,48,32,40,48,1,35,32,48,52,0,49,33,17,2,40,17,48,33,33,48,20,32,37,33,48,58]

theorem envBound39060 : H12AffineFastState.Bounded env39060 := by
  intro p hp
  have h : env39060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39059_39060 : H12AffineEnvironment.transform 8 59 env39059 = env39060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env39059 == env39060) = true)

def leafEnv39060 : List Nat := [2,4,8,16,32,16,8,37,59,52,48,32,40,48,1,35,32,48,52,0,49,33,17,2,20,40,1,17,48,33,33,48,20,32,37,33,4,35,48,58,1,49,0]

def active39060 : List Nat := [0,1,2,3,4]

def tree39060 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39060 : H12WitnessSearch.Good tree39060 := H12GlobalWitnessIndex.good

theorem leafIdentity39060 : H12AffineFastState.composeSystem env39060 rootObs = leafEnv39060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39060 rootObs == leafEnv39060) = true)

theorem terminalChecked39060 : H12PackedTerminal.terminalCheckFast leafEnv39060 active39060 tree39060 = true := by decide +kernel

def env39061 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,41,49,0,34,33,49,53,1,48,33,17,3,40,16,48,33,32,48,20,33,36,32,48,513]

theorem envBound39061 : H12AffineFastState.Bounded env39061 := by
  intro p hp
  have h : env39061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39058_39061 : H12AffineEnvironment.transform 5 17 env39058 = env39061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39058 == env39061) = true)

def leafEnv39061 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,41,49,0,34,33,49,53,1,48,33,17,3,20,40,1,16,48,33,32,48,20,33,36,32,4,35,48,513,1,49,0]

def active39061 : List Nat := [0,1,2,3,4,8]

def tree39061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39061 : H12WitnessSearch.Good tree39061 := H12GlobalWitnessIndex.good

theorem leafIdentity39061 : H12AffineFastState.composeSystem env39061 rootObs = leafEnv39061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39061 rootObs == leafEnv39061) = true)

theorem terminalChecked39061 : H12PackedTerminal.terminalCheckFast leafEnv39061 active39061 tree39061 = true := by decide +kernel

def env39062 : List Nat := [2,4,8,16,32,64,88,117,512,100,97,4096,120,4160,81,115,4176,97,100,80,4161,33,17,82,40,65,49,4097,4177,49,20,112,117,113,4112,513]

theorem envBound39062 : H12AffineFastState.Bounded env39062 := by
  intro p hp
  have h : env39062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39056_39062 : H12AffineEnvironment.transform 10 97 env39056 = env39062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env39056 == env39062) = true)

theorem identity39062 : scanCanonicalize (H12AffineFastState.compose env39062 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound39062 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39063 : List Nat := [2,4,8,16,32,64,88,117,512,100,97,113,120,49,81,115,33,97,100,80,48,33,17,82,40,65,49,112,32,49,20,112,117,113,97,513]

theorem envBound39063 : H12AffineFastState.Bounded env39063 := by
  intro p hp
  have h : env39063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39062_39063 : H12AffineEnvironment.transform 11 113 env39062 = env39063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env39062 == env39063) = true)

theorem identity39063 : scanCanonicalize (H12AffineFastState.compose env39063 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39063 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39064 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,1,35,33,49,52,0,48,33,17,2,40,17,49,32,32,49,20,32,37,33,49,513]

theorem envBound39064 : H12AffineFastState.Bounded env39064 := by
  intro p hp
  have h : env39064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39063_39064 : H12AffineEnvironment.transform 5 16 env39063 = env39064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39063 == env39064) = true)

theorem identity39064 : scanCanonicalize (H12AffineFastState.compose env39064 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound39064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39065 : List Nat := [2,4,8,16,32,16,8,37,58,52,49,33,40,49,1,35,33,49,52,0,48,33,17,2,40,17,49,32,32,49,20,32,37,33,49,59]

theorem envBound39065 : H12AffineFastState.Bounded env39065 := by
  intro p hp
  have h : env39065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39064_39065 : H12AffineEnvironment.transform 8 58 env39064 = env39065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env39064 == env39065) = true)

def leafEnv39065 : List Nat := [2,4,8,16,32,16,8,37,58,52,49,33,40,49,1,35,33,49,52,0,48,33,17,2,20,40,1,17,49,32,32,49,20,32,37,33,4,35,49,59,1,48,0]

def active39065 : List Nat := [0,1,2,3,4]

def tree39065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39065 : H12WitnessSearch.Good tree39065 := H12GlobalWitnessIndex.good

theorem leafIdentity39065 : H12AffineFastState.composeSystem env39065 rootObs = leafEnv39065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39065 rootObs == leafEnv39065) = true)

theorem terminalChecked39065 : H12PackedTerminal.terminalCheckFast leafEnv39065 active39065 tree39065 = true := by decide +kernel

def env39066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101329,98780,8328,65,6351932,2098512,17665,2125280,2102684,6349852,256,21792,46213,2175563]

theorem envBound39066 : H12AffineFastState.Bounded env39066 := by
  intro p hp
  have h : env39066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39015_39066 : H12AffineEnvironment.transform 17 179633 env39015 = env39066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env39015 == env39066) = true)

def env39067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,17,98780,8328,65,4258940,5392,17665,32160,1500,4256860,256,21792,46213,74251]

theorem envBound39067 : H12AffineFastState.Bounded env39067 := by
  intro p hp
  have h : env39067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39066_39067 : H12AffineEnvironment.transform 20 4160 env39066 = env39067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39066 == env39067) = true)

theorem identity39067 : scanCanonicalize (H12AffineFastState.compose env39067 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound39067 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,156133,17,98780,8328,65,171417,5392,17665,32160,1500,169401,256,21792,46213,74251]

theorem envBound39068 : H12AffineFastState.Bounded env39068 := by
  intro p hp
  have h : env39068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39067_39068 : H12AffineEnvironment.transform 21 156133 env39067 = env39068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env39067 == env39068) = true)

def env39069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,17,98644,8192,65,171281,5392,17665,32040,1364,169265,256,21792,46093,74251]

theorem envBound39069 : H12AffineFastState.Bounded env39069 := by
  intro p hp
  have h : env39069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39068_39069 : H12AffineEnvironment.transform 6 8 env39068 = env39069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39068 == env39069) = true)

theorem identity39069 : scanCanonicalize (H12AffineFastState.compose env39069 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound39069 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,179513,1024,32769,4160,156013,17,62559,8192,65,171281,5392,17665,32040,1364,169265,256,21792,46093,22272]

theorem envBound39070 : H12AffineFastState.Bounded env39070 := by
  intro p hp
  have h : env39070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39069_39070 : H12AffineEnvironment.transform 15 29963 env39069 = env39070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env39069 == env39070) = true)

theorem identity39070 : scanCanonicalize (H12AffineFastState.compose env39070 (packedSelected [1,16,19,20,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39070 : packedSelected [1,16,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env39071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21590,131072,171108,1024,32769,4160,147504,17,54530,349,65,171281,5392,17665,23669,1364,169265,256,21792,38224,22272]

theorem envBound39071 : H12AffineFastState.Bounded env39071 := by
  intro p hp
  have h : env39071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39070_39071 : H12AffineEnvironment.transform 12 349 env39070 = env39071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39070 == env39071) = true)

theorem identity39071 : scanCanonicalize (H12AffineFastState.compose env39071 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound39071 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env39072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,131072,149861,1024,21760,4160,147504,17,3,349,65,149520,5392,17665,23669,1364,147504,256,21792,16465,22272]

theorem envBound39072 : H12AffineFastState.Bounded env39072 := by
  intro p hp
  have h : env39072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39071_39072 : H12AffineEnvironment.transform 14 21761 env39071 = env39072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39071 == env39072) = true)

theorem identity39072 : scanCanonicalize (H12AffineFastState.compose env39072 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39072 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env39073 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21761,21511,131072,149812,1024,21760,4113,147504,17,3,268,16,149520,5392,17665,23588,1285,147504,256,21792,16384,22272]

theorem envBound39073 : H12AffineFastState.Bounded env39073 := by
  intro p hp
  have h : env39073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39072_39073 : H12AffineEnvironment.transform 5 17 env39072 = env39073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39072 == env39073) = true)

theorem identity39073 : scanCanonicalize (H12AffineFastState.compose env39073 (packedSelected [1,8,10,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39073 : packedSelected [1,8,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env39074 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,16384,20497,20759,131072,149812,272,20496,4113,147504,17,3,268,16,149520,4096,16401,22836,21,147504,256,20528,16384,21008]

theorem envBound39074 : H12AffineFastState.Bounded env39074 := by
  intro p hp
  have h : env39074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39073_39074 : H12AffineEnvironment.transform 9 272 env39073 = env39074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39073 == env39074) = true)

theorem identity39074 : scanCanonicalize (H12AffineFastState.compose env39074 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound39074 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env39075 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,16384,20497,20759,4097,22837,272,20496,4113,20529,17,3,268,16,22545,4096,16401,22836,21,20529,256,20528,16384,21008]

theorem envBound39075 : H12AffineFastState.Bounded env39075 := by
  intro p hp
  have h : env39075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39074_39075 : H12AffineEnvironment.transform 16 4097 env39074 = env39075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env39074 == env39075) = true)

theorem identity39075 : scanCanonicalize (H12AffineFastState.compose env39075 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound39075 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39076 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,1,263,4097,2341,272,0,4113,33,17,3,268,16,2049,4096,4097,2340,21,33,256,32,4112,512]

theorem envBound39076 : H12AffineFastState.Bounded env39076 := by
  intro p hp
  have h : env39076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39075_39076 : H12AffineEnvironment.transform 13 4112 env39075 = env39076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env39075 == env39076) = true)

theorem identity39076 : scanCanonicalize (H12AffineFastState.compose env39076 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39076 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39077 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4112,1,35,4097,2049,52,0,4113,33,17,3,40,16,2049,4096,4097,2048,21,33,36,32,4112,512]

theorem envBound39077 : H12AffineFastState.Bounded env39077 := by
  intro p hp
  have h : env39077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39076_39077 : H12AffineEnvironment.transform 7 36 env39076 = env39077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39076 == env39077) = true)

theorem identity39077 : scanCanonicalize (H12AffineFastState.compose env39077 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound39077 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39078 : List Nat := [2,4,8,16,32,17,8,36,512,52,32,4096,40,4112,1,35,4097,33,52,0,4113,33,17,3,40,16,33,4096,4097,32,21,33,36,32,4112,512]

theorem envBound39078 : H12AffineFastState.Bounded env39078 := by
  intro p hp
  have h : env39078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39077_39078 : H12AffineEnvironment.transform 10 32 env39077 = env39078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env39077 == env39078) = true)

theorem identity39078 : scanCanonicalize (H12AffineFastState.compose env39078 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 564) := by decide +kernel

theorem selectedBound39078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39079 : List Nat := [2,4,8,16,32,17,8,36,512,52,32,564,40,548,1,35,565,33,52,0,549,33,17,3,40,16,33,564,565,32,21,33,36,32,548,512]

theorem envBound39079 : H12AffineFastState.Bounded env39079 := by
  intro p hp
  have h : env39079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39078_39079 : H12AffineEnvironment.transform 11 564 env39078 = env39079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 564 env39078 == env39079) = true)

theorem identity39079 : scanCanonicalize (H12AffineFastState.compose env39079 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39079 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39080 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,533,9,517,1,2,532,0,21,0,516,0,17,3,9,16,0,533,532,1,21,0,5,1,517,512]

theorem envBound39080 : H12AffineFastState.Bounded env39080 := by
  intro p hp
  have h : env39080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39079_39080 : H12AffineEnvironment.transform 4 1 env39079 = env39080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39079 == env39080) = true)

theorem identity39080 : scanCanonicalize (H12AffineFastState.compose env39080 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39080 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39081 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,21,9,5,1,2,20,0,21,0,4,0,17,3,9,16,0,21,20,1,21,0,5,1,5,0]

theorem envBound39081 : H12AffineFastState.Bounded env39081 := by
  intro p hp
  have h : env39081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39080_39081 : H12AffineEnvironment.transform 8 0 env39080 = env39081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39080 == env39081) = true)

theorem identity39081 : scanCanonicalize (H12AffineFastState.compose env39081 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound39081 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39082 : List Nat := [2,4,8,4,1,5,8,5,0,1,1,1,9,5,1,2,0,0,1,0,4,0,5,3,9,4,0,1,0,1,1,0,5,1,5,0]

theorem envBound39082 : H12AffineFastState.Bounded env39082 := by
  intro p hp
  have h : env39082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39081_39082 : H12AffineEnvironment.transform 3 4 env39081 = env39082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env39081 == env39082) = true)

def env39083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156012,17,98645,8193,65,171280,5392,17665,32041,1365,169264,256,21792,46092,74251]

theorem envBound39083 : H12AffineFastState.Bounded env39083 := by
  intro p hp
  have h : env39083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39068_39083 : H12AffineEnvironment.transform 6 9 env39068 = env39083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39068 == env39083) = true)

theorem identity39083 : scanCanonicalize (H12AffineFastState.compose env39083 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39083 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138340,1024,8541,4160,156012,17,73737,8193,65,146508,5392,17665,32041,1365,144492,256,21792,5456,74251]

theorem envBound39084 : H12AffineFastState.Bounded env39084 := by
  intro p hp
  have h : env39084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39083_39084 : H12AffineEnvironment.transform 14 8540 env39083 = env39084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39083 == env39084) = true)

theorem identity39084 : scanCanonicalize (H12AffineFastState.compose env39084 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound39084 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8283,131072,138340,1024,8541,4160,156012,17,82,8193,65,146508,5392,17665,32041,1365,144492,256,21792,5456,592]

theorem envBound39085 : H12AffineFastState.Bounded env39085 := by
  intro p hp
  have h : env39085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39084_39085 : H12AffineEnvironment.transform 15 8283 env39084 = env39085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env39084 == env39085) = true)

theorem identity39085 : scanCanonicalize (H12AffineFastState.compose env39085 (packedSelected [0,1,3,4,7,16,20,22,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39085 : packedSelected [0,1,3,4,7,16,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env39086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,263,131072,138340,1024,1,4160,147504,17,82,349,65,138512,5392,17665,23669,1365,136496,256,21792,5456,592]

theorem envBound39086 : H12AffineFastState.Bounded env39086 := by
  intro p hp
  have h : env39086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39085_39086 : H12AffineEnvironment.transform 12 348 env39085 = env39086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39085 == env39086) = true)

theorem identity39086 : scanCanonicalize (H12AffineFastState.compose env39086 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound39086 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,263,16401,23669,1024,1,4160,33,17,82,349,65,23809,5392,17665,23669,1365,21793,256,21792,5456,592]

theorem envBound39087 : H12AffineFastState.Bounded env39087 := by
  intro p hp
  have h : env39087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39086_39087 : H12AffineEnvironment.transform 16 16401 env39086 = env39087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39086 == env39087) = true)

theorem identity39087 : scanCanonicalize (H12AffineFastState.compose env39087 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39087 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39088 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,348,16384,0,263,16401,22544,101,1,4160,33,17,82,349,65,22884,4469,16740,22544,304,20804,256,20805,4405,592]

theorem envBound39088 : H12AffineFastState.Bounded env39088 := by
  intro p hp
  have h : env39088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39087_39088 : H12AffineEnvironment.transform 9 101 env39087 = env39088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39087 == env39088) = true)

theorem identity39088 : scanCanonicalize (H12AffineFastState.compose env39088 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39088 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env39089 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,16384,0,263,16401,22544,52,1,4113,33,17,3,268,16,22837,4388,16693,22544,304,20757,256,20756,4405,513]

theorem envBound39089 : H12AffineFastState.Bounded env39089 := by
  intro p hp
  have h : env39089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39088_39089 : H12AffineEnvironment.transform 5 17 env39088 = env39089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39088 == env39089) = true)

theorem identity39089 : scanCanonicalize (H12AffineFastState.compose env39089 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6964) := by decide +kernel

theorem selectedBound39089 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39090 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,6964,0,263,6949,804,52,1,4113,33,17,3,268,16,513,4388,6657,804,304,2593,256,2592,4405,513]

theorem envBound39090 : H12AffineFastState.Bounded env39090 := by
  intro p hp
  have h : env39090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39089_39090 : H12AffineEnvironment.transform 13 6964 env39089 = env39090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6964 env39089 == env39090) = true)

theorem identity39090 : scanCanonicalize (H12AffineFastState.compose env39090 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound39090 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env39091 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,528,269,2340,0,263,2357,804,52,1,513,33,17,3,268,16,513,820,2065,804,304,2593,256,2592,805,513]

theorem envBound39091 : H12AffineFastState.Bounded env39091 := by
  intro p hp
  have h : env39091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39090_39091 : H12AffineEnvironment.transform 11 528 env39090 = env39091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env39090 == env39091) = true)

theorem identity39091 : scanCanonicalize (H12AffineFastState.compose env39091 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound39091 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env39092 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,528,269,528,0,263,513,804,52,1,513,33,17,3,268,16,513,820,805,804,304,277,256,276,805,513]

theorem envBound39092 : H12AffineFastState.Bounded env39092 := by
  intro p hp
  have h : env39092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39091_39092 : H12AffineEnvironment.transform 10 820 env39091 = env39092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env39091 == env39092) = true)

theorem identity39092 : scanCanonicalize (H12AffineFastState.compose env39092 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound39092 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39093 : List Nat := [2,4,8,16,32,17,9,53,512,52,513,528,56,528,0,50,513,529,52,1,513,33,17,3,57,16,513,513,528,529,5,32,53,33,528,513]

theorem envBound39093 : H12AffineFastState.Bounded env39093 := by
  intro p hp
  have h : env39093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39092_39093 : H12AffineEnvironment.transform 7 53 env39092 = env39093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env39092 == env39093) = true)

theorem identity39093 : scanCanonicalize (H12AffineFastState.compose env39093 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39094 : List Nat := [2,4,8,1,32,0,9,36,512,37,513,513,41,513,0,35,513,512,37,1,513,33,0,3,40,1,513,513,513,512,5,32,36,33,513,513]

theorem envBound39094 : H12AffineFastState.Bounded env39094 := by
  intro p hp
  have h : env39094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39093_39094 : H12AffineEnvironment.transform 3 1 env39093 = env39094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39093 == env39094) = true)

theorem identity39094 : scanCanonicalize (H12AffineFastState.compose env39094 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39095 : List Nat := [2,4,8,1,32,0,9,36,1,37,0,0,41,0,0,35,0,1,37,1,0,33,0,3,40,1,0,0,0,1,5,32,36,33,0,0]

theorem envBound39095 : H12AffineFastState.Bounded env39095 := by
  intro p hp
  have h : env39095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39094_39095 : H12AffineEnvironment.transform 8 1 env39094 = env39095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39094 == env39095) = true)

theorem identity39095 : scanCanonicalize (H12AffineFastState.compose env39095 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39096 : List Nat := [2,4,8,1,11,0,9,15,1,14,0,0,2,0,0,8,0,1,14,1,0,10,0,3,3,1,0,0,0,1,5,11,15,10,0,0]

theorem envBound39096 : H12AffineFastState.Bounded env39096 := by
  intro p hp
  have h : env39096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39095_39096 : H12AffineEnvironment.transform 4 11 env39095 = env39096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39095 == env39096) = true)

def env39097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,16,98780,8328,65,4258941,5393,17665,32161,1501,4256861,256,21792,46213,74250]

theorem envBound39097 : H12AffineFastState.Bounded env39097 := by
  intro p hp
  have h : env39097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39066_39097 : H12AffineEnvironment.transform 20 4161 env39066 = env39097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39066 == env39097) = true)

theorem identity39097 : scanCanonicalize (H12AffineFastState.compose env39097 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound39097 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149860,1024,29908,4161,4194304,16,95497,8328,65,4196520,5393,17665,32161,1501,4194440,256,21792,16464,74250]

theorem envBound39098 : H12AffineFastState.Bounded env39098 := by
  intro p hp
  have h : env39098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39097_39098 : H12AffineEnvironment.transform 14 29909 env39097 = env39098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39097 == env39098) = true)

def env39099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138340,1024,8660,4161,4194304,16,73737,8328,65,4196520,5393,4097,10401,1501,4194440,256,32,5456,74250]

theorem envBound39099 : H12AffineFastState.Bounded env39099 := by
  intro p hp
  have h : env39099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39098_39099 : H12AffineEnvironment.transform 13 5376 env39098 = env39099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39098 == env39099) = true)

theorem identity39099 : scanCanonicalize (H12AffineFastState.compose env39099 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound39099 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,10400,1024,8660,4161,4194304,16,73737,8328,65,4196520,5393,4097,10401,1501,4194440,256,32,5456,74250]

theorem envBound39100 : H12AffineFastState.Bounded env39100 := by
  intro p hp
  have h : env39100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39099_39100 : H12AffineEnvironment.transform 16 13508 env39099 = env39100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env39099 == env39100) = true)

theorem identity39100 : scanCanonicalize (H12AffineFastState.compose env39100 (packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39100 : packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env39101 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,13460,10400,1024,8580,4113,4194304,16,73737,8328,17,4196520,5393,4097,10401,1421,4194440,256,32,5376,74250]

theorem envBound39101 : H12AffineFastState.Bounded env39101 := by
  intro p hp
  have h : env39101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39100_39101 : H12AffineEnvironment.transform 5 16 env39100 = env39101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39100 == env39101) = true)

theorem identity39101 : scanCanonicalize (H12AffineFastState.compose env39101 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound39101 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39102 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,262,13460,10400,1024,8580,4113,4194304,16,8463,8328,17,4196520,5393,4097,10401,1421,4194440,256,32,5376,8972]

theorem envBound39102 : H12AffineFastState.Bounded env39102 := by
  intro p hp
  have h : env39102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39101_39102 : H12AffineEnvironment.transform 15 262 env39101 = env39102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env39101 == env39102) = true)

theorem identity39102 : scanCanonicalize (H12AffineFastState.compose env39102 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39102 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39103 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,136,262,5529,2477,1024,137,4113,4194304,16,2,389,17,4196520,5393,4097,2476,1421,4194440,256,32,5376,513]

theorem envBound39103 : H12AffineFastState.Bounded env39103 := by
  intro p hp
  have h : env39103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39102_39103 : H12AffineEnvironment.transform 12 269 env39102 = env39103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39102 == env39103) = true)

theorem identity39103 : scanCanonicalize (H12AffineFastState.compose env39103 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound39103 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39104 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,136,262,5529,2477,1024,137,4113,169,16,2,389,17,2049,5393,4097,2476,1421,33,256,32,5376,513]

theorem envBound39104 : H12AffineFastState.Bounded env39104 := by
  intro p hp
  have h : env39104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39103_39104 : H12AffineEnvironment.transform 21 169 env39103 = env39104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env39103 == env39104) = true)

theorem identity39104 : scanCanonicalize (H12AffineFastState.compose env39104 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound39104 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env39105 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,269,4541,136,262,4388,2477,189,137,4113,169,16,2,389,17,2049,4524,4097,2476,304,33,256,32,4541,513]

theorem envBound39105 : H12AffineFastState.Bounded env39105 := by
  intro p hp
  have h : env39105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39104_39105 : H12AffineEnvironment.transform 9 189 env39104 = env39105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env39104 == env39105) = true)

theorem identity39105 : scanCanonicalize (H12AffineFastState.compose env39105 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound39105 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env39106 : List Nat := [2,4,8,16,32,16,128,173,512,189,2048,4096,160,4112,136,171,4233,2048,189,137,4113,169,16,2,40,17,2049,4097,4097,2049,157,33,173,32,4112,513]

theorem envBound39106 : H12AffineFastState.Bounded env39106 := by
  intro p hp
  have h : env39106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39105_39106 : H12AffineEnvironment.transform 7 173 env39105 = env39106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39105 == env39106) = true)

theorem identity39106 : scanCanonicalize (H12AffineFastState.compose env39106 (packedSelected [11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39106 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env39107 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4112,0,35,4097,2048,53,1,4113,33,16,2,40,17,2049,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound39107 : H12AffineFastState.Bounded env39107 := by
  intro p hp
  have h : env39107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39106_39107 : H12AffineEnvironment.transform 6 8 env39106 = env39107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39106 == env39107) = true)

theorem identity39107 : scanCanonicalize (H12AffineFastState.compose env39107 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound39107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39108 : List Nat := [2,4,8,16,32,16,8,37,4,53,2048,4096,40,4112,0,35,4097,2048,53,1,4113,33,16,2,40,17,2049,4097,4097,2049,21,33,37,32,4112,5]

theorem envBound39108 : H12AffineFastState.Bounded env39108 := by
  intro p hp
  have h : env39108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39107_39108 : H12AffineEnvironment.transform 8 4 env39107 = env39108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env39107 == env39108) = true)

theorem identity39108 : scanCanonicalize (H12AffineFastState.compose env39108 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 7) := by decide +kernel

theorem selectedBound39108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39109 : List Nat := [2,4,8,16,32,16,8,37,4,53,2048,7,40,23,0,35,6,2048,53,1,22,33,16,2,40,17,2049,6,6,2049,21,33,37,32,23,5]

theorem envBound39109 : H12AffineFastState.Bounded env39109 := by
  intro p hp
  have h : env39109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39108_39109 : H12AffineEnvironment.transform 11 7 env39108 = env39109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 7 env39108 == env39109) = true)

def env39110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138341,1024,8661,4161,4194304,16,73736,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5457,74250]

theorem envBound39110 : H12AffineFastState.Bounded env39110 := by
  intro p hp
  have h : env39110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39098_39110 : H12AffineEnvironment.transform 13 5377 env39098 = env39110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39098 == env39110) = true)

theorem identity39110 : scanCanonicalize (H12AffineFastState.compose env39110 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound39110 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10280,1024,8661,4161,4194304,16,73736,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5457,74250]

theorem envBound39111 : H12AffineFastState.Bounded env39111 := by
  intro p hp
  have h : env39111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39110_39111 : H12AffineEnvironment.transform 16 13389 env39110 = env39111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env39110 == env39111) = true)

theorem identity39111 : scanCanonicalize (H12AffineFastState.compose env39111 (packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound39111 : packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env39112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,65536,5528,2557,1024,0,4161,4194304,16,66013,349,65,4196520,5393,4096,2421,1501,4194440,256,33,5457,66527]

theorem envBound39112 : H12AffineFastState.Bounded env39112 := by
  intro p hp
  have h : env39112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39111_39112 : H12AffineEnvironment.transform 12 469 env39111 = env39112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env39111 == env39112) = true)

theorem identity39112 : scanCanonicalize (H12AffineFastState.compose env39112 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound39112 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env39113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,478,5528,2557,1024,0,4161,4194304,16,3,349,65,4196520,5393,4096,2421,1501,4194440,256,33,5457,513]

theorem envBound39113 : H12AffineFastState.Bounded env39113 := by
  intro p hp
  have h : env39113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39112_39113 : H12AffineEnvironment.transform 15 478 env39112 = env39113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env39112 == env39113) = true)

theorem identity39113 : scanCanonicalize (H12AffineFastState.compose env39113 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound39113 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,478,5528,2557,1024,0,4161,113,16,3,349,65,2265,5393,4096,2421,1501,249,256,33,5457,513]

theorem envBound39114 : H12AffineFastState.Bounded env39114 := by
  intro p hp
  have h : env39114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39113_39114 : H12AffineEnvironment.transform 21 113 env39113 = env39114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env39113 == env39114) = true)

theorem identity39114 : scanCanonicalize (H12AffineFastState.compose env39114 (packedSelected [0,4,7,9,11,14,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39114 : packedSelected [0,4,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env39115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1024,0,4161,113,16,3,349,65,2129,5393,4096,2421,1365,113,256,33,5457,513]

theorem envBound39115 : H12AffineFastState.Bounded env39115 := by
  intro p hp
  have h : env39115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39114_39115 : H12AffineEnvironment.transform 6 8 env39114 = env39115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39114 == env39115) = true)

def env39116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound39116 : H12AffineFastState.Bounded env39116 := by
  intro p hp
  have h : env39116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38908_39116 : H12AffineEnvironment.transform 18 1025 env38908 = env39116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env38908 == env39116) = true)

theorem identity39116 : scanCanonicalize (H12AffineFastState.compose env39116 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444640) := by decide +kernel

theorem selectedBound39116 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444640,8328,65,14847329,313837,10507600,8830977,10799473,4466848,257,8686028,8677480,10874535]

theorem envBound39117 : H12AffineFastState.Bounded env39117 := by
  intro p hp
  have h : env39117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39116_39117 : H12AffineEnvironment.transform 23 2444640 env39116 = env39117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444640 env39116 == env39117) = true)

def env39118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318700,2444640,8328,65,6705549,313837,2394556,138477,2102685,4466848,257,21792,46212,2175563]

theorem envBound39118 : H12AffineFastState.Bounded env39118 := by
  intro p hp
  have h : env39118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39117_39118 : H12AffineEnvironment.transform 22 318700 env39117 = env39118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318700 env39117 == env39118) = true)

def env39119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318700,466224,8328,65,4456925,313837,449004,138477,148941,4466848,257,21792,46212,221723]

theorem envBound39119 : H12AffineFastState.Bounded env39119 := by
  intro p hp
  have h : env39119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39118_39119 : H12AffineEnvironment.transform 20 151632 env39118 = env39119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env39118 == env39119) = true)

theorem identity39119 : scanCanonicalize (H12AffineFastState.compose env39119 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39119 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env39120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318565,466224,8193,65,4456788,313700,448869,138340,148804,4466729,257,21792,46093,221723]

theorem envBound39120 : H12AffineFastState.Bounded env39120 := by
  intro p hp
  have h : env39120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39119_39120 : H12AffineEnvironment.transform 6 9 env39119 = env39120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39119 == env39120) = true)

def env39121 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,262144,273,32769,151632,4194304,317813,464928,8193,65,4456788,313700,448869,137588,147540,4466729,257,20528,45341,221723]

theorem envBound39121 : H12AffineFastState.Bounded env39121 := by
  intro p hp
  have h : env39121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39120_39121 : H12AffineEnvironment.transform 9 272 env39120 = env39121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39120 == env39121) = true)

theorem identity39121 : scanCanonicalize (H12AffineFastState.compose env39121 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 63544) := by decide +kernel

theorem selectedBound39121 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env39122 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63544,273,32769,151632,4194304,8525,253976,8193,65,4258156,12636,139613,137588,147540,4247569,257,20528,45341,221723]

theorem envBound39122 : H12AffineFastState.Bounded env39122 := by
  intro p hp
  have h : env39122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39121_39122 : H12AffineEnvironment.transform 17 63544 env39121 = env39122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63544 env39121 == env39122) = true)

def env39123 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63544,273,32769,151552,4194304,8477,253976,8193,17,4258108,12556,139533,137508,147460,4247569,257,20528,45341,221723]

theorem envBound39123 : H12AffineFastState.Bounded env39123 := by
  intro p hp
  have h : env39123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39122_39123 : H12AffineEnvironment.transform 5 16 env39122 = env39123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39122 == env39123) = true)

theorem identity39123 : scanCanonicalize (H12AffineFastState.compose env39123 (packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS)) = affineNative (2^(21+1) ^^^ 241706) := by decide +kernel

theorem selectedBound39123 : packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env39124 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63544,273,32769,151552,241706,8477,253976,8193,17,215318,12556,139533,137508,147460,221243,257,20528,45341,221723]

theorem envBound39124 : H12AffineFastState.Bounded env39124 := by
  intro p hp
  have h : env39124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39123_39124 : H12AffineEnvironment.transform 21 241706 env39123 = env39124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 241706 env39123 == env39124) = true)

theorem identity39124 : scanCanonicalize (H12AffineFastState.compose env39124 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,14,15,16,17,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound39124 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,14,15,16,17,20,24] rootPS < 2^1333 := by decide +kernel

def env39125 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,32768,65536,82198,63544,273,32769,69910,61756,8477,41230,8193,17,2048,12556,90139,88114,65810,8493,257,20528,45341,8973]

theorem envBound39125 : H12AffineFastState.Bounded env39125 := by
  intro p hp
  have h : env39125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39124_39125 : H12AffineEnvironment.transform 16 82198 env39124 = env39125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env39124 == env39125) = true)

theorem identity39125 : scanCanonicalize (H12AffineFastState.compose env39125 (packedSelected [2,3,4,5,6,10,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39125 : packedSelected [2,3,4,5,6,10,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env39126 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,1,65536,82198,30777,273,0,69910,28989,8477,8463,8193,17,2048,12556,90139,88114,65810,8493,257,20528,12572,8973]

theorem envBound39126 : H12AffineFastState.Bounded env39126 := by
  intro p hp
  have h : env39126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39125_39126 : H12AffineEnvironment.transform 14 1 env39125 = env39126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39125 == env39126) = true)

theorem identity39126 : scanCanonicalize (H12AffineFastState.compose env39126 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39126 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env39127 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,16384,1,8202,24860,30777,273,0,12572,28989,8477,8463,8193,17,2048,12556,16401,30776,8472,8493,257,20528,12572,8973]

theorem envBound39127 : H12AffineFastState.Bounded env39127 := by
  intro p hp
  have h : env39127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39126_39127 : H12AffineEnvironment.transform 15 8202 env39126 = env39127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39126 == env39127) = true)

theorem identity39127 : scanCanonicalize (H12AffineFastState.compose env39127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39128 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,16384,1,262,16400,22837,273,0,4112,20529,17,3,269,17,2048,4096,16401,22836,20,33,257,20528,4112,513]

theorem envBound39128 : H12AffineFastState.Bounded env39128 := by
  intro p hp
  have h : env39128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39127_39128 : H12AffineEnvironment.transform 12 268 env39127 = env39128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39127 == env39128) = true)

theorem identity39128 : scanCanonicalize (H12AffineFastState.compose env39128 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 49) := by decide +kernel

theorem selectedBound39128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39129 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,49,1,262,33,6404,273,0,4112,4096,17,3,269,17,2048,4096,32,6405,20,33,257,4097,4112,513]

theorem envBound39129 : H12AffineFastState.Bounded env39129 := by
  intro p hp
  have h : env39129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39128_39129 : H12AffineEnvironment.transform 13 49 env39128 = env39129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env39128 == env39129) = true)

theorem identity39129 : scanCanonicalize (H12AffineFastState.compose env39129 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound39129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39130 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,33,268,49,1,262,33,2341,273,0,49,33,17,3,269,17,2048,33,32,2340,20,33,257,32,49,513]

theorem envBound39130 : H12AffineFastState.Bounded env39130 := by
  intro p hp
  have h : env39130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39129_39130 : H12AffineEnvironment.transform 11 33 env39129 = env39130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env39129 == env39130) = true)

theorem identity39130 : scanCanonicalize (H12AffineFastState.compose env39130 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound39130 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39131 : List Nat := [2,4,8,16,32,16,9,256,512,272,286,33,268,49,1,262,33,59,273,0,49,33,17,3,269,17,286,33,32,58,20,33,257,32,49,513]

theorem envBound39131 : H12AffineFastState.Bounded env39131 := by
  intro p hp
  have h : env39131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39130_39131 : H12AffineEnvironment.transform 10 286 env39130 = env39131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env39130 == env39131) = true)

theorem identity39131 : scanCanonicalize (H12AffineFastState.compose env39131 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound39131 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39132 : List Nat := [2,4,8,16,32,16,9,256,270,272,286,33,268,49,1,262,33,59,273,0,49,33,17,3,269,17,286,33,32,58,20,33,257,32,49,271]

theorem envBound39132 : H12AffineFastState.Bounded env39132 := by
  intro p hp
  have h : env39132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39131_39132 : H12AffineEnvironment.transform 8 270 env39131 = env39132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env39131 == env39132) = true)

theorem identity39132 : scanCanonicalize (H12AffineFastState.compose env39132 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39132 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39133 : List Nat := [2,4,8,12,32,12,9,256,270,268,258,33,268,45,1,262,33,39,269,0,45,33,13,3,269,13,258,33,32,38,8,33,257,32,45,271]

theorem envBound39133 : H12AffineFastState.Bounded env39133 := by
  intro p hp
  have h : env39133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39132_39133 : H12AffineEnvironment.transform 3 12 env39132 = env39133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39132 == env39133) = true)

theorem identity39133 : scanCanonicalize (H12AffineFastState.compose env39133 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound39133 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env39134 : List Nat := [2,4,8,12,32,12,9,3,13,15,1,33,15,45,1,5,33,39,14,0,45,33,13,3,14,13,1,33,32,38,8,33,2,32,45,12]

theorem envBound39134 : H12AffineFastState.Bounded env39134 := by
  intro p hp
  have h : env39134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39133_39134 : H12AffineEnvironment.transform 7 3 env39133 = env39134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env39133 == env39134) = true)

theorem identity39134 : scanCanonicalize (H12AffineFastState.compose env39134 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39134 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39135 : List Nat := [2,2,8,10,32,10,9,3,11,9,1,33,9,43,1,3,33,33,8,0,43,33,11,3,8,11,1,33,32,32,8,33,2,32,43,10]

theorem envBound39135 : H12AffineFastState.Bounded env39135 := by
  intro p hp
  have h : env39135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39134_39135 : H12AffineEnvironment.transform 1 2 env39134 = env39135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39134 == env39135) = true)

theorem identity39135 : scanCanonicalize (H12AffineFastState.compose env39135 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39135 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env39136 : List Nat := [2,2,8,10,10,10,9,3,11,9,1,11,9,1,1,3,11,11,8,0,1,11,11,3,8,11,1,11,10,10,8,11,2,10,1,10]

theorem envBound39136 : H12AffineFastState.Bounded env39136 := by
  intro p hp
  have h : env39136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39135_39136 : H12AffineEnvironment.transform 4 10 env39135 = env39136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39135 == env39136) = true)

theorem identity39136 : scanCanonicalize (H12AffineFastState.compose env39136 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39137 : List Nat := [1,1,8,9,9,9,9,0,8,9,1,8,9,1,1,0,8,8,8,0,1,8,8,0,8,8,1,8,9,9,8,8,1,9,1,9]

theorem envBound39137 : H12AffineFastState.Bounded env39137 := by
  intro p hp
  have h : env39137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39136_39137 : H12AffineEnvironment.transform 0 1 env39136 = env39137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39136 == env39137) = true)

def env39138 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,65536,131072,63544,273,32769,151553,4194304,8476,253976,8193,16,4258109,12557,139532,137509,147461,4247569,257,20528,45341,221723]

theorem envBound39138 : H12AffineFastState.Bounded env39138 := by
  intro p hp
  have h : env39138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39122_39138 : H12AffineEnvironment.transform 5 17 env39122 = env39138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39122 == env39138) = true)

theorem identity39138 : scanCanonicalize (H12AffineFastState.compose env39138 (packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound39138 : packedSelected [0,3,4,10,11,12,14,15,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env39139 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,65536,4096,63544,273,32769,16385,4194304,8476,127000,8193,16,4258109,12557,12556,2341,20485,4247569,257,20528,45341,94747]

theorem envBound39139 : H12AffineFastState.Bounded env39139 := by
  intro p hp
  have h : env39139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39138_39139 : H12AffineEnvironment.transform 16 4096 env39138 = env39139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env39138 == env39139) = true)

theorem identity39139 : scanCanonicalize (H12AffineFastState.compose env39139 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound39139 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env39140 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,16384,32768,28698,4096,63544,273,32769,16385,4194304,8476,32770,8193,16,4258109,12557,12556,2341,20485,4247569,257,20528,45341,513]

theorem envBound39140 : H12AffineFastState.Bounded env39140 := by
  intro p hp
  have h : env39140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39139_39140 : H12AffineEnvironment.transform 15 28698 env39139 = env39140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env39139 == env39140) = true)

theorem identity39140 : scanCanonicalize (H12AffineFastState.compose env39140 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39140 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39141 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,32768,20759,4096,55605,273,32769,16385,4194304,17,32770,268,16,4249648,4096,4097,2341,20485,4247569,257,20528,36880,513]

theorem envBound39141 : H12AffineFastState.Bounded env39141 := by
  intro p hp
  have h : env39141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39140_39141 : H12AffineEnvironment.transform 12 269 env39140 = env39141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39140 == env39141) = true)

theorem identity39141 : scanCanonicalize (H12AffineFastState.compose env39141 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound39141 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39142 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,32768,20759,4096,55605,273,32769,16385,32,17,32770,268,16,55312,4096,4097,2341,20485,53297,257,20528,36880,513]

theorem envBound39142 : H12AffineFastState.Bounded env39142 := by
  intro p hp
  have h : env39142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39141_39142 : H12AffineEnvironment.transform 21 32 env39141 = env39142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39141 == env39142) = true)

def env39143 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,32768,65536,131072,262144,272,32769,151632,4194304,317812,464929,8193,65,4456788,313700,448869,137589,147541,4466729,257,20529,45340,221723]

theorem envBound39143 : H12AffineFastState.Bounded env39143 := by
  intro p hp
  have h : env39143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39120_39143 : H12AffineEnvironment.transform 9 273 env39120 = env39143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39120 == env39143) = true)

theorem identity39143 : scanCanonicalize (H12AffineFastState.compose env39143 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound39143 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env39144 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,20497,65536,131072,262144,272,20496,151632,4194304,264549,464929,8193,65,4456788,268661,395636,137589,147541,4466729,257,20529,24845,221723]

theorem envBound39144 : H12AffineFastState.Bounded env39144 := by
  intro p hp
  have h : env39144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39143_39144 : H12AffineEnvironment.transform 14 20497 env39143 = env39144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env39143 == env39144) = true)

def env39145 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20497,65536,131072,262144,272,20496,151552,4194304,264501,464929,8193,17,4456708,268581,395556,137509,147461,4466729,257,20529,24845,221723]

theorem envBound39145 : H12AffineFastState.Bounded env39145 := by
  intro p hp
  have h : env39145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39144_39145 : H12AffineEnvironment.transform 5 16 env39144 = env39145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39144 == env39145) = true)

theorem identity39145 : scanCanonicalize (H12AffineFastState.compose env39145 (packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 477202) := by decide +kernel

theorem selectedBound39145 : packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39146 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20497,65536,131072,262144,272,20496,151552,477202,264501,464929,8193,17,215318,268581,395556,137509,147461,221243,257,20529,24845,221723]

theorem envBound39146 : H12AffineFastState.Bounded env39146 := by
  intro p hp
  have h : env39146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39145_39146 : H12AffineEnvironment.transform 21 477202 env39145 = env39146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477202 env39145 == env39146) = true)

theorem identity39146 : scanCanonicalize (H12AffineFastState.compose env39146 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,17,18,22,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound39146 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,17,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env39147 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20497,65536,131072,30776,272,20496,151552,208938,28941,221209,8193,17,215318,24861,160028,137509,147461,221243,257,20529,24845,221723]

theorem envBound39147 : H12AffineFastState.Bounded env39147 := by
  intro p hp
  have h : env39147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39146_39147 : H12AffineEnvironment.transform 17 30776 env39146 = env39147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env39146 == env39147) = true)

theorem identity39147 : scanCanonicalize (H12AffineFastState.compose env39147 (packedSelected [0,2,4,6,7,9,12,14,15,16,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound39147 : packedSelected [0,2,4,6,7,9,12,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env39148 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,16384,20497,262,131072,30776,272,20496,151552,143660,28941,155935,8193,17,149520,24861,160028,137509,147461,155965,257,20529,24845,156445]

theorem envBound39148 : H12AffineFastState.Bounded env39148 := by
  intro p hp
  have h : env39148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39147_39148 : H12AffineEnvironment.transform 15 262 env39147 = env39148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env39147 == env39148) = true)

theorem identity39148 : scanCanonicalize (H12AffineFastState.compose env39148 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound39148 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39149 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,4112,1,262,131072,10280,272,0,131088,143660,8477,143631,8193,17,137216,12557,139532,137509,135189,143661,257,33,12573,144141]

theorem envBound39149 : H12AffineFastState.Bounded env39149 := by
  intro p hp
  have h : env39149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39148_39149 : H12AffineEnvironment.transform 13 4112 env39148 = env39149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env39148 == env39149) = true)

theorem identity39149 : scanCanonicalize (H12AffineFastState.compose env39149 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 10297) := by decide +kernel

theorem selectedBound39149 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env39150 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,8192,4112,1,262,10297,10280,272,0,10281,6421,8477,6454,8193,17,12345,12557,2357,12572,14380,6420,257,33,12573,6964]

theorem envBound39150 : H12AffineFastState.Bounded env39150 := by
  intro p hp
  have h : env39150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39149_39150 : H12AffineEnvironment.transform 16 10297 env39149 = env39150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10297 env39149 == env39150) = true)

theorem identity39150 : scanCanonicalize (H12AffineFastState.compose env39150 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39150 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39151 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,4096,8192,4112,1,262,8249,8232,272,0,8233,4373,8477,4406,8193,17,12345,12557,309,12572,12332,4372,257,33,12573,4916]

theorem envBound39151 : H12AffineFastState.Bounded env39151 := by
  intro p hp
  have h : env39151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39150_39151 : H12AffineEnvironment.transform 10 0 env39150 = env39151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39150 == env39151) = true)

theorem identity39151 : scanCanonicalize (H12AffineFastState.compose env39151 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 4374) := by decide +kernel

theorem selectedBound39151 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env39152 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,4096,4374,4112,1,262,4399,4414,272,0,4415,4373,4107,4406,4375,17,303,27,309,10,314,4372,257,33,11,4916]

theorem envBound39152 : H12AffineFastState.Bounded env39152 := by
  intro p hp
  have h : env39152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39151_39152 : H12AffineEnvironment.transform 12 4374 env39151 = env39152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4374 env39151 == env39152) = true)

theorem identity39152 : scanCanonicalize (H12AffineFastState.compose env39152 (packedSelected [1,3,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound39152 : packedSelected [1,3,11,12] rootPS < 2^1333 := by decide +kernel

def env39153 : List Nat := [2,4,8,16,32,16,9,47,512,62,0,4096,4153,4112,1,41,4096,4113,63,0,4112,4154,4107,4121,4152,17,0,27,26,10,21,4155,46,33,11,4635]

theorem envBound39153 : H12AffineFastState.Bounded env39153 := by
  intro p hp
  have h : env39153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39152_39153 : H12AffineEnvironment.transform 7 47 env39152 = env39153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env39152 == env39153) = true)

theorem identity39153 : scanCanonicalize (H12AffineFastState.compose env39153 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound39153 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39154 : List Nat := [2,4,8,16,32,16,9,47,512,62,0,560,521,544,1,41,560,545,63,0,544,522,571,553,520,17,0,27,26,10,21,523,46,33,11,43]

theorem envBound39154 : H12AffineFastState.Bounded env39154 := by
  intro p hp
  have h : env39154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39153_39154 : H12AffineEnvironment.transform 11 560 env39153 = env39154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env39153 == env39154) = true)

theorem identity39154 : scanCanonicalize (H12AffineFastState.compose env39154 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound39154 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env39155 : List Nat := [2,4,8,16,32,16,9,47,32,62,0,16,41,0,1,41,16,1,63,0,0,42,27,9,40,17,0,27,26,10,21,43,46,33,11,43]

theorem envBound39155 : H12AffineFastState.Bounded env39155 := by
  intro p hp
  have h : env39155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39154_39155 : H12AffineEnvironment.transform 8 32 env39154 = env39155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env39154 == env39155) = true)

theorem identity39155 : scanCanonicalize (H12AffineFastState.compose env39155 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound39155 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39156 : List Nat := [2,4,8,14,32,14,9,47,32,32,0,14,41,0,1,41,14,1,33,0,0,42,5,9,40,15,0,5,4,10,11,43,46,33,11,43]

theorem envBound39156 : H12AffineFastState.Bounded env39156 := by
  intro p hp
  have h : env39156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39155_39156 : H12AffineEnvironment.transform 3 14 env39155 = env39156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env39155 == env39156) = true)

theorem identity39156 : scanCanonicalize (H12AffineFastState.compose env39156 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound39156 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env39157 : List Nat := [2,4,8,14,14,14,9,1,14,14,0,14,7,0,1,7,14,1,15,0,0,4,5,9,6,15,0,5,4,10,11,5,0,15,11,5]

theorem envBound39157 : H12AffineFastState.Bounded env39157 := by
  intro p hp
  have h : env39157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39156_39157 : H12AffineEnvironment.transform 4 14 env39156 = env39157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env39156 == env39157) = true)

theorem identity39157 : scanCanonicalize (H12AffineFastState.compose env39157 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39158 : List Nat := [2,4,4,2,2,2,5,1,2,2,0,2,7,0,1,7,2,1,3,0,0,4,5,5,6,3,0,5,4,6,7,5,0,3,7,5]

theorem envBound39158 : H12AffineFastState.Bounded env39158 := by
  intro p hp
  have h : env39158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39157_39158 : H12AffineEnvironment.transform 2 4 env39157 = env39158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39157 == env39158) = true)

theorem identity39158 : scanCanonicalize (H12AffineFastState.compose env39158 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39158 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39159 : List Nat := [2,1,1,2,2,2,0,1,2,2,0,2,2,0,1,2,2,1,3,0,0,1,0,0,3,3,0,0,1,3,2,0,0,3,2,0]

theorem envBound39159 : H12AffineFastState.Bounded env39159 := by
  intro p hp
  have h : env39159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39158_39159 : H12AffineEnvironment.transform 1 1 env39158 = env39159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39158 == env39159) = true)

theorem identity39159 : scanCanonicalize (H12AffineFastState.compose env39159 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39160 : List Nat := [0,1,1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,1,1,0,0,1,0,0,1,1,0,0,1,1,0,0,0,1,0,0]

theorem envBound39160 : H12AffineFastState.Bounded env39160 := by
  intro p hp
  have h : env39160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39159_39160 : H12AffineEnvironment.transform 0 0 env39159 = env39160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39159 == env39160) = true)

def env39161 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20497,65536,131072,262144,272,20496,151553,4194304,264500,464929,8193,16,4456709,268580,395557,137508,147460,4466729,257,20529,24845,221723]

theorem envBound39161 : H12AffineFastState.Bounded env39161 := by
  intro p hp
  have h : env39161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39144_39161 : H12AffineEnvironment.transform 5 17 env39144 = env39161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39144 == env39161) = true)

theorem identity39161 : scanCanonicalize (H12AffineFastState.compose env39161 (packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound39161 : packedSelected [0,3,4,8,10,12,14,15,16,18,21,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39162 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20497,65536,4097,262144,272,20496,16384,4194304,264500,329760,8193,16,4456709,268580,268580,2341,20485,4466729,257,20529,24845,94746]

theorem envBound39162 : H12AffineFastState.Bounded env39162 := by
  intro p hp
  have h : env39162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39161_39162 : H12AffineEnvironment.transform 16 4097 env39161 = env39162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env39161 == env39162) = true)

theorem identity39162 : scanCanonicalize (H12AffineFastState.compose env39162 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound39162 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env39163 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,16384,20497,28699,4097,262144,272,20496,16384,4194304,264500,292923,8193,16,4456709,268580,268580,2341,20485,4466729,257,20529,24845,513]

theorem envBound39163 : H12AffineFastState.Bounded env39163 := by
  intro p hp
  have h : env39163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39162_39163 : H12AffineEnvironment.transform 15 28699 env39162 = env39163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env39162 == env39163) = true)

theorem identity39163 : scanCanonicalize (H12AffineFastState.compose env39163 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound39163 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39164 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8461,263,4097,262144,272,8460,12572,4194304,264500,264487,8193,16,4456709,268580,268580,2341,8473,4466729,257,8493,4113,513]

theorem envBound39164 : H12AffineFastState.Bounded env39164 := by
  intro p hp
  have h : env39164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39163_39164 : H12AffineEnvironment.transform 13 12572 env39163 = env39164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env39163 == env39164) = true)

theorem identity39164 : scanCanonicalize (H12AffineFastState.compose env39164 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound39164 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39165 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12572,8461,263,4097,262144,272,8460,12572,8493,264500,264487,8193,16,270376,268580,268580,2341,8473,264452,257,8493,4113,513]

theorem envBound39165 : H12AffineFastState.Bounded env39165 := by
  intro p hp
  have h : env39165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39164_39165 : H12AffineEnvironment.transform 21 8493 env39164 = env39165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env39164 == env39165) = true)

theorem identity39165 : scanCanonicalize (H12AffineFastState.compose env39165 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39165 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39166 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,0,263,4097,262144,272,1,4113,32,264500,264487,268,16,262437,268580,268580,2341,20,264452,257,32,4113,513]

theorem envBound39166 : H12AffineFastState.Bounded env39166 := by
  intro p hp
  have h : env39166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39165_39166 : H12AffineEnvironment.transform 12 269 env39165 = env39166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39165 == env39166) = true)

def env39167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318700,466225,8328,65,4456924,313837,449005,138477,148940,4466848,257,21792,46212,221722]

theorem envBound39167 : H12AffineFastState.Bounded env39167 := by
  intro p hp
  have h : env39167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39118_39167 : H12AffineEnvironment.transform 20 151633 env39118 = env39167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env39118 == env39167) = true)

def env39168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,147640,318700,466225,8328,65,409956,313837,449005,138477,148940,419864,257,21792,46212,221722]

theorem envBound39168 : H12AffineFastState.Bounded env39168 := by
  intro p hp
  have h : env39168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39167_39168 : H12AffineEnvironment.transform 21 147640 env39167 = env39168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147640 env39167 == env39168) = true)

def env39169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4161,168,318700,351521,8328,65,262516,313837,301565,23805,1500,272392,257,21792,46212,74250]

theorem envBound39169 : H12AffineFastState.Bounded env39169 := by
  intro p hp
  have h : env39169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39168_39169 : H12AffineEnvironment.transform 16 16400 env39168 = env39169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39168 == env39169) = true)

theorem identity39169 : scanCanonicalize (H12AffineFastState.compose env39169 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound39169 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16400,262144,1025,32769,4161,168,318700,297471,8328,65,262516,313837,301565,23805,1500,272392,257,21792,46212,63188]

theorem envBound39170 : H12AffineFastState.Bounded env39170 := by
  intro p hp
  have h : env39170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39169_39170 : H12AffineEnvironment.transform 15 54494 env39169 = env39170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env39169 == env39170) = true)

theorem identity39170 : scanCanonicalize (H12AffineFastState.compose env39170 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound39170 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env39171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16400,262144,1025,29908,4161,168,272441,294186,8328,65,262516,277816,290088,23805,1500,272392,257,21792,16465,513]

theorem envBound39171 : H12AffineFastState.Bounded env39171 := by
  intro p hp
  have h : env39171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39170_39171 : H12AffineEnvironment.transform 14 29909 env39170 = env39171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39170 == env39171) = true)

theorem identity39171 : scanCanonicalize (H12AffineFastState.compose env39171 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound39171 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env39172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16400,32040,1025,29908,4161,168,21777,2,8328,65,31836,16400,4096,23805,1500,21792,257,21792,16465,513]

theorem envBound39172 : H12AffineFastState.Bounded env39172 := by
  intro p hp
  have h : env39172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39171_39172 : H12AffineEnvironment.transform 17 32040 env39171 = env39172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env39171 == env39172) = true)

theorem identity39172 : scanCanonicalize (H12AffineFastState.compose env39172 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39172 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,5392,10280,1025,8660,4161,168,17,2,8328,65,10588,5392,4096,2557,1500,32,257,32,5457,513]

theorem envBound39173 : H12AffineFastState.Bounded env39173 := by
  intro p hp
  have h : env39173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39172_39173 : H12AffineEnvironment.transform 13 5376 env39172 = env39173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39172 == env39173) = true)

theorem identity39173 : scanCanonicalize (H12AffineFastState.compose env39173 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound39173 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,129,5376,340,138,5392,2217,1025,341,4161,168,17,2,9,65,2525,5392,4096,2557,1500,32,257,32,5457,513]

theorem envBound39174 : H12AffineFastState.Bounded env39174 := by
  intro p hp
  have h : env39174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39173_39174 : H12AffineEnvironment.transform 12 129 env39173 = env39174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env39173 == env39174) = true)

theorem identity39174 : scanCanonicalize (H12AffineFastState.compose env39174 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound39174 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env39175 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,129,5340,136,138,5324,2217,1025,137,4161,168,17,2,9,65,2049,5324,4096,2081,1024,32,221,32,5261,513]

theorem envBound39175 : H12AffineFastState.Bounded env39175 := by
  intro p hp
  have h : env39175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39174_39175 : H12AffineEnvironment.transform 7 220 env39174 = env39175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env39174 == env39175) = true)

def env39176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4160,169,318700,351520,8328,65,262517,313837,301564,23804,1501,272393,257,21792,46212,74251]

theorem envBound39176 : H12AffineFastState.Bounded env39176 := by
  intro p hp
  have h : env39176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39168_39176 : H12AffineEnvironment.transform 16 16401 env39168 = env39176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39168 == env39176) = true)

theorem identity39176 : scanCanonicalize (H12AffineFastState.compose env39176 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 130295) := by decide +kernel

theorem selectedBound39176 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130295,1025,32769,4160,169,73755,41431,8328,65,130434,79130,91403,23804,1501,120062,257,21792,46212,74251]

theorem envBound39177 : H12AffineFastState.Bounded env39177 := by
  intro p hp
  have h : env39177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39176_39177 : H12AffineEnvironment.transform 17 130295 env39176 = env39177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130295 env39176 == env39177) = true)

def env39178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130175,1025,32769,4160,33,73755,41311,8192,65,130314,79130,91403,23668,1365,119926,257,21792,46092,74251]

theorem envBound39178 : H12AffineFastState.Bounded env39178 := by
  intro p hp
  have h : env39178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39177_39178 : H12AffineEnvironment.transform 6 8 env39177 = env39178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39177 == env39178) = true)

theorem identity39178 : scanCanonicalize (H12AffineFastState.compose env39178 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39178 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16401,32040,1025,32769,4160,33,41292,41311,8192,65,31837,46157,58460,23668,1365,21793,257,21792,46092,41820]

theorem envBound39179 : H12AffineFastState.Bounded env39179 := by
  intro p hp
  have h : env39179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39178_39179 : H12AffineEnvironment.transform 15 33111 env39178 = env39179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39178 == env39179) = true)

theorem identity39179 : scanCanonicalize (H12AffineFastState.compose env39179 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound39179 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env39180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,33111,13673,2128,1025,32769,4160,33,41292,41311,8192,65,2341,46157,37156,10508,1365,8281,257,8280,46092,41820]

theorem envBound39180 : H12AffineFastState.Bounded env39180 := by
  intro p hp
  have h : env39180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39179_39180 : H12AffineEnvironment.transform 13 13688 env39179 = env39180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env39179 == env39180) = true)

theorem identity39180 : scanCanonicalize (H12AffineFastState.compose env39180 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound39180 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,292,115,13673,2128,1025,293,4160,33,8296,8315,8192,65,2341,13673,4096,10508,1365,8281,257,8280,13608,8824]

theorem envBound39181 : H12AffineFastState.Bounded env39181 := by
  intro p hp
  have h : env39181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39180_39181 : H12AffineEnvironment.transform 14 292 env39180 = env39181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env39180 == env39181) = true)

theorem identity39181 : scanCanonicalize (H12AffineFastState.compose env39181 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39181 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,292,115,5393,2128,1025,293,4160,33,16,3,120,65,2341,5393,4096,2420,1365,33,257,32,5456,512]

theorem envBound39182 : H12AffineFastState.Bounded env39182 := by
  intro p hp
  have h : env39182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39181_39182 : H12AffineEnvironment.transform 12 120 env39181 = env39182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39181 == env39182) = true)

theorem identity39182 : scanCanonicalize (H12AffineFastState.compose env39182 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound39182 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39183 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5205,113,115,5188,2128,1025,112,4160,33,16,3,120,65,2160,5188,4096,2081,1024,33,84,32,5125,512]

theorem envBound39183 : H12AffineFastState.Bounded env39183 := by
  intro p hp
  have h : env39183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39182_39183 : H12AffineEnvironment.transform 7 85 env39182 = env39183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env39182 == env39183) = true)

theorem identity39183 : scanCanonicalize (H12AffineFastState.compose env39183 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39183 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39184 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,89,5205,80,82,5188,2128,1025,81,4160,0,16,3,89,65,2129,5188,4096,2048,1024,0,84,1,5125,512]

theorem envBound39184 : H12AffineFastState.Bounded env39184 := by
  intro p hp
  have h : env39184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39183_39184 : H12AffineEnvironment.transform 4 1 env39183 = env39184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39183 == env39184) = true)

theorem identity39184 : scanCanonicalize (H12AffineFastState.compose env39184 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound39184 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39185 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,89,5205,80,82,5188,1,1025,81,4160,0,16,3,89,65,0,5188,4096,81,1024,0,84,1,5125,512]

theorem envBound39185 : H12AffineFastState.Bounded env39185 := by
  intro p hp
  have h : env39185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39184_39185 : H12AffineEnvironment.transform 10 81 env39184 = env39185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env39184 == env39185) = true)

def env39186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,130174,1025,32769,4160,32,73755,41310,8193,65,130315,79130,91403,23669,1364,119927,257,21792,46093,74251]

theorem envBound39186 : H12AffineFastState.Bounded env39186 := by
  intro p hp
  have h : env39186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39177_39186 : H12AffineEnvironment.transform 6 9 env39177 = env39186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39177 == env39186) = true)

theorem identity39186 : scanCanonicalize (H12AffineFastState.compose env39186 (packedSelected [3,4,5,9,10,12,14,16,17,38] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39186 : packedSelected [3,4,5,9,10,12,14,16,17,38] rootPS < 2^1333 := by decide +kernel

def env39187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108926,1025,32769,4160,32,73755,41310,8193,65,108555,79130,77835,2421,1364,98679,257,32,46093,74251]

theorem envBound39187 : H12AffineFastState.Bounded env39187 := by
  intro p hp
  have h : env39187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39186_39187 : H12AffineEnvironment.transform 13 5376 env39186 = env39187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39186 == env39187) = true)

theorem identity39187 : scanCanonicalize (H12AffineFastState.compose env39187 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39187 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,5393,76158,1025,1,4160,32,73755,8542,8193,65,75787,79130,77835,2421,1364,65911,257,32,13325,74251]

theorem envBound39188 : H12AffineFastState.Bounded env39188 := by
  intro p hp
  have h : env39188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39187_39188 : H12AffineEnvironment.transform 14 0 env39187 = env39188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39187 == env39188) = true)

theorem identity39188 : scanCanonicalize (H12AffineFastState.compose env39188 (packedSelected [1,2,3,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound39188 : packedSelected [1,2,3,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env39189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,5376,0,65536,5393,68679,1025,1,4160,32,66850,1127,1336,65,68914,69667,70962,2421,1364,65911,257,32,4404,67378]

theorem envBound39189 : H12AffineFastState.Bounded env39189 := by
  intro p hp
  have h : env39189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39188_39189 : H12AffineEnvironment.transform 12 1337 env39188 = env39189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env39188 == env39189) = true)

theorem identity39189 : scanCanonicalize (H12AffineFastState.compose env39189 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39189 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39190 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,5376,0,65536,5393,68630,1025,1,4113,32,66850,1078,1336,16,68914,69667,70962,2340,1285,65830,257,32,4404,67378]

theorem envBound39190 : H12AffineFastState.Bounded env39190 := by
  intro p hp
  have h : env39190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39189_39190 : H12AffineEnvironment.transform 5 17 env39189 = env39190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39189 == env39190) = true)

theorem identity39190 : scanCanonicalize (H12AffineFastState.compose env39190 (packedSelected [1,2,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39190 : packedSelected [1,2,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39191 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,5376,0,263,5393,3345,1025,1,4113,32,1061,1078,1336,16,3125,4388,5173,2340,1285,33,257,32,4404,1589]

theorem envBound39191 : H12AffineFastState.Bounded env39191 := by
  intro p hp
  have h : env39191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39190_39191 : H12AffineEnvironment.transform 15 263 env39190 = env39191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39190 == env39191) = true)

theorem identity39191 : scanCanonicalize (H12AffineFastState.compose env39191 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39191 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env39192 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4112,0,263,4097,2049,273,1,4113,32,309,294,40,16,2341,4388,4389,2340,21,33,257,32,4404,805]

theorem envBound39192 : H12AffineFastState.Bounded env39192 := by
  intro p hp
  have h : env39192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39191_39192 : H12AffineEnvironment.transform 9 272 env39191 = env39192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39191 == env39192) = true)

theorem identity39192 : scanCanonicalize (H12AffineFastState.compose env39192 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39192 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env39193 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,0,35,4097,2049,53,1,4113,32,17,2,40,16,2049,4096,4097,2048,21,33,37,32,4112,513]

theorem envBound39193 : H12AffineFastState.Bounded env39193 := by
  intro p hp
  have h : env39193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39192_39193 : H12AffineEnvironment.transform 7 36 env39192 = env39193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39192 == env39193) = true)

theorem identity39193 : scanCanonicalize (H12AffineFastState.compose env39193 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound39193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39194 : List Nat := [2,4,8,16,32,17,9,36,512,52,512,4096,41,4112,0,35,4097,513,53,1,4113,32,17,2,40,16,513,4096,4097,512,21,33,37,32,4112,513]

theorem envBound39194 : H12AffineFastState.Bounded env39194 := by
  intro p hp
  have h : env39194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39193_39194 : H12AffineEnvironment.transform 10 512 env39193 = env39194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env39193 == env39194) = true)

theorem identity39194 : scanCanonicalize (H12AffineFastState.compose env39194 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39195 : List Nat := [2,4,8,11,32,10,9,36,512,47,512,4096,41,4107,0,35,4097,513,46,1,4106,32,10,2,40,11,513,4096,4097,512,14,33,37,32,4107,513]

theorem envBound39195 : H12AffineFastState.Bounded env39195 := by
  intro p hp
  have h : env39195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39194_39195 : H12AffineEnvironment.transform 3 11 env39194 = env39195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39194 == env39195) = true)

theorem identity39195 : scanCanonicalize (H12AffineFastState.compose env39195 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39195 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39196 : List Nat := [2,4,8,11,0,10,9,4,512,15,512,4096,9,4107,0,3,4097,513,14,1,4106,0,10,2,8,11,513,4096,4097,512,14,1,5,0,4107,513]

theorem envBound39196 : H12AffineFastState.Bounded env39196 := by
  intro p hp
  have h : env39196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39195_39196 : H12AffineEnvironment.transform 4 0 env39195 = env39196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39195 == env39196) = true)

def env39197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,147641,318700,466225,8328,65,409957,313837,449005,138477,148940,419865,257,21792,46212,221722]

theorem envBound39197 : H12AffineFastState.Bounded env39197 := by
  intro p hp
  have h : env39197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39167_39197 : H12AffineEnvironment.transform 21 147641 env39167 = env39197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147641 env39167 == env39197) = true)

def env39198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4161,169,318700,351521,8328,65,262517,313837,301565,23805,1500,272393,257,21792,46212,74250]

theorem envBound39198 : H12AffineFastState.Bounded env39198 := by
  intro p hp
  have h : env39198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39197_39198 : H12AffineEnvironment.transform 16 16400 env39197 = env39198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39197 == env39198) = true)

theorem identity39198 : scanCanonicalize (H12AffineFastState.compose env39198 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound39198 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,67619,1025,32769,4161,169,120015,21762,8328,65,67926,115150,102878,23805,1500,73770,257,21792,46212,74250]

theorem envBound39199 : H12AffineFastState.Bounded env39199 := by
  intro p hp
  have h : env39199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39198_39199 : H12AffineEnvironment.transform 17 67619 env39198 = env39199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env39198 == env39199) = true)

theorem identity39199 : scanCanonicalize (H12AffineFastState.compose env39199 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39199 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env39200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,67619,1025,32769,4161,32,119878,21762,8193,65,67926,115015,102743,23668,1365,73770,257,21792,46093,74250]

theorem envBound39200 : H12AffineFastState.Bounded env39200 := by
  intro p hp
  have h : env39200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39199_39200 : H12AffineEnvironment.transform 6 9 env39199 = env39200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39199 == env39200) = true)

theorem identity39200 : scanCanonicalize (H12AffineFastState.compose env39200 (packedSelected [0,1,3,4,5,8,9,14,15,17,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound39200 : packedSelected [0,1,3,4,5,8,9,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env39201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,16400,35108,1025,32769,4161,32,21825,21762,8193,65,34897,16448,4176,23668,1365,41261,257,21792,46093,41741]

theorem envBound39201 : H12AffineFastState.Bounded env39201 := by
  intro p hp
  have h : env39201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39200_39201 : H12AffineEnvironment.transform 15 33031 env39200 = env39201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env39200 == env39201) = true)

theorem identity39201 : scanCanonicalize (H12AffineFastState.compose env39201 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39201 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env39202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33031,16400,35108,1025,32769,4161,32,21825,21762,348,65,34897,16448,4176,23668,1365,32880,257,21792,38224,33360]

theorem envBound39202 : H12AffineFastState.Bounded env39202 := by
  intro p hp
  have h : env39202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39201_39202 : H12AffineEnvironment.transform 12 349 env39201 = env39202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39201 == env39202) = true)

theorem identity39202 : scanCanonicalize (H12AffineFastState.compose env39202 (packedSelected [0,3,4,5,6,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39202 : packedSelected [0,3,4,5,6,12,14] rootPS < 2^1333 := by decide +kernel

def env39203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,262,16400,2341,1025,0,4161,32,21825,21762,348,65,2128,16448,4176,23668,1365,113,257,21792,5457,593]

theorem envBound39203 : H12AffineFastState.Bounded env39203 := by
  intro p hp
  have h : env39203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39202_39203 : H12AffineEnvironment.transform 14 1 env39202 = env39203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39202 == env39203) = true)

theorem identity39203 : scanCanonicalize (H12AffineFastState.compose env39203 (packedSelected [1,4,6,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39203 : packedSelected [1,4,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39204 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1025,0,4112,32,21776,21762,269,16,2049,16401,4097,23589,1284,32,257,21792,5376,512]

theorem envBound39204 : H12AffineFastState.Bounded env39204 := by
  intro p hp
  have h : env39204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39203_39204 : H12AffineEnvironment.transform 5 17 env39203 = env39204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39203 == env39204) = true)

theorem identity39204 : scanCanonicalize (H12AffineFastState.compose env39204 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39204 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39205 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,16384,1,262,16400,2309,1025,0,4112,0,21776,21762,269,16,2049,16401,4097,23557,1284,0,257,21760,5376,512]

theorem envBound39205 : H12AffineFastState.Bounded env39205 := by
  intro p hp
  have h : env39205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39204_39205 : H12AffineEnvironment.transform 4 0 env39204 = env39205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39204 == env39205) = true)

theorem identity39205 : scanCanonicalize (H12AffineFastState.compose env39205 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 6420) := by decide +kernel

theorem selectedBound39205 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39206 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,6420,1,262,6404,2309,1025,0,4112,0,3076,3094,269,16,2049,6405,4097,1297,1284,0,257,3092,5376,512]

theorem envBound39206 : H12AffineFastState.Bounded env39206 := by
  intro p hp
  have h : env39206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39205_39206 : H12AffineEnvironment.transform 13 6420 env39205 = env39206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6420 env39205 == env39206) = true)

theorem identity39206 : scanCanonicalize (H12AffineFastState.compose env39206 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound39206 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39207 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,277,268,2049,1,262,2065,2309,1025,0,261,0,3076,3094,269,16,2049,2064,276,1297,1284,0,257,3092,1045,512]

theorem envBound39207 : H12AffineFastState.Bounded env39207 := by
  intro p hp
  have h : env39207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39206_39207 : H12AffineEnvironment.transform 11 277 env39206 = env39207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env39206 == env39207) = true)

theorem identity39207 : scanCanonicalize (H12AffineFastState.compose env39207 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39207 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39208 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,16,9,2049,1,3,2065,2048,1025,0,0,0,3076,3094,8,16,2049,2064,17,1044,1025,0,4,3092,1045,512]

theorem envBound39208 : H12AffineFastState.Bounded env39208 := by
  intro p hp
  have h : env39208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39207_39208 : H12AffineEnvironment.transform 7 5 env39207 = env39208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39207 == env39208) = true)

theorem identity39208 : scanCanonicalize (H12AffineFastState.compose env39208 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound39208 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39209 : List Nat := [2,4,8,16,0,17,9,5,512,1024,1045,16,9,1044,1,3,1028,1045,1025,0,0,0,17,3,8,16,1044,1029,17,1044,1025,0,4,1,1045,512]

theorem envBound39209 : H12AffineFastState.Bounded env39209 := by
  intro p hp
  have h : env39209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39208_39209 : H12AffineEnvironment.transform 10 1045 env39208 = env39209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env39208 == env39209) = true)

theorem identity39209 : scanCanonicalize (H12AffineFastState.compose env39209 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39209 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39210 : List Nat := [2,4,8,16,0,17,9,5,512,21,0,16,9,1,1,3,17,0,20,0,0,0,17,3,8,16,1,16,17,1,20,0,4,1,0,512]

theorem envBound39210 : H12AffineFastState.Bounded env39210 := by
  intro p hp
  have h : env39210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39209_39210 : H12AffineEnvironment.transform 9 21 env39209 = env39210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39209 == env39210) = true)

theorem identity39210 : scanCanonicalize (H12AffineFastState.compose env39210 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound39210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39211 : List Nat := [2,4,8,16,0,17,9,5,15,21,0,16,9,1,1,3,17,0,20,0,0,0,17,3,8,16,1,16,17,1,20,0,4,1,0,15]

theorem envBound39211 : H12AffineFastState.Bounded env39211 := by
  intro p hp
  have h : env39211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39210_39211 : H12AffineEnvironment.transform 8 15 env39210 = env39211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env39210 == env39211) = true)

def env39212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4160,168,318700,351520,8328,65,262516,313837,301564,23804,1501,272392,257,21792,46212,74251]

theorem envBound39212 : H12AffineFastState.Bounded env39212 := by
  intro p hp
  have h : env39212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39197_39212 : H12AffineEnvironment.transform 16 16401 env39197 = env39212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39197 == env39212) = true)

theorem identity39212 : scanCanonicalize (H12AffineFastState.compose env39212 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39212 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,168,318700,294186,8328,65,262516,313837,301564,23804,1501,272392,257,21792,46212,513]

theorem envBound39213 : H12AffineFastState.Bounded env39213 := by
  intro p hp
  have h : env39213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39212_39213 : H12AffineEnvironment.transform 15 8202 env39212 = env39213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39212 == env39213) = true)

def env39214 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4112,168,318652,294186,8328,17,262436,313789,301484,23724,1421,272392,257,21792,46212,513]

theorem envBound39214 : H12AffineFastState.Bounded env39214 := by
  intro p hp
  have h : env39214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39213_39214 : H12AffineEnvironment.transform 5 16 env39213 = env39214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39213 == env39214) = true)

theorem identity39214 : scanCanonicalize (H12AffineFastState.compose env39214 (packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound39214 : packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env39215 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35245,1025,32769,4112,168,21777,62599,8328,17,34953,16400,4097,23724,1421,41381,257,21792,46212,513]

theorem envBound39215 : H12AffineFastState.Bounded env39215 := by
  intro p hp
  have h : env39215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39214_39215 : H12AffineEnvironment.transform 17 35245 env39214 = env39215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env39214 == env39215) = true)

theorem identity39215 : scanCanonicalize (H12AffineFastState.compose env39215 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound39215 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env39216 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8202,16401,32160,1025,29708,4112,168,21777,138,8328,17,31876,16400,4097,23724,1421,21928,257,21792,16521,513]

theorem envBound39216 : H12AffineFastState.Bounded env39216 := by
  intro p hp
  have h : env39216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39215_39216 : H12AffineEnvironment.transform 14 29709 env39215 = env39216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env39215 == env39216) = true)

theorem identity39216 : scanCanonicalize (H12AffineFastState.compose env39216 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound39216 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8581,8202,5529,10280,1025,8580,4112,168,153,138,8328,17,10508,5528,4097,2340,1421,32,257,168,5377,513]

theorem envBound39217 : H12AffineFastState.Bounded env39217 := by
  intro p hp
  have h : env39217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39216_39217 : H12AffineEnvironment.transform 13 5512 env39216 = env39217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env39216 == env39217) = true)

theorem identity39217 : scanCanonicalize (H12AffineFastState.compose env39217 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39217 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39218 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,5393,10280,1025,8460,4112,32,17,2,8192,17,10508,5392,4097,2340,1285,32,257,32,5377,513]

theorem envBound39218 : H12AffineFastState.Bounded env39218 := by
  intro p hp
  have h : env39218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39217_39218 : H12AffineEnvironment.transform 6 8 env39217 = env39218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39217 == env39218) = true)

theorem identity39218 : scanCanonicalize (H12AffineFastState.compose env39218 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39218 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39219 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,4112,8461,8202,4097,10280,273,8460,4112,32,17,2,8192,17,10508,4096,4097,2340,21,32,257,32,4113,513]

theorem envBound39219 : H12AffineFastState.Bounded env39219 := by
  intro p hp
  have h : env39219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39218_39219 : H12AffineEnvironment.transform 9 272 env39218 = env39219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39218 == env39219) = true)

theorem identity39219 : scanCanonicalize (H12AffineFastState.compose env39219 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39219 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39220 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4112,8232,8202,4097,10280,52,8233,4112,32,17,2,8192,17,10281,4096,4097,2049,21,32,36,32,4113,513]

theorem envBound39220 : H12AffineFastState.Bounded env39220 := by
  intro p hp
  have h : env39220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39219_39220 : H12AffineEnvironment.transform 7 37 env39219 = env39220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39219 == env39220) = true)

theorem identity39220 : scanCanonicalize (H12AffineFastState.compose env39220 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound39220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39221 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,553,4112,513,547,4097,2561,52,512,4112,32,17,2,553,17,2560,4096,4097,2049,21,32,36,32,4113,513]

theorem envBound39221 : H12AffineFastState.Bounded env39221 := by
  intro p hp
  have h : env39221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39220_39221 : H12AffineEnvironment.transform 12 553 env39220 = env39221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env39220 == env39221) = true)

theorem identity39221 : scanCanonicalize (H12AffineFastState.compose env39221 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound39221 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39222 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,570,553,554,513,547,571,2561,52,512,554,32,17,2,553,17,2560,570,571,2049,21,32,36,32,555,513]

theorem envBound39222 : H12AffineFastState.Bounded env39222 := by
  intro p hp
  have h : env39222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39221_39222 : H12AffineEnvironment.transform 11 570 env39221 = env39222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env39221 == env39222) = true)

def env39223 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4113,168,318653,294186,8328,16,262437,313788,301485,23725,1420,272392,257,21792,46212,513]

theorem envBound39223 : H12AffineFastState.Bounded env39223 := by
  intro p hp
  have h : env39223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39213_39223 : H12AffineEnvironment.transform 5 17 env39213 = env39223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39213 == env39223) = true)

theorem identity39223 : scanCanonicalize (H12AffineFastState.compose env39223 (packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound39223 : packedSelected [1,3,7,11,14,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env39224 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,56357,1025,32769,4113,168,152,41231,8328,16,56576,5529,17800,23725,1420,62509,257,21792,46212,513]

theorem envBound39224 : H12AffineFastState.Bounded env39224 := by
  intro p hp
  have h : env39224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39223_39224 : H12AffineEnvironment.transform 17 56357 env39223 = env39224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env39223 == env39224) = true)

theorem identity39224 : scanCanonicalize (H12AffineFastState.compose env39224 (packedSelected [1,2,4,5,6,8,9,14,15,20,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39224 : packedSelected [1,2,4,5,6,8,9,14,15,20,24,38] rootPS < 2^1333 := by decide +kernel

def env39225 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,32768,263,16401,56357,1025,32769,4113,168,152,32770,389,16,56576,5529,17800,23725,1420,54560,257,21792,38281,513]

theorem envBound39225 : H12AffineFastState.Bounded env39225 := by
  intro p hp
  have h : env39225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39224_39225 : H12AffineEnvironment.transform 12 269 env39224 = env39225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39224 == env39225) = true)

theorem identity39225 : scanCanonicalize (H12AffineFastState.compose env39225 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39225 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39226 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,1,263,16401,23588,1025,0,4113,168,152,3,389,16,23809,5529,17800,23725,1420,21793,257,21792,5512,513]

theorem envBound39226 : H12AffineFastState.Bounded env39226 := by
  intro p hp
  have h : env39226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39225_39226 : H12AffineEnvironment.transform 14 1 env39225 = env39226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39225 == env39226) = true)

theorem identity39226 : scanCanonicalize (H12AffineFastState.compose env39226 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39226 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env39227 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1025,0,4113,168,152,3,389,16,2048,5529,4233,2476,1420,32,257,33,5512,513]

theorem envBound39227 : H12AffineFastState.Bounded env39227 := by
  intro p hp
  have h : env39227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39226_39227 : H12AffineEnvironment.transform 13 5377 env39226 = env39227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39226 == env39227) = true)

theorem identity39227 : scanCanonicalize (H12AffineFastState.compose env39227 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39227 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39228 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1025,0,4113,33,17,3,268,16,2048,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound39228 : H12AffineFastState.Bounded env39228 := by
  intro p hp
  have h : env39228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39227_39228 : H12AffineEnvironment.transform 6 9 env39227 = env39228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39227 == env39228) = true)

theorem identity39228 : scanCanonicalize (H12AffineFastState.compose env39228 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39229 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5172,2049,1025,0,4113,33,17,3,40,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound39229 : H12AffineFastState.Bounded env39229 := by
  intro p hp
  have h : env39229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39228_39229 : H12AffineEnvironment.transform 7 36 env39228 = env39229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39228 == env39229) = true)

def env39230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318701,2444640,8328,65,6705548,313837,2394557,138476,2102684,4466848,257,21793,46213,2175562]

theorem envBound39230 : H12AffineFastState.Bounded env39230 := by
  intro p hp
  have h : env39230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39117_39230 : H12AffineEnvironment.transform 22 318701 env39117 = env39230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318701 env39117 == env39230) = true)

def env39231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318701,466224,8328,65,4456924,313837,449005,138476,148940,4466848,257,21793,46213,221722]

theorem envBound39231 : H12AffineFastState.Bounded env39231 := by
  intro p hp
  have h : env39231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39230_39231 : H12AffineEnvironment.transform 20 151632 env39230 = env39231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env39230 == env39231) = true)

theorem identity39231 : scanCanonicalize (H12AffineFastState.compose env39231 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound39231 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env39232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,4194304,318701,294187,8328,65,4456924,313837,375286,97527,75223,4466848,257,21793,46213,513]

theorem envBound39232 : H12AffineFastState.Bounded env39232 := by
  intro p hp
  have h : env39232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39231_39232 : H12AffineEnvironment.transform 16 90139 env39231 = env39232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env39231 == env39232) = true)

def env39233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,4194304,272441,294187,8328,65,4456924,277817,347426,97527,75223,4466848,257,21793,16465,513]

theorem envBound39233 : H12AffineFastState.Bounded env39233 := by
  intro p hp
  have h : env39233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39232_39233 : H12AffineEnvironment.transform 14 29908 env39232 = env39233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env39232 == env39233) = true)

def env39234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,272512,272441,294187,8328,65,10588,277817,347426,97527,75223,32,257,21793,16465,513]

theorem envBound39234 : H12AffineFastState.Bounded env39234 := by
  intro p hp
  have h : env39234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39233_39234 : H12AffineEnvironment.transform 21 272512 env39233 = env39234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39233 == env39234) = true)

theorem identity39234 : scanCanonicalize (H12AffineFastState.compose env39234 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound39234 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10280,1025,29909,77899,168,17,21763,8328,65,10588,5393,91402,97527,75223,32,257,21793,16465,513]

theorem envBound39235 : H12AffineFastState.Bounded env39235 := by
  intro p hp
  have h : env39235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39234_39235 : H12AffineEnvironment.transform 17 10280 env39234 = env39235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39234 == env39235) = true)

theorem identity39235 : scanCanonicalize (H12AffineFastState.compose env39235 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound39235 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env39236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,479,25028,10280,1025,29909,12692,168,17,21763,8328,65,10588,5393,25813,32040,9224,32,257,21793,16465,513]

theorem envBound39236 : H12AffineFastState.Bounded env39236 := by
  intro p hp
  have h : env39236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39235_39236 : H12AffineEnvironment.transform 15 479 env39235 = env39236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env39235 == env39236) = true)

theorem identity39236 : scanCanonicalize (H12AffineFastState.compose env39236 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound39236 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env39237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,479,5393,10280,1025,0,12692,168,17,8662,8328,65,10588,5393,4096,2557,9224,32,257,8692,13444,513]

theorem envBound39237 : H12AffineFastState.Bounded env39237 := by
  intro p hp
  have h : env39237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39236_39237 : H12AffineEnvironment.transform 13 13525 env39236 = env39237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env39236 == env39237) = true)

theorem identity39237 : scanCanonicalize (H12AffineFastState.compose env39237 (packedSelected [1,2,5,6,8,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39237 : packedSelected [1,2,5,6,8,17,24] rootPS < 2^1333 := by decide +kernel

def env39238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,398,5393,10280,1025,0,12692,168,17,8583,8328,16,10509,5393,4096,2476,9224,32,257,8613,13444,513]

theorem envBound39238 : H12AffineFastState.Bounded env39238 := by
  intro p hp
  have h : env39238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39237_39238 : H12AffineEnvironment.transform 5 17 env39237 = env39238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39237 == env39238) = true)

theorem identity39238 : scanCanonicalize (H12AffineFastState.compose env39238 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound39238 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,398,5393,2476,1025,0,4112,168,17,3,268,16,2185,5393,4096,2476,1420,32,257,33,5376,513]

theorem envBound39239 : H12AffineFastState.Bounded env39239 := by
  intro p hp
  have h : env39239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39238_39239 : H12AffineEnvironment.transform 12 388 env39238 = env39239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env39238 == env39239) = true)

theorem identity39239 : scanCanonicalize (H12AffineFastState.compose env39239 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39239 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env39240 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5393,2341,1025,0,4112,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound39240 : H12AffineFastState.Bounded env39240 := by
  intro p hp
  have h : env39240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39239_39240 : H12AffineEnvironment.transform 6 9 env39239 = env39240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39239 == env39240) = true)

theorem identity39240 : scanCanonicalize (H12AffineFastState.compose env39240 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39241 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4112,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound39241 : H12AffineFastState.Bounded env39241 := by
  intro p hp
  have h : env39241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39240_39241 : H12AffineEnvironment.transform 7 36 env39240 = env39241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39240 == env39241) = true)

def env39242 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,1,35,1029,2049,1025,0,32,33,17,3,40,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound39242 : H12AffineFastState.Bounded env39242 := by
  intro p hp
  have h : env39242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39241_39242 : H12AffineEnvironment.transform 11 48 env39241 = env39242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39241 == env39242) = true)

theorem identity39242 : scanCanonicalize (H12AffineFastState.compose env39242 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39243 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1044,1,3,1029,2049,1025,0,0,1,17,3,8,16,2048,1029,16,2049,1025,0,5,1,1044,513]

theorem envBound39243 : H12AffineFastState.Bounded env39243 := by
  intro p hp
  have h : env39243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39242_39243 : H12AffineEnvironment.transform 4 0 env39242 = env39243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39242 == env39243) = true)

def env39244 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,0,1,3,17,2049,21,0,0,1,17,3,8,16,2048,17,16,2049,21,0,5,1,0,513]

theorem envBound39244 : H12AffineFastState.Bounded env39244 := by
  intro p hp
  have h : env39244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39243_39244 : H12AffineEnvironment.transform 9 20 env39243 = env39244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env39243 == env39244) = true)

theorem identity39244 : scanCanonicalize (H12AffineFastState.compose env39244 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound39244 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39245 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,16,9,0,1,3,17,522,21,0,0,1,17,3,8,16,523,17,16,522,21,0,5,1,0,513]

theorem envBound39245 : H12AffineFastState.Bounded env39245 := by
  intro p hp
  have h : env39245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39244_39245 : H12AffineEnvironment.transform 10 523 env39244 = env39245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env39244 == env39245) = true)

def leafEnv39245 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,16,9,0,1,3,17,522,21,0,0,1,17,3,20,8,1,16,523,17,16,522,21,0,5,1,5,2,0,513,1,0,0]

def active39245 : List Nat := [0,1,2,3,8]

def tree39245 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39245 : H12WitnessSearch.Good tree39245 := H12GlobalWitnessIndex.good

theorem leafIdentity39245 : H12AffineFastState.composeSystem env39245 rootObs = leafEnv39245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39245 rootObs == leafEnv39245) = true)

theorem terminalChecked39245 : H12PackedTerminal.terminalCheckFast leafEnv39245 active39245 tree39245 = true := by decide +kernel

def env39246 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,9,1,1,3,16,2049,20,0,0,1,17,3,8,16,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound39246 : H12AffineFastState.Bounded env39246 := by
  intro p hp
  have h : env39246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39243_39246 : H12AffineEnvironment.transform 9 21 env39243 = env39246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39243 == env39246) = true)

theorem identity39246 : scanCanonicalize (H12AffineFastState.compose env39246 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39247 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,1,1,3,16,1,20,0,0,1,17,3,8,16,0,16,16,1,20,0,5,1,1,513]

theorem envBound39247 : H12AffineFastState.Bounded env39247 := by
  intro p hp
  have h : env39247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39246_39247 : H12AffineEnvironment.transform 10 0 env39246 = env39247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39246 == env39247) = true)

def leafEnv39247 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,1,1,3,16,1,20,0,0,1,17,3,21,8,1,16,0,16,16,1,20,0,5,1,5,2,1,513,1,0,0]

def active39247 : List Nat := [0,1,2,3,8]

def tree39247 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39247 : H12WitnessSearch.Good tree39247 := H12GlobalWitnessIndex.good

theorem leafIdentity39247 : H12AffineFastState.composeSystem env39247 rootObs = leafEnv39247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39247 rootObs == leafEnv39247) = true)

theorem terminalChecked39247 : H12PackedTerminal.terminalCheckFast leafEnv39247 active39247 tree39247 = true := by decide +kernel

def env39248 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,1,35,1028,2049,1025,0,33,33,17,3,40,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound39248 : H12AffineFastState.Bounded env39248 := by
  intro p hp
  have h : env39248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39241_39248 : H12AffineEnvironment.transform 11 49 env39241 = env39248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39241 == env39248) = true)

theorem identity39248 : scanCanonicalize (H12AffineFastState.compose env39248 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39249 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,49,41,0,1,35,17,2049,20,0,33,33,17,3,40,16,2048,17,49,2049,52,32,37,33,0,513]

theorem envBound39249 : H12AffineFastState.Bounded env39249 := by
  intro p hp
  have h : env39249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39248_39249 : H12AffineEnvironment.transform 9 21 env39248 = env39249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39248 == env39249) = true)

def env39250 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,0,1,3,17,2049,20,0,1,1,17,3,8,16,2048,17,17,2049,20,0,5,1,0,513]

theorem envBound39250 : H12AffineFastState.Bounded env39250 := by
  intro p hp
  have h : env39250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39249_39250 : H12AffineEnvironment.transform 4 0 env39249 = env39250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39249 == env39250) = true)

theorem identity39250 : scanCanonicalize (H12AffineFastState.compose env39250 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39251 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,0,1,3,17,0,20,0,1,1,17,3,8,16,1,17,17,0,20,0,5,1,0,513]

theorem envBound39251 : H12AffineFastState.Bounded env39251 := by
  intro p hp
  have h : env39251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39250_39251 : H12AffineEnvironment.transform 10 1 env39250 = env39251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39250 == env39251) = true)

def leafEnv39251 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,0,1,3,17,0,20,0,1,1,17,3,21,8,1,16,1,17,17,0,20,0,5,1,5,2,0,513,1,1,0]

def active39251 : List Nat := [0,1,2,3,8]

def tree39251 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39251 : H12WitnessSearch.Good tree39251 := H12GlobalWitnessIndex.good

theorem leafIdentity39251 : H12AffineFastState.composeSystem env39251 rootObs = leafEnv39251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39251 rootObs == leafEnv39251) = true)

theorem terminalChecked39251 : H12PackedTerminal.terminalCheckFast leafEnv39251 active39251 tree39251 = true := by decide +kernel

def env39252 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,0,1,2,17,2049,20,0,0,0,17,3,9,16,2048,17,16,2049,21,1,4,0,0,513]

theorem envBound39252 : H12AffineFastState.Bounded env39252 := by
  intro p hp
  have h : env39252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39249_39252 : H12AffineEnvironment.transform 4 1 env39249 = env39252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39249 == env39252) = true)

theorem identity39252 : scanCanonicalize (H12AffineFastState.compose env39252 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound39252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39253 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,16,8,0,1,2,17,523,20,0,0,0,17,3,9,16,522,17,16,523,21,1,4,0,0,513]

theorem envBound39253 : H12AffineFastState.Bounded env39253 := by
  intro p hp
  have h : env39253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39252_39253 : H12AffineEnvironment.transform 10 522 env39252 = env39253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env39252 == env39253) = true)

def leafEnv39253 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,16,8,0,1,2,17,523,20,0,0,0,17,3,20,9,1,16,522,17,16,523,21,1,4,0,5,3,0,513,1,0,0]

def active39253 : List Nat := [0,1,2,3,8]

def tree39253 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39253 : H12WitnessSearch.Good tree39253 := H12GlobalWitnessIndex.good

theorem leafIdentity39253 : H12AffineFastState.composeSystem env39253 rootObs = leafEnv39253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39253 rootObs == leafEnv39253) = true)

theorem terminalChecked39253 : H12PackedTerminal.terminalCheckFast leafEnv39253 active39253 tree39253 = true := by decide +kernel

def env39254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,272513,272441,294187,8328,65,10589,277817,347426,97527,75223,33,257,21793,16465,513]

theorem envBound39254 : H12AffineFastState.Bounded env39254 := by
  intro p hp
  have h : env39254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39233_39254 : H12AffineEnvironment.transform 21 272513 env39233 = env39254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39233 == env39254) = true)

def env39255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,32160,1025,29909,77899,21793,21913,139,8328,65,10589,16537,77954,97527,75223,33,257,21793,16465,513]

theorem envBound39255 : H12AffineFastState.Bounded env39255 := by
  intro p hp
  have h : env39255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39254_39255 : H12AffineEnvironment.transform 17 32160 env39254 = env39255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env39254 == env39255) = true)

theorem identity39255 : scanCanonicalize (H12AffineFastState.compose env39255 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39255 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79130,10401,1025,8660,77899,32,152,139,8328,65,10589,5528,77954,76278,75223,33,257,32,5456,513]

theorem envBound39256 : H12AffineFastState.Bounded env39256 := by
  intro p hp
  have h : env39256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39255_39256 : H12AffineEnvironment.transform 13 5377 env39255 = env39256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39255 == env39256) = true)

theorem identity39256 : scanCanonicalize (H12AffineFastState.compose env39256 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound39256 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env39257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8283,5441,10401,1025,8660,4112,32,152,139,8328,65,10589,5528,4313,2477,1420,33,257,32,5456,513]

theorem envBound39257 : H12AffineFastState.Bounded env39257 := by
  intro p hp
  have h : env39257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39256_39257 : H12AffineEnvironment.transform 15 8283 env39256 = env39257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env39256 == env39257) = true)

theorem identity39257 : scanCanonicalize (H12AffineFastState.compose env39257 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound39257 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,81,479,5441,2341,1025,80,4112,32,152,139,268,65,2265,5528,4313,2477,1420,33,257,32,5456,513]

theorem envBound39258 : H12AffineFastState.Bounded env39258 := by
  intro p hp
  have h : env39258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39257_39258 : H12AffineEnvironment.transform 12 388 env39257 = env39258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env39257 == env39258) = true)

theorem identity39258 : scanCanonicalize (H12AffineFastState.compose env39258 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39258 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39259 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,240,5237,81,171,5173,2129,1025,80,4112,32,152,139,120,65,2265,5356,4313,2265,1272,33,117,32,5156,513]

theorem envBound39259 : H12AffineFastState.Bounded env39259 := by
  intro p hp
  have h : env39259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39258_39259 : H12AffineEnvironment.transform 7 116 env39258 = env39259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39258 == env39259) = true)

def env39260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,32161,1025,29909,77899,21792,21912,138,8328,65,10589,16536,77955,97527,75223,33,257,21793,16465,513]

theorem envBound39260 : H12AffineFastState.Bounded env39260 := by
  intro p hp
  have h : env39260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39254_39260 : H12AffineEnvironment.transform 17 32161 env39254 = env39260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env39254 == env39260) = true)

theorem identity39260 : scanCanonicalize (H12AffineFastState.compose env39260 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound39260 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,79250,10280,1025,8540,77899,169,17,138,8328,65,10589,5393,77955,76158,75223,33,257,168,5592,513]

theorem envBound39261 : H12AffineFastState.Bounded env39261 := by
  intro p hp
  have h : env39261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39260_39261 : H12AffineEnvironment.transform 13 5513 env39260 = env39261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env39260 == env39261) = true)

theorem identity39261 : scanCanonicalize (H12AffineFastState.compose env39261 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39261 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env39262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,65536,70863,2421,1025,1,69910,169,17,138,469,65,2048,5393,70110,67619,66698,33,257,168,5592,513]

theorem envBound39262 : H12AffineFastState.Bounded env39262 := by
  intro p hp
  have h : env39262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39261_39262 : H12AffineEnvironment.transform 12 349 env39261 = env39262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39261 == env39262) = true)

theorem identity39262 : scanCanonicalize (H12AffineFastState.compose env39262 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound39262 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env39263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,479,5392,2421,1025,1,4297,169,17,138,469,65,2048,5393,4097,2556,1365,33,257,168,5592,513]

theorem envBound39263 : H12AffineFastState.Bounded env39263 := by
  intro p hp
  have h : env39263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39262_39263 : H12AffineEnvironment.transform 15 479 env39262 = env39263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env39262 == env39263) = true)

theorem identity39263 : scanCanonicalize (H12AffineFastState.compose env39263 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39263 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env39264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5392,2421,1025,1,4161,33,17,2,349,65,2048,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound39264 : H12AffineFastState.Bounded env39264 := by
  intro p hp
  have h : env39264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39263_39264 : H12AffineEnvironment.transform 6 8 env39263 = env39264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39263 == env39264) = true)

theorem identity39264 : scanCanonicalize (H12AffineFastState.compose env39264 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound39264 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,349,1124,0,343,1141,2421,1025,1,292,33,17,2,349,65,2048,1140,356,2420,1365,33,257,32,1077,513]

theorem envBound39265 : H12AffineFastState.Bounded env39265 := by
  intro p hp
  have h : env39265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39264_39265 : H12AffineEnvironment.transform 11 357 env39264 = env39265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env39264 == env39265) = true)

theorem identity39265 : scanCanonicalize (H12AffineFastState.compose env39265 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39265 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39266 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,268,1077,0,262,1060,2340,1025,1,292,33,17,2,268,16,2048,1061,309,2341,1284,33,257,32,1077,513]

theorem envBound39266 : H12AffineFastState.Bounded env39266 := by
  intro p hp
  have h : env39266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39265_39266 : H12AffineEnvironment.transform 5 17 env39265 = env39266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39265 == env39266) = true)

theorem identity39266 : scanCanonicalize (H12AffineFastState.compose env39266 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39267 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,49,9,1077,0,3,1060,2081,1025,1,33,33,17,2,9,16,2048,1061,48,2080,1025,33,4,32,1077,513]

theorem envBound39267 : H12AffineFastState.Bounded env39267 := by
  intro p hp
  have h : env39267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39266_39267 : H12AffineEnvironment.transform 7 5 env39266 = env39267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39266 == env39267) = true)

theorem identity39267 : scanCanonicalize (H12AffineFastState.compose env39267 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound39267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39268 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1556,49,9,1077,0,3,1060,1589,1025,1,33,33,17,2,9,16,1556,1061,48,1588,1025,33,4,32,1077,513]

theorem envBound39268 : H12AffineFastState.Bounded env39268 := by
  intro p hp
  have h : env39268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39267_39268 : H12AffineEnvironment.transform 10 1556 env39267 = env39268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env39267 == env39268) = true)

theorem identity39268 : scanCanonicalize (H12AffineFastState.compose env39268 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39269 : List Nat := [2,4,8,0,32,1,8,5,512,1024,1540,33,9,1061,0,3,1060,1573,1025,1,33,33,1,2,9,0,1540,1061,32,1572,1025,33,4,32,1061,513]

theorem envBound39269 : H12AffineFastState.Bounded env39269 := by
  intro p hp
  have h : env39269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39268_39269 : H12AffineEnvironment.transform 3 0 env39268 = env39269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39268 == env39269) = true)

theorem identity39269 : scanCanonicalize (H12AffineFastState.compose env39269 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39269 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39270 : List Nat := [2,4,8,0,1,1,8,5,512,1024,1540,0,9,1028,0,3,1029,1540,1025,1,0,0,1,2,9,0,1540,1028,1,1541,1025,0,4,1,1028,513]

theorem envBound39270 : H12AffineFastState.Bounded env39270 := by
  intro p hp
  have h : env39270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39269_39270 : H12AffineEnvironment.transform 4 1 env39269 = env39270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39269 == env39270) = true)

theorem identity39270 : scanCanonicalize (H12AffineFastState.compose env39270 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound39270 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39271 : List Nat := [2,4,8,0,1,1,8,5,512,517,1,0,9,513,0,3,512,1,516,1,0,0,1,2,9,0,1,513,1,0,516,0,4,1,513,513]

theorem envBound39271 : H12AffineFastState.Bounded env39271 := by
  intro p hp
  have h : env39271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39270_39271 : H12AffineEnvironment.transform 9 517 env39270 = env39271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env39270 == env39271) = true)

theorem identity39271 : scanCanonicalize (H12AffineFastState.compose env39271 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39271 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39272 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,0,9,0,0,3,1,1,5,1,0,0,1,2,9,0,1,0,1,0,5,0,4,1,0,0]

theorem envBound39272 : H12AffineFastState.Bounded env39272 := by
  intro p hp
  have h : env39272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39271_39272 : H12AffineEnvironment.transform 8 1 env39271 = env39272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39271 == env39272) = true)

theorem identity39272 : scanCanonicalize (H12AffineFastState.compose env39272 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39273 : List Nat := [2,4,2,0,1,1,2,5,1,4,1,0,3,0,0,3,1,1,5,1,0,0,1,2,3,0,1,0,1,0,5,0,4,1,0,0]

theorem envBound39273 : H12AffineFastState.Bounded env39273 := by
  intro p hp
  have h : env39273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39272_39273 : H12AffineEnvironment.transform 2 2 env39272 = env39273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39272 == env39273) = true)

def env39274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,4194304,272440,294187,8328,65,4456924,277816,347427,97527,75223,4466848,257,21793,16464,513]

theorem envBound39274 : H12AffineFastState.Bounded env39274 := by
  intro p hp
  have h : env39274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39232_39274 : H12AffineEnvironment.transform 14 29909 env39232 = env39274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39232 == env39274) = true)

def env39275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,272512,272440,294187,8328,65,10588,277816,347427,97527,75223,32,257,21793,16464,513]

theorem envBound39275 : H12AffineFastState.Bounded env39275 := by
  intro p hp
  have h : env39275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39274_39275 : H12AffineEnvironment.transform 21 272512 env39274 = env39275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39274 == env39275) = true)

theorem identity39275 : scanCanonicalize (H12AffineFastState.compose env39275 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39275 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,16401,262144,1025,29908,4161,272512,272440,294187,8328,65,10588,277816,290089,23805,1501,32,257,21793,16464,513]

theorem envBound39276 : H12AffineFastState.Bounded env39276 := by
  intro p hp
  have h : env39276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39275_39276 : H12AffineEnvironment.transform 15 8202 env39275 = env39276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39275 == env39276) = true)

theorem identity39276 : scanCanonicalize (H12AffineFastState.compose env39276 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 32120) := by decide +kernel

theorem selectedBound39276 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env39277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,16401,32120,1025,29908,4161,22008,21824,83,8328,65,10588,16448,4177,23805,1501,32,257,21793,16464,513]

theorem envBound39277 : H12AffineFastState.Bounded env39277 := by
  intro p hp
  have h : env39277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39276_39277 : H12AffineEnvironment.transform 17 32120 env39276 = env39277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32120 env39276 == env39277) = true)

theorem identity39277 : scanCanonicalize (H12AffineFastState.compose env39277 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound39277 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env39278 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29708,8202,16401,32120,1025,29709,4161,21793,21824,83,8273,65,10588,16448,4177,23588,1284,32,257,21793,16464,513]

theorem envBound39278 : H12AffineFastState.Bounded env39278 := by
  intro p hp
  have h : env39278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39277_39278 : H12AffineEnvironment.transform 6 89 env39277 = env39278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env39277 == env39278) = true)

theorem identity39278 : scanCanonicalize (H12AffineFastState.compose env39278 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound39278 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env39279 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,0,8202,13341,2420,1025,1,4161,8493,8524,83,8273,65,10588,13388,4177,10280,1284,32,257,8493,13404,513]

theorem envBound39279 : H12AffineFastState.Bounded env39279 := by
  intro p hp
  have h : env39279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39278_39279 : H12AffineEnvironment.transform 13 13324 env39278 = env39279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env39278 == env39279) = true)

theorem identity39279 : scanCanonicalize (H12AffineFastState.compose env39279 (packedSelected [0,1,4,6,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39279 : packedSelected [0,1,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env39280 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,0,8202,13341,2341,1025,1,4112,8493,8477,2,8192,16,10509,13341,4096,10280,1284,32,257,8493,13325,513]

theorem envBound39280 : H12AffineFastState.Bounded env39280 := by
  intro p hp
  have h : env39280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39279_39280 : H12AffineEnvironment.transform 5 17 env39279 = env39280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39279 == env39280) = true)

theorem identity39280 : scanCanonicalize (H12AffineFastState.compose env39280 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39281 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4112,33,17,2,268,16,2049,5393,4096,2340,1284,32,257,33,5377,513]

theorem envBound39281 : H12AffineFastState.Bounded env39281 := by
  intro p hp
  have h : env39281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39280_39281 : H12AffineEnvironment.transform 12 268 env39280 = env39281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39280 == env39281) = true)

theorem identity39281 : scanCanonicalize (H12AffineFastState.compose env39281 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39282 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4113,0,262,4096,2341,272,1,4112,33,17,2,268,16,2049,4096,4096,2340,21,32,257,33,4112,513]

theorem envBound39282 : H12AffineFastState.Bounded env39282 := by
  intro p hp
  have h : env39282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39281_39282 : H12AffineEnvironment.transform 9 273 env39281 = env39282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39281 == env39282) = true)

def env39283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,272513,272440,294187,8328,65,10589,277816,347427,97527,75223,33,257,21793,16464,513]

theorem envBound39283 : H12AffineFastState.Bounded env39283 := by
  intro p hp
  have h : env39283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39274_39283 : H12AffineEnvironment.transform 21 272513 env39274 = env39283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39274 == env39283) = true)

theorem identity39283 : scanCanonicalize (H12AffineFastState.compose env39283 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound39283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,67619,1025,29908,77899,73890,73755,95496,8328,65,10589,79131,17664,97527,75223,33,257,21793,16464,513]

theorem envBound39284 : H12AffineFastState.Bounded env39284 := by
  intro p hp
  have h : env39284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39283_39284 : H12AffineEnvironment.transform 17 67619 env39283 = env39284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env39283 == env39284) = true)

def env39285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,67619,1025,29788,77899,73770,73755,95496,8192,65,10589,79131,17664,97407,75103,33,257,21793,16464,513]

theorem envBound39285 : H12AffineFastState.Bounded env39285 := by
  intro p hp
  have h : env39285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39284_39285 : H12AffineEnvironment.transform 6 8 env39284 = env39285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39284 == env39285) = true)

theorem identity39285 : scanCanonicalize (H12AffineFastState.compose env39285 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39285 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5393,32041,1025,29788,17729,21792,21777,2,8192,65,10589,16401,17664,2421,20565,33,257,21793,16464,513]

theorem envBound39286 : H12AffineFastState.Bounded env39286 := by
  intro p hp
  have h : env39286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39285_39286 : H12AffineEnvironment.transform 15 29962 env39285 = env39286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39285 == env39286) = true)

theorem identity39286 : scanCanonicalize (H12AffineFastState.compose env39286 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound39286 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8283,5393,10360,1025,8461,4112,113,64,2,8192,65,10589,5440,4177,2421,1284,33,257,112,5377,513]

theorem envBound39287 : H12AffineFastState.Bounded env39287 := by
  intro p hp
  have h : env39287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39286_39287 : H12AffineEnvironment.transform 13 5457 env39286 = env39287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env39286 == env39287) = true)

theorem identity39287 : scanCanonicalize (H12AffineFastState.compose env39287 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound39287 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,3393,8460,8283,3329,10360,1025,8461,2048,113,64,2,8192,65,10589,3408,2113,2421,1284,33,257,112,3345,513]

theorem envBound39288 : H12AffineFastState.Bounded env39288 := by
  intro p hp
  have h : env39288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39287_39288 : H12AffineEnvironment.transform 11 2064 env39287 = env39288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env39287 == env39288) = true)

theorem identity39288 : scanCanonicalize (H12AffineFastState.compose env39288 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39288 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39289 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,8192,2340,8460,8283,2404,10360,100,8461,2048,113,64,2,8192,65,10589,2357,2113,2421,353,33,257,112,2420,513]

theorem envBound39289 : H12AffineFastState.Bounded env39289 := by
  intro p hp
  have h : env39289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39288_39289 : H12AffineEnvironment.transform 9 101 env39288 = env39289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39288 == env39289) = true)

theorem identity39289 : scanCanonicalize (H12AffineFastState.compose env39289 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39289 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env39290 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,8192,2128,8312,8283,2064,10360,100,8313,2048,113,64,2,8192,65,10281,2113,2113,2049,21,33,117,112,2048,513]

theorem envBound39290 : H12AffineFastState.Bounded env39290 := by
  intro p hp
  have h : env39290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39289_39290 : H12AffineEnvironment.transform 7 116 env39289 = env39290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39289 == env39290) = true)

theorem identity39290 : scanCanonicalize (H12AffineFastState.compose env39290 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound39290 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39291 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,2089,2128,2129,2162,2064,81,100,2128,2048,113,64,2,2089,65,0,2113,2113,2049,21,33,117,112,2048,513]

theorem envBound39291 : H12AffineFastState.Bounded env39291 := by
  intro p hp
  have h : env39291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39290_39291 : H12AffineEnvironment.transform 12 2089 env39290 = env39291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env39290 == env39291) = true)

theorem identity39291 : scanCanonicalize (H12AffineFastState.compose env39291 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39291 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39292 : List Nat := [2,4,8,16,32,64,8,116,0,101,2048,2064,2089,2128,2129,2162,2064,81,100,2128,2048,113,64,2,2089,65,0,2113,2113,2049,21,33,117,112,2048,1]

theorem envBound39292 : H12AffineFastState.Bounded env39292 := by
  intro p hp
  have h : env39292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39291_39292 : H12AffineEnvironment.transform 8 0 env39291 = env39292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39291 == env39292) = true)

theorem identity39292 : scanCanonicalize (H12AffineFastState.compose env39292 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39292 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env39293 : List Nat := [2,4,8,16,32,64,8,116,0,101,0,16,41,80,81,114,16,81,100,80,0,113,64,2,41,65,0,65,65,1,21,33,117,112,0,1]

theorem envBound39293 : H12AffineFastState.Bounded env39293 := by
  intro p hp
  have h : env39293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39292_39293 : H12AffineEnvironment.transform 10 0 env39292 = env39293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39292 == env39293) = true)

theorem identity39293 : scanCanonicalize (H12AffineFastState.compose env39293 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39293 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39294 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,16,41,1,0,35,16,0,53,1,0,32,17,2,41,16,0,16,16,1,21,33,36,33,0,1]

theorem envBound39294 : H12AffineFastState.Bounded env39294 := by
  intro p hp
  have h : env39294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39293_39294 : H12AffineEnvironment.transform 5 17 env39293 = env39294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39293 == env39294) = true)

theorem identity39294 : scanCanonicalize (H12AffineFastState.compose env39294 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39295 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,16,9,1,0,3,16,0,21,1,0,0,17,2,9,16,0,16,16,1,21,1,4,1,0,1]

theorem envBound39295 : H12AffineFastState.Bounded env39295 := by
  intro p hp
  have h : env39295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39294_39295 : H12AffineEnvironment.transform 4 0 env39294 = env39295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39294 == env39295) = true)

def env39296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,67619,1025,29789,77899,73771,73755,95496,8193,65,10589,79131,17664,97406,75102,33,257,21793,16464,513]

theorem envBound39296 : H12AffineFastState.Bounded env39296 := by
  intro p hp
  have h : env39296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39284_39296 : H12AffineEnvironment.transform 6 9 env39284 = env39296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39284 == env39296) = true)

theorem identity39296 : scanCanonicalize (H12AffineFastState.compose env39296 (packedSelected [2,6,7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39296 : packedSelected [2,6,7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env39297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,65536,82198,67619,1025,21840,69958,65830,65814,87045,268,65,2128,70678,17664,89459,66643,33,257,21793,16464,513]

theorem envBound39297 : H12AffineFastState.Bounded env39297 := by
  intro p hp
  have h : env39297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39296_39297 : H12AffineEnvironment.transform 12 269 env39296 = env39297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39296 == env39297) = true)

theorem identity39297 : scanCanonicalize (H12AffineFastState.compose env39297 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound39297 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,21510,5392,23589,1025,21840,17728,21792,21776,3,268,65,2128,16400,17664,2421,20565,33,257,21793,16464,513]

theorem envBound39298 : H12AffineFastState.Bounded env39298 := by
  intro p hp
  have h : env39298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39297_39298 : H12AffineEnvironment.transform 15 21510 env39297 = env39298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env39297 == env39298) = true)

theorem identity39298 : scanCanonicalize (H12AffineFastState.compose env39298 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39298 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,342,5392,2421,1025,0,4112,112,64,3,268,65,2128,5440,4176,2421,1285,33,257,113,5376,513]

theorem envBound39299 : H12AffineFastState.Bounded env39299 := by
  intro p hp
  have h : env39299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39298_39299 : H12AffineEnvironment.transform 13 5456 env39298 = env39299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env39298 == env39299) = true)

theorem identity39299 : scanCanonicalize (H12AffineFastState.compose env39299 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound39299 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,269,80,1,342,16,2421,1025,0,1296,112,64,3,268,65,2128,64,1360,2421,1285,33,257,113,0,513]

theorem envBound39300 : H12AffineFastState.Bounded env39300 := by
  intro p hp
  have h : env39300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39299_39300 : H12AffineEnvironment.transform 11 1280 env39299 = env39300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env39299 == env39300) = true)

theorem identity39300 : scanCanonicalize (H12AffineFastState.compose env39300 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39301 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,357,269,80,1,342,16,2421,100,0,373,112,64,3,268,65,2128,64,309,2421,352,33,257,113,0,513]

theorem envBound39301 : H12AffineFastState.Bounded env39301 := by
  intro p hp
  have h : env39301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39300_39301 : H12AffineEnvironment.transform 9 101 env39300 = env39301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39300 == env39301) = true)

theorem identity39301 : scanCanonicalize (H12AffineFastState.compose env39301 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound39301 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env39302 : List Nat := [2,4,8,16,32,64,9,256,512,101,292,357,269,80,1,342,16,81,100,0,373,112,64,3,268,65,372,64,309,81,352,33,257,113,0,513]

theorem envBound39302 : H12AffineFastState.Bounded env39302 := by
  intro p hp
  have h : env39302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39301_39302 : H12AffineEnvironment.transform 10 292 env39301 = env39302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env39301 == env39302) = true)

theorem identity39302 : scanCanonicalize (H12AffineFastState.compose env39302 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

end H12CloudChart1