import H12CloudChart1Data037

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env9456 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,278,4373,226,65536,4605,2421,70308,226,625,372,70216,35,415,70169,67901,70037,69737,67809,65985,65728,70309,65729,70100,1020]

theorem envBound9456 : H12AffineFastState.Bounded env9456 := by
  intro p hp
  have h : env9456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9455_9456 : H12AffineEnvironment.transform 12 278 env9455 = env9456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 278 env9455 == env9456) = true)

theorem identity9456 : scanCanonicalize (H12AffineFastState.compose env9456 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound9456 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env9457 : List Nat := [2,4,8,16,32,64,128,256,512,257,522,4096,278,4373,226,65536,4605,895,70308,226,625,372,70216,35,415,70169,66359,70037,69737,66283,65985,65728,70309,65729,70100,1020]

theorem envBound9457 : H12AffineFastState.Bounded env9457 := by
  intro p hp
  have h : env9457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9456_9457 : H12AffineEnvironment.transform 10 522 env9456 = env9457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env9456 == env9457) = true)

theorem identity9457 : scanCanonicalize (H12AffineFastState.compose env9457 (packedSelected [1,6,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9457 : packedSelected [1,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9458 : List Nat := [2,4,8,16,32,64,40,256,512,257,522,4096,278,4373,74,65536,4437,895,70156,74,625,372,70216,35,311,70169,66359,69949,69737,66115,65897,65640,70157,65641,70012,852]

theorem envBound9458 : H12AffineFastState.Bounded env9458 := by
  intro p hp
  have h : env9458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9457_9458 : H12AffineEnvironment.transform 6 40 env9457 = env9458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9457 == env9458) = true)

theorem identity9458 : scanCanonicalize (H12AffineFastState.compose env9458 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9458 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env9459 : List Nat := [2,4,8,16,32,64,40,37,512,36,522,4096,51,4144,74,65536,4208,602,70156,74,625,81,70216,35,18,70169,66066,69656,69737,66115,65612,65640,70157,65641,69721,625]

theorem envBound9459 : H12AffineFastState.Bounded env9459 := by
  intro p hp
  have h : env9459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9458_9459 : H12AffineEnvironment.transform 7 37 env9458 = env9459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9458 == env9459) = true)

theorem identity9459 : scanCanonicalize (H12AffineFastState.compose env9459 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound9459 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env9460 : List Nat := [2,4,8,16,32,64,40,37,512,36,522,4096,51,4144,74,82,4208,602,4702,74,625,81,4634,35,18,4683,576,4170,4155,529,30,58,4703,59,4107,625]

theorem envBound9460 : H12AffineFastState.Bounded env9460 := by
  intro p hp
  have h : env9460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9459_9460 : H12AffineEnvironment.transform 15 82 env9459 = env9460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env9459 == env9460) = true)

theorem identity9460 : scanCanonicalize (H12AffineFastState.compose env9460 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound9460 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9461 : List Nat := [2,4,8,16,32,64,40,37,512,36,522,528,51,544,74,82,608,602,78,74,625,81,10,35,18,91,576,602,555,529,30,58,79,59,539,625]

theorem envBound9461 : H12AffineFastState.Bounded env9461 := by
  intro p hp
  have h : env9461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9460_9461 : H12AffineEnvironment.transform 11 528 env9460 = env9461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env9460 == env9461) = true)

theorem identity9461 : scanCanonicalize (H12AffineFastState.compose env9461 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9461 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env9462 : List Nat := [2,4,8,16,32,49,40,37,512,36,522,528,51,544,59,35,529,555,63,59,512,32,10,35,18,42,561,555,555,529,30,58,62,59,539,512]

theorem envBound9462 : H12AffineFastState.Bounded env9462 := by
  intro p hp
  have h : env9462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9461_9462 : H12AffineEnvironment.transform 5 49 env9461 = env9462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9461 == env9462) = true)

def env9463 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524289,21500723,23593047,16778207]

theorem envBound9463 : H12AffineFastState.Bounded env9463 := by
  intro p hp
  have h : env9463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9437_9463 : H12AffineEnvironment.transform 26 4985753 env9437 = env9463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4985753 env9437 == env9463) = true)

def env9464 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,4194304,524524,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524289,21500723,21781063,16778207]

theorem envBound9464 : H12AffineFastState.Bounded env9464 := by
  intro p hp
  have h : env9464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9463_9464 : H12AffineEnvironment.transform 20 285200 env9463 = env9464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285200 env9463 == env9464) = true)

theorem identity9464 : scanCanonicalize (H12AffineFastState.compose env9464 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9464 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9465 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285200,476,524524,16777216,8329,16855852,791109,525104,525004,17308367,529253,17306182,524289,17306351,17587099,16778207]

theorem envBound9465 : H12AffineFastState.Bounded env9465 := by
  intro p hp
  have h : env9465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9464_9465 : H12AffineEnvironment.transform 21 476 env9464 = env9465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9464 == env9465) = true)

theorem identity9465 : scanCanonicalize (H12AffineFastState.compose env9465 (packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9465 : packedSelected [1,3,5,8,10,11,13,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9466 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,285200,373,524357,16777216,8224,16855852,791109,525104,524901,17308262,529253,17306182,524289,17306182,17586994,16778102]

theorem envBound9466 : H12AffineFastState.Bounded env9466 := by
  intro p hp
  have h : env9466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9465_9466 : H12AffineEnvironment.transform 6 41 env9465 = env9466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9465 == env9466) = true)

theorem identity9466 : scanCanonicalize (H12AffineFastState.compose env9466 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9466 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9467 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,285200,32,524357,16777216,8224,16855673,791109,524901,524901,17308262,528944,17306182,524289,17306182,17586791,16777763]

theorem envBound9467 : H12AffineFastState.Bounded env9467 := by
  intro p hp
  have h : env9467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9466_9467 : H12AffineEnvironment.transform 7 85 env9466 = env9467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9466 == env9467) = true)

theorem identity9467 : scanCanonicalize (H12AffineFastState.compose env9467 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound9467 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9468 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8200,65536,4097,262144,78415,8200,285200,32,78346,16777216,8224,16855673,335882,77866,77866,16853033,73855,16850953,78414,16850953,17131560,16777763]

theorem envBound9468 : H12AffineFastState.Bounded env9468 := by
  intro p hp
  have h : env9468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9467_9468 : H12AffineEnvironment.transform 18 78415 env9467 = env9468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env9467 == env9468) = true)

theorem identity9468 : scanCanonicalize (H12AffineFastState.compose env9468 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(23+1) ^^^ 336418) := by decide +kernel

theorem selectedBound9468 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env9469 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8200,65536,4097,262144,78415,8200,285200,32,78346,336418,8224,266331,335882,77866,77866,264715,73855,262699,78414,262699,18954,335873]

theorem envBound9469 : H12AffineFastState.Bounded env9469 := by
  intro p hp
  have h : env9469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9468_9469 : H12AffineEnvironment.transform 23 336418 env9468 = env9469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 336418 env9468 == env9469) = true)

theorem identity9469 : scanCanonicalize (H12AffineFastState.compose env9469 (packedSelected [0,4,6,10,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound9469 : packedSelected [0,4,6,10,13,14] rootPS < 2^1333 := by decide +kernel

def env9470 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8200,65536,4097,16395,78415,8200,6683,32,78346,90665,8224,20560,90113,77866,77866,18944,73855,16928,78414,16928,18954,90122]

theorem envBound9470 : H12AffineFastState.Bounded env9470 := by
  intro p hp
  have h : env9470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9469_9470 : H12AffineEnvironment.transform 17 16395 env9469 = env9470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env9469 == env9470) = true)

theorem identity9470 : scanCanonicalize (H12AffineFastState.compose env9470 (packedSelected [1,2,3,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9470 : packedSelected [1,2,3,13,17] rootPS < 2^1333 := by decide +kernel

def env9471 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,16384,8200,14401,4097,16395,2574,8200,6683,32,2635,23144,8224,20560,22592,2155,2155,18944,6206,16928,2575,16928,18954,22603]

theorem envBound9471 : H12AffineFastState.Bounded env9471 := by
  intro p hp
  have h : env9471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9470_9471 : H12AffineEnvironment.transform 15 14401 env9470 = env9471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9470 == env9471) = true)

theorem identity9471 : scanCanonicalize (H12AffineFastState.compose env9471 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound9471 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env9472 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,8192,8744,8200,14401,4097,8739,2574,8200,6683,32,2635,14400,8224,12920,14952,2155,2155,10280,6206,8200,2575,8200,10274,14947]

theorem envBound9472 : H12AffineFastState.Bounded env9472 := by
  intro p hp
  have h : env9472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9471_9472 : H12AffineEnvironment.transform 13 8744 env9471 = env9472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env9471 == env9472) = true)

theorem identity9472 : scanCanonicalize (H12AffineFastState.compose env9472 (packedSelected [11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 6243) := by decide +kernel

theorem selectedBound9472 : packedSelected [11,13,18] rootPS < 2^1333 := by decide +kernel

def env9473 : List Nat := [2,4,8,16,32,64,41,85,512,84,2048,4096,6243,6731,6251,34,4097,6720,2574,6251,6683,32,2635,35,6211,2587,523,2155,2155,4171,6206,6251,2575,6251,4161,512]

theorem envBound9473 : H12AffineFastState.Bounded env9473 := by
  intro p hp
  have h : env9473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9472_9473 : H12AffineEnvironment.transform 12 6243 env9472 = env9473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6243 env9472 == env9473) = true)

def env9474 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,4194304,524524,16777216,8329,16855852,4985753,525104,525004,21502739,529253,17306182,524289,21500723,21781062,16778207]

theorem envBound9474 : H12AffineFastState.Bounded env9474 := by
  intro p hp
  have h : env9474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9463_9474 : H12AffineEnvironment.transform 20 285201 env9463 = env9474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 285201 env9463 == env9474) = true)

theorem identity9474 : scanCanonicalize (H12AffineFastState.compose env9474 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound9474 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env9475 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,372,524524,16777216,8329,16855852,791277,525104,525004,17308263,529253,17306182,524289,17306183,17586994,16778207]

theorem envBound9475 : H12AffineFastState.Bounded env9475 := by
  intro p hp
  have h : env9475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9474_9475 : H12AffineEnvironment.transform 21 372 env9474 = env9475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env9474 == env9475) = true)

theorem identity9475 : scanCanonicalize (H12AffineFastState.compose env9475 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 35) := by decide +kernel

theorem selectedBound9475 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9476 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,285201,372,524524,35,8329,78607,791277,525104,525004,531012,529253,528997,524289,528996,809745,1020]

theorem envBound9476 : H12AffineFastState.Bounded env9476 := by
  intro p hp
  have h : env9476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9475_9476 : H12AffineEnvironment.transform 23 35 env9475 = env9476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35 env9475 == env9476) = true)

theorem identity9476 : scanCanonicalize (H12AffineFastState.compose env9476 (packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS)) = affineNative (2^(18+1) ^^^ 342727) := by decide +kernel

theorem selectedBound9476 : packedSelected [1,3,5,8,10,13,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env9477 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,342727,8692,285201,372,342571,35,8329,78607,75818,342519,342027,336003,338338,338082,342726,338083,90582,1020]

theorem envBound9477 : H12AffineFastState.Bounded env9477 := by
  intro p hp
  have h : env9477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9476_9477 : H12AffineEnvironment.transform 18 342727 env9476 = env9477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 342727 env9476 == env9477) = true)

theorem identity9477 : scanCanonicalize (H12AffineFastState.compose env9477 (packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound9477 : packedSelected [0,1,3,4,5,7,8,9,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env9478 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,2524,78619,8692,21453,372,78839,35,8329,78607,75818,77867,78295,76127,73854,74110,78618,74111,90582,1020]

theorem envBound9478 : H12AffineFastState.Bounded env9478 := by
  intro p hp
  have h : env9478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9477_9478 : H12AffineEnvironment.transform 17 2524 env9477 = env9478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env9477 == env9478) = true)

theorem identity9478 : scanCanonicalize (H12AffineFastState.compose env9478 (packedSelected [2,5,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 30857) := by decide +kernel

theorem selectedBound9478 : packedSelected [2,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env9479 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,30857,4605,2524,19346,8692,21453,372,19326,35,8329,19334,20643,18594,18782,20950,22775,23031,19347,23030,6495,1020]

theorem envBound9479 : H12AffineFastState.Bounded env9479 := by
  intro p hp
  have h : env9479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9478_9479 : H12AffineEnvironment.transform 15 30857 env9478 = env9479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30857 env9478 == env9479) = true)

theorem identity9479 : scanCanonicalize (H12AffineFastState.compose env9479 (packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 8754) := by decide +kernel

theorem selectedBound9479 : packedSelected [0,1,2,4,6,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env9480 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,8754,8692,6843,4605,2524,10656,8692,12799,372,10572,35,8329,10676,12945,10896,11116,13284,15045,15301,10657,15300,6495,1020]

theorem envBound9480 : H12AffineFastState.Bounded env9480 := by
  intro p hp
  have h : env9480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9479_9480 : H12AffineEnvironment.transform 13 8754 env9479 = env9480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8754 env9479 == env9480) = true)

theorem identity9480 : scanCanonicalize (H12AffineFastState.compose env9480 (packedSelected [0,3,4,6,7,8,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound9480 : packedSelected [0,3,4,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env9481 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,2288,2754,2308,6843,4605,2524,336,2308,6415,372,444,35,2169,324,6753,608,924,6932,4661,4917,337,4916,6495,1020]

theorem envBound9481 : H12AffineFastState.Bounded env9481 := by
  intro p hp
  have h : env9481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9480_9481 : H12AffineEnvironment.transform 12 2288 env9480 = env9481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env9480 == env9481) = true)

theorem identity9481 : scanCanonicalize (H12AffineFastState.compose env9481 (packedSelected [0,2,4,7,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound9481 : packedSelected [0,2,4,7,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env9482 : List Nat := [2,4,8,16,32,64,128,256,512,257,390,4096,374,836,130,4925,4605,90,336,130,4233,372,444,35,511,324,5095,608,924,4754,4661,4917,337,4916,4313,1020]

theorem envBound9482 : H12AffineFastState.Bounded env9482 := by
  intro p hp
  have h : env9482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9481_9482 : H12AffineEnvironment.transform 10 390 env9481 = env9482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env9481 == env9482) = true)

theorem identity9482 : scanCanonicalize (H12AffineFastState.compose env9482 (packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound9482 : packedSelected [0,1,2,3,4,6,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env9483 : List Nat := [2,4,8,16,32,64,128,256,512,257,390,277,374,836,130,552,232,90,336,130,412,372,444,35,511,324,754,608,924,903,800,544,337,545,460,1020]

theorem envBound9483 : H12AffineFastState.Bounded env9483 := by
  intro p hp
  have h : env9483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9482_9483 : H12AffineEnvironment.transform 11 277 env9482 = env9483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env9482 == env9483) = true)

theorem identity9483 : scanCanonicalize (H12AffineFastState.compose env9483 (packedSelected [1,2,5,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9483 : packedSelected [1,2,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env9484 : List Nat := [2,4,8,16,32,64,128,85,512,84,211,64,35,529,130,552,232,90,5,130,201,33,233,35,170,17,754,608,713,722,629,544,4,545,153,681]

theorem envBound9484 : H12AffineFastState.Bounded env9484 := by
  intro p hp
  have h : env9484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9483_9484 : H12AffineEnvironment.transform 7 85 env9483 = env9484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9483 == env9484) = true)

theorem identity9484 : scanCanonicalize (H12AffineFastState.compose env9484 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound9484 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9485 : List Nat := [2,4,8,16,32,58,128,47,512,46,169,58,35,529,130,552,146,32,5,130,179,33,147,35,170,17,648,538,691,680,527,544,4,545,153,681]

theorem envBound9485 : H12AffineFastState.Bounded env9485 := by
  intro p hp
  have h : env9485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9484_9485 : H12AffineEnvironment.transform 5 58 env9484 = env9485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env9484 == env9485) = true)

theorem identity9485 : scanCanonicalize (H12AffineFastState.compose env9485 (packedSelected [1,2,3,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound9485 : packedSelected [1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9486 : List Nat := [2,4,8,16,32,58,128,47,131,46,169,58,35,146,130,171,146,32,5,130,179,33,147,35,170,17,11,153,48,43,140,163,4,162,153,42]

theorem envBound9486 : H12AffineFastState.Bounded env9486 := by
  intro p hp
  have h : env9486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9485_9486 : H12AffineEnvironment.transform 8 131 env9485 = env9486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env9485 == env9486) = true)

theorem identity9486 : scanCanonicalize (H12AffineFastState.compose env9486 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9486 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9487 : List Nat := [2,4,8,16,32,58,40,47,43,46,1,58,35,58,42,3,58,32,5,42,27,33,59,35,2,17,11,49,48,43,36,11,4,10,49,42]

theorem envBound9487 : H12AffineFastState.Bounded env9487 := by
  intro p hp
  have h : env9487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9486_9487 : H12AffineEnvironment.transform 6 40 env9486 = env9487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9486 == env9487) = true)

theorem identity9487 : scanCanonicalize (H12AffineFastState.compose env9487 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9488 : List Nat := [2,4,8,11,32,33,40,47,43,46,1,33,35,33,42,3,33,32,5,42,0,33,32,35,2,10,11,42,43,43,36,11,4,10,42,42]

theorem envBound9488 : H12AffineFastState.Bounded env9488 := by
  intro p hp
  have h : env9488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9487_9488 : H12AffineEnvironment.transform 3 11 env9487 = env9488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9487 == env9488) = true)

theorem identity9488 : scanCanonicalize (H12AffineFastState.compose env9488 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound9488 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9489 : List Nat := [2,4,6,5,32,33,38,33,37,32,1,33,35,33,36,3,33,32,5,36,0,33,32,35,2,4,5,36,37,37,36,5,4,4,36,36]

theorem envBound9489 : H12AffineFastState.Bounded env9489 := by
  intro p hp
  have h : env9489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9488_9489 : H12AffineEnvironment.transform 2 6 env9488 = env9489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env9488 == env9489) = true)

theorem identity9489 : scanCanonicalize (H12AffineFastState.compose env9489 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound9489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9490 : List Nat := [2,4,6,5,5,4,3,4,0,5,1,4,6,4,1,3,4,5,5,1,0,4,5,6,2,4,5,1,0,0,1,5,4,4,1,1]

theorem envBound9490 : H12AffineFastState.Bounded env9490 := by
  intro p hp
  have h : env9490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9489_9490 : H12AffineEnvironment.transform 4 5 env9489 = env9490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env9489 == env9490) = true)

def env9491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound9491 : H12AffineFastState.Bounded env9491 := by
  intro p hp
  have h : env9491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8143_9491 : H12AffineEnvironment.transform 14 8693 env8143 = env9491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env8143 == env9491) = true)

def env9492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,67108864,134217728,138678440,138678612,151259274,84484168,155451870,525568,151257258,203759843,16778206]

theorem envBound9492 : H12AffineFastState.Bounded env9492 := by
  intro p hp
  have h : env9492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9491_9492 : H12AffineEnvironment.transform 27 138678440 env9491 = env9492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env9491 == env9492) = true)

theorem identity9492 : scanCanonicalize (H12AffineFastState.compose env9492 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 79374) := by decide +kernel

theorem selectedBound9492 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env9493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,4194304,525805,16777216,8329,79374,134217728,138678440,138678612,151259274,17307206,155451870,525568,151257258,136582893,16778206]

theorem envBound9493 : H12AffineFastState.Bounded env9493 := by
  intro p hp
  have h : env9493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9492_9493 : H12AffineEnvironment.transform 25 79374 env9492 = env9493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 79374 env9492 == env9493) = true)

def env9494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79374,134217728,134500812,134500400,151259274,17307206,151273658,525568,151257258,136582893,16778206]

theorem envBound9494 : H12AffineFastState.Bounded env9494 := by
  intro p hp
  have h : env9494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9493_9494 : H12AffineEnvironment.transform 21 16740 env9493 = env9494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16740 env9493 == env9494) = true)

def env9495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79374,279904,5292,5456,16797162,17307206,16778714,525568,16795082,2118541,16778206]

theorem envBound9495 : H12AffineFastState.Bounded env9495 := by
  intro p hp
  have h : env9495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9494_9495 : H12AffineEnvironment.transform 26 279904 env9494 = env9495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279904 env9494 == env9495) = true)

def env9496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,91616,8329,79374,279904,5292,5456,75786,619430,90170,525568,73770,2118541,91710]

theorem envBound9496 : H12AffineFastState.Bounded env9496 := by
  intro p hp
  have h : env9496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9495_9496 : H12AffineEnvironment.transform 23 91616 env9495 = env9496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env9495 == env9496) = true)

theorem identity9496 : scanCanonicalize (H12AffineFastState.compose env9496 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9496 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9497 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91165,8329,79374,279709,5292,5293,75786,619099,90170,525565,73770,2118256,91710]

theorem envBound9497 : H12AffineFastState.Bounded env9497 := by
  intro p hp
  have h : env9497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9496_9497 : H12AffineEnvironment.transform 7 253 env9496 = env9497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9496 == env9497) = true)

def env9498 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91165,8329,78958,279709,5292,5293,75786,618555,90170,525565,73770,2117648,91230]

theorem envBound9498 : H12AffineFastState.Bounded env9498 := by
  intro p hp
  have h : env9498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9497_9498 : H12AffineEnvironment.transform 8 96 env9497 = env9498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9497 == env9498) = true)

theorem identity9498 : scanCanonicalize (H12AffineFastState.compose env9498 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound9498 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9499 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9263,4096,262144,524288,8200,2097152,16537,525328,16434,8329,4161,279709,5292,5293,3109,545812,17429,525565,1029,2117648,16497]

theorem envBound9499 : H12AffineFastState.Bounded env9499 := by
  intro p hp
  have h : env9499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9498_9499 : H12AffineEnvironment.transform 15 9263 env9498 = env9499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env9498 == env9499) = true)

theorem identity9499 : scanCanonicalize (H12AffineFastState.compose env9499 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545021) := by decide +kernel

theorem selectedBound9499 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9500 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9263,4096,262144,524288,8200,545021,16537,525328,16434,8329,4161,279709,5292,5293,3109,545812,17429,525565,1029,524525,16497]

theorem envBound9500 : H12AffineFastState.Bounded env9500 := by
  intro p hp
  have h : env9500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9499_9500 : H12AffineEnvironment.transform 20 545021 env9499 = env9500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545021 env9499 == env9500) = true)

theorem identity9500 : scanCanonicalize (H12AffineFastState.compose env9500 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282655) := by decide +kernel

theorem selectedBound9500 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env9501 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9263,4096,262144,282655,8200,262370,16537,283663,16434,8329,4161,279709,5292,5293,3109,263179,17429,283874,1029,282866,16497]

theorem envBound9501 : H12AffineFastState.Bounded env9501 := by
  intro p hp
  have h : env9501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9500_9501 : H12AffineEnvironment.transform 18 282655 env9500 = env9501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282655 env9500 == env9501) = true)

theorem identity9501 : scanCanonicalize (H12AffineFastState.compose env9501 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17591) := by decide +kernel

theorem selectedBound9501 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9502 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9263,4096,17591,5288,8200,17493,16537,4280,16434,8329,4161,42,5292,5293,3109,16572,17429,4181,1029,5189,16497]

theorem envBound9502 : H12AffineFastState.Bounded env9502 := by
  intro p hp
  have h : env9502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9501_9502 : H12AffineEnvironment.transform 17 17591 env9501 = env9502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17591 env9501 == env9502) = true)

theorem identity9502 : scanCanonicalize (H12AffineFastState.compose env9502 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9502 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9503 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8200,9263,4096,1191,5288,8200,1093,137,4280,34,8329,4161,42,5292,5293,3109,172,1029,4181,1029,5189,97]

theorem envBound9503 : H12AffineFastState.Bounded env9503 := by
  intro p hp
  have h : env9503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9502_9503 : H12AffineEnvironment.transform 13 16 env9502 = env9503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9502 == env9503) = true)

def env9504 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91165,8329,78959,279709,5292,5293,75786,618554,90170,525565,73770,2117649,91231]

theorem envBound9504 : H12AffineFastState.Bounded env9504 := by
  intro p hp
  have h : env9504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9497_9504 : H12AffineEnvironment.transform 8 97 env9497 = env9504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9497 == env9504) = true)

theorem identity9504 : scanCanonicalize (H12AffineFastState.compose env9504 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound9504 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9505 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,25662,4096,262144,524288,8200,2097152,16537,525328,35,8329,20561,279709,5292,5293,19508,529412,1028,525565,17428,2117649,97]

theorem envBound9505 : H12AffineFastState.Bounded env9505 := by
  intro p hp
  have h : env9505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9504_9505 : H12AffineEnvironment.transform 15 25662 env9504 = env9505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env9504 == env9505) = true)

theorem identity9505 : scanCanonicalize (H12AffineFastState.compose env9505 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9505 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9506 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8200,9262,4096,262144,524288,8200,2097152,137,525328,35,8329,4161,263309,5292,5293,3108,529412,1028,525565,1028,2101249,97]

theorem envBound9506 : H12AffineFastState.Bounded env9506 := by
  intro p hp
  have h : env9506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9505_9506 : H12AffineEnvironment.transform 13 16 env9505 = env9506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9505 == env9506) = true)

theorem identity9506 : scanCanonicalize (H12AffineFastState.compose env9506 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound9506 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9507 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8200,9262,4096,262144,524288,8200,529640,137,525328,35,8329,4161,263309,5292,5293,3108,529412,1028,525565,1028,525545,97]

theorem envBound9507 : H12AffineFastState.Bounded env9507 := by
  intro p hp
  have h : env9507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9506_9507 : H12AffineEnvironment.transform 20 529640 env9506 = env9507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env9506 == env9507) = true)

theorem identity9507 : scanCanonicalize (H12AffineFastState.compose env9507 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13472) := by decide +kernel

theorem selectedBound9507 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9508 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8200,9262,4096,262144,13472,8200,8264,137,12464,35,8329,4161,263309,5292,5293,3108,8356,1028,12381,1028,12361,97]

theorem envBound9508 : H12AffineFastState.Bounded env9508 := by
  intro p hp
  have h : env9508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9507_9508 : H12AffineEnvironment.transform 18 13472 env9507 = env9508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13472 env9507 == env9508) = true)

theorem identity9508 : scanCanonicalize (H12AffineFastState.compose env9508 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9287) := by decide +kernel

theorem selectedBound9508 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9509 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8200,9262,4096,9287,13472,8200,8264,137,12464,35,8329,4161,8394,5292,5293,3108,8356,1028,12381,1028,12361,97]

theorem envBound9509 : H12AffineFastState.Bounded env9509 := by
  intro p hp
  have h : env9509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9508_9509 : H12AffineEnvironment.transform 17 9287 env9508 = env9509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9287 env9508 == env9509) = true)

theorem identity9509 : scanCanonicalize (H12AffineFastState.compose env9509 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9509 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env9510 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8,16,0,1062,4096,1103,5288,0,64,137,4280,35,129,4161,194,5292,5293,3108,172,1028,4181,1028,4161,97]

theorem envBound9510 : H12AffineFastState.Bounded env9510 := by
  intro p hp
  have h : env9510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9509_9510 : H12AffineEnvironment.transform 12 8 env9509 = env9510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9509 == env9510) = true)

theorem identity9510 : scanCanonicalize (H12AffineFastState.compose env9510 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9510 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9511 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,4096,8,16,0,1062,4096,1103,5120,0,64,33,4112,35,41,4161,106,5124,5125,3108,4,1028,4181,1028,4161,97]

theorem envBound9511 : H12AffineFastState.Bounded env9511 := by
  intro p hp
  have h : env9511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9510_9511 : H12AffineEnvironment.transform 6 40 env9510 = env9511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9510 == env9511) = true)

theorem identity9511 : scanCanonicalize (H12AffineFastState.compose env9511 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound9511 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env9512 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,1108,8,16,0,1062,1108,1103,84,0,64,33,1092,35,41,1045,106,80,81,3108,4,1028,1025,1028,1045,97]

theorem envBound9512 : H12AffineFastState.Bounded env9512 := by
  intro p hp
  have h : env9512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9511_9512 : H12AffineEnvironment.transform 11 1108 env9511 = env9512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env9511 == env9512) = true)

def env9513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,91617,8329,79374,279904,5292,5456,75787,619431,90171,525568,73771,2118541,91711]

theorem envBound9513 : H12AffineFastState.Bounded env9513 := by
  intro p hp
  have h : env9513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9495_9513 : H12AffineEnvironment.transform 23 91617 env9495 = env9513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env9495 == env9513) = true)

theorem identity9513 : scanCanonicalize (H12AffineFastState.compose env9513 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26050) := by decide +kernel

theorem selectedBound9513 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,2097152,16740,525805,35,8329,21452,279904,5292,5456,19913,530021,1529,525568,17897,2118541,1021]

theorem envBound9514 : H12AffineFastState.Bounded env9514 := by
  intro p hp
  have h : env9514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9513_9514 : H12AffineEnvironment.transform 15 26050 env9513 = env9514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26050 env9513 == env9514) = true)

def env9515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,529264,16740,525805,35,8329,21452,279904,5292,5456,19913,530021,1529,525568,17897,540925,1021]

theorem envBound9515 : H12AffineFastState.Bounded env9515 := by
  intro p hp
  have h : env9515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9514_9515 : H12AffineEnvironment.transform 20 529264 env9514 = env9515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env9514 == env9515) = true)

theorem identity9515 : scanCanonicalize (H12AffineFastState.compose env9515 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9515 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9516 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,25663,4096,262144,524288,8200,529037,16537,525328,35,8329,21041,279709,5292,5293,19508,530021,1028,525565,17428,540925,512]

theorem envBound9516 : H12AffineFastState.Bounded env9516 := by
  intro p hp
  have h : env9516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9515_9516 : H12AffineEnvironment.transform 7 253 env9515 = env9516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9515 == env9516) = true)

theorem identity9516 : scanCanonicalize (H12AffineFastState.compose env9516 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9516 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9517 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,17,8200,9262,4096,262144,524288,8200,529037,136,525328,35,8329,4640,263308,5292,5293,3109,530021,1028,525565,1029,524524,512]

theorem envBound9517 : H12AffineFastState.Bounded env9517 := by
  intro p hp
  have h : env9517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9516_9517 : H12AffineEnvironment.transform 13 17 env9516 = env9517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9516 == env9517) = true)

theorem identity9517 : scanCanonicalize (H12AffineFastState.compose env9517 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9517 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9518 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8200,8234,4096,262144,524288,8200,529037,136,524308,35,8329,4640,262280,4264,4265,2081,528993,0,524537,1,524524,512]

theorem envBound9518 : H12AffineFastState.Bounded env9518 := by
  intro p hp
  have h : env9518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9517_9518 : H12AffineEnvironment.transform 9 4 env9517 = env9518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9517 == env9518) = true)

theorem identity9518 : scanCanonicalize (H12AffineFastState.compose env9518 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4269) := by decide +kernel

theorem selectedBound9518 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9519 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8200,8234,4096,262144,4269,8200,544,136,4281,35,8329,4640,262280,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9519 : H12AffineFastState.Bounded env9519 := by
  intro p hp
  have h : env9519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9518_9519 : H12AffineEnvironment.transform 18 4269 env9518 = env9519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4269 env9518 == env9519) = true)

theorem identity9519 : scanCanonicalize (H12AffineFastState.compose env9519 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14545) := by decide +kernel

theorem selectedBound9519 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9520 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8200,8234,4096,14545,4269,8200,544,136,4281,35,8329,4640,14425,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9520 : H12AffineFastState.Bounded env9520 := by
  intro p hp
  have h : env9520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9519_9520 : H12AffineEnvironment.transform 17 14545 env9519 = env9520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14545 env9519 == env9520) = true)

theorem identity9520 : scanCanonicalize (H12AffineFastState.compose env9520 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6906) := by decide +kernel

theorem selectedBound9520 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9521 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,6906,17,6898,6864,4096,555,4269,6898,544,136,4281,35,6771,4640,675,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9521 : H12AffineFastState.Bounded env9521 := by
  intro p hp
  have h : env9521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9520_9521 : H12AffineEnvironment.transform 12 6906 env9520 = env9521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6906 env9520 == env9521) = true)

theorem identity9521 : scanCanonicalize (H12AffineFastState.compose env9521 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound9521 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env9522 : List Nat := [2,4,8,16,32,64,128,253,96,4,2048,4096,6298,17,6290,6320,4096,75,4269,6290,64,136,4281,35,6163,4160,195,4264,4265,2081,172,0,4180,1,4161,96]

theorem envBound9522 : H12AffineFastState.Bounded env9522 := by
  intro p hp
  have h : env9522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9521_9522 : H12AffineEnvironment.transform 8 96 env9521 = env9522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9521 == env9522) = true)

theorem identity9522 : scanCanonicalize (H12AffineFastState.compose env9522 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound9522 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9523 : List Nat := [2,4,8,16,32,64,128,253,96,4,26,4096,4224,17,4232,4266,4096,75,4269,4232,64,136,4281,35,4105,4160,195,4264,4265,59,172,0,4180,1,4161,96]

theorem envBound9523 : H12AffineFastState.Bounded env9523 := by
  intro p hp
  have h : env9523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9522_9523 : H12AffineEnvironment.transform 10 26 env9522 = env9523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env9522 == env9523) = true)

theorem identity9523 : scanCanonicalize (H12AffineFastState.compose env9523 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound9523 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9524 : List Nat := [2,4,8,16,32,64,128,253,96,4,26,81,209,17,217,251,81,75,252,217,64,136,232,35,88,17,195,249,248,59,172,0,5,1,16,96]

theorem envBound9524 : H12AffineFastState.Bounded env9524 := by
  intro p hp
  have h : env9524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9523_9524 : H12AffineEnvironment.transform 11 81 env9523 = env9524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env9523 == env9524) = true)

theorem identity9524 : scanCanonicalize (H12AffineFastState.compose env9524 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9524 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9525 : List Nat := [2,4,8,16,32,64,88,37,96,4,26,81,9,17,1,35,81,75,36,1,64,80,48,35,88,17,27,33,32,59,116,0,5,1,16,96]

theorem envBound9525 : H12AffineFastState.Bounded env9525 := by
  intro p hp
  have h : env9525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9524_9525 : H12AffineEnvironment.transform 6 88 env9524 = env9525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9524 == env9525) = true)

theorem identity9525 : scanCanonicalize (H12AffineFastState.compose env9525 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9525 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env9526 : List Nat := [2,4,8,16,32,48,40,37,16,4,26,33,9,17,1,35,33,59,36,1,48,32,48,35,40,17,27,33,32,59,4,0,5,1,16,16]

theorem envBound9526 : H12AffineFastState.Bounded env9526 := by
  intro p hp
  have h : env9526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9525_9526 : H12AffineEnvironment.transform 5 48 env9525 = env9526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9525 == env9526) = true)

theorem identity9526 : scanCanonicalize (H12AffineFastState.compose env9526 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9526 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9527 : List Nat := [2,4,8,16,27,11,19,30,16,4,26,26,9,17,1,24,26,0,31,1,11,27,11,24,19,17,27,26,27,0,4,0,5,1,16,16]

theorem envBound9527 : H12AffineFastState.Bounded env9527 := by
  intro p hp
  have h : env9527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9526_9527 : H12AffineEnvironment.transform 4 27 env9526 = env9527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9526 == env9527) = true)

theorem identity9527 : scanCanonicalize (H12AffineFastState.compose env9527 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9528 : List Nat := [2,4,3,16,16,0,19,21,16,4,17,17,2,17,1,19,17,0,20,1,0,16,0,19,19,17,16,17,16,0,4,0,5,1,16,16]

theorem envBound9528 : H12AffineFastState.Bounded env9528 := by
  intro p hp
  have h : env9528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9527_9528 : H12AffineEnvironment.transform 2 3 env9527 = env9528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9527 == env9528) = true)

def leafEnv9528 : List Nat := [2,4,3,16,16,0,19,21,16,4,17,17,2,17,1,19,17,0,20,1,0,16,0,19,20,19,1,17,16,17,16,0,4,0,5,1,20,3,16,16,1,0,0]

def active9528 : List Nat := [0,1,3]

def tree9528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9528 : H12WitnessSearch.Good tree9528 := H12GlobalWitnessIndex.good

theorem leafIdentity9528 : H12AffineFastState.composeSystem env9528 rootObs = leafEnv9528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9528 rootObs == leafEnv9528) = true)

theorem terminalChecked9528 : H12PackedTerminal.terminalCheckFast leafEnv9528 active9528 tree9528 = true := by decide +kernel

def env9529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,529265,16740,525805,35,8329,21452,279904,5292,5456,19913,530021,1529,525568,17897,540924,1021]

theorem envBound9529 : H12AffineFastState.Bounded env9529 := by
  intro p hp
  have h : env9529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9514_9529 : H12AffineEnvironment.transform 20 529265 env9514 = env9529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env9514 == env9529) = true)

def env9530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,4432,8693,545,16740,5309,35,8329,21452,279904,5292,5456,19913,1845,1529,5200,17897,20908,1021]

theorem envBound9530 : H12AffineFastState.Bounded env9530 := by
  intro p hp
  have h : env9530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9529_9530 : H12AffineEnvironment.transform 18 4432 env9529 = env9530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env9529 == env9530) = true)

theorem identity9530 : scanCanonicalize (H12AffineFastState.compose env9530 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9530 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,9683,4605,262144,4432,8693,545,373,5309,35,8329,5085,263537,5292,5456,3544,1845,1529,5200,1528,4541,1021]

theorem envBound9531 : H12AffineFastState.Bounded env9531 := by
  intro p hp
  have h : env9531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9530_9531 : H12AffineEnvironment.transform 13 17 env9530 = env9531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9530 == env9531) = true)

theorem identity9531 : scanCanonicalize (H12AffineFastState.compose env9531 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound9531 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9532 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,17,8693,9143,4605,262144,4432,8693,545,373,4825,35,8329,5085,262933,4808,4916,3004,337,925,4660,924,4541,1021]

theorem envBound9532 : H12AffineFastState.Bounded env9532 := by
  intro p hp
  have h : env9532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9531_9532 : H12AffineEnvironment.transform 9 612 env9531 = env9532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env9531 == env9532) = true)

theorem identity9532 : scanCanonicalize (H12AffineFastState.compose env9532 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7148) := by decide +kernel

theorem selectedBound9532 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9533 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,17,8693,9143,4605,7148,4432,8693,545,373,4825,35,8329,5085,6393,4808,4916,3004,337,925,4660,924,4541,1021]

theorem envBound9533 : H12AffineFastState.Bounded env9533 := by
  intro p hp
  have h : env9533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9532_9533 : H12AffineEnvironment.transform 17 7148 env9532 = env9533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7148 env9532 == env9533) = true)

theorem identity9533 : scanCanonicalize (H12AffineFastState.compose env9533 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound9533 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env9534 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,664,8192,17,8693,9143,869,2420,968,8693,545,373,65,35,8329,325,2657,80,428,3004,337,925,172,924,805,1021]

theorem envBound9534 : H12AffineFastState.Bounded env9534 := by
  intro p hp
  have h : env9534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9533_9534 : H12AffineEnvironment.transform 11 664 env9533 = env9534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env9533 == env9534) = true)

theorem identity9534 : scanCanonicalize (H12AffineFastState.compose env9534 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 492) := by decide +kernel

theorem selectedBound9534 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9535 : List Nat := [2,4,8,16,32,64,128,256,492,392,2048,372,8192,17,8693,8283,137,2420,36,8693,461,373,65,35,8329,325,2445,80,428,2128,337,113,172,112,201,17]

theorem envBound9535 : H12AffineFastState.Bounded env9535 := by
  intro p hp
  have h : env9535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9534_9535 : H12AffineEnvironment.transform 8 492 env9534 = env9535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 492 env9534 == env9535) = true)

theorem identity9535 : scanCanonicalize (H12AffineFastState.compose env9535 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9535 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env9536 : List Nat := [2,4,8,16,32,64,128,85,185,221,2048,33,8192,17,8352,8283,137,2081,36,8352,152,32,65,35,8329,16,2264,80,249,2128,4,113,172,112,201,17]

theorem envBound9536 : H12AffineFastState.Bounded env9536 := by
  intro p hp
  have h : env9536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9535_9536 : H12AffineEnvironment.transform 7 85 env9535 = env9536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9535 == env9536) = true)

theorem identity9536 : scanCanonicalize (H12AffineFastState.compose env9536 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound9536 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env9537 : List Nat := [2,4,8,16,32,64,128,85,185,221,136,33,8192,17,8352,8283,137,169,36,8352,152,32,65,35,8329,16,80,80,249,216,4,113,172,112,201,17]

theorem envBound9537 : H12AffineFastState.Bounded env9537 := by
  intro p hp
  have h : env9537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9536_9537 : H12AffineEnvironment.transform 10 136 env9536 = env9537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env9536 == env9537) = true)

theorem identity9537 : scanCanonicalize (H12AffineFastState.compose env9537 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound9537 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9538 : List Nat := [2,4,8,16,32,64,128,85,185,221,136,33,154,17,58,193,137,169,36,58,152,32,65,35,19,16,80,80,249,216,4,113,172,112,201,17]

theorem envBound9538 : H12AffineFastState.Bounded env9538 := by
  intro p hp
  have h : env9538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9537_9538 : H12AffineEnvironment.transform 12 154 env9537 = env9538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env9537 == env9538) = true)

theorem identity9538 : scanCanonicalize (H12AffineFastState.compose env9538 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9538 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env9539 : List Nat := [2,4,8,16,32,11,128,30,185,150,136,33,154,17,58,138,137,169,36,58,152,32,10,35,19,16,27,27,178,147,4,58,172,59,130,17]

theorem envBound9539 : H12AffineFastState.Bounded env9539 := by
  intro p hp
  have h : env9539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9538_9539 : H12AffineEnvironment.transform 5 11 env9538 = env9539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9538 == env9539) = true)

theorem identity9539 : scanCanonicalize (H12AffineFastState.compose env9539 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9539 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env9540 : List Nat := [2,4,8,16,32,11,19,30,42,5,27,33,9,17,58,25,26,58,36,58,11,32,10,35,19,16,27,27,33,0,4,58,63,59,17,17]

theorem envBound9540 : H12AffineFastState.Bounded env9540 := by
  intro p hp
  have h : env9540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9539_9540 : H12AffineEnvironment.transform 6 19 env9539 = env9540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9539 == env9540) = true)

theorem identity9540 : scanCanonicalize (H12AffineFastState.compose env9540 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9540 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9541 : List Nat := [2,4,8,16,17,11,19,30,27,5,27,16,9,17,11,25,26,11,21,11,11,17,10,18,19,16,27,27,16,0,4,11,14,10,17,17]

theorem envBound9541 : H12AffineFastState.Bounded env9541 := by
  intro p hp
  have h : env9541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9540_9541 : H12AffineEnvironment.transform 4 17 env9540 = env9541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9540 == env9541) = true)

theorem identity9541 : scanCanonicalize (H12AffineFastState.compose env9541 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9541 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9542 : List Nat := [2,4,2,16,17,1,19,20,17,5,17,16,3,17,1,19,16,1,21,1,1,17,0,18,19,16,17,17,16,0,4,1,4,0,17,17]

theorem envBound9542 : H12AffineFastState.Bounded env9542 := by
  intro p hp
  have h : env9542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9541_9542 : H12AffineEnvironment.transform 2 2 env9541 = env9542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9541 == env9542) = true)

def leafEnv9542 : List Nat := [2,4,2,16,17,1,19,20,17,5,17,16,3,17,1,19,16,1,21,1,1,17,0,18,20,19,1,16,17,17,16,0,4,1,4,0,20,2,17,17,1,0,0]

def active9542 : List Nat := [0,1,3]

def tree9542 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9542 : H12WitnessSearch.Good tree9542 := H12GlobalWitnessIndex.good

theorem leafIdentity9542 : H12AffineFastState.composeSystem env9542 rootObs = leafEnv9542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9542 rootObs == leafEnv9542) = true)

theorem terminalChecked9542 : H12PackedTerminal.terminalCheckFast leafEnv9542 active9542 tree9542 = true := by decide +kernel

def env9543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,4433,8693,544,16740,5308,35,8329,21452,279904,5292,5456,19913,1844,1529,5201,17897,20909,1021]

theorem envBound9543 : H12AffineFastState.Bounded env9543 := by
  intro p hp
  have h : env9543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9529_9543 : H12AffineEnvironment.transform 18 4433 env9529 = env9543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env9529 == env9543) = true)

theorem identity9543 : scanCanonicalize (H12AffineFastState.compose env9543 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 492) := by decide +kernel

theorem selectedBound9543 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,492,8693,9262,4605,262144,4433,8693,544,136,5308,35,8329,4640,263308,5292,5456,3109,1844,1529,5201,1029,4161,1021]

theorem envBound9544 : H12AffineFastState.Bounded env9544 := by
  intro p hp
  have h : env9544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9543_9544 : H12AffineEnvironment.transform 13 492 env9543 = env9544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 492 env9543 == env9544) = true)

theorem identity9544 : scanCanonicalize (H12AffineFastState.compose env9544 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9544 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9545 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,8192,492,8693,8235,4605,262144,4433,8693,544,136,4281,35,8329,4640,262281,4265,4437,2080,817,508,4180,0,4161,1021]

theorem envBound9545 : H12AffineFastState.Bounded env9545 := by
  intro p hp
  have h : env9545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9544_9545 : H12AffineEnvironment.transform 9 5 env9544 = env9545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9544 == env9545) = true)

theorem identity9545 : scanCanonicalize (H12AffineFastState.compose env9545 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9545 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9546 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8200,8235,4096,262144,4268,8200,544,136,4281,35,8329,4640,262281,4265,4264,2080,716,1,4180,0,4161,512]

theorem envBound9546 : H12AffineFastState.Bounded env9546 := by
  intro p hp
  have h : env9546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9545_9546 : H12AffineEnvironment.transform 7 253 env9545 = env9546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9545 == env9546) = true)

def env9547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,16777216,8329,79374,279905,5293,5457,16797163,17307206,16778715,525568,16795083,2118540,16778206]

theorem envBound9547 : H12AffineFastState.Bounded env9547 := by
  intro p hp
  have h : env9547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9494_9547 : H12AffineEnvironment.transform 26 279905 env9494 = env9547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279905 env9494 == env9547) = true)

def env9548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,91616,8329,79374,279905,5293,5457,75787,619430,90171,525568,73771,2118540,91710]

theorem envBound9548 : H12AffineFastState.Bounded env9548 := by
  intro p hp
  have h : env9548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9547_9548 : H12AffineEnvironment.transform 23 91616 env9547 = env9548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env9547 == env9548) = true)

theorem identity9548 : scanCanonicalize (H12AffineFastState.compose env9548 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound9548 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,2097152,16740,525805,35,8329,21453,279905,5293,5457,19912,530021,1528,525568,17896,2118540,1021]

theorem envBound9549 : H12AffineFastState.Bounded env9549 := by
  intro p hp
  have h : env9549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9548_9549 : H12AffineEnvironment.transform 15 26051 env9548 = env9549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env9548 == env9549) = true)

def env9550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,529264,16740,525805,35,8329,21453,279905,5293,5457,19912,530021,1528,525568,17896,540924,1021]

theorem envBound9550 : H12AffineFastState.Bounded env9550 := by
  intro p hp
  have h : env9550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9549_9550 : H12AffineEnvironment.transform 20 529264 env9549 = env9550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env9549 == env9550) = true)

theorem identity9550 : scanCanonicalize (H12AffineFastState.compose env9550 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9550 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9551 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,25662,4096,262144,524288,8200,529037,16537,525328,35,8329,21040,279708,5293,5292,19509,530021,1029,525565,17429,540924,512]

theorem envBound9551 : H12AffineFastState.Bounded env9551 := by
  intro p hp
  have h : env9551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9550_9551 : H12AffineEnvironment.transform 7 253 env9550 = env9551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9550 == env9551) = true)

theorem identity9551 : scanCanonicalize (H12AffineFastState.compose env9551 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9551 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9552 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,17,8200,9263,4096,262144,524288,8200,529037,136,525328,35,8329,4641,263309,5293,5292,3108,530021,1029,525565,1028,524525,512]

theorem envBound9552 : H12AffineFastState.Bounded env9552 := by
  intro p hp
  have h : env9552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9551_9552 : H12AffineEnvironment.transform 13 17 env9551 = env9552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9551 == env9552) = true)

theorem identity9552 : scanCanonicalize (H12AffineFastState.compose env9552 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9552 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9553 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8200,8234,4096,262144,524288,8200,529037,136,524309,35,8329,4641,262280,4264,4265,2081,528992,0,524536,1,524525,512]

theorem envBound9553 : H12AffineFastState.Bounded env9553 := by
  intro p hp
  have h : env9553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9552_9553 : H12AffineEnvironment.transform 9 5 env9552 = env9553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9552 == env9553) = true)

theorem identity9553 : scanCanonicalize (H12AffineFastState.compose env9553 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4268) := by decide +kernel

theorem selectedBound9553 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9554 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8200,8234,4096,262144,4268,8200,545,136,4281,35,8329,4641,262280,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9554 : H12AffineFastState.Bounded env9554 := by
  intro p hp
  have h : env9554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9553_9554 : H12AffineEnvironment.transform 18 4268 env9553 = env9554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4268 env9553 == env9554) = true)

theorem identity9554 : scanCanonicalize (H12AffineFastState.compose env9554 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14545) := by decide +kernel

theorem selectedBound9554 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9555 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,17,8200,8234,4096,14545,4268,8200,545,136,4281,35,8329,4641,14425,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9555 : H12AffineFastState.Bounded env9555 := by
  intro p hp
  have h : env9555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9554_9555 : H12AffineEnvironment.transform 17 14545 env9554 = env9555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14545 env9554 == env9555) = true)

theorem identity9555 : scanCanonicalize (H12AffineFastState.compose env9555 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6906) := by decide +kernel

theorem selectedBound9555 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9556 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,6906,17,6898,6864,4096,555,4268,6898,545,136,4281,35,6771,4641,675,4264,4265,2081,716,0,4180,1,4161,512]

theorem envBound9556 : H12AffineFastState.Bounded env9556 := by
  intro p hp
  have h : env9556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9555_9556 : H12AffineEnvironment.transform 12 6906 env9555 = env9556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6906 env9555 == env9556) = true)

theorem identity9556 : scanCanonicalize (H12AffineFastState.compose env9556 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound9556 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env9557 : List Nat := [2,4,8,16,32,64,128,253,97,5,2048,4096,6299,17,6291,6321,4096,74,4268,6291,64,136,4281,35,6162,4160,194,4264,4265,2081,173,0,4180,1,4161,97]

theorem envBound9557 : H12AffineFastState.Bounded env9557 := by
  intro p hp
  have h : env9557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9556_9557 : H12AffineEnvironment.transform 8 97 env9556 = env9557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9556 == env9557) = true)

theorem identity9557 : scanCanonicalize (H12AffineFastState.compose env9557 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound9557 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9558 : List Nat := [2,4,8,16,32,64,128,253,97,5,27,4096,4224,17,4232,4266,4096,74,4268,4232,64,136,4281,35,4105,4160,194,4264,4265,58,173,0,4180,1,4161,97]

theorem envBound9558 : H12AffineFastState.Bounded env9558 := by
  intro p hp
  have h : env9558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9557_9558 : H12AffineEnvironment.transform 10 27 env9557 = env9558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env9557 == env9558) = true)

theorem identity9558 : scanCanonicalize (H12AffineFastState.compose env9558 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound9558 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9559 : List Nat := [2,4,8,16,32,64,128,253,97,5,27,81,209,17,217,251,81,74,253,217,64,136,232,35,88,17,194,249,248,58,173,0,5,1,16,97]

theorem envBound9559 : H12AffineFastState.Bounded env9559 := by
  intro p hp
  have h : env9559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9558_9559 : H12AffineEnvironment.transform 11 81 env9558 = env9559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env9558 == env9559) = true)

theorem identity9559 : scanCanonicalize (H12AffineFastState.compose env9559 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9559 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9560 : List Nat := [2,4,8,16,32,64,40,85,97,5,27,81,121,17,113,83,81,74,85,113,64,32,64,35,88,17,106,81,80,58,5,0,5,1,16,97]

theorem envBound9560 : H12AffineFastState.Bounded env9560 := by
  intro p hp
  have h : env9560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9559_9560 : H12AffineEnvironment.transform 6 40 env9559 = env9560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9559 == env9560) = true)

theorem identity9560 : scanCanonicalize (H12AffineFastState.compose env9560 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9561 : List Nat := [2,4,8,16,27,64,19,85,90,5,27,81,66,17,74,83,81,74,85,74,64,27,64,24,88,17,81,81,80,1,5,0,5,1,16,90]

theorem envBound9561 : H12AffineFastState.Bounded env9561 := by
  intro p hp
  have h : env9561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9560_9561 : H12AffineEnvironment.transform 4 27 env9560 = env9561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9560 == env9561) = true)

theorem identity9561 : scanCanonicalize (H12AffineFastState.compose env9561 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9561 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9562 : List Nat := [2,4,8,16,27,1,19,20,27,5,27,16,3,17,11,18,16,11,20,11,1,27,1,24,25,17,16,16,17,1,5,0,5,1,16,27]

theorem envBound9562 : H12AffineFastState.Bounded env9562 := by
  intro p hp
  have h : env9562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9561_9562 : H12AffineEnvironment.transform 5 1 env9561 = env9562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9561 == env9562) = true)

theorem identity9562 : scanCanonicalize (H12AffineFastState.compose env9562 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9563 : List Nat := [2,4,2,16,17,1,19,20,17,5,17,16,3,17,1,18,16,1,20,1,1,17,1,18,19,17,16,16,17,1,5,0,5,1,16,17]

theorem envBound9563 : H12AffineFastState.Bounded env9563 := by
  intro p hp
  have h : env9563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9562_9563 : H12AffineEnvironment.transform 2 2 env9562 = env9563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9562 == env9563) = true)

def leafEnv9563 : List Nat := [2,4,2,16,17,1,19,20,17,5,17,16,3,17,1,18,16,1,20,1,1,17,1,18,20,19,1,17,16,16,17,1,5,0,5,1,21,3,16,17,1,1,0]

def active9563 : List Nat := [0,1,3]

def tree9563 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9563 : H12WitnessSearch.Good tree9563 := H12GlobalWitnessIndex.good

theorem leafIdentity9563 : H12AffineFastState.composeSystem env9563 rootObs = leafEnv9563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9563 rootObs == leafEnv9563) = true)

theorem terminalChecked9563 : H12PackedTerminal.terminalCheckFast leafEnv9563 active9563 tree9563 = true := by decide +kernel

def env9564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,529265,16740,525805,35,8329,21453,279905,5293,5457,19912,530021,1528,525568,17896,540925,1021]

theorem envBound9564 : H12AffineFastState.Bounded env9564 := by
  intro p hp
  have h : env9564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9549_9564 : H12AffineEnvironment.transform 20 529265 env9549 = env9564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env9549 == env9564) = true)

def env9565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,4432,8693,545,16740,5309,35,8329,21453,279905,5293,5457,19912,1845,1528,5200,17896,20909,1021]

theorem envBound9565 : H12AffineFastState.Bounded env9565 := by
  intro p hp
  have h : env9565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9564_9565 : H12AffineEnvironment.transform 18 4432 env9564 = env9565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env9564 == env9565) = true)

theorem identity9565 : scanCanonicalize (H12AffineFastState.compose env9565 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 492) := by decide +kernel

theorem selectedBound9565 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,492,8693,9263,4605,262144,4432,8693,545,136,5309,35,8329,4641,263309,5293,5457,3108,1845,1528,5200,1028,4161,1021]

theorem envBound9566 : H12AffineFastState.Bounded env9566 := by
  intro p hp
  have h : env9566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9565_9566 : H12AffineEnvironment.transform 13 492 env9565 = env9566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 492 env9565 == env9566) = true)

theorem identity9566 : scanCanonicalize (H12AffineFastState.compose env9566 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9566 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9567 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,492,8693,8235,4605,262144,4432,8693,545,136,4281,35,8329,4641,262281,4265,4437,2080,817,508,4180,0,4161,1021]

theorem envBound9567 : H12AffineFastState.Bounded env9567 := by
  intro p hp
  have h : env9567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9566_9567 : H12AffineEnvironment.transform 9 4 env9566 = env9567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9566 == env9567) = true)

theorem identity9567 : scanCanonicalize (H12AffineFastState.compose env9567 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9567 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9568 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,17,8200,8235,4096,262144,4269,8200,545,136,4281,35,8329,4641,262281,4265,4264,2080,716,1,4180,0,4161,512]

theorem envBound9568 : H12AffineFastState.Bounded env9568 := by
  intro p hp
  have h : env9568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9567_9568 : H12AffineEnvironment.transform 7 253 env9567 = env9568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9567 == env9568) = true)

def env9569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,4433,8693,544,16740,5308,35,8329,21453,279905,5293,5457,19912,1844,1528,5201,17896,20908,1021]

theorem envBound9569 : H12AffineFastState.Bounded env9569 := by
  intro p hp
  have h : env9569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9564_9569 : H12AffineEnvironment.transform 18 4433 env9564 = env9569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env9564 == env9569) = true)

theorem identity9569 : scanCanonicalize (H12AffineFastState.compose env9569 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9569 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,17,8693,9682,4605,262144,4433,8693,544,373,5308,35,8329,5084,263536,5293,5457,3545,1844,1528,5201,1529,4541,1021]

theorem envBound9570 : H12AffineFastState.Bounded env9570 := by
  intro p hp
  have h : env9570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9569_9570 : H12AffineEnvironment.transform 13 17 env9569 = env9570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9569 == env9570) = true)

theorem identity9570 : scanCanonicalize (H12AffineFastState.compose env9570 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound9570 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9571 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,17,8693,9142,4605,262144,4433,8693,544,373,4824,35,8329,5084,262932,4809,4917,3005,336,924,4661,925,4541,1021]

theorem envBound9571 : H12AffineFastState.Bounded env9571 := by
  intro p hp
  have h : env9571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9570_9571 : H12AffineEnvironment.transform 9 612 env9570 = env9571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env9570 == env9571) = true)

theorem identity9571 : scanCanonicalize (H12AffineFastState.compose env9571 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7149) := by decide +kernel

theorem selectedBound9571 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9572 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,4096,8192,17,8693,9142,4605,7149,4433,8693,544,373,4824,35,8329,5084,6393,4809,4917,3005,336,924,4661,925,4541,1021]

theorem envBound9572 : H12AffineFastState.Bounded env9572 := by
  intro p hp
  have h : env9572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9571_9572 : H12AffineEnvironment.transform 17 7149 env9571 = env9572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7149 env9571 == env9572) = true)

theorem identity9572 : scanCanonicalize (H12AffineFastState.compose env9572 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound9572 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env9573 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,665,8192,17,8693,9142,868,2420,968,8693,544,373,65,35,8329,325,2656,80,428,3005,336,924,172,925,804,1021]

theorem envBound9573 : H12AffineFastState.Bounded env9573 := by
  intro p hp
  have h : env9573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9572_9573 : H12AffineEnvironment.transform 11 665 env9572 = env9573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env9572 == env9573) = true)

theorem identity9573 : scanCanonicalize (H12AffineFastState.compose env9573 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 493) := by decide +kernel

theorem selectedBound9573 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9574 : List Nat := [2,4,8,16,32,64,128,256,493,393,2048,372,8192,17,8693,8283,137,2420,37,8693,461,373,65,35,8329,325,2445,80,428,2128,336,113,172,112,201,16]

theorem envBound9574 : H12AffineFastState.Bounded env9574 := by
  intro p hp
  have h : env9574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9573_9574 : H12AffineEnvironment.transform 8 493 env9573 = env9574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 493 env9573 == env9574) = true)

theorem identity9574 : scanCanonicalize (H12AffineFastState.compose env9574 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9574 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env9575 : List Nat := [2,4,8,16,32,64,128,85,184,220,2048,33,8192,17,8352,8283,137,2081,37,8352,152,32,65,35,8329,16,2264,80,249,2128,5,113,172,112,201,16]

theorem envBound9575 : H12AffineFastState.Bounded env9575 := by
  intro p hp
  have h : env9575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9574_9575 : H12AffineEnvironment.transform 7 85 env9574 = env9575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9574 == env9575) = true)

theorem identity9575 : scanCanonicalize (H12AffineFastState.compose env9575 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound9575 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env9576 : List Nat := [2,4,8,16,32,64,128,85,184,220,33,33,8192,17,8352,8283,137,0,37,8352,152,32,65,35,8329,16,249,80,249,113,5,113,172,112,201,16]

theorem envBound9576 : H12AffineFastState.Bounded env9576 := by
  intro p hp
  have h : env9576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9575_9576 : H12AffineEnvironment.transform 10 33 env9575 = env9576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env9575 == env9576) = true)

theorem identity9576 : scanCanonicalize (H12AffineFastState.compose env9576 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound9576 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9577 : List Nat := [2,4,8,16,32,64,128,85,184,220,33,33,50,17,146,105,137,0,37,146,152,32,65,35,187,16,249,80,249,113,5,113,172,112,201,16]

theorem envBound9577 : H12AffineFastState.Bounded env9577 := by
  intro p hp
  have h : env9577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9576_9577 : H12AffineEnvironment.transform 12 50 env9576 = env9577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env9576 == env9577) = true)

theorem identity9577 : scanCanonicalize (H12AffineFastState.compose env9577 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9577 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env9578 : List Nat := [2,4,8,16,32,11,128,30,184,151,33,33,50,17,146,34,137,0,37,146,152,32,10,35,187,16,178,27,178,58,5,58,172,59,130,16]

theorem envBound9578 : H12AffineFastState.Bounded env9578 := by
  intro p hp
  have h : env9578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9577_9578 : H12AffineEnvironment.transform 5 11 env9577 = env9578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9577 == env9578) = true)

theorem identity9578 : scanCanonicalize (H12AffineFastState.compose env9578 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9578 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env9579 : List Nat := [2,4,8,16,27,11,128,30,131,151,26,26,9,17,146,25,137,0,30,146,152,27,10,24,128,16,137,27,137,1,5,1,151,0,130,16]

theorem envBound9579 : H12AffineFastState.Bounded env9579 := by
  intro p hp
  have h : env9579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9578_9579 : H12AffineEnvironment.transform 4 27 env9578 = env9579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9578 == env9579) = true)

theorem identity9579 : scanCanonicalize (H12AffineFastState.compose env9579 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9579 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9580 : List Nat := [2,4,8,16,27,11,19,30,16,4,26,26,9,17,1,25,26,0,30,1,11,27,10,24,19,16,26,27,26,1,5,1,4,0,17,16]

theorem envBound9580 : H12AffineFastState.Bounded env9580 := by
  intro p hp
  have h : env9580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9579_9580 : H12AffineEnvironment.transform 6 19 env9579 = env9580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9579 == env9580) = true)

theorem identity9580 : scanCanonicalize (H12AffineFastState.compose env9580 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9581 : List Nat := [2,4,3,16,16,0,19,21,16,4,17,17,2,17,1,18,17,0,21,1,0,16,1,19,19,16,17,16,17,1,5,1,4,0,17,16]

theorem envBound9581 : H12AffineFastState.Bounded env9581 := by
  intro p hp
  have h : env9581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9580_9581 : H12AffineEnvironment.transform 2 3 env9580 = env9581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9580 == env9581) = true)

def leafEnv9581 : List Nat := [2,4,3,16,16,0,19,21,16,4,17,17,2,17,1,18,17,0,21,1,0,16,1,19,20,19,1,16,17,16,17,1,5,1,4,0,21,2,17,16,1,1,0]

def active9581 : List Nat := [0,1,3]

def tree9581 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9581 : H12WitnessSearch.Good tree9581 := H12GlobalWitnessIndex.good

theorem leafIdentity9581 : H12AffineFastState.composeSystem env9581 rootObs = leafEnv9581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9581 rootObs == leafEnv9581) = true)

theorem terminalChecked9581 : H12PackedTerminal.terminalCheckFast leafEnv9581 active9581 tree9581 = true := by decide +kernel

def env9582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16740,525805,91617,8329,79374,279905,5293,5457,75786,619431,90170,525568,73770,2118540,91711]

theorem envBound9582 : H12AffineFastState.Bounded env9582 := by
  intro p hp
  have h : env9582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9547_9582 : H12AffineEnvironment.transform 23 91617 env9547 = env9582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env9547 == env9582) = true)

theorem identity9582 : scanCanonicalize (H12AffineFastState.compose env9582 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9582 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9583 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91164,8329,79374,279708,5293,5292,75786,619098,90170,525565,73770,2118257,91711]

theorem envBound9583 : H12AffineFastState.Bounded env9583 := by
  intro p hp
  have h : env9583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9582_9583 : H12AffineEnvironment.transform 7 253 env9582 = env9583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9582 == env9583) = true)

def env9584 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91164,8329,78958,279708,5293,5292,75786,618554,90170,525565,73770,2117649,91231]

theorem envBound9584 : H12AffineFastState.Bounded env9584 := by
  intro p hp
  have h : env9584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9583_9584 : H12AffineEnvironment.transform 8 96 env9583 = env9584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9583 == env9584) = true)

theorem identity9584 : scanCanonicalize (H12AffineFastState.compose env9584 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound9584 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9585 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,25663,4096,262144,524288,8200,2097152,16537,525328,35,8329,20561,279708,5293,5292,19509,529413,1029,525565,17429,2117649,96]

theorem envBound9585 : H12AffineFastState.Bounded env9585 := by
  intro p hp
  have h : env9585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9584_9585 : H12AffineEnvironment.transform 15 25663 env9584 = env9585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env9584 == env9585) = true)

theorem identity9585 : scanCanonicalize (H12AffineFastState.compose env9585 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9585 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9586 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8200,9263,4096,262144,524288,8200,2097152,137,525328,35,8329,4161,263308,5293,5292,3109,529413,1029,525565,1029,2101249,96]

theorem envBound9586 : H12AffineFastState.Bounded env9586 := by
  intro p hp
  have h : env9586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9585_9586 : H12AffineEnvironment.transform 13 16 env9585 = env9586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9585 == env9586) = true)

theorem identity9586 : scanCanonicalize (H12AffineFastState.compose env9586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound9586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9587 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8200,9263,4096,262144,524288,8200,529640,137,525328,35,8329,4161,263308,5293,5292,3109,529413,1029,525565,1029,525545,96]

theorem envBound9587 : H12AffineFastState.Bounded env9587 := by
  intro p hp
  have h : env9587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9586_9587 : H12AffineEnvironment.transform 20 529640 env9586 = env9587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env9586 == env9587) = true)

theorem identity9587 : scanCanonicalize (H12AffineFastState.compose env9587 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13472) := by decide +kernel

theorem selectedBound9587 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9588 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8200,9263,4096,262144,13472,8200,8264,137,12464,35,8329,4161,263308,5293,5292,3109,8357,1029,12381,1029,12361,96]

theorem envBound9588 : H12AffineFastState.Bounded env9588 := by
  intro p hp
  have h : env9588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9587_9588 : H12AffineEnvironment.transform 18 13472 env9587 = env9588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13472 env9587 == env9588) = true)

theorem identity9588 : scanCanonicalize (H12AffineFastState.compose env9588 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9287) := by decide +kernel

theorem selectedBound9588 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9589 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16,8200,9263,4096,9287,13472,8200,8264,137,12464,35,8329,4161,8395,5293,5292,3109,8357,1029,12381,1029,12361,96]

theorem envBound9589 : H12AffineFastState.Bounded env9589 := by
  intro p hp
  have h : env9589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9588_9589 : H12AffineEnvironment.transform 17 9287 env9588 = env9589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9287 env9588 == env9589) = true)

theorem identity9589 : scanCanonicalize (H12AffineFastState.compose env9589 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9589 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env9590 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8,16,0,1063,4096,1103,5288,0,64,137,4280,35,129,4161,195,5293,5292,3109,173,1029,4181,1029,4161,96]

theorem envBound9590 : H12AffineFastState.Bounded env9590 := by
  intro p hp
  have h : env9590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9589_9590 : H12AffineEnvironment.transform 12 8 env9589 = env9590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9589 == env9590) = true)

theorem identity9590 : scanCanonicalize (H12AffineFastState.compose env9590 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9590 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9591 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,4096,8,16,0,1063,4096,1103,5120,0,64,33,4112,35,41,4161,107,5125,5124,3109,5,1029,4181,1029,4161,96]

theorem envBound9591 : H12AffineFastState.Bounded env9591 := by
  intro p hp
  have h : env9591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9590_9591 : H12AffineEnvironment.transform 6 40 env9590 = env9591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9590 == env9591) = true)

theorem identity9591 : scanCanonicalize (H12AffineFastState.compose env9591 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound9591 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env9592 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,1109,8,16,0,1063,1109,1103,85,0,64,33,1093,35,41,1044,107,80,81,3109,5,1029,1024,1029,1044,96]

theorem envBound9592 : H12AffineFastState.Bounded env9592 := by
  intro p hp
  have h : env9592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9591_9592 : H12AffineEnvironment.transform 11 1109 env9591 = env9592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env9591 == env9592) = true)

def env9593 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16537,525328,91164,8329,78959,279708,5293,5292,75786,618555,90170,525565,73770,2117648,91230]

theorem envBound9593 : H12AffineFastState.Bounded env9593 := by
  intro p hp
  have h : env9593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9583_9593 : H12AffineEnvironment.transform 8 97 env9583 = env9593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9583 == env9593) = true)

theorem identity9593 : scanCanonicalize (H12AffineFastState.compose env9593 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9262) := by decide +kernel

theorem selectedBound9593 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9594 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9262,4096,262144,524288,8200,2097152,16537,525328,16434,8329,4161,279708,5293,5292,3108,545813,17428,525565,1028,2117648,16496]

theorem envBound9594 : H12AffineFastState.Bounded env9594 := by
  intro p hp
  have h : env9594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9593_9594 : H12AffineEnvironment.transform 15 9262 env9593 = env9594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9262 env9593 == env9594) = true)

theorem identity9594 : scanCanonicalize (H12AffineFastState.compose env9594 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545020) := by decide +kernel

theorem selectedBound9594 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9595 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9262,4096,262144,524288,8200,545020,16537,525328,16434,8329,4161,279708,5293,5292,3108,545813,17428,525565,1028,524524,16496]

theorem envBound9595 : H12AffineFastState.Bounded env9595 := by
  intro p hp
  have h : env9595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9594_9595 : H12AffineEnvironment.transform 20 545020 env9594 = env9595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545020 env9594 == env9595) = true)

theorem identity9595 : scanCanonicalize (H12AffineFastState.compose env9595 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282654) := by decide +kernel

theorem selectedBound9595 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env9596 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9262,4096,262144,282654,8200,262370,16537,283662,16434,8329,4161,279708,5293,5292,3108,263179,17428,283875,1028,282866,16496]

theorem envBound9596 : H12AffineFastState.Bounded env9596 := by
  intro p hp
  have h : env9596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9595_9596 : H12AffineEnvironment.transform 18 282654 env9595 = env9596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282654 env9595 == env9596) = true)

theorem identity9596 : scanCanonicalize (H12AffineFastState.compose env9596 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17590) := by decide +kernel

theorem selectedBound9596 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9597 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9262,4096,17590,5288,8200,17492,16537,4280,16434,8329,4161,42,5293,5292,3108,16573,17428,4181,1028,5188,16496]

theorem envBound9597 : H12AffineFastState.Bounded env9597 := by
  intro p hp
  have h : env9597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9596_9597 : H12AffineEnvironment.transform 17 17590 env9596 = env9597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17590 env9596 == env9597) = true)

theorem identity9597 : scanCanonicalize (H12AffineFastState.compose env9597 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9597 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9598 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16,8200,9262,4096,1190,5288,8200,1092,137,4280,34,8329,4161,42,5293,5292,3108,173,1028,4181,1028,5188,96]

theorem envBound9598 : H12AffineFastState.Bounded env9598 := by
  intro p hp
  have h : env9598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9597_9598 : H12AffineEnvironment.transform 13 16 env9597 = env9598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9597 == env9598) = true)

def env9599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79374,134217728,134500813,134500401,151259274,17307206,151273659,525568,151257258,136582893,16778206]

theorem envBound9599 : H12AffineFastState.Bounded env9599 := by
  intro p hp
  have h : env9599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9493_9599 : H12AffineEnvironment.transform 21 16741 env9493 = env9599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16741 env9493 == env9599) = true)

def env9600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79374,279904,5293,5457,16797162,17307206,16778715,525568,16795082,2118541,16778206]

theorem envBound9600 : H12AffineFastState.Bounded env9600 := by
  intro p hp
  have h : env9600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9599_9600 : H12AffineEnvironment.transform 26 279904 env9599 = env9600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279904 env9599 == env9600) = true)

def env9601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,91616,8329,79374,279904,5293,5457,75786,619430,90171,525568,73770,2118541,91710]

theorem envBound9601 : H12AffineFastState.Bounded env9601 := by
  intro p hp
  have h : env9601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9600_9601 : H12AffineEnvironment.transform 23 91616 env9600 = env9601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env9600 == env9601) = true)

theorem identity9601 : scanCanonicalize (H12AffineFastState.compose env9601 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9601 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9602 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91165,8329,79374,279709,5293,5292,75786,619099,90171,525565,73770,2118256,91710]

theorem envBound9602 : H12AffineFastState.Bounded env9602 := by
  intro p hp
  have h : env9602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9601_9602 : H12AffineEnvironment.transform 7 253 env9601 = env9602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9601 == env9602) = true)

def env9603 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91165,8329,78958,279709,5293,5292,75786,618555,90171,525565,73770,2117648,91230]

theorem envBound9603 : H12AffineFastState.Bounded env9603 := by
  intro p hp
  have h : env9603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9602_9603 : H12AffineEnvironment.transform 8 96 env9602 = env9603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9602 == env9603) = true)

theorem identity9603 : scanCanonicalize (H12AffineFastState.compose env9603 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9262) := by decide +kernel

theorem selectedBound9603 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9604 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9262,4096,262144,524288,8200,2097152,16536,525328,16435,8329,4160,279709,5293,5292,3108,545813,17429,525565,1028,2117648,16496]

theorem envBound9604 : H12AffineFastState.Bounded env9604 := by
  intro p hp
  have h : env9604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9603_9604 : H12AffineEnvironment.transform 15 9262 env9603 = env9604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9262 env9603 == env9604) = true)

theorem identity9604 : scanCanonicalize (H12AffineFastState.compose env9604 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545021) := by decide +kernel

theorem selectedBound9604 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9605 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9262,4096,262144,524288,8200,545021,16536,525328,16435,8329,4160,279709,5293,5292,3108,545813,17429,525565,1028,524525,16496]

theorem envBound9605 : H12AffineFastState.Bounded env9605 := by
  intro p hp
  have h : env9605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9604_9605 : H12AffineEnvironment.transform 20 545021 env9604 = env9605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545021 env9604 == env9605) = true)

theorem identity9605 : scanCanonicalize (H12AffineFastState.compose env9605 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282655) := by decide +kernel

theorem selectedBound9605 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env9606 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9262,4096,262144,282655,8200,262370,16536,283663,16435,8329,4160,279709,5293,5292,3108,263178,17429,283874,1028,282866,16496]

theorem envBound9606 : H12AffineFastState.Bounded env9606 := by
  intro p hp
  have h : env9606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9605_9606 : H12AffineEnvironment.transform 18 282655 env9605 = env9606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282655 env9605 == env9606) = true)

theorem identity9606 : scanCanonicalize (H12AffineFastState.compose env9606 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17590) := by decide +kernel

theorem selectedBound9606 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9607 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,9262,4096,17590,5289,8200,17492,16536,4281,16435,8329,4160,43,5293,5292,3108,16572,17429,4180,1028,5188,16496]

theorem envBound9607 : H12AffineFastState.Bounded env9607 := by
  intro p hp
  have h : env9607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9606_9607 : H12AffineEnvironment.transform 17 17590 env9606 = env9607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17590 env9606 == env9607) = true)

theorem identity9607 : scanCanonicalize (H12AffineFastState.compose env9607 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9607 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9608 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8200,9262,4096,1191,5289,8200,1093,137,4281,34,8329,4160,43,5293,5292,3108,173,1028,4180,1028,5188,97]

theorem envBound9608 : H12AffineFastState.Bounded env9608 := by
  intro p hp
  have h : env9608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9607_9608 : H12AffineEnvironment.transform 13 17 env9607 = env9608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9607 == env9608) = true)

def env9609 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91165,8329,78959,279709,5293,5292,75786,618554,90171,525565,73770,2117649,91231]

theorem envBound9609 : H12AffineFastState.Bounded env9609 := by
  intro p hp
  have h : env9609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9602_9609 : H12AffineEnvironment.transform 8 97 env9602 = env9609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9602 == env9609) = true)

theorem identity9609 : scanCanonicalize (H12AffineFastState.compose env9609 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound9609 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9610 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,25662,4096,262144,524288,8200,2097152,16536,525328,35,8329,20561,279709,5293,5292,19508,529412,1029,525565,17428,2117649,97]

theorem envBound9610 : H12AffineFastState.Bounded env9610 := by
  intro p hp
  have h : env9610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9609_9610 : H12AffineEnvironment.transform 15 25662 env9609 = env9610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env9609 == env9610) = true)

theorem identity9610 : scanCanonicalize (H12AffineFastState.compose env9610 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9610 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9611 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8200,9263,4096,262144,524288,8200,2097152,137,525328,35,8329,4160,263308,5293,5292,3109,529412,1029,525565,1029,2101248,97]

theorem envBound9611 : H12AffineFastState.Bounded env9611 := by
  intro p hp
  have h : env9611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9610_9611 : H12AffineEnvironment.transform 13 17 env9610 = env9611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9610 == env9611) = true)

theorem identity9611 : scanCanonicalize (H12AffineFastState.compose env9611 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound9611 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9612 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8200,9263,4096,262144,524288,8200,529640,137,525328,35,8329,4160,263308,5293,5292,3109,529412,1029,525565,1029,525544,97]

theorem envBound9612 : H12AffineFastState.Bounded env9612 := by
  intro p hp
  have h : env9612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9611_9612 : H12AffineEnvironment.transform 20 529640 env9611 = env9612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env9611 == env9612) = true)

theorem identity9612 : scanCanonicalize (H12AffineFastState.compose env9612 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13473) := by decide +kernel

theorem selectedBound9612 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9613 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8200,9263,4096,262144,13473,8200,8265,137,12465,35,8329,4160,263308,5293,5292,3109,8357,1029,12380,1029,12361,97]

theorem envBound9613 : H12AffineFastState.Bounded env9613 := by
  intro p hp
  have h : env9613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9612_9613 : H12AffineEnvironment.transform 18 13473 env9612 = env9613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13473 env9612 == env9613) = true)

theorem identity9613 : scanCanonicalize (H12AffineFastState.compose env9613 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9286) := by decide +kernel

theorem selectedBound9613 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9614 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8200,9263,4096,9286,13473,8200,8265,137,12465,35,8329,4160,8394,5293,5292,3109,8357,1029,12380,1029,12361,97]

theorem envBound9614 : H12AffineFastState.Bounded env9614 := by
  intro p hp
  have h : env9614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9613_9614 : H12AffineEnvironment.transform 17 9286 env9613 = env9614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9286 env9613 == env9614) = true)

theorem identity9614 : scanCanonicalize (H12AffineFastState.compose env9614 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9614 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env9615 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8,17,0,1063,4096,1102,5289,0,65,137,4281,35,129,4160,194,5293,5292,3109,173,1029,4180,1029,4161,97]

theorem envBound9615 : H12AffineFastState.Bounded env9615 := by
  intro p hp
  have h : env9615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9614_9615 : H12AffineEnvironment.transform 12 8 env9614 = env9615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9614 == env9615) = true)

theorem identity9615 : scanCanonicalize (H12AffineFastState.compose env9615 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9615 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9616 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,4096,8,17,0,1063,4096,1102,5121,0,65,33,4113,35,41,4160,106,5125,5124,3109,5,1029,4180,1029,4161,97]

theorem envBound9616 : H12AffineFastState.Bounded env9616 := by
  intro p hp
  have h : env9616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9615_9616 : H12AffineEnvironment.transform 6 40 env9615 = env9616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9615 == env9616) = true)

theorem identity9616 : scanCanonicalize (H12AffineFastState.compose env9616 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound9616 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env9617 : List Nat := [2,4,8,16,32,64,40,85,97,1024,2048,1108,8,17,0,1063,1108,1102,85,0,65,33,1093,35,41,1044,106,81,80,3109,5,1029,1024,1029,1045,97]

theorem envBound9617 : H12AffineFastState.Bounded env9617 := by
  intro p hp
  have h : env9617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9616_9617 : H12AffineEnvironment.transform 11 1108 env9616 = env9617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env9616 == env9617) = true)

def env9618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,91617,8329,79374,279904,5293,5457,75787,619431,90170,525568,73771,2118541,91711]

theorem envBound9618 : H12AffineFastState.Bounded env9618 := by
  intro p hp
  have h : env9618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9600_9618 : H12AffineEnvironment.transform 23 91617 env9600 = env9618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env9600 == env9618) = true)

theorem identity9618 : scanCanonicalize (H12AffineFastState.compose env9618 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26050) := by decide +kernel

theorem selectedBound9618 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,2097152,16741,525805,35,8329,21452,279904,5293,5457,19913,530021,1528,525568,17897,2118541,1021]

theorem envBound9619 : H12AffineFastState.Bounded env9619 := by
  intro p hp
  have h : env9619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9618_9619 : H12AffineEnvironment.transform 15 26050 env9618 = env9619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26050 env9618 == env9619) = true)

def env9620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,529264,16741,525805,35,8329,21452,279904,5293,5457,19913,530021,1528,525568,17897,540925,1021]

theorem envBound9620 : H12AffineFastState.Bounded env9620 := by
  intro p hp
  have h : env9620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9619_9620 : H12AffineEnvironment.transform 20 529264 env9619 = env9620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env9619 == env9620) = true)

def env9621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,4432,8693,544,16741,5309,35,8329,21452,279904,5293,5457,19913,1845,1528,5200,17897,20909,1021]

theorem envBound9621 : H12AffineFastState.Bounded env9621 := by
  intro p hp
  have h : env9621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9620_9621 : H12AffineEnvironment.transform 18 4432 env9620 = env9621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env9620 == env9621) = true)

theorem identity9621 : scanCanonicalize (H12AffineFastState.compose env9621 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9621 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,9682,4605,262144,4432,8693,544,373,5309,35,8329,5084,263536,5293,5457,3545,1845,1528,5200,1529,4541,1021]

theorem envBound9622 : H12AffineFastState.Bounded env9622 := by
  intro p hp
  have h : env9622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9621_9622 : H12AffineEnvironment.transform 13 16 env9621 = env9622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9621 == env9622) = true)

theorem identity9622 : scanCanonicalize (H12AffineFastState.compose env9622 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound9622 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9623 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,16,8693,9143,4605,262144,4432,8693,544,373,4824,35,8329,5084,262933,4808,4916,3004,336,925,4661,924,4541,1021]

theorem envBound9623 : H12AffineFastState.Bounded env9623 := by
  intro p hp
  have h : env9623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9622_9623 : H12AffineEnvironment.transform 9 613 env9622 = env9623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env9622 == env9623) = true)

theorem identity9623 : scanCanonicalize (H12AffineFastState.compose env9623 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7149) := by decide +kernel

theorem selectedBound9623 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9624 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,16,8693,9143,4605,7149,4432,8693,544,373,4824,35,8329,5084,6392,4808,4916,3004,336,925,4661,924,4541,1021]

theorem envBound9624 : H12AffineFastState.Bounded env9624 := by
  intro p hp
  have h : env9624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9623_9624 : H12AffineEnvironment.transform 17 7149 env9623 = env9624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7149 env9623 == env9624) = true)

theorem identity9624 : scanCanonicalize (H12AffineFastState.compose env9624 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound9624 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env9625 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,665,8192,16,8693,9143,868,2420,969,8693,544,373,65,35,8329,325,2657,81,429,3004,336,925,172,924,804,1021]

theorem envBound9625 : H12AffineFastState.Bounded env9625 := by
  intro p hp
  have h : env9625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9624_9625 : H12AffineEnvironment.transform 11 665 env9624 = env9625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env9624 == env9625) = true)

theorem identity9625 : scanCanonicalize (H12AffineFastState.compose env9625 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 492) := by decide +kernel

theorem selectedBound9625 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9626 : List Nat := [2,4,8,16,32,64,128,256,492,393,2048,373,8192,16,8693,8283,136,2420,37,8693,460,373,65,35,8329,325,2445,81,429,2128,336,113,172,112,200,17]

theorem envBound9626 : H12AffineFastState.Bounded env9626 := by
  intro p hp
  have h : env9626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9625_9626 : H12AffineEnvironment.transform 8 492 env9625 = env9626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 492 env9625 == env9626) = true)

theorem identity9626 : scanCanonicalize (H12AffineFastState.compose env9626 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9626 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env9627 : List Nat := [2,4,8,16,32,64,128,85,185,220,2048,32,8192,16,8352,8283,136,2081,37,8352,153,32,65,35,8329,16,2264,81,248,2128,5,113,172,112,200,17]

theorem envBound9627 : H12AffineFastState.Bounded env9627 := by
  intro p hp
  have h : env9627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9626_9627 : H12AffineEnvironment.transform 7 85 env9626 = env9627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9626 == env9627) = true)

theorem identity9627 : scanCanonicalize (H12AffineFastState.compose env9627 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound9627 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env9628 : List Nat := [2,4,8,16,32,64,128,85,185,220,32,32,8192,16,8352,8283,136,1,37,8352,153,32,65,35,8329,16,248,81,248,112,5,113,172,112,200,17]

theorem envBound9628 : H12AffineFastState.Bounded env9628 := by
  intro p hp
  have h : env9628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9627_9628 : H12AffineEnvironment.transform 10 32 env9627 = env9628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env9627 == env9628) = true)

theorem identity9628 : scanCanonicalize (H12AffineFastState.compose env9628 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound9628 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9629 : List Nat := [2,4,8,16,32,64,128,85,185,220,32,32,50,16,146,105,136,1,37,146,153,32,65,35,187,16,248,81,248,112,5,113,172,112,200,17]

theorem envBound9629 : H12AffineFastState.Bounded env9629 := by
  intro p hp
  have h : env9629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9628_9629 : H12AffineEnvironment.transform 12 50 env9628 = env9629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env9628 == env9629) = true)

theorem identity9629 : scanCanonicalize (H12AffineFastState.compose env9629 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9629 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env9630 : List Nat := [2,4,8,16,32,11,128,30,185,151,32,32,50,16,146,34,136,1,37,146,153,32,10,35,187,16,179,26,179,59,5,58,172,59,131,17]

theorem envBound9630 : H12AffineFastState.Bounded env9630 := by
  intro p hp
  have h : env9630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9629_9630 : H12AffineEnvironment.transform 5 11 env9629 = env9630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9629 == env9630) = true)

theorem identity9630 : scanCanonicalize (H12AffineFastState.compose env9630 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9630 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env9631 : List Nat := [2,4,8,16,27,11,128,30,130,151,27,27,9,16,146,25,136,1,30,146,153,27,10,24,128,16,136,26,136,0,5,1,151,0,131,17]

theorem envBound9631 : H12AffineFastState.Bounded env9631 := by
  intro p hp
  have h : env9631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9630_9631 : H12AffineEnvironment.transform 4 27 env9630 = env9631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9630 == env9631) = true)

theorem identity9631 : scanCanonicalize (H12AffineFastState.compose env9631 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9631 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9632 : List Nat := [2,4,8,16,27,11,19,30,17,4,27,27,9,16,1,25,27,1,30,1,10,27,10,24,19,16,27,26,27,0,5,1,4,0,16,17]

theorem envBound9632 : H12AffineFastState.Bounded env9632 := by
  intro p hp
  have h : env9632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9631_9632 : H12AffineEnvironment.transform 6 19 env9631 = env9632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9631 == env9632) = true)

theorem identity9632 : scanCanonicalize (H12AffineFastState.compose env9632 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9633 : List Nat := [2,4,2,16,17,1,19,20,17,4,17,17,3,16,1,19,17,1,20,1,0,17,0,18,19,16,17,16,17,0,5,1,4,0,16,17]

theorem envBound9633 : H12AffineFastState.Bounded env9633 := by
  intro p hp
  have h : env9633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9632_9633 : H12AffineEnvironment.transform 2 2 env9632 = env9633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9632 == env9633) = true)

def leafEnv9633 : List Nat := [2,4,2,16,17,1,19,20,17,4,17,17,3,16,1,19,17,1,20,1,0,17,0,18,21,19,1,16,17,16,17,0,5,1,4,0,20,2,16,17,1,1,0]

def active9633 : List Nat := [0,1,3]

def tree9633 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9633 : H12WitnessSearch.Good tree9633 := H12GlobalWitnessIndex.good

theorem leafIdentity9633 : H12AffineFastState.composeSystem env9633 rootObs = leafEnv9633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9633 rootObs == leafEnv9633) = true)

theorem terminalChecked9633 : H12PackedTerminal.terminalCheckFast leafEnv9633 active9633 tree9633 = true := by decide +kernel

def env9634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,4433,8693,545,16741,5308,35,8329,21452,279904,5293,5457,19913,1844,1528,5201,17897,20908,1021]

theorem envBound9634 : H12AffineFastState.Bounded env9634 := by
  intro p hp
  have h : env9634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9620_9634 : H12AffineEnvironment.transform 18 4433 env9620 = env9634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env9620 == env9634) = true)

theorem identity9634 : scanCanonicalize (H12AffineFastState.compose env9634 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound9634 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8693,9263,4605,262144,4433,8693,545,136,5308,35,8329,4641,263309,5293,5457,3108,1844,1528,5201,1028,4161,1021]

theorem envBound9635 : H12AffineFastState.Bounded env9635 := by
  intro p hp
  have h : env9635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9634_9635 : H12AffineEnvironment.transform 13 493 env9634 = env9635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env9634 == env9635) = true)

theorem identity9635 : scanCanonicalize (H12AffineFastState.compose env9635 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9635 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9636 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,493,8693,8235,4605,262144,4433,8693,545,136,4280,35,8329,4641,262281,4265,4437,2080,816,508,4181,0,4161,1021]

theorem envBound9636 : H12AffineFastState.Bounded env9636 := by
  intro p hp
  have h : env9636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9635_9636 : H12AffineEnvironment.transform 9 4 env9635 = env9636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9635 == env9636) = true)

theorem identity9636 : scanCanonicalize (H12AffineFastState.compose env9636 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9636 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9637 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8200,8235,4096,262144,4268,8200,545,136,4280,35,8329,4641,262281,4265,4264,2080,717,1,4181,0,4161,512]

theorem envBound9637 : H12AffineFastState.Bounded env9637 := by
  intro p hp
  have h : env9637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9636_9637 : H12AffineEnvironment.transform 7 253 env9636 = env9637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9636 == env9637) = true)

def env9638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26050,4605,262144,524288,8693,529265,16741,525805,35,8329,21452,279904,5293,5457,19913,530021,1528,525568,17897,540924,1021]

theorem envBound9638 : H12AffineFastState.Bounded env9638 := by
  intro p hp
  have h : env9638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9619_9638 : H12AffineEnvironment.transform 20 529265 env9619 = env9638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env9619 == env9638) = true)

theorem identity9638 : scanCanonicalize (H12AffineFastState.compose env9638 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9638 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9639 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,25663,4096,262144,524288,8200,529036,16536,525328,35,8329,21041,279709,5293,5292,19508,530021,1029,525565,17428,540924,512]

theorem envBound9639 : H12AffineFastState.Bounded env9639 := by
  intro p hp
  have h : env9639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9638_9639 : H12AffineEnvironment.transform 7 253 env9638 = env9639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9638 == env9639) = true)

theorem identity9639 : scanCanonicalize (H12AffineFastState.compose env9639 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9639 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9640 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16,8200,9263,4096,262144,524288,8200,529036,136,525328,35,8329,4641,263309,5293,5292,3108,530021,1029,525565,1028,524524,512]

theorem envBound9640 : H12AffineFastState.Bounded env9640 := by
  intro p hp
  have h : env9640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9639_9640 : H12AffineEnvironment.transform 13 16 env9639 = env9640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9639 == env9640) = true)

theorem identity9640 : scanCanonicalize (H12AffineFastState.compose env9640 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9640 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9641 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8200,8234,4096,262144,524288,8200,529036,136,524309,35,8329,4641,262280,4264,4265,2081,528992,0,524536,1,524524,512]

theorem envBound9641 : H12AffineFastState.Bounded env9641 := by
  intro p hp
  have h : env9641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9640_9641 : H12AffineEnvironment.transform 9 5 env9640 = env9641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9640 == env9641) = true)

theorem identity9641 : scanCanonicalize (H12AffineFastState.compose env9641 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4269) := by decide +kernel

theorem selectedBound9641 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9642 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8200,8234,4096,262144,4269,8200,545,136,4280,35,8329,4641,262280,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9642 : H12AffineFastState.Bounded env9642 := by
  intro p hp
  have h : env9642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9641_9642 : H12AffineEnvironment.transform 18 4269 env9641 = env9642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4269 env9641 == env9642) = true)

theorem identity9642 : scanCanonicalize (H12AffineFastState.compose env9642 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14544) := by decide +kernel

theorem selectedBound9642 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9643 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8200,8234,4096,14544,4269,8200,545,136,4280,35,8329,4641,14424,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9643 : H12AffineFastState.Bounded env9643 := by
  intro p hp
  have h : env9643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9642_9643 : H12AffineEnvironment.transform 17 14544 env9642 = env9643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14544 env9642 == env9643) = true)

theorem identity9643 : scanCanonicalize (H12AffineFastState.compose env9643 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6907) := by decide +kernel

theorem selectedBound9643 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9644 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,6907,16,6899,6865,4096,555,4269,6899,545,136,4280,35,6770,4641,675,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9644 : H12AffineFastState.Bounded env9644 := by
  intro p hp
  have h : env9644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9643_9644 : H12AffineEnvironment.transform 12 6907 env9643 = env9644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6907 env9643 == env9644) = true)

theorem identity9644 : scanCanonicalize (H12AffineFastState.compose env9644 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound9644 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env9645 : List Nat := [2,4,8,16,32,64,128,253,96,5,2048,4096,6299,16,6291,6321,4096,75,4269,6291,65,136,4280,35,6162,4161,195,4264,4265,2081,173,0,4181,1,4161,96]

theorem envBound9645 : H12AffineFastState.Bounded env9645 := by
  intro p hp
  have h : env9645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9644_9645 : H12AffineEnvironment.transform 8 96 env9644 = env9645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9644 == env9645) = true)

theorem identity9645 : scanCanonicalize (H12AffineFastState.compose env9645 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound9645 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9646 : List Nat := [2,4,8,16,32,64,128,253,96,5,26,4096,4225,16,4233,4267,4096,75,4269,4233,65,136,4280,35,4104,4161,195,4264,4265,59,173,0,4181,1,4161,96]

theorem envBound9646 : H12AffineFastState.Bounded env9646 := by
  intro p hp
  have h : env9646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9645_9646 : H12AffineEnvironment.transform 10 26 env9645 = env9646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env9645 == env9646) = true)

theorem identity9646 : scanCanonicalize (H12AffineFastState.compose env9646 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound9646 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9647 : List Nat := [2,4,8,16,32,64,128,253,96,5,26,80,209,16,217,251,80,75,253,217,65,136,232,35,88,17,195,248,249,59,173,0,5,1,17,96]

theorem envBound9647 : H12AffineFastState.Bounded env9647 := by
  intro p hp
  have h : env9647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9646_9647 : H12AffineEnvironment.transform 11 80 env9646 = env9647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env9646 == env9647) = true)

theorem identity9647 : scanCanonicalize (H12AffineFastState.compose env9647 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9647 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9648 : List Nat := [2,4,8,16,32,64,88,37,96,5,26,80,9,16,1,35,80,75,37,1,65,80,48,35,88,17,27,32,33,59,117,0,5,1,17,96]

theorem envBound9648 : H12AffineFastState.Bounded env9648 := by
  intro p hp
  have h : env9648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9647_9648 : H12AffineEnvironment.transform 6 88 env9647 = env9648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9647 == env9648) = true)

theorem identity9648 : scanCanonicalize (H12AffineFastState.compose env9648 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9648 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env9649 : List Nat := [2,4,8,16,32,48,40,37,16,5,26,32,9,16,1,35,32,59,37,1,49,32,48,35,40,17,27,32,33,59,5,0,5,1,17,16]

theorem envBound9649 : H12AffineFastState.Bounded env9649 := by
  intro p hp
  have h : env9649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9648_9649 : H12AffineEnvironment.transform 5 48 env9648 = env9649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9648 == env9649) = true)

theorem identity9649 : scanCanonicalize (H12AffineFastState.compose env9649 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9649 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9650 : List Nat := [2,4,8,16,27,11,19,30,16,5,26,27,9,16,1,24,27,0,30,1,10,27,11,24,19,17,27,27,26,0,5,0,5,1,17,16]

theorem envBound9650 : H12AffineFastState.Bounded env9650 := by
  intro p hp
  have h : env9650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9649_9650 : H12AffineEnvironment.transform 4 27 env9649 = env9650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9649 == env9650) = true)

theorem identity9650 : scanCanonicalize (H12AffineFastState.compose env9650 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9651 : List Nat := [2,4,3,16,16,0,19,21,16,5,17,16,2,16,1,19,16,0,21,1,1,16,0,19,19,17,16,16,17,0,5,0,5,1,17,16]

theorem envBound9651 : H12AffineFastState.Bounded env9651 := by
  intro p hp
  have h : env9651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9650_9651 : H12AffineEnvironment.transform 2 3 env9650 = env9651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9650 == env9651) = true)

def leafEnv9651 : List Nat := [2,4,3,16,16,0,19,21,16,5,17,16,2,16,1,19,16,0,21,1,1,16,0,19,21,19,1,17,16,16,17,0,5,0,5,1,20,3,17,16,1,1,0]

def active9651 : List Nat := [0,1,3]

def tree9651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9651 : H12WitnessSearch.Good tree9651 := H12GlobalWitnessIndex.good

theorem leafIdentity9651 : H12AffineFastState.composeSystem env9651 rootObs = leafEnv9651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9651 rootObs == leafEnv9651) = true)

theorem terminalChecked9651 : H12PackedTerminal.terminalCheckFast leafEnv9651 active9651 tree9651 = true := by decide +kernel

def env9652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,16777216,8329,79374,279905,5292,5456,16797163,17307206,16778714,525568,16795083,2118540,16778206]

theorem envBound9652 : H12AffineFastState.Bounded env9652 := by
  intro p hp
  have h : env9652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9599_9652 : H12AffineEnvironment.transform 26 279905 env9599 = env9652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 279905 env9599 == env9652) = true)

def env9653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,91616,8329,79374,279905,5292,5456,75787,619430,90170,525568,73771,2118540,91710]

theorem envBound9653 : H12AffineFastState.Bounded env9653 := by
  intro p hp
  have h : env9653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9652_9653 : H12AffineEnvironment.transform 23 91616 env9652 = env9653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91616 env9652 == env9653) = true)

theorem identity9653 : scanCanonicalize (H12AffineFastState.compose env9653 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound9653 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,2097152,16741,525805,35,8329,21453,279905,5292,5456,19912,530021,1529,525568,17896,2118540,1021]

theorem envBound9654 : H12AffineFastState.Bounded env9654 := by
  intro p hp
  have h : env9654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9653_9654 : H12AffineEnvironment.transform 15 26051 env9653 = env9654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env9653 == env9654) = true)

def env9655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,529264,16741,525805,35,8329,21453,279905,5292,5456,19912,530021,1529,525568,17896,540924,1021]

theorem envBound9655 : H12AffineFastState.Bounded env9655 := by
  intro p hp
  have h : env9655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9654_9655 : H12AffineEnvironment.transform 20 529264 env9654 = env9655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529264 env9654 == env9655) = true)

def env9656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,4432,8693,544,16741,5309,35,8329,21453,279905,5292,5456,19912,1845,1529,5200,17896,20908,1021]

theorem envBound9656 : H12AffineFastState.Bounded env9656 := by
  intro p hp
  have h : env9656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9655_9656 : H12AffineEnvironment.transform 18 4432 env9655 = env9656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4432 env9655 == env9656) = true)

theorem identity9656 : scanCanonicalize (H12AffineFastState.compose env9656 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound9656 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8693,9262,4605,262144,4432,8693,544,136,5309,35,8329,4640,263308,5292,5456,3109,1845,1529,5200,1029,4161,1021]

theorem envBound9657 : H12AffineFastState.Bounded env9657 := by
  intro p hp
  have h : env9657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9656_9657 : H12AffineEnvironment.transform 13 493 env9656 = env9657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env9656 == env9657) = true)

theorem identity9657 : scanCanonicalize (H12AffineFastState.compose env9657 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9657 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9658 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,8192,493,8693,8235,4605,262144,4432,8693,544,136,4280,35,8329,4640,262281,4265,4437,2080,816,508,4181,0,4161,1021]

theorem envBound9658 : H12AffineFastState.Bounded env9658 := by
  intro p hp
  have h : env9658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9657_9658 : H12AffineEnvironment.transform 9 5 env9657 = env9658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9657 == env9658) = true)

theorem identity9658 : scanCanonicalize (H12AffineFastState.compose env9658 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9658 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9659 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,4096,8192,16,8200,8235,4096,262144,4269,8200,544,136,4280,35,8329,4640,262281,4265,4264,2080,717,1,4181,0,4161,512]

theorem envBound9659 : H12AffineFastState.Bounded env9659 := by
  intro p hp
  have h : env9659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9658_9659 : H12AffineEnvironment.transform 7 253 env9658 = env9659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9658 == env9659) = true)

def env9660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,4433,8693,545,16741,5308,35,8329,21453,279905,5292,5456,19912,1844,1529,5201,17896,20909,1021]

theorem envBound9660 : H12AffineFastState.Bounded env9660 := by
  intro p hp
  have h : env9660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9655_9660 : H12AffineEnvironment.transform 18 4433 env9655 = env9660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4433 env9655 == env9660) = true)

theorem identity9660 : scanCanonicalize (H12AffineFastState.compose env9660 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9660 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16,8693,9683,4605,262144,4433,8693,545,373,5308,35,8329,5085,263537,5292,5456,3544,1844,1529,5201,1528,4541,1021]

theorem envBound9661 : H12AffineFastState.Bounded env9661 := by
  intro p hp
  have h : env9661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9660_9661 : H12AffineEnvironment.transform 13 16 env9660 = env9661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9660 == env9661) = true)

theorem identity9661 : scanCanonicalize (H12AffineFastState.compose env9661 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound9661 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9662 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,16,8693,9142,4605,262144,4433,8693,545,373,4825,35,8329,5085,262932,4809,4917,3005,337,924,4660,925,4541,1021]

theorem envBound9662 : H12AffineFastState.Bounded env9662 := by
  intro p hp
  have h : env9662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9661_9662 : H12AffineEnvironment.transform 9 613 env9661 = env9662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env9661 == env9662) = true)

theorem identity9662 : scanCanonicalize (H12AffineFastState.compose env9662 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7148) := by decide +kernel

theorem selectedBound9662 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9663 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,4096,8192,16,8693,9142,4605,7148,4433,8693,545,373,4825,35,8329,5085,6392,4809,4917,3005,337,924,4660,925,4541,1021]

theorem envBound9663 : H12AffineFastState.Bounded env9663 := by
  intro p hp
  have h : env9663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9662_9663 : H12AffineEnvironment.transform 17 7148 env9662 = env9663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7148 env9662 == env9663) = true)

theorem identity9663 : scanCanonicalize (H12AffineFastState.compose env9663 (packedSelected [1,2,3,8,10,11,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound9663 : packedSelected [1,2,3,8,10,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env9664 : List Nat := [2,4,8,16,32,64,128,256,512,613,2048,664,8192,16,8693,9142,869,2420,969,8693,545,373,65,35,8329,325,2656,81,429,3005,337,924,172,925,805,1021]

theorem envBound9664 : H12AffineFastState.Bounded env9664 := by
  intro p hp
  have h : env9664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9663_9664 : H12AffineEnvironment.transform 11 664 env9663 = env9664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env9663 == env9664) = true)

theorem identity9664 : scanCanonicalize (H12AffineFastState.compose env9664 (packedSelected [0,4,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(8+1) ^^^ 493) := by decide +kernel

theorem selectedBound9664 : packedSelected [0,4,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9665 : List Nat := [2,4,8,16,32,64,128,256,493,392,2048,373,8192,16,8693,8283,136,2420,36,8693,460,373,65,35,8329,325,2445,81,429,2128,337,113,172,112,200,16]

theorem envBound9665 : H12AffineFastState.Bounded env9665 := by
  intro p hp
  have h : env9665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9664_9665 : H12AffineEnvironment.transform 8 493 env9664 = env9665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 493 env9664 == env9665) = true)

theorem identity9665 : scanCanonicalize (H12AffineFastState.compose env9665 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9665 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env9666 : List Nat := [2,4,8,16,32,64,128,85,184,221,2048,32,8192,16,8352,8283,136,2081,36,8352,153,32,65,35,8329,16,2264,81,248,2128,4,113,172,112,200,16]

theorem envBound9666 : H12AffineFastState.Bounded env9666 := by
  intro p hp
  have h : env9666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9665_9666 : H12AffineEnvironment.transform 7 85 env9665 = env9666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9665 == env9666) = true)

theorem identity9666 : scanCanonicalize (H12AffineFastState.compose env9666 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound9666 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env9667 : List Nat := [2,4,8,16,32,64,128,85,184,221,137,32,8192,16,8352,8283,136,168,36,8352,153,32,65,35,8329,16,81,81,248,217,4,113,172,112,200,16]

theorem envBound9667 : H12AffineFastState.Bounded env9667 := by
  intro p hp
  have h : env9667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9666_9667 : H12AffineEnvironment.transform 10 137 env9666 = env9667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env9666 == env9667) = true)

theorem identity9667 : scanCanonicalize (H12AffineFastState.compose env9667 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound9667 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env9668 : List Nat := [2,4,8,16,32,64,128,85,184,221,137,32,154,16,58,193,136,168,36,58,153,32,65,35,19,16,81,81,248,217,4,113,172,112,200,16]

theorem envBound9668 : H12AffineFastState.Bounded env9668 := by
  intro p hp
  have h : env9668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9667_9668 : H12AffineEnvironment.transform 12 154 env9667 = env9668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env9667 == env9668) = true)

theorem identity9668 : scanCanonicalize (H12AffineFastState.compose env9668 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9668 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env9669 : List Nat := [2,4,8,16,32,11,128,30,184,150,137,32,154,16,58,138,136,168,36,58,153,32,10,35,19,16,26,26,179,146,4,58,172,59,131,16]

theorem envBound9669 : H12AffineFastState.Bounded env9669 := by
  intro p hp
  have h : env9669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9668_9669 : H12AffineEnvironment.transform 5 11 env9668 = env9669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9668 == env9669) = true)

theorem identity9669 : scanCanonicalize (H12AffineFastState.compose env9669 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9669 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env9670 : List Nat := [2,4,8,16,32,11,19,30,43,5,26,32,9,16,58,25,27,59,36,58,10,32,10,35,19,16,26,26,32,1,4,58,63,59,16,16]

theorem envBound9670 : H12AffineFastState.Bounded env9670 := by
  intro p hp
  have h : env9670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9669_9670 : H12AffineEnvironment.transform 6 19 env9669 = env9670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9669 == env9670) = true)

theorem identity9670 : scanCanonicalize (H12AffineFastState.compose env9670 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9670 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9671 : List Nat := [2,4,8,16,16,11,19,30,27,5,26,16,9,16,10,25,27,11,20,10,10,16,10,19,19,16,26,26,16,1,4,10,15,11,16,16]

theorem envBound9671 : H12AffineFastState.Bounded env9671 := by
  intro p hp
  have h : env9671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9670_9671 : H12AffineEnvironment.transform 4 16 env9670 = env9671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9670 == env9671) = true)

theorem identity9671 : scanCanonicalize (H12AffineFastState.compose env9671 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9671 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env9672 : List Nat := [2,4,3,16,16,0,19,21,16,5,17,16,2,16,1,18,16,0,20,1,1,16,1,19,19,16,17,17,16,1,4,1,4,0,16,16]

theorem envBound9672 : H12AffineFastState.Bounded env9672 := by
  intro p hp
  have h : env9672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9671_9672 : H12AffineEnvironment.transform 2 3 env9671 = env9672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9671 == env9672) = true)

def leafEnv9672 : List Nat := [2,4,3,16,16,0,19,21,16,5,17,16,2,16,1,18,16,0,20,1,1,16,1,19,21,19,1,16,17,17,16,1,4,1,4,0,21,2,16,16,1,0,0]

def active9672 : List Nat := [0,1,3]

def tree9672 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9672 : H12WitnessSearch.Good tree9672 := H12GlobalWitnessIndex.good

theorem leafIdentity9672 : H12AffineFastState.composeSystem env9672 rootObs = leafEnv9672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9672 rootObs == leafEnv9672) = true)

theorem terminalChecked9672 : H12PackedTerminal.terminalCheckFast leafEnv9672 active9672 tree9672 = true := by decide +kernel

def env9673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,26051,4605,262144,524288,8693,529265,16741,525805,35,8329,21453,279905,5292,5456,19912,530021,1529,525568,17896,540925,1021]

theorem envBound9673 : H12AffineFastState.Bounded env9673 := by
  intro p hp
  have h : env9673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9654_9673 : H12AffineEnvironment.transform 20 529265 env9654 = env9673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529265 env9654 == env9673) = true)

theorem identity9673 : scanCanonicalize (H12AffineFastState.compose env9673 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9673 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9674 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,25662,4096,262144,524288,8200,529036,16536,525328,35,8329,21040,279708,5292,5293,19509,530021,1028,525565,17429,540925,512]

theorem envBound9674 : H12AffineFastState.Bounded env9674 := by
  intro p hp
  have h : env9674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9673_9674 : H12AffineEnvironment.transform 7 253 env9673 = env9674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9673 == env9674) = true)

theorem identity9674 : scanCanonicalize (H12AffineFastState.compose env9674 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 16) := by decide +kernel

theorem selectedBound9674 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9675 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16,8200,9262,4096,262144,524288,8200,529036,136,525328,35,8329,4640,263308,5292,5293,3109,530021,1028,525565,1029,524525,512]

theorem envBound9675 : H12AffineFastState.Bounded env9675 := by
  intro p hp
  have h : env9675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9674_9675 : H12AffineEnvironment.transform 13 16 env9674 = env9675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16 env9674 == env9675) = true)

theorem identity9675 : scanCanonicalize (H12AffineFastState.compose env9675 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound9675 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9676 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8200,8234,4096,262144,524288,8200,529036,136,524308,35,8329,4640,262280,4264,4265,2081,528993,0,524537,1,524525,512]

theorem envBound9676 : H12AffineFastState.Bounded env9676 := by
  intro p hp
  have h : env9676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9675_9676 : H12AffineEnvironment.transform 9 4 env9675 = env9676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env9675 == env9676) = true)

theorem identity9676 : scanCanonicalize (H12AffineFastState.compose env9676 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(18+1) ^^^ 4268) := by decide +kernel

theorem selectedBound9676 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9677 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8200,8234,4096,262144,4268,8200,544,136,4280,35,8329,4640,262280,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9677 : H12AffineFastState.Bounded env9677 := by
  intro p hp
  have h : env9677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9676_9677 : H12AffineEnvironment.transform 18 4268 env9676 = env9677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4268 env9676 == env9677) = true)

theorem identity9677 : scanCanonicalize (H12AffineFastState.compose env9677 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(17+1) ^^^ 14544) := by decide +kernel

theorem selectedBound9677 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9678 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,8192,16,8200,8234,4096,14544,4268,8200,544,136,4280,35,8329,4640,14424,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9678 : H12AffineFastState.Bounded env9678 := by
  intro p hp
  have h : env9678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9677_9678 : H12AffineEnvironment.transform 17 14544 env9677 = env9678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 14544 env9677 == env9678) = true)

theorem identity9678 : scanCanonicalize (H12AffineFastState.compose env9678 (packedSelected [0,6,27] rootPS)) = affineNative (2^(12+1) ^^^ 6907) := by decide +kernel

theorem selectedBound9678 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9679 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,4096,6907,16,6899,6865,4096,555,4268,6899,544,136,4280,35,6770,4640,675,4264,4265,2081,717,0,4181,1,4161,512]

theorem envBound9679 : H12AffineFastState.Bounded env9679 := by
  intro p hp
  have h : env9679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9678_9679 : H12AffineEnvironment.transform 12 6907 env9678 = env9679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6907 env9678 == env9679) = true)

theorem identity9679 : scanCanonicalize (H12AffineFastState.compose env9679 (packedSelected [11,12,13,15,32] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound9679 : packedSelected [11,12,13,15,32] rootPS < 2^1333 := by decide +kernel

def env9680 : List Nat := [2,4,8,16,32,64,128,253,97,4,2048,4096,6298,16,6290,6320,4096,74,4268,6290,65,136,4280,35,6163,4161,194,4264,4265,2081,172,0,4181,1,4161,97]

theorem envBound9680 : H12AffineFastState.Bounded env9680 := by
  intro p hp
  have h : env9680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9679_9680 : H12AffineEnvironment.transform 8 97 env9679 = env9680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9679 == env9680) = true)

theorem identity9680 : scanCanonicalize (H12AffineFastState.compose env9680 (packedSelected [2,13,14] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound9680 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9681 : List Nat := [2,4,8,16,32,64,128,253,97,4,27,4096,4225,16,4233,4267,4096,74,4268,4233,65,136,4280,35,4104,4161,194,4264,4265,58,172,0,4181,1,4161,97]

theorem envBound9681 : H12AffineFastState.Bounded env9681 := by
  intro p hp
  have h : env9681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9680_9681 : H12AffineEnvironment.transform 10 27 env9680 = env9681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env9680 == env9681) = true)

theorem identity9681 : scanCanonicalize (H12AffineFastState.compose env9681 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound9681 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9682 : List Nat := [2,4,8,16,32,64,128,253,97,4,27,80,209,16,217,251,80,74,252,217,65,136,232,35,88,17,194,248,249,58,172,0,5,1,17,97]

theorem envBound9682 : H12AffineFastState.Bounded env9682 := by
  intro p hp
  have h : env9682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9681_9682 : H12AffineEnvironment.transform 11 80 env9681 = env9682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env9681 == env9682) = true)

theorem identity9682 : scanCanonicalize (H12AffineFastState.compose env9682 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9682 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9683 : List Nat := [2,4,8,16,32,64,40,85,97,4,27,80,121,16,113,83,80,74,84,113,65,32,64,35,88,17,106,80,81,58,4,0,5,1,17,97]

theorem envBound9683 : H12AffineFastState.Bounded env9683 := by
  intro p hp
  have h : env9683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9682_9683 : H12AffineEnvironment.transform 6 40 env9682 = env9683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9682 == env9683) = true)

theorem identity9683 : scanCanonicalize (H12AffineFastState.compose env9683 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9684 : List Nat := [2,4,8,16,27,64,19,85,90,4,27,80,66,16,74,83,80,74,84,74,65,27,64,24,88,17,81,80,81,1,4,0,5,1,17,90]

theorem envBound9684 : H12AffineFastState.Bounded env9684 := by
  intro p hp
  have h : env9684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9683_9684 : H12AffineEnvironment.transform 4 27 env9683 = env9684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9683 == env9684) = true)

theorem identity9684 : scanCanonicalize (H12AffineFastState.compose env9684 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound9684 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9685 : List Nat := [2,4,8,16,27,1,19,20,27,4,27,17,3,16,11,18,17,11,21,11,0,27,1,24,25,17,16,17,16,1,4,0,5,1,17,27]

theorem envBound9685 : H12AffineFastState.Bounded env9685 := by
  intro p hp
  have h : env9685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9684_9685 : H12AffineEnvironment.transform 5 1 env9684 = env9685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env9684 == env9685) = true)

theorem identity9685 : scanCanonicalize (H12AffineFastState.compose env9685 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9685 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9686 : List Nat := [2,4,2,16,17,1,19,20,17,4,17,17,3,16,1,18,17,1,21,1,0,17,1,18,19,17,16,17,16,1,4,0,5,1,17,17]

theorem envBound9686 : H12AffineFastState.Bounded env9686 := by
  intro p hp
  have h : env9686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9685_9686 : H12AffineEnvironment.transform 2 2 env9685 = env9686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9685 == env9686) = true)

def leafEnv9686 : List Nat := [2,4,2,16,17,1,19,20,17,4,17,17,3,16,1,18,17,1,21,1,0,17,1,18,21,19,1,17,16,17,16,1,4,0,5,1,21,3,17,17,1,0,0]

def active9686 : List Nat := [0,1,3]

def tree9686 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9686 : H12WitnessSearch.Good tree9686 := H12GlobalWitnessIndex.good

theorem leafIdentity9686 : H12AffineFastState.composeSystem env9686 rootObs = leafEnv9686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9686 rootObs == leafEnv9686) = true)

theorem terminalChecked9686 : H12PackedTerminal.terminalCheckFast leafEnv9686 active9686 tree9686 = true := by decide +kernel

def env9687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4605,262144,524288,8693,2097152,16741,525805,91617,8329,79374,279905,5292,5456,75786,619431,90171,525568,73770,2118540,91711]

theorem envBound9687 : H12AffineFastState.Bounded env9687 := by
  intro p hp
  have h : env9687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9652_9687 : H12AffineEnvironment.transform 23 91617 env9652 = env9687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 91617 env9652 == env9687) = true)

theorem identity9687 : scanCanonicalize (H12AffineFastState.compose env9687 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9687 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9688 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91164,8329,79374,279708,5292,5293,75786,619098,90171,525565,73770,2118257,91711]

theorem envBound9688 : H12AffineFastState.Bounded env9688 := by
  intro p hp
  have h : env9688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9687_9688 : H12AffineEnvironment.transform 7 253 env9687 = env9688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9687 == env9688) = true)

def env9689 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91164,8329,78958,279708,5292,5293,75786,618554,90171,525565,73770,2117649,91231]

theorem envBound9689 : H12AffineFastState.Bounded env9689 := by
  intro p hp
  have h : env9689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9688_9689 : H12AffineEnvironment.transform 8 96 env9688 = env9689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9688 == env9689) = true)

theorem identity9689 : scanCanonicalize (H12AffineFastState.compose env9689 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound9689 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9690 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,16384,8200,25663,4096,262144,524288,8200,2097152,16536,525328,35,8329,20561,279708,5292,5293,19509,529413,1028,525565,17429,2117649,96]

theorem envBound9690 : H12AffineFastState.Bounded env9690 := by
  intro p hp
  have h : env9690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9689_9690 : H12AffineEnvironment.transform 15 25663 env9689 = env9690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env9689 == env9690) = true)

theorem identity9690 : scanCanonicalize (H12AffineFastState.compose env9690 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9690 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9691 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8200,9262,4096,262144,524288,8200,2097152,137,525328,35,8329,4160,263309,5292,5293,3108,529413,1028,525565,1028,2101248,96]

theorem envBound9691 : H12AffineFastState.Bounded env9691 := by
  intro p hp
  have h : env9691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9690_9691 : H12AffineEnvironment.transform 13 17 env9690 = env9691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9690 == env9691) = true)

theorem identity9691 : scanCanonicalize (H12AffineFastState.compose env9691 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 529640) := by decide +kernel

theorem selectedBound9691 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9692 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8200,9262,4096,262144,524288,8200,529640,137,525328,35,8329,4160,263309,5292,5293,3108,529413,1028,525565,1028,525544,96]

theorem envBound9692 : H12AffineFastState.Bounded env9692 := by
  intro p hp
  have h : env9692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9691_9692 : H12AffineEnvironment.transform 20 529640 env9691 = env9692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529640 env9691 == env9692) = true)

theorem identity9692 : scanCanonicalize (H12AffineFastState.compose env9692 (packedSelected [2,11,12,13,14,15,23] rootPS)) = affineNative (2^(18+1) ^^^ 13473) := by decide +kernel

theorem selectedBound9692 : packedSelected [2,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env9693 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8200,9262,4096,262144,13473,8200,8265,137,12465,35,8329,4160,263309,5292,5293,3108,8356,1028,12380,1028,12361,96]

theorem envBound9693 : H12AffineFastState.Bounded env9693 := by
  intro p hp
  have h : env9693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9692_9693 : H12AffineEnvironment.transform 18 13473 env9692 = env9693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 13473 env9692 == env9693) = true)

theorem identity9693 : scanCanonicalize (H12AffineFastState.compose env9693 (packedSelected [0,6,27] rootPS)) = affineNative (2^(17+1) ^^^ 9286) := by decide +kernel

theorem selectedBound9693 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env9694 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8192,17,8200,9262,4096,9286,13473,8200,8265,137,12465,35,8329,4160,8395,5292,5293,3108,8356,1028,12380,1028,12361,96]

theorem envBound9694 : H12AffineFastState.Bounded env9694 := by
  intro p hp
  have h : env9694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9693_9694 : H12AffineEnvironment.transform 17 9286 env9693 = env9694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9286 env9693 == env9694) = true)

theorem identity9694 : scanCanonicalize (H12AffineFastState.compose env9694 (packedSelected [12,13,38] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9694 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env9695 : List Nat := [2,4,8,16,32,64,128,253,96,1024,2048,4096,8,17,0,1062,4096,1102,5289,0,65,137,4281,35,129,4160,195,5292,5293,3108,172,1028,4180,1028,4161,96]

theorem envBound9695 : H12AffineFastState.Bounded env9695 := by
  intro p hp
  have h : env9695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9694_9695 : H12AffineEnvironment.transform 12 8 env9694 = env9695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9694 == env9695) = true)

theorem identity9695 : scanCanonicalize (H12AffineFastState.compose env9695 (packedSelected [2,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9695 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env9696 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,4096,8,17,0,1062,4096,1102,5121,0,65,33,4113,35,41,4160,107,5124,5125,3108,4,1028,4180,1028,4161,96]

theorem envBound9696 : H12AffineFastState.Bounded env9696 := by
  intro p hp
  have h : env9696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9695_9696 : H12AffineEnvironment.transform 6 40 env9695 = env9696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9695 == env9696) = true)

theorem identity9696 : scanCanonicalize (H12AffineFastState.compose env9696 (packedSelected [2,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound9696 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env9697 : List Nat := [2,4,8,16,32,64,40,85,96,1024,2048,1109,8,17,0,1062,1109,1102,84,0,65,33,1092,35,41,1045,107,81,80,3108,4,1028,1025,1028,1044,96]

theorem envBound9697 : H12AffineFastState.Bounded env9697 := by
  intro p hp
  have h : env9697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9696_9697 : H12AffineEnvironment.transform 11 1109 env9696 = env9697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env9696 == env9697) = true)

def env9698 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,2097152,16536,525328,91164,8329,78959,279708,5292,5293,75786,618555,90171,525565,73770,2117648,91230]

theorem envBound9698 : H12AffineFastState.Bounded env9698 := by
  intro p hp
  have h : env9698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9688_9698 : H12AffineEnvironment.transform 8 97 env9688 = env9698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env9688 == env9698) = true)

theorem identity9698 : scanCanonicalize (H12AffineFastState.compose env9698 (packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound9698 : packedSelected [0,1,2,7,8,11,13,14,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env9699 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9263,4096,262144,524288,8200,2097152,16536,525328,16435,8329,4160,279708,5292,5293,3109,545812,17428,525565,1029,2117648,16497]

theorem envBound9699 : H12AffineFastState.Bounded env9699 := by
  intro p hp
  have h : env9699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9698_9699 : H12AffineEnvironment.transform 15 9263 env9698 = env9699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env9698 == env9699) = true)

theorem identity9699 : scanCanonicalize (H12AffineFastState.compose env9699 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 545020) := by decide +kernel

theorem selectedBound9699 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9700 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9263,4096,262144,524288,8200,545020,16536,525328,16435,8329,4160,279708,5292,5293,3109,545812,17428,525565,1029,524524,16497]

theorem envBound9700 : H12AffineFastState.Bounded env9700 := by
  intro p hp
  have h : env9700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9699_9700 : H12AffineEnvironment.transform 20 545020 env9699 = env9700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 545020 env9699 == env9700) = true)

theorem identity9700 : scanCanonicalize (H12AffineFastState.compose env9700 (packedSelected [0,3,5,6,10,27] rootPS)) = affineNative (2^(18+1) ^^^ 282654) := by decide +kernel

theorem selectedBound9700 : packedSelected [0,3,5,6,10,27] rootPS < 2^1333 := by decide +kernel

def env9701 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9263,4096,262144,282654,8200,262370,16536,283662,16435,8329,4160,279708,5292,5293,3109,263178,17428,283875,1029,282866,16497]

theorem envBound9701 : H12AffineFastState.Bounded env9701 := by
  intro p hp
  have h : env9701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9700_9701 : H12AffineEnvironment.transform 18 282654 env9700 = env9701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 282654 env9700 == env9701) = true)

theorem identity9701 : scanCanonicalize (H12AffineFastState.compose env9701 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 17591) := by decide +kernel

theorem selectedBound9701 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9702 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,16384,8200,9263,4096,17591,5289,8200,17493,16536,4281,16435,8329,4160,43,5292,5293,3109,16573,17428,4180,1029,5189,16497]

theorem envBound9702 : H12AffineFastState.Bounded env9702 := by
  intro p hp
  have h : env9702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9701_9702 : H12AffineEnvironment.transform 17 17591 env9701 = env9702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17591 env9701 == env9702) = true)

theorem identity9702 : scanCanonicalize (H12AffineFastState.compose env9702 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound9702 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9703 : List Nat := [2,4,8,16,32,64,128,253,97,1024,2048,4096,8192,17,8200,9263,4096,1190,5289,8200,1092,137,4281,34,8329,4160,43,5292,5293,3109,172,1029,4180,1029,5189,96]

theorem envBound9703 : H12AffineFastState.Bounded env9703 := by
  intro p hp
  have h : env9703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9702_9703 : H12AffineEnvironment.transform 13 17 env9702 = env9703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env9702 == env9703) = true)

end H12CloudChart1