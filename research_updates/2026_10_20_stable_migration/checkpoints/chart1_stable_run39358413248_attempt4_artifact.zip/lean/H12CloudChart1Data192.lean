import H12CloudChart1Data191

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env48638 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,212150,1024,29829,77850,201783,73754,95496,8328,16,215319,79131,17664,10280,75143,144565,256,21792,16385,513]

theorem envBound48638 : H12AffineFastState.Bounded env48638 := by
  intro p hp
  have h : env48638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48637_48638 : H12AffineEnvironment.transform 14 29828 env48637 = env48638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env48637 == env48638) = true)

theorem identity48638 : scanCanonicalize (H12AffineFastState.compose env48638 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48638 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env48639 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8322,131072,138292,1024,29829,4248,144565,152,21898,8328,16,158101,5529,17664,10280,1285,144565,256,21792,16385,513]

theorem envBound48639 : H12AffineFastState.Bounded env48639 := by
  intro p hp
  have h : env48639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48638_48639 : H12AffineEnvironment.transform 15 8322 env48638 = env48639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48638 == env48639) = true)

theorem identity48639 : scanCanonicalize (H12AffineFastState.compose env48639 (packedSelected [2,3,6,10,16,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48639 : packedSelected [2,3,6,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env48640 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8322,13341,10281,1024,29829,4248,168,152,21898,8328,16,23944,5529,17664,10280,1285,168,256,21792,16385,513]

theorem envBound48640 : H12AffineFastState.Bounded env48640 := by
  intro p hp
  have h : env48640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48639_48640 : H12AffineEnvironment.transform 16 13341 env48639 = env48640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env48639 == env48640) = true)

theorem identity48640 : scanCanonicalize (H12AffineFastState.compose env48640 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound48640 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48641 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,16384,20497,1047,4232,3260,1024,20496,4248,168,152,21898,1053,16,23944,5529,17664,3261,1285,168,256,21792,16385,513]

theorem envBound48641 : H12AffineFastState.Bounded env48641 := by
  intro p hp
  have h : env48641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48640_48641 : H12AffineEnvironment.transform 12 1173 env48640 = env48641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env48640 == env48641) = true)

theorem identity48641 : scanCanonicalize (H12AffineFastState.compose env48641 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound48641 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env48642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,4248,137,1047,4232,3260,1024,136,4248,168,152,1298,1053,16,3344,5529,5528,3261,1285,168,256,1464,4249,513]

theorem envBound48642 : H12AffineFastState.Bounded env48642 := by
  intro p hp
  have h : env48642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48641_48642 : H12AffineEnvironment.transform 13 4248 env48641 = env48642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env48641 == env48642) = true)

theorem identity48642 : scanCanonicalize (H12AffineFastState.compose env48642 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound48642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48643 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,269,4248,137,399,4232,2340,408,136,4248,168,152,138,389,16,2184,4097,4096,2341,157,168,256,32,4249,513]

theorem envBound48643 : H12AffineFastState.Bounded env48643 := by
  intro p hp
  have h : env48643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48642_48643 : H12AffineEnvironment.transform 9 408 env48642 = env48643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env48642 == env48643) = true)

theorem identity48643 : scanCanonicalize (H12AffineFastState.compose env48643 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound48643 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env48644 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,2493,269,2341,137,399,2357,2340,408,136,2341,168,152,138,389,16,2184,2492,2493,2341,157,168,256,32,2340,513]

theorem envBound48644 : H12AffineFastState.Bounded env48644 := by
  intro p hp
  have h : env48644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48643_48644 : H12AffineEnvironment.transform 11 2493 env48643 = env48644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env48643 == env48644) = true)

theorem identity48644 : scanCanonicalize (H12AffineFastState.compose env48644 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48644 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env48645 : List Nat := [2,4,8,16,32,17,128,37,512,189,2048,2200,40,2048,137,170,2064,2049,189,136,2048,168,152,138,160,16,2184,2201,2200,2048,157,168,37,32,2049,513]

theorem envBound48645 : H12AffineFastState.Bounded env48645 := by
  intro p hp
  have h : env48645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48644_48645 : H12AffineEnvironment.transform 7 37 env48644 = env48645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48644 == env48645) = true)

theorem identity48645 : scanCanonicalize (H12AffineFastState.compose env48645 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48645 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48646 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,40,2048,0,35,2064,2049,52,1,2048,33,17,3,41,16,2049,2064,2065,2048,20,33,37,32,2049,513]

theorem envBound48646 : H12AffineFastState.Bounded env48646 := by
  intro p hp
  have h : env48646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48645_48646 : H12AffineEnvironment.transform 6 9 env48645 = env48646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48645 == env48646) = true)

theorem identity48646 : scanCanonicalize (H12AffineFastState.compose env48646 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48647 : List Nat := [2,4,8,16,32,17,9,37,33,52,2048,2065,40,2048,0,35,2064,2049,52,1,2048,33,17,3,41,16,2049,2064,2065,2048,20,33,37,32,2049,32]

theorem envBound48647 : H12AffineFastState.Bounded env48647 := by
  intro p hp
  have h : env48647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48646_48647 : H12AffineEnvironment.transform 8 33 env48646 = env48647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48646 == env48647) = true)

def env48648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452649,2114882,8328,65,6385003,115151,2538872,10281,2566522,4268163,256,485831,493666,2494125]

theorem envBound48648 : H12AffineFastState.Bounded env48648 := by
  intro p hp
  have h : env48648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48557_48648 : H12AffineEnvironment.transform 22 452649 env48557 = env48648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env48557 == env48648) = true)

def env48649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,441658,8328,65,4691219,115151,17664,10281,119042,4268163,256,485831,493666,63189]

theorem envBound48649 : H12AffineFastState.Bounded env48649 := by
  intro p hp
  have h : env48649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48648_48649 : H12AffineEnvironment.transform 20 456824 env48648 = env48649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env48648 == env48649) = true)

def env48650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,441658,8328,65,245139,115151,17664,10281,119042,329731,256,485831,493666,63189]

theorem envBound48650 : H12AffineFastState.Bounded env48650 := by
  intro p hp
  have h : env48650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48649_48650 : H12AffineEnvironment.transform 21 272512 env48649 = env48650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48649 == env48650) = true)

theorem identity48650 : scanCanonicalize (H12AffineFastState.compose env48650 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound48650 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,58517,144493,62660,41431,8328,65,245139,115151,17664,10281,119042,201966,256,95530,103567,63189]

theorem envBound48651 : H12AffineFastState.Bounded env48651 := by
  intro p hp
  have h : env48651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48650_48651 : H12AffineEnvironment.transform 17 138477 env48650 = env48651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env48650 == env48651) = true)

def env48652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138429,1024,32769,58517,144445,62612,41351,8328,17,245139,115103,17664,10281,119042,201918,256,95530,103567,63109]

theorem envBound48652 : H12AffineFastState.Bounded env48652 := by
  intro p hp
  have h : env48652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48651_48652 : H12AffineEnvironment.transform 5 16 env48651 = env48652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48651 == env48652) = true)

theorem identity48652 : scanCanonicalize (H12AffineFastState.compose env48652 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound48652 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env48653 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,138429,1024,8460,17816,144445,21913,138,8328,17,203934,90258,17664,10281,94223,201918,256,95530,79234,22408]

theorem envBound48653 : H12AffineFastState.Bounded env48653 := by
  intro p hp
  have h : env48653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48652_48653 : H12AffineEnvironment.transform 14 8461 env48652 = env48653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env48652 == env48653) = true)

theorem identity48653 : scanCanonicalize (H12AffineFastState.compose env48653 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48653 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env48654 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,13341,10400,1024,8460,17816,32,21913,138,8328,17,75907,90258,17664,10281,94223,73891,256,95530,79234,22408]

theorem envBound48654 : H12AffineFastState.Bounded env48654 := by
  intro p hp
  have h : env48654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48653_48654 : H12AffineEnvironment.transform 16 13341 env48653 = env48654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env48653 == env48654) = true)

theorem identity48654 : scanCanonicalize (H12AffineFastState.compose env48654 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48654 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48655 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,13341,10280,1024,8460,17680,32,21777,2,8192,17,75787,90138,17664,10281,94223,73771,256,95530,79114,22272]

theorem envBound48655 : H12AffineFastState.Bounded env48655 := by
  intro p hp
  have h : env48655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48654_48655 : H12AffineEnvironment.transform 6 8 env48654 = env48655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48654 == env48655) = true)

theorem identity48655 : scanCanonicalize (H12AffineFastState.compose env48655 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound48655 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env48656 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,3345,8461,65536,13341,10280,1024,8460,2049,32,6144,2,8192,17,75787,77067,2065,10281,81182,73771,256,79931,79114,6673]

theorem envBound48656 : H12AffineFastState.Bounded env48656 := by
  intro p hp
  have h : env48656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48655_48656 : H12AffineEnvironment.transform 13 3345 env48655 = env48656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env48655 == env48656) = true)

theorem identity48656 : scanCanonicalize (H12AffineFastState.compose env48656 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound48656 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env48657 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6428,3345,6161,65536,3329,4404,1024,6160,2049,32,6144,2,6428,17,69911,70679,2065,4405,66562,71991,256,65831,68630,6673]

theorem envBound48657 : H12AffineFastState.Bounded env48657 := by
  intro p hp
  have h : env48657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48656_48657 : H12AffineEnvironment.transform 12 6428 env48656 = env48657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env48656 == env48657) = true)

theorem identity48657 : scanCanonicalize (H12AffineFastState.compose env48657 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48657 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48658 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6428,3345,6161,263,3329,4404,1024,6160,2049,32,6144,2,6428,17,4112,5392,2065,4405,1285,6192,256,32,3345,6673]

theorem envBound48658 : H12AffineFastState.Bounded env48658 := by
  intro p hp
  have h : env48658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48657_48658 : H12AffineEnvironment.transform 15 263 env48657 = env48658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48657 == env48658) = true)

theorem identity48658 : scanCanonicalize (H12AffineFastState.compose env48658 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound48658 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env48659 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1572,4096,5944,821,5685,263,805,4404,1024,5684,1573,32,5668,2,5944,17,4112,5392,1589,4405,1285,5652,256,32,821,5173]

theorem envBound48659 : H12AffineFastState.Bounded env48659 := by
  intro p hp
  have h : env48659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48658_48659 : H12AffineEnvironment.transform 10 1572 env48658 = env48659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env48658 == env48659) = true)

theorem identity48659 : scanCanonicalize (H12AffineFastState.compose env48659 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound48659 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env48660 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1572,513,1337,821,1076,263,805,821,1024,1077,1573,32,1061,2,1337,17,529,1809,1589,820,1285,1045,256,32,821,1588]

theorem envBound48660 : H12AffineFastState.Bounded env48660 := by
  intro p hp
  have h : env48660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48659_48660 : H12AffineEnvironment.transform 11 513 env48659 = env48660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env48659 == env48660) = true)

theorem identity48660 : scanCanonicalize (H12AffineFastState.compose env48660 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound48660 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48661 : List Nat := [2,4,8,16,32,16,8,256,512,304,788,513,9,821,260,263,805,821,304,261,789,32,277,2,9,17,529,545,773,820,53,293,256,32,821,772]

theorem envBound48661 : H12AffineFastState.Bounded env48661 := by
  intro p hp
  have h : env48661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48660_48661 : H12AffineEnvironment.transform 9 304 env48660 = env48661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env48660 == env48661) = true)

theorem identity48661 : scanCanonicalize (H12AffineFastState.compose env48661 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48661 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48662 : List Nat := [2,4,8,16,32,16,8,256,49,304,293,48,9,260,260,263,276,260,304,261,292,32,277,2,9,17,32,16,308,261,53,293,256,32,260,309]

theorem envBound48662 : H12AffineFastState.Bounded env48662 := by
  intro p hp
  have h : env48662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48661_48662 : H12AffineEnvironment.transform 8 49 env48661 = env48662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48661 == env48662) = true)

theorem identity48662 : scanCanonicalize (H12AffineFastState.compose env48662 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48663 : List Nat := [2,4,8,16,16,16,8,256,1,256,277,0,9,260,260,263,276,260,256,261,276,16,277,2,9,17,16,16,260,261,5,277,256,16,260,261]

theorem envBound48663 : H12AffineFastState.Bounded env48663 := by
  intro p hp
  have h : env48663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48662_48663 : H12AffineEnvironment.transform 4 16 env48662 = env48663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48662 == env48663) = true)

theorem identity48663 : scanCanonicalize (H12AffineFastState.compose env48663 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48663 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48664 : List Nat := [2,4,8,16,16,16,8,21,1,21,0,0,9,17,17,18,1,17,21,16,1,16,0,2,9,17,16,16,17,16,5,0,21,16,17,16]

theorem envBound48664 : H12AffineFastState.Bounded env48664 := by
  intro p hp
  have h : env48664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48663_48664 : H12AffineEnvironment.transform 7 21 env48663 = env48664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48663 == env48664) = true)

def env48665 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138428,1024,32769,58517,144444,62613,41350,8328,16,245139,115102,17664,10281,119042,201919,256,95530,103567,63108]

theorem envBound48665 : H12AffineFastState.Bounded env48665 := by
  intro p hp
  have h : env48665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48651_48665 : H12AffineEnvironment.transform 5 17 env48651 = env48665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48651 == env48665) = true)

theorem identity48665 : scanCanonicalize (H12AffineFastState.compose env48665 (packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48665 : packedSelected [0,4,7,11,15,16,19,20,22,26,32,38] rootPS < 2^1333 := by decide +kernel

def env48666 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138293,1024,32769,58396,144444,62492,41231,8193,16,245018,114967,17664,10281,119042,201782,256,95530,103430,62989]

theorem envBound48666 : H12AffineFastState.Bounded env48666 := by
  intro p hp
  have h : env48666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48665_48666 : H12AffineEnvironment.transform 6 9 env48665 = env48666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48665 == env48666) = true)

theorem identity48666 : scanCanonicalize (H12AffineFastState.compose env48666 (packedSelected [0,1,3,4,8,12,14,15,16,19,22,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound48666 : packedSelected [0,1,3,4,8,12,14,15,16,19,22,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env48667 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,13625,10508,1024,32769,58396,261,62492,41231,8193,16,100387,114967,17664,10281,119042,73999,256,95530,103430,62989]

theorem envBound48667 : H12AffineFastState.Bounded env48667 := by
  intro p hp
  have h : env48667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48666_48667 : H12AffineEnvironment.transform 16 13625 env48666 = env48667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env48666 == env48667) = true)

theorem identity48667 : scanCanonicalize (H12AffineFastState.compose env48667 (packedSelected [0,1,2,4,5,6,8,9,11,18,19,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48667 : packedSelected [0,1,2,4,5,6,8,9,11,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48668 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,13625,10508,1024,32769,45341,261,41245,41231,8193,16,100387,103446,4097,10281,99331,73999,256,73771,103430,41740]

theorem envBound48668 : H12AffineFastState.Bounded env48668 := by
  intro p hp
  have h : env48668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48667_48668 : H12AffineEnvironment.transform 13 5377 env48667 = env48668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48667 == env48668) = true)

theorem identity48668 : scanCanonicalize (H12AffineFastState.compose env48668 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48668 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,23] rootPS < 2^1333 := by decide +kernel

def env48669 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,32768,65536,13341,10280,1024,32769,45113,33,41017,41003,8193,16,100387,103446,4097,10281,99331,73771,36,73771,103430,41512]

theorem envBound48669 : H12AffineFastState.Bounded env48669 := by
  intro p hp
  have h : env48669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48668_48669 : H12AffineEnvironment.transform 7 36 env48668 = env48669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48668 == env48669) = true)

theorem identity48669 : scanCanonicalize (H12AffineFastState.compose env48669 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound48669 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env48670 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,6200,5157,32768,65536,3109,4112,1024,32769,34817,33,38913,38931,6201,16,100387,103446,4097,4113,99331,71699,36,71699,103430,39440]

theorem envBound48670 : H12AffineFastState.Bounded env48670 := by
  intro p hp
  have h : env48670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48669_48670 : H12AffineEnvironment.transform 12 6200 env48669 = env48670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env48669 == env48670) = true)

theorem identity48670 : scanCanonicalize (H12AffineFastState.compose env48670 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48670 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env48671 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,40,3125,32768,65536,3109,2048,1024,32769,34817,33,32785,32771,41,16,100387,101382,2065,2049,99331,65539,36,65539,101398,33280]

theorem envBound48671 : H12AffineFastState.Bounded env48671 := by
  intro p hp
  have h : env48671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48670_48671 : H12AffineEnvironment.transform 11 2064 env48670 = env48671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48670 == env48671) = true)

theorem identity48671 : scanCanonicalize (H12AffineFastState.compose env48671 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound48671 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env48672 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,40,3125,32768,2083,3109,2048,1024,32769,34817,33,32785,32771,41,16,32768,33829,2065,2049,35872,2080,36,2080,33845,33280]

theorem envBound48672 : H12AffineFastState.Bounded env48672 := by
  intro p hp
  have h : env48672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48671_48672 : H12AffineEnvironment.transform 15 2083 env48671 = env48672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env48671 == env48672) = true)

theorem identity48672 : scanCanonicalize (H12AffineFastState.compose env48672 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound48672 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48673 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1060,1076,40,17,32768,1031,1,1060,1024,32769,33829,33,32785,32771,41,16,32768,33829,1077,1061,32772,1028,36,1028,33845,33280]

theorem envBound48673 : H12AffineFastState.Bounded env48673 := by
  intro p hp
  have h : env48673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48672_48673 : H12AffineEnvironment.transform 10 1060 env48672 = env48673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env48672 == env48673) = true)

theorem identity48673 : scanCanonicalize (H12AffineFastState.compose env48673 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 1061) := by decide +kernel

theorem selectedBound48673 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env48674 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1060,1076,40,17,1061,1031,1,1060,1024,1060,0,33,1076,1062,41,16,1061,0,1077,1061,1057,1028,36,1028,16,1573]

theorem envBound48674 : H12AffineFastState.Bounded env48674 := by
  intro p hp
  have h : env48674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48673_48674 : H12AffineEnvironment.transform 14 1061 env48673 = env48674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1061 env48673 == env48674) = true)

theorem identity48674 : scanCanonicalize (H12AffineFastState.compose env48674 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48674 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48675 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1028,1044,8,17,1029,1031,1,1028,1024,1028,0,1,1044,1030,9,16,1029,0,1045,1029,1025,1028,4,1028,16,1541]

theorem envBound48675 : H12AffineFastState.Bounded env48675 := by
  intro p hp
  have h : env48675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48674_48675 : H12AffineEnvironment.transform 4 0 env48674 = env48675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48674 == env48675) = true)

theorem identity48675 : scanCanonicalize (H12AffineFastState.compose env48675 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound48675 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48676 : List Nat := [2,4,8,16,0,17,9,4,512,517,513,529,8,17,512,514,1,513,517,513,0,1,529,515,9,16,512,0,528,512,516,513,4,513,16,0]

theorem envBound48676 : H12AffineFastState.Bounded env48676 := by
  intro p hp
  have h : env48676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48675_48676 : H12AffineEnvironment.transform 9 517 env48675 = env48676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env48675 == env48676) = true)

theorem identity48676 : scanCanonicalize (H12AffineFastState.compose env48676 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48676 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48677 : List Nat := [2,4,8,0,0,1,9,4,512,517,513,513,8,1,512,514,1,513,517,513,0,1,513,515,9,0,512,0,512,512,516,513,4,513,0,0]

theorem envBound48677 : H12AffineFastState.Bounded env48677 := by
  intro p hp
  have h : env48677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48676_48677 : H12AffineEnvironment.transform 3 0 env48676 = env48677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48676 == env48677) = true)

def env48678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,441658,8328,65,245138,115151,17664,10281,119042,329730,256,485831,493666,63189]

theorem envBound48678 : H12AffineFastState.Bounded env48678 := by
  intro p hp
  have h : env48678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48649_48678 : H12AffineEnvironment.transform 21 272513 env48649 = env48678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48649 == env48678) = true)

theorem identity48678 : scanCanonicalize (H12AffineFastState.compose env48678 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound48678 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396460,272513,400637,412142,8328,65,215366,79131,17664,10281,75222,329730,256,485831,490678,513]

theorem envBound48679 : H12AffineFastState.Bounded env48679 := by
  intro p hp
  have h : env48679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48678_48679 : H12AffineEnvironment.transform 14 29908 env48678 = env48679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env48678 == env48679) = true)

def env48680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396324,272393,400501,412006,8192,65,215366,79131,17664,10281,75102,329730,256,485711,490558,513]

theorem envBound48680 : H12AffineFastState.Bounded env48680 := by
  intro p hp
  have h : env48680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48679_48680 : H12AffineEnvironment.transform 6 8 env48679 = env48680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48679 == env48680) = true)

theorem identity48680 : scanCanonicalize (H12AffineFastState.compose env48680 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48680 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env48681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,140300,33,144477,155982,8192,65,215366,79131,17664,10281,75102,73770,256,213351,218134,513]

theorem envBound48681 : H12AffineFastState.Bounded env48681 := by
  intro p hp
  have h : env48681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48680_48681 : H12AffineEnvironment.transform 17 10280 env48680 = env48681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48680 == env48681) = true)

theorem identity48681 : scanCanonicalize (H12AffineFastState.compose env48681 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound48681 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env48682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5393,10280,1024,29789,12573,33,8524,29791,8192,65,89175,79131,17664,10281,75102,73770,256,87158,82183,513]

theorem envBound48682 : H12AffineFastState.Bounded env48682 := by
  intro p hp
  have h : env48682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48681_48682 : H12AffineEnvironment.transform 16 5393 env48681 = env48682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env48681 == env48682) = true)

theorem identity48682 : scanCanonicalize (H12AffineFastState.compose env48682 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48682 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env48683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,65536,5393,2341,1024,21840,4112,33,65,21842,269,65,89175,70678,17664,2340,66643,65831,256,87158,82183,513]

theorem envBound48683 : H12AffineFastState.Bounded env48683 := by
  intro p hp
  have h : env48683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48682_48683 : H12AffineEnvironment.transform 12 269 env48682 = env48683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48682 == env48683) = true)

theorem identity48683 : scanCanonicalize (H12AffineFastState.compose env48683 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound48683 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env48684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,21591,5393,2341,1024,21840,4112,33,65,21842,269,65,2048,16449,17664,2340,20484,21872,256,33,5456,513]

theorem envBound48684 : H12AffineFastState.Bounded env48684 := by
  intro p hp
  have h : env48684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48683_48684 : H12AffineEnvironment.transform 15 21591 env48683 = env48684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env48683 == env48684) = true)

def env48685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396325,272392,400500,412007,8193,65,215366,79131,17664,10281,75103,329730,256,485710,490559,513]

theorem envBound48685 : H12AffineFastState.Bounded env48685 := by
  intro p hp
  have h : env48685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48679_48685 : H12AffineEnvironment.transform 6 9 env48679 = env48685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48679 == env48685) = true)

theorem identity48685 : scanCanonicalize (H12AffineFastState.compose env48685 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound48685 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,355390,272392,359535,338300,8193,65,10589,79131,17664,10281,75103,329730,256,264533,269348,513]

theorem envBound48686 : H12AffineFastState.Bounded env48686 := by
  intro p hp
  have h : env48686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48685_48686 : H12AffineEnvironment.transform 16 90139 env48685 = env48686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env48685 == env48686) = true)

theorem identity48686 : scanCanonicalize (H12AffineFastState.compose env48686 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound48686 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env48687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21510,13341,262144,1024,29788,276536,272392,272489,294266,8193,65,10589,24861,17664,10281,29017,285700,256,264533,269348,513]

theorem envBound48687 : H12AffineFastState.Bounded env48687 := by
  intro p hp
  have h : env48687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48686_48687 : H12AffineEnvironment.transform 15 21510 env48686 = env48687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env48686 == env48687) = true)

theorem identity48687 : scanCanonicalize (H12AffineFastState.compose env48687 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48687 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env48688 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,28777,20530,12329,262144,52,28776,276536,272392,272489,293198,8193,65,10589,24861,16692,10281,29017,284720,256,264533,268304,513]

theorem envBound48688 : H12AffineFastState.Bounded env48688 := by
  intro p hp
  have h : env48688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48687_48688 : H12AffineEnvironment.transform 9 52 env48687 = env48688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48687 == env48688) = true)

theorem identity48688 : scanCanonicalize (H12AffineFastState.compose env48688 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(17+1) ^^^ 22592) := by decide +kernel

theorem selectedBound48688 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env48689 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,28777,20530,12329,22592,52,28776,24696,28744,28713,8462,8193,65,10589,24861,16692,10281,29017,112,256,20757,16464,513]

theorem envBound48689 : H12AffineFastState.Bounded env48689 := by
  intro p hp
  have h : env48689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48688_48689 : H12AffineEnvironment.transform 17 22592 env48688 = env48689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22592 env48688 == env48689) = true)

theorem identity48689 : scanCanonicalize (H12AffineFastState.compose env48689 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48689 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env48690 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28728,20530,12329,22545,52,28729,24617,28697,28713,8462,8193,16,10508,24861,16692,10281,28936,33,256,20757,16385,513]

theorem envBound48690 : H12AffineFastState.Bounded env48690 := by
  intro p hp
  have h : env48690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48689_48690 : H12AffineEnvironment.transform 5 17 env48689 = env48690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48689 == env48690) = true)

theorem identity48690 : scanCanonicalize (H12AffineFastState.compose env48690 (packedSelected [2,3,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 805) := by decide +kernel

theorem selectedBound48690 : packedSelected [2,3,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48691 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,805,13085,4887,12329,6964,52,13084,8972,13116,13068,8462,8193,16,10508,8760,529,10281,12845,33,256,4656,804,513]

theorem envBound48691 : H12AffineFastState.Bounded env48691 := by
  intro p hp
  have h : env48691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48690_48691 : H12AffineEnvironment.transform 13 805 env48690 = env48691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 805 env48690 == env48691) = true)

theorem identity48691 : scanCanonicalize (H12AffineFastState.compose env48691 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound48691 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env48692 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,821,8192,805,8232,34,8988,2049,52,8233,8972,8201,8249,8462,8193,16,10508,8760,529,10281,8472,33,256,261,804,513]

theorem envBound48692 : H12AffineFastState.Bounded env48692 := by
  intro p hp
  have h : env48692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48691_48692 : H12AffineEnvironment.transform 11 821 env48691 = env48692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env48691 == env48692) = true)

theorem identity48692 : scanCanonicalize (H12AffineFastState.compose env48692 (packedSelected [5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound48692 : packedSelected [5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48693 : List Nat := [2,4,8,16,32,17,9,256,512,52,528,821,8192,805,8232,34,8988,529,52,8233,8972,8201,8249,8462,8193,16,8988,8760,529,8761,8472,33,256,261,804,513]

theorem envBound48693 : H12AffineFastState.Bounded env48693 := by
  intro p hp
  have h : env48693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48692_48693 : H12AffineEnvironment.transform 10 528 env48692 = env48693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env48692 == env48693) = true)

theorem identity48693 : scanCanonicalize (H12AffineFastState.compose env48693 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48693 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env48694 : List Nat := [2,4,8,16,32,17,9,5,512,52,528,560,8192,544,8232,34,8729,529,52,8233,8713,8201,8249,8203,8193,16,8729,8760,529,8761,8221,33,5,0,545,513]

theorem envBound48694 : H12AffineFastState.Bounded env48694 := by
  intro p hp
  have h : env48694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48693_48694 : H12AffineEnvironment.transform 7 5 env48693 = env48694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48693 == env48694) = true)

theorem identity48694 : scanCanonicalize (H12AffineFastState.compose env48694 (packedSelected [1,2,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48694 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48695 : List Nat := [2,4,8,16,32,17,9,5,512,52,528,560,41,544,1,34,560,529,52,0,544,32,16,34,40,16,560,529,529,528,52,33,5,0,545,513]

theorem envBound48695 : H12AffineFastState.Bounded env48695 := by
  intro p hp
  have h : env48695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48694_48695 : H12AffineEnvironment.transform 12 41 env48694 = env48695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48694 == env48695) = true)

theorem identity48695 : scanCanonicalize (H12AffineFastState.compose env48695 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48695 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48696 : List Nat := [2,4,8,16,1,17,9,5,512,21,528,529,8,513,1,3,529,529,21,0,513,1,16,3,9,16,529,529,529,528,21,0,5,0,512,513]

theorem envBound48696 : H12AffineFastState.Bounded env48696 := by
  intro p hp
  have h : env48696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48695_48696 : H12AffineEnvironment.transform 4 1 env48695 = env48696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48695 == env48696) = true)

theorem identity48696 : scanCanonicalize (H12AffineFastState.compose env48696 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48697 : List Nat := [2,4,8,1,1,0,9,5,512,4,513,512,8,513,1,3,512,512,4,0,513,1,1,3,9,1,512,512,512,513,4,0,5,0,512,513]

theorem envBound48697 : H12AffineFastState.Bounded env48697 := by
  intro p hp
  have h : env48697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48696_48697 : H12AffineEnvironment.transform 3 1 env48696 = env48697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48696 == env48697) = true)

theorem identity48697 : scanCanonicalize (H12AffineFastState.compose env48697 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48697 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48698 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,1,8,0,1,3,1,1,4,0,0,1,1,3,9,1,1,1,1,0,4,0,5,0,1,0]

theorem envBound48698 : H12AffineFastState.Bounded env48698 := by
  intro p hp
  have h : env48698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48697_48698 : H12AffineEnvironment.transform 8 1 env48697 = env48698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48697 == env48698) = true)

def env48699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,441659,8328,65,4691218,115151,17665,10281,119043,4268163,256,485831,493666,63188]

theorem envBound48699 : H12AffineFastState.Bounded env48699 := by
  intro p hp
  have h : env48699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48648_48699 : H12AffineEnvironment.transform 20 456825 env48648 = env48699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env48648 == env48699) = true)

def env48700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,441659,8328,65,245138,115151,17665,10281,119043,329731,256,485831,493666,63188]

theorem envBound48700 : H12AffineFastState.Bounded env48700 := by
  intro p hp
  have h : env48700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48699_48700 : H12AffineEnvironment.transform 21 272512 env48699 = env48700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48699 == env48700) = true)

theorem identity48700 : scanCanonicalize (H12AffineFastState.compose env48700 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound48700 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180409,16,21762,8328,65,245138,115151,17665,10281,119043,254010,256,98814,90203,63188]

theorem envBound48701 : H12AffineFastState.Bounded env48701 := by
  intro p hp
  have h : env48701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48700_48701 : H12AffineEnvironment.transform 17 190521 env48700 = env48701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env48700 == env48701) = true)

def env48702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180273,16,21762,8192,65,245018,115015,17665,10281,119043,254010,256,98678,90203,63068]

theorem envBound48702 : H12AffineFastState.Bounded env48702 := by
  intro p hp
  have h : env48702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48701_48702 : H12AffineEnvironment.transform 6 8 env48701 = env48702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48701 == env48702) = true)

theorem identity48702 : scanCanonicalize (H12AffineFastState.compose env48702 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound48702 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,32,16,21762,8192,65,97547,115015,17665,10281,119043,73771,256,98678,90203,63068]

theorem envBound48703 : H12AffineFastState.Bounded env48703 := by
  intro p hp
  have h : env48703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48702_48703 : H12AffineEnvironment.transform 16 49169 env48702 = env48703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48702 == env48703) = true)

theorem identity48703 : scanCanonicalize (H12AffineFastState.compose env48703 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound48703 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env48704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,65536,5440,10280,1024,21840,4160,32,16,21762,8192,65,97547,70678,17665,10281,66642,73771,256,87079,90203,8973]

theorem envBound48704 : H12AffineFastState.Bounded env48704 := by
  intro p hp
  have h : env48704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48703_48704 : H12AffineEnvironment.transform 14 21841 env48703 = env48704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env48703 == env48704) = true)

theorem identity48704 : scanCanonicalize (H12AffineFastState.compose env48704 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48704 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21841,65536,5440,2420,1024,21840,4160,32,16,21762,348,65,89175,70678,17665,2421,66642,65911,256,87079,82183,593]

theorem envBound48705 : H12AffineFastState.Bounded env48705 := by
  intro p hp
  have h : env48705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48704_48705 : H12AffineEnvironment.transform 12 348 env48704 = env48705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48704 == env48705) = true)

theorem identity48705 : scanCanonicalize (H12AffineFastState.compose env48705 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound48705 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env48706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,1,65536,5440,2420,1024,0,4160,32,16,82,348,65,67847,70678,4177,2421,66642,65911,256,65911,70743,593]

theorem envBound48706 : H12AffineFastState.Bounded env48706 := by
  intro p hp
  have h : env48706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48705_48706 : H12AffineEnvironment.transform 13 5456 env48705 = env48706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env48705 == env48706) = true)

theorem identity48706 : scanCanonicalize (H12AffineFastState.compose env48706 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48706 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3392,1,65536,3408,2420,1024,0,2128,32,16,82,348,65,67847,68614,2113,2421,66642,65911,256,65911,68679,593]

theorem envBound48707 : H12AffineFastState.Bounded env48707 := by
  intro p hp
  have h : env48707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48706_48707 : H12AffineEnvironment.transform 11 2064 env48706 = env48707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48706 == env48707) = true)

theorem identity48707 : scanCanonicalize (H12AffineFastState.compose env48707 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48707 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env48708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3392,1,263,3408,2420,1024,0,2128,32,16,82,348,65,2048,3329,2113,2421,1365,112,256,112,3392,593]

theorem envBound48708 : H12AffineFastState.Bounded env48708 := by
  intro p hp
  have h : env48708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48707_48708 : H12AffineEnvironment.transform 15 263 env48707 = env48708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48707 == env48708) = true)

theorem identity48708 : scanCanonicalize (H12AffineFastState.compose env48708 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound48708 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48709 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,2064,348,2161,1,263,2145,2420,305,0,2128,32,16,82,348,65,2048,2096,2113,2421,100,112,256,112,2161,593]

theorem envBound48709 : H12AffineFastState.Bounded env48709 := by
  intro p hp
  have h : env48709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48708_48709 : H12AffineEnvironment.transform 9 305 env48708 = env48709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env48708 == env48709) = true)

theorem identity48709 : scanCanonicalize (H12AffineFastState.compose env48709 (packedSelected [1,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48709 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env48710 : List Nat := [2,4,8,16,32,64,8,256,512,305,1,17,348,112,1,263,96,373,305,0,81,32,16,82,348,65,1,49,64,372,100,112,256,112,112,593]

theorem envBound48710 : H12AffineFastState.Bounded env48710 := by
  intro p hp
  have h : env48710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48709_48710 : H12AffineEnvironment.transform 10 1 env48709 = env48710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48709 == env48710) = true)

theorem identity48710 : scanCanonicalize (H12AffineFastState.compose env48710 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound48710 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env48711 : List Nat := [2,4,8,16,32,49,8,256,512,305,1,17,301,1,1,263,17,260,305,0,32,32,16,35,301,48,1,49,49,261,21,1,256,1,1,544]

theorem envBound48711 : H12AffineFastState.Bounded env48711 := by
  intro p hp
  have h : env48711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48710_48711 : H12AffineEnvironment.transform 5 49 env48710 = env48711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env48710 == env48711) = true)

theorem identity48711 : scanCanonicalize (H12AffineFastState.compose env48711 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48711 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48712 : List Nat := [2,4,8,16,1,16,8,256,512,272,1,17,268,1,1,263,17,260,272,0,1,1,16,2,268,17,1,16,16,261,21,1,256,1,1,513]

theorem envBound48712 : H12AffineFastState.Bounded env48712 := by
  intro p hp
  have h : env48712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48711_48712 : H12AffineEnvironment.transform 4 1 env48711 = env48712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48711 == env48712) = true)

theorem identity48712 : scanCanonicalize (H12AffineFastState.compose env48712 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48713 : List Nat := [2,4,8,0,1,0,8,256,512,256,1,1,268,1,1,263,1,260,256,0,1,1,0,2,268,1,1,0,0,261,5,1,256,1,1,513]

theorem envBound48713 : H12AffineFastState.Bounded env48713 := by
  intro p hp
  have h : env48713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48712_48713 : H12AffineEnvironment.transform 3 0 env48712 = env48713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48712 == env48713) = true)

theorem identity48713 : scanCanonicalize (H12AffineFastState.compose env48713 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48713 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48714 : List Nat := [2,4,8,0,1,0,8,256,0,256,1,1,268,1,1,263,1,260,256,0,1,1,0,2,268,1,1,0,0,261,5,1,256,1,1,1]

theorem envBound48714 : H12AffineFastState.Bounded env48714 := by
  intro p hp
  have h : env48714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48713_48714 : H12AffineEnvironment.transform 8 0 env48713 = env48714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48713 == env48714) = true)

theorem identity48714 : scanCanonicalize (H12AffineFastState.compose env48714 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48714 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env48715 : List Nat := [2,4,8,0,1,0,8,4,0,4,1,1,8,1,1,3,1,0,4,0,1,1,0,2,8,1,1,0,0,1,5,1,4,1,1,1]

theorem envBound48715 : H12AffineFastState.Bounded env48715 := by
  intro p hp
  have h : env48715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48714_48715 : H12AffineEnvironment.transform 7 4 env48714 = env48715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48714 == env48715) = true)

def env48716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180272,16,21762,8193,65,245019,115014,17665,10281,119043,254010,256,98679,90203,63069]

theorem envBound48716 : H12AffineFastState.Bounded env48716 := by
  intro p hp
  have h : env48716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48701_48716 : H12AffineEnvironment.transform 6 9 env48701 = env48716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48701 == env48716) = true)

theorem identity48716 : scanCanonicalize (H12AffineFastState.compose env48716 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound48716 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4160,41340,16,21762,8193,65,121943,115014,17665,10281,119043,98678,256,98679,90203,63069]

theorem envBound48717 : H12AffineFastState.Bounded env48717 := by
  intro p hp
  have h : env48717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48716_48717 : H12AffineEnvironment.transform 16 24908 env48716 = env48717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env48716 == env48717) = true)

theorem identity48717 : scanCanonicalize (H12AffineFastState.compose env48717 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound48717 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,24908,35189,1024,32769,4160,41340,16,21762,8193,65,31837,24908,17665,10281,28937,8572,256,8573,49233,63069]

theorem envBound48718 : H12AffineFastState.Bounded env48718 := by
  intro p hp
  have h : env48718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48717_48718 : H12AffineEnvironment.transform 15 40970 env48717 = env48718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env48717 == env48718) = true)

theorem identity48718 : scanCanonicalize (H12AffineFastState.compose env48718 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound48718 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,30073,21875,24908,31756,1024,30072,4160,21509,16,21762,8193,65,31837,24908,17665,10281,28937,8572,256,8573,13608,804]

theorem envBound48719 : H12AffineFastState.Bounded env48719 := by
  intro p hp
  have h : env48719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48718_48719 : H12AffineEnvironment.transform 14 30073 env48718 = env48719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env48718 == env48719) = true)

theorem identity48719 : scanCanonicalize (H12AffineFastState.compose env48719 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48719 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env48720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8312,114,13389,10509,1024,8313,4160,260,16,3,8193,65,10588,13389,4096,10281,9224,8572,256,8573,13608,804]

theorem envBound48720 : H12AffineFastState.Bounded env48720 := by
  intro p hp
  have h : env48720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48719_48720 : H12AffineEnvironment.transform 13 5377 env48719 = env48720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48719 == env48720) = true)

theorem identity48720 : scanCanonicalize (H12AffineFastState.compose env48720 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound48720 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env48721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,3125,8312,114,11641,10509,1024,8313,2420,260,16,3,8193,65,10588,11641,2356,10281,9224,8572,256,8573,11292,804]

theorem envBound48721 : H12AffineFastState.Bounded env48721 := by
  intro p hp
  have h : env48721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48720_48721 : H12AffineEnvironment.transform 11 2356 env48720 = env48721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env48720 == env48721) = true)

theorem identity48721 : scanCanonicalize (H12AffineFastState.compose env48721 (packedSelected [2,4,5,6,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48721 : packedSelected [2,4,5,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,348,3125,292,114,3109,2129,1024,293,2420,260,16,3,349,65,2048,3109,2356,2421,1364,32,256,33,3392,804]

theorem envBound48722 : H12AffineFastState.Bounded env48722 := by
  intro p hp
  have h : env48722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48721_48722 : H12AffineEnvironment.transform 12 348 env48721 = env48722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48721 == env48722) = true)

theorem identity48722 : scanCanonicalize (H12AffineFastState.compose env48722 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48722 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48723 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,2096,88,3125,32,114,3109,2129,1024,33,2160,0,16,3,89,65,2048,3109,2096,2161,1104,32,4,33,3140,544]

theorem envBound48723 : H12AffineFastState.Bounded env48723 := by
  intro p hp
  have h : env48723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48722_48723 : H12AffineEnvironment.transform 7 4 env48722 = env48723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48722 == env48723) = true)

theorem identity48723 : scanCanonicalize (H12AffineFastState.compose env48723 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound48723 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env48724 : List Nat := [2,4,8,16,32,64,9,4,512,1024,1044,1060,88,33,32,114,49,1093,1024,33,1124,0,16,3,89,65,1044,49,1060,1125,1104,32,4,33,80,544]

theorem envBound48724 : H12AffineFastState.Bounded env48724 := by
  intro p hp
  have h : env48724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48723_48724 : H12AffineEnvironment.transform 10 1044 env48723 = env48724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env48723 == env48724) = true)

theorem identity48724 : scanCanonicalize (H12AffineFastState.compose env48724 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48724 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48725 : List Nat := [2,4,8,16,32,64,9,4,512,53,33,17,88,33,32,114,49,112,53,33,81,0,16,3,89,65,33,49,17,80,101,32,4,33,80,544]

theorem envBound48725 : H12AffineFastState.Bounded env48725 := by
  intro p hp
  have h : env48725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48724_48725 : H12AffineEnvironment.transform 9 53 env48724 = env48725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48724 == env48725) = true)

def env48726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,441659,8328,65,245139,115151,17665,10281,119043,329730,256,485831,493666,63188]

theorem envBound48726 : H12AffineFastState.Bounded env48726 := by
  intro p hp
  have h : env48726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48699_48726 : H12AffineEnvironment.transform 21 272513 env48699 = env48726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48699 == env48726) = true)

def env48727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452649,441659,8192,65,245019,115015,17665,10281,119043,329730,256,485711,493666,63068]

theorem envBound48727 : H12AffineFastState.Bounded env48727 := by
  intro p hp
  have h : env48727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48726_48727 : H12AffineEnvironment.transform 6 8 env48726 = env48727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48726 == env48727) = true)

def env48728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272393,272441,294187,8192,65,97547,115015,17665,10281,119043,329730,256,371039,346226,63068]

theorem envBound48728 : H12AffineFastState.Bounded env48728 := by
  intro p hp
  have h : env48728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48727_48728 : H12AffineEnvironment.transform 16 49168 env48727 = env48728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48727 == env48728) = true)

theorem identity48728 : scanCanonicalize (H12AffineFastState.compose env48728 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,33,17,21763,8192,65,97547,115015,17665,10281,119043,73770,256,98679,90202,63068]

theorem envBound48729 : H12AffineFastState.Bounded env48729 := by
  intro p hp
  have h : env48729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48728_48729 : H12AffineEnvironment.transform 17 10280 env48728 = env48729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48728 == env48729) = true)

theorem identity48729 : scanCanonicalize (H12AffineFastState.compose env48729 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound48729 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env48730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62810,49168,10280,1024,32769,4161,33,17,21763,8192,65,34897,13341,17665,10281,9305,54640,256,29741,38144,63068]

theorem envBound48730 : H12AffineFastState.Bounded env48730 := by
  intro p hp
  have h : env48730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48729_48730 : H12AffineEnvironment.transform 15 62810 env48729 = env48730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env48729 == env48730) = true)

theorem identity48730 : scanCanonicalize (H12AffineFastState.compose env48730 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound48730 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env48731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,343,13341,10280,1024,29708,4161,33,17,21763,8192,65,31836,13341,17665,10281,9305,8573,256,29741,24845,593]

theorem envBound48731 : H12AffineFastState.Bounded env48731 := by
  intro p hp
  have h : env48731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48730_48731 : H12AffineEnvironment.transform 14 29709 env48730 = env48731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env48730 == env48731) = true)

def env48732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272393,272440,294186,8192,65,97546,115015,17665,10281,119043,329730,256,371038,346227,63068]

theorem envBound48732 : H12AffineFastState.Bounded env48732 := by
  intro p hp
  have h : env48732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48727_48732 : H12AffineEnvironment.transform 16 49169 env48727 = env48732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48727 == env48732) = true)

theorem identity48732 : scanCanonicalize (H12AffineFastState.compose env48732 (packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound48732 : packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env48733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56357,1024,32769,58445,62508,62493,41231,8192,65,97546,115015,17665,10281,119043,119847,256,95611,103510,63068]

theorem envBound48733 : H12AffineFastState.Bounded env48733 := by
  intro p hp
  have h : env48733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48732_48733 : H12AffineEnvironment.transform 17 56357 env48732 = env48733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env48732 == env48733) = true)

theorem identity48733 : scanCanonicalize (H12AffineFastState.compose env48733 (packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48733 : packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,10361,1024,29789,4113,112,65,21843,8192,65,97546,79131,17665,10281,75103,73851,256,95611,90122,512]

theorem envBound48734 : H12AffineFastState.Bounded env48734 := by
  intro p hp
  have h : env48734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48733_48734 : H12AffineEnvironment.transform 14 29788 env48733 = env48734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48733 == env48734) = true)

theorem identity48734 : scanCanonicalize (H12AffineFastState.compose env48734 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound48734 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env48735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,30042,13389,10361,1024,29789,4113,112,65,21843,8192,65,2128,16449,17665,10281,20485,21793,256,33,5456,512]

theorem envBound48735 : H12AffineFastState.Bounded env48735 := by
  intro p hp
  have h : env48735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48734_48735 : H12AffineEnvironment.transform 15 30042 env48734 = env48735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env48734 == env48735) = true)

theorem identity48735 : scanCanonicalize (H12AffineFastState.compose env48735 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound48735 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env48736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9528,9278,13389,10361,1024,9529,4113,112,65,1079,8192,65,2128,4389,5221,10281,353,1093,256,33,5456,512]

theorem envBound48736 : H12AffineFastState.Bounded env48736 := by
  intro p hp
  have h : env48736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48735_48736 : H12AffineEnvironment.transform 13 4452 env48735 = env48736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env48735 == env48736) = true)

theorem identity48736 : scanCanonicalize (H12AffineFastState.compose env48736 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound48736 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4452,80,342,4389,3345,1024,81,4113,112,65,1079,1384,65,2128,4389,5221,3393,353,1093,256,33,5456,512]

theorem envBound48737 : H12AffineFastState.Bounded env48737 := by
  intro p hp
  have h : env48737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48736_48737 : H12AffineEnvironment.transform 12 1384 env48736 = env48737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env48736 == env48737) = true)

theorem identity48737 : scanCanonicalize (H12AffineFastState.compose env48737 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound48737 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48738 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,1305,4373,33,295,4389,3345,1024,32,4113,1,48,1079,1305,48,2081,4389,5140,3376,272,1076,256,33,5409,512]

theorem envBound48738 : H12AffineFastState.Bounded env48738 := by
  intro p hp
  have h : env48738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48737_48738 : H12AffineEnvironment.transform 5 49 env48737 = env48738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env48737 == env48738) = true)

theorem identity48738 : scanCanonicalize (H12AffineFastState.compose env48738 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48738 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env48739 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,1305,4373,0,262,4356,3345,1024,1,4113,1,17,1046,1305,17,2048,4356,5140,3345,272,1045,256,0,5376,512]

theorem envBound48739 : H12AffineFastState.Bounded env48739 := by
  intro p hp
  have h : env48739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48738_48739 : H12AffineEnvironment.transform 4 1 env48738 = env48739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48738 == env48739) = true)

theorem identity48739 : scanCanonicalize (H12AffineFastState.compose env48739 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48739 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48740 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,1052,4112,0,3,4097,3092,1024,1,4113,1,17,1046,1052,17,2048,4097,5140,3092,21,1045,5,0,5125,512]

theorem envBound48740 : H12AffineFastState.Bounded env48740 := by
  intro p hp
  have h : env48740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48739_48740 : H12AffineEnvironment.transform 7 5 env48739 = env48740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48739 == env48740) = true)

def env48741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452649,441659,8193,65,245018,115014,17665,10281,119043,329730,256,485710,493666,63069]

theorem envBound48741 : H12AffineFastState.Bounded env48741 := by
  intro p hp
  have h : env48741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48726_48741 : H12AffineEnvironment.transform 6 9 env48726 = env48741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48726 == env48741) = true)

def env48742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272392,272441,294187,8193,65,97546,115014,17665,10281,119043,329730,256,371038,346226,63069]

theorem envBound48742 : H12AffineFastState.Bounded env48742 := by
  intro p hp
  have h : env48742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48741_48742 : H12AffineEnvironment.transform 16 49168 env48741 = env48742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48741 == env48742) = true)

theorem identity48742 : scanCanonicalize (H12AffineFastState.compose env48742 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1024,8541,276585,272392,272441,294187,8193,65,97546,90138,17665,10281,94303,329730,256,329730,346226,22273]

theorem envBound48743 : H12AffineFastState.Bounded env48743 := by
  intro p hp
  have h : env48743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48742_48743 : H12AffineEnvironment.transform 14 8540 env48742 = env48743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48742 == env48743) = true)

theorem identity48743 : scanCanonicalize (H12AffineFastState.compose env48743 (packedSelected [3,4,5,7,8,9,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound48743 : packedSelected [3,4,5,7,8,9,27,28] rootPS < 2^1333 := by decide +kernel

def env48744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,2420,1024,8541,12573,8572,8525,29791,8193,65,97546,90138,17665,10281,94303,65910,256,65910,82182,22273]

theorem envBound48744 : H12AffineFastState.Bounded env48744 := by
  intro p hp
  have h : env48744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48743_48744 : H12AffineEnvironment.transform 17 2420 env48743 = env48744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env48743 == env48744) = true)

theorem identity48744 : scanCanonicalize (H12AffineFastState.compose env48744 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound48744 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env48745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,24908,2420,1024,8541,12573,8572,8525,29791,8193,65,31836,24908,17665,10281,28937,32,256,32,16464,22273]

theorem envBound48745 : H12AffineFastState.Bounded env48745 := by
  intro p hp
  have h : env48745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48744_48745 : H12AffineEnvironment.transform 15 342 env48744 = env48745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env48744 == env48745) = true)

def env48746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272392,272440,294186,8193,65,97547,115014,17665,10281,119043,329730,256,371039,346227,63069]

theorem envBound48746 : H12AffineFastState.Bounded env48746 := by
  intro p hp
  have h : env48746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48741_48746 : H12AffineEnvironment.transform 16 49169 env48741 = env48746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48741 == env48746) = true)

theorem identity48746 : scanCanonicalize (H12AffineFastState.compose env48746 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48746 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,45341,41341,41293,62559,8193,65,97547,115014,17665,10281,119043,98679,256,73770,114950,63069]

theorem envBound48747 : H12AffineFastState.Bounded env48747 := by
  intro p hp
  have h : env48747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48746_48747 : H12AffineEnvironment.transform 17 35189 env48746 = env48747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48746 == env48747) = true)

theorem identity48747 : scanCanonicalize (H12AffineFastState.compose env48747 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound48747 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env48748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,65536,16741,2049,1024,373,12393,8201,8249,29995,8193,65,97547,81970,17665,10281,86135,65539,256,73770,82034,30505]

theorem envBound48748 : H12AffineFastState.Bounded env48748 := by
  intro p hp
  have h : env48748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48747_48748 : H12AffineEnvironment.transform 14 372 env48747 = env48748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env48747 == env48748) = true)

theorem identity48748 : scanCanonicalize (H12AffineFastState.compose env48748 (packedSelected [0,2,4,6,7,8,9,10,11,12,14,15,16,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound48748 : packedSelected [0,2,4,6,7,8,9,10,11,12,14,15,16,20,23,28] rootPS < 2^1333 := by decide +kernel

def env48749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,35,16741,2049,1024,373,12393,8201,8249,29995,8193,65,32040,16401,17665,10281,20564,32,256,8201,16465,30505]

theorem envBound48749 : H12AffineFastState.Bounded env48749 := by
  intro p hp
  have h : env48749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48748_48749 : H12AffineEnvironment.transform 15 35 env48748 = env48749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env48748 == env48749) = true)

theorem identity48749 : scanCanonicalize (H12AffineFastState.compose env48749 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound48749 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env48750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,372,35,13388,2049,1024,373,12393,8201,8249,2,8193,65,2049,13624,12328,10281,9597,32,256,8201,13688,512]

theorem envBound48750 : H12AffineFastState.Bounded env48750 := by
  intro p hp
  have h : env48750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48749_48750 : H12AffineEnvironment.transform 13 13609 env48749 = env48750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env48749 == env48750) = true)

theorem identity48750 : scanCanonicalize (H12AffineFastState.compose env48750 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48750 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48751 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,0,35,13388,2049,1024,1,12393,8201,8249,2,8193,65,2049,13388,12328,10281,9225,32,116,8201,13324,512]

theorem envBound48751 : H12AffineFastState.Bounded env48751 := by
  intro p hp
  have h : env48751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48750_48751 : H12AffineEnvironment.transform 7 116 env48750 = env48751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48750 == env48751) = true)

theorem identity48751 : scanCanonicalize (H12AffineFastState.compose env48751 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound48751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48752 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,9,5204,0,35,5189,2049,1024,1,4192,0,48,2,8,65,2049,5189,4129,2080,1024,32,116,0,5125,512]

theorem envBound48752 : H12AffineFastState.Bounded env48752 := by
  intro p hp
  have h : env48752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48751_48752 : H12AffineEnvironment.transform 12 9 env48751 = env48752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env48751 == env48752) = true)

theorem identity48752 : scanCanonicalize (H12AffineFastState.compose env48752 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound48752 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48753 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1044,4096,9,5204,0,35,5189,1045,1024,1,4192,0,48,2,8,65,1045,5189,4129,1076,1024,32,116,0,5125,512]

theorem envBound48753 : H12AffineFastState.Bounded env48753 := by
  intro p hp
  have h : env48753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48752_48753 : H12AffineEnvironment.transform 10 1044 env48752 = env48753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env48752 == env48753) = true)

theorem identity48753 : scanCanonicalize (H12AffineFastState.compose env48753 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound48753 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env48754 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1044,16,9,1092,0,35,1109,1045,1024,1,112,0,48,2,8,65,1045,1109,49,1076,1024,32,116,0,1045,512]

theorem envBound48754 : H12AffineFastState.Bounded env48754 := by
  intro p hp
  have h : env48754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48753_48754 : H12AffineEnvironment.transform 11 16 env48753 = env48754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48753 == env48754) = true)

theorem identity48754 : scanCanonicalize (H12AffineFastState.compose env48754 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48754 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48755 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1044,16,9,1044,0,35,1029,1045,1024,1,32,0,48,2,8,17,1045,1029,49,1076,1024,32,36,0,1045,512]

theorem envBound48755 : H12AffineFastState.Bounded env48755 := by
  intro p hp
  have h : env48755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48754_48755 : H12AffineEnvironment.transform 5 16 env48754 = env48755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48754 == env48755) = true)

theorem identity48755 : scanCanonicalize (H12AffineFastState.compose env48755 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound48755 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env48756 : List Nat := [2,4,8,16,32,16,9,36,512,21,1,16,9,1,0,35,16,0,21,1,32,0,48,2,8,17,0,16,49,33,21,32,36,0,0,512]

theorem envBound48756 : H12AffineFastState.Bounded env48756 := by
  intro p hp
  have h : env48756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48755_48756 : H12AffineEnvironment.transform 9 21 env48755 = env48756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48755 == env48756) = true)

theorem identity48756 : scanCanonicalize (H12AffineFastState.compose env48756 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48756 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env48757 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,16,9,1,0,2,16,0,21,1,1,0,17,2,8,17,0,16,16,0,21,1,5,0,0,512]

theorem envBound48757 : H12AffineFastState.Bounded env48757 := by
  intro p hp
  have h : env48757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48756_48757 : H12AffineEnvironment.transform 4 1 env48756 = env48757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48756 == env48757) = true)

theorem identity48757 : scanCanonicalize (H12AffineFastState.compose env48757 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48757 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48758 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,16,9,1,0,2,16,0,21,1,1,0,17,2,8,17,0,16,16,0,21,1,5,0,0,1]

theorem envBound48758 : H12AffineFastState.Bounded env48758 := by
  intro p hp
  have h : env48758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48757_48758 : H12AffineEnvironment.transform 8 1 env48757 = env48758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48757 == env48758) = true)

theorem identity48758 : scanCanonicalize (H12AffineFastState.compose env48758 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound48758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48759 : List Nat := [2,4,8,15,1,15,9,5,1,10,1,15,9,1,0,2,15,0,10,1,1,0,14,2,8,14,0,15,15,0,10,1,5,0,0,1]

theorem envBound48759 : H12AffineFastState.Bounded env48759 := by
  intro p hp
  have h : env48759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48758_48759 : H12AffineEnvironment.transform 3 15 env48758 = env48759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env48758 == env48759) = true)

def env48760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound48760 : H12AffineFastState.Bounded env48760 := by
  intro p hp
  have h : env48760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48555_48760 : H12AffineEnvironment.transform 18 1025 env48555 = env48760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env48555 == env48760) = true)

theorem identity48760 : scanCanonicalize (H12AffineFastState.compose env48760 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347627) := by decide +kernel

theorem selectedBound48760 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,16777216,8328,65,29868033,17090919,8722618,8830977,25265169,21243946,257,25463110,25454818,25207751]

theorem envBound48761 : H12AffineFastState.Bounded env48761 := by
  intro p hp
  have h : env48761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48760_48761 : H12AffineEnvironment.transform 20 347627 env48760 = env48761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347627 env48760 == env48761) = true)

def env48762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392316,8328,65,12729469,79131,8722618,8830977,8681581,4314198,257,8484154,8492190,8740795]

theorem envBound48762 : H12AffineFastState.Bounded env48762 := by
  intro p hp
  have h : env48762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48761_48762 : H12AffineEnvironment.transform 23 392316 env48761 = env48762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392316 env48761 == env48762) = true)

def env48763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98780,8328,65,12729469,79131,8480026,8568225,8390093,4314198,257,8484154,8492190,8462875]

theorem envBound48763 : H12AffineFastState.Bounded env48763 := by
  intro p hp
  have h : env48763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48762_48763 : H12AffineEnvironment.transform 17 32160 env48762 = env48763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env48762 == env48763) = true)

def env48764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98780,8328,65,8546653,79131,8480026,8568225,8390093,98678,257,8484154,8492190,8462875]

theorem envBound48764 : H12AffineFastState.Bounded env48764 := by
  intro p hp
  have h : env48764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48763_48764 : H12AffineEnvironment.transform 21 21792 env48763 = env48764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env48763 == env48764) = true)

theorem identity48764 : scanCanonicalize (H12AffineFastState.compose env48764 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62660) := by decide +kernel

theorem selectedBound48764 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,62660,98780,8328,65,171417,79131,102878,149861,61705,98678,257,98814,90202,120543]

theorem envBound48765 : H12AffineFastState.Bounded env48765 := by
  intro p hp
  have h : env48765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48764_48765 : H12AffineEnvironment.transform 22 62660 env48764 = env48765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62660 env48764 == env48765) = true)

def env48766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10280,1025,32769,77899,168,41292,98780,8328,65,171417,79131,102878,138477,42113,98678,257,98814,79314,99159]

theorem envBound48766 : H12AffineFastState.Bounded env48766 := by
  intro p hp
  have h : env48766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48765_48766 : H12AffineEnvironment.transform 13 5512 env48765 = env48766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env48765 == env48766) = true)

def env48767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,46276,10280,1025,32769,77899,168,41292,98780,8328,65,10589,79131,102878,43049,42113,98678,257,98814,79314,99159]

theorem envBound48767 : H12AffineFastState.Bounded env48767 := by
  intro p hp
  have h : env48767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48766_48767 : H12AffineEnvironment.transform 16 46276 env48766 = env48767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env48766 == env48767) = true)

theorem identity48767 : scanCanonicalize (H12AffineFastState.compose env48767 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound48767 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,136,65536,13388,10280,1025,137,77899,168,8644,65876,8328,65,10589,79131,69974,10401,9225,66046,257,65910,79314,66527]

theorem envBound48768 : H12AffineFastState.Bounded env48768 := by
  intro p hp
  have h : env48768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48767_48768 : H12AffineEnvironment.transform 14 136 env48767 = env48768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env48767 == env48768) = true)

theorem identity48768 : scanCanonicalize (H12AffineFastState.compose env48768 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48768 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,65536,13388,10280,1025,0,77899,33,8525,65876,8193,65,10589,79131,69974,10280,9225,65911,257,65910,79195,66390]

theorem envBound48769 : H12AffineFastState.Bounded env48769 := by
  intro p hp
  have h : env48769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48768_48769 : H12AffineEnvironment.transform 6 9 env48768 = env48769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48768 == env48769) = true)

theorem identity48769 : scanCanonicalize (H12AffineFastState.compose env48769 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound48769 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env48770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,343,13388,10280,1025,0,12572,33,8525,3,8193,65,10589,13388,4097,10280,9225,32,257,33,13324,513]

theorem envBound48770 : H12AffineFastState.Bounded env48770 := by
  intro p hp
  have h : env48770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48769_48770 : H12AffineEnvironment.transform 15 343 env48769 = env48770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env48769 == env48770) = true)

theorem identity48770 : scanCanonicalize (H12AffineFastState.compose env48770 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48770 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5393,2421,1025,0,4161,33,16,3,348,65,2048,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound48771 : H12AffineFastState.Bounded env48771 := by
  intro p hp
  have h : env48771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48770_48771 : H12AffineEnvironment.transform 12 349 env48770 = env48771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48770 == env48771) = true)

theorem identity48771 : scanCanonicalize (H12AffineFastState.compose env48771 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound48771 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,523,4096,349,5377,1,343,5393,894,1025,0,4161,33,16,3,348,65,523,5393,4097,894,1364,32,257,33,5457,513]

theorem envBound48772 : H12AffineFastState.Bounded env48772 := by
  intro p hp
  have h : env48772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48771_48772 : H12AffineEnvironment.transform 10 523 env48771 = env48772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env48771 == env48772) = true)

theorem identity48772 : scanCanonicalize (H12AffineFastState.compose env48772 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48772 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48773 : List Nat := [2,4,8,16,32,64,9,37,512,1024,523,4096,120,5156,1,114,5172,603,1025,0,4161,33,16,3,121,65,523,5172,4097,603,1137,32,36,33,5236,513]

theorem envBound48773 : H12AffineFastState.Bounded env48773 := by
  intro p hp
  have h : env48773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48772_48773 : H12AffineEnvironment.transform 7 37 env48772 = env48773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48772 == env48773) = true)

theorem identity48773 : scanCanonicalize (H12AffineFastState.compose env48773 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48773 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48774 : List Nat := [2,4,8,16,32,17,9,37,512,1024,523,4096,41,5156,1,35,5172,522,1025,0,4112,33,16,3,40,16,523,5172,4097,522,1056,32,36,33,5157,513]

theorem envBound48774 : H12AffineFastState.Bounded env48774 := by
  intro p hp
  have h : env48774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48773_48774 : H12AffineEnvironment.transform 5 17 env48773 = env48774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48773 == env48774) = true)

def env48775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,46277,10280,1025,32769,77899,168,41292,98780,8328,65,10588,79131,102878,43048,42113,98678,257,98814,79314,99159]

theorem envBound48775 : H12AffineFastState.Bounded env48775 := by
  intro p hp
  have h : env48775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48766_48775 : H12AffineEnvironment.transform 16 46277 env48766 = env48775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env48766 == env48775) = true)

theorem identity48775 : scanCanonicalize (H12AffineFastState.compose env48775 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48775 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,5528,10280,1025,8540,77899,168,17,73857,8328,65,10588,79131,77955,2421,1500,73771,257,73891,79314,74250]

theorem envBound48776 : H12AffineFastState.Bounded env48776 := by
  intro p hp
  have h : env48776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48775_48776 : H12AffineEnvironment.transform 14 8541 env48775 = env48776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48775 == env48776) = true)

theorem identity48776 : scanCanonicalize (H12AffineFastState.compose env48776 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48776 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,5392,10280,1025,8540,77899,32,17,73737,8192,65,10588,79131,77835,2421,1364,73771,257,73771,79194,74250]

theorem envBound48777 : H12AffineFastState.Bounded env48777 := by
  intro p hp
  have h : env48777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48776_48777 : H12AffineEnvironment.transform 6 8 env48776 = env48777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48776 == env48777) = true)

theorem identity48777 : scanCanonicalize (H12AffineFastState.compose env48777 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound48777 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,2,5392,10280,1025,8540,12361,32,17,8203,8192,65,10588,13593,12297,2421,1364,8233,257,8233,13656,8712]

theorem envBound48778 : H12AffineFastState.Bounded env48778 := by
  intro p hp
  have h : env48778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48777_48778 : H12AffineEnvironment.transform 15 2 env48777 = env48778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env48777 == env48778) = true)

theorem identity48778 : scanCanonicalize (H12AffineFastState.compose env48778 (packedSelected [0,7,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48778 : packedSelected [0,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env48779 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8313,2,5172,10280,1025,8312,12361,32,17,8203,8192,65,10360,13373,12297,2129,1136,8233,37,8233,13436,8712]

theorem envBound48779 : H12AffineFastState.Bounded env48779 := by
  intro p hp
  have h : env48779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48778_48779 : H12AffineEnvironment.transform 7 36 env48778 = env48779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48778 == env48779) = true)

theorem identity48779 : scanCanonicalize (H12AffineFastState.compose env48779 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound48779 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48780 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8,5156,113,2,5172,2080,1025,112,4161,32,17,3,8,65,2160,5173,4097,2129,1136,33,37,33,5236,512]

theorem envBound48780 : H12AffineFastState.Bounded env48780 := by
  intro p hp
  have h : env48780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48779_48780 : H12AffineEnvironment.transform 12 8 env48779 = env48780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env48779 == env48780) = true)

theorem identity48780 : scanCanonicalize (H12AffineFastState.compose env48780 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound48780 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48781 : List Nat := [2,4,8,16,32,64,8,36,512,21,2048,4096,8,4145,113,2,4129,2080,20,112,4161,32,17,3,8,65,2160,4128,4097,2129,101,33,37,33,4193,512]

theorem envBound48781 : H12AffineFastState.Bounded env48781 := by
  intro p hp
  have h : env48781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48780_48781 : H12AffineEnvironment.transform 9 21 env48780 = env48781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48780 == env48781) = true)

theorem identity48781 : scanCanonicalize (H12AffineFastState.compose env48781 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound48781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48782 : List Nat := [2,4,8,16,32,64,8,36,512,21,2048,16,8,33,113,2,49,2080,20,112,81,32,17,3,8,65,2160,48,17,2129,101,33,37,33,113,512]

theorem envBound48782 : H12AffineFastState.Bounded env48782 := by
  intro p hp
  have h : env48782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48781_48782 : H12AffineEnvironment.transform 11 16 env48781 = env48782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48781 == env48782) = true)

theorem identity48782 : scanCanonicalize (H12AffineFastState.compose env48782 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound48782 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48783 : List Nat := [2,4,8,16,32,64,8,36,512,21,32,16,8,33,113,2,49,0,20,112,81,32,17,3,8,65,80,48,17,113,101,33,37,33,113,512]

theorem envBound48783 : H12AffineFastState.Bounded env48783 := by
  intro p hp
  have h : env48783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48782_48783 : H12AffineEnvironment.transform 10 32 env48782 = env48783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env48782 == env48783) = true)

theorem identity48783 : scanCanonicalize (H12AffineFastState.compose env48783 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48783 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48784 : List Nat := [2,4,8,16,32,16,8,36,512,21,32,16,8,33,33,2,49,0,20,32,1,32,17,3,8,17,0,48,17,33,53,33,37,33,33,512]

theorem envBound48784 : H12AffineFastState.Bounded env48784 := by
  intro p hp
  have h : env48784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48783_48784 : H12AffineEnvironment.transform 5 16 env48783 = env48784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48783 == env48784) = true)

def env48785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10281,1025,32769,77899,169,41293,98780,8328,65,171417,79131,102878,138476,42112,98678,257,98814,79315,99158]

theorem envBound48785 : H12AffineFastState.Bounded env48785 := by
  intro p hp
  have h : env48785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48765_48785 : H12AffineEnvironment.transform 13 5513 env48765 = env48785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env48765 == env48785) = true)

theorem identity48785 : scanCanonicalize (H12AffineFastState.compose env48785 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48785 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,65536,131072,10281,1025,8660,77899,169,152,73737,8328,65,146508,79131,77835,138476,1365,73891,257,73771,79315,74371]

theorem envBound48786 : H12AffineFastState.Bounded env48786 := by
  intro p hp
  have h : env48786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48785_48786 : H12AffineEnvironment.transform 14 8661 env48785 = env48786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48785 == env48786) = true)

theorem identity48786 : scanCanonicalize (H12AffineFastState.compose env48786 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48786 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,65536,5392,10281,1025,8660,77899,169,152,73737,8328,65,10588,79131,77835,2556,1365,73891,257,73771,79315,74371]

theorem envBound48787 : H12AffineFastState.Bounded env48787 := by
  intro p hp
  have h : env48787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48786_48787 : H12AffineEnvironment.transform 16 5392 env48786 = env48787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48786 == env48787) = true)

theorem identity48787 : scanCanonicalize (H12AffineFastState.compose env48787 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48787 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48788 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4249,8661,65536,4096,10281,273,8660,77899,169,152,73737,8328,65,10588,77835,77835,2556,69,73891,257,73771,78019,74371]

theorem envBound48788 : H12AffineFastState.Bounded env48788 := by
  intro p hp
  have h : env48788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48787_48788 : H12AffineEnvironment.transform 9 272 env48787 = env48788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48787 == env48788) = true)

theorem identity48788 : scanCanonicalize (H12AffineFastState.compose env48788 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound48788 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env48789 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4249,8661,479,4096,10281,273,8660,12692,169,152,8662,8328,65,10588,12756,12756,2556,69,8572,257,8692,12572,9052]

theorem envBound48789 : H12AffineFastState.Bounded env48789 := by
  intro p hp
  have h : env48789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48788_48789 : H12AffineEnvironment.transform 15 479 env48788 = env48789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env48788 == env48789) = true)

theorem identity48789 : scanCanonicalize (H12AffineFastState.compose env48789 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48789 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env48790 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,348,4249,137,479,4096,2421,273,136,4296,169,152,138,468,65,2048,4232,4232,2556,69,32,257,168,4160,512]

theorem envBound48790 : H12AffineFastState.Bounded env48790 := by
  intro p hp
  have h : env48790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48789_48790 : H12AffineEnvironment.transform 12 348 env48789 = env48790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48789 == env48790) = true)

theorem identity48790 : scanCanonicalize (H12AffineFastState.compose env48790 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound48790 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48791 : List Nat := [2,4,8,16,32,64,120,256,512,272,2048,4096,348,4193,113,295,4096,2421,273,112,4144,81,96,114,300,65,2048,4208,4208,2308,69,32,257,80,4160,512]

theorem envBound48791 : H12AffineFastState.Bounded env48791 := by
  intro p hp
  have h : env48791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48790_48791 : H12AffineEnvironment.transform 6 120 env48790 = env48791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env48790 == env48791) = true)

theorem identity48791 : scanCanonicalize (H12AffineFastState.compose env48791 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48791 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48792 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,300,4113,1,295,4096,2309,273,0,4144,33,16,2,300,49,2048,4096,4096,2308,53,32,257,32,4144,512]

theorem envBound48792 : H12AffineFastState.Bounded env48792 := by
  intro p hp
  have h : env48792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48791_48792 : H12AffineEnvironment.transform 5 48 env48791 = env48792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48791 == env48792) = true)

theorem identity48792 : scanCanonicalize (H12AffineFastState.compose env48792 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound48792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48793 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,48,300,33,1,295,48,2309,273,0,0,33,16,2,300,49,2048,48,48,2308,53,32,257,32,0,512]

theorem envBound48793 : H12AffineFastState.Bounded env48793 := by
  intro p hp
  have h : env48793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48792_48793 : H12AffineEnvironment.transform 11 48 env48792 = env48793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48792 == env48793) = true)

theorem identity48793 : scanCanonicalize (H12AffineFastState.compose env48793 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48793 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48794 : List Nat := [2,4,8,16,1,17,8,256,512,272,2048,17,269,0,1,262,17,2309,273,0,0,0,16,2,269,16,2048,17,17,2308,20,1,257,1,0,512]

theorem envBound48794 : H12AffineFastState.Bounded env48794 := by
  intro p hp
  have h : env48794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48793_48794 : H12AffineEnvironment.transform 4 1 env48793 = env48794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48793 == env48794) = true)

theorem identity48794 : scanCanonicalize (H12AffineFastState.compose env48794 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound48794 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48795 : List Nat := [2,4,8,16,1,17,8,256,261,272,2048,17,269,0,1,262,17,2309,273,0,0,0,16,2,269,16,2048,17,17,2308,20,1,257,1,0,261]

theorem envBound48795 : H12AffineFastState.Bounded env48795 := by
  intro p hp
  have h : env48795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48794_48795 : H12AffineEnvironment.transform 8 261 env48794 = env48795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env48794 == env48795) = true)

theorem identity48795 : scanCanonicalize (H12AffineFastState.compose env48795 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound48795 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48796 : List Nat := [2,4,8,16,1,17,8,256,261,272,16,17,269,0,1,262,17,277,273,0,0,0,16,2,269,16,16,17,17,276,20,1,257,1,0,261]

theorem envBound48796 : H12AffineFastState.Bounded env48796 := by
  intro p hp
  have h : env48796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48795_48796 : H12AffineEnvironment.transform 10 16 env48795 = env48796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env48795 == env48796) = true)

theorem identity48796 : scanCanonicalize (H12AffineFastState.compose env48796 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 27) := by decide +kernel

theorem selectedBound48796 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48797 : List Nat := [2,4,8,16,1,17,8,27,30,11,16,17,22,0,1,29,17,14,10,0,0,0,16,2,22,16,16,17,17,15,20,1,26,1,0,30]

theorem envBound48797 : H12AffineFastState.Bounded env48797 := by
  intro p hp
  have h : env48797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48796_48797 : H12AffineEnvironment.transform 7 27 env48796 = env48797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 27 env48796 == env48797) = true)

theorem identity48797 : scanCanonicalize (H12AffineFastState.compose env48797 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound48797 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48798 : List Nat := [2,4,7,16,1,17,7,20,17,4,16,17,22,0,1,18,17,1,5,0,0,0,16,2,22,16,16,17,17,0,20,1,21,1,0,17]

theorem envBound48798 : H12AffineFastState.Bounded env48798 := by
  intro p hp
  have h : env48798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48797_48798 : H12AffineEnvironment.transform 2 7 env48797 = env48798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env48797 == env48798) = true)

theorem identity48798 : scanCanonicalize (H12AffineFastState.compose env48798 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48799 : List Nat := [2,4,7,0,1,1,7,4,1,4,0,1,6,0,1,2,1,1,5,0,0,0,0,2,6,0,0,1,1,0,4,1,5,1,0,1]

theorem envBound48799 : H12AffineFastState.Bounded env48799 := by
  intro p hp
  have h : env48799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48798_48799 : H12AffineEnvironment.transform 3 0 env48798 = env48799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48798 == env48799) = true)

def env48800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98780,8328,65,8546652,79131,8480026,8568225,8390093,98679,257,8484154,8492190,8462875]

theorem envBound48800 : H12AffineFastState.Bounded env48800 := by
  intro p hp
  have h : env48800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48763_48800 : H12AffineEnvironment.transform 21 21793 env48763 = env48800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env48763 == env48800) = true)

theorem identity48800 : scanCanonicalize (H12AffineFastState.compose env48800 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48800 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32160,1025,29908,77899,21793,8388608,95497,8328,65,8546652,79131,8480026,8538484,8390093,95650,257,8484154,8478795,8462875]

theorem envBound48801 : H12AffineFastState.Bounded env48801 := by
  intro p hp
  have h : env48801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48800_48801 : H12AffineEnvironment.transform 14 29909 env48800 = env48801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48800 == env48801) = true)

def env48802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1025,8660,77899,33,8388608,73737,8328,65,8535132,79131,8466458,8526964,8390093,73890,257,8462394,8467787,8462875]

theorem envBound48802 : H12AffineFastState.Bounded env48802 := by
  intro p hp
  have h : env48802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48801_48802 : H12AffineEnvironment.transform 13 5376 env48801 = env48802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48801 == env48802) = true)

theorem identity48802 : scanCanonicalize (H12AffineFastState.compose env48802 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound48802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1025,8660,77899,33,17,73737,8328,65,146509,79131,77835,138341,1500,73890,257,73771,79194,74250]

theorem envBound48803 : H12AffineFastState.Bounded env48803 := by
  intro p hp
  have h : env48803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48802_48803 : H12AffineEnvironment.transform 22 17 env48802 = env48803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env48802 == env48803) = true)

theorem identity48803 : scanCanonicalize (H12AffineFastState.compose env48803 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound48803 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,478,131072,10400,1025,8660,12693,33,17,8663,8328,65,146509,13509,12757,138341,1500,8572,257,8693,13444,9172]

theorem envBound48804 : H12AffineFastState.Bounded env48804 := by
  intro p hp
  have h : env48804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48803_48804 : H12AffineEnvironment.transform 15 478 env48803 = env48804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env48803 == env48804) = true)

theorem identity48804 : scanCanonicalize (H12AffineFastState.compose env48804 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48804 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,478,5392,10400,1025,8660,12693,33,17,8663,8328,65,10589,13509,12757,2421,1500,8572,257,8693,13444,9172]

theorem envBound48805 : H12AffineFastState.Bounded env48805 := by
  intro p hp
  have h : env48805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48804_48805 : H12AffineEnvironment.transform 16 5392 env48804 = env48805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48804 == env48805) = true)

def env48806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1025,8661,77899,32,8388608,73736,8328,65,8535133,79131,8466459,8526965,8390093,73891,257,8462395,8467786,8462875]

theorem envBound48806 : H12AffineFastState.Bounded env48806 := by
  intro p hp
  have h : env48806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48801_48806 : H12AffineEnvironment.transform 13 5377 env48801 = env48806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48801 == env48806) = true)

theorem identity48806 : scanCanonicalize (H12AffineFastState.compose env48806 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48806 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,77899,32,8388608,73736,8193,65,8535133,79131,8466459,8526965,8389956,73770,257,8462395,8467786,8462875]

theorem envBound48807 : H12AffineFastState.Bounded env48807 := by
  intro p hp
  have h : env48807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48806_48807 : H12AffineEnvironment.transform 6 9 env48806 = env48807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48806 == env48807) = true)

theorem identity48807 : scanCanonicalize (H12AffineFastState.compose env48807 (packedSelected [16,20] rootPS)) = affineNative (2^(22+1) ^^^ 65862) := by decide +kernel

theorem selectedBound48807 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,77899,32,65862,73736,8193,65,212251,79131,12637,204083,66562,73770,257,8573,13324,9053]

theorem envBound48808 : H12AffineFastState.Bounded env48808 := by
  intro p hp
  have h : env48808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48807_48808 : H12AffineEnvironment.transform 22 65862 env48807 = env48808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65862 env48807 == env48808) = true)

theorem identity48808 : scanCanonicalize (H12AffineFastState.compose env48808 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48808 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env48809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10280,1025,8540,4160,32,8525,3,8193,65,138512,5392,12637,146744,9225,33,257,8573,13324,9053]

theorem envBound48809 : H12AffineFastState.Bounded env48809 := by
  intro p hp
  have h : env48809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48808_48809 : H12AffineEnvironment.transform 15 8203 env48808 = env48809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48808 == env48809) = true)

theorem identity48809 : scanCanonicalize (H12AffineFastState.compose env48809 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound48809 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env48810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5221,10280,1025,8540,4160,32,8525,3,8193,65,2421,5392,12637,10589,9225,33,257,8573,13324,9053]

theorem envBound48810 : H12AffineFastState.Bounded env48810 := by
  intro p hp
  have h : env48810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48809_48810 : H12AffineEnvironment.transform 16 5221 env48809 = env48810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env48809 == env48810) = true)

theorem identity48810 : scanCanonicalize (H12AffineFastState.compose env48810 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48810 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48811 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8232,8203,5221,10280,1025,8233,4160,32,8248,3,8193,65,2048,5221,12328,10280,9225,33,116,8200,13324,8744]

theorem envBound48811 : H12AffineFastState.Bounded env48811 := by
  intro p hp
  have h : env48811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48810_48811 : H12AffineEnvironment.transform 7 117 env48810 = env48811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48810 == env48811) = true)

theorem identity48811 : scanCanonicalize (H12AffineFastState.compose env48811 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48811 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env48812 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,1,34,5221,2049,1025,0,4160,32,17,3,40,65,2048,5221,4097,2049,1056,33,116,33,5157,513]

theorem envBound48812 : H12AffineFastState.Bounded env48812 := by
  intro p hp
  have h : env48812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48811_48812 : H12AffineEnvironment.transform 12 41 env48811 = env48812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48811 == env48812) = true)

theorem identity48812 : scanCanonicalize (H12AffineFastState.compose env48812 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound48812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48813 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1646,4096,41,5236,1,34,5221,1647,1025,0,4160,32,17,3,40,65,1646,5221,4097,1647,1056,33,116,33,5157,513]

theorem envBound48813 : H12AffineFastState.Bounded env48813 := by
  intro p hp
  have h : env48813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48812_48813 : H12AffineEnvironment.transform 10 1646 env48812 = env48813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env48812 == env48813) = true)

theorem identity48813 : scanCanonicalize (H12AffineFastState.compose env48813 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound48813 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48814 : List Nat := [2,4,8,16,32,64,9,117,512,574,80,4096,41,4682,1,34,4699,81,575,0,4160,32,17,3,40,65,80,4699,4097,81,542,33,116,33,4635,513]

theorem envBound48814 : H12AffineFastState.Bounded env48814 := by
  intro p hp
  have h : env48814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48813_48814 : H12AffineEnvironment.transform 9 574 env48813 = env48814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env48813 == env48814) = true)

theorem identity48814 : scanCanonicalize (H12AffineFastState.compose env48814 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48814 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48815 : List Nat := [2,4,8,16,32,64,9,117,43,21,80,4096,41,4193,1,34,4208,81,20,0,4160,32,17,3,40,65,80,4208,4097,81,53,33,116,33,4144,42]

theorem envBound48815 : H12AffineFastState.Bounded env48815 := by
  intro p hp
  have h : env48815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48814_48815 : H12AffineEnvironment.transform 8 43 env48814 = env48815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48814 == env48815) = true)

theorem identity48815 : scanCanonicalize (H12AffineFastState.compose env48815 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound48815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48816 : List Nat := [2,4,8,16,32,8,9,61,43,21,24,4096,41,4137,1,34,4152,25,20,0,4104,32,17,3,40,9,24,4152,4097,25,53,33,60,33,4144,42]

theorem envBound48816 : H12AffineFastState.Bounded env48816 := by
  intro p hp
  have h : env48816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48815_48816 : H12AffineEnvironment.transform 5 8 env48815 = env48816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env48815 == env48816) = true)

def env48817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98781,8328,65,12729469,79131,8480027,8568224,8390092,4314198,257,8484154,8492190,8462874]

theorem envBound48817 : H12AffineFastState.Bounded env48817 := by
  intro p hp
  have h : env48817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48762_48817 : H12AffineEnvironment.transform 17 32161 env48762 = env48817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env48762 == env48817) = true)

def env48818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98781,8328,65,8546653,79131,8480027,8568224,8390092,98678,257,8484154,8492190,8462874]

theorem envBound48818 : H12AffineFastState.Bounded env48818 := by
  intro p hp
  have h : env48818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48817_48818 : H12AffineEnvironment.transform 21 21792 env48817 = env48818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env48817 == env48818) = true)

def env48819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21792,8388608,98645,8192,65,8546653,79131,8480027,8568104,8389956,98678,257,8484154,8492054,8462874]

theorem envBound48819 : H12AffineFastState.Bounded env48819 := by
  intro p hp
  have h : env48819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48818_48819 : H12AffineEnvironment.transform 6 8 env48818 = env48819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48818 == env48819) = true)

theorem identity48819 : scanCanonicalize (H12AffineFastState.compose env48819 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound48819 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env48820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,32041,1025,32769,77898,21792,8388608,98645,8192,65,8399181,79131,8480027,8453432,8389956,98678,257,8484154,8492054,8462874]

theorem envBound48820 : H12AffineFastState.Bounded env48820 := by
  intro p hp
  have h : env48820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48819_48820 : H12AffineEnvironment.transform 16 16400 env48819 = env48820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48819 == env48820) = true)

def env48821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10281,1025,32769,77898,32,8388608,98645,8192,65,8399181,79131,8466459,8431672,8389956,98678,257,8462394,8492054,8462874]

theorem envBound48821 : H12AffineFastState.Bounded env48821 := by
  intro p hp
  have h : env48821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48820_48821 : H12AffineEnvironment.transform 13 5376 env48820 = env48821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48820 == env48821) = true)

theorem identity48821 : scanCanonicalize (H12AffineFastState.compose env48821 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48821 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,5392,10281,1025,8540,77898,32,8388608,73736,8192,65,8399181,79131,8466459,8391013,8389956,73771,257,8462394,8467787,8462874]

theorem envBound48822 : H12AffineFastState.Bounded env48822 := by
  intro p hp
  have h : env48822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48821_48822 : H12AffineEnvironment.transform 14 8541 env48821 = env48822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48821 == env48822) = true)

theorem identity48822 : scanCanonicalize (H12AffineFastState.compose env48822 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48822 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5392,10281,1025,8540,4160,32,8388608,2,8192,65,8399181,5393,8392721,8391013,8389956,33,257,8388656,8394049,8389136]

theorem envBound48823 : H12AffineFastState.Bounded env48823 := by
  intro p hp
  have h : env48823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48822_48823 : H12AffineEnvironment.transform 15 8202 env48822 = env48823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48822 == env48823) = true)

theorem identity48823 : scanCanonicalize (H12AffineFastState.compose env48823 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(22+1) ^^^ 1028) := by decide +kernel

theorem selectedBound48823 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env48824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5392,10281,1025,8540,4160,32,1028,2,8192,65,11593,5393,5141,3425,320,33,257,1076,4421,1556]

theorem envBound48824 : H12AffineFastState.Bounded env48824 := by
  intro p hp
  have h : env48824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48823_48824 : H12AffineEnvironment.transform 22 1028 env48823 = env48824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1028 env48823 == env48824) = true)

theorem identity48824 : scanCanonicalize (H12AffineFastState.compose env48824 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound48824 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env48825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5376,112,295,5392,2308,1025,113,4160,32,1028,2,301,65,3172,5393,5141,3425,320,33,257,1076,4421,1556]

theorem envBound48825 : H12AffineFastState.Bounded env48825 := by
  intro p hp
  have h : env48825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48824_48825 : H12AffineEnvironment.transform 12 301 env48824 = env48825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env48824 == env48825) = true)

theorem identity48825 : scanCanonicalize (H12AffineFastState.compose env48825 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound48825 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48826 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,4096,301,4145,112,295,4129,2308,304,113,4160,32,309,2,301,65,2389,4128,4388,2128,320,33,257,261,4421,805]

theorem envBound48826 : H12AffineFastState.Bounded env48826 := by
  intro p hp
  have h : env48826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48825_48826 : H12AffineEnvironment.transform 9 305 env48825 = env48826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env48825 == env48826) = true)

theorem identity48826 : scanCanonicalize (H12AffineFastState.compose env48826 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound48826 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env48827 : List Nat := [2,4,8,16,32,64,8,256,512,305,293,4096,301,4145,112,295,4129,33,304,113,4160,32,309,2,301,65,112,4128,4388,373,320,33,257,261,4421,805]

theorem envBound48827 : H12AffineFastState.Bounded env48827 := by
  intro p hp
  have h : env48827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48826_48827 : H12AffineEnvironment.transform 10 293 env48826 = env48827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env48826 == env48827) = true)

theorem identity48827 : scanCanonicalize (H12AffineFastState.compose env48827 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound48827 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env48828 : List Nat := [2,4,8,16,32,64,8,256,512,305,293,276,301,293,112,295,309,33,304,113,340,32,309,2,301,65,112,308,48,373,320,33,257,261,81,805]

theorem envBound48828 : H12AffineFastState.Bounded env48828 := by
  intro p hp
  have h : env48828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48827_48828 : H12AffineEnvironment.transform 11 276 env48827 = env48828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env48827 == env48828) = true)

theorem identity48828 : scanCanonicalize (H12AffineFastState.compose env48828 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound48828 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env48829 : List Nat := [2,4,8,16,32,64,8,256,373,305,293,276,301,293,112,295,309,33,304,113,340,32,309,2,301,65,112,308,48,373,320,33,257,261,81,80]

theorem envBound48829 : H12AffineFastState.Bounded env48829 := by
  intro p hp
  have h : env48829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48828_48829 : H12AffineEnvironment.transform 8 373 env48828 = env48829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env48828 == env48829) = true)

theorem identity48829 : scanCanonicalize (H12AffineFastState.compose env48829 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48829 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48830 : List Nat := [2,4,8,16,1,64,8,256,340,272,260,276,268,260,81,262,276,0,273,80,340,1,276,2,268,65,81,277,17,340,320,0,257,261,81,80]

theorem envBound48830 : H12AffineFastState.Bounded env48830 := by
  intro p hp
  have h : env48830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48829_48830 : H12AffineEnvironment.transform 4 1 env48829 = env48830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48829 == env48830) = true)

theorem identity48830 : scanCanonicalize (H12AffineFastState.compose env48830 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound48830 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48831 : List Nat := [2,4,8,16,1,64,8,84,0,68,80,64,88,80,81,82,64,0,69,80,0,1,64,2,88,65,81,65,17,0,20,0,85,81,81,80]

theorem envBound48831 : H12AffineFastState.Bounded env48831 := by
  intro p hp
  have h : env48831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48830_48831 : H12AffineEnvironment.transform 7 84 env48830 = env48831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env48830 == env48831) = true)

theorem identity48831 : scanCanonicalize (H12AffineFastState.compose env48831 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48832 : List Nat := [2,4,8,16,1,0,8,20,0,4,16,0,24,16,17,18,0,0,5,16,0,1,0,2,24,1,17,1,17,0,20,0,21,17,17,16]

theorem envBound48832 : H12AffineFastState.Bounded env48832 := by
  intro p hp
  have h : env48832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48831_48832 : H12AffineEnvironment.transform 5 0 env48831 = env48832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48831 == env48832) = true)

theorem identity48832 : scanCanonicalize (H12AffineFastState.compose env48832 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48832 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env48833 : List Nat := [2,4,8,1,1,0,8,5,0,4,1,0,9,1,0,3,0,0,5,1,0,1,0,2,9,1,0,1,0,0,5,0,4,0,0,1]

theorem envBound48833 : H12AffineFastState.Bounded env48833 := by
  intro p hp
  have h : env48833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48832_48833 : H12AffineEnvironment.transform 3 1 env48832 = env48833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48832 == env48833) = true)

theorem identity48833 : scanCanonicalize (H12AffineFastState.compose env48833 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48834 : List Nat := [2,1,8,1,1,0,8,0,0,1,1,0,9,1,0,3,0,0,0,1,0,1,0,2,9,1,0,1,0,0,0,0,1,0,0,1]

theorem envBound48834 : H12AffineFastState.Bounded env48834 := by
  intro p hp
  have h : env48834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48833_48834 : H12AffineEnvironment.transform 1 1 env48833 = env48834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48833 == env48834) = true)

theorem identity48834 : scanCanonicalize (H12AffineFastState.compose env48834 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48835 : List Nat := [2,1,1,1,1,0,1,0,0,1,1,0,0,1,0,3,0,0,0,1,0,1,0,2,0,1,0,1,0,0,0,0,1,0,0,1]

theorem envBound48835 : H12AffineFastState.Bounded env48835 := by
  intro p hp
  have h : env48835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48834_48835 : H12AffineEnvironment.transform 2 1 env48834 = env48835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48834 == env48835) = true)

theorem identity48835 : scanCanonicalize (H12AffineFastState.compose env48835 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48835 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48836 : List Nat := [1,1,1,1,1,0,1,0,0,1,1,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,1,0,0,1]

theorem envBound48836 : H12AffineFastState.Bounded env48836 := by
  intro p hp
  have h : env48836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48835_48836 : H12AffineEnvironment.transform 0 1 env48835 = env48836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48835 == env48836) = true)

def env48837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1025,32769,77898,33,8388608,98645,8192,65,8399181,79131,8466458,8431673,8389956,98678,257,8462395,8492054,8462874]

theorem envBound48837 : H12AffineFastState.Bounded env48837 := by
  intro p hp
  have h : env48837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48820_48837 : H12AffineEnvironment.transform 13 5377 env48820 = env48837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48820 == env48837) = true)

theorem identity48837 : scanCanonicalize (H12AffineFastState.compose env48837 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound48837 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,10280,1025,32769,77898,33,41292,98645,8192,65,34817,79131,102742,2421,41992,98678,257,98679,79194,99158]

theorem envBound48838 : H12AffineFastState.Bounded env48838 := by
  intro p hp
  have h : env48838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48837_48838 : H12AffineEnvironment.transform 22 41292 env48837 = env48838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env48837 == env48838) = true)

theorem identity48838 : scanCanonicalize (H12AffineFastState.compose env48838 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound48838 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env48839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40970,5393,10280,1025,32769,36928,33,41292,8543,8192,65,34817,38161,12636,2421,41992,8572,257,8573,38224,9052]

theorem envBound48839 : H12AffineFastState.Bounded env48839 := by
  intro p hp
  have h : env48839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48838_48839 : H12AffineEnvironment.transform 15 40970 env48838 = env48839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env48838 == env48839) = true)

theorem identity48839 : scanCanonicalize (H12AffineFastState.compose env48839 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48839 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env48840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,5393,10280,1025,1,4160,33,8524,8543,8192,65,2049,5393,12636,2421,9224,8572,257,8573,5456,9052]

theorem envBound48840 : H12AffineFastState.Bounded env48840 := by
  intro p hp
  have h : env48840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48839_48840 : H12AffineEnvironment.transform 14 0 env48839 = env48840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48839 == env48840) = true)

theorem identity48840 : scanCanonicalize (H12AffineFastState.compose env48840 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound48840 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,5377,0,294,5393,2308,1025,1,4160,33,96,115,300,65,2049,5393,4208,2421,1316,80,257,81,5456,624]

theorem envBound48841 : H12AffineFastState.Bounded env48841 := by
  intro p hp
  have h : env48841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48840_48841 : H12AffineEnvironment.transform 12 300 env48840 = env48841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env48840 == env48841) = true)

theorem identity48841 : scanCanonicalize (H12AffineFastState.compose env48841 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48841 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48842 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5377,0,263,5393,2308,1025,1,4160,0,65,82,269,65,2049,5393,4177,2388,1285,80,257,81,5456,593]

theorem envBound48842 : H12AffineFastState.Bounded env48842 := by
  intro p hp
  have h : env48842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48841_48842 : H12AffineEnvironment.transform 4 1 env48841 = env48842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48841 == env48842) = true)

theorem identity48842 : scanCanonicalize (H12AffineFastState.compose env48842 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound48842 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env48843 : List Nat := [2,4,8,16,1,64,8,256,512,785,2048,4096,269,4624,0,263,4608,2308,784,1,4160,0,65,82,269,65,2049,4608,4177,2388,532,80,257,81,4673,593]

theorem envBound48843 : H12AffineFastState.Bounded env48843 := by
  intro p hp
  have h : env48843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48842_48843 : H12AffineEnvironment.transform 9 785 env48842 = env48843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env48842 == env48843) = true)

theorem identity48843 : scanCanonicalize (H12AffineFastState.compose env48843 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48843 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48844 : List Nat := [2,4,8,16,1,16,8,256,512,785,2048,4096,269,4624,0,263,4608,2308,784,1,4112,0,17,2,269,17,2049,4608,4097,2308,532,0,257,1,4625,513]

theorem envBound48844 : H12AffineFastState.Bounded env48844 := by
  intro p hp
  have h : env48844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48843_48844 : H12AffineEnvironment.transform 5 16 env48843 = env48844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48843 == env48844) = true)

theorem identity48844 : scanCanonicalize (H12AffineFastState.compose env48844 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound48844 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48845 : List Nat := [2,4,8,16,1,16,8,256,512,785,2048,773,269,277,0,263,261,2308,784,1,789,0,17,2,269,17,2049,261,772,2308,532,0,257,1,276,513]

theorem envBound48845 : H12AffineFastState.Bounded env48845 := by
  intro p hp
  have h : env48845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48844_48845 : H12AffineEnvironment.transform 11 773 env48844 = env48845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env48844 == env48845) = true)

theorem identity48845 : scanCanonicalize (H12AffineFastState.compose env48845 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound48845 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48846 : List Nat := [2,4,8,16,1,16,8,256,512,785,27,773,269,277,0,263,261,287,784,1,789,0,17,2,269,17,26,261,772,287,532,0,257,1,276,513]

theorem envBound48846 : H12AffineFastState.Bounded env48846 := by
  intro p hp
  have h : env48846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48845_48846 : H12AffineEnvironment.transform 10 27 env48845 = env48846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env48845 == env48846) = true)

theorem identity48846 : scanCanonicalize (H12AffineFastState.compose env48846 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48846 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48847 : List Nat := [2,4,8,16,1,16,8,4,512,533,27,513,9,17,0,3,1,27,532,1,529,0,17,2,9,17,26,1,512,27,532,0,5,1,16,513]

theorem envBound48847 : H12AffineFastState.Bounded env48847 := by
  intro p hp
  have h : env48847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48846_48847 : H12AffineEnvironment.transform 7 4 env48846 = env48847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48846 == env48847) = true)

theorem identity48847 : scanCanonicalize (H12AffineFastState.compose env48847 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound48847 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48848 : List Nat := [2,4,8,16,1,16,8,4,16,5,27,17,9,17,0,3,1,27,4,1,1,0,17,2,9,17,26,1,16,27,4,0,5,1,16,17]

theorem envBound48848 : H12AffineFastState.Bounded env48848 := by
  intro p hp
  have h : env48848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48847_48848 : H12AffineEnvironment.transform 8 16 env48847 = env48848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env48847 == env48848) = true)

theorem identity48848 : scanCanonicalize (H12AffineFastState.compose env48848 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound48848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48849 : List Nat := [2,4,7,16,1,16,7,4,16,5,20,17,6,17,0,3,1,20,4,1,1,0,17,2,6,17,21,1,16,20,4,0,5,1,16,17]

theorem envBound48849 : H12AffineFastState.Bounded env48849 := by
  intro p hp
  have h : env48849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48848_48849 : H12AffineEnvironment.transform 2 7 env48848 = env48849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env48848 == env48849) = true)

theorem identity48849 : scanCanonicalize (H12AffineFastState.compose env48849 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48849 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env48850 : List Nat := [2,1,2,16,1,16,2,1,16,0,17,17,3,17,0,3,1,17,1,1,1,0,17,2,3,17,16,1,16,17,1,0,0,1,16,17]

theorem envBound48850 : H12AffineFastState.Bounded env48850 := by
  intro p hp
  have h : env48850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48849_48850 : H12AffineEnvironment.transform 1 1 env48849 = env48850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48849 == env48850) = true)

theorem identity48850 : scanCanonicalize (H12AffineFastState.compose env48850 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound48850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48851 : List Nat := [2,1,2,2,1,2,2,1,2,0,3,3,3,3,0,3,1,3,1,1,1,0,3,2,3,3,2,1,2,3,1,0,0,1,2,3]

theorem envBound48851 : H12AffineFastState.Bounded env48851 := by
  intro p hp
  have h : env48851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48850_48851 : H12AffineEnvironment.transform 3 2 env48850 = env48851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env48850 == env48851) = true)

theorem identity48851 : scanCanonicalize (H12AffineFastState.compose env48851 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48851 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48852 : List Nat := [1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,1,1,1,0,0,1,0,0,1,1,1,0,1,0,0,1,1,0]

theorem envBound48852 : H12AffineFastState.Bounded env48852 := by
  intro p hp
  have h : env48852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48851_48852 : H12AffineEnvironment.transform 0 1 env48851 = env48852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48851 == env48852) = true)

def env48853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,8388608,98644,8193,65,8546653,79131,8480027,8568105,8389957,98678,257,8484154,8492055,8462874]

theorem envBound48853 : H12AffineFastState.Bounded env48853 := by
  intro p hp
  have h : env48853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48818_48853 : H12AffineEnvironment.transform 6 9 env48818 = env48853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48818 == env48853) = true)

theorem identity48853 : scanCanonicalize (H12AffineFastState.compose env48853 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound48853 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env48854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,73755,98644,8193,65,215366,79131,17664,236850,75102,98678,257,21793,46092,513]

theorem envBound48854 : H12AffineFastState.Bounded env48854 := by
  intro p hp
  have h : env48854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48853_48854 : H12AffineEnvironment.transform 22 73755 env48853 = env48854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env48853 == env48854) = true)

theorem identity48854 : scanCanonicalize (H12AffineFastState.compose env48854 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound48854 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,77898,21792,73755,95497,8193,65,215366,79131,17664,223599,75102,95531,257,21793,16465,513]

theorem envBound48855 : H12AffineFastState.Bounded env48855 := by
  intro p hp
  have h : env48855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48854_48855 : H12AffineEnvironment.transform 14 29789 env48854 = env48855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env48854 == env48855) = true)

theorem identity48855 : scanCanonicalize (H12AffineFastState.compose env48855 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound48855 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env48856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,32040,1025,29788,17728,21792,21777,3,8193,65,146508,16401,17664,138341,20564,33,257,21793,16465,513]

theorem envBound48856 : H12AffineFastState.Bounded env48856 := by
  intro p hp
  have h : env48856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48855_48856 : H12AffineEnvironment.transform 15 29962 env48855 = env48856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env48855 == env48856) = true)

theorem identity48856 : scanCanonicalize (H12AffineFastState.compose env48856 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound48856 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8460,8283,131072,10361,1025,8461,4113,113,64,3,8193,65,146508,5440,4177,138341,1285,33,257,112,5376,513]

theorem envBound48857 : H12AffineFastState.Bounded env48857 := by
  intro p hp
  have h : env48857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48856_48857 : H12AffineEnvironment.transform 13 5457 env48856 = env48857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env48856 == env48857) = true)

theorem identity48857 : scanCanonicalize (H12AffineFastState.compose env48857 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48858 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10280,1025,8461,4113,32,17,3,8193,16,146461,5393,4096,138292,1285,33,257,33,5376,513]

theorem envBound48858 : H12AffineFastState.Bounded env48858 := by
  intro p hp
  have h : env48858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48857_48858 : H12AffineEnvironment.transform 5 17 env48857 = env48858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48857 == env48858) = true)

theorem identity48858 : scanCanonicalize (H12AffineFastState.compose env48858 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13592) := by decide +kernel

theorem selectedBound48858 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48859 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,13592,10280,1025,8461,4113,32,17,3,8193,16,2309,5393,4096,10540,1285,33,257,33,5376,513]

theorem envBound48859 : H12AffineFastState.Bounded env48859 := by
  intro p hp
  have h : env48859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48858_48859 : H12AffineEnvironment.transform 16 13592 env48858 = env48859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13592 env48858 == env48859) = true)

theorem identity48859 : scanCanonicalize (H12AffineFastState.compose env48859 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48859 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48860 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8200,8202,13340,10280,1025,8201,4113,32,17,3,8193,16,2049,5141,4096,10280,1025,33,5,33,5124,513]

theorem envBound48860 : H12AffineFastState.Bounded env48860 := by
  intro p hp
  have h : env48860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48859_48860 : H12AffineEnvironment.transform 7 4 env48859 = env48860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48859 == env48860) = true)

theorem identity48860 : scanCanonicalize (H12AffineFastState.compose env48860 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound48860 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48861 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,4096,8192,5124,8200,8202,13340,8200,1025,8201,4113,32,17,3,8193,16,33,5141,4096,8200,1025,33,5,33,5124,513]

theorem envBound48861 : H12AffineFastState.Bounded env48861 := by
  intro p hp
  have h : env48861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48860_48861 : H12AffineEnvironment.transform 10 32 env48860 = env48861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env48860 == env48861) = true)

theorem identity48861 : scanCanonicalize (H12AffineFastState.compose env48861 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound48861 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48862 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,4096,4120,5124,4112,4114,1028,4112,1025,4113,4113,32,17,3,4121,16,33,5141,4096,4112,1025,33,5,33,5124,513]

theorem envBound48862 : H12AffineFastState.Bounded env48862 := by
  intro p hp
  have h : env48862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48861_48862 : H12AffineEnvironment.transform 12 4120 env48861 = env48862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env48861 == env48862) = true)

theorem identity48862 : scanCanonicalize (H12AffineFastState.compose env48862 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound48862 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48863 : List Nat := [2,4,8,16,32,17,9,4,512,1024,32,17,9,1045,1,3,1028,1,1025,0,0,32,17,3,8,16,33,1028,17,1,1025,33,5,33,1045,513]

theorem envBound48863 : H12AffineFastState.Bounded env48863 := by
  intro p hp
  have h : env48863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48862_48863 : H12AffineEnvironment.transform 11 17 env48862 = env48863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48862 == env48863) = true)

theorem identity48863 : scanCanonicalize (H12AffineFastState.compose env48863 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48864 : List Nat := [2,4,8,16,0,17,9,4,512,1024,0,17,9,1045,1,3,1028,1,1025,0,0,0,17,3,8,16,1,1028,17,1,1025,1,5,1,1045,513]

theorem envBound48864 : H12AffineFastState.Bounded env48864 := by
  intro p hp
  have h : env48864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48863_48864 : H12AffineEnvironment.transform 4 0 env48863 = env48864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48863 == env48864) = true)

theorem identity48864 : scanCanonicalize (H12AffineFastState.compose env48864 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound48864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48865 : List Nat := [2,4,8,16,0,17,9,4,17,1024,0,17,9,1045,1,3,1028,1,1025,0,0,0,17,3,8,16,1,1028,17,1,1025,1,5,1,1045,16]

theorem envBound48865 : H12AffineFastState.Bounded env48865 := by
  intro p hp
  have h : env48865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48864_48865 : H12AffineEnvironment.transform 8 17 env48864 = env48865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env48864 == env48865) = true)

def env48866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98781,8328,65,8546652,79131,8480027,8568224,8390092,98679,257,8484154,8492190,8462874]

theorem envBound48866 : H12AffineFastState.Bounded env48866 := by
  intro p hp
  have h : env48866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48817_48866 : H12AffineEnvironment.transform 21 21793 env48817 = env48866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env48817 == env48866) = true)

theorem identity48866 : scanCanonicalize (H12AffineFastState.compose env48866 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound48866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,17,98781,8328,65,158029,79131,91402,179633,1501,98679,257,95531,103567,74251]

theorem envBound48867 : H12AffineFastState.Bounded env48867 := by
  intro p hp
  have h : env48867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48866_48867 : H12AffineEnvironment.transform 22 17 env48866 = env48867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env48866 == env48867) = true)

theorem identity48867 : scanCanonicalize (H12AffineFastState.compose env48867 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48867 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,17,41431,8328,65,158029,5393,17664,179633,1501,41341,257,21793,46213,513]

theorem envBound48868 : H12AffineFastState.Bounded env48868 := by
  intro p hp
  have h : env48868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48867_48868 : H12AffineEnvironment.transform 15 8202 env48867 = env48868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48867 == env48868) = true)

theorem identity48868 : scanCanonicalize (H12AffineFastState.compose env48868 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 49352) := by decide +kernel

theorem selectedBound48868 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env48869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49352,32161,1025,32769,4160,21793,17,41431,8328,65,43397,5393,17664,32121,1501,41341,257,21793,46213,513]

theorem envBound48869 : H12AffineFastState.Bounded env48869 := by
  intro p hp
  have h : env48869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48868_48869 : H12AffineEnvironment.transform 16 49352 env48868 = env48869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49352 env48868 == env48869) = true)

theorem identity48869 : scanCanonicalize (H12AffineFastState.compose env48869 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound48869 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,13508,32161,1025,29709,4160,21793,17,21979,8328,65,23945,5393,17664,32121,1501,21873,257,21793,16521,513]

theorem envBound48870 : H12AffineFastState.Bounded env48870 := by
  intro p hp
  have h : env48870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48869_48870 : H12AffineEnvironment.transform 14 29708 env48869 = env48870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env48869 == env48870) = true)

theorem identity48870 : scanCanonicalize (H12AffineFastState.compose env48870 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound48870 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8541,8202,13508,10480,1025,8540,4160,112,17,138,8328,65,2264,5393,4177,10280,1501,32,257,112,5592,513]

theorem envBound48871 : H12AffineFastState.Bounded env48871 := by
  intro p hp
  have h : env48871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48870_48871 : H12AffineEnvironment.transform 13 5457 env48870 = env48871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env48870 == env48871) = true)

theorem identity48871 : scanCanonicalize (H12AffineFastState.compose env48871 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound48871 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env48872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,217,398,5440,2420,1025,216,4160,112,17,138,268,65,2264,5393,4177,2476,1501,32,257,112,5592,513]

theorem envBound48872 : H12AffineFastState.Bounded env48872 := by
  intro p hp
  have h : env48872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48871_48872 : H12AffineEnvironment.transform 12 388 env48871 = env48872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env48871 == env48872) = true)

theorem identity48872 : scanCanonicalize (H12AffineFastState.compose env48872 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48872 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,80,263,5440,2420,1025,81,4160,112,17,3,268,65,2129,5393,4177,2341,1364,32,257,112,5457,513]

theorem envBound48873 : H12AffineFastState.Bounded env48873 := by
  intro p hp
  have h : env48873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48872_48873 : H12AffineEnvironment.transform 6 9 env48872 = env48873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48872 == env48873) = true)

theorem identity48873 : scanCanonicalize (H12AffineFastState.compose env48873 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48874 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5237,80,35,5220,2128,1025,81,4160,112,17,3,40,65,2129,5173,4177,2049,1136,32,37,112,5237,513]

theorem envBound48874 : H12AffineFastState.Bounded env48874 := by
  intro p hp
  have h : env48874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48873_48874 : H12AffineEnvironment.transform 7 36 env48873 = env48874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48873 == env48874) = true)

theorem identity48874 : scanCanonicalize (H12AffineFastState.compose env48874 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48874 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48875 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4113,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound48875 : H12AffineFastState.Bounded env48875 := by
  intro p hp
  have h : env48875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48874_48875 : H12AffineEnvironment.transform 5 17 env48874 = env48875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48874 == env48875) = true)

def env48876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392317,8328,65,12729468,79130,8722618,8830977,8681580,4314199,257,8484155,8492191,8740794]

theorem envBound48876 : H12AffineFastState.Bounded env48876 := by
  intro p hp
  have h : env48876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48761_48876 : H12AffineEnvironment.transform 23 392317 env48761 = env48876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392317 env48761 == env48876) = true)

def env48877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98781,8328,65,12729468,79130,8480026,8568225,8390092,4314199,257,8484155,8492191,8462874]

theorem envBound48877 : H12AffineFastState.Bounded env48877 := by
  intro p hp
  have h : env48877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48876_48877 : H12AffineEnvironment.transform 17 32160 env48876 = env48877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env48876 == env48877) = true)

def env48878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98781,8328,65,8546652,79130,8480026,8568225,8390092,98679,257,8484155,8492191,8462874]

theorem envBound48878 : H12AffineFastState.Bounded env48878 := by
  intro p hp
  have h : env48878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48877_48878 : H12AffineEnvironment.transform 21 21792 env48877 = env48878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env48877 == env48878) = true)

theorem identity48878 : scanCanonicalize (H12AffineFastState.compose env48878 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,8388608,41431,8328,65,8546652,5392,8406288,8568225,8390092,41341,257,8410417,8434837,8389136]

theorem envBound48879 : H12AffineFastState.Bounded env48879 := by
  intro p hp
  have h : env48879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48878_48879 : H12AffineEnvironment.transform 15 8202 env48878 = env48879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48878 == env48879) = true)

def env48880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,96,41431,8328,65,158012,5392,17776,179649,1452,41341,257,21841,46325,624]

theorem envBound48880 : H12AffineFastState.Bounded env48880 := by
  intro p hp
  have h : env48880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48879_48880 : H12AffineEnvironment.transform 22 96 env48879 = env48880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 96 env48879 == env48880) = true)

theorem identity48880 : scanCanonicalize (H12AffineFastState.compose env48880 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound48880 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13509,32160,1025,32769,4161,21792,96,41431,8328,65,24057,5392,17776,35076,1452,41341,257,21841,46325,624]

theorem envBound48881 : H12AffineFastState.Bounded env48881 := by
  intro p hp
  have h : env48881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48880_48881 : H12AffineEnvironment.transform 16 13509 env48880 = env48881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env48880 == env48881) = true)

theorem identity48881 : scanCanonicalize (H12AffineFastState.compose env48881 (packedSelected [0,2,3,4,5,6,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound48881 : packedSelected [0,2,3,4,5,6,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env48882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5409,32768,8202,13509,10369,1025,32769,4161,1,96,41431,8328,65,2264,5392,4177,35076,1452,41341,257,112,46325,624]

theorem envBound48882 : H12AffineFastState.Bounded env48882 := by
  intro p hp
  have h : env48882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48881_48882 : H12AffineEnvironment.transform 13 5409 env48881 = env48882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env48881 == env48882) = true)

theorem identity48882 : scanCanonicalize (H12AffineFastState.compose env48882 (packedSelected [1,3,5,8,17,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48882 : packedSelected [1,3,5,8,17,26,31] rootPS < 2^1333 := by decide +kernel

def env48883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5409,8541,8202,13509,10369,1025,8540,4161,1,96,138,8328,65,2264,5392,4177,10329,1452,32,257,112,5544,624]

theorem envBound48883 : H12AffineFastState.Bounded env48883 := by
  intro p hp
  have h : env48883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48882_48883 : H12AffineEnvironment.transform 14 8541 env48882 = env48883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48882 == env48883) = true)

theorem identity48883 : scanCanonicalize (H12AffineFastState.compose env48883 (packedSelected [0,1,2,7,8,10,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound48883 : packedSelected [0,1,2,7,8,10,14,17,20] rootPS < 2^1333 := by decide +kernel

def env48884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5409,249,430,5473,2341,1025,248,4161,1,96,138,300,65,2264,5392,4177,2557,1452,32,257,112,5544,624]

theorem envBound48884 : H12AffineFastState.Bounded env48884 := by
  intro p hp
  have h : env48884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48883_48884 : H12AffineEnvironment.transform 12 420 env48883 = env48884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env48883 == env48884) = true)

theorem identity48884 : scanCanonicalize (H12AffineFastState.compose env48884 (packedSelected [2,4,6,9,11,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound48884 : packedSelected [2,4,6,9,11,17,18] rootPS < 2^1333 := by decide +kernel

def env48885 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,420,5409,136,430,5392,2341,1025,137,4144,1,17,138,300,48,2217,5392,4128,2444,1452,32,257,1,5544,513]

theorem envBound48885 : H12AffineFastState.Bounded env48885 := by
  intro p hp
  have h : env48885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48884_48885 : H12AffineEnvironment.transform 5 49 env48884 = env48885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env48884 == env48885) = true)

theorem identity48885 : scanCanonicalize (H12AffineFastState.compose env48885 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48885 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48886 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,388,5377,136,398,5392,2309,1025,137,4112,1,17,138,268,16,2185,5392,4096,2444,1420,0,257,1,5512,513]

theorem envBound48886 : H12AffineFastState.Bounded env48886 := by
  intro p hp
  have h : env48886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48885_48886 : H12AffineEnvironment.transform 4 0 env48885 = env48886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48885 == env48886) = true)

theorem identity48886 : scanCanonicalize (H12AffineFastState.compose env48886 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48886 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48887 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,1,263,5392,2309,1025,0,4112,1,17,3,268,16,2048,5392,4096,2309,1285,0,257,1,5377,513]

theorem envBound48887 : H12AffineFastState.Bounded env48887 := by
  intro p hp
  have h : env48887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48886_48887 : H12AffineEnvironment.transform 6 9 env48886 = env48887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48886 == env48887) = true)

theorem identity48887 : scanCanonicalize (H12AffineFastState.compose env48887 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48888 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5125,1,3,5140,2049,1025,0,4112,1,17,3,8,16,2048,5140,4096,2049,1025,0,5,1,5125,513]

theorem envBound48888 : H12AffineFastState.Bounded env48888 := by
  intro p hp
  have h : env48888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48887_48888 : H12AffineEnvironment.transform 7 4 env48887 = env48888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48887 == env48888) = true)

def env48889 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1045,1,3,1028,2049,1025,0,0,1,17,3,8,16,2048,1028,16,2049,1025,0,5,1,1045,513]

theorem envBound48889 : H12AffineFastState.Bounded env48889 := by
  intro p hp
  have h : env48889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48888_48889 : H12AffineEnvironment.transform 11 16 env48888 = env48889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48888 == env48889) = true)

theorem identity48889 : scanCanonicalize (H12AffineFastState.compose env48889 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48890 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,1,1,3,16,2049,21,0,0,1,17,3,8,16,2048,16,16,2049,21,0,5,1,1,513]

theorem envBound48890 : H12AffineFastState.Bounded env48890 := by
  intro p hp
  have h : env48890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48889_48890 : H12AffineEnvironment.transform 9 20 env48889 = env48890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48889 == env48890) = true)

theorem identity48890 : scanCanonicalize (H12AffineFastState.compose env48890 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48891 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,1,1,3,16,0,21,0,0,1,17,3,8,16,1,16,16,0,21,0,5,1,1,513]

theorem envBound48891 : H12AffineFastState.Bounded env48891 := by
  intro p hp
  have h : env48891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48890_48891 : H12AffineEnvironment.transform 10 1 env48890 = env48891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48890 == env48891) = true)

def leafEnv48891 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,1,1,3,16,0,21,0,0,1,17,3,20,8,1,16,1,16,16,0,21,0,5,1,5,2,1,513,1,0,0]

def active48891 : List Nat := [0,1,2,3,8]

def tree48891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48891 : H12WitnessSearch.Good tree48891 := H12GlobalWitnessIndex.good

theorem leafIdentity48891 : H12AffineFastState.composeSystem env48891 rootObs = leafEnv48891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48891 rootObs == leafEnv48891) = true)

theorem terminalChecked48891 : H12PackedTerminal.terminalCheckFast leafEnv48891 active48891 tree48891 = true := by decide +kernel

def env48892 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1044,1,3,1029,2049,1025,0,1,1,17,3,8,16,2048,1029,17,2049,1025,0,5,1,1044,513]

theorem envBound48892 : H12AffineFastState.Bounded env48892 := by
  intro p hp
  have h : env48892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48888_48892 : H12AffineEnvironment.transform 11 17 env48888 = env48892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48888 == env48892) = true)

def env48893 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,9,0,1,3,17,2049,21,0,1,1,17,3,8,16,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound48893 : H12AffineFastState.Bounded env48893 := by
  intro p hp
  have h : env48893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48892_48893 : H12AffineEnvironment.transform 9 20 env48892 = env48893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48892 == env48893) = true)

theorem identity48893 : scanCanonicalize (H12AffineFastState.compose env48893 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48894 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,0,1,3,17,1,21,0,1,1,17,3,8,16,0,17,17,1,21,0,5,1,0,513]

theorem envBound48894 : H12AffineFastState.Bounded env48894 := by
  intro p hp
  have h : env48894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1