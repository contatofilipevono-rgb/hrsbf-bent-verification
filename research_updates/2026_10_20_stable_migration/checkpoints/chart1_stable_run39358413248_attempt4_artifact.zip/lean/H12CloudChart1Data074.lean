import H12CloudChart1Data073

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound18677 : H12AffineFastState.Bounded env18677 := by
  intro p hp
  have h : env18677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18676_18677 : H12AffineEnvironment.transform 3 0 env18676 = env18677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18676 == env18677) = true)

def env18678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,8631681,8328,64,4486528,8393984,8548701,8830977,143761,12645452,257,21792,46212,202310]

theorem envBound18678 : H12AffineFastState.Bounded env18678 := by
  intro p hp
  have h : env18678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18562_18678 : H12AffineEnvironment.transform 23 8631681 env18562 = env18678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631681 env18562 == env18678) = true)

def env18679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180360,95497,8328,64,4486528,185736,45525,262281,143761,4338884,257,21792,46212,202310]

theorem envBound18679 : H12AffineFastState.Bounded env18679 := by
  intro p hp
  have h : env18679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18678_18679 : H12AffineEnvironment.transform 22 180360 env18678 = env18679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env18678 == env18679) = true)

def env18680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180360,95497,8328,64,23808,185736,45525,262281,143761,400452,257,21792,46212,202310]

theorem envBound18680 : H12AffineFastState.Bounded env18680 := by
  intro p hp
  have h : env18680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18679_18680 : H12AffineEnvironment.transform 21 272512 env18679 = env18680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18679 == env18680) = true)

theorem identity18680 : scanCanonicalize (H12AffineFastState.compose env18680 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18680 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140300,272512,144477,95497,8328,64,23808,139613,17664,262281,143761,400452,257,21792,16465,202310]

theorem envBound18681 : H12AffineFastState.Bounded env18681 := by
  intro p hp
  have h : env18681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18680_18681 : H12AffineEnvironment.transform 14 29909 env18680 = env18681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18680 == env18681) = true)

def env18682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272392,144477,95497,8192,64,23808,139613,17664,262145,143641,400452,257,21792,16465,202310]

theorem envBound18682 : H12AffineFastState.Bounded env18682 := by
  intro p hp
  have h : env18682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18681_18682 : H12AffineEnvironment.transform 6 8 env18681 = env18682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18681 == env18682) = true)

theorem identity18682 : scanCanonicalize (H12AffineFastState.compose env18682 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound18682 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env18683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,212078,1025,29788,140300,201830,144477,95497,8192,64,23808,139613,17664,212079,143641,73770,257,21792,16465,202310]

theorem envBound18683 : H12AffineFastState.Bounded env18683 := by
  intro p hp
  have h : env18683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18682_18683 : H12AffineEnvironment.transform 17 212078 env18682 = env18683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env18682 == env18683) = true)

theorem identity18683 : scanCanonicalize (H12AffineFastState.compose env18683 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18683 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env18684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,212078,1025,8541,140300,201830,144477,73736,8192,64,2049,139613,4097,212079,143641,73770,257,33,5456,202310]

theorem envBound18684 : H12AffineFastState.Bounded env18684 := by
  intro p hp
  have h : env18684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18683_18684 : H12AffineEnvironment.transform 13 5377 env18683 = env18684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18683 == env18684) = true)

theorem identity18684 : scanCanonicalize (H12AffineFastState.compose env18684 (packedSelected [2,3,5,6,11,12,14,16,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound18684 : packedSelected [2,3,5,6,11,12,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env18685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,13673,67847,1025,8541,4453,73999,308,73736,8192,64,2049,5172,4097,67846,1136,73770,257,33,5456,74543]

theorem envBound18685 : H12AffineFastState.Bounded env18685 := by
  intro p hp
  have h : env18685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18684_18685 : H12AffineEnvironment.transform 16 13673 env18684 = env18685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env18684 == env18685) = true)

theorem identity18685 : scanCanonicalize (H12AffineFastState.compose env18685 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18685 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,65536,5172,67847,1025,0,4453,65618,308,65877,349,64,2049,5172,4097,67846,1136,65911,257,33,5456,66162]

theorem envBound18686 : H12AffineFastState.Bounded env18686 := by
  intro p hp
  have h : env18686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18685_18686 : H12AffineEnvironment.transform 12 349 env18685 = env18686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18685 == env18686) = true)

theorem identity18686 : scanCanonicalize (H12AffineFastState.compose env18686 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18686 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env18687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5172,2128,1025,0,4453,261,308,2,349,64,2049,5172,4097,2129,1136,32,257,33,5456,805]

theorem envBound18687 : H12AffineFastState.Bounded env18687 := by
  intro p hp
  have h : env18687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18686_18687 : H12AffineEnvironment.transform 15 343 env18686 = env18687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18686 == env18687) = true)

def env18688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272393,144477,95497,8193,64,23808,139613,17664,262144,143640,400452,257,21792,16465,202310]

theorem envBound18688 : H12AffineFastState.Bounded env18688 := by
  intro p hp
  have h : env18688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18681_18688 : H12AffineEnvironment.transform 6 9 env18681 = env18688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18681 == env18688) = true)

theorem identity18688 : scanCanonicalize (H12AffineFastState.compose env18688 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound18688 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env18689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,146744,1025,29789,140300,136497,144477,95497,8193,64,23808,139613,17664,146744,143640,8572,257,21792,16465,202310]

theorem envBound18689 : H12AffineFastState.Bounded env18689 := by
  intro p hp
  have h : env18689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18688_18689 : H12AffineEnvironment.transform 17 146744 env18688 = env18689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env18688 == env18689) = true)

theorem identity18689 : scanCanonicalize (H12AffineFastState.compose env18689 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound18689 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,2421,1025,29789,4161,8572,16,95497,8193,64,23808,5392,17664,2421,1365,8572,257,21792,16465,74251]

theorem envBound18690 : H12AffineFastState.Bounded env18690 := by
  intro p hp
  have h : env18690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18689_18690 : H12AffineEnvironment.transform 16 13389 env18689 = env18690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env18689 == env18690) = true)

theorem identity18690 : scanCanonicalize (H12AffineFastState.compose env18690 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18690 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13389,2421,1025,29789,4161,8572,16,21763,8193,64,23808,5392,17664,2421,1365,8572,257,21792,16465,513]

theorem envBound18691 : H12AffineFastState.Bounded env18691 := by
  intro p hp
  have h : env18691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18690_18691 : H12AffineEnvironment.transform 15 8202 env18690 = env18691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18690 == env18691) = true)

theorem identity18691 : scanCanonicalize (H12AffineFastState.compose env18691 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18691 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13389,2421,1025,8541,4161,8572,16,3,8193,64,2048,5392,4096,2421,1365,8572,257,32,5457,513]

theorem envBound18692 : H12AffineFastState.Bounded env18692 := by
  intro p hp
  have h : env18692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18691_18692 : H12AffineEnvironment.transform 13 5376 env18691 = env18692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18691 == env18692) = true)

theorem identity18692 : scanCanonicalize (H12AffineFastState.compose env18692 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18692 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1025,1,4161,32,16,3,349,64,2048,5392,4096,2421,1365,32,257,32,5457,513]

theorem envBound18693 : H12AffineFastState.Bounded env18693 := by
  intro p hp
  have h : env18693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18692_18693 : H12AffineEnvironment.transform 12 348 env18692 = env18693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18692 == env18693) = true)

theorem identity18693 : scanCanonicalize (H12AffineFastState.compose env18693 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound18693 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,10,4096,348,5376,0,342,5393,383,1025,1,4161,32,16,3,349,64,10,5392,4096,383,1365,32,257,32,5457,513]

theorem envBound18694 : H12AffineFastState.Bounded env18694 := by
  intro p hp
  have h : env18694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18693_18694 : H12AffineEnvironment.transform 10 10 env18693 = env18694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env18693 == env18694) = true)

theorem identity18694 : scanCanonicalize (H12AffineFastState.compose env18694 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound18694 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,10,1077,348,309,0,342,292,383,1025,1,1140,32,16,3,349,64,10,293,1077,383,1365,32,257,32,356,513]

theorem envBound18695 : H12AffineFastState.Bounded env18695 := by
  intro p hp
  have h : env18695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18694_18695 : H12AffineEnvironment.transform 11 1077 env18694 = env18695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env18694 == env18695) = true)

theorem identity18695 : scanCanonicalize (H12AffineFastState.compose env18695 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18695 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18696 : List Nat := [2,4,8,16,32,17,9,256,512,1024,10,1077,269,309,0,263,292,302,1025,1,1061,32,16,3,268,17,10,293,1077,302,1284,32,257,32,309,513]

theorem envBound18696 : H12AffineFastState.Bounded env18696 := by
  intro p hp
  have h : env18696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18695_18696 : H12AffineEnvironment.transform 5 17 env18695 = env18696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18695 == env18696) = true)

def env18697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180360,95497,8328,64,23809,185736,45525,262281,143761,400453,257,21792,46212,202310]

theorem envBound18697 : H12AffineFastState.Bounded env18697 := by
  intro p hp
  have h : env18697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18679_18697 : H12AffineEnvironment.transform 21 272513 env18679 = env18697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18679 == env18697) = true)

theorem identity18697 : scanCanonicalize (H12AffineFastState.compose env18697 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound18697 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,272513,62660,95497,8328,64,23809,57796,45525,262281,1501,272393,257,21792,46212,74250]

theorem envBound18698 : H12AffineFastState.Bounded env18698 := by
  intro p hp
  have h : env18698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18697_18698 : H12AffineEnvironment.transform 16 13388 env18697 = env18698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env18697 == env18698) = true)

theorem identity18698 : scanCanonicalize (H12AffineFastState.compose env18698 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18698 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,13388,262144,1025,32769,4160,272513,62660,21762,8328,64,23809,57796,45525,262281,1501,272393,257,21792,46212,513]

theorem envBound18699 : H12AffineFastState.Bounded env18699 := by
  intro p hp
  have h : env18699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18698_18699 : H12AffineEnvironment.transform 15 8203 env18698 = env18699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18698 == env18699) = true)

theorem identity18699 : scanCanonicalize (H12AffineFastState.compose env18699 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18699 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env18700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,262144,1025,32769,4160,264533,54544,21762,348,64,23809,49168,36865,262281,1501,264669,257,21792,38224,513]

theorem envBound18700 : H12AffineFastState.Bounded env18700 := by
  intro p hp
  have h : env18700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18699_18700 : H12AffineEnvironment.transform 12 468 env18699 = env18700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18699 == env18700) = true)

theorem identity18700 : scanCanonicalize (H12AffineFastState.compose env18700 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound18700 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env18701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,56437,1025,32769,4160,54560,54544,21762,348,64,23809,49168,36865,56572,1501,54696,257,21792,38224,513]

theorem envBound18701 : H12AffineFastState.Bounded env18701 := by
  intro p hp
  have h : env18701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18700_18701 : H12AffineEnvironment.transform 17 56437 env18700 = env18701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env18700 == env18701) = true)

theorem identity18701 : scanCanonicalize (H12AffineFastState.compose env18701 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound18701 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env18702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,32768,479,5528,35324,1025,32769,4160,32937,32921,139,348,64,2184,38297,36865,35189,1501,32801,257,169,38224,513]

theorem envBound18702 : H12AffineFastState.Bounded env18702 := by
  intro p hp
  have h : env18702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18701_18702 : H12AffineEnvironment.transform 13 5513 env18701 = env18702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env18701 == env18702) = true)

theorem identity18702 : scanCanonicalize (H12AffineFastState.compose env18702 (packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound18702 : packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env18703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,479,5528,2421,1025,136,4160,32,16,139,348,64,2184,5392,4232,2556,1501,168,257,169,5593,513]

theorem envBound18703 : H12AffineFastState.Bounded env18703 := by
  intro p hp
  have h : env18703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18702_18703 : H12AffineEnvironment.transform 14 137 env18702 = env18703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18702 == env18703) = true)

theorem identity18703 : scanCanonicalize (H12AffineFastState.compose env18703 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18703 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18704 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,81,263,5440,2421,1025,80,4160,32,16,83,348,64,2128,5392,4176,2340,1285,112,257,113,5377,513]

theorem envBound18704 : H12AffineFastState.Bounded env18704 := by
  intro p hp
  have h : env18704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18703_18704 : H12AffineEnvironment.transform 6 88 env18703 = env18704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18703 == env18704) = true)

theorem identity18704 : scanCanonicalize (H12AffineFastState.compose env18704 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound18704 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18705 : List Nat := [2,4,8,16,32,64,88,53,512,1024,2048,4096,57,5220,81,50,5237,2112,1025,80,4160,32,16,83,105,64,2128,5157,4176,2065,1072,112,52,113,5172,513]

theorem envBound18705 : H12AffineFastState.Bounded env18705 := by
  intro p hp
  have h : env18705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18704_18705 : H12AffineEnvironment.transform 7 53 env18704 = env18705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env18704 == env18705) = true)

theorem identity18705 : scanCanonicalize (H12AffineFastState.compose env18705 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound18705 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18706 : List Nat := [2,4,8,16,32,64,88,53,512,1024,1572,4096,57,5220,81,50,5237,1636,1025,80,4160,32,16,83,105,64,1652,5157,4176,1589,1072,112,52,113,5172,513]

theorem envBound18706 : H12AffineFastState.Bounded env18706 := by
  intro p hp
  have h : env18706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18705_18706 : H12AffineEnvironment.transform 10 1572 env18705 = env18706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env18705 == env18706) = true)

theorem identity18706 : scanCanonicalize (H12AffineFastState.compose env18706 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound18706 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18707 : List Nat := [2,4,8,16,32,64,88,53,512,1024,1572,592,57,1588,81,50,1573,1636,1025,80,528,32,16,83,105,64,1652,1653,512,1589,1072,112,52,113,1636,513]

theorem envBound18707 : H12AffineFastState.Bounded env18707 := by
  intro p hp
  have h : env18707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18706_18707 : H12AffineEnvironment.transform 11 592 env18706 = env18707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env18706 == env18707) = true)

theorem identity18707 : scanCanonicalize (H12AffineFastState.compose env18707 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound18707 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env18708 : List Nat := [2,4,8,16,32,64,88,53,512,612,64,592,57,80,81,50,65,0,613,80,528,32,16,83,105,64,16,17,512,81,596,112,52,113,0,513]

theorem envBound18708 : H12AffineFastState.Bounded env18708 := by
  intro p hp
  have h : env18708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18707_18708 : H12AffineEnvironment.transform 9 612 env18707 = env18708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env18707 == env18708) = true)

theorem identity18708 : scanCanonicalize (H12AffineFastState.compose env18708 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18708 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env18709 : List Nat := [2,4,8,16,32,64,88,53,16,116,64,64,57,80,81,50,65,0,117,80,0,32,16,83,105,64,16,17,16,81,68,112,52,113,0,17]

theorem envBound18709 : H12AffineFastState.Bounded env18709 := by
  intro p hp
  have h : env18709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18708_18709 : H12AffineEnvironment.transform 8 16 env18708 = env18709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18708 == env18709) = true)

theorem identity18709 : scanCanonicalize (H12AffineFastState.compose env18709 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18710 : List Nat := [2,4,8,0,32,64,72,37,0,100,64,64,41,64,65,34,65,0,101,64,0,32,0,67,105,64,0,1,0,65,68,96,36,97,0,1]

theorem envBound18710 : H12AffineFastState.Bounded env18710 := by
  intro p hp
  have h : env18710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18709_18710 : H12AffineEnvironment.transform 3 0 env18709 = env18710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18709 == env18710) = true)

theorem identity18710 : scanCanonicalize (H12AffineFastState.compose env18710 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18711 : List Nat := [2,4,8,0,0,64,72,5,0,68,64,64,9,64,65,2,65,0,69,64,0,0,0,67,73,64,0,1,0,65,68,64,4,65,0,1]

theorem envBound18711 : H12AffineFastState.Bounded env18711 := by
  intro p hp
  have h : env18711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18710_18711 : H12AffineEnvironment.transform 4 0 env18710 = env18711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18710 == env18711) = true)

def env18712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180361,95496,8328,64,4486528,185737,45524,262280,143761,4338885,257,21792,46212,202310]

theorem envBound18712 : H12AffineFastState.Bounded env18712 := by
  intro p hp
  have h : env18712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18678_18712 : H12AffineEnvironment.transform 22 180361 env18678 = env18712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env18678 == env18712) = true)

def env18713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180361,95496,8328,64,23808,185737,45524,262280,143761,400453,257,21792,46212,202310]

theorem envBound18713 : H12AffineFastState.Bounded env18713 := by
  intro p hp
  have h : env18713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18712_18713 : H12AffineEnvironment.transform 21 272512 env18712 = env18713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18712 == env18713) = true)

def env18714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272392,180225,95496,8192,64,23808,185601,45404,262144,143641,400453,257,21792,46092,202310]

theorem envBound18714 : H12AffineFastState.Bounded env18714 := by
  intro p hp
  have h : env18714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18713_18714 : H12AffineEnvironment.transform 6 8 env18713 = env18714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18713 == env18714) = true)

def env18715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,17,95496,8192,64,23808,5393,45404,262144,61705,318549,257,21792,46092,120406]

theorem envBound18715 : H12AffineFastState.Bounded env18715 := by
  intro p hp
  have h : env18715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18714_18715 : H12AffineEnvironment.transform 16 49168 env18714 = env18715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18714 == env18715) = true)

theorem identity18715 : scanCanonicalize (H12AffineFastState.compose env18715 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound18715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89378,1025,32769,58396,95530,17,95496,8192,64,23808,5393,45404,89378,61705,98679,257,21792,46092,120406]

theorem envBound18716 : H12AffineFastState.Bounded env18716 := by
  intro p hp
  have h : env18716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18715_18716 : H12AffineEnvironment.transform 17 89378 env18715 = env18716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env18715 == env18716) = true)

theorem identity18716 : scanCanonicalize (H12AffineFastState.compose env18716 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound18716 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,46441,75867,1025,32769,37221,65619,17,65649,8192,64,10361,5393,45404,75867,33904,98679,257,8281,46092,107311]

theorem envBound18717 : H12AffineFastState.Bounded env18717 := by
  intro p hp
  have h : env18717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18716_18717 : H12AffineEnvironment.transform 13 13689 env18716 = env18717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env18716 == env18717) = true)

theorem identity18717 : scanCanonicalize (H12AffineFastState.compose env18717 (packedSelected [7,14,16,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18717 : packedSelected [7,14,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8461,65536,5220,75867,1025,8460,12392,65619,17,65649,8192,64,10361,5393,4177,75867,9597,73850,257,8281,5377,66082]

theorem envBound18718 : H12AffineFastState.Bounded env18718 := by
  intro p hp
  have h : env18718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18717_18718 : H12AffineEnvironment.transform 14 8461 env18717 = env18718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env18717 == env18718) = true)

theorem identity18718 : scanCanonicalize (H12AffineFastState.compose env18718 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound18718 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5456,292,65536,5220,67698,1025,293,4161,65619,17,65649,41,64,2128,5393,4177,67698,1364,65619,257,112,5377,66082]

theorem envBound18719 : H12AffineFastState.Bounded env18719 := by
  intro p hp
  have h : env18719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18718_18719 : H12AffineEnvironment.transform 12 41 env18718 = env18719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18718 == env18719) = true)

theorem identity18719 : scanCanonicalize (H12AffineFastState.compose env18719 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18719 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env18720 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,292,65536,5172,67618,1025,293,4113,65539,17,65569,41,16,2048,5393,4097,67618,1284,65539,257,32,5377,66082]

theorem envBound18720 : H12AffineFastState.Bounded env18720 := by
  intro p hp
  have h : env18720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18719_18720 : H12AffineEnvironment.transform 5 16 env18719 = env18720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18719 == env18720) = true)

theorem identity18720 : scanCanonicalize (H12AffineFastState.compose env18720 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18720 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18721 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,292,35,5172,2049,1025,293,4113,32,17,2,41,16,2048,5393,4097,2049,1284,32,257,32,5377,513]

theorem envBound18721 : H12AffineFastState.Bounded env18721 := by
  intro p hp
  have h : env18721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18720_18721 : H12AffineEnvironment.transform 15 35 env18720 = env18721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18720 == env18721) = true)

theorem identity18721 : scanCanonicalize (H12AffineFastState.compose env18721 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18721 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18722 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,1,35,5172,2049,1025,0,4113,32,17,2,41,16,2048,5172,4097,2049,1057,32,36,32,5156,513]

theorem envBound18722 : H12AffineFastState.Bounded env18722 := by
  intro p hp
  have h : env18722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18721_18722 : H12AffineEnvironment.transform 7 37 env18721 = env18722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18721 == env18722) = true)

theorem identity18722 : scanCanonicalize (H12AffineFastState.compose env18722 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18722 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18723 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4113,1,35,4096,2049,53,0,4113,32,17,2,41,16,2048,4096,4097,2049,21,32,36,32,4112,513]

theorem envBound18723 : H12AffineFastState.Bounded env18723 := by
  intro p hp
  have h : env18723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18722_18723 : H12AffineEnvironment.transform 9 52 env18722 = env18723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18722 == env18723) = true)

theorem identity18723 : scanCanonicalize (H12AffineFastState.compose env18723 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound18723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18724 : List Nat := [2,4,8,16,32,16,8,37,36,52,2048,4096,41,4113,1,35,4096,2049,53,0,4113,32,17,2,41,16,2048,4096,4097,2049,21,32,36,32,4112,37]

theorem envBound18724 : H12AffineFastState.Bounded env18724 := by
  intro p hp
  have h : env18724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18723_18724 : H12AffineEnvironment.transform 8 36 env18723 = env18724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env18723 == env18724) = true)

theorem identity18724 : scanCanonicalize (H12AffineFastState.compose env18724 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 25) := by decide +kernel

theorem selectedBound18724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18725 : List Nat := [2,4,8,16,32,16,8,37,36,52,2048,25,41,8,1,35,25,2049,53,0,8,32,17,2,41,16,2048,25,24,2049,21,32,36,32,9,37]

theorem envBound18725 : H12AffineFastState.Bounded env18725 := by
  intro p hp
  have h : env18725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18724_18725 : H12AffineEnvironment.transform 11 25 env18724 = env18725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 25 env18724 == env18725) = true)

theorem identity18725 : scanCanonicalize (H12AffineFastState.compose env18725 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 47) := by decide +kernel

theorem selectedBound18725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18726 : List Nat := [2,4,8,16,32,16,8,37,36,52,47,25,41,8,1,35,25,46,53,0,8,32,17,2,41,16,47,25,24,46,21,32,36,32,9,37]

theorem envBound18726 : H12AffineFastState.Bounded env18726 := by
  intro p hp
  have h : env18726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18725_18726 : H12AffineEnvironment.transform 10 47 env18725 = env18726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 47 env18725 == env18726) = true)

theorem identity18726 : scanCanonicalize (H12AffineFastState.compose env18726 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18726 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18727 : List Nat := [2,4,8,16,1,16,8,4,5,21,14,25,8,8,1,2,25,15,20,0,8,1,17,2,8,16,14,25,24,15,21,1,5,1,9,4]

theorem envBound18727 : H12AffineFastState.Bounded env18727 := by
  intro p hp
  have h : env18727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18726_18727 : H12AffineEnvironment.transform 4 1 env18726 = env18727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18726 == env18727) = true)

theorem identity18727 : scanCanonicalize (H12AffineFastState.compose env18727 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound18727 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18728 : List Nat := [2,4,0,16,1,16,0,4,5,21,6,17,0,0,1,2,17,7,20,0,0,1,17,2,0,16,6,17,16,7,21,1,5,1,1,4]

theorem envBound18728 : H12AffineFastState.Bounded env18728 := by
  intro p hp
  have h : env18728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18727_18728 : H12AffineEnvironment.transform 2 0 env18727 = env18728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env18727 == env18728) = true)

theorem identity18728 : scanCanonicalize (H12AffineFastState.compose env18728 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound18728 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18729 : List Nat := [2,3,0,16,1,16,0,3,2,18,1,17,0,0,1,2,17,0,19,0,0,1,17,2,0,16,1,17,16,0,18,1,2,1,1,3]

theorem envBound18729 : H12AffineFastState.Bounded env18729 := by
  intro p hp
  have h : env18729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18728_18729 : H12AffineEnvironment.transform 1 3 env18728 = env18729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env18728 == env18729) = true)

def env18730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,16,95496,8192,64,23808,5392,45404,262144,61704,318548,257,21792,46092,120407]

theorem envBound18730 : H12AffineFastState.Bounded env18730 := by
  intro p hp
  have h : env18730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18714_18730 : H12AffineEnvironment.transform 16 49169 env18714 = env18730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18714 == env18730) = true)

theorem identity18730 : scanCanonicalize (H12AffineFastState.compose env18730 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound18730 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49169,262144,1025,32769,58397,272392,16,2,8192,64,23808,5392,45404,262144,61704,318548,257,21792,46092,41821]

theorem envBound18731 : H12AffineFastState.Bounded env18731 := by
  intro p hp
  have h : env18731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18730_18731 : H12AffineEnvironment.transform 15 29962 env18730 = env18731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env18730 == env18731) = true)

theorem identity18731 : scanCanonicalize (H12AffineFastState.compose env18731 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound18731 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env18732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49169,35109,1025,32769,58397,41261,16,2,8192,64,23808,5392,45404,35109,61704,21873,257,21792,46092,41821]

theorem envBound18732 : H12AffineFastState.Bounded env18732 := by
  intro p hp
  have h : env18732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18731_18732 : H12AffineEnvironment.transform 17 35109 env18731 = env18732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env18731 == env18732) = true)

theorem identity18732 : scanCanonicalize (H12AffineFastState.compose env18732 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound18732 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env18733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,35,46392,35109,1025,32769,37172,41261,16,2,8192,64,10281,5392,45404,35109,33825,8280,257,8201,46092,41821]

theorem envBound18733 : H12AffineFastState.Bounded env18733 := by
  intro p hp
  have h : env18733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18732_18733 : H12AffineEnvironment.transform 13 13609 env18732 = env18733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env18732 == env18733) = true)

theorem identity18733 : scanCanonicalize (H12AffineFastState.compose env18733 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound18733 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env18734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,80,35,13672,2421,1025,81,4452,8573,16,2,8192,64,10281,5392,12556,2421,1137,8280,257,8201,13404,8973]

theorem envBound18734 : H12AffineFastState.Bounded env18734 := by
  intro p hp
  have h : env18734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18733_18734 : H12AffineEnvironment.transform 14 80 env18733 = env18734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env18733 == env18734) = true)

theorem identity18734 : scanCanonicalize (H12AffineFastState.compose env18734 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18734 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5157,80,35,5220,2421,1025,81,4452,113,16,2,268,64,2341,5392,4096,2421,1137,340,257,261,5456,513]

theorem envBound18735 : H12AffineFastState.Bounded env18735 := by
  intro p hp
  have h : env18735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18734_18735 : H12AffineEnvironment.transform 12 268 env18734 = env18735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18734 == env18735) = true)

theorem identity18735 : scanCanonicalize (H12AffineFastState.compose env18735 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18735 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18736 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,1,35,5173,2340,1025,0,4405,32,16,2,268,17,2341,5392,4096,2340,1056,261,257,261,5377,513]

theorem envBound18736 : H12AffineFastState.Bounded env18736 := by
  intro p hp
  have h : env18736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18735_18736 : H12AffineEnvironment.transform 5 17 env18735 = env18736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18735 == env18736) = true)

theorem identity18736 : scanCanonicalize (H12AffineFastState.compose env18736 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18736 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18737 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4404,1,35,4388,2340,272,0,4405,32,16,2,268,17,2341,4097,4096,2340,305,261,257,261,4112,513]

theorem envBound18737 : H12AffineFastState.Bounded env18737 := by
  intro p hp
  have h : env18737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18736_18737 : H12AffineEnvironment.transform 9 273 env18736 = env18737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18736 == env18737) = true)

def env18738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272393,180224,95496,8193,64,23808,185600,45405,262145,143640,400453,257,21792,46093,202310]

theorem envBound18738 : H12AffineFastState.Bounded env18738 := by
  intro p hp
  have h : env18738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18713_18738 : H12AffineEnvironment.transform 6 9 env18713 = env18738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18713 == env18738) = true)

def env18739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,16,95496,8193,64,23808,5392,45405,262145,61704,318549,257,21792,46093,120406]

theorem envBound18739 : H12AffineFastState.Bounded env18739 := by
  intro p hp
  have h : env18739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18738_18739 : H12AffineEnvironment.transform 16 49168 env18738 = env18739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18738 == env18739) = true)

theorem identity18739 : scanCanonicalize (H12AffineFastState.compose env18739 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound18739 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1025,32769,58396,272393,16,41311,8193,64,23808,5392,45405,262145,61704,318549,257,21792,46093,513]

theorem envBound18740 : H12AffineFastState.Bounded env18740 := by
  intro p hp
  have h : env18740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18739_18740 : H12AffineEnvironment.transform 15 54359 env18739 = env18740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env18739 == env18740) = true)

theorem identity18740 : scanCanonicalize (H12AffineFastState.compose env18740 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18740 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,46157,262144,1025,32769,36929,272393,16,41311,8193,64,10589,5392,45405,262145,34133,305160,257,8573,46093,513]

theorem envBound18741 : H12AffineFastState.Bounded env18741 := by
  intro p hp
  have h : env18741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18740_18741 : H12AffineEnvironment.transform 13 13405 env18740 = env18741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18740 == env18741) = true)

theorem identity18741 : scanCanonicalize (H12AffineFastState.compose env18741 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18741 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33111,38160,262144,1025,32769,36929,264532,16,32770,348,64,2048,5392,36864,262145,34133,297301,257,32,38224,513]

theorem envBound18742 : H12AffineFastState.Bounded env18742 := by
  intro p hp
  have h : env18742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18741_18742 : H12AffineEnvironment.transform 12 349 env18741 = env18742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18741 == env18742) = true)

theorem identity18742 : scanCanonicalize (H12AffineFastState.compose env18742 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound18742 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33111,38160,2420,1025,32769,36929,32,16,32770,348,64,2048,5392,36864,2421,34133,32801,257,32,38224,513]

theorem envBound18743 : H12AffineFastState.Bounded env18743 := by
  intro p hp
  have h : env18743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18742_18743 : H12AffineEnvironment.transform 17 2420 env18742 = env18743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env18742 == env18743) = true)

theorem identity18743 : scanCanonicalize (H12AffineFastState.compose env18743 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18743 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18744 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4112,32768,33111,36864,2420,273,32769,36929,32,16,32770,348,64,2048,4096,36864,2421,32837,32801,257,32,36928,513]

theorem envBound18744 : H12AffineFastState.Bounded env18744 := by
  intro p hp
  have h : env18744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18743_18744 : H12AffineEnvironment.transform 9 272 env18743 = env18744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18743 == env18744) = true)

theorem identity18744 : scanCanonicalize (H12AffineFastState.compose env18744 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2128) := by decide +kernel

theorem selectedBound18744 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18745 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4112,2128,2311,6224,2420,273,2129,6161,32,16,2130,348,64,2048,4096,6224,2421,2069,2161,257,32,6160,513]

theorem envBound18745 : H12AffineFastState.Bounded env18745 := by
  intro p hp
  have h : env18745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18744_18745 : H12AffineEnvironment.transform 14 2128 env18744 = env18745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2128 env18744 == env18745) = true)

theorem identity18745 : scanCanonicalize (H12AffineFastState.compose env18745 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18745 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env18746 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,41,4112,2128,2163,6224,2048,101,2129,6161,32,16,2130,40,64,2048,4096,6224,2049,2069,2161,117,32,6160,513]

theorem envBound18746 : H12AffineFastState.Bounded env18746 := by
  intro p hp
  have h : env18746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18745_18746 : H12AffineEnvironment.transform 7 116 env18745 = env18746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18745 == env18746) = true)

theorem identity18746 : scanCanonicalize (H12AffineFastState.compose env18746 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 2641) := by decide +kernel

theorem selectedBound18746 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env18747 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2641,41,2625,2128,2163,513,2048,101,2129,576,32,16,2130,40,64,2048,2641,513,2049,2069,2161,117,32,577,513]

theorem envBound18747 : H12AffineFastState.Bounded env18747 := by
  intro p hp
  have h : env18747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18746_18747 : H12AffineEnvironment.transform 11 2641 env18746 = env18747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2641 env18746 == env18747) = true)

theorem identity18747 : scanCanonicalize (H12AffineFastState.compose env18747 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18747 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18748 : List Nat := [2,4,8,16,32,64,9,116,17,100,2048,2112,41,2128,2128,2163,16,2048,101,2129,81,32,16,2130,40,64,2048,2112,16,2049,2069,2161,117,32,80,16]

theorem envBound18748 : H12AffineFastState.Bounded env18748 := by
  intro p hp
  have h : env18748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18747_18748 : H12AffineEnvironment.transform 8 17 env18747 = env18748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18747 == env18748) = true)

theorem identity18748 : scanCanonicalize (H12AffineFastState.compose env18748 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound18748 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18749 : List Nat := [2,4,8,16,32,64,9,116,17,100,80,16,41,0,0,35,16,80,101,1,81,32,16,2,40,64,80,16,16,81,69,33,117,32,80,16]

theorem envBound18749 : H12AffineFastState.Bounded env18749 := by
  intro p hp
  have h : env18749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18748_18749 : H12AffineEnvironment.transform 10 80 env18748 = env18749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env18748 == env18749) = true)

def env18750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,17,95496,8193,64,23808,5393,45405,262145,61705,318548,257,21792,46093,120407]

theorem envBound18750 : H12AffineFastState.Bounded env18750 := by
  intro p hp
  have h : env18750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18738_18750 : H12AffineEnvironment.transform 16 49169 env18738 = env18750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18738 == env18750) = true)

theorem identity18750 : scanCanonicalize (H12AffineFastState.compose env18750 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound18750 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1025,32769,58397,119927,17,95496,8193,64,23808,5393,45405,130175,61705,73770,257,21792,46093,120407]

theorem envBound18751 : H12AffineFastState.Bounded env18751 := by
  intro p hp
  have h : env18751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18750_18751 : H12AffineEnvironment.transform 17 130174 env18750 = env18751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env18750 == env18751) = true)

theorem identity18751 : scanCanonicalize (H12AffineFastState.compose env18751 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18751 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env18752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,16400,97407,1025,0,25628,87158,17,95496,8193,64,23808,5393,12636,97406,28936,73770,257,21792,13324,87638]

theorem envBound18752 : H12AffineFastState.Bounded env18752 := by
  intro p hp
  have h : env18752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18751_18752 : H12AffineEnvironment.transform 14 1 env18751 = env18752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18751 == env18752) = true)

theorem identity18752 : scanCanonicalize (H12AffineFastState.compose env18752 (packedSelected [0,1,3,5,7,8,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound18752 : packedSelected [0,1,3,5,7,8,14,15,23] rootPS < 2^1333 := by decide +kernel

def env18753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,65536,13341,67698,1025,0,4113,73851,17,65797,8193,64,10509,5393,12636,67699,1285,73770,257,8493,13324,74331]

theorem envBound18753 : H12AffineFastState.Bounded env18753 := by
  intro p hp
  have h : env18753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18752_18753 : H12AffineEnvironment.transform 13 13325 env18752 = env18753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env18752 == env18753) = true)

theorem identity18753 : scanCanonicalize (H12AffineFastState.compose env18753 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18753 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18754 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,65536,13341,67618,1025,0,4113,73771,17,65797,8193,16,10509,5393,12556,67619,1285,73770,257,8493,13324,74251]

theorem envBound18754 : H12AffineFastState.Bounded env18754 := by
  intro p hp
  have h : env18754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18753_18754 : H12AffineEnvironment.transform 5 16 env18753 = env18754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18753 == env18754) = true)

theorem identity18754 : scanCanonicalize (H12AffineFastState.compose env18754 (packedSelected [0,3,4,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 15167) := by decide +kernel

theorem selectedBound18754 : packedSelected [0,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env18755 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,15167,13341,13085,1025,0,4113,6932,17,14906,8193,16,10509,5393,12556,13084,1285,6933,257,8493,13324,6452]

theorem envBound18755 : H12AffineFastState.Bounded env18755 := by
  intro p hp
  have h : env18755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18754_18755 : H12AffineEnvironment.transform 15 15167 env18754 = env18755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15167 env18754 == env18755) = true)

theorem identity18755 : scanCanonicalize (H12AffineFastState.compose env18755 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18755 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18756 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,6707,5393,4625,1025,0,4113,6932,17,6966,269,16,2049,5393,4096,4624,1285,6933,257,33,5376,6452]

theorem envBound18756 : H12AffineFastState.Bounded env18756 := by
  intro p hp
  have h : env18756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18755_18756 : H12AffineEnvironment.transform 12 268 env18755 = env18756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18755 == env18756) = true)

theorem identity18756 : scanCanonicalize (H12AffineFastState.compose env18756 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18756 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env18757 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,268,309,1,3591,293,1573,1025,0,1061,3872,17,3842,269,16,2049,293,1076,1572,1285,3873,257,33,308,3328]

theorem envBound18757 : H12AffineFastState.Bounded env18757 := by
  intro p hp
  have h : env18757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18756_18757 : H12AffineEnvironment.transform 11 1076 env18756 = env18757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env18756 == env18757) = true)

theorem identity18757 : scanCanonicalize (H12AffineFastState.compose env18757 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound18757 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env18758 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1076,268,309,1,774,293,1573,1025,0,1061,545,17,515,269,16,1280,293,1076,1572,1285,544,257,33,308,1]

theorem envBound18758 : H12AffineFastState.Bounded env18758 := by
  intro p hp
  have h : env18758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18757_18758 : H12AffineEnvironment.transform 10 1281 env18757 = env18758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env18757 == env18758) = true)

theorem identity18758 : scanCanonicalize (H12AffineFastState.compose env18758 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18758 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18759 : List Nat := [2,4,8,16,32,16,9,256,512,273,16,293,268,309,1,774,293,820,272,0,308,545,17,515,269,16,17,293,293,821,20,544,257,33,308,1]

theorem envBound18759 : H12AffineFastState.Bounded env18759 := by
  intro p hp
  have h : env18759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18758_18759 : H12AffineEnvironment.transform 9 273 env18758 = env18759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18758 == env18759) = true)

theorem identity18759 : scanCanonicalize (H12AffineFastState.compose env18759 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18759 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env18760 : List Nat := [2,4,8,16,32,16,9,256,0,273,16,293,268,309,1,262,293,308,272,0,308,33,17,3,269,16,17,293,293,309,20,32,257,33,308,1]

theorem envBound18760 : H12AffineFastState.Bounded env18760 := by
  intro p hp
  have h : env18760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18759_18760 : H12AffineEnvironment.transform 8 0 env18759 = env18760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18759 == env18760) = true)

theorem identity18760 : scanCanonicalize (H12AffineFastState.compose env18760 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18760 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18761 : List Nat := [2,4,8,16,17,16,9,256,0,273,16,276,268,260,1,262,276,261,272,0,261,16,17,3,269,16,17,276,276,260,20,17,257,16,261,1]

theorem envBound18761 : H12AffineFastState.Bounded env18761 := by
  intro p hp
  have h : env18761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18760_18761 : H12AffineEnvironment.transform 4 17 env18760 = env18761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18760 == env18761) = true)

theorem identity18761 : scanCanonicalize (H12AffineFastState.compose env18761 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18761 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env18762 : List Nat := [2,4,8,16,17,16,9,20,0,5,16,0,24,16,1,18,0,17,4,0,17,16,17,3,25,16,17,0,0,16,20,17,21,16,17,1]

theorem envBound18762 : H12AffineFastState.Bounded env18762 := by
  intro p hp
  have h : env18762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18761_18762 : H12AffineEnvironment.transform 7 20 env18761 = env18762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18761 == env18762) = true)

def env18763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180361,95496,8328,64,23809,185737,45524,262280,143761,400452,257,21792,46212,202310]

theorem envBound18763 : H12AffineFastState.Bounded env18763 := by
  intro p hp
  have h : env18763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18712_18763 : H12AffineEnvironment.transform 21 272513 env18712 = env18763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18712 == env18763) = true)

theorem identity18763 : scanCanonicalize (H12AffineFastState.compose env18763 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound18763 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58516,272513,17,95496,8328,64,23809,5393,45524,262280,61705,318684,257,21792,46212,120542]

theorem envBound18764 : H12AffineFastState.Bounded env18764 := by
  intro p hp
  have h : env18764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18763_18764 : H12AffineEnvironment.transform 16 49304 env18763 = env18764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env18763 == env18764) = true)

def env18765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,17,95496,8192,64,23809,5393,45404,262144,61705,318548,257,21792,46092,120406]

theorem envBound18765 : H12AffineFastState.Bounded env18765 := by
  intro p hp
  have h : env18765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18764_18765 : H12AffineEnvironment.transform 6 8 env18764 = env18765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18764 == env18765) = true)

theorem identity18765 : scanCanonicalize (H12AffineFastState.compose env18765 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound18765 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89378,1025,32769,58396,95531,17,95496,8192,64,23809,5393,45404,89378,61705,98678,257,21792,46092,120406]

theorem envBound18766 : H12AffineFastState.Bounded env18766 := by
  intro p hp
  have h : env18766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18765_18766 : H12AffineEnvironment.transform 17 89378 env18765 = env18766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env18765 == env18766) = true)

theorem identity18766 : scanCanonicalize (H12AffineFastState.compose env18766 (packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound18766 : packedSelected [0,1,4,5,12,14,15,16,19,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21620,65536,5220,89378,1025,21621,12392,95531,17,95496,8192,64,23809,5393,25896,89378,9597,87298,257,21792,24696,66082]

theorem envBound18767 : H12AffineFastState.Bounded env18767 := by
  intro p hp
  have h : env18767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18766_18767 : H12AffineEnvironment.transform 14 21620 env18766 = env18767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env18766 == env18767) = true)

theorem identity18767 : scanCanonicalize (H12AffineFastState.compose env18767 (packedSelected [2,4,6,7,11,14,18,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18767 : packedSelected [2,4,6,7,11,14,18,22,27] rootPS < 2^1333 := by decide +kernel

def env18768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21620,65536,5220,89378,1025,21621,4160,87299,17,87328,40,64,23809,5393,17664,89378,1365,87298,257,21792,16464,66082]

theorem envBound18768 : H12AffineFastState.Bounded env18768 := by
  intro p hp
  have h : env18768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18767_18768 : H12AffineEnvironment.transform 12 40 env18767 = env18768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18767 == env18768) = true)

theorem identity18768 : scanCanonicalize (H12AffineFastState.compose env18768 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound18768 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env18769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21620,21794,5220,2048,1025,21621,4160,33,17,2,40,64,23809,5393,17664,2048,1365,32,257,21792,16464,22272]

theorem envBound18769 : H12AffineFastState.Bounded env18769 := by
  intro p hp
  have h : env18769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18768_18769 : H12AffineEnvironment.transform 15 21794 env18768 = env18769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env18768 == env18769) = true)

theorem identity18769 : scanCanonicalize (H12AffineFastState.compose env18769 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18769 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env18770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,372,34,5220,2048,1025,373,4160,33,17,2,40,64,2049,5393,4096,2048,1365,32,257,32,5456,512]

theorem envBound18770 : H12AffineFastState.Bounded env18770 := by
  intro p hp
  have h : env18770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18769_18770 : H12AffineEnvironment.transform 13 5376 env18769 = env18770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18769 == env18770) = true)

theorem identity18770 : scanCanonicalize (H12AffineFastState.compose env18770 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18770 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18771 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,40,5376,261,34,5141,2048,1025,260,4145,33,17,2,40,49,2049,5393,4096,2048,1316,32,257,32,5409,512]

theorem envBound18771 : H12AffineFastState.Bounded env18771 := by
  intro p hp
  have h : env18771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18770_18771 : H12AffineEnvironment.transform 5 49 env18770 = env18771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18770 == env18771) = true)

theorem identity18771 : scanCanonicalize (H12AffineFastState.compose env18771 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound18771 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18772 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,1028,40,260,261,34,17,2048,1025,260,1077,33,17,2,40,49,2049,277,1028,2048,1316,32,257,32,293,512]

theorem envBound18772 : H12AffineFastState.Bounded env18772 := by
  intro p hp
  have h : env18772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18771_18772 : H12AffineEnvironment.transform 11 1028 env18771 = env18772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env18771 == env18772) = true)

theorem identity18772 : scanCanonicalize (H12AffineFastState.compose env18772 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound18772 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18773 : List Nat := [2,4,8,16,32,49,8,256,512,1024,513,1028,40,260,261,34,17,513,1025,260,1077,33,17,2,40,49,512,277,1028,513,1316,32,257,32,293,512]

theorem envBound18773 : H12AffineFastState.Bounded env18773 := by
  intro p hp
  have h : env18773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18772_18773 : H12AffineEnvironment.transform 10 513 env18772 = env18773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env18772 == env18773) = true)

theorem identity18773 : scanCanonicalize (H12AffineFastState.compose env18773 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18773 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env18774 : List Nat := [2,4,8,16,32,49,8,36,512,1024,513,1028,40,32,33,34,17,513,1025,32,1077,33,17,2,40,49,512,49,1028,513,1024,32,37,32,1,512]

theorem envBound18774 : H12AffineFastState.Bounded env18774 := by
  intro p hp
  have h : env18774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18773_18774 : H12AffineEnvironment.transform 7 36 env18773 = env18774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18773 == env18774) = true)

theorem identity18774 : scanCanonicalize (H12AffineFastState.compose env18774 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18774 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18775 : List Nat := [2,4,8,16,32,49,8,36,17,1024,16,1028,40,32,33,34,17,16,1025,32,1077,33,17,2,40,49,17,49,1028,16,1024,32,37,32,1,17]

theorem envBound18775 : H12AffineFastState.Bounded env18775 := by
  intro p hp
  have h : env18775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18774_18775 : H12AffineEnvironment.transform 8 17 env18774 = env18775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18774 == env18775) = true)

theorem identity18775 : scanCanonicalize (H12AffineFastState.compose env18775 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18775 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18776 : List Nat := [2,4,8,16,1,16,8,5,17,1024,16,1028,9,1,0,3,17,16,1025,1,1044,0,17,2,9,16,17,16,1028,16,1024,1,4,1,1,17]

theorem envBound18776 : H12AffineFastState.Bounded env18776 := by
  intro p hp
  have h : env18776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18775_18776 : H12AffineEnvironment.transform 4 1 env18775 = env18776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18775 == env18776) = true)

theorem identity18776 : scanCanonicalize (H12AffineFastState.compose env18776 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound18776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18777 : List Nat := [2,4,8,5,1,5,8,5,4,1024,5,1028,9,1,0,3,4,5,1025,1,1025,0,4,2,9,5,4,5,1028,5,1024,1,4,1,1,4]

theorem envBound18777 : H12AffineFastState.Bounded env18777 := by
  intro p hp
  have h : env18777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18776_18777 : H12AffineEnvironment.transform 3 5 env18776 = env18777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env18776 == env18777) = true)

theorem identity18777 : scanCanonicalize (H12AffineFastState.compose env18777 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound18777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18778 : List Nat := [2,4,8,5,1,5,8,5,4,0,5,4,9,1,0,3,4,5,1,1,1,0,4,2,9,5,4,5,4,5,0,1,4,1,1,4]

theorem envBound18778 : H12AffineFastState.Bounded env18778 := by
  intro p hp
  have h : env18778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18777_18778 : H12AffineEnvironment.transform 9 0 env18777 = env18778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env18777 == env18778) = true)

theorem identity18778 : scanCanonicalize (H12AffineFastState.compose env18778 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound18778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18779 : List Nat := [2,4,5,5,1,5,5,5,4,0,5,4,4,1,0,3,4,5,1,1,1,0,4,2,4,5,4,5,4,5,0,1,4,1,1,4]

theorem envBound18779 : H12AffineFastState.Bounded env18779 := by
  intro p hp
  have h : env18779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18778_18779 : H12AffineEnvironment.transform 2 5 env18778 = env18779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env18778 == env18779) = true)

theorem identity18779 : scanCanonicalize (H12AffineFastState.compose env18779 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound18779 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18780 : List Nat := [2,2,3,3,1,3,3,3,2,0,3,2,2,1,0,3,2,3,1,1,1,0,2,2,2,3,2,3,2,3,0,1,2,1,1,2]

theorem envBound18780 : H12AffineFastState.Bounded env18780 := by
  intro p hp
  have h : env18780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18779_18780 : H12AffineEnvironment.transform 1 2 env18779 = env18780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env18779 == env18780) = true)

theorem identity18780 : scanCanonicalize (H12AffineFastState.compose env18780 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound18780 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18781 : List Nat := [1,1,0,0,1,0,0,0,1,0,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1,0,1,0,1,0,0,1,1,1,1,1]

theorem envBound18781 : H12AffineFastState.Bounded env18781 := by
  intro p hp
  have h : env18781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18780_18781 : H12AffineEnvironment.transform 0 1 env18780 = env18781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env18780 == env18781) = true)

def env18782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,17,95496,8193,64,23809,5393,45405,262145,61705,318549,257,21792,46093,120407]

theorem envBound18782 : H12AffineFastState.Bounded env18782 := by
  intro p hp
  have h : env18782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18764_18782 : H12AffineEnvironment.transform 6 9 env18764 = env18782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18764 == env18782) = true)

theorem identity18782 : scanCanonicalize (H12AffineFastState.compose env18782 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound18782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1025,32769,58397,119926,17,95496,8193,64,23809,5393,45405,130175,61705,73771,257,21792,46093,120407]

theorem envBound18783 : H12AffineFastState.Bounded env18783 := by
  intro p hp
  have h : env18783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18782_18783 : H12AffineEnvironment.transform 17 130174 env18782 = env18783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env18782 == env18783) = true)

theorem identity18783 : scanCanonicalize (H12AffineFastState.compose env18783 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound18783 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env18784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,49169,43048,1025,32769,58397,32800,17,8542,8193,64,23809,5393,45405,43049,61705,29821,257,21792,46093,33281]

theorem envBound18784 : H12AffineFastState.Bounded env18784 := by
  intro p hp
  have h : env18784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18783_18784 : H12AffineEnvironment.transform 15 21590 env18783 = env18784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env18783 == env18784) = true)

theorem identity18784 : scanCanonicalize (H12AffineFastState.compose env18784 (packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18784 : packedSelected [0,3,4,5,7,9,11,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env18785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,8282,46109,43048,1025,32769,36881,32800,17,8542,8193,64,10509,5393,45405,43049,34053,113,257,8492,46093,33281]

theorem envBound18785 : H12AffineFastState.Bounded env18785 := by
  intro p hp
  have h : env18785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18784_18785 : H12AffineEnvironment.transform 13 13324 env18784 = env18785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18784 == env18785) = true)

theorem identity18785 : scanCanonicalize (H12AffineFastState.compose env18785 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18785 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,8282,5393,2340,1025,8461,12573,8492,17,8542,8193,64,10509,5393,4177,2341,9225,113,257,8492,5377,8973]

theorem envBound18786 : H12AffineFastState.Bounded env18786 := by
  intro p hp
  have h : env18786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18785_18786 : H12AffineEnvironment.transform 14 8460 env18785 = env18786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18785 == env18786) = true)

theorem identity18786 : scanCanonicalize (H12AffineFastState.compose env18786 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18786 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,343,5393,2340,1025,0,4112,33,17,83,268,64,2048,5393,4177,2341,1284,113,257,33,5377,512]

theorem envBound18787 : H12AffineFastState.Bounded env18787 := by
  intro p hp
  have h : env18787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18786_18787 : H12AffineEnvironment.transform 12 269 env18786 = env18787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18786 == env18787) = true)

theorem identity18787 : scanCanonicalize (H12AffineFastState.compose env18787 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18788 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,269,5377,1,343,5393,2309,1025,0,4112,0,17,83,268,64,2048,5393,4177,2308,1284,80,257,0,5377,512]

theorem envBound18788 : H12AffineFastState.Bounded env18788 := by
  intro p hp
  have h : env18788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18787_18788 : H12AffineEnvironment.transform 4 1 env18787 = env18788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18787 == env18788) = true)

theorem identity18788 : scanCanonicalize (H12AffineFastState.compose env18788 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18788 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18789 : List Nat := [2,4,8,16,1,64,9,256,512,272,2048,4096,269,4113,1,343,4097,2309,273,0,4112,0,17,83,268,64,2048,4097,4177,2308,20,80,257,0,4113,512]

theorem envBound18789 : H12AffineFastState.Bounded env18789 := by
  intro p hp
  have h : env18789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18788_18789 : H12AffineEnvironment.transform 9 272 env18788 = env18789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18788 == env18789) = true)

theorem identity18789 : scanCanonicalize (H12AffineFastState.compose env18789 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound18789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18790 : List Nat := [2,4,8,16,1,64,9,256,512,272,341,4096,269,4113,1,343,4097,80,273,0,4112,0,17,83,268,64,341,4097,4177,81,20,80,257,0,4113,512]

theorem envBound18790 : H12AffineFastState.Bounded env18790 := by
  intro p hp
  have h : env18790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18789_18790 : H12AffineEnvironment.transform 10 341 env18789 = env18790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env18789 == env18790) = true)

theorem identity18790 : scanCanonicalize (H12AffineFastState.compose env18790 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18790 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18791 : List Nat := [2,4,8,16,1,64,9,256,512,272,341,17,269,0,1,343,16,80,273,0,1,0,17,83,268,64,341,16,64,81,20,80,257,0,0,512]

theorem envBound18791 : H12AffineFastState.Bounded env18791 := by
  intro p hp
  have h : env18791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18790_18791 : H12AffineEnvironment.transform 11 17 env18790 = env18791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18790 == env18791) = true)

theorem identity18791 : scanCanonicalize (H12AffineFastState.compose env18791 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18791 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18792 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,17,269,0,1,262,16,1,273,0,1,0,17,2,268,17,260,16,17,0,20,1,257,0,0,512]

theorem envBound18792 : H12AffineFastState.Bounded env18792 := by
  intro p hp
  have h : env18792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18791_18792 : H12AffineEnvironment.transform 5 17 env18791 = env18792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18791 == env18792) = true)

theorem identity18792 : scanCanonicalize (H12AffineFastState.compose env18792 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18793 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,17,8,0,1,3,16,1,20,0,1,0,17,2,9,17,1,16,17,0,20,1,4,0,0,512]

theorem envBound18793 : H12AffineFastState.Bounded env18793 := by
  intro p hp
  have h : env18793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18792_18793 : H12AffineEnvironment.transform 7 5 env18792 = env18793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18792 == env18793) = true)

theorem identity18793 : scanCanonicalize (H12AffineFastState.compose env18793 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18794 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,17,8,0,1,3,16,1,20,0,1,0,17,2,9,17,1,16,17,0,20,1,4,0,0,1]

theorem envBound18794 : H12AffineFastState.Bounded env18794 := by
  intro p hp
  have h : env18794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18793_18794 : H12AffineEnvironment.transform 8 1 env18793 = env18794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18793 == env18794) = true)

theorem identity18794 : scanCanonicalize (H12AffineFastState.compose env18794 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound18794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18795 : List Nat := [2,4,8,15,1,14,9,5,1,10,1,14,8,0,1,3,15,1,11,0,1,0,14,2,9,14,1,15,14,0,11,1,4,0,0,1]

theorem envBound18795 : H12AffineFastState.Bounded env18795 := by
  intro p hp
  have h : env18795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18794_18795 : H12AffineEnvironment.transform 3 15 env18794 = env18795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env18794 == env18795) = true)

def env18796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound18796 : H12AffineFastState.Bounded env18796 := by
  intro p hp
  have h : env18796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18394_18796 : H12AffineEnvironment.transform 26 30393345 env18394 = env18796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env18394 == env18796) = true)

def env18797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound18797 : H12AffineFastState.Bounded env18797 := by
  intro p hp
  have h : env18797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18796_18797 : H12AffineEnvironment.transform 18 1024 env18796 = env18797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18796 == env18797) = true)

theorem identity18797 : scanCanonicalize (H12AffineFastState.compose env18797 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound18797 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21455180,18973836,2159644,418124,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound18798 : H12AffineFastState.Bounded env18798 := by
  intro p hp
  have h : env18798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18797_18798 : H12AffineEnvironment.transform 22 41293 env18797 = env18798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env18797 == env18798) = true)

def env18799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21331968,18973836,2159644,294912,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound18799 : H12AffineFastState.Bounded env18799 := by
  intro p hp
  have h : env18799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18798_18799 : H12AffineEnvironment.transform 16 57676 env18798 = env18799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env18798 == env18799) = true)

def env18800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,16777216,8328,64,21080104,18973836,2159644,43048,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound18800 : H12AffineFastState.Bounded env18800 := by
  intro p hp
  have h : env18800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18799_18800 : H12AffineEnvironment.transform 17 10280 env18799 = env18800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18799 == env18800) = true)

theorem identity18800 : scanCanonicalize (H12AffineFastState.compose env18800 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound18800 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,138,8328,64,4303010,2196486,2159644,43048,75223,6382922,256,2188650,2196686,513]

theorem envBound18801 : H12AffineFastState.Bounded env18801 := by
  intro p hp
  have h : env18801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18800_18801 : H12AffineEnvironment.transform 23 138 env18800 = env18801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env18800 == env18801) = true)

def env18802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302890,2196486,2159644,43048,75103,6382922,256,2188650,2196550,513]

theorem envBound18802 : H12AffineFastState.Bounded env18802 := by
  intro p hp
  have h : env18802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18801_18802 : H12AffineEnvironment.transform 6 8 env18801 = env18802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18801 == env18802) = true)

theorem identity18802 : scanCanonicalize (H12AffineFastState.compose env18802 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound18802 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4204924,2098512,2159644,43048,41993,6349852,256,2155580,2098448,513]

theorem envBound18803 : H12AffineFastState.Bounded env18803 := by
  intro p hp
  have h : env18803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18802_18803 : H12AffineEnvironment.transform 15 33110 env18802 = env18803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env18802 == env18803) = true)

theorem identity18803 : scanCanonicalize (H12AffineFastState.compose env18803 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound18803 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env18804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,5456,4194304,41293,2,8192,64,4204924,4096,57676,43048,41993,4256076,256,61804,4160,513]

theorem envBound18804 : H12AffineFastState.Bounded env18804 := by
  intro p hp
  have h : env18804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18803_18804 : H12AffineEnvironment.transform 20 5456 env18803 = env18804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env18803 == env18804) = true)

theorem identity18804 : scanCanonicalize (H12AffineFastState.compose env18804 (packedSelected [11,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound18804 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env18805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,32768,33110,50512,3124,1024,32769,5456,4194304,34129,2,1052,64,4197728,4096,50512,35892,32789,4248912,256,54640,4160,513]

theorem envBound18805 : H12AffineFastState.Bounded env18805 := by
  intro p hp
  have h : env18805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18804_18805 : H12AffineEnvironment.transform 12 1052 env18804 = env18805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env18804 == env18805) = true)

theorem identity18805 : scanCanonicalize (H12AffineFastState.compose env18805 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound18805 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env18806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,21761,21591,4177,3124,1024,21760,5456,4194304,20560,2,1052,64,4197728,4096,4177,22837,21780,4194385,256,113,4160,513]

theorem envBound18806 : H12AffineFastState.Bounded env18806 := by
  intro p hp
  have h : env18806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18805_18806 : H12AffineEnvironment.transform 14 21761 env18805 = env18806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env18805 == env18806) = true)

theorem identity18806 : scanCanonicalize (H12AffineFastState.compose env18806 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound18806 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env18807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,6161,3344,3142,4177,3124,1024,3345,5456,4194304,2113,2,1052,64,4197728,4096,4177,292,3333,4194385,256,113,4160,513]

theorem envBound18807 : H12AffineFastState.Bounded env18807 := by
  intro p hp
  have h : env18807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18806_18807 : H12AffineEnvironment.transform 13 6161 env18806 = env18807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env18806 == env18807) = true)

theorem identity18807 : scanCanonicalize (H12AffineFastState.compose env18807 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(21+1) ^^^ 4420) := by decide +kernel

theorem selectedBound18807 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env18808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,6161,3344,3142,4177,3124,1024,3345,5456,4420,2113,2,1052,64,7204,4096,4177,292,3333,4373,256,113,4160,513]

theorem envBound18808 : H12AffineFastState.Bounded env18808 := by
  intro p hp
  have h : env18808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18807_18808 : H12AffineEnvironment.transform 21 4420 env18807 = env18808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4420 env18807 == env18808) = true)

theorem identity18808 : scanCanonicalize (H12AffineFastState.compose env18808 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound18808 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,1052,372,3344,3142,2356,3124,1024,3345,3125,2081,2113,2,1052,64,1345,2405,2356,292,3333,2160,256,113,2341,513]

theorem envBound18809 : H12AffineFastState.Bounded env18809 := by
  intro p hp
  have h : env18809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18808_18809 : H12AffineEnvironment.transform 11 2405 env18808 = env18809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env18808 == env18809) = true)

theorem identity18809 : scanCanonicalize (H12AffineFastState.compose env18809 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18809 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,357,1052,372,1296,1094,308,1076,1024,1297,1077,33,65,2,1052,64,1345,357,308,292,1285,112,256,113,293,513]

theorem envBound18810 : H12AffineFastState.Bounded env18810 := by
  intro p hp
  have h : env18810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18809_18810 : H12AffineEnvironment.transform 10 0 env18809 = env18810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18809 == env18810) = true)

theorem identity18810 : scanCanonicalize (H12AffineFastState.compose env18810 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound18810 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18811 : List Nat := [2,4,8,16,32,64,8,256,512,321,0,357,349,372,81,263,308,373,321,80,372,33,65,2,349,64,0,357,308,292,68,112,256,113,293,513]

theorem envBound18811 : H12AffineFastState.Bounded env18811 := by
  intro p hp
  have h : env18811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18810_18811 : H12AffineEnvironment.transform 9 321 env18810 = env18811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env18810 == env18811) = true)

theorem identity18811 : scanCanonicalize (H12AffineFastState.compose env18811 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound18811 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18812 : List Nat := [2,4,8,16,32,1,8,256,512,256,0,292,284,309,16,263,308,308,256,17,309,33,0,2,284,1,0,292,308,292,5,49,256,48,293,513]

theorem envBound18812 : H12AffineFastState.Bounded env18812 := by
  intro p hp
  have h : env18812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18811_18812 : H12AffineEnvironment.transform 5 1 env18811 = env18812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env18811 == env18812) = true)

theorem identity18812 : scanCanonicalize (H12AffineFastState.compose env18812 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound18812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18813 : List Nat := [2,4,8,16,32,1,8,256,293,256,0,292,284,309,16,263,308,308,256,17,309,33,0,2,284,1,0,292,308,292,5,49,256,48,293,292]

theorem envBound18813 : H12AffineFastState.Bounded env18813 := by
  intro p hp
  have h : env18813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18812_18813 : H12AffineEnvironment.transform 8 293 env18812 = env18813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env18812 == env18813) = true)

theorem identity18813 : scanCanonicalize (H12AffineFastState.compose env18813 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18814 : List Nat := [2,4,8,16,16,1,8,256,277,256,0,276,284,261,16,263,260,260,256,17,261,17,0,2,284,1,0,276,260,276,5,1,256,0,277,276]

theorem envBound18814 : H12AffineFastState.Bounded env18814 := by
  intro p hp
  have h : env18814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18813_18814 : H12AffineEnvironment.transform 4 16 env18813 = env18814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18813 == env18814) = true)

def env18815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,3,8193,64,4302891,2196486,2159644,43048,75102,6382922,256,2188650,2196551,513]

theorem envBound18815 : H12AffineFastState.Bounded env18815 := by
  intro p hp
  have h : env18815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18801_18815 : H12AffineEnvironment.transform 6 9 env18801 = env18815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18801 == env18815) = true)

theorem identity18815 : scanCanonicalize (H12AffineFastState.compose env18815 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 50496) := by decide +kernel

theorem selectedBound18815 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env18816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,50496,4194304,41293,3,8193,64,4302891,82246,12636,43048,75102,4300810,256,106538,82183,513]

theorem envBound18816 : H12AffineFastState.Bounded env18816 := by
  intro p hp
  have h : env18816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18815_18816 : H12AffineEnvironment.transform 20 50496 env18815 = env18816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50496 env18815 == env18816) = true)

theorem identity18816 : scanCanonicalize (H12AffineFastState.compose env18816 (packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound18816 : packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS < 2^1333 := by decide +kernel

def env18817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57676,10280,1024,32769,50496,4194304,41293,3,8193,64,4237693,16400,12636,43048,9224,4235612,256,41340,16465,513]

theorem envBound18817 : H12AffineFastState.Bounded env18817 := by
  intro p hp
  have h : env18817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18816_18817 : H12AffineEnvironment.transform 15 342 env18816 = env18817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env18816 == env18817) = true)

theorem identity18817 : scanCanonicalize (H12AffineFastState.compose env18817 (packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound18817 : packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57676,10280,1024,32769,50496,41341,41293,3,8193,64,2048,16400,12636,43048,9224,33,256,41340,16465,513]

theorem envBound18818 : H12AffineFastState.Bounded env18818 := by
  intro p hp
  have h : env18818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18817_18818 : H12AffineEnvironment.transform 21 41341 env18817 = env18818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env18817 == env18818) = true)

theorem identity18818 : scanCanonicalize (H12AffineFastState.compose env18818 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18818 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16401,10280,1024,8540,25629,32,16,3,8193,64,2048,16400,12636,2421,9224,33,256,33,16465,513]

theorem envBound18819 : H12AffineFastState.Bounded env18819 := by
  intro p hp
  have h : env18819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18818_18819 : H12AffineEnvironment.transform 14 8541 env18818 = env18819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18818 == env18819) = true)

def env18820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41293,16777216,8328,64,21080105,18973836,2159644,43049,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound18820 : H12AffineFastState.Bounded env18820 := by
  intro p hp
  have h : env18820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18799_18820 : H12AffineEnvironment.transform 17 10281 env18799 = env18820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18799 == env18820) = true)

theorem identity18820 : scanCanonicalize (H12AffineFastState.compose env18820 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41431) := by decide +kernel

theorem selectedBound18820 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41293,41431,8328,64,4262398,2172251,2159644,43049,99466,6407191,256,2212919,2172307,41820]

theorem envBound18821 : H12AffineFastState.Bounded env18821 := by
  intro p hp
  have h : env18821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18820_18821 : H12AffineEnvironment.transform 23 41431 env18820 = env18821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41431 env18820 == env18821) = true)

def env18822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41293,41311,8192,64,4262262,2172251,2159644,43049,99330,6407191,256,2212919,2172187,41820]

theorem envBound18822 : H12AffineFastState.Bounded env18822 := by
  intro p hp
  have h : env18822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18821_18822 : H12AffineEnvironment.transform 6 8 env18821 = env18822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18821 == env18822) = true)

theorem identity18822 : scanCanonicalize (H12AffineFastState.compose env18822 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound18822 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env18823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10281,1024,32769,2097152,4194304,41293,41311,8192,64,4229152,2139149,2159644,43049,1364,6309185,256,2114913,2139213,41820]

theorem envBound18823 : H12AffineFastState.Bounded env18823 := by
  intro p hp
  have h : env18823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18822_18823 : H12AffineEnvironment.transform 15 33110 env18822 = env18823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env18822 == env18823) = true)

theorem identity18823 : scanCanonicalize (H12AffineFastState.compose env18823 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound18823 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env18824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10281,1024,32769,2097152,2122860,41293,41311,8192,64,2157644,2139149,2159644,43049,1364,8493,256,2114913,2139213,41820]

theorem envBound18824 : H12AffineFastState.Bounded env18824 := by
  intro p hp
  have h : env18824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18823_18824 : H12AffineEnvironment.transform 21 2122860 env18823 = env18824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env18823 == env18824) = true)

theorem identity18824 : scanCanonicalize (H12AffineFastState.compose env18824 (packedSelected [0,7,9,12,14,15,16,17,22] rootPS)) = affineNative (2^(20+1) ^^^ 49444) := by decide +kernel

theorem selectedBound18824 : packedSelected [0,7,9,12,14,15,16,17,22] rootPS < 2^1333 := by decide +kernel

def env18825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10281,1024,32769,49444,42312,41293,41311,8192,64,11624,25897,13624,43049,1364,8493,256,33861,25961,41820]

theorem envBound18825 : H12AffineFastState.Bounded env18825 := by
  intro p hp
  have h : env18825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18824_18825 : H12AffineEnvironment.transform 20 49444 env18824 = env18825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49444 env18824 == env18825) = true)

theorem identity18825 : scanCanonicalize (H12AffineFastState.compose env18825 (packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound18825 : packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env18826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,262,24860,10281,1024,81,16756,9496,8477,8463,8192,64,11624,25897,13624,10361,1364,8493,256,1045,25961,8972]

theorem envBound18826 : H12AffineFastState.Bounded env18826 := by
  intro p hp
  have h : env18826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18825_18826 : H12AffineEnvironment.transform 14 80 env18825 = env18826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env18825 == env18826) = true)

theorem identity18826 : scanCanonicalize (H12AffineFastState.compose env18826 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound18826 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env18827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12573,80,262,4097,10281,1024,81,12393,9496,8477,8463,8192,64,11624,5172,13624,10361,1364,8493,256,1045,5236,8972]

theorem envBound18827 : H12AffineFastState.Bounded env18827 := by
  intro p hp
  have h : env18827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18826_18827 : H12AffineEnvironment.transform 13 12573 env18826 = env18827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env18826 == env18827) = true)

theorem identity18827 : scanCanonicalize (H12AffineFastState.compose env18827 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18827 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18828 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12573,80,262,4097,10281,52,81,12393,8492,8477,8463,8192,64,10588,4096,12556,10361,352,8493,256,33,4160,8972]

theorem envBound18828 : H12AffineFastState.Bounded env18828 := by
  intro p hp
  have h : env18828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18827_18828 : H12AffineEnvironment.transform 9 52 env18827 = env18828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18827 == env18828) = true)

theorem identity18828 : scanCanonicalize (H12AffineFastState.compose env18828 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound18828 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env18829 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,9,4372,80,262,4097,2080,52,81,4192,293,276,262,9,64,2389,4096,4357,2160,352,292,256,33,4160,773]

theorem envBound18829 : H12AffineFastState.Bounded env18829 := by
  intro p hp
  have h : env18829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18828_18829 : H12AffineEnvironment.transform 12 9 env18828 = env18829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env18828 == env18829) = true)

theorem identity18829 : scanCanonicalize (H12AffineFastState.compose env18829 (packedSelected [3,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound18829 : packedSelected [3,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18830 : List Nat := [2,4,8,16,32,64,8,256,512,52,561,4096,9,4372,80,262,4097,529,52,81,4192,293,276,262,9,64,868,4096,4357,577,352,292,256,33,4160,773]

theorem envBound18830 : H12AffineFastState.Bounded env18830 := by
  intro p hp
  have h : env18830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18829_18830 : H12AffineEnvironment.transform 10 561 env18829 = env18830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env18829 == env18830) = true)

theorem identity18830 : scanCanonicalize (H12AffineFastState.compose env18830 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18830 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env18831 : List Nat := [2,4,8,16,32,64,8,5,512,52,561,4096,9,4113,80,3,4097,529,52,81,4192,32,17,3,9,64,609,4096,4096,577,101,33,5,33,4160,512]

theorem envBound18831 : H12AffineFastState.Bounded env18831 := by
  intro p hp
  have h : env18831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18830_18831 : H12AffineEnvironment.transform 7 5 env18830 = env18831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18830 == env18831) = true)

theorem identity18831 : scanCanonicalize (H12AffineFastState.compose env18831 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound18831 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18832 : List Nat := [2,4,8,16,27,64,8,5,512,15,522,4096,9,4113,80,3,4097,529,15,81,4187,27,17,3,9,64,602,4096,4096,577,94,26,5,26,4160,512]

theorem envBound18832 : H12AffineFastState.Bounded env18832 := by
  intro p hp
  have h : env18832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18831_18832 : H12AffineEnvironment.transform 4 27 env18831 = env18832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env18831 == env18832) = true)

theorem identity18832 : scanCanonicalize (H12AffineFastState.compose env18832 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18832 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18833 : List Nat := [2,4,8,16,27,16,8,5,512,15,522,4096,9,4113,0,3,4097,529,15,1,4107,27,17,3,9,16,522,4096,4096,529,14,26,5,26,4112,512]

theorem envBound18833 : H12AffineFastState.Bounded env18833 := by
  intro p hp
  have h : env18833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18832_18833 : H12AffineEnvironment.transform 5 16 env18832 = env18833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18832 == env18833) = true)

theorem identity18833 : scanCanonicalize (H12AffineFastState.compose env18833 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound18833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18834 : List Nat := [2,4,8,16,27,16,8,5,4,15,14,4096,9,4113,0,3,4097,21,15,1,4107,27,17,3,9,16,14,4096,4096,21,14,26,5,26,4112,4]

theorem envBound18834 : H12AffineFastState.Bounded env18834 := by
  intro p hp
  have h : env18834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18833_18834 : H12AffineEnvironment.transform 8 4 env18833 = env18834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env18833 == env18834) = true)

theorem identity18834 : scanCanonicalize (H12AffineFastState.compose env18834 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 23) := by decide +kernel

theorem selectedBound18834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18835 : List Nat := [2,4,8,16,27,16,8,5,4,15,14,23,9,6,0,3,22,21,15,1,28,27,17,3,9,16,14,23,23,21,14,26,5,26,7,4]

theorem envBound18835 : H12AffineFastState.Bounded env18835 := by
  intro p hp
  have h : env18835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18834_18835 : H12AffineEnvironment.transform 11 23 env18834 = env18835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 23 env18834 == env18835) = true)

theorem identity18835 : scanCanonicalize (H12AffineFastState.compose env18835 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18835 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18836 : List Nat := [2,4,8,0,11,0,8,5,4,15,14,7,9,6,0,3,6,5,15,1,12,11,1,3,9,0,14,7,7,5,14,10,5,10,7,4]

theorem envBound18836 : H12AffineFastState.Bounded env18836 := by
  intro p hp
  have h : env18836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18835_18836 : H12AffineEnvironment.transform 3 0 env18835 = env18836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18835 == env18836) = true)

theorem identity18836 : scanCanonicalize (H12AffineFastState.compose env18836 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18836 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18837 : List Nat := [2,4,3,0,0,0,3,5,4,4,5,7,2,6,0,3,6,5,4,1,7,0,1,3,2,0,5,7,7,5,5,1,5,1,7,4]

theorem envBound18837 : H12AffineFastState.Bounded env18837 := by
  intro p hp
  have h : env18837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18836_18837 : H12AffineEnvironment.transform 2 3 env18836 = env18837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18836 == env18837) = true)

def env18838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41293,41310,8193,64,4262263,2172251,2159644,43049,99331,6407191,256,2212919,2172186,41820]

theorem envBound18838 : H12AffineFastState.Bounded env18838 := by
  intro p hp
  have h : env18838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18821_18838 : H12AffineEnvironment.transform 6 9 env18821 = env18838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18821 == env18838) = true)

theorem identity18838 : scanCanonicalize (H12AffineFastState.compose env18838 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18838 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env18839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57676,10281,1024,32769,2097152,4194304,41293,41310,8193,64,4204924,2098512,2159644,43049,41992,6349852,256,2155580,2098449,41820]

theorem envBound18839 : H12AffineFastState.Bounded env18839 := by
  intro p hp
  have h : env18839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18838_18839 : H12AffineEnvironment.transform 15 8203 env18838 = env18839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18838 == env18839) = true)

theorem identity18839 : scanCanonicalize (H12AffineFastState.compose env18839 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18839 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env18840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45405,10281,1024,32769,2097152,4194304,41293,41310,8193,64,4204924,2098512,2139149,43049,41992,6337549,256,2143277,2098449,41820]

theorem envBound18840 : H12AffineFastState.Bounded env18840 := by
  intro p hp
  have h : env18840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18839_18840 : H12AffineEnvironment.transform 13 4113 env18839 = env18840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env18839 == env18840) = true)

theorem identity18840 : scanCanonicalize (H12AffineFastState.compose env18840 (packedSelected [0,1,3,4,5,7,8,10,11,16,19,20,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 340) := by decide +kernel

theorem selectedBound18840 : packedSelected [0,1,3,4,5,7,8,10,11,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env18841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45405,10281,1024,32769,2097152,340,41293,41310,8193,64,10280,2098512,2139149,43049,41992,2143577,256,2143277,2098449,41820]

theorem envBound18841 : H12AffineFastState.Bounded env18841 := by
  intro p hp
  have h : env18841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18840_18841 : H12AffineEnvironment.transform 21 340 env18840 = env18841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 340 env18840 == env18841) = true)

theorem identity18841 : scanCanonicalize (H12AffineFastState.compose env18841 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound18841 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env18842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,32768,8203,45405,10281,1024,32769,5457,340,41293,41310,8193,64,10280,4097,45404,43049,41992,40968,256,41340,4160,41820]

theorem envBound18842 : H12AffineFastState.Bounded env18842 := by
  intro p hp
  have h : env18842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18841_18842 : H12AffineEnvironment.transform 20 5457 env18841 = env18842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env18841 == env18842) = true)

theorem identity18842 : scanCanonicalize (H12AffineFastState.compose env18842 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound18842 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env18843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8232,8203,4469,10281,1024,8233,5457,340,357,374,8193,64,10280,4097,4468,2049,1056,32,256,340,4160,884]

theorem envBound18843 : H12AffineFastState.Bounded env18843 := by
  intro p hp
  have h : env18843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18842_18843 : H12AffineEnvironment.transform 14 8232 env18842 = env18843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env18842 == env18843) = true)

theorem identity18843 : scanCanonicalize (H12AffineFastState.compose env18843 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound18843 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18844 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,8192,4113,8232,8203,4469,10281,320,8233,4113,340,357,374,8193,64,10280,4097,4468,2049,352,32,256,340,4160,884]

theorem envBound18844 : H12AffineFastState.Bounded env18844 := by
  intro p hp
  have h : env18844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18843_18844 : H12AffineEnvironment.transform 9 320 env18843 = env18844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env18843 == env18844) = true)

theorem identity18844 : scanCanonicalize (H12AffineFastState.compose env18844 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound18844 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18845 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,356,8192,373,8232,8203,17,10281,320,8233,373,340,357,374,8193,64,10280,357,16,2049,352,32,256,340,292,884]

theorem envBound18845 : H12AffineFastState.Bounded env18845 := by
  intro p hp
  have h : env18845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18844_18845 : H12AffineEnvironment.transform 11 356 env18844 = env18845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env18844 == env18845) = true)

theorem identity18845 : scanCanonicalize (H12AffineFastState.compose env18845 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound18845 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18846 : List Nat := [2,4,8,16,32,64,9,256,512,320,80,356,8192,373,8232,8203,17,8313,320,8233,373,340,357,374,8193,64,8312,357,16,81,352,32,256,340,292,884]

theorem envBound18846 : H12AffineFastState.Bounded env18846 := by
  intro p hp
  have h : env18846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18845_18846 : H12AffineEnvironment.transform 10 80 env18845 = env18846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env18845 == env18846) = true)

theorem identity18846 : scanCanonicalize (H12AffineFastState.compose env18846 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18846 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env18847 : List Nat := [2,4,8,16,32,64,9,256,512,320,80,356,348,373,372,343,17,293,320,373,373,340,357,374,349,64,292,357,16,81,352,32,256,340,292,884]

theorem envBound18847 : H12AffineFastState.Bounded env18847 := by
  intro p hp
  have h : env18847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18846_18847 : H12AffineEnvironment.transform 12 348 env18846 = env18847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18846 == env18847) = true)

theorem identity18847 : scanCanonicalize (H12AffineFastState.compose env18847 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound18847 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18848 : List Nat := [2,4,8,16,32,64,9,256,64,320,80,356,348,373,372,343,17,293,320,373,373,340,357,374,349,64,292,357,16,81,352,32,256,340,292,308]

theorem envBound18848 : H12AffineFastState.Bounded env18848 := by
  intro p hp
  have h : env18848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18847_18848 : H12AffineEnvironment.transform 8 64 env18847 = env18848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env18847 == env18848) = true)

theorem identity18848 : scanCanonicalize (H12AffineFastState.compose env18848 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18848 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env18849 : List Nat := [2,4,8,16,32,16,9,256,16,272,0,308,268,293,292,263,17,293,272,293,293,260,309,294,269,16,292,309,16,1,304,32,256,260,292,308]

theorem envBound18849 : H12AffineFastState.Bounded env18849 := by
  intro p hp
  have h : env18849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18848_18849 : H12AffineEnvironment.transform 5 16 env18848 = env18849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18848 == env18849) = true)

theorem identity18849 : scanCanonicalize (H12AffineFastState.compose env18849 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18849 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18850 : List Nat := [2,4,8,16,0,16,9,256,16,272,0,276,268,261,260,263,17,261,272,261,261,260,277,262,269,16,260,277,16,1,272,0,256,260,260,276]

theorem envBound18850 : H12AffineFastState.Bounded env18850 := by
  intro p hp
  have h : env18850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18849_18850 : H12AffineEnvironment.transform 4 0 env18849 = env18850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18849 == env18850) = true)

theorem identity18850 : scanCanonicalize (H12AffineFastState.compose env18850 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18850 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env18851 : List Nat := [2,4,8,16,0,16,9,4,16,20,0,16,8,1,0,3,17,1,20,1,1,0,17,2,9,16,0,17,16,1,20,0,4,0,0,16]

theorem envBound18851 : H12AffineFastState.Bounded env18851 := by
  intro p hp
  have h : env18851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18850_18851 : H12AffineEnvironment.transform 7 4 env18850 = env18851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18850 == env18851) = true)

def env18852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21331969,18973836,2159644,294913,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound18852 : H12AffineFastState.Bounded env18852 := by
  intro p hp
  have h : env18852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18798_18852 : H12AffineEnvironment.transform 16 57677 env18798 = env18852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env18798 == env18852) = true)

theorem identity18852 : scanCanonicalize (H12AffineFastState.compose env18852 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound18852 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41293,138,8328,64,4554891,2196486,2159644,294913,75223,6382922,256,2188650,2196686,513]

theorem envBound18853 : H12AffineFastState.Bounded env18853 := by
  intro p hp
  have h : env18853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18852_18853 : H12AffineEnvironment.transform 23 138 env18852 = env18853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env18852 == env18853) = true)

def env18854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,138,8328,64,4303011,2196486,2159644,43049,75223,6382922,256,2188650,2196686,513]

theorem envBound18854 : H12AffineFastState.Bounded env18854 := by
  intro p hp
  have h : env18854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18853_18854 : H12AffineEnvironment.transform 17 10280 env18853 = env18854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18853 == env18854) = true)

def env18855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302891,2196486,2159644,43049,75103,6382922,256,2188650,2196550,513]

theorem envBound18855 : H12AffineFastState.Bounded env18855 := by
  intro p hp
  have h : env18855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18854_18855 : H12AffineEnvironment.transform 6 8 env18854 = env18855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18854 == env18855) = true)

theorem identity18855 : scanCanonicalize (H12AffineFastState.compose env18855 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound18855 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,2097152,4194304,41293,2,8192,64,4204924,2098513,2159644,43049,41992,6349853,256,2155581,2098449,513]

theorem envBound18856 : H12AffineFastState.Bounded env18856 := by
  intro p hp
  have h : env18856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18855_18856 : H12AffineEnvironment.transform 15 33111 env18855 = env18856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env18855 == env18856) = true)

theorem identity18856 : scanCanonicalize (H12AffineFastState.compose env18856 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18856 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env18857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33111,45405,10280,1024,32769,2097152,4194304,41293,2,8192,64,4204924,2098513,2139148,43049,41992,6337549,256,2143277,2098449,513]

theorem envBound18857 : H12AffineFastState.Bounded env18857 := by
  intro p hp
  have h : env18857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18856_18857 : H12AffineEnvironment.transform 13 4112 env18856 = env18857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env18856 == env18857) = true)

theorem identity18857 : scanCanonicalize (H12AffineFastState.compose env18857 (packedSelected [11,17,23] rootPS)) = affineNative (2^(21+1) ^^^ 9325) := by decide +kernel

theorem selectedBound18857 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env18858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33111,45405,10280,1024,32769,2097152,9325,41293,2,8192,64,3345,2098513,2139148,43049,41992,2134112,256,2143277,2098449,513]

theorem envBound18858 : H12AffineFastState.Bounded env18858 := by
  intro p hp
  have h : env18858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18857_18858 : H12AffineEnvironment.transform 21 9325 env18857 = env18858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9325 env18857 == env18858) = true)

theorem identity18858 : scanCanonicalize (H12AffineFastState.compose env18858 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(20+1) ^^^ 46173) := by decide +kernel

theorem selectedBound18858 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env18859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33111,45405,10280,1024,32769,46173,9325,41293,2,8192,64,3345,45324,4177,43049,41992,9277,256,112,45388,513]

theorem envBound18859 : H12AffineFastState.Bounded env18859 := by
  intro p hp
  have h : env18859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18858_18859 : H12AffineEnvironment.transform 20 46173 env18858 = env18859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46173 env18858 == env18859) = true)

theorem identity18859 : scanCanonicalize (H12AffineFastState.compose env18859 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound18859 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env18860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3100,4112,32768,33111,40257,1076,1024,32769,38977,2161,36177,2,3100,64,3345,40208,4177,33845,34836,2081,256,112,40272,513]

theorem envBound18860 : H12AffineFastState.Bounded env18860 := by
  intro p hp
  have h : env18860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18859_18860 : H12AffineEnvironment.transform 12 3100 env18859 = env18860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env18859 == env18860) = true)

theorem identity18860 : scanCanonicalize (H12AffineFastState.compose env18860 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound18860 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env18861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,3100,3173,32768,33111,33076,1076,1024,32769,33844,2161,36177,2,3100,64,3345,33125,3108,33845,34836,2081,256,112,33061,513]

theorem envBound18861 : H12AffineFastState.Bounded env18861 := by
  intro p hp
  have h : env18861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18860_18861 : H12AffineEnvironment.transform 11 3189 env18860 = env18861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env18860 == env18861) = true)

theorem identity18861 : scanCanonicalize (H12AffineFastState.compose env18861 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound18861 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1060,1101,1076,32768,33111,33076,1076,1024,32769,33844,32,34048,2,1101,64,1344,33125,1141,33845,32837,112,256,112,33061,513]

theorem envBound18862 : H12AffineFastState.Bounded env18862 := by
  intro p hp
  have h : env18862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18861_18862 : H12AffineEnvironment.transform 10 81 env18861 = env18862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env18861 == env18862) = true)

theorem identity18862 : scanCanonicalize (H12AffineFastState.compose env18862 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18862 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18863 : List Nat := [2,4,8,16,32,64,8,116,512,1024,81,1060,1101,1076,32768,32803,32832,1076,1024,32769,33844,32,33908,2,1101,64,1076,32785,1141,33845,32837,112,116,112,32849,513]

theorem envBound18863 : H12AffineFastState.Bounded env18863 := by
  intro p hp
  have h : env18863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18862_18863 : H12AffineEnvironment.transform 7 116 env18862 = env18863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18862 == env18863) = true)

theorem identity18863 : scanCanonicalize (H12AffineFastState.compose env18863 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18863 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env18864 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1060,1053,1076,32768,32803,32784,1076,1024,32769,33844,32,33828,2,1053,16,1076,32785,1061,33845,32789,32,36,32,32769,513]

theorem envBound18864 : H12AffineFastState.Bounded env18864 := by
  intro p hp
  have h : env18864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18863_18864 : H12AffineEnvironment.transform 5 16 env18863 = env18864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18863 == env18864) = true)

theorem identity18864 : scanCanonicalize (H12AffineFastState.compose env18864 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18864 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18865 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1060,1053,1076,1,34,17,1076,1024,0,1077,32,1061,2,1053,16,1076,16,1061,1076,20,32,36,32,0,513]

theorem envBound18865 : H12AffineFastState.Bounded env18865 := by
  intro p hp
  have h : env18865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18864_18865 : H12AffineEnvironment.transform 14 1 env18864 = env18865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18864 == env18865) = true)

theorem identity18865 : scanCanonicalize (H12AffineFastState.compose env18865 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18866 : List Nat := [2,4,8,16,32,16,8,36,512,20,1,48,9,32,1,34,17,32,20,0,33,32,49,2,9,16,32,16,49,32,20,32,36,32,0,513]

theorem envBound18866 : H12AffineFastState.Bounded env18866 := by
  intro p hp
  have h : env18866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18865_18866 : H12AffineEnvironment.transform 9 20 env18865 = env18866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18865 == env18866) = true)

theorem identity18866 : scanCanonicalize (H12AffineFastState.compose env18866 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18867 : List Nat := [2,4,8,0,32,0,8,36,512,4,1,32,9,32,1,34,1,32,4,0,33,32,33,2,9,0,32,0,33,32,4,32,36,32,0,513]

theorem envBound18867 : H12AffineFastState.Bounded env18867 := by
  intro p hp
  have h : env18867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18866_18867 : H12AffineEnvironment.transform 3 0 env18866 = env18867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18866 == env18867) = true)

theorem identity18867 : scanCanonicalize (H12AffineFastState.compose env18867 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18867 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18868 : List Nat := [2,4,8,0,0,0,8,4,512,4,1,0,9,0,1,2,1,0,4,0,1,0,1,2,9,0,0,0,1,0,4,0,4,0,0,513]

theorem envBound18868 : H12AffineFastState.Bounded env18868 := by
  intro p hp
  have h : env18868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18867_18868 : H12AffineEnvironment.transform 4 0 env18867 = env18868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18867 == env18868) = true)

def env18869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,3,8193,64,4302890,2196486,2159644,43049,75102,6382922,256,2188650,2196551,513]

theorem envBound18869 : H12AffineFastState.Bounded env18869 := by
  intro p hp
  have h : env18869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18854_18869 : H12AffineEnvironment.transform 6 9 env18854 = env18869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18854 == env18869) = true)

theorem identity18869 : scanCanonicalize (H12AffineFastState.compose env18869 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound18869 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env18870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,115734,4194304,41293,3,8193,64,4302890,16400,77834,43049,75102,4235612,256,41340,16465,513]

theorem envBound18870 : H12AffineFastState.Bounded env18870 := by
  intro p hp
  have h : env18870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18869_18870 : H12AffineEnvironment.transform 20 115734 env18869 = env18870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env18869 == env18870) = true)

theorem identity18870 : scanCanonicalize (H12AffineFastState.compose env18870 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18870 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env18871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91466,4194304,17,3,8193,64,4262262,16400,77834,2421,75102,4194304,256,32,16465,513]

theorem envBound18871 : H12AffineFastState.Bounded env18871 := by
  intro p hp
  have h : env18871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18870_18871 : H12AffineEnvironment.transform 14 8540 env18870 = env18871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18870 == env18871) = true)

theorem identity18871 : scanCanonicalize (H12AffineFastState.compose env18871 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18871 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1024,8541,17729,4194304,17,3,8193,64,4204925,16400,4097,2421,1365,4194304,256,32,16465,513]

theorem envBound18872 : H12AffineFastState.Bounded env18872 := by
  intro p hp
  have h : env18872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18871_18872 : H12AffineEnvironment.transform 15 8203 env18871 = env18872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18871 == env18872) = true)

theorem identity18872 : scanCanonicalize (H12AffineFastState.compose env18872 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18873 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16401,10280,1024,8460,17680,4194304,17,3,8193,17,4204844,16400,4097,2340,1284,4194304,256,32,16384,513]

theorem envBound18873 : H12AffineFastState.Bounded env18873 := by
  intro p hp
  have h : env18873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18872_18873 : H12AffineEnvironment.transform 5 17 env18872 = env18873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18872 == env18873) = true)

theorem identity18873 : scanCanonicalize (H12AffineFastState.compose env18873 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound18873 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18874 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3101,16384,3344,3094,16401,1077,1024,3345,17680,4194304,17,3,3100,17,4195633,16400,4097,2340,1284,4194304,256,32,16384,513]

theorem envBound18874 : H12AffineFastState.Bounded env18874 := by
  intro p hp
  have h : env18874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18873_18874 : H12AffineEnvironment.transform 12 3101 env18873 = env18874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env18873 == env18874) = true)

theorem identity18874 : scanCanonicalize (H12AffineFastState.compose env18874 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound18874 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18875 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3101,16384,3344,3094,16401,1077,1024,3345,17680,33,17,3,3100,17,1296,16400,4097,2340,1284,33,256,32,16384,513]

theorem envBound18875 : H12AffineFastState.Bounded env18875 := by
  intro p hp
  have h : env18875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18874_18875 : H12AffineEnvironment.transform 21 33 env18874 = env18875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18874 == env18875) = true)

theorem identity18875 : scanCanonicalize (H12AffineFastState.compose env18875 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound18875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18876 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2324,3101,16384,3344,3094,16401,1077,1024,3345,17680,33,17,3,3100,17,1296,16400,2325,2340,1284,33,256,32,16384,513]

theorem envBound18876 : H12AffineFastState.Bounded env18876 := by
  intro p hp
  have h : env18876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18875_18876 : H12AffineEnvironment.transform 11 2324 env18875 = env18876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env18875 == env18876) = true)

theorem identity18876 : scanCanonicalize (H12AffineFastState.compose env18876 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound18876 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18877 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1557,1793,520,16384,773,515,16401,1077,1024,772,17680,33,17,3,521,17,1296,16400,1792,1841,1284,33,256,32,16384,513]

theorem envBound18877 : H12AffineFastState.Bounded env18877 := by
  intro p hp
  have h : env18877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18876_18877 : H12AffineEnvironment.transform 10 1557 env18876 = env18877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env18876 == env18877) = true)

theorem identity18877 : scanCanonicalize (H12AffineFastState.compose env18877 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound18877 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env18878 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1557,1793,520,293,773,515,308,1077,1024,772,1077,33,17,3,521,17,1296,309,1792,1841,1284,33,256,32,293,513]

theorem envBound18878 : H12AffineFastState.Bounded env18878 := by
  intro p hp
  have h : env18878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18877_18878 : H12AffineEnvironment.transform 13 293 env18877 = env18878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env18877 == env18878) = true)

theorem identity18878 : scanCanonicalize (H12AffineFastState.compose env18878 (packedSelected [1,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound18878 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env18879 : List Nat := [2,4,8,16,32,17,9,256,261,1024,1296,1028,269,293,0,262,308,1077,1024,1,1077,33,17,3,268,17,1296,309,1029,1076,1284,33,256,32,293,260]

theorem envBound18879 : H12AffineFastState.Bounded env18879 := by
  intro p hp
  have h : env18879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18878_18879 : H12AffineEnvironment.transform 8 261 env18878 = env18879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env18878 == env18879) = true)

theorem identity18879 : scanCanonicalize (H12AffineFastState.compose env18879 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18880 : List Nat := [2,4,8,16,32,17,9,256,261,53,293,49,269,293,0,262,308,0,53,1,0,33,17,3,268,17,293,309,48,1,305,33,256,32,293,260]

theorem envBound18880 : H12AffineFastState.Bounded env18880 := by
  intro p hp
  have h : env18880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18879_18880 : H12AffineEnvironment.transform 9 53 env18879 = env18880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18879 == env18880) = true)

theorem identity18880 : scanCanonicalize (H12AffineFastState.compose env18880 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18880 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18881 : List Nat := [2,4,8,16,17,17,9,256,261,4,276,0,269,276,0,262,261,0,4,1,0,16,17,3,268,17,276,260,1,1,256,16,256,17,276,260]

theorem envBound18881 : H12AffineFastState.Bounded env18881 := by
  intro p hp
  have h : env18881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18880_18881 : H12AffineEnvironment.transform 4 17 env18880 = env18881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18880 == env18881) = true)

theorem identity18881 : scanCanonicalize (H12AffineFastState.compose env18881 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18882 : List Nat := [2,4,8,16,17,17,9,21,16,4,1,0,24,1,0,19,16,0,4,1,0,16,17,3,25,17,1,17,1,1,21,16,21,17,1,17]

theorem envBound18882 : H12AffineFastState.Bounded env18882 := by
  intro p hp
  have h : env18882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18881_18882 : H12AffineEnvironment.transform 7 21 env18881 = env18882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18881 == env18882) = true)

theorem identity18882 : scanCanonicalize (H12AffineFastState.compose env18882 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18882 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18883 : List Nat := [2,4,8,0,1,1,9,5,0,4,1,0,8,1,0,3,0,0,4,1,0,0,1,3,9,1,1,1,1,1,5,0,5,1,1,1]

theorem envBound18883 : H12AffineFastState.Bounded env18883 := by
  intro p hp
  have h : env18883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18882_18883 : H12AffineEnvironment.transform 3 0 env18882 = env18883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18882 == env18883) = true)

theorem identity18883 : scanCanonicalize (H12AffineFastState.compose env18883 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18884 : List Nat := [2,4,2,0,1,1,3,5,0,4,1,0,2,1,0,3,0,0,4,1,0,0,1,3,3,1,1,1,1,1,5,0,5,1,1,1]

theorem envBound18884 : H12AffineFastState.Bounded env18884 := by
  intro p hp
  have h : env18884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18883_18884 : H12AffineEnvironment.transform 2 2 env18883 = env18884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18883 == env18884) = true)

def env18885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41293,138,8328,64,4303010,2196486,2159644,43048,75223,6382922,256,2188650,2196686,513]

theorem envBound18885 : H12AffineFastState.Bounded env18885 := by
  intro p hp
  have h : env18885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18853_18885 : H12AffineEnvironment.transform 17 10281 env18853 = env18885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18853 == env18885) = true)

theorem identity18885 : scanCanonicalize (H12AffineFastState.compose env18885 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18885 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,2097152,4194304,16,138,8328,64,4262399,2172251,2118977,2421,75223,6382922,256,2188650,2172307,513]

theorem envBound18886 : H12AffineFastState.Bounded env18886 := by
  intro p hp
  have h : env18886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18885_18886 : H12AffineEnvironment.transform 14 8541 env18885 = env18886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18885 == env18886) = true)

theorem identity18886 : scanCanonicalize (H12AffineFastState.compose env18886 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18886 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env18887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,2097152,4194304,16,138,8328,64,4205045,2098513,2118977,2421,1501,6309184,256,2114912,2098585,513]

theorem envBound18887 : H12AffineFastState.Bounded env18887 := by
  intro p hp
  have h : env18887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18886_18887 : H12AffineEnvironment.transform 15 8202 env18886 = env18887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18886 == env18887) = true)

theorem identity18887 : scanCanonicalize (H12AffineFastState.compose env18887 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5592) := by decide +kernel

theorem selectedBound18887 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,5592,4194304,16,138,8328,64,4205045,4233,16537,2421,1501,4214936,256,20664,4161,513]

theorem envBound18888 : H12AffineFastState.Bounded env18888 := by
  intro p hp
  have h : env18888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18887_18888 : H12AffineEnvironment.transform 20 5592 env18887 = env18888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5592 env18887 == env18888) = true)

theorem identity18888 : scanCanonicalize (H12AffineFastState.compose env18888 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 20577) := by decide +kernel

theorem selectedBound18888 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env18889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,5592,20577,16,138,8328,64,31124,4233,16537,2421,1501,249,256,20664,4161,513]

theorem envBound18889 : H12AffineFastState.Bounded env18889 := by
  intro p hp
  have h : env18889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18888_18889 : H12AffineEnvironment.transform 21 20577 env18888 = env18889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20577 env18888 == env18889) = true)

theorem identity18889 : scanCanonicalize (H12AffineFastState.compose env18889 (packedSelected [1,3,4,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 12693) := by decide +kernel

theorem selectedBound18889 : packedSelected [1,3,4,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env18890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12693,8541,8202,12677,10281,1024,8540,5592,8692,16,138,8328,64,2049,4233,12556,2421,1501,249,256,8493,4161,513]

theorem envBound18890 : H12AffineFastState.Bounded env18890 := by
  intro p hp
  have h : env18890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18889_18890 : H12AffineEnvironment.transform 13 12693 env18889 = env18890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12693 env18889 == env18890) = true)

theorem identity18890 : scanCanonicalize (H12AffineFastState.compose env18890 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18890 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env18891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,4296,0,343,4312,2420,1024,1,5592,169,16,138,469,64,2049,4233,4177,2421,1501,249,256,112,4161,513]

theorem envBound18891 : H12AffineFastState.Bounded env18891 := by
  intro p hp
  have h : env18891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18890_18891 : H12AffineEnvironment.transform 12 349 env18890 = env18891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18890 == env18891) = true)

theorem identity18891 : scanCanonicalize (H12AffineFastState.compose env18891 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18891 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env18892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4160,0,343,4176,2420,1024,1,5456,33,16,2,349,64,2049,4097,4177,2421,1365,113,256,112,4161,513]

theorem envBound18892 : H12AffineFastState.Bounded env18892 := by
  intro p hp
  have h : env18892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18891_18892 : H12AffineEnvironment.transform 6 8 env18891 = env18892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18891 == env18892) = true)

theorem identity18892 : scanCanonicalize (H12AffineFastState.compose env18892 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound18892 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,349,2129,0,343,2113,2420,1024,1,3393,33,16,2,349,64,2049,2064,2112,2421,1365,113,256,112,2128,513]

theorem envBound18893 : H12AffineFastState.Bounded env18893 := by
  intro p hp
  have h : env18893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18892_18893 : H12AffineEnvironment.transform 11 2065 env18892 = env18893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env18892 == env18893) = true)

theorem identity18893 : scanCanonicalize (H12AffineFastState.compose env18893 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18893 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18894 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2129,0,343,2113,2420,53,1,2420,33,16,2,349,64,2049,2064,2112,2421,352,113,256,112,2128,513]

theorem envBound18894 : H12AffineFastState.Bounded env18894 := by
  intro p hp
  have h : env18894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18893_18894 : H12AffineEnvironment.transform 9 53 env18893 = env18894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18893 == env18894) = true)

theorem identity18894 : scanCanonicalize (H12AffineFastState.compose env18894 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18894 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18895 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2065,268,2048,0,262,2064,2341,53,1,2341,33,16,2,268,17,2049,2064,2065,2340,305,32,256,33,2049,513]

theorem envBound18895 : H12AffineFastState.Bounded env18895 := by
  intro p hp
  have h : env18895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18894_18895 : H12AffineEnvironment.transform 5 17 env18894 = env18895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18894 == env18895) = true)

theorem identity18895 : scanCanonicalize (H12AffineFastState.compose env18895 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound18895 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18896 : List Nat := [2,4,8,16,32,17,8,256,512,53,302,319,268,302,0,262,318,11,53,1,11,33,16,2,268,17,303,318,319,10,305,32,256,33,303,513]

theorem envBound18896 : H12AffineFastState.Bounded env18896 := by
  intro p hp
  have h : env18896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18895_18896 : H12AffineEnvironment.transform 10 302 env18895 = env18896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env18895 == env18896) = true)

def env18897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound18897 : H12AffineFastState.Bounded env18897 := by
  intro p hp
  have h : env18897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18796_18897 : H12AffineEnvironment.transform 18 1025 env18796 = env18897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18796 == env18897) = true)

theorem identity18897 : scanCanonicalize (H12AffineFastState.compose env18897 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213452) := by decide +kernel

theorem selectedBound18897 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213452,8328,64,12878284,2278721,10507601,8830976,8570332,6431756,257,10650976,10642629,8643083]

theorem envBound18898 : H12AffineFastState.Bounded env18898 := by
  intro p hp
  have h : env18898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18897_18898 : H12AffineEnvironment.transform 23 213452 env18897 = env18898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213452 env18897 == env18898) = true)

def env18899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281536,213452,8328,64,6705548,2278721,165137,2363456,2102684,6431756,257,21792,46213,2175563]

theorem envBound18899 : H12AffineFastState.Bounded env18899 := by
  intro p hp
  have h : env18899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18898_18899 : H12AffineEnvironment.transform 22 2281536 env18898 = env18899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281536 env18898 == env18899) = true)

def env18900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590876,2098513,17665,2363456,2102684,6349852,257,21792,46213,2175563]

theorem envBound18900 : H12AffineFastState.Bounded env18900 := by
  intro p hp
  have h : env18900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18899_18900 : H12AffineEnvironment.transform 16 49168 env18899 = env18900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18899 == env18900) = true)

def env18901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144540,2098513,17665,2363456,2102684,2411676,257,21792,46213,2175563]

theorem envBound18901 : H12AffineFastState.Bounded env18901 := by
  intro p hp
  have h : env18901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18900_18901 : H12AffineEnvironment.transform 21 272512 env18900 = env18901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18900 == env18901) = true)

theorem identity18901 : scanCanonicalize (H12AffineFastState.compose env18901 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound18901 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272512,62660,98780,8328,64,23944,57797,17665,324820,61704,272392,257,21792,46213,120543]

theorem envBound18902 : H12AffineFastState.Bounded env18902 := by
  intro p hp
  have h : env18902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18901_18902 : H12AffineEnvironment.transform 20 58516 env18901 = env18902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env18901 == env18902) = true)

def env18903 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272512,62612,98700,8328,16,23944,57749,17665,324740,61704,272392,257,21792,46213,120463]

theorem envBound18903 : H12AffineFastState.Bounded env18903 := by
  intro p hp
  have h : env18903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18902_18903 : H12AffineEnvironment.transform 5 16 env18902 = env18903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18902 == env18903) = true)

theorem identity18903 : scanCanonicalize (H12AffineFastState.compose env18903 (packedSelected [10,15,17,19,26,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18903 : packedSelected [10,15,17,19,26,31,38] rootPS < 2^1333 := by decide +kernel

def env18904 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58516,168,62612,98700,8328,16,23944,57749,17665,56492,61704,32,257,21792,46213,120463]

theorem envBound18904 : H12AffineFastState.Bounded env18904 := by
  intro p hp
  have h : env18904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18903_18904 : H12AffineEnvironment.transform 17 10280 env18903 = env18904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18903 == env18904) = true)

theorem identity18904 : scanCanonicalize (H12AffineFastState.compose env18904 (packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound18904 : packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env18905 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,13461,10280,1025,29828,4113,168,17,95497,8328,16,23944,5392,17665,10281,1421,32,257,21792,16384,74250]

theorem envBound18905 : H12AffineFastState.Bounded env18905 := by
  intro p hp
  have h : env18905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18904_18905 : H12AffineEnvironment.transform 14 29829 env18904 = env18905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env18904 == env18905) = true)

theorem identity18905 : scanCanonicalize (H12AffineFastState.compose env18905 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound18905 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env18906 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,65536,5393,2476,1025,21760,4113,168,17,87181,268,16,23944,5392,17665,2477,1421,32,257,21792,16384,66446]

theorem envBound18906 : H12AffineFastState.Bounded env18906 := by
  intro p hp
  have h : env18906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18905_18906 : H12AffineEnvironment.transform 12 388 env18905 = env18906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env18905 == env18906) = true)

theorem identity18906 : scanCanonicalize (H12AffineFastState.compose env18906 (packedSelected [2,4,6,11,16,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18906 : packedSelected [2,4,6,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env18907 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,65536,5393,2340,1025,21760,4113,32,17,87045,268,16,23808,5392,17665,2341,1285,32,257,21792,16384,66310]

theorem envBound18907 : H12AffineFastState.Bounded env18907 := by
  intro p hp
  have h : env18907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18906_18907 : H12AffineEnvironment.transform 6 8 env18906 = env18907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18906 == env18907) = true)

theorem identity18907 : scanCanonicalize (H12AffineFastState.compose env18907 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound18907 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18908 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,263,5393,2340,1025,21760,4113,32,17,21762,268,16,23808,5392,17665,2341,1285,32,257,21792,16384,513]

theorem envBound18908 : H12AffineFastState.Bounded env18908 := by
  intro p hp
  have h : env18908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18907_18908 : H12AffineEnvironment.transform 15 263 env18907 = env18908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env18907 == env18908) = true)

theorem identity18908 : scanCanonicalize (H12AffineFastState.compose env18908 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18908 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18909 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1025,0,4113,32,17,2,268,16,2048,5392,4097,2341,1285,32,257,32,5376,513]

theorem envBound18909 : H12AffineFastState.Bounded env18909 := by
  intro p hp
  have h : env18909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18908_18909 : H12AffineEnvironment.transform 13 5376 env18908 = env18909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18908 == env18909) = true)

theorem identity18909 : scanCanonicalize (H12AffineFastState.compose env18909 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound18909 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18910 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,33,268,1313,1,263,1328,2340,1025,0,48,32,17,2,268,16,2048,1329,32,2341,1285,32,257,32,1313,513]

theorem envBound18910 : H12AffineFastState.Bounded env18910 := by
  intro p hp
  have h : env18910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18909_18910 : H12AffineEnvironment.transform 11 33 env18909 = env18910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env18909 == env18910) = true)

theorem identity18910 : scanCanonicalize (H12AffineFastState.compose env18910 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound18910 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18911 : List Nat := [2,4,8,16,32,16,8,256,512,800,2048,33,268,513,1,263,528,2340,801,0,48,32,17,2,268,16,2048,529,32,2341,549,32,257,32,513,513]

theorem envBound18911 : H12AffineFastState.Bounded env18911 := by
  intro p hp
  have h : env18911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18910_18911 : H12AffineEnvironment.transform 9 800 env18910 = env18911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env18910 == env18911) = true)

theorem identity18911 : scanCanonicalize (H12AffineFastState.compose env18911 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound18911 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18912 : List Nat := [2,4,8,16,32,16,8,256,512,800,48,33,268,513,1,263,528,276,801,0,48,32,17,2,268,16,48,529,32,277,549,32,257,32,513,513]

theorem envBound18912 : H12AffineFastState.Bounded env18912 := by
  intro p hp
  have h : env18912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18911_18912 : H12AffineEnvironment.transform 10 48 env18911 = env18912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env18911 == env18912) = true)

theorem identity18912 : scanCanonicalize (H12AffineFastState.compose env18912 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound18912 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18913 : List Nat := [2,4,8,16,32,16,8,256,17,305,48,33,268,16,1,263,1,276,304,0,48,32,17,2,268,16,48,0,32,277,52,32,257,32,16,16]

theorem envBound18913 : H12AffineFastState.Bounded env18913 := by
  intro p hp
  have h : env18913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18912_18913 : H12AffineEnvironment.transform 8 17 env18912 = env18913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env18912 == env18913) = true)

theorem identity18913 : scanCanonicalize (H12AffineFastState.compose env18913 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18913 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18914 : List Nat := [2,4,8,16,32,16,8,21,17,36,48,33,25,16,1,18,1,1,37,0,48,32,17,2,25,16,48,0,32,0,52,32,20,32,16,16]

theorem envBound18914 : H12AffineFastState.Bounded env18914 := by
  intro p hp
  have h : env18914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18913_18914 : H12AffineEnvironment.transform 7 21 env18913 = env18914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18913 == env18914) = true)

theorem identity18914 : scanCanonicalize (H12AffineFastState.compose env18914 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18914 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env18915 : List Nat := [2,4,8,1,32,1,8,4,0,36,33,33,8,1,1,3,1,1,37,0,33,32,0,2,8,1,33,0,32,0,37,32,5,32,1,1]

theorem envBound18915 : H12AffineFastState.Bounded env18915 := by
  intro p hp
  have h : env18915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18914_18915 : H12AffineEnvironment.transform 3 1 env18914 = env18915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18914 == env18915) = true)

theorem identity18915 : scanCanonicalize (H12AffineFastState.compose env18915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18916 : List Nat := [2,4,8,1,1,1,8,4,0,5,0,0,8,1,1,3,1,1,4,0,0,1,0,2,8,1,0,0,1,0,4,1,5,1,1,1]

theorem envBound18916 : H12AffineFastState.Bounded env18916 := by
  intro p hp
  have h : env18916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18915_18916 : H12AffineEnvironment.transform 4 1 env18915 = env18916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18915 == env18916) = true)

theorem identity18916 : scanCanonicalize (H12AffineFastState.compose env18916 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18917 : List Nat := [2,4,2,1,1,1,2,4,0,5,0,0,2,1,1,3,1,1,4,0,0,1,0,2,2,1,0,0,1,0,4,1,5,1,1,1]

theorem envBound18917 : H12AffineFastState.Bounded env18917 := by
  intro p hp
  have h : env18917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18916_18917 : H12AffineEnvironment.transform 2 2 env18916 = env18917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18916 == env18917) = true)

def env18918 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272512,62613,98701,8328,17,23944,57748,17665,324741,61704,272392,257,21792,46213,120462]

theorem envBound18918 : H12AffineFastState.Bounded env18918 := by
  intro p hp
  have h : env18918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18902_18918 : H12AffineEnvironment.transform 5 17 env18902 = env18918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18902 == env18918) = true)

def env18919 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,62493,98565,8192,17,23808,57628,17665,324621,61704,272392,257,21792,46093,120326]

theorem envBound18919 : H12AffineFastState.Bounded env18919 := by
  intro p hp
  have h : env18919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18918_18919 : H12AffineEnvironment.transform 6 8 env18918 = env18919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18918 == env18919) = true)

theorem identity18919 : scanCanonicalize (H12AffineFastState.compose env18919 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound18919 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env18920 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,58396,21792,62493,98565,8192,17,23808,57628,17665,35109,61704,21792,257,21792,46093,120326]

theorem envBound18920 : H12AffineFastState.Bounded env18920 := by
  intro p hp
  have h : env18920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18919_18920 : H12AffineEnvironment.transform 17 32040 env18919 = env18920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env18919 == env18920) = true)

theorem identity18920 : scanCanonicalize (H12AffineFastState.compose env18920 (packedSelected [0,4,7,17,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound18920 : packedSelected [0,4,7,17,19,22,26] rootPS < 2^1333 := by decide +kernel

def env18921 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33031,49168,32040,1025,32769,58396,21792,62493,2,8192,17,23808,57628,17665,35109,61704,21792,257,21792,46093,22273]

theorem envBound18921 : H12AffineFastState.Bounded env18921 := by
  intro p hp
  have h : env18921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18920_18921 : H12AffineEnvironment.transform 15 33031 env18920 = env18921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env18920 == env18921) = true)

theorem identity18921 : scanCanonicalize (H12AffineFastState.compose env18921 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18921 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env18922 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33031,49168,23589,1025,32769,50449,21792,54544,2,269,17,23808,49169,17665,35109,53253,21792,257,21792,38144,22273]

theorem envBound18922 : H12AffineFastState.Bounded env18922 := by
  intro p hp
  have h : env18922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18921_18922 : H12AffineEnvironment.transform 12 269 env18921 = env18922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18921 == env18922) = true)

def env18923 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,62492,98564,8193,17,23809,57629,17665,324620,61704,272392,257,21792,46092,120327]

theorem envBound18923 : H12AffineFastState.Bounded env18923 := by
  intro p hp
  have h : env18923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18918_18923 : H12AffineEnvironment.transform 6 9 env18918 = env18923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18918 == env18923) = true)

theorem identity18923 : scanCanonicalize (H12AffineFastState.compose env18923 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound18923 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env18924 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,97326,1025,32769,58397,87079,62492,98564,8193,17,23809,57629,17665,100386,61704,87078,257,21792,46092,120327]

theorem envBound18924 : H12AffineFastState.Bounded env18924 := by
  intro p hp
  have h : env18924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18923_18924 : H12AffineEnvironment.transform 17 97326 env18923 = env18924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env18923 == env18924) = true)

theorem identity18924 : scanCanonicalize (H12AffineFastState.compose env18924 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound18924 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18925 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,29963,49168,2341,1025,32769,58397,8492,62492,62479,8193,17,23809,57629,17665,64809,61704,8493,257,21792,46092,41740]

theorem envBound18925 : H12AffineFastState.Bounded env18925 := by
  intro p hp
  have h : env18925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18924_18925 : H12AffineEnvironment.transform 15 29963 env18924 = env18925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env18924 == env18925) = true)

theorem identity18925 : scanCanonicalize (H12AffineFastState.compose env18925 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18925 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env18926 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,32768,263,46108,2341,1025,32769,36881,8492,32784,32771,8193,17,10509,38161,12557,35109,34052,8493,257,8492,46092,41740]

theorem envBound18926 : H12AffineFastState.Bounded env18926 := by
  intro p hp
  have h : env18926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18925_18926 : H12AffineEnvironment.transform 13 13324 env18925 = env18926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18925 == env18926) = true)

theorem identity18926 : scanCanonicalize (H12AffineFastState.compose env18926 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound18926 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18927 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,293,263,13625,2341,1025,292,4404,8492,309,294,8193,17,10509,5172,12557,2048,1057,8493,257,8492,13609,8745]

theorem envBound18927 : H12AffineFastState.Bounded env18927 := by
  intro p hp
  have h : env18927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18926_18927 : H12AffineEnvironment.transform 14 293 env18926 = env18927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env18926 == env18927) = true)

def env18928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144541,2098513,17665,2363456,2102684,2411677,257,21792,46213,2175563]

theorem envBound18928 : H12AffineFastState.Bounded env18928 := by
  intro p hp
  have h : env18928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18900_18928 : H12AffineEnvironment.transform 21 272513 env18900 = env18928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18900 == env18928) = true)

theorem identity18928 : scanCanonicalize (H12AffineFastState.compose env18928 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound18928 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,262144,1025,29908,2097152,272513,2101328,95497,8328,64,2117064,2098513,17665,2363456,2102684,2373704,257,21792,16464,2175563]

theorem envBound18929 : H12AffineFastState.Bounded env18929 := by
  intro p hp
  have h : env18929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18928_18929 : H12AffineEnvironment.transform 14 29909 env18928 = env18929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env18928 == env18929) = true)

def env18930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,262144,1025,29788,2097152,272393,2101328,95497,8192,64,2116928,2098513,17665,2363456,2102548,2373704,257,21792,16464,2175563]

theorem envBound18930 : H12AffineFastState.Bounded env18930 := by
  intro p hp
  have h : env18930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18929_18930 : H12AffineEnvironment.transform 6 8 env18929 = env18930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18929 == env18930) = true)

theorem identity18930 : scanCanonicalize (H12AffineFastState.compose env18930 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound18930 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env18931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,2420,1025,29788,2097152,8573,2101328,95497,8192,64,2116928,2098513,17665,2103604,2102548,2109756,257,21792,16464,2175563]

theorem envBound18931 : H12AffineFastState.Bounded env18931 := by
  intro p hp
  have h : env18931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18930_18931 : H12AffineEnvironment.transform 17 2420 env18930 = env18931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env18930 == env18931) = true)

theorem identity18931 : scanCanonicalize (H12AffineFastState.compose env18931 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound18931 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,2420,1025,29788,69910,8573,65862,95497,8192,64,89174,70727,17665,67618,66562,73770,257,21792,16464,9053]

theorem envBound18932 : H12AffineFastState.Bounded env18932 := by
  intro p hp
  have h : env18932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18931_18932 : H12AffineEnvironment.transform 20 69910 env18931 = env18932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env18931 == env18932) = true)

theorem identity18932 : scanCanonicalize (H12AffineFastState.compose env18932 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18932 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env18933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,13389,2420,1025,29788,12572,8573,8524,21763,8192,64,31836,13389,17665,10280,9224,32,257,21792,16464,9053]

theorem envBound18933 : H12AffineFastState.Bounded env18933 := by
  intro p hp
  have h : env18933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18932_18933 : H12AffineEnvironment.transform 15 8202 env18932 = env18933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18932 == env18933) = true)

end H12CloudChart1