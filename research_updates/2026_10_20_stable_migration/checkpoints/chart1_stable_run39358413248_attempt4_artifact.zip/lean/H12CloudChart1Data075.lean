import H12CloudChart1Data074

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity18933 : scanCanonicalize (H12AffineFastState.compose env18933 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18933 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env18934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13389,2420,1025,1,12572,8573,8524,8542,8192,64,2049,13389,12636,10280,9224,32,257,8573,13325,9053]

theorem envBound18934 : H12AffineFastState.Bounded env18934 := by
  intro p hp
  have h : env18934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18933_18934 : H12AffineEnvironment.transform 13 13405 env18933 = env18934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18933 == env18934) = true)

theorem identity18934 : scanCanonicalize (H12AffineFastState.compose env18934 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18934 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env18935 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13389,2389,1025,1,12572,8540,8524,8542,8192,64,2049,13389,12636,10249,9224,1,257,8540,13325,9053]

theorem envBound18935 : H12AffineFastState.Bounded env18935 := by
  intro p hp
  have h : env18935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18934_18935 : H12AffineEnvironment.transform 4 1 env18934 = env18935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18934 == env18935) = true)

theorem identity18935 : scanCanonicalize (H12AffineFastState.compose env18935 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18935 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18936 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5456,0,263,5440,2389,1025,1,4113,81,65,83,269,64,2049,5440,4177,2308,1285,1,257,81,5376,592]

theorem envBound18936 : H12AffineFastState.Bounded env18936 := by
  intro p hp
  have h : env18936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18935_18936 : H12AffineEnvironment.transform 12 269 env18935 = env18936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18935 == env18936) = true)

theorem identity18936 : scanCanonicalize (H12AffineFastState.compose env18936 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18936 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18937 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5376,0,263,5392,2309,1025,1,4113,1,17,3,269,16,2049,5392,4097,2308,1285,1,257,1,5376,512]

theorem envBound18937 : H12AffineFastState.Bounded env18937 := by
  intro p hp
  have h : env18937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18936_18937 : H12AffineEnvironment.transform 5 16 env18936 = env18937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18936 == env18937) = true)

theorem identity18937 : scanCanonicalize (H12AffineFastState.compose env18937 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound18937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18938 : List Nat := [2,4,8,16,1,16,8,256,512,257,2048,4096,269,4097,0,263,4113,2309,256,1,4113,1,17,3,269,16,2049,4113,4097,2308,4,1,257,1,4097,512]

theorem envBound18938 : H12AffineFastState.Bounded env18938 := by
  intro p hp
  have h : env18938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18937_18938 : H12AffineEnvironment.transform 9 257 env18937 = env18938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env18937 == env18938) = true)

theorem identity18938 : scanCanonicalize (H12AffineFastState.compose env18938 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound18938 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18939 : List Nat := [2,4,8,16,1,16,8,256,512,257,271,4096,269,4097,0,263,4113,10,256,1,4113,1,17,3,269,16,270,4113,4097,11,4,1,257,1,4097,512]

theorem envBound18939 : H12AffineFastState.Bounded env18939 := by
  intro p hp
  have h : env18939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18938_18939 : H12AffineEnvironment.transform 10 271 env18938 = env18939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env18938 == env18939) = true)

theorem identity18939 : scanCanonicalize (H12AffineFastState.compose env18939 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 788) := by decide +kernel

theorem selectedBound18939 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18940 : List Nat := [2,4,8,16,1,16,8,256,512,257,271,788,269,789,0,263,773,10,256,1,773,1,17,3,269,16,270,773,789,11,4,1,257,1,789,512]

theorem envBound18940 : H12AffineFastState.Bounded env18940 := by
  intro p hp
  have h : env18940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18939_18940 : H12AffineEnvironment.transform 11 788 env18939 = env18940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 788 env18939 == env18940) = true)

theorem identity18940 : scanCanonicalize (H12AffineFastState.compose env18940 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18940 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18941 : List Nat := [2,4,8,16,1,16,8,256,16,257,271,260,269,261,0,263,277,10,256,1,277,1,17,3,269,16,270,277,261,11,4,1,257,1,261,16]

theorem envBound18941 : H12AffineFastState.Bounded env18941 := by
  intro p hp
  have h : env18941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18940_18941 : H12AffineEnvironment.transform 8 16 env18940 = env18941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18940 == env18941) = true)

theorem identity18941 : scanCanonicalize (H12AffineFastState.compose env18941 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18941 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18942 : List Nat := [2,4,8,16,1,16,8,21,16,20,26,17,24,16,0,18,0,10,21,1,0,1,17,3,24,16,27,0,16,11,4,1,20,1,16,16]

theorem envBound18942 : H12AffineFastState.Bounded env18942 := by
  intro p hp
  have h : env18942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18941_18942 : H12AffineEnvironment.transform 7 21 env18941 = env18942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18941 == env18942) = true)

theorem identity18942 : scanCanonicalize (H12AffineFastState.compose env18942 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound18942 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18943 : List Nat := [2,4,8,8,1,8,8,13,8,12,2,9,0,8,0,10,0,10,13,1,0,1,9,3,0,8,3,0,8,11,4,1,12,1,8,8]

theorem envBound18943 : H12AffineFastState.Bounded env18943 := by
  intro p hp
  have h : env18943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18942_18943 : H12AffineEnvironment.transform 3 8 env18942 = env18943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env18942 == env18943) = true)

theorem identity18943 : scanCanonicalize (H12AffineFastState.compose env18943 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18943 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env18944 : List Nat := [2,4,2,2,1,2,2,7,2,6,2,3,0,2,0,0,0,0,7,1,0,1,3,3,0,2,3,0,2,1,4,1,6,1,2,2]

theorem envBound18944 : H12AffineFastState.Bounded env18944 := by
  intro p hp
  have h : env18944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18943_18944 : H12AffineEnvironment.transform 2 2 env18943 = env18944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18943 == env18944) = true)

theorem identity18944 : scanCanonicalize (H12AffineFastState.compose env18944 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound18944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18945 : List Nat := [2,2,2,2,1,2,2,1,2,0,2,3,0,2,0,0,0,0,1,1,0,1,3,3,0,2,3,0,2,1,2,1,0,1,2,2]

theorem envBound18945 : H12AffineFastState.Bounded env18945 := by
  intro p hp
  have h : env18945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18944_18945 : H12AffineEnvironment.transform 1 2 env18944 = env18945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env18944 == env18945) = true)

theorem identity18945 : scanCanonicalize (H12AffineFastState.compose env18945 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound18945 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18946 : List Nat := [0,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0,1,0,0,1,0,1,0,1,0,0]

theorem envBound18946 : H12AffineFastState.Bounded env18946 := by
  intro p hp
  have h : env18946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18945_18946 : H12AffineEnvironment.transform 0 0 env18945 = env18946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env18945 == env18946) = true)

def env18947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,2097152,272392,2101328,95497,8193,64,2116929,2098513,17665,2363456,2102549,2373704,257,21792,16464,2175563]

theorem envBound18947 : H12AffineFastState.Bounded env18947 := by
  intro p hp
  have h : env18947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18929_18947 : H12AffineEnvironment.transform 6 9 env18929 = env18947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18929 == env18947) = true)

theorem identity18947 : scanCanonicalize (H12AffineFastState.compose env18947 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(20+1) ^^^ 347159) := by decide +kernel

theorem selectedBound18947 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env18948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,347159,272392,351303,95497,8193,64,328022,346438,17665,89175,350466,95327,257,21792,16464,294492]

theorem envBound18948 : H12AffineFastState.Bounded env18948 := by
  intro p hp
  have h : env18948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18947_18948 : H12AffineEnvironment.transform 20 347159 env18947 = env18948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347159 env18947 == env18948) = true)

theorem identity18948 : scanCanonicalize (H12AffineFastState.compose env18948 (packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97546) := by decide +kernel

theorem selectedBound18948 : packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,97546,1025,29789,12573,87298,8525,95497,8193,64,31836,13388,17665,89175,9224,95327,257,21792,16464,66390]

theorem envBound18949 : H12AffineFastState.Bounded env18949 := by
  intro p hp
  have h : env18949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18948_18949 : H12AffineEnvironment.transform 17 97546 env18948 = env18949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97546 env18948 == env18949) = true)

theorem identity18949 : scanCanonicalize (H12AffineFastState.compose env18949 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound18949 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env18950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,13388,10588,1025,29789,12573,340,8525,8543,8193,64,31836,13388,17665,2049,9224,8201,257,21792,16464,22272]

theorem envBound18950 : H12AffineFastState.Bounded env18950 := by
  intro p hp
  have h : env18950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18949_18950 : H12AffineEnvironment.transform 15 21590 env18949 = env18950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env18949 == env18950) = true)

theorem identity18950 : scanCanonicalize (H12AffineFastState.compose env18950 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18950 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env18951 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29788,21590,13388,10281,1025,29789,12392,33,8248,8234,8193,64,31836,13388,17524,2049,9224,8201,116,21589,16464,22133]

theorem envBound18951 : H12AffineFastState.Bounded env18951 := by
  intro p hp
  have h : env18951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18950_18951 : H12AffineEnvironment.transform 7 117 env18950 = env18951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18950 == env18951) = true)

theorem identity18951 : scanCanonicalize (H12AffineFastState.compose env18951 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18951 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env18952 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4113,9293,1095,13388,10281,1025,9292,12392,33,8248,8234,8193,64,11341,13388,5221,2049,9224,8201,116,1092,4161,1636]

theorem envBound18952 : H12AffineFastState.Bounded env18952 := by
  intro p hp
  have h : env18952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18951_18952 : H12AffineEnvironment.transform 13 4113 env18951 = env18952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env18951 == env18952) = true)

theorem identity18952 : scanCanonicalize (H12AffineFastState.compose env18952 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 3084) := by decide +kernel

theorem selectedBound18952 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env18953 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,3084,4113,2113,1095,6208,1061,1025,2112,7268,33,3124,3110,3085,64,65,6208,5221,2049,2052,3077,116,1092,4161,1636]

theorem envBound18953 : H12AffineFastState.Bounded env18953 := by
  intro p hp
  have h : env18953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18952_18953 : H12AffineEnvironment.transform 12 3084 env18952 = env18953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3084 env18952 == env18953) = true)

theorem identity18953 : scanCanonicalize (H12AffineFastState.compose env18953 (packedSelected [1,2,4,6,8,9,10,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound18953 : packedSelected [1,2,4,6,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env18954 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1060,4096,40,4113,1125,1095,5220,1061,1025,1124,4160,33,16,2,41,64,65,5220,5221,1061,1056,33,116,1092,4161,1636]

theorem envBound18954 : H12AffineFastState.Bounded env18954 := by
  intro p hp
  have h : env18954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18953_18954 : H12AffineEnvironment.transform 10 1060 env18953 = env18954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env18953 == env18954) = true)

theorem identity18954 : scanCanonicalize (H12AffineFastState.compose env18954 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound18954 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18955 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1060,113,40,96,1125,1095,1045,1061,1025,1124,49,33,16,2,41,64,65,1045,1044,1061,1056,33,116,1092,48,1636]

theorem envBound18955 : H12AffineFastState.Bounded env18955 := by
  intro p hp
  have h : env18955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18954_18955 : H12AffineEnvironment.transform 11 113 env18954 = env18955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env18954 == env18955) = true)

theorem identity18955 : scanCanonicalize (H12AffineFastState.compose env18955 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18955 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18956 : List Nat := [2,4,8,16,32,49,9,4,512,1024,1060,0,40,17,1044,1078,1045,1061,1025,1045,49,33,16,2,41,49,48,1045,1044,1061,1056,33,5,1077,48,1557]

theorem envBound18956 : H12AffineFastState.Bounded env18956 := by
  intro p hp
  have h : env18956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18955_18956 : H12AffineEnvironment.transform 5 49 env18955 = env18956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18955 == env18956) = true)

theorem identity18956 : scanCanonicalize (H12AffineFastState.compose env18956 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18956 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18957 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1028,0,8,17,1044,1046,1045,1029,1025,1045,17,1,16,2,9,17,16,1045,1044,1029,1024,1,5,1045,16,1557]

theorem envBound18957 : H12AffineFastState.Bounded env18957 := by
  intro p hp
  have h : env18957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18956_18957 : H12AffineEnvironment.transform 4 0 env18956 = env18957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18956 == env18957) = true)

def env18958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590877,2098512,17664,2363456,2102684,6349853,257,21792,46213,2175563]

theorem envBound18958 : H12AffineFastState.Bounded env18958 := by
  intro p hp
  have h : env18958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18899_18958 : H12AffineEnvironment.transform 16 49169 env18899 = env18958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18899 == env18958) = true)

def env18959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144541,2098512,17664,2363456,2102684,2411677,257,21792,46213,2175563]

theorem envBound18959 : H12AffineFastState.Bounded env18959 := by
  intro p hp
  have h : env18959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18958_18959 : H12AffineEnvironment.transform 21 272512 env18958 = env18959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18958 == env18959) = true)

theorem identity18959 : scanCanonicalize (H12AffineFastState.compose env18959 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound18959 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272512,17,98781,8328,64,43357,5392,17664,262144,1500,318685,257,21792,46213,74251]

theorem envBound18960 : H12AffineFastState.Bounded env18960 := by
  intro p hp
  have h : env18960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18959_18960 : H12AffineEnvironment.transform 20 4160 env18959 = env18960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18959 == env18960) = true)

theorem identity18960 : scanCanonicalize (H12AffineFastState.compose env18960 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18960 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272512,17,41431,8328,64,43357,5392,17664,262144,1500,318685,257,21792,46213,513]

theorem envBound18961 : H12AffineFastState.Bounded env18961 := by
  intro p hp
  have h : env18961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18960_18961 : H12AffineEnvironment.transform 15 8202 env18960 = env18961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18960 == env18961) = true)

theorem identity18961 : scanCanonicalize (H12AffineFastState.compose env18961 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound18961 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35325,1025,32769,4160,41341,17,41431,8328,64,43357,5392,17664,35325,1500,21792,257,21792,46213,513]

theorem envBound18962 : H12AffineFastState.Bounded env18962 := by
  intro p hp
  have h : env18962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18961_18962 : H12AffineEnvironment.transform 17 35325 env18961 = env18962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env18961 == env18962) = true)

theorem identity18962 : scanCanonicalize (H12AffineFastState.compose env18962 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18962 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,24909,10401,1025,8541,4160,33,17,139,8328,64,2049,5392,17664,10401,1500,21792,257,21792,5593,513]

theorem envBound18963 : H12AffineFastState.Bounded env18963 := by
  intro p hp
  have h : env18963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18962_18963 : H12AffineEnvironment.transform 14 8540 env18962 = env18963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18962 == env18963) = true)

def env18964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144540,2098512,17664,2363456,2102684,2411676,257,21792,46213,2175563]

theorem envBound18964 : H12AffineFastState.Bounded env18964 := by
  intro p hp
  have h : env18964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18958_18964 : H12AffineEnvironment.transform 21 272513 env18958 = env18964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18958 == env18964) = true)

def env18965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101329,98645,8192,64,2144540,2098512,17664,2363456,2102548,2411540,257,21792,46093,2175563]

theorem envBound18965 : H12AffineFastState.Bounded env18965 := by
  intro p hp
  have h : env18965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18964_18965 : H12AffineEnvironment.transform 6 8 env18964 = env18965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18964 == env18965) = true)

theorem identity18965 : scanCanonicalize (H12AffineFastState.compose env18965 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound18965 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272393,73755,98645,8192,64,100694,79130,17664,335882,75102,392286,257,21792,46093,513]

theorem envBound18966 : H12AffineFastState.Bounded env18966 := by
  intro p hp
  have h : env18966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18965_18966 : H12AffineEnvironment.transform 20 77898 env18965 = env18966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env18965 == env18966) = true)

theorem identity18966 : scanCanonicalize (H12AffineFastState.compose env18966 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound18966 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,77898,41340,73755,98645,8192,64,100694,79130,17664,108927,75102,95531,257,21792,46093,513]

theorem envBound18967 : H12AffineFastState.Bounded env18967 := by
  intro p hp
  have h : env18967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18966_18967 : H12AffineEnvironment.transform 17 35189 env18966 = env18967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env18966 == env18967) = true)

theorem identity18967 : scanCanonicalize (H12AffineFastState.compose env18967 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18967 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env18968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,32040,1025,29788,77898,21793,73755,95496,8192,64,97547,79130,17664,89378,75102,95531,257,21792,16464,513]

theorem envBound18968 : H12AffineFastState.Bounded env18968 := by
  intro p hp
  have h : env18968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18967_18968 : H12AffineEnvironment.transform 14 29789 env18967 = env18968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18967 == env18968) = true)

theorem identity18968 : scanCanonicalize (H12AffineFastState.compose env18968 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound18968 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env18969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,65536,13388,10361,1025,8461,77898,112,73755,73817,8192,64,75866,79130,4177,67699,75102,73850,257,113,5377,513]

theorem envBound18969 : H12AffineFastState.Bounded env18969 := by
  intro p hp
  have h : env18969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18968_18969 : H12AffineEnvironment.transform 13 5457 env18968 = env18969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env18968 == env18969) = true)

theorem identity18969 : scanCanonicalize (H12AffineFastState.compose env18969 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound18969 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env18970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8283,13388,10361,1025,8461,4113,112,64,2,8192,64,2049,5441,4177,10280,1285,33,257,113,5377,513]

theorem envBound18970 : H12AffineFastState.Bounded env18970 := by
  intro p hp
  have h : env18970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18969_18970 : H12AffineEnvironment.transform 15 8283 env18969 = env18970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env18969 == env18970) = true)

theorem identity18970 : scanCanonicalize (H12AffineFastState.compose env18970 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound18970 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env18971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,5457,7284,7459,2356,5377,1025,7285,4113,112,64,2,7544,64,2049,5441,4177,5456,1285,33,257,113,5377,513]

theorem envBound18971 : H12AffineFastState.Bounded env18971 := by
  intro p hp
  have h : env18971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18970_18971 : H12AffineEnvironment.transform 12 7544 env18970 = env18971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env18970 == env18971) = true)

theorem identity18971 : scanCanonicalize (H12AffineFastState.compose env18971 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound18971 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env18972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,1101,3172,1345,1046,2356,3124,1025,1344,2340,112,64,2,1101,64,2049,3188,2404,3173,1285,33,257,113,3124,513]

theorem envBound18972 : H12AffineFastState.Bounded env18972 := by
  intro p hp
  have h : env18972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18971_18972 : H12AffineEnvironment.transform 11 2357 env18971 = env18972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env18971 == env18972) = true)

theorem identity18972 : scanCanonicalize (H12AffineFastState.compose env18972 (packedSelected [2,4,6,9,11,23] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18972 : packedSelected [2,4,6,9,11,23] rootPS < 2^1333 := by decide +kernel

def env18973 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2357,348,2421,80,263,2356,2341,272,81,2340,112,64,2,348,64,2049,2405,2404,2420,20,33,257,113,2341,513]

theorem envBound18973 : H12AffineFastState.Bounded env18973 := by
  intro p hp
  have h : env18973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18972_18973 : H12AffineEnvironment.transform 9 273 env18972 = env18973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18972 == env18973) = true)

def env18974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101329,98644,8193,64,2144540,2098512,17664,2363456,2102549,2411541,257,21792,46092,2175563]

theorem envBound18974 : H12AffineFastState.Bounded env18974 := by
  intro p hp
  have h : env18974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18964_18974 : H12AffineEnvironment.transform 6 9 env18964 = env18974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18964 == env18974) = true)

theorem identity18974 : scanCanonicalize (H12AffineFastState.compose env18974 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18974 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,16401,262144,1025,1,2097152,272392,2101329,65876,8193,64,2111772,2098512,17664,2363456,2102549,2378773,257,21792,13324,2175563]

theorem envBound18975 : H12AffineFastState.Bounded env18975 := by
  intro p hp
  have h : env18975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18974_18975 : H12AffineEnvironment.transform 14 0 env18974 = env18975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18974 == env18975) = true)

theorem identity18975 : scanCanonicalize (H12AffineFastState.compose env18975 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound18975 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env18976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,16401,262144,1025,1,12573,272392,8524,65876,8193,64,2049,13389,17664,270685,9224,294152,257,21792,13324,66390]

theorem envBound18976 : H12AffineFastState.Bounded env18976 := by
  intro p hp
  have h : env18976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18975_18976 : H12AffineEnvironment.transform 20 12573 env18975 = env18976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env18975 == env18976) = true)

theorem identity18976 : scanCanonicalize (H12AffineFastState.compose env18976 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound18976 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env18977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,16401,2421,1025,1,12573,8573,8524,65876,8193,64,2049,13389,17664,10280,9224,29821,257,21792,13324,66390]

theorem envBound18977 : H12AffineFastState.Bounded env18977 := by
  intro p hp
  have h : env18977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18976_18977 : H12AffineEnvironment.transform 17 2421 env18976 = env18977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env18976 == env18977) = true)

theorem identity18977 : scanCanonicalize (H12AffineFastState.compose env18977 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18977 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,343,16401,2421,1025,1,12573,8573,8524,3,8193,64,2049,13389,17664,10280,9224,29821,257,21792,13324,513]

theorem envBound18978 : H12AffineFastState.Bounded env18978 := by
  intro p hp
  have h : env18978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18977_18978 : H12AffineEnvironment.transform 15 343 env18977 = env18978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18977 == env18978) = true)

theorem identity18978 : scanCanonicalize (H12AffineFastState.compose env18978 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18978 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,0,343,4097,2421,1025,1,12573,8573,8524,3,8193,64,2049,13389,5392,10280,9224,9325,257,1328,13324,513]

theorem envBound18979 : H12AffineFastState.Bounded env18979 := by
  intro p hp
  have h : env18979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18978_18979 : H12AffineEnvironment.transform 13 4112 env18978 = env18979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env18978 == env18979) = true)

theorem identity18979 : scanCanonicalize (H12AffineFastState.compose env18979 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound18979 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env18980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4112,0,343,4097,2421,1025,1,5456,1328,1281,3,1100,64,2049,4096,5392,3173,69,32,257,1328,4161,513]

theorem envBound18980 : H12AffineFastState.Bounded env18980 := by
  intro p hp
  have h : env18980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18979_18980 : H12AffineEnvironment.transform 12 1101 env18979 = env18980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env18979 == env18980) = true)

def env18981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281537,213452,8328,64,6705549,2278721,165136,2363457,2102685,6431756,257,21793,46212,2175562]

theorem envBound18981 : H12AffineFastState.Bounded env18981 := by
  intro p hp
  have h : env18981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18898_18981 : H12AffineEnvironment.transform 22 2281537 env18898 = env18981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281537 env18898 == env18981) = true)

def env18982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590877,2098513,17664,2363457,2102685,6349852,257,21793,46212,2175562]

theorem envBound18982 : H12AffineFastState.Bounded env18982 := by
  intro p hp
  have h : env18982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18981_18982 : H12AffineEnvironment.transform 16 49168 env18981 = env18982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18981 == env18982) = true)

def env18983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144541,2098513,17664,2363457,2102685,2411676,257,21793,46212,2175562]

theorem envBound18983 : H12AffineFastState.Bounded env18983 := by
  intro p hp
  have h : env18983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18982_18983 : H12AffineEnvironment.transform 21 272512 env18982 = env18983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18982 == env18983) = true)

theorem identity18983 : scanCanonicalize (H12AffineFastState.compose env18983 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound18983 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49168,262144,1025,32769,2097152,272512,2101329,21763,8328,64,2144541,2098513,17664,2363457,2102685,2411676,257,21793,46212,2156181]

theorem envBound18984 : H12AffineFastState.Bounded env18984 := by
  intro p hp
  have h : env18984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18983_18984 : H12AffineEnvironment.transform 15 54495 env18983 = env18984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env18983 == env18984) = true)

def env18985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1025,32769,2097152,272392,2101329,21763,8192,64,2144541,2098513,17664,2363457,2102549,2411540,257,21793,46092,2156061]

theorem envBound18985 : H12AffineFastState.Bounded env18985 := by
  intro p hp
  have h : env18985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18984_18985 : H12AffineEnvironment.transform 6 8 env18984 = env18985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18984 == env18985) = true)

theorem identity18985 : scanCanonicalize (H12AffineFastState.compose env18985 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 36929) := by decide +kernel

theorem selectedBound18985 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env18986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1025,32769,36929,272392,32784,21763,8192,64,10588,38160,17664,294912,34132,285781,257,21793,46092,30300]

theorem envBound18986 : H12AffineFastState.Bounded env18986 := by
  intro p hp
  have h : env18986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18985_18986 : H12AffineEnvironment.transform 20 36929 env18985 = env18986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36929 env18985 == env18986) = true)

theorem identity18986 : scanCanonicalize (H12AffineFastState.compose env18986 (packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound18986 : packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS < 2^1333 := by decide +kernel

def env18987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,56436,1025,32769,36929,62588,32784,21763,8192,64,10588,38160,17664,23668,34132,32801,257,21793,46092,30300]

theorem envBound18987 : H12AffineFastState.Bounded env18987 := by
  intro p hp
  have h : env18987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18986_18987 : H12AffineEnvironment.transform 17 56436 env18986 = env18987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env18986 == env18987) = true)

theorem identity18987 : scanCanonicalize (H12AffineFastState.compose env18987 (packedSelected [4,8,9,10,12,14,15,16,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18987 : packedSelected [4,8,9,10,12,14,15,16,28] rootPS < 2^1333 := by decide +kernel

def env18988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54359,49168,56436,1025,32769,36929,54641,32784,21763,269,64,2129,38160,17664,23668,34132,32801,257,21793,38145,22353]

theorem envBound18988 : H12AffineFastState.Bounded env18988 := by
  intro p hp
  have h : env18988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18987_18988 : H12AffineEnvironment.transform 12 269 env18987 = env18988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18987 == env18988) = true)

theorem identity18988 : scanCanonicalize (H12AffineFastState.compose env18988 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound18988 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21761,342,5393,2421,1025,21760,17728,112,21777,21763,269,64,2129,16401,17664,23668,20565,21792,257,21793,16384,22353]

theorem envBound18989 : H12AffineFastState.Bounded env18989 := by
  intro p hp
  have h : env18989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18988_18989 : H12AffineEnvironment.transform 14 21761 env18988 = env18989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env18988 == env18989) = true)

theorem identity18989 : scanCanonicalize (H12AffineFastState.compose env18989 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18989 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env18990 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21761,262,5393,2341,1025,21760,17680,32,21777,21763,269,16,2049,16401,17664,23588,20485,21792,257,21793,16384,22273]

theorem envBound18990 : H12AffineFastState.Bounded env18990 := by
  intro p hp
  have h : env18990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18989_18990 : H12AffineEnvironment.transform 5 16 env18989 = env18990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18989 == env18990) = true)

theorem identity18990 : scanCanonicalize (H12AffineFastState.compose env18990 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 7953) := by decide +kernel

theorem selectedBound18990 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env18991 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7953,2576,262,5393,2341,1025,2577,6657,32,2560,2578,269,16,2049,7936,6673,821,3860,2609,257,2608,7953,2064]

theorem envBound18991 : H12AffineFastState.Bounded env18991 := by
  intro p hp
  have h : env18991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18990_18991 : H12AffineEnvironment.transform 13 7953 env18990 = env18991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7953 env18990 == env18991) = true)

theorem identity18991 : scanCanonicalize (H12AffineFastState.compose env18991 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3345) := by decide +kernel

theorem selectedBound18991 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env18992 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3345,269,512,2576,262,2048,2341,1025,2577,1808,32,2560,2578,269,16,2049,529,1792,821,3860,2609,257,2608,512,2064]

theorem envBound18992 : H12AffineFastState.Bounded env18992 := by
  intro p hp
  have h : env18992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18991_18992 : H12AffineEnvironment.transform 11 3345 env18991 = env18992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3345 env18991 == env18992) = true)

theorem identity18992 : scanCanonicalize (H12AffineFastState.compose env18992 (packedSelected [0,1,3,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18992 : packedSelected [0,1,3,6,9] rootPS < 2^1333 := by decide +kernel

def env18993 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3345,269,512,2576,262,2048,2308,1025,2577,1808,1,2560,2578,269,16,2049,529,1792,788,3860,2576,257,2577,512,2064]

theorem envBound18993 : H12AffineFastState.Bounded env18993 := by
  intro p hp
  have h : env18993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18992_18993 : H12AffineEnvironment.transform 4 1 env18992 = env18993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18992 == env18993) = true)

theorem identity18993 : scanCanonicalize (H12AffineFastState.compose env18993 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound18993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18994 : List Nat := [2,4,8,16,1,16,8,256,512,1024,528,1793,269,512,0,262,528,788,1025,1,1808,1,16,2,269,16,529,529,1792,788,1284,0,257,1,512,512]

theorem envBound18994 : H12AffineFastState.Bounded env18994 := by
  intro p hp
  have h : env18994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18993_18994 : H12AffineEnvironment.transform 10 528 env18993 = env18994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env18993 == env18994) = true)

def env18995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272393,2101329,21763,8193,64,2144541,2098513,17664,2363457,2102548,2411541,257,21793,46093,2156060]

theorem envBound18995 : H12AffineFastState.Bounded env18995 := by
  intro p hp
  have h : env18995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18984_18995 : H12AffineEnvironment.transform 6 9 env18984 = env18995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18984 == env18995) = true)

theorem identity18995 : scanCanonicalize (H12AffineFastState.compose env18995 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound18995 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env18996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32803,37989,262144,1025,32769,2097152,272393,2101329,374,8193,64,2144541,2098513,4469,2363457,2102548,2398304,257,340,46093,2142825]

theorem envBound18996 : H12AffineFastState.Bounded env18996 := by
  intro p hp
  have h : env18996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18995_18996 : H12AffineEnvironment.transform 13 5237 env18995 = env18996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env18995 == env18996) = true)

theorem identity18996 : scanCanonicalize (H12AffineFastState.compose env18996 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18996 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env18997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32803,37989,10280,1025,32769,2097152,33,2101329,374,8193,64,2144541,2098513,4469,2111593,2102548,2142280,257,340,46093,2142825]

theorem envBound18997 : H12AffineFastState.Bounded env18997 := by
  intro p hp
  have h : env18997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18996_18997 : H12AffineEnvironment.transform 17 10280 env18996 = env18997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18996 == env18997) = true)

theorem identity18997 : scanCanonicalize (H12AffineFastState.compose env18997 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18997 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18998 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,32803,37989,10280,1025,32769,2097152,33,2101329,3,8193,64,2144360,2098212,4096,2111593,2102369,2142280,116,33,46093,2142825]

theorem envBound18998 : H12AffineFastState.Bounded env18998 := by
  intro p hp
  have h : env18998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18997_18998 : H12AffineEnvironment.transform 7 117 env18997 = env18998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18997 == env18998) = true)

theorem identity18998 : scanCanonicalize (H12AffineFastState.compose env18998 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound18998 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env18999 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,32803,37989,10280,1025,32769,12392,33,8249,3,8193,64,34816,13388,4096,2049,9225,32800,116,33,46093,33281]

theorem envBound18999 : H12AffineFastState.Bounded env18999 := by
  intro p hp
  have h : env18999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18998_18999 : H12AffineEnvironment.transform 20 12392 env18998 = env18999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env18998 == env18999) = true)

theorem identity18999 : scanCanonicalize (H12AffineFastState.compose env18999 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18999 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env19000 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,1,34,5220,10280,1025,0,12392,33,8249,3,8193,64,2049,13388,4096,2049,9225,33,116,33,13324,512]

theorem envBound19000 : H12AffineFastState.Bounded env19000 := by
  intro p hp
  have h : env19000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18999_19000 : H12AffineEnvironment.transform 14 1 env18999 = env19000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18999 == env19000) = true)

theorem identity19000 : scanCanonicalize (H12AffineFastState.compose env19000 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19000 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19001 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,5205,1,2,5188,10248,1025,0,12360,1,8217,3,8193,64,2049,13388,4096,2049,9225,1,84,1,13324,512]

theorem envBound19001 : H12AffineFastState.Bounded env19001 := by
  intro p hp
  have h : env19001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19000_19001 : H12AffineEnvironment.transform 4 0 env19000 = env19001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19000 == env19001) = true)

theorem identity19001 : scanCanonicalize (H12AffineFastState.compose env19001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound19001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19002 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,1,2,5188,2048,1025,0,4160,1,17,3,9,64,2049,5188,4096,2049,1025,1,84,1,5124,512]

theorem envBound19002 : H12AffineFastState.Bounded env19002 := by
  intro p hp
  have h : env19002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19001_19002 : H12AffineEnvironment.transform 12 8 env19001 = env19002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env19001 == env19002) = true)

theorem identity19002 : scanCanonicalize (H12AffineFastState.compose env19002 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound19002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19003 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,8,4112,1,2,4097,2048,68,0,4160,1,17,3,9,64,2049,4097,4096,2049,68,1,84,1,4161,512]

theorem envBound19003 : H12AffineFastState.Bounded env19003 := by
  intro p hp
  have h : env19003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19002_19003 : H12AffineEnvironment.transform 9 69 env19002 = env19003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env19002 == env19003) = true)

theorem identity19003 : scanCanonicalize (H12AffineFastState.compose env19003 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound19003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19004 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,8,1,1,2,16,2048,68,0,81,1,17,3,9,64,2049,16,17,2049,68,1,84,1,80,512]

theorem envBound19004 : H12AffineFastState.Bounded env19004 := by
  intro p hp
  have h : env19004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19003_19004 : H12AffineEnvironment.transform 11 17 env19003 = env19004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19003 == env19004) = true)

theorem identity19004 : scanCanonicalize (H12AffineFastState.compose env19004 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19005 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,17,8,1,1,2,16,2048,20,0,1,1,17,3,9,16,2049,16,17,2049,20,1,4,1,0,512]

theorem envBound19005 : H12AffineFastState.Bounded env19005 := by
  intro p hp
  have h : env19005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19004_19005 : H12AffineEnvironment.transform 5 16 env19004 = env19005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19004 == env19005) = true)

theorem identity19005 : scanCanonicalize (H12AffineFastState.compose env19005 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 527) := by decide +kernel

theorem selectedBound19005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19006 : List Nat := [2,4,8,16,0,16,9,5,512,21,527,17,8,1,1,2,16,527,20,0,1,1,17,3,9,16,526,16,17,526,20,1,4,1,0,512]

theorem envBound19006 : H12AffineFastState.Bounded env19006 := by
  intro p hp
  have h : env19006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19005_19006 : H12AffineEnvironment.transform 10 527 env19005 = env19006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 527 env19005 == env19006) = true)

def env19007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144540,2098513,17664,2363457,2102685,2411677,257,21793,46212,2175562]

theorem envBound19007 : H12AffineFastState.Bounded env19007 := by
  intro p hp
  have h : env19007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18982_19007 : H12AffineEnvironment.transform 21 272513 env18982 = env19007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18982 == env19007) = true)

theorem identity19007 : scanCanonicalize (H12AffineFastState.compose env19007 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound19007 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115871,272513,120014,98780,8328,64,97667,115150,17664,382174,119042,329730,257,21793,46212,63189]

theorem envBound19008 : H12AffineFastState.Bounded env19008 := by
  intro p hp
  have h : env19008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19007_19008 : H12AffineEnvironment.transform 20 115871 env19007 = env19008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env19007 == env19008) = true)

def env19009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115735,272393,119878,98644,8192,64,97547,115014,17664,382038,119042,329730,257,21793,46092,63069]

theorem envBound19009 : H12AffineFastState.Bounded env19009 := by
  intro p hp
  have h : env19009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19008_19009 : H12AffineEnvironment.transform 6 8 env19008 = env19009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19008 == env19009) = true)

theorem identity19009 : scanCanonicalize (H12AffineFastState.compose env19009 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19009 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env19010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,49168,262144,1025,32769,115735,264533,119878,98644,348,64,89175,115014,17664,382038,119042,329730,257,21793,38224,55041]

theorem envBound19010 : H12AffineFastState.Bounded env19010 := by
  intro p hp
  have h : env19010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19009_19010 : H12AffineEnvironment.transform 12 348 env19009 = env19010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19009 == env19010) = true)

theorem identity19010 : scanCanonicalize (H12AffineFastState.compose env19010 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19010 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env19011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,5392,262144,1025,21761,69911,264533,65862,87124,348,64,89175,70726,17664,328022,66562,329730,257,21793,16464,513]

theorem envBound19011 : H12AffineFastState.Bounded env19011 := by
  intro p hp
  have h : env19011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19010_19011 : H12AffineEnvironment.transform 14 21760 env19010 = env19011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19010 == env19011) = true)

theorem identity19011 : scanCanonicalize (H12AffineFastState.compose env19011 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound19011 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env19012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,5392,89379,1025,21761,69911,87158,65862,87124,348,64,89175,70726,17664,23669,66562,21793,257,21793,16464,513]

theorem envBound19012 : H12AffineFastState.Bounded env19012 := by
  intro p hp
  have h : env19012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19011_19012 : H12AffineEnvironment.transform 17 89379 env19011 = env19012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env19011 == env19012) = true)

theorem identity19012 : scanCanonicalize (H12AffineFastState.compose env19012 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19012 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,80,65536,5392,67699,1025,81,69911,65830,65862,65796,348,64,67847,70726,4176,2341,66562,113,257,113,5376,513]

theorem envBound19013 : H12AffineFastState.Bounded env19013 := by
  intro p hp
  have h : env19013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19012_19013 : H12AffineEnvironment.transform 13 5456 env19012 = env19013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19012 == env19013) = true)

theorem identity19013 : scanCanonicalize (H12AffineFastState.compose env19013 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19013 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19014 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,65536,5392,67618,1025,0,69911,65830,65815,65796,269,17,67847,70679,4097,2341,66562,32,257,32,5376,513]

theorem envBound19014 : H12AffineFastState.Bounded env19014 := by
  intro p hp
  have h : env19014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19013_19014 : H12AffineEnvironment.transform 5 17 env19013 = env19014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19013 == env19014) = true)

theorem identity19014 : scanCanonicalize (H12AffineFastState.compose env19014 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound19014 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19015 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4113,32,17,2,269,17,2049,5393,4097,2341,1284,32,257,32,5376,513]

theorem envBound19015 : H12AffineFastState.Bounded env19015 := by
  intro p hp
  have h : env19015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19014_19015 : H12AffineEnvironment.transform 15 262 env19014 = env19015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env19014 == env19015) = true)

theorem identity19015 : scanCanonicalize (H12AffineFastState.compose env19015 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound19015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19016 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,269,309,1,262,292,2340,1025,0,1061,32,17,2,269,17,2049,293,1077,2341,1284,32,257,32,308,513]

theorem envBound19016 : H12AffineFastState.Bounded env19016 := by
  intro p hp
  have h : env19016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19015_19016 : H12AffineEnvironment.transform 11 1076 env19015 = env19016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env19015 == env19016) = true)

theorem identity19016 : scanCanonicalize (H12AffineFastState.compose env19016 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound19016 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19017 : List Nat := [2,4,8,16,32,17,8,256,512,785,2048,805,269,309,1,262,292,2340,784,0,820,32,17,2,269,17,2049,293,804,2341,533,32,257,32,308,513]

theorem envBound19017 : H12AffineFastState.Bounded env19017 := by
  intro p hp
  have h : env19017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19016_19017 : H12AffineEnvironment.transform 9 785 env19016 = env19017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env19016 == env19017) = true)

theorem identity19017 : scanCanonicalize (H12AffineFastState.compose env19017 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound19017 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19018 : List Nat := [2,4,8,16,32,17,8,256,512,785,820,805,269,309,1,262,292,528,784,0,820,32,17,2,269,17,821,293,804,529,533,32,257,32,308,513]

theorem envBound19018 : H12AffineFastState.Bounded env19018 := by
  intro p hp
  have h : env19018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19017_19018 : H12AffineEnvironment.transform 10 820 env19017 = env19018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env19017 == env19018) = true)

def env19019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115734,272392,119879,98645,8193,64,97546,115015,17664,382039,119042,329730,257,21793,46093,63068]

theorem envBound19019 : H12AffineFastState.Bounded env19019 := by
  intro p hp
  have h : env19019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19008_19019 : H12AffineEnvironment.transform 6 9 env19008 = env19019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19008 == env19019) = true)

theorem identity19019 : scanCanonicalize (H12AffineFastState.compose env19019 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound19019 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env19020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62590,49168,262144,1025,32769,12392,272392,8249,29995,8193,64,35188,13625,17664,270377,9596,326780,257,21793,46093,63068]

theorem envBound19020 : H12AffineFastState.Bounded env19020 := by
  intro p hp
  have h : env19020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19019_19020 : H12AffineEnvironment.transform 15 62590 env19019 = env19020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env19019 == env19020) = true)

theorem identity19020 : scanCanonicalize (H12AffineFastState.compose env19020 (packedSelected [0,1,2,4,6,9,11,16,17,18,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound19020 : packedSelected [0,1,2,4,6,9,11,16,17,18,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62590,49168,56576,1025,32769,12392,62728,8249,29995,8193,64,35188,13625,17664,64809,9596,8572,257,21793,46093,63068]

theorem envBound19021 : H12AffineFastState.Bounded env19021 := by
  intro p hp
  have h : env19021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19020_19021 : H12AffineEnvironment.transform 17 56576 env19020 = env19021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env19020 == env19021) = true)

theorem identity19021 : scanCanonicalize (H12AffineFastState.compose env19021 (packedSelected [0,7,9,14,16,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19021 : packedSelected [0,7,9,14,16,17,22] rootPS < 2^1333 := by decide +kernel

def env19022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,34,13388,10588,1025,29789,12392,340,8249,29995,8193,64,32040,13625,17664,2421,9596,8572,257,21793,16465,512]

theorem envBound19022 : H12AffineFastState.Bounded env19022 := by
  intro p hp
  have h : env19022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19021_19022 : H12AffineEnvironment.transform 14 29788 env19021 = env19022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19021 == env19022) = true)

theorem identity19022 : scanCanonicalize (H12AffineFastState.compose env19022 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19022 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env19023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,34,5392,2048,1025,21761,4404,340,357,21623,349,64,23668,5221,17664,2421,1056,32,257,21793,16465,512]

theorem envBound19023 : H12AffineFastState.Bounded env19023 := by
  intro p hp
  have h : env19023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19022_19023 : H12AffineEnvironment.transform 12 348 env19022 = env19023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19022 == env19023) = true)

theorem identity19023 : scanCanonicalize (H12AffineFastState.compose env19023 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound19023 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19024 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,16384,21588,34,5188,2048,1025,21589,4192,0,49,21623,9,64,23668,5221,17492,2081,1056,32,85,21621,16465,512]

theorem envBound19024 : H12AffineFastState.Bounded env19024 := by
  intro p hp
  have h : env19024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19023_19024 : H12AffineEnvironment.transform 7 84 env19023 = env19024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env19023 == env19024) = true)

theorem identity19024 : scanCanonicalize (H12AffineFastState.compose env19024 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound19024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19025 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5236,32,34,5188,2048,1025,33,4192,0,49,3,9,64,2048,5221,4128,2081,1056,32,85,1,5157,512]

theorem envBound19025 : H12AffineFastState.Bounded env19025 := by
  intro p hp
  have h : env19025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19024_19025 : H12AffineEnvironment.transform 13 5236 env19024 = env19025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env19024 == env19025) = true)

theorem identity19025 : scanCanonicalize (H12AffineFastState.compose env19025 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound19025 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env19026 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3134,8,2122,32,34,2170,2048,1025,33,3166,0,49,3,9,64,2048,2139,3102,2081,1056,32,85,1,2075,512]

theorem envBound19026 : H12AffineFastState.Bounded env19026 := by
  intro p hp
  have h : env19026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19025_19026 : H12AffineEnvironment.transform 11 3134 env19025 = env19026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env19025 == env19026) = true)

theorem identity19026 : scanCanonicalize (H12AffineFastState.compose env19026 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 79) := by decide +kernel

theorem selectedBound19026 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env19027 : List Nat := [2,4,8,16,32,64,9,84,512,79,2048,2161,8,2122,32,34,2170,2048,78,33,2065,0,49,3,9,64,2048,2139,2129,2081,111,32,85,1,2075,512]

theorem envBound19027 : H12AffineFastState.Bounded env19027 := by
  intro p hp
  have h : env19027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19026_19027 : H12AffineEnvironment.transform 9 79 env19026 = env19027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 79 env19026 == env19027) = true)

theorem identity19027 : scanCanonicalize (H12AffineFastState.compose env19027 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound19027 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env19028 : List Nat := [2,4,8,16,32,33,9,53,512,46,2048,2064,8,2091,32,34,2075,2048,47,33,2065,0,49,3,9,33,2048,2106,2096,2081,14,32,52,1,2075,512]

theorem envBound19028 : H12AffineFastState.Bounded env19028 := by
  intro p hp
  have h : env19028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19027_19028 : H12AffineEnvironment.transform 5 33 env19027 = env19028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env19027 == env19028) = true)

theorem identity19028 : scanCanonicalize (H12AffineFastState.compose env19028 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19028 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env19029 : List Nat := [2,4,8,16,0,1,9,21,512,14,2048,2064,8,2059,0,2,2075,2048,15,1,2065,0,17,3,9,1,2048,2074,2064,2049,14,0,20,1,2075,512]

theorem envBound19029 : H12AffineFastState.Bounded env19029 := by
  intro p hp
  have h : env19029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19028_19029 : H12AffineEnvironment.transform 4 0 env19028 = env19029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19028 == env19029) = true)

theorem identity19029 : scanCanonicalize (H12AffineFastState.compose env19029 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19030 : List Nat := [2,4,8,0,0,1,9,5,512,14,2048,2048,8,2059,0,2,2059,2048,15,1,2049,0,1,3,9,1,2048,2058,2048,2049,14,0,4,1,2059,512]

theorem envBound19030 : H12AffineFastState.Bounded env19030 := by
  intro p hp
  have h : env19030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19029_19030 : H12AffineEnvironment.transform 3 0 env19029 = env19030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19029 == env19030) = true)

theorem identity19030 : scanCanonicalize (H12AffineFastState.compose env19030 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound19030 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19031 : List Nat := [2,4,8,0,0,1,9,5,512,14,512,512,8,523,0,2,523,512,15,1,513,0,1,3,9,1,512,522,512,513,14,0,4,1,523,512]

theorem envBound19031 : H12AffineFastState.Bounded env19031 := by
  intro p hp
  have h : env19031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19030_19031 : H12AffineEnvironment.transform 10 512 env19030 = env19031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env19030 == env19031) = true)

theorem identity19031 : scanCanonicalize (H12AffineFastState.compose env19031 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound19031 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19032 : List Nat := [2,4,8,0,0,1,9,5,8,14,8,8,8,3,0,2,3,8,15,1,9,0,1,3,9,1,8,2,8,9,14,0,4,1,3,8]

theorem envBound19032 : H12AffineFastState.Bounded env19032 := by
  intro p hp
  have h : env19032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19031_19032 : H12AffineEnvironment.transform 8 8 env19031 = env19032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env19031 == env19032) = true)

theorem identity19032 : scanCanonicalize (H12AffineFastState.compose env19032 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19032 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env19033 : List Nat := [2,4,2,0,0,1,3,5,2,4,2,2,2,3,0,2,3,2,5,1,3,0,1,3,3,1,2,2,2,3,4,0,4,1,3,2]

theorem envBound19033 : H12AffineFastState.Bounded env19033 := by
  intro p hp
  have h : env19033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19032_19033 : H12AffineEnvironment.transform 2 2 env19032 = env19033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19032 == env19033) = true)

theorem identity19033 : scanCanonicalize (H12AffineFastState.compose env19033 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound19033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19034 : List Nat := [2,1,2,0,0,1,3,0,2,1,2,2,2,3,0,2,3,2,0,1,3,0,1,3,3,1,2,2,2,3,1,0,1,1,3,2]

theorem envBound19034 : H12AffineFastState.Bounded env19034 := by
  intro p hp
  have h : env19034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19033_19034 : H12AffineEnvironment.transform 1 1 env19033 = env19034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env19033 == env19034) = true)

def env19035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590876,2098512,17665,2363457,2102685,6349853,257,21793,46212,2175562]

theorem envBound19035 : H12AffineFastState.Bounded env19035 := by
  intro p hp
  have h : env19035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18981_19035 : H12AffineEnvironment.transform 16 49169 env18981 = env19035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18981 == env19035) = true)

def env19036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144540,2098512,17665,2363457,2102685,2411677,257,21793,46212,2175562]

theorem envBound19036 : H12AffineFastState.Bounded env19036 := by
  intro p hp
  have h : env19036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19035_19036 : H12AffineEnvironment.transform 21 272512 env19035 = env19036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19035 == env19036) = true)

theorem identity19036 : scanCanonicalize (H12AffineFastState.compose env19036 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272512,2101328,41431,8328,64,2144540,2098512,17665,2363457,2102685,2411677,257,21793,46212,2101824]

theorem envBound19037 : H12AffineFastState.Bounded env19037 := by
  intro p hp
  have h : env19037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19036_19037 : H12AffineEnvironment.transform 15 8202 env19036 = env19037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19036 == env19037) = true)

theorem identity19037 : scanCanonicalize (H12AffineFastState.compose env19037 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 268732) := by decide +kernel

theorem selectedBound19037 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,268732,272512,264684,41431,8328,64,303264,269548,17665,2557,265249,54561,257,21793,46212,265212]

theorem envBound19038 : H12AffineFastState.Bounded env19038 := by
  intro p hp
  have h : env19038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19037_19038 : H12AffineEnvironment.transform 20 268732 env19037 = env19038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268732 env19037 == env19038) = true)

theorem identity19038 : scanCanonicalize (H12AffineFastState.compose env19038 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound19038 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env19039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35325,1025,32769,36929,41341,32785,41431,8328,64,10589,38161,17665,2557,34268,54561,257,21793,46212,33281]

theorem envBound19039 : H12AffineFastState.Bounded env19039 := by
  intro p hp
  have h : env19039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19038_19039 : H12AffineEnvironment.transform 17 35325 env19038 = env19039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env19038 == env19039) = true)

theorem identity19039 : scanCanonicalize (H12AffineFastState.compose env19039 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound19039 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8202,16537,2421,1025,137,4297,8693,153,8543,8328,64,10589,5529,17665,2557,1364,21929,257,21793,13324,649]

theorem envBound19040 : H12AffineFastState.Bounded env19040 := by
  intro p hp
  have h : env19040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19039_19040 : H12AffineEnvironment.transform 14 136 env19039 = env19040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env19039 == env19040) = true)

theorem identity19040 : scanCanonicalize (H12AffineFastState.compose env19040 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound19040 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,479,16537,2421,1025,137,4297,32,153,138,349,64,2184,5529,17665,2557,1364,21929,257,21793,5593,649]

theorem envBound19041 : H12AffineFastState.Bounded env19041 := by
  intro p hp
  have h : env19041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19040_19041 : H12AffineEnvironment.transform 12 469 env19040 = env19041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env19040 == env19041) = true)

theorem identity19041 : scanCanonicalize (H12AffineFastState.compose env19041 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19041 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env19042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,136,479,5529,2421,1025,137,4297,32,153,138,349,64,2184,5529,4097,2557,1364,169,257,33,5593,649]

theorem envBound19042 : H12AffineFastState.Bounded env19042 := by
  intro p hp
  have h : env19042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19041_19042 : H12AffineEnvironment.transform 13 5376 env19041 = env19042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19041 == env19042) = true)

theorem identity19042 : scanCanonicalize (H12AffineFastState.compose env19042 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound19042 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19043 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,40,5373,136,34,5220,2184,1025,137,4297,32,153,138,160,64,2184,5220,4097,2048,1193,169,252,33,5156,649]

theorem envBound19043 : H12AffineFastState.Bounded env19043 := by
  intro p hp
  have h : env19043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19042_19043 : H12AffineEnvironment.transform 7 253 env19042 = env19043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env19042 == env19043) = true)

theorem identity19043 : scanCanonicalize (H12AffineFastState.compose env19043 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound19043 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19044 : List Nat := [2,4,8,16,32,64,128,253,512,1024,136,4096,40,5373,136,34,5220,0,1025,137,4297,32,153,138,160,64,0,5220,4097,136,1193,169,252,33,5156,649]

theorem envBound19044 : H12AffineFastState.Bounded env19044 := by
  intro p hp
  have h : env19044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19043_19044 : H12AffineEnvironment.transform 10 136 env19043 = env19044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env19043 == env19044) = true)

theorem identity19044 : scanCanonicalize (H12AffineFastState.compose env19044 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound19044 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env19045 : List Nat := [2,4,8,16,32,64,128,253,512,204,136,4096,40,4145,136,34,4264,0,205,137,4297,32,153,138,160,64,0,4264,4097,136,101,169,252,33,4328,649]

theorem envBound19045 : H12AffineFastState.Bounded env19045 := by
  intro p hp
  have h : env19045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19044_19045 : H12AffineEnvironment.transform 9 204 env19044 = env19045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env19044 == env19045) = true)

def env19046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144541,2098512,17665,2363457,2102685,2411676,257,21793,46212,2175562]

theorem envBound19046 : H12AffineFastState.Bounded env19046 := by
  intro p hp
  have h : env19046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19035_19046 : H12AffineEnvironment.transform 21 272513 env19035 = env19046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19035 == env19046) = true)

theorem identity19046 : scanCanonicalize (H12AffineFastState.compose env19046 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound19046 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272513,73755,98781,8328,64,100694,79131,17665,335882,75222,392407,257,21793,46212,513]

theorem envBound19047 : H12AffineFastState.Bounded env19047 := by
  intro p hp
  have h : env19047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19046_19047 : H12AffineEnvironment.transform 20 77899 env19046 = env19047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env19046 == env19047) = true)

def env19048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272393,73755,98645,8192,64,100694,79131,17665,335882,75102,392287,257,21793,46092,513]

theorem envBound19048 : H12AffineFastState.Bounded env19048 := by
  intro p hp
  have h : env19048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19047_19048 : H12AffineEnvironment.transform 6 8 env19047 = env19048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19047 == env19048) = true)

theorem identity19048 : scanCanonicalize (H12AffineFastState.compose env19048 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound19048 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,77899,41340,73755,98645,8192,64,100694,79131,17665,108927,75102,95530,257,21793,46092,513]

theorem envBound19049 : H12AffineFastState.Bounded env19049 := by
  intro p hp
  have h : env19049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19048_19049 : H12AffineEnvironment.transform 17 35189 env19048 = env19049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env19048 == env19049) = true)

theorem identity19049 : scanCanonicalize (H12AffineFastState.compose env19049 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19049 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env19050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32041,1025,29789,77899,21792,73755,95497,8192,64,97546,79131,17665,89379,75102,95530,257,21793,16464,513]

theorem envBound19050 : H12AffineFastState.Bounded env19050 := by
  intro p hp
  have h : env19050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19049_19050 : H12AffineEnvironment.transform 14 29788 env19049 = env19050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19049 == env19050) = true)

theorem identity19050 : scanCanonicalize (H12AffineFastState.compose env19050 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19050 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env19051 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,13340,32041,1025,29708,77850,21792,73755,95497,8192,17,97546,79131,17665,89379,75023,95530,257,21793,16385,513]

theorem envBound19051 : H12AffineFastState.Bounded env19051 := by
  intro p hp
  have h : env19051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19050_19051 : H12AffineEnvironment.transform 5 17 env19050 = env19051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19050 == env19051) = true)

theorem identity19051 : scanCanonicalize (H12AffineFastState.compose env19051 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound19051 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env19052 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,29963,13340,32041,1025,29708,17681,21792,21776,2,8192,17,2049,16400,17665,10280,20484,33,257,21793,16385,513]

theorem envBound19052 : H12AffineFastState.Bounded env19052 := by
  intro p hp
  have h : env19052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19051_19052 : H12AffineEnvironment.transform 15 29963 env19051 = env19052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env19051 == env19052) = true)

theorem identity19052 : scanCanonicalize (H12AffineFastState.compose env19052 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound19052 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env19053 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12572,1297,1047,13340,3125,1025,1296,13325,9276,9228,2,8192,17,2049,12556,13341,10280,8472,33,257,9277,12573,513]

theorem envBound19053 : H12AffineFastState.Bounded env19053 := by
  intro p hp
  have h : env19053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19052_19053 : H12AffineEnvironment.transform 13 12572 env19052 = env19053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env19052 == env19053) = true)

theorem identity19053 : scanCanonicalize (H12AffineFastState.compose env19053 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound19053 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env19054 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1053,5377,1297,1047,4097,3125,1025,1296,4112,33,17,2,1053,17,2049,5393,4096,3125,1285,33,257,32,5376,513]

theorem envBound19054 : H12AffineFastState.Bounded env19054 := by
  intro p hp
  have h : env19054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19053_19054 : H12AffineEnvironment.transform 12 1053 env19053 = env19054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env19053 == env19054) = true)

theorem identity19054 : scanCanonicalize (H12AffineFastState.compose env19054 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound19054 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env19055 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3076,1053,2309,1297,1047,3077,3125,1025,1296,3092,33,17,2,1053,17,2049,2325,3076,3125,1285,33,257,32,2308,513]

theorem envBound19055 : H12AffineFastState.Bounded env19055 := by
  intro p hp
  have h : env19055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19054_19055 : H12AffineEnvironment.transform 11 3076 env19054 = env19055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env19054 == env19055) = true)

theorem identity19055 : scanCanonicalize (H12AffineFastState.compose env19055 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound19055 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19056 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,2356,301,2309,33,295,2357,2309,305,32,2340,33,17,2,301,17,2049,2325,2356,2309,53,33,257,32,2308,513]

theorem envBound19056 : H12AffineFastState.Bounded env19056 := by
  intro p hp
  have h : env19056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19055_19056 : H12AffineEnvironment.transform 9 304 env19055 = env19056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env19055 == env19056) = true)

theorem identity19056 : scanCanonicalize (H12AffineFastState.compose env19056 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19056 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19057 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,2324,269,2309,1,263,2325,2309,273,0,2308,1,17,2,269,17,2049,2325,2324,2309,21,1,257,0,2308,513]

theorem envBound19057 : H12AffineFastState.Bounded env19057 := by
  intro p hp
  have h : env19057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19056_19057 : H12AffineEnvironment.transform 4 0 env19056 = env19057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19056 == env19057) = true)

theorem identity19057 : scanCanonicalize (H12AffineFastState.compose env19057 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19057 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19058 : List Nat := [2,4,8,16,0,17,8,256,512,272,1,277,269,260,1,263,276,260,273,0,261,1,17,2,269,17,0,276,277,260,21,1,257,0,261,513]

theorem envBound19058 : H12AffineFastState.Bounded env19058 := by
  intro p hp
  have h : env19058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19057_19058 : H12AffineEnvironment.transform 10 1 env19057 = env19058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19057 == env19058) = true)

def env19059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272392,73755,98644,8193,64,100694,79131,17665,335882,75103,392286,257,21793,46093,513]

theorem envBound19059 : H12AffineFastState.Bounded env19059 := by
  intro p hp
  have h : env19059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19047_19059 : H12AffineEnvironment.transform 6 9 env19047 = env19059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19047 == env19059) = true)

theorem identity19059 : scanCanonicalize (H12AffineFastState.compose env19059 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound19059 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49169,262144,1025,32769,36928,272392,32784,8543,8193,64,10589,38160,17665,294913,34132,285781,257,21793,46093,513]

theorem envBound19060 : H12AffineFastState.Bounded env19060 := by
  intro p hp
  have h : env19060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19059_19060 : H12AffineEnvironment.transform 15 40971 env19059 = env19060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env19059 == env19060) = true)

theorem identity19060 : scanCanonicalize (H12AffineFastState.compose env19060 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19060 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1344,9547,17745,262144,1025,1345,5376,272392,1360,8543,8193,64,10589,4176,17665,263489,20,285781,257,21793,12621,513]

theorem envBound19061 : H12AffineFastState.Bounded env19061 := by
  intro p hp
  have h : env19061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19060_19061 : H12AffineEnvironment.transform 14 1344 env19060 = env19061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env19060 == env19061) = true)

theorem identity19061 : scanCanonicalize (H12AffineFastState.compose env19061 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19061 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1344,9547,4097,262144,1025,1345,5376,272392,1360,8543,8193,64,10589,4176,4177,263489,20,264453,257,113,12621,513]

theorem envBound19062 : H12AffineFastState.Bounded env19062 := by
  intro p hp
  have h : env19062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19061_19062 : H12AffineEnvironment.transform 13 5456 env19061 = env19062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19061 == env19062) = true)

theorem identity19062 : scanCanonicalize (H12AffineFastState.compose env19062 (packedSelected [17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound19062 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env19063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1344,9547,4097,2421,1025,1345,5376,8573,1360,8543,8193,64,10589,4176,4177,3124,20,112,257,113,12621,513]

theorem envBound19063 : H12AffineFastState.Bounded env19063 := by
  intro p hp
  have h : env19063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19062_19063 : H12AffineEnvironment.transform 17 2421 env19062 = env19063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env19062 == env19063) = true)

theorem identity19063 : scanCanonicalize (H12AffineFastState.compose env19063 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound19063 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19064 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,4113,1,8202,4097,2421,320,0,4161,8573,17,8543,8193,64,10589,4176,4177,2421,20,112,257,113,12621,513]

theorem envBound19064 : H12AffineFastState.Bounded env19064 := by
  intro p hp
  have h : env19064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19063_19064 : H12AffineEnvironment.transform 9 321 env19063 = env19064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env19063 == env19064) = true)

theorem identity19064 : scanCanonicalize (H12AffineFastState.compose env19064 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19064 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19065 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,269,4113,1,263,4097,2421,320,0,4161,112,17,82,268,64,2128,4176,4177,2421,20,112,257,113,4160,513]

theorem envBound19065 : H12AffineFastState.Bounded env19065 := by
  intro p hp
  have h : env19065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19064_19065 : H12AffineEnvironment.transform 12 269 env19064 = env19065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19064 == env19065) = true)

theorem identity19065 : scanCanonicalize (H12AffineFastState.compose env19065 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound19065 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env19066 : List Nat := [2,4,8,16,32,64,9,256,112,321,2048,4096,269,4113,1,263,4097,2421,320,0,4161,112,17,82,268,64,2128,4176,4177,2421,20,112,257,113,4160,113]

theorem envBound19066 : H12AffineFastState.Bounded env19066 := by
  intro p hp
  have h : env19066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19065_19066 : H12AffineEnvironment.transform 8 112 env19065 = env19066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env19065 == env19066) = true)

theorem identity19066 : scanCanonicalize (H12AffineFastState.compose env19066 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19066 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env19067 : List Nat := [2,4,8,16,17,64,9,256,65,321,2048,4096,269,4113,1,263,4097,2372,320,0,4161,65,17,82,268,64,2128,4176,4177,2372,20,65,257,64,4160,64]

theorem envBound19067 : H12AffineFastState.Bounded env19067 := by
  intro p hp
  have h : env19067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19066_19067 : H12AffineEnvironment.transform 4 17 env19066 = env19067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19066 == env19067) = true)

theorem identity19067 : scanCanonicalize (H12AffineFastState.compose env19067 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound19067 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19068 : List Nat := [2,4,8,16,17,64,9,256,65,321,325,4096,269,4113,1,263,4097,1,320,0,4161,65,17,82,268,64,277,4176,4177,1,20,65,257,64,4160,64]

theorem envBound19068 : H12AffineFastState.Bounded env19068 := by
  intro p hp
  have h : env19068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19067_19068 : H12AffineEnvironment.transform 10 325 env19067 = env19068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env19067 == env19068) = true)

theorem identity19068 : scanCanonicalize (H12AffineFastState.compose env19068 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19068 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19069 : List Nat := [2,4,8,16,17,64,9,20,65,85,81,4096,25,4113,1,19,4097,1,84,0,4161,65,17,82,24,64,1,4176,4177,1,20,65,21,64,4160,64]

theorem envBound19069 : H12AffineFastState.Bounded env19069 := by
  intro p hp
  have h : env19069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19068_19069 : H12AffineEnvironment.transform 7 20 env19068 = env19069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19068 == env19069) = true)

theorem identity19069 : scanCanonicalize (H12AffineFastState.compose env19069 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 75) := by decide +kernel

theorem selectedBound19069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19070 : List Nat := [2,4,8,16,17,64,9,20,65,85,81,75,25,90,1,19,74,1,84,0,10,65,17,82,24,64,1,27,26,1,20,65,21,64,11,64]

theorem envBound19070 : H12AffineFastState.Bounded env19070 := by
  intro p hp
  have h : env19070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19069_19070 : H12AffineEnvironment.transform 11 75 env19069 = env19070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 75 env19069 == env19070) = true)

theorem identity19070 : scanCanonicalize (H12AffineFastState.compose env19070 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound19070 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19071 : List Nat := [2,4,8,16,17,10,9,20,11,31,27,1,25,16,1,19,0,1,30,0,10,11,17,24,24,10,1,27,26,1,20,11,21,10,11,10]

theorem envBound19071 : H12AffineFastState.Bounded env19071 := by
  intro p hp
  have h : env19071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19070_19071 : H12AffineEnvironment.transform 5 10 env19070 = env19071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env19070 == env19071) = true)

theorem identity19071 : scanCanonicalize (H12AffineFastState.compose env19071 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19071 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env19072 : List Nat := [2,4,8,1,0,10,9,5,11,14,10,1,8,1,1,2,0,1,15,0,10,11,0,9,9,10,1,10,11,1,5,11,4,10,11,10]

theorem envBound19072 : H12AffineFastState.Bounded env19072 := by
  intro p hp
  have h : env19072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19071_19072 : H12AffineEnvironment.transform 3 1 env19071 = env19072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19071 == env19072) = true)

def env19073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound19073 : H12AffineFastState.Bounded env19073 := by
  intro p hp
  have h : env19073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18393_19073 : H12AffineEnvironment.transform 25 65 env18393 = env19073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env18393 == env19073) = true)

def env19074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound19074 : H12AffineFastState.Bounded env19074 := by
  intro p hp
  have h : env19074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19073_19074 : H12AffineEnvironment.transform 26 30393344 env19073 = env19074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env19073 == env19074) = true)

def env19075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound19075 : H12AffineFastState.Bounded env19075 := by
  intro p hp
  have h : env19075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19074_19075 : H12AffineEnvironment.transform 18 1024 env19074 = env19075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19074 == env19075) = true)

theorem identity19075 : scanCanonicalize (H12AffineFastState.compose env19075 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396460) := by decide +kernel

theorem selectedBound19075 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,16777216,8328,65,29868032,17270816,8804860,8830976,25265169,21457261,256,25675776,25635237,25207750]

theorem envBound19076 : H12AffineFastState.Bounded env19076 := by
  intro p hp
  have h : env19076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19075_19076 : H12AffineEnvironment.transform 20 396460 env19075 = env19076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396460 env19075 == env19076) = true)

def env19077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,8887584,8328,65,4218144,8393984,8804860,8830976,399665,12645453,256,21792,46213,474854]

theorem envBound19077 : H12AffineFastState.Bounded env19077 := by
  intro p hp
  have h : env19077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19076_19077 : H12AffineEnvironment.transform 23 8887584 env19076 = env19077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887584 env19076 == env19077) = true)

def env19078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452648,95496,8328,65,4218144,458024,45524,10280,399665,4594789,256,21792,46213,474854]

theorem envBound19078 : H12AffineFastState.Bounded env19078 := by
  intro p hp
  have h : env19078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19077_19078 : H12AffineEnvironment.transform 22 452648 env19077 = env19078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env19077 == env19078) = true)

def env19079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452648,95496,8328,65,292256,458024,45524,10280,399665,144613,256,21792,46213,474854]

theorem envBound19079 : H12AffineFastState.Bounded env19079 := by
  intro p hp
  have h : env19079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19078_19079 : H12AffineEnvironment.transform 21 272512 env19078 = env19079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19078 == env19079) = true)

theorem identity19079 : scanCanonicalize (H12AffineFastState.compose env19079 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19079 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396460,272512,452648,21762,8328,65,292256,458024,45524,10280,399665,144613,256,21792,46213,401132]

theorem envBound19080 : H12AffineFastState.Bounded env19080 := by
  intro p hp
  have h : env19080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19079_19080 : H12AffineEnvironment.transform 15 8202 env19079 = env19080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19079 == env19080) = true)

def env19081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396324,272392,452648,21762,8192,65,292136,458024,45404,10280,399665,144493,256,21792,46093,400996]

theorem envBound19081 : H12AffineFastState.Bounded env19081 := by
  intro p hp
  have h : env19081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19080_19081 : H12AffineEnvironment.transform 6 8 env19080 = env19081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19080 == env19081) = true)

theorem identity19081 : scanCanonicalize (H12AffineFastState.compose env19081 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound19081 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,23669,1024,32769,151633,29821,177245,21762,8192,65,10589,172381,45404,10280,148804,144493,256,21792,46093,147985]

theorem envBound19082 : H12AffineFastState.Bounded env19082 := by
  intro p hp
  have h : env19082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19081_19082 : H12AffineEnvironment.transform 17 23669 env19081 = env19082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env19081 == env19082) = true)

theorem identity19082 : scanCanonicalize (H12AffineFastState.compose env19082 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19082 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env19083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,131072,23669,1024,21761,151633,29821,155997,21762,8192,65,10589,160861,25692,10280,148804,144493,256,21792,24845,147985]

theorem envBound19083 : H12AffineFastState.Bounded env19083 := by
  intro p hp
  have h : env19083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19082_19083 : H12AffineEnvironment.transform 14 21760 env19082 = env19083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19082 == env19083) = true)

def env19084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,396325,272393,452648,21762,8193,65,292137,458024,45405,10280,399665,144492,256,21792,46092,400997]

theorem envBound19084 : H12AffineFastState.Bounded env19084 := by
  intro p hp
  have h : env19084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19080_19084 : H12AffineEnvironment.transform 6 9 env19080 = env19084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19080 == env19084) = true)

theorem identity19084 : scanCanonicalize (H12AffineFastState.compose env19084 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 182336) := by decide +kernel

theorem selectedBound19084 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env19085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182336,1024,32769,50277,188489,8296,21762,8193,65,179561,13672,45405,10280,53617,144492,256,21792,46092,54821]

theorem envBound19085 : H12AffineFastState.Bounded env19085 := by
  intro p hp
  have h : env19085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19084_19085 : H12AffineEnvironment.transform 17 182336 env19084 = env19085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182336 env19084 == env19085) = true)

theorem identity19085 : scanCanonicalize (H12AffineFastState.compose env19085 (packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound19085 : packedSelected [0,4,7,8,10,12,15,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env19086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,8202,131072,149520,1024,81,17461,155673,8296,21762,8193,65,146745,13672,12557,10280,20769,144492,256,21792,13404,22133]

theorem envBound19086 : H12AffineFastState.Bounded env19086 := by
  intro p hp
  have h : env19086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19085_19086 : H12AffineEnvironment.transform 14 80 env19085 = env19086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env19085 == env19086) = true)

theorem identity19086 : scanCanonicalize (H12AffineFastState.compose env19086 (packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound19086 : packedSelected [0,1,5,6,7,8,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,80,8202,131072,146792,1024,81,12621,136545,8296,8314,8193,65,146745,13672,12557,10280,9305,144492,256,8280,13404,8973]

theorem envBound19087 : H12AffineFastState.Bounded env19087 := by
  intro p hp
  have h : env19087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19086_19087 : H12AffineEnvironment.transform 13 13688 env19086 = env19087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env19086 == env19087) = true)

theorem identity19087 : scanCanonicalize (H12AffineFastState.compose env19087 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound19087 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,80,115,131072,138513,1024,81,4404,136545,17,3,120,65,138560,5393,4468,2129,1056,136213,256,33,5157,884]

theorem envBound19088 : H12AffineFastState.Bounded env19088 := by
  intro p hp
  have h : env19088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19087_19088 : H12AffineEnvironment.transform 12 121 env19087 = env19088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env19087 == env19088) = true)

theorem identity19088 : scanCanonicalize (H12AffineFastState.compose env19088 (packedSelected [0,1,4,6,7,8,9,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound19088 : packedSelected [0,1,4,6,7,8,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env19089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,121,5377,80,115,131072,135541,1024,81,4404,136545,17,3,120,65,135460,5393,4468,1077,1056,136213,256,33,5157,884]

theorem envBound19089 : H12AffineFastState.Bounded env19089 := by
  intro p hp
  have h : env19089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19088_19089 : H12AffineEnvironment.transform 10 1124 env19088 = env19089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env19088 == env19089) = true)

theorem identity19089 : scanCanonicalize (H12AffineFastState.compose env19089 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound19089 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env19090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,121,5377,80,115,4469,0,1024,81,4404,1044,17,3,120,65,81,5393,4468,1077,1056,1376,256,33,5157,884]

theorem envBound19090 : H12AffineFastState.Bounded env19090 := by
  intro p hp
  have h : env19090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19089_19090 : H12AffineEnvironment.transform 16 4469 env19089 = env19090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env19089 == env19090) = true)

theorem identity19090 : scanCanonicalize (H12AffineFastState.compose env19090 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19090 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19091 : List Nat := [2,4,8,16,32,64,9,256,512,272,372,4096,121,4113,80,115,4469,0,272,81,4404,260,17,3,120,65,81,4097,4468,293,304,112,256,33,4405,884]

theorem envBound19091 : H12AffineFastState.Bounded env19091 := by
  intro p hp
  have h : env19091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19090_19091 : H12AffineEnvironment.transform 9 272 env19090 = env19091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19090 == env19091) = true)

theorem identity19091 : scanCanonicalize (H12AffineFastState.compose env19091 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound19091 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19092 : List Nat := [2,4,8,16,32,0,9,256,512,272,308,4096,57,4113,16,51,4405,0,272,17,4404,260,17,3,56,1,17,4097,4404,293,304,48,256,33,4405,820]

theorem envBound19092 : H12AffineFastState.Bounded env19092 := by
  intro p hp
  have h : env19092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19091_19092 : H12AffineEnvironment.transform 5 0 env19091 = env19092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env19091 == env19092) = true)

theorem identity19092 : scanCanonicalize (H12AffineFastState.compose env19092 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound19092 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env19093 : List Nat := [2,4,8,16,32,0,9,256,512,272,308,529,57,512,16,51,804,0,272,17,805,260,17,3,56,1,17,528,805,293,304,48,256,33,804,820]

theorem envBound19093 : H12AffineFastState.Bounded env19093 := by
  intro p hp
  have h : env19093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19092_19093 : H12AffineEnvironment.transform 11 529 env19092 = env19093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env19092 == env19093) = true)

theorem identity19093 : scanCanonicalize (H12AffineFastState.compose env19093 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19093 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19094 : List Nat := [2,4,8,16,32,0,9,256,1,272,308,16,57,1,16,51,293,0,272,17,292,260,17,3,56,1,17,17,292,293,304,48,256,33,293,309]

theorem envBound19094 : H12AffineFastState.Bounded env19094 := by
  intro p hp
  have h : env19094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19093_19094 : H12AffineEnvironment.transform 8 1 env19093 = env19094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19093 == env19094) = true)

theorem identity19094 : scanCanonicalize (H12AffineFastState.compose env19094 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19094 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env19095 : List Nat := [2,4,8,16,32,0,9,36,1,52,16,16,57,1,16,51,1,0,52,17,0,32,17,3,56,1,17,17,0,1,20,48,36,33,1,17]

theorem envBound19095 : H12AffineFastState.Bounded env19095 := by
  intro p hp
  have h : env19095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19094_19095 : H12AffineEnvironment.transform 7 36 env19094 = env19095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19094 == env19095) = true)

def env19096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452648,95496,8328,65,292257,458024,45524,10280,399665,144612,256,21792,46213,474854]

theorem envBound19096 : H12AffineFastState.Bounded env19096 := by
  intro p hp
  have h : env19096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19078_19096 : H12AffineEnvironment.transform 21 272513 env19078 = env19096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19078 == env19096) = true)

theorem identity19096 : scanCanonicalize (H12AffineFastState.compose env19096 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound19096 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115870,254131,73754,95496,8328,65,245139,79130,45524,10280,119043,144612,256,21792,46213,63188]

theorem envBound19097 : H12AffineFastState.Bounded env19097 := by
  intro p hp
  have h : env19097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19096_19097 : H12AffineEnvironment.transform 17 247858 env19096 = env19097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env19096 == env19097) = true)

def env19098 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115870,254131,73754,95496,8328,17,245139,79130,45444,10280,119043,144564,256,21792,46213,63108]

theorem envBound19098 : H12AffineFastState.Bounded env19098 := by
  intro p hp
  have h : env19098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19097_19098 : H12AffineEnvironment.transform 5 16 env19097 = env19098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19097 == env19098) = true)

theorem identity19098 : scanCanonicalize (H12AffineFastState.compose env19098 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound19098 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19099 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57628,76078,1024,32769,115870,65967,73754,95496,8328,17,89231,79130,45444,10280,119043,54696,256,21792,46213,63108]

theorem envBound19099 : H12AffineFastState.Bounded env19099 := by
  intro p hp
  have h : env19099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19098_19099 : H12AffineEnvironment.transform 16 57628 env19098 = env19099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env19098 == env19099) = true)

theorem identity19099 : scanCanonicalize (H12AffineFastState.compose env19099 (packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19099 : packedSelected [0,1,5,8,9,17,18,19,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19100 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,57628,76078,1024,32769,115734,65831,73754,95496,8192,17,89095,79130,45324,10280,119043,54560,256,21792,46093,62988]

theorem envBound19100 : H12AffineFastState.Bounded env19100 := by
  intro p hp
  have h : env19100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19099_19100 : H12AffineEnvironment.transform 6 8 env19099 = env19100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19099 == env19100) = true)

def env19101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,115870,254131,73754,95496,8328,16,245139,79130,45445,10280,119043,144565,256,21792,46213,63109]

theorem envBound19101 : H12AffineFastState.Bounded env19101 := by
  intro p hp
  have h : env19101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19097_19101 : H12AffineEnvironment.transform 5 17 env19097 = env19101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19097 == env19101) = true)

theorem identity19101 : scanCanonicalize (H12AffineFastState.compose env19101 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound19101 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env19102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79131,64809,1024,32769,115870,54696,73754,95496,8328,16,34952,79130,45445,10280,119043,65966,256,21792,46213,63109]

theorem envBound19102 : H12AffineFastState.Bounded env19102 := by
  intro p hp
  have h : env19102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19101_19102 : H12AffineEnvironment.transform 16 79131 env19101 = env19102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env19101 == env19102) = true)

theorem identity19102 : scanCanonicalize (H12AffineFastState.compose env19102 (packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound19102 : packedSelected [0,1,5,8,9,14,18,22,23,24,27,35] rootPS < 2^1333 := by decide +kernel

def env19103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,57748,64809,1024,32769,4113,54696,62613,41351,8328,16,34952,57749,45445,10280,1420,54561,256,21792,46213,63109]

theorem envBound19103 : H12AffineFastState.Bounded env19103 := by
  intro p hp
  have h : env19103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19102_19103 : H12AffineEnvironment.transform 15 54415 env19102 = env19103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env19102 == env19103) = true)

theorem identity19103 : scanCanonicalize (H12AffineFastState.compose env19103 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound19103 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env19104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,5392,2477,1024,29829,4113,8492,17,21763,8328,16,31756,5393,17665,10280,1420,8613,256,21792,16385,513]

theorem envBound19104 : H12AffineFastState.Bounded env19104 := by
  intro p hp
  have h : env19104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19103_19104 : H12AffineEnvironment.transform 14 29828 env19103 = env19104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env19103 == env19104) = true)

theorem identity19104 : scanCanonicalize (H12AffineFastState.compose env19104 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19104 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19105 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,8203,5392,2477,1024,8581,4113,8492,17,3,8328,16,10508,5393,4097,10280,1420,8613,256,32,5377,513]

theorem envBound19105 : H12AffineFastState.Bounded env19105 := by
  intro p hp
  have h : env19105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19104_19105 : H12AffineEnvironment.transform 13 5376 env19104 = env19105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19104 == env19105) = true)

theorem identity19105 : scanCanonicalize (H12AffineFastState.compose env19105 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19105 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19106 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,398,5392,2477,1024,0,4113,169,17,3,269,16,2185,5393,4097,2477,1420,32,256,32,5377,513]

theorem envBound19106 : H12AffineFastState.Bounded env19106 := by
  intro p hp
  have h : env19106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19105_19106 : H12AffineEnvironment.transform 12 389 env19105 = env19106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19105 == env19106) = true)

theorem identity19106 : scanCanonicalize (H12AffineFastState.compose env19106 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound19106 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19107 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,389,2185,1,398,2201,2477,1024,0,3480,169,17,3,269,16,2185,2200,3464,2477,1420,32,256,32,2184,513]

theorem envBound19107 : H12AffineFastState.Bounded env19107 := by
  intro p hp
  have h : env19107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19106_19107 : H12AffineEnvironment.transform 11 3465 env19106 = env19107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env19106 == env19107) = true)

theorem identity19107 : scanCanonicalize (H12AffineFastState.compose env19107 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound19107 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env19108 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1061,389,293,1,398,309,1,1024,0,1076,169,17,3,269,16,293,308,1060,1,1420,32,256,32,292,513]

theorem envBound19108 : H12AffineFastState.Bounded env19108 := by
  intro p hp
  have h : env19108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19107_19108 : H12AffineEnvironment.transform 10 428 env19107 = env19108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env19107 == env19108) = true)

theorem identity19108 : scanCanonicalize (H12AffineFastState.compose env19108 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound19108 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19109 : List Nat := [2,4,8,16,32,17,128,256,512,188,428,153,389,293,1,398,309,1,188,0,136,169,17,3,269,16,293,308,152,1,304,32,256,32,292,513]

theorem envBound19109 : H12AffineFastState.Bounded env19109 := by
  intro p hp
  have h : env19109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19108_19109 : H12AffineEnvironment.transform 9 188 env19108 = env19109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env19108 == env19109) = true)

theorem identity19109 : scanCanonicalize (H12AffineFastState.compose env19109 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19109 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19110 : List Nat := [2,4,8,16,32,17,9,256,512,53,293,16,268,293,1,263,309,1,53,0,1,32,17,3,269,16,293,308,17,1,304,32,256,32,292,513]

theorem envBound19110 : H12AffineFastState.Bounded env19110 := by
  intro p hp
  have h : env19110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19109_19110 : H12AffineEnvironment.transform 6 9 env19109 = env19110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19109 == env19110) = true)

def env19111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452649,95497,8328,65,4218144,458025,45525,10281,399665,4594788,256,21792,46213,474854]

theorem envBound19111 : H12AffineFastState.Bounded env19111 := by
  intro p hp
  have h : env19111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19077_19111 : H12AffineEnvironment.transform 22 452649 env19077 = env19111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env19077 == env19111) = true)

def env19112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452649,95497,8328,65,292256,458025,45525,10281,399665,144612,256,21792,46213,474854]

theorem envBound19112 : H12AffineFastState.Bounded env19112 := by
  intro p hp
  have h : env19112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19111_19112 : H12AffineEnvironment.transform 21 272512 env19111 = env19112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19111 == env19112) = true)

theorem identity19112 : scanCanonicalize (H12AffineFastState.compose env19112 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound19112 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,396460,272512,452649,41431,8328,65,292256,458025,45525,10281,399665,144612,256,21792,46213,453176]

theorem envBound19113 : H12AffineFastState.Bounded env19113 := by
  intro p hp
  have h : env19113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19112_19113 : H12AffineEnvironment.transform 15 54494 env19112 = env19113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env19112 == env19113) = true)

def env19114 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,396460,272512,452649,41351,8328,17,292256,458025,45445,10281,399665,144564,256,21792,46213,453176]

theorem envBound19114 : H12AffineFastState.Bounded env19114 := by
  intro p hp
  have h : env19114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19113_19114 : H12AffineEnvironment.transform 5 16 env19113 = env19114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19113 == env19114) = true)

theorem identity19114 : scanCanonicalize (H12AffineFastState.compose env19114 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound19114 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env19115 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,32041,1024,32769,160133,21929,169216,41351,8328,17,2185,163840,45445,10281,156696,144564,256,21792,46213,169745]

theorem envBound19115 : H12AffineFastState.Bounded env19115 := by
  intro p hp
  have h : env19115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19114_19115 : H12AffineEnvironment.transform 17 32041 env19114 = env19115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env19114 == env19115) = true)

theorem identity19115 : scanCanonicalize (H12AffineFastState.compose env19115 (packedSelected [0,9,10,17,18,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound19115 : packedSelected [0,9,10,17,18,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env19116 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46108,32041,1024,32769,50585,21929,8476,41351,8328,17,2185,13340,45445,10281,53252,32936,256,21792,46213,8973]

theorem envBound19116 : H12AffineFastState.Bounded env19116 := by
  intro p hp
  have h : env19116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19115_19116 : H12AffineEnvironment.transform 16 46108 env19115 = env19116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env19115 == env19116) = true)

theorem identity19116 : scanCanonicalize (H12AffineFastState.compose env19116 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19116 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env19117 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,54414,38297,23724,1024,32769,50585,21929,153,32770,269,17,2185,5529,36864,2476,53252,32936,256,21792,38144,648]

theorem envBound19117 : H12AffineFastState.Bounded env19117 := by
  intro p hp
  have h : env19117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19116_19117 : H12AffineEnvironment.transform 12 389 env19116 = env19117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19116 == env19117) = true)

theorem identity19117 : scanCanonicalize (H12AffineFastState.compose env19117 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound19117 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env19118 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4248,32768,33814,38297,3124,1024,32769,38145,1329,153,32770,269,17,2185,5529,36864,2476,32924,32936,256,1464,38144,648]

theorem envBound19118 : H12AffineFastState.Bounded env19118 := by
  intro p hp
  have h : env19118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19117_19118 : H12AffineEnvironment.transform 13 4248 env19117 = env19118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env19117 == env19118) = true)

theorem identity19118 : scanCanonicalize (H12AffineFastState.compose env19118 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19118 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env19119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4248,1,1047,5528,3124,1024,0,5376,1329,153,3,269,17,2185,5529,4097,2476,157,169,256,1464,5377,648]

theorem envBound19119 : H12AffineFastState.Bounded env19119 := by
  intro p hp
  have h : env19119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19118_19119 : H12AffineEnvironment.transform 14 1 env19118 = env19119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19118 == env19119) = true)

theorem identity19119 : scanCanonicalize (H12AffineFastState.compose env19119 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound19119 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19120 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,40,4248,1,1047,5173,3124,1024,0,5293,1180,153,3,160,17,2185,5172,4097,2049,157,169,173,1045,5292,648]

theorem envBound19120 : H12AffineFastState.Bounded env19120 := by
  intro p hp
  have h : env19120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19119_19120 : H12AffineEnvironment.transform 7 173 env19119 = env19120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env19119 == env19120) = true)

theorem identity19120 : scanCanonicalize (H12AffineFastState.compose env19120 (packedSelected [1,2,3,4,5,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound19120 : packedSelected [1,2,3,4,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env19121 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,48,40,168,1,1047,1029,3124,1024,0,1181,1180,153,3,160,17,2185,1028,49,2049,157,169,173,1045,1180,648]

theorem envBound19121 : H12AffineFastState.Bounded env19121 := by
  intro p hp
  have h : env19121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19120_19121 : H12AffineEnvironment.transform 11 48 env19120 = env19121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env19120 == env19121) = true)

theorem identity19121 : scanCanonicalize (H12AffineFastState.compose env19121 (packedSelected [0,2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound19121 : packedSelected [0,2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env19122 : List Nat := [2,4,8,16,32,16,128,173,512,156,2048,48,40,168,1,139,153,2216,156,0,1,0,153,3,160,17,2185,152,49,2049,157,169,173,137,0,648]

theorem envBound19122 : H12AffineFastState.Bounded env19122 := by
  intro p hp
  have h : env19122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19121_19122 : H12AffineEnvironment.transform 9 156 env19121 = env19122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env19121 == env19122) = true)

theorem identity19122 : scanCanonicalize (H12AffineFastState.compose env19122 (packedSelected [2,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19122 : packedSelected [2,9,10] rootPS < 2^1333 := by decide +kernel

def env19123 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,48,40,33,1,2,16,2081,21,0,1,0,16,3,41,17,2048,17,49,2049,20,32,36,0,0,513]

theorem envBound19123 : H12AffineFastState.Bounded env19123 := by
  intro p hp
  have h : env19123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19122_19123 : H12AffineEnvironment.transform 6 9 env19122 = env19123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19122 == env19123) = true)

def env19124 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,396460,272512,452649,41350,8328,16,292256,458025,45444,10281,399665,144565,256,21792,46213,453176]

theorem envBound19124 : H12AffineFastState.Bounded env19124 := by
  intro p hp
  have h : env19124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19113_19124 : H12AffineEnvironment.transform 5 17 env19113 = env19124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19113 == env19124) = true)

theorem identity19124 : scanCanonicalize (H12AffineFastState.compose env19124 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound19124 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env19125 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,262144,1024,32769,276657,272512,318516,41350,8328,16,292256,313652,45444,10281,273708,168,256,21792,46213,319013]

theorem envBound19125 : H12AffineFastState.Bounded env19125 := by
  intro p hp
  have h : env19125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19124_19125 : H12AffineEnvironment.transform 16 13341 env19124 = env19125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env19124 == env19125) = true)

theorem identity19125 : scanCanonicalize (H12AffineFastState.compose env19125 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound19125 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env19126 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,2476,1024,32769,12573,8492,54680,41350,8328,16,31756,49304,45444,10281,9344,168,256,21792,46213,55177]

theorem envBound19126 : H12AffineFastState.Bounded env19126 := by
  intro p hp
  have h : env19126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19125_19126 : H12AffineEnvironment.transform 17 2476 env19125 = env19126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env19125 == env19126) = true)

theorem identity19126 : scanCanonicalize (H12AffineFastState.compose env19126 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound19126 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env19127 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21896,263,13341,2476,1024,21897,12573,8492,16,29710,8328,16,31756,5392,25612,10281,9344,168,256,21792,24845,513]

theorem envBound19127 : H12AffineFastState.Bounded env19127 := by
  intro p hp
  have h : env19127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19126_19127 : H12AffineEnvironment.transform 14 21896 env19126 = env19127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env19126 == env19127) = true)

theorem identity19127 : scanCanonicalize (H12AffineFastState.compose env19127 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound19127 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env19128 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,1,263,13341,2476,1024,0,12573,8492,16,8583,8328,16,10629,5392,12677,10281,9344,168,256,169,13444,513]

theorem envBound19128 : H12AffineFastState.Bounded env19128 := by
  intro p hp
  have h : env19128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19127_19128 : H12AffineEnvironment.transform 13 5513 env19127 = env19128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env19127 == env19128) = true)

theorem identity19128 : scanCanonicalize (H12AffineFastState.compose env19128 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19128 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19129 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,13341,2341,1024,0,12573,8492,16,8462,8193,16,10508,5392,12556,10281,9225,33,256,32,13325,513]

theorem envBound19129 : H12AffineFastState.Bounded env19129 := by
  intro p hp
  have h : env19129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19128_19129 : H12AffineEnvironment.transform 6 9 env19128 = env19129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19128 == env19129) = true)

theorem identity19129 : scanCanonicalize (H12AffineFastState.compose env19129 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound19129 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env19130 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2350,8192,3118,1,263,11571,2341,1024,0,10291,8492,16,8462,8193,16,10508,3134,10274,10281,9225,33,256,32,11555,513]

theorem envBound19130 : H12AffineFastState.Bounded env19130 := by
  intro p hp
  have h : env19130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19129_19130 : H12AffineEnvironment.transform 11 2350 env19129 = env19130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env19129 == env19130) = true)

theorem identity19130 : scanCanonicalize (H12AffineFastState.compose env19130 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound19130 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19131 : List Nat := [2,4,8,16,32,17,9,256,512,1024,271,33,8192,1313,1,263,9276,42,1024,0,8508,8492,16,8462,8193,16,8195,1329,8493,8486,9225,33,256,32,9260,513]

theorem envBound19131 : H12AffineFastState.Bounded env19131 := by
  intro p hp
  have h : env19131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19130_19131 : H12AffineEnvironment.transform 10 271 env19130 = env19131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env19130 == env19131) = true)

theorem identity19131 : scanCanonicalize (H12AffineFastState.compose env19131 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound19131 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env19132 : List Nat := [2,4,8,16,32,17,9,256,512,1024,271,33,1085,1313,1,263,1,42,1024,0,1281,1297,16,1331,1084,16,1086,1329,1296,1307,52,33,256,32,17,513]

theorem envBound19132 : H12AffineFastState.Bounded env19132 := by
  intro p hp
  have h : env19132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19131_19132 : H12AffineEnvironment.transform 12 1085 env19131 = env19132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env19131 == env19132) = true)

theorem identity19132 : scanCanonicalize (H12AffineFastState.compose env19132 (packedSelected [0,1,5,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound19132 : packedSelected [0,1,5,9,11] rootPS < 2^1333 := by decide +kernel

def env19133 : List Nat := [2,4,8,16,32,17,9,63,512,1024,48,33,1085,1054,1,56,1,42,1024,0,1086,1070,16,1036,1084,16,1086,1038,1071,1060,52,33,63,32,17,513]

theorem envBound19133 : H12AffineFastState.Bounded env19133 := by
  intro p hp
  have h : env19133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19132_19133 : H12AffineEnvironment.transform 7 63 env19132 = env19133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env19132 == env19133) = true)

theorem identity19133 : scanCanonicalize (H12AffineFastState.compose env19133 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19133 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env19134 : List Nat := [2,4,8,16,27,17,9,4,512,1024,11,26,1030,1054,1,3,1,17,1024,0,1029,1045,16,1036,1031,16,1029,1038,1044,1055,15,26,4,27,17,513]

theorem envBound19134 : H12AffineFastState.Bounded env19134 := by
  intro p hp
  have h : env19134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19133_19134 : H12AffineEnvironment.transform 4 27 env19133 = env19134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19133 == env19134) = true)

theorem identity19134 : scanCanonicalize (H12AffineFastState.compose env19134 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound19134 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env19135 : List Nat := [2,4,8,12,7,13,9,4,512,1024,11,6,1030,1026,1,3,1,13,1024,0,1029,1033,12,1036,1031,12,1029,1038,1032,1027,15,6,4,7,13,513]

theorem envBound19135 : H12AffineFastState.Bounded env19135 := by
  intro p hp
  have h : env19135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19134_19135 : H12AffineEnvironment.transform 3 12 env19134 = env19135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env19134 == env19135) = true)

theorem identity19135 : scanCanonicalize (H12AffineFastState.compose env19135 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound19135 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19136 : List Nat := [2,4,8,12,7,13,9,4,512,15,11,6,9,13,1,3,1,13,15,0,10,6,12,3,8,12,10,1,7,12,15,6,4,7,13,513]

theorem envBound19136 : H12AffineFastState.Bounded env19136 := by
  intro p hp
  have h : env19136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19135_19136 : H12AffineEnvironment.transform 9 15 env19135 = env19136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env19135 == env19136) = true)

theorem identity19136 : scanCanonicalize (H12AffineFastState.compose env19136 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound19136 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19137 : List Nat := [2,2,8,10,1,11,9,2,512,9,11,0,9,11,1,3,1,11,9,0,10,0,10,3,8,10,10,1,1,10,9,0,2,1,11,513]

theorem envBound19137 : H12AffineFastState.Bounded env19137 := by
  intro p hp
  have h : env19137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19136_19137 : H12AffineEnvironment.transform 1 2 env19136 = env19137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env19136 == env19137) = true)

theorem identity19137 : scanCanonicalize (H12AffineFastState.compose env19137 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound19137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19138 : List Nat := [1,1,8,9,1,8,9,1,512,9,8,0,9,8,1,0,1,8,9,0,9,0,9,0,8,9,9,1,1,9,9,0,1,1,8,513]

theorem envBound19138 : H12AffineFastState.Bounded env19138 := by
  intro p hp
  have h : env19138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19137_19138 : H12AffineEnvironment.transform 0 1 env19137 = env19138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env19137 == env19138) = true)

theorem identity19138 : scanCanonicalize (H12AffineFastState.compose env19138 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound19138 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19139 : List Nat := [1,1,1,0,1,1,0,1,512,0,1,0,0,1,1,0,1,1,0,0,0,0,0,0,1,0,0,1,1,0,0,0,1,1,1,513]

theorem envBound19139 : H12AffineFastState.Bounded env19139 := by
  intro p hp
  have h : env19139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19138_19139 : H12AffineEnvironment.transform 2 1 env19138 = env19139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env19138 == env19139) = true)

def env19140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452649,95497,8328,65,292257,458025,45525,10281,399665,144613,256,21792,46213,474854]

theorem envBound19140 : H12AffineFastState.Bounded env19140 := by
  intro p hp
  have h : env19140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19111_19140 : H12AffineEnvironment.transform 21 272513 env19111 = env19140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19111 == env19140) = true)

theorem identity19140 : scanCanonicalize (H12AffineFastState.compose env19140 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212199) := by decide +kernel

theorem selectedBound19140 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212199,1024,32769,77899,201830,120014,95497,8328,65,215366,115150,45525,10281,75222,144613,256,21792,46213,513]

theorem envBound19141 : H12AffineFastState.Bounded env19141 := by
  intro p hp
  have h : env19141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19140_19141 : H12AffineEnvironment.transform 17 212199 env19140 = env19141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212199 env19140 == env19141) = true)

def env19142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,77899,201830,119878,95497,8192,65,215366,115014,45405,10281,75102,144493,256,21792,46093,513]

theorem envBound19142 : H12AffineFastState.Bounded env19142 := by
  intro p hp
  have h : env19142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19141_19142 : H12AffineEnvironment.transform 6 8 env19141 = env19142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19141 == env19142) = true)

theorem identity19142 : scanCanonicalize (H12AffineFastState.compose env19142 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound19142 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10280,1024,32769,77899,33,119878,95497,8192,65,23809,115014,45405,10281,75102,73770,256,21792,46093,513]

theorem envBound19143 : H12AffineFastState.Bounded env19143 := by
  intro p hp
  have h : env19143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19142_19143 : H12AffineEnvironment.transform 16 70727 env19142 = env19143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env19142 == env19143) = true)

theorem identity19143 : scanCanonicalize (H12AffineFastState.compose env19143 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19143 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env19144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,70727,10280,1024,8540,77899,33,95515,95497,8192,65,23809,90139,4096,10281,75102,73770,256,21792,5456,513]

theorem envBound19144 : H12AffineFastState.Bounded env19144 := by
  intro p hp
  have h : env19144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19143_19144 : H12AffineEnvironment.transform 14 8541 env19143 = env19144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19143 == env19144) = true)

theorem identity19144 : scanCanonicalize (H12AffineFastState.compose env19144 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound19144 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21591,16400,10280,1024,8540,25628,33,8524,8542,8192,65,23809,13388,4096,10281,28937,29821,256,21792,5456,513]

theorem envBound19145 : H12AffineFastState.Bounded env19145 := by
  intro p hp
  have h : env19145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19144_19145 : H12AffineEnvironment.transform 15 21591 env19144 = env19145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env19144 == env19145) = true)

theorem identity19145 : scanCanonicalize (H12AffineFastState.compose env19145 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19145 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21591,16400,2420,1024,0,17728,33,16,2,348,65,23809,5392,4096,2421,20565,21793,256,21792,5456,513]

theorem envBound19146 : H12AffineFastState.Bounded env19146 := by
  intro p hp
  have h : env19146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19145_19146 : H12AffineEnvironment.transform 12 348 env19145 = env19146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19145 == env19146) = true)

theorem identity19146 : scanCanonicalize (H12AffineFastState.compose env19146 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19146 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5392,2420,1024,0,4160,33,16,2,348,65,2049,5392,4096,2421,1365,33,256,32,5456,513]

theorem envBound19147 : H12AffineFastState.Bounded env19147 := by
  intro p hp
  have h : env19147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19146_19147 : H12AffineEnvironment.transform 13 5376 env19146 = env19147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19146 == env19147) = true)

theorem identity19147 : scanCanonicalize (H12AffineFastState.compose env19147 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound19147 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19148 : List Nat := [2,4,8,16,32,64,8,256,512,565,2048,4096,348,4917,1,343,4901,2420,565,0,4160,33,16,2,348,65,2049,4901,4096,2421,864,33,256,32,4965,513]

theorem envBound19148 : H12AffineFastState.Bounded env19148 := by
  intro p hp
  have h : env19148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19147_19148 : H12AffineEnvironment.transform 9 565 env19147 = env19148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env19147 == env19148) = true)

theorem identity19148 : scanCanonicalize (H12AffineFastState.compose env19148 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19148 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19149 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,4096,269,4917,1,262,4901,2341,565,0,4113,33,16,2,269,16,2049,4901,4096,2340,817,33,256,32,4916,513]

theorem envBound19149 : H12AffineFastState.Bounded env19149 := by
  intro p hp
  have h : env19149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19148_19149 : H12AffineEnvironment.transform 5 17 env19148 = env19149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19148 == env19149) = true)

theorem identity19149 : scanCanonicalize (H12AffineFastState.compose env19149 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound19149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19150 : List Nat := [2,4,8,16,32,17,8,256,512,565,2048,513,269,308,1,262,292,2341,565,0,528,33,16,2,269,16,2049,292,513,2340,817,33,256,32,309,513]

theorem envBound19150 : H12AffineFastState.Bounded env19150 := by
  intro p hp
  have h : env19150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19149_19150 : H12AffineEnvironment.transform 11 513 env19149 = env19150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env19149 == env19150) = true)

theorem identity19150 : scanCanonicalize (H12AffineFastState.compose env19150 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound19150 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19151 : List Nat := [2,4,8,16,32,17,8,256,512,565,821,513,269,308,1,262,292,528,565,0,528,33,16,2,269,16,820,292,513,529,817,33,256,32,309,513]

theorem envBound19151 : H12AffineFastState.Bounded env19151 := by
  intro p hp
  have h : env19151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19150_19151 : H12AffineEnvironment.transform 10 821 env19150 = env19151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env19150 == env19151) = true)

theorem identity19151 : scanCanonicalize (H12AffineFastState.compose env19151 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound19151 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19152 : List Nat := [2,4,8,16,32,17,8,256,293,272,16,292,269,308,1,262,292,309,272,0,309,33,16,2,269,16,17,292,292,308,20,33,256,32,309,292]

theorem envBound19152 : H12AffineFastState.Bounded env19152 := by
  intro p hp
  have h : env19152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19151_19152 : H12AffineEnvironment.transform 8 293 env19151 = env19152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env19151 == env19152) = true)

theorem identity19152 : scanCanonicalize (H12AffineFastState.compose env19152 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19152 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19153 : List Nat := [2,4,8,16,17,17,8,256,276,272,16,277,269,261,1,262,277,260,272,0,260,16,16,2,269,16,17,277,277,261,20,16,256,17,260,277]

theorem envBound19153 : H12AffineFastState.Bounded env19153 := by
  intro p hp
  have h : env19153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19152_19153 : H12AffineEnvironment.transform 4 17 env19152 = env19153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19152 == env19153) = true)

theorem identity19153 : scanCanonicalize (H12AffineFastState.compose env19153 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19153 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19154 : List Nat := [2,4,8,16,17,17,8,20,0,4,16,1,25,17,1,18,1,16,4,0,16,16,16,2,25,16,17,1,1,17,20,16,20,17,16,1]

theorem envBound19154 : H12AffineFastState.Bounded env19154 := by
  intro p hp
  have h : env19154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19153_19154 : H12AffineEnvironment.transform 7 20 env19153 = env19154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19153 == env19154) = true)

theorem identity19154 : scanCanonicalize (H12AffineFastState.compose env19154 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19154 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19155 : List Nat := [2,4,8,0,1,1,8,4,0,4,0,1,9,1,1,2,1,0,4,0,0,0,0,2,9,0,1,1,1,1,4,0,4,1,0,1]

theorem envBound19155 : H12AffineFastState.Bounded env19155 := by
  intro p hp
  have h : env19155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19154_19155 : H12AffineEnvironment.transform 3 0 env19154 = env19155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19154 == env19155) = true)

def env19156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201830,119879,95497,8193,65,215366,115015,45404,10281,75103,144492,256,21792,46092,513]

theorem envBound19156 : H12AffineFastState.Bounded env19156 := by
  intro p hp
  have h : env19156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19141_19156 : H12AffineEnvironment.transform 6 9 env19141 = env19156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19141 == env19156) = true)

theorem identity19156 : scanCanonicalize (H12AffineFastState.compose env19156 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound19156 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,23669,1024,32769,77899,29821,119879,95497,8193,65,10589,115015,45404,10281,75103,87159,256,21792,46092,513]

theorem envBound19157 : H12AffineFastState.Bounded env19157 := by
  intro p hp
  have h : env19157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19156_19157 : H12AffineEnvironment.transform 16 90139 env19156 = env19157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env19156 == env19157) = true)

theorem identity19157 : scanCanonicalize (H12AffineFastState.compose env19157 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound19157 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41051,49216,23669,1024,32769,36880,29821,29724,54610,8193,65,10589,24860,45404,10281,34052,62508,256,21792,46092,513]

theorem envBound19158 : H12AffineFastState.Bounded env19158 := by
  intro p hp
  have h : env19158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19157_19158 : H12AffineEnvironment.transform 15 41051 env19157 = env19158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env19157 == env19158) = true)

theorem identity19158 : scanCanonicalize (H12AffineFastState.compose env19158 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound19158 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env19159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1124,9279,17444,23669,1024,1125,5236,29821,29724,20790,8193,65,10589,24860,13624,10281,352,28744,256,21792,12392,513]

theorem envBound19159 : H12AffineFastState.Bounded env19159 := by
  intro p hp
  have h : env19159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19158_19159 : H12AffineEnvironment.transform 14 1124 env19158 = env19159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env19158 == env19159) = true)

theorem identity19159 : scanCanonicalize (H12AffineFastState.compose env19159 (packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19159 : packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env19160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1124,9279,12328,10361,1024,1125,5236,113,16,9530,8193,65,10589,5392,13624,10281,352,1092,256,8492,12392,513]

theorem envBound19160 : H12AffineFastState.Bounded env19160 := by
  intro p hp
  have h : env19160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19159_19160 : H12AffineEnvironment.transform 13 13324 env19159 = env19160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19159 == env19160) = true)

theorem identity19160 : scanCanonicalize (H12AffineFastState.compose env19160 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound19160 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4452,1124,343,5440,3345,1024,1125,5236,113,16,82,1385,65,3125,5392,4176,3393,352,1092,256,1092,5376,513]

theorem envBound19161 : H12AffineFastState.Bounded env19161 := by
  intro p hp
  have h : env19161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19160_19161 : H12AffineEnvironment.transform 12 1384 env19160 = env19161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env19160 == env19161) = true)

theorem identity19161 : scanCanonicalize (H12AffineFastState.compose env19161 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound19161 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,885,1384,529,1124,343,1589,3345,1024,1125,1793,113,16,82,1385,65,3125,1637,805,3393,352,1092,256,1092,1653,513]

theorem envBound19162 : H12AffineFastState.Bounded env19162 := by
  intro p hp
  have h : env19162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19161_19162 : H12AffineEnvironment.transform 11 885 env19161 = env19162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env19161 == env19162) = true)

theorem identity19162 : scanCanonicalize (H12AffineFastState.compose env19162 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound19162 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1280,885,1384,529,1124,343,1589,17,1024,1125,1793,113,16,82,1385,65,309,1637,805,65,352,1092,256,1092,1653,513]

theorem envBound19163 : H12AffineFastState.Bounded env19163 := by
  intro p hp
  have h : env19163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19162_19163 : H12AffineEnvironment.transform 10 1280 env19162 = env19163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env19162 == env19163) = true)

theorem identity19163 : scanCanonicalize (H12AffineFastState.compose env19163 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound19163 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env19164 : List Nat := [2,4,8,16,32,64,9,256,64,1024,1280,309,1384,81,1124,343,1141,17,1024,1125,1345,113,16,82,1385,65,309,1061,357,65,352,1092,256,1092,1077,65]

theorem envBound19164 : H12AffineFastState.Bounded env19164 := by
  intro p hp
  have h : env19164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19163_19164 : H12AffineEnvironment.transform 8 64 env19163 = env19164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env19163 == env19164) = true)

theorem identity19164 : scanCanonicalize (H12AffineFastState.compose env19164 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19164 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env19165 : List Nat := [2,4,8,16,32,64,9,36,64,1024,1060,17,1100,81,1124,115,1141,17,1024,1125,1125,113,16,82,1101,65,17,1061,65,65,68,1092,36,1092,1077,65]

theorem envBound19165 : H12AffineFastState.Bounded env19165 := by
  intro p hp
  have h : env19165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19164_19165 : H12AffineEnvironment.transform 7 36 env19164 = env19165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19164 == env19165) = true)

theorem identity19165 : scanCanonicalize (H12AffineFastState.compose env19165 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19165 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env19166 : List Nat := [2,4,8,16,32,64,9,36,64,52,16,17,120,81,80,115,65,17,52,81,81,113,16,82,121,65,17,17,65,65,68,112,36,112,1,65]

theorem envBound19166 : H12AffineFastState.Bounded env19166 := by
  intro p hp
  have h : env19166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19165_19166 : H12AffineEnvironment.transform 9 52 env19165 = env19166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19165 == env19166) = true)

theorem identity19166 : scanCanonicalize (H12AffineFastState.compose env19166 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound19166 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19167 : List Nat := [2,4,8,16,32,0,9,36,0,52,16,17,56,17,16,51,1,17,52,17,17,49,16,18,57,1,17,17,1,1,4,48,36,48,1,1]

theorem envBound19167 : H12AffineFastState.Bounded env19167 := by
  intro p hp
  have h : env19167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19166_19167 : H12AffineEnvironment.transform 5 0 env19166 = env19167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env19166 == env19167) = true)

def env19168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,8388608,8887585,8328,65,4218145,8393985,8804860,8830976,399664,12645452,256,21793,46212,474855]

theorem envBound19168 : H12AffineFastState.Bounded env19168 := by
  intro p hp
  have h : env19168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19076_19168 : H12AffineEnvironment.transform 23 8887585 env19076 = env19168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887585 env19076 == env19168) = true)

def env19169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452648,95497,8328,65,4218145,458025,45524,10280,399664,4594788,256,21793,46212,474855]

theorem envBound19169 : H12AffineFastState.Bounded env19169 := by
  intro p hp
  have h : env19169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19168_19169 : H12AffineEnvironment.transform 22 452648 env19168 = env19169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env19168 == env19169) = true)

def env19170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452648,95497,8328,65,292257,458025,45524,10280,399664,144612,256,21793,46212,474855]

theorem envBound19170 : H12AffineFastState.Bounded env19170 := by
  intro p hp
  have h : env19170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19169_19170 : H12AffineEnvironment.transform 21 272512 env19169 = env19170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19169 == env19170) = true)

theorem identity19170 : scanCanonicalize (H12AffineFastState.compose env19170 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound19170 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4160,144492,62660,95497,8328,65,158029,57797,45524,10280,1500,144612,256,21793,46212,74251]

theorem envBound19171 : H12AffineFastState.Bounded env19171 := by
  intro p hp
  have h : env19171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19170_19171 : H12AffineEnvironment.transform 17 138476 env19170 = env19171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env19170 == env19171) = true)

theorem identity19171 : scanCanonicalize (H12AffineFastState.compose env19171 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19171 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138476,1024,32769,4160,144492,62660,21763,8328,65,158029,57797,45524,10280,1500,144612,256,21793,46212,513]

theorem envBound19172 : H12AffineFastState.Bounded env19172 := by
  intro p hp
  have h : env19172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19171_19172 : H12AffineEnvironment.transform 15 8202 env19171 = env19172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19171 == env19172) = true)

theorem identity19172 : scanCanonicalize (H12AffineFastState.compose env19172 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound19172 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env19173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,2421,1024,32769,4160,8693,62660,21763,8328,65,31956,57797,45524,10280,1500,8573,256,21793,46212,513]

theorem envBound19173 : H12AffineFastState.Bounded env19173 := by
  intro p hp
  have h : env19173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19172_19173 : H12AffineEnvironment.transform 16 5529 env19172 = env19173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env19172 == env19173) = true)

theorem identity19173 : scanCanonicalize (H12AffineFastState.compose env19173 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound19173 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env19174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8202,5529,2421,1024,21761,4160,8693,8644,21763,8328,65,31956,13509,25812,10280,1500,8573,256,21793,24964,513]

theorem envBound19174 : H12AffineFastState.Bounded env19174 := by
  intro p hp
  have h : env19174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19173_19174 : H12AffineEnvironment.transform 14 21760 env19173 = env19174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env19173 == env19174) = true)

theorem identity19174 : scanCanonicalize (H12AffineFastState.compose env19174 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19174 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env19175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,136,8202,5529,2421,1024,137,4160,8693,8644,139,8328,65,10588,13509,12636,10280,1500,8573,256,169,13324,513]

theorem envBound19175 : H12AffineFastState.Bounded env19175 := by
  intro p hp
  have h : env19175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19174_19175 : H12AffineEnvironment.transform 13 5512 env19174 = env19175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19174 == env19175) = true)

def env19176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452648,95497,8328,65,292256,458025,45524,10280,399664,144613,256,21793,46212,474855]

theorem envBound19176 : H12AffineFastState.Bounded env19176 := by
  intro p hp
  have h : env19176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19169_19176 : H12AffineEnvironment.transform 21 272513 env19169 = env19176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19169 == env19176) = true)

theorem identity19176 : scanCanonicalize (H12AffineFastState.compose env19176 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound19176 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396460,272513,400636,95497,8328,65,292256,395773,17664,10280,399664,144613,256,21793,16464,474855]

theorem envBound19177 : H12AffineFastState.Bounded env19177 := by
  intro p hp
  have h : env19177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19176_19177 : H12AffineEnvironment.transform 14 29908 env19176 = env19177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env19176 == env19177) = true)

def env19178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140300,33,144476,95497,8328,65,23808,139613,17664,10280,143760,144613,256,21793,16464,202311]

theorem envBound19178 : H12AffineFastState.Bounded env19178 := by
  intro p hp
  have h : env19178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19177_19178 : H12AffineEnvironment.transform 17 10400 env19177 = env19178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19177 == env19178) = true)

theorem identity19178 : scanCanonicalize (H12AffineFastState.compose env19178 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound19178 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env19179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,5528,10400,1024,29909,12692,33,8644,95497,8328,65,23808,13509,17664,10280,9224,8573,256,21793,16464,66527]

theorem envBound19179 : H12AffineFastState.Bounded env19179 := by
  intro p hp
  have h : env19179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19178_19179 : H12AffineEnvironment.transform 16 5528 env19178 = env19179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env19178 == env19179) = true)

theorem identity19179 : scanCanonicalize (H12AffineFastState.compose env19179 (packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound19179 : packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env19180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,65536,5528,2421,1024,21760,4161,33,17,87260,349,65,23808,5392,17664,2557,1501,168,256,21793,16464,66527]

theorem envBound19180 : H12AffineFastState.Bounded env19180 := by
  intro p hp
  have h : env19180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19179_19180 : H12AffineEnvironment.transform 12 469 env19179 = env19180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env19179 == env19180) = true)

theorem identity19180 : scanCanonicalize (H12AffineFastState.compose env19180 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19180 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env19181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,65536,5528,2421,1024,136,4161,33,17,65876,349,65,2184,5392,4232,2557,1501,168,256,169,5592,66527]

theorem envBound19181 : H12AffineFastState.Bounded env19181 := by
  intro p hp
  have h : env19181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19180_19181 : H12AffineEnvironment.transform 13 5512 env19180 = env19181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19180 == env19181) = true)

theorem identity19181 : scanCanonicalize (H12AffineFastState.compose env19181 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound19181 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,478,5528,2421,1024,136,4161,33,17,138,349,65,2184,5392,4232,2557,1501,168,256,169,5592,513]

theorem envBound19182 : H12AffineFastState.Bounded env19182 := by
  intro p hp
  have h : env19182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19181_19182 : H12AffineEnvironment.transform 15 478 env19181 = env19182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env19181 == env19182) = true)

def env19183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140301,32,144477,95497,8328,65,23809,139612,17664,10280,143761,144613,256,21793,16464,202310]

theorem envBound19183 : H12AffineFastState.Bounded env19183 := by
  intro p hp
  have h : env19183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19177_19183 : H12AffineEnvironment.transform 17 10401 env19177 = env19183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19177 == env19183) = true)

theorem identity19183 : scanCanonicalize (H12AffineFastState.compose env19183 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound19183 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env19184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,131072,10401,1024,137,140301,32,144477,65877,8328,65,10589,139612,12636,10280,143761,144613,256,8573,13324,202310]

theorem envBound19184 : H12AffineFastState.Bounded env19184 := by
  intro p hp
  have h : env19184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19183_19184 : H12AffineEnvironment.transform 13 13404 env19183 = env19184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env19183 == env19184) = true)

theorem identity19184 : scanCanonicalize (H12AffineFastState.compose env19184 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound19184 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env19185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,70727,10401,1024,137,77898,32,73754,65877,8328,65,10589,79131,12636,10280,75222,73890,256,8573,13324,513]

theorem envBound19185 : H12AffineFastState.Bounded env19185 := by
  intro p hp
  have h : env19185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19184_19185 : H12AffineEnvironment.transform 16 70727 env19184 = env19185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env19184 == env19185) = true)

theorem identity19185 : scanCanonicalize (H12AffineFastState.compose env19185 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19185 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,65536,70727,10280,1024,0,77898,32,73754,65877,8193,65,10589,79131,12636,10280,75103,73771,256,8573,13324,513]

theorem envBound19186 : H12AffineFastState.Bounded env19186 := by
  intro p hp
  have h : env19186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19185_19186 : H12AffineEnvironment.transform 6 9 env19185 = env19186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19185 == env19186) = true)

theorem identity19186 : scanCanonicalize (H12AffineFastState.compose env19186 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19186 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env19187 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,1,65536,69975,10280,272,0,77898,32,73754,65877,8193,65,10589,77835,12636,10280,73807,73771,256,8573,12572,513]

theorem envBound19187 : H12AffineFastState.Bounded env19187 := by
  intro p hp
  have h : env19187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19186_19187 : H12AffineEnvironment.transform 9 272 env19186 = env19187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19186 == env19187) = true)

theorem identity19187 : scanCanonicalize (H12AffineFastState.compose env19187 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound19187 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19188 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,8192,10588,1,65536,67911,10280,272,0,75866,32,73754,65877,8193,65,10589,75803,10572,10280,73807,73771,256,8573,10508,513]

theorem envBound19188 : H12AffineFastState.Bounded env19188 := by
  intro p hp
  have h : env19188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19187_19188 : H12AffineEnvironment.transform 11 2064 env19187 = env19188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env19187 == env19188) = true)

theorem identity19188 : scanCanonicalize (H12AffineFastState.compose env19188 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound19188 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19189 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,8192,10588,1,342,2065,10280,272,0,10508,32,8524,3,8193,65,10589,10573,10572,10280,8473,8573,256,8573,10508,513]

theorem envBound19189 : H12AffineFastState.Bounded env19189 := by
  intro p hp
  have h : env19189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19188_19189 : H12AffineEnvironment.transform 15 342 env19188 = env19189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env19188 == env19189) = true)

def env19190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,4194304,452649,95496,8328,65,4218145,458024,45525,10281,399664,4594789,256,21793,46212,474855]

theorem envBound19190 : H12AffineFastState.Bounded env19190 := by
  intro p hp
  have h : env19190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19168_19190 : H12AffineEnvironment.transform 22 452649 env19168 = env19190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env19168 == env19190) = true)

def env19191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272512,452649,95496,8328,65,292257,458024,45525,10281,399664,144613,256,21793,46212,474855]

theorem envBound19191 : H12AffineFastState.Bounded env19191 := by
  intro p hp
  have h : env19191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19190_19191 : H12AffineEnvironment.transform 21 272512 env19190 = env19191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env19190 == env19191) = true)

end H12CloudChart1