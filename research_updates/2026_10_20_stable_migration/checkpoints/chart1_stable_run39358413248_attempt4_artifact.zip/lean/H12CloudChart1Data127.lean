import H12CloudChart1Data126

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env32224 : List Nat := [2,4,3,1,0,1,3,5,0,4,1,1,3,0,1,2,0,1,5,0,0,1,0,3,3,1,1,1,0,1,5,0,4,0,1,1]

theorem envBound32224 : H12AffineFastState.Bounded env32224 := by
  intro p hp
  have h : env32224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32223_32224 : H12AffineEnvironment.transform 3 1 env32223 = env32224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32223 == env32224) = true)

def env32225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272392,73755,98644,8193,64,100694,79130,17665,335882,75103,392287,257,21792,46092,513]

theorem envBound32225 : H12AffineFastState.Bounded env32225 := by
  intro p hp
  have h : env32225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32209_32225 : H12AffineEnvironment.transform 6 9 env32209 = env32225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32209 == env32225) = true)

theorem identity32225 : scanCanonicalize (H12AffineFastState.compose env32225 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound32225 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49168,262144,1025,32769,36929,272392,32784,8543,8193,64,10589,38161,17665,294913,34132,285780,257,21792,46092,513]

theorem envBound32226 : H12AffineFastState.Bounded env32226 := by
  intro p hp
  have h : env32226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32225_32226 : H12AffineEnvironment.transform 15 40971 env32225 = env32226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env32225 == env32226) = true)

theorem identity32226 : scanCanonicalize (H12AffineFastState.compose env32226 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound32226 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1345,9546,17745,262144,1025,1344,5376,272392,1361,8543,8193,64,10589,4176,17665,263488,21,285780,257,21792,12621,513]

theorem envBound32227 : H12AffineFastState.Bounded env32227 := by
  intro p hp
  have h : env32227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32226_32227 : H12AffineEnvironment.transform 14 1345 env32226 = env32227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env32226 == env32227) = true)

theorem identity32227 : scanCanonicalize (H12AffineFastState.compose env32227 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound32227 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1345,9546,4096,262144,1025,1344,5376,272392,1361,8543,8193,64,10589,4176,4176,263488,21,264453,257,113,12621,513]

theorem envBound32228 : H12AffineFastState.Bounded env32228 := by
  intro p hp
  have h : env32228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32227_32228 : H12AffineEnvironment.transform 13 5457 env32227 = env32228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env32227 == env32228) = true)

theorem identity32228 : scanCanonicalize (H12AffineFastState.compose env32228 (packedSelected [17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound32228 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env32229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1345,9546,4096,2421,1025,1344,5376,8573,1361,8543,8193,64,10589,4176,4176,3125,21,112,257,113,12621,513]

theorem envBound32229 : H12AffineFastState.Bounded env32229 := by
  intro p hp
  have h : env32229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32228_32229 : H12AffineEnvironment.transform 17 2421 env32228 = env32229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env32228 == env32229) = true)

theorem identity32229 : scanCanonicalize (H12AffineFastState.compose env32229 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32229 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32230 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4405,293,8494,4096,2421,101,292,4452,8573,309,8543,8193,64,10589,4176,4176,2129,21,112,257,113,12621,513]

theorem envBound32230 : H12AffineFastState.Bounded env32230 := by
  intro p hp
  have h : env32230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32229_32230 : H12AffineEnvironment.transform 9 100 env32229 = env32230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32229 == env32230) = true)

theorem identity32230 : scanCanonicalize (H12AffineFastState.compose env32230 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound32230 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env32231 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,8192,2421,293,8494,2112,2421,101,292,2340,8573,309,8543,8193,64,10589,2064,2064,2129,21,112,257,113,10509,513]

theorem envBound32231 : H12AffineFastState.Bounded env32231 := by
  intro p hp
  have h : env32231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32230_32231 : H12AffineEnvironment.transform 11 2112 env32230 = env32231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env32230 == env32231) = true)

theorem identity32231 : scanCanonicalize (H12AffineFastState.compose env32231 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32231 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env32232 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,41,2421,293,263,2112,2421,101,292,2340,340,309,374,40,64,2420,2064,2064,2129,21,112,257,113,2340,513]

theorem envBound32232 : H12AffineFastState.Bounded env32232 := by
  intro p hp
  have h : env32232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32231_32232 : H12AffineEnvironment.transform 12 41 env32231 = env32232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32231 == env32232) = true)

theorem identity32232 : scanCanonicalize (H12AffineFastState.compose env32232 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32232 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32233 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2112,41,2128,0,34,2112,2128,101,1,2049,113,16,83,40,64,2129,2064,2064,2129,21,112,36,113,2049,513]

theorem envBound32233 : H12AffineFastState.Bounded env32233 := by
  intro p hp
  have h : env32233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32232_32233 : H12AffineEnvironment.transform 7 37 env32232 = env32233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32232 == env32233) = true)

theorem identity32233 : scanCanonicalize (H12AffineFastState.compose env32233 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32234 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,41,2048,0,34,2064,2048,53,1,2049,33,16,3,40,16,2049,2064,2064,2049,21,32,36,33,2049,513]

theorem envBound32234 : H12AffineFastState.Bounded env32234 := by
  intro p hp
  have h : env32234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32233_32234 : H12AffineEnvironment.transform 5 16 env32233 = env32234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32233 == env32234) = true)

theorem identity32234 : scanCanonicalize (H12AffineFastState.compose env32234 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound32234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32235 : List Nat := [2,4,8,16,32,16,9,37,512,52,17,1,41,17,0,34,1,17,53,1,16,33,16,3,40,16,16,1,1,16,21,32,36,33,16,513]

theorem envBound32235 : H12AffineFastState.Bounded env32235 := by
  intro p hp
  have h : env32235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32234_32235 : H12AffineEnvironment.transform 10 17 env32234 = env32235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env32234 == env32235) = true)

theorem identity32235 : scanCanonicalize (H12AffineFastState.compose env32235 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound32235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32236 : List Nat := [2,4,8,16,32,16,9,37,26,52,17,1,41,17,0,34,1,17,53,1,16,33,16,3,40,16,16,1,1,16,21,32,36,33,16,27]

theorem envBound32236 : H12AffineFastState.Bounded env32236 := by
  intro p hp
  have h : env32236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32235_32236 : H12AffineEnvironment.transform 8 26 env32235 = env32236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env32235 == env32236) = true)

def env32237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590876,2098513,17664,2363456,2102684,6349852,257,21792,46213,2175563]

theorem envBound32237 : H12AffineFastState.Bounded env32237 := by
  intro p hp
  have h : env32237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32192_32237 : H12AffineEnvironment.transform 16 49169 env32192 = env32237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32192 == env32237) = true)

def env32238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144540,2098513,17664,2363456,2102684,2411676,257,21792,46213,2175563]

theorem envBound32238 : H12AffineFastState.Bounded env32238 := by
  intro p hp
  have h : env32238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32237_32238 : H12AffineEnvironment.transform 21 272512 env32237 = env32238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32237 == env32238) = true)

theorem identity32238 : scanCanonicalize (H12AffineFastState.compose env32238 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound32238 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49169,262144,1025,32769,2097152,272512,2101328,21762,8328,64,2144540,2098513,17664,2363456,2102684,2411676,257,21792,46213,2156181]

theorem envBound32239 : H12AffineFastState.Bounded env32239 := by
  intro p hp
  have h : env32239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32238_32239 : H12AffineEnvironment.transform 15 54494 env32238 = env32239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env32238 == env32239) = true)

def env32240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1025,32769,2097152,272392,2101328,21762,8192,64,2144540,2098513,17664,2363456,2102548,2411540,257,21792,46093,2156061]

theorem envBound32240 : H12AffineFastState.Bounded env32240 := by
  intro p hp
  have h : env32240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32239_32240 : H12AffineEnvironment.transform 6 8 env32239 = env32240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32239 == env32240) = true)

theorem identity32240 : scanCanonicalize (H12AffineFastState.compose env32240 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound32240 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env32241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1025,32769,25629,272392,29773,21762,8192,64,56577,24908,17664,291933,28937,305161,257,21792,46093,33280]

theorem envBound32241 : H12AffineFastState.Bounded env32241 := by
  intro p hp
  have h : env32241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32240_32241 : H12AffineEnvironment.transform 20 25629 env32240 = env32241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env32240 == env32241) = true)

theorem identity32241 : scanCanonicalize (H12AffineFastState.compose env32241 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound32241 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env32242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,43049,1025,32769,25629,32801,29773,21762,8192,64,56577,24908,17664,56436,28937,32,257,21792,46093,33280]

theorem envBound32242 : H12AffineFastState.Bounded env32242 := by
  intro p hp
  have h : env32242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32241_32242 : H12AffineEnvironment.transform 17 43049 env32241 = env32242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env32241 == env32242) = true)

theorem identity32242 : scanCanonicalize (H12AffineFastState.compose env32242 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32242 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env32243 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,43049,1025,32769,25629,32801,29725,21762,8192,16,56577,24860,17664,56356,28937,32,257,21792,46093,33280]

theorem envBound32243 : H12AffineFastState.Bounded env32243 := by
  intro p hp
  have h : env32243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32242_32243 : H12AffineEnvironment.transform 5 16 env32242 = env32243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32242 == env32243) = true)

theorem identity32243 : scanCanonicalize (H12AffineFastState.compose env32243 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32243 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env32244 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,40970,46109,43049,1025,32769,4113,32801,17,8462,8192,16,43277,5392,12556,43048,1285,32,257,8492,46093,33280]

theorem envBound32244 : H12AffineFastState.Bounded env32244 := by
  intro p hp
  have h : env32244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32243_32244 : H12AffineEnvironment.transform 13 13324 env32243 = env32244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32243 == env32244) = true)

theorem identity32244 : scanCanonicalize (H12AffineFastState.compose env32244 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32244 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32245 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,8203,13340,10280,1025,0,4113,32,17,8462,8192,16,10508,5392,12556,10281,1285,32,257,8492,13324,513]

theorem envBound32245 : H12AffineFastState.Bounded env32245 := by
  intro p hp
  have h : env32245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32244_32245 : H12AffineEnvironment.transform 14 1 env32244 = env32245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32244 == env32245) = true)

theorem identity32245 : scanCanonicalize (H12AffineFastState.compose env32245 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7740) := by decide +kernel

theorem selectedBound32245 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32246 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7740,2608,1,7735,2592,5652,1025,0,4113,32,17,7986,7740,16,5936,5392,3888,5653,1285,32,257,7952,2608,513]

theorem envBound32246 : H12AffineFastState.Bounded env32246 := by
  intro p hp
  have h : env32246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32245_32246 : H12AffineEnvironment.transform 12 7740 env32245 = env32246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7740 env32245 == env32246) = true)

theorem identity32246 : scanCanonicalize (H12AffineFastState.compose env32246 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound32246 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32247 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2608,1,262,2592,2341,1025,0,3872,32,17,3,269,16,2049,2593,3888,2340,1285,32,257,33,2608,513]

theorem envBound32247 : H12AffineFastState.Bounded env32247 := by
  intro p hp
  have h : env32247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32246_32247 : H12AffineEnvironment.transform 11 3889 env32246 = env32247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env32246 == env32247) = true)

theorem identity32247 : scanCanonicalize (H12AffineFastState.compose env32247 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound32247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32248 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1588,261,269,1028,1,262,1044,1809,1025,0,276,32,17,3,269,16,1589,1045,260,1808,1285,32,257,33,1028,513]

theorem envBound32248 : H12AffineFastState.Bounded env32248 := by
  intro p hp
  have h : env32248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32247_32248 : H12AffineEnvironment.transform 10 1588 env32247 = env32248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env32247 == env32248) = true)

theorem identity32248 : scanCanonicalize (H12AffineFastState.compose env32248 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound32248 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32249 : List Nat := [2,4,8,16,32,16,8,256,512,784,292,261,269,788,1,262,772,1,785,0,276,32,17,3,269,16,293,773,260,0,533,32,257,33,788,513]

theorem envBound32249 : H12AffineFastState.Bounded env32249 := by
  intro p hp
  have h : env32249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32248_32249 : H12AffineEnvironment.transform 9 784 env32248 = env32249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env32248 == env32249) = true)

theorem identity32249 : scanCanonicalize (H12AffineFastState.compose env32249 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32249 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32250 : List Nat := [2,4,8,0,32,0,8,256,512,768,292,261,269,772,1,262,772,1,769,0,260,32,1,3,269,0,293,773,260,0,517,32,257,33,772,513]

theorem envBound32250 : H12AffineFastState.Bounded env32250 := by
  intro p hp
  have h : env32250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32249_32250 : H12AffineEnvironment.transform 3 0 env32249 = env32250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32249 == env32250) = true)

theorem identity32250 : scanCanonicalize (H12AffineFastState.compose env32250 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound32250 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32251 : List Nat := [2,4,8,0,32,0,8,256,260,4,292,261,269,0,1,262,0,1,5,0,260,32,1,3,269,0,293,1,260,0,257,32,257,33,0,261]

theorem envBound32251 : H12AffineFastState.Bounded env32251 := by
  intro p hp
  have h : env32251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32250_32251 : H12AffineEnvironment.transform 8 260 env32250 = env32251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env32250 == env32251) = true)

theorem identity32251 : scanCanonicalize (H12AffineFastState.compose env32251 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32251 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env32252 : List Nat := [2,4,8,0,1,0,8,256,260,4,261,261,269,0,1,262,0,1,5,0,260,1,1,3,269,0,260,1,260,0,257,1,257,0,0,261]

theorem envBound32252 : H12AffineFastState.Bounded env32252 := by
  intro p hp
  have h : env32252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32251_32252 : H12AffineEnvironment.transform 4 1 env32251 = env32252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32251 == env32252) = true)

theorem identity32252 : scanCanonicalize (H12AffineFastState.compose env32252 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32253 : List Nat := [2,4,8,0,1,0,8,4,0,4,1,1,9,0,1,2,0,1,5,0,0,1,1,3,9,0,0,1,0,0,5,1,5,0,0,1]

theorem envBound32253 : H12AffineFastState.Bounded env32253 := by
  intro p hp
  have h : env32253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32252_32253 : H12AffineEnvironment.transform 7 4 env32252 = env32253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32252 == env32253) = true)

theorem identity32253 : scanCanonicalize (H12AffineFastState.compose env32253 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32253 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32254 : List Nat := [2,4,2,0,1,0,2,4,0,4,1,1,3,0,1,2,0,1,5,0,0,1,1,3,3,0,0,1,0,0,5,1,5,0,0,1]

theorem envBound32254 : H12AffineFastState.Bounded env32254 := by
  intro p hp
  have h : env32254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32253_32254 : H12AffineEnvironment.transform 2 2 env32253 = env32254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32253 == env32254) = true)

def env32255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272393,2101328,21762,8193,64,2144540,2098513,17664,2363456,2102549,2411541,257,21792,46092,2156060]

theorem envBound32255 : H12AffineFastState.Bounded env32255 := by
  intro p hp
  have h : env32255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32239_32255 : H12AffineEnvironment.transform 6 9 env32239 = env32255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32239 == env32255) = true)

theorem identity32255 : scanCanonicalize (H12AffineFastState.compose env32255 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound32255 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env32256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29823,24633,262144,1025,8233,2097152,272393,2101328,21762,8193,64,2103604,2098513,17664,2363456,2102549,2387005,257,21792,5156,2115124]

theorem envBound32256 : H12AffineFastState.Bounded env32256 := by
  intro p hp
  have h : env32256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32255_32256 : H12AffineEnvironment.transform 14 8232 env32255 = env32256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env32255 == env32256) = true)

theorem identity32256 : scanCanonicalize (H12AffineFastState.compose env32256 (packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound32256 : packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS < 2^1333 := by decide +kernel

def env32257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29823,24633,262144,1025,8233,281653,272393,285797,21762,8193,64,283905,280932,17664,23669,284960,8200,257,21792,5156,264705]

theorem envBound32257 : H12AffineFastState.Bounded env32257 := by
  intro p hp
  have h : env32257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32256_32257 : H12AffineEnvironment.transform 20 281653 env32256 = env32257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env32256 == env32257) = true)

theorem identity32257 : scanCanonicalize (H12AffineFastState.compose env32257 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound32257 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29823,24633,2420,1025,8233,17729,8573,21777,21762,8193,64,23669,16400,17664,23669,20564,8200,257,21792,5156,885]

theorem envBound32258 : H12AffineFastState.Bounded env32258 := by
  intro p hp
  have h : env32258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32257_32258 : H12AffineEnvironment.transform 17 2420 env32257 = env32258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env32257 == env32258) = true)

theorem identity32258 : scanCanonicalize (H12AffineFastState.compose env32258 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound32258 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8232,343,5393,2420,1025,8233,12393,8573,8249,8234,8193,64,10589,13624,12328,10589,9596,8200,257,8200,5156,885]

theorem envBound32259 : H12AffineFastState.Bounded env32259 := by
  intro p hp
  have h : env32259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32258_32259 : H12AffineEnvironment.transform 13 13608 env32258 = env32259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env32258 == env32259) = true)

theorem identity32259 : scanCanonicalize (H12AffineFastState.compose env32259 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32259 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,0,343,5393,2420,1025,1,4161,341,17,2,41,64,2421,5392,4096,2421,1364,32,257,32,5156,885]

theorem envBound32260 : H12AffineFastState.Bounded env32260 := by
  intro p hp
  have h : env32260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32259_32260 : H12AffineEnvironment.transform 12 40 env32259 = env32260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32259 == env32260) = true)

theorem identity32260 : scanCanonicalize (H12AffineFastState.compose env32260 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32260 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32261 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8,5376,0,343,5393,2388,1025,1,4161,341,17,2,9,64,2389,5392,4096,2389,1364,0,257,0,5124,853]

theorem envBound32261 : H12AffineFastState.Bounded env32261 := by
  intro p hp
  have h : env32261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32260_32261 : H12AffineEnvironment.transform 4 0 env32260 = env32261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32260 == env32261) = true)

theorem identity32261 : scanCanonicalize (H12AffineFastState.compose env32261 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound32261 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32262 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1028,8,260,0,343,277,2388,1025,1,1093,341,17,2,9,64,2389,276,1028,2389,1364,0,257,0,0,853]

theorem envBound32262 : H12AffineFastState.Bounded env32262 := by
  intro p hp
  have h : env32262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32261_32262 : H12AffineEnvironment.transform 11 1028 env32261 = env32262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env32261 == env32262) = true)

theorem identity32262 : scanCanonicalize (H12AffineFastState.compose env32262 (packedSelected [0,4,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound32262 : packedSelected [0,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env32263 : List Nat := [2,4,8,16,0,64,9,256,512,10,2048,14,8,260,0,343,277,2388,11,1,79,341,17,2,9,64,2389,276,14,2389,350,0,257,0,0,853]

theorem envBound32263 : H12AffineFastState.Bounded env32263 := by
  intro p hp
  have h : env32263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32262_32263 : H12AffineEnvironment.transform 9 10 env32262 = env32263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env32262 == env32263) = true)

theorem identity32263 : scanCanonicalize (H12AffineFastState.compose env32263 (packedSelected [3,5,6,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound32263 : packedSelected [3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env32264 : List Nat := [2,4,8,16,0,27,9,256,512,10,2048,14,8,260,0,268,277,2319,11,1,20,270,17,2,9,27,2318,276,14,2318,261,0,257,0,0,782]

theorem envBound32264 : H12AffineFastState.Bounded env32264 := by
  intro p hp
  have h : env32264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32263_32264 : H12AffineEnvironment.transform 5 27 env32263 = env32264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env32263 == env32264) = true)

theorem identity32264 : scanCanonicalize (H12AffineFastState.compose env32264 (packedSelected [2,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32264 : packedSelected [2,7,12] rootPS < 2^1333 := by decide +kernel

def env32265 : List Nat := [2,4,8,16,0,27,9,256,512,10,0,14,8,260,0,268,277,271,11,1,20,270,17,2,9,27,270,276,14,270,261,0,257,0,0,782]

theorem envBound32265 : H12AffineFastState.Bounded env32265 := by
  intro p hp
  have h : env32265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32264_32265 : H12AffineEnvironment.transform 10 0 env32264 = env32265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32264 == env32265) = true)

theorem identity32265 : scanCanonicalize (H12AffineFastState.compose env32265 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32265 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env32266 : List Nat := [2,4,8,0,0,11,9,256,512,10,0,14,8,260,0,268,261,271,11,1,4,270,1,2,9,11,270,260,14,270,261,0,257,0,0,782]

theorem envBound32266 : H12AffineFastState.Bounded env32266 := by
  intro p hp
  have h : env32266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32265_32266 : H12AffineEnvironment.transform 3 0 env32265 = env32266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32265 == env32266) = true)

theorem identity32266 : scanCanonicalize (H12AffineFastState.compose env32266 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound32266 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env32267 : List Nat := [2,4,8,0,0,11,9,1,512,10,0,14,8,5,0,13,4,14,11,1,4,15,1,2,9,11,15,5,14,15,4,0,0,0,0,527]

theorem envBound32267 : H12AffineFastState.Bounded env32267 := by
  intro p hp
  have h : env32267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32266_32267 : H12AffineEnvironment.transform 7 1 env32266 = env32267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env32266 == env32267) = true)

theorem identity32267 : scanCanonicalize (H12AffineFastState.compose env32267 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32267 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32268 : List Nat := [2,4,3,0,0,0,2,1,512,1,0,5,3,5,0,6,4,5,0,1,4,4,1,2,2,0,4,5,5,4,4,0,0,0,0,516]

theorem envBound32268 : H12AffineFastState.Bounded env32268 := by
  intro p hp
  have h : env32268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32267_32268 : H12AffineEnvironment.transform 2 3 env32267 = env32268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32267 == env32268) = true)

theorem identity32268 : scanCanonicalize (H12AffineFastState.compose env32268 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32269 : List Nat := [2,0,3,0,0,0,2,1,512,1,0,1,3,1,0,2,0,1,0,1,0,0,1,2,2,0,0,1,1,0,0,0,0,0,0,512]

theorem envBound32269 : H12AffineFastState.Bounded env32269 := by
  intro p hp
  have h : env32269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32268_32269 : H12AffineEnvironment.transform 1 0 env32268 = env32269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32268 == env32269) = true)

theorem identity32269 : scanCanonicalize (H12AffineFastState.compose env32269 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32270 : List Nat := [1,0,0,0,0,0,1,1,512,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,512]

theorem envBound32270 : H12AffineFastState.Bounded env32270 := by
  intro p hp
  have h : env32270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32269_32270 : H12AffineEnvironment.transform 0 1 env32269 = env32270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32269 == env32270) = true)

def env32271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144541,2098513,17664,2363456,2102684,2411677,257,21792,46213,2175563]

theorem envBound32271 : H12AffineFastState.Bounded env32271 := by
  intro p hp
  have h : env32271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32237_32271 : H12AffineEnvironment.transform 21 272513 env32237 = env32271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32237 == env32271) = true)

theorem identity32271 : scanCanonicalize (H12AffineFastState.compose env32271 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound32271 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115871,272513,120015,98780,8328,64,97666,115150,17664,382175,119043,329730,257,21792,46213,63188]

theorem envBound32272 : H12AffineFastState.Bounded env32272 := by
  intro p hp
  have h : env32272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32271_32272 : H12AffineEnvironment.transform 20 115871 env32271 = env32272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env32271 == env32272) = true)

def env32273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115735,272393,119879,98644,8192,64,97546,115014,17664,382039,119043,329730,257,21792,46093,63068]

theorem envBound32273 : H12AffineFastState.Bounded env32273 := by
  intro p hp
  have h : env32273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32272_32273 : H12AffineEnvironment.transform 6 8 env32272 = env32273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32272 == env32273) = true)

theorem identity32273 : scanCanonicalize (H12AffineFastState.compose env32273 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound32273 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env32274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,5392,262144,1025,21760,69910,272393,65862,87125,8192,64,97546,70727,17664,328022,66562,329730,257,21792,24844,9053]

theorem envBound32274 : H12AffineFastState.Bounded env32274 := by
  intro p hp
  have h : env32274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32273_32274 : H12AffineEnvironment.transform 14 21761 env32273 = env32274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env32273 == env32274) = true)

theorem identity32274 : scanCanonicalize (H12AffineFastState.compose env32274 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound32274 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,5392,76159,1025,21760,69910,65910,65862,87125,8192,64,97546,70727,17664,10281,66562,8573,257,21792,24844,9053]

theorem envBound32275 : H12AffineFastState.Bounded env32275 := by
  intro p hp
  have h : env32275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32274_32275 : H12AffineEnvironment.transform 17 76159 env32274 = env32275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env32274 == env32275) = true)

theorem identity32275 : scanCanonicalize (H12AffineFastState.compose env32275 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32275 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env32276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,5392,2420,1025,21760,12573,8573,8525,29790,8192,64,23809,13388,17664,10281,9225,8573,257,21792,24844,9053]

theorem envBound32276 : H12AffineFastState.Bounded env32276 := by
  intro p hp
  have h : env32276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32275_32276 : H12AffineEnvironment.transform 15 8203 env32275 = env32276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32275 == env32276) = true)

theorem identity32276 : scanCanonicalize (H12AffineFastState.compose env32276 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32276 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8460,8203,5392,2420,1025,8461,12573,8573,8525,83,8192,64,10508,13388,12557,10281,9225,8573,257,8493,5377,9053]

theorem envBound32277 : H12AffineFastState.Bounded env32277 := by
  intro p hp
  have h : env32277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32276_32277 : H12AffineEnvironment.transform 13 13325 env32276 = env32277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32276 == env32277) = true)

theorem identity32277 : scanCanonicalize (H12AffineFastState.compose env32277 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32277 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env32278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1,262,5392,2420,1025,0,4112,112,64,83,269,64,2049,5441,4096,2340,1284,112,257,32,5377,592]

theorem envBound32278 : H12AffineFastState.Bounded env32278 := by
  intro p hp
  have h : env32278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32277_32278 : H12AffineEnvironment.transform 12 269 env32277 = env32278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32277 == env32278) = true)

theorem identity32278 : scanCanonicalize (H12AffineFastState.compose env32278 (packedSelected [0,1,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound32278 : packedSelected [0,1,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env32279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,357,4096,269,5376,1,262,5392,17,1025,0,4112,112,64,83,269,64,356,5441,4096,65,1284,112,257,32,5377,592]

theorem envBound32279 : H12AffineFastState.Bounded env32279 := by
  intro p hp
  have h : env32279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32278_32279 : H12AffineEnvironment.transform 10 357 env32278 = env32279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env32278 == env32279) = true)

theorem identity32279 : scanCanonicalize (H12AffineFastState.compose env32279 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32279 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32280 : List Nat := [2,4,8,16,32,16,8,256,512,1024,309,4096,269,5376,1,262,5392,17,1025,0,4112,32,16,3,269,16,308,5393,4096,17,1284,32,257,32,5377,512]

theorem envBound32280 : H12AffineFastState.Bounded env32280 := by
  intro p hp
  have h : env32280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32279_32280 : H12AffineEnvironment.transform 5 16 env32279 = env32280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32279 == env32280) = true)

theorem identity32280 : scanCanonicalize (H12AffineFastState.compose env32280 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound32280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32281 : List Nat := [2,4,8,16,32,16,8,256,512,1024,309,1328,269,48,1,262,32,17,1025,0,1312,32,16,3,269,16,308,33,1328,17,1284,32,257,32,49,512]

theorem envBound32281 : H12AffineFastState.Bounded env32281 := by
  intro p hp
  have h : env32281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32280_32281 : H12AffineEnvironment.transform 11 1328 env32280 = env32281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env32280 == env32281) = true)

theorem identity32281 : scanCanonicalize (H12AffineFastState.compose env32281 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 283) := by decide +kernel

theorem selectedBound32281 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32282 : List Nat := [2,4,8,16,32,16,8,256,512,283,309,43,269,48,1,262,32,17,282,0,59,32,16,3,269,16,308,33,43,17,31,32,257,32,49,512]

theorem envBound32282 : H12AffineFastState.Bounded env32282 := by
  intro p hp
  have h : env32282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32281_32282 : H12AffineEnvironment.transform 9 283 env32281 = env32282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 283 env32281 == env32282) = true)

theorem identity32282 : scanCanonicalize (H12AffineFastState.compose env32282 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound32282 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32283 : List Nat := [2,4,8,16,32,16,8,63,512,36,10,43,50,48,1,57,32,17,37,0,59,32,16,3,50,16,11,33,43,17,31,32,62,32,49,512]

theorem envBound32283 : H12AffineFastState.Bounded env32283 := by
  intro p hp
  have h : env32283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32282_32283 : H12AffineEnvironment.transform 7 63 env32282 = env32283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env32282 == env32283) = true)

theorem identity32283 : scanCanonicalize (H12AffineFastState.compose env32283 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32283 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32284 : List Nat := [2,4,8,16,0,16,8,31,512,4,10,11,18,16,1,25,0,17,5,0,27,0,16,3,18,16,11,1,11,17,31,0,30,0,17,512]

theorem envBound32284 : H12AffineFastState.Bounded env32284 := by
  intro p hp
  have h : env32284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32283_32284 : H12AffineEnvironment.transform 4 0 env32283 = env32284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32283 == env32284) = true)

def env32285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115734,272392,119878,98645,8193,64,97547,115015,17664,382038,119043,329730,257,21792,46092,63069]

theorem envBound32285 : H12AffineFastState.Bounded env32285 := by
  intro p hp
  have h : env32285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32272_32285 : H12AffineEnvironment.transform 6 9 env32272 = env32285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32272 == env32285) = true)

theorem identity32285 : scanCanonicalize (H12AffineFastState.compose env32285 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound32285 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env32286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,35,49169,262144,1025,32769,50229,272392,54373,33142,8193,64,32040,49508,17664,316533,53536,264225,257,21792,46092,63069]

theorem envBound32286 : H12AffineFastState.Bounded env32286 := by
  intro p hp
  have h : env32286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32285_32286 : H12AffineEnvironment.transform 15 35 env32285 = env32286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env32285 == env32286) = true)

theorem identity32286 : scanCanonicalize (H12AffineFastState.compose env32286 (packedSelected [0,3,4,10,16,22,24,26,27,35] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound32286 : packedSelected [0,3,4,10,16,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env32287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,35,37988,262144,1025,32769,36928,272392,32784,33142,8193,64,10589,38161,4469,294912,34133,264225,257,341,46092,41512]

theorem envBound32287 : H12AffineFastState.Bounded env32287 := by
  intro p hp
  have h : env32287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32286_32287 : H12AffineEnvironment.transform 13 5237 env32286 = env32287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env32286 == env32287) = true)

theorem identity32287 : scanCanonicalize (H12AffineFastState.compose env32287 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32287 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env32288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,35,37988,35189,1025,32769,36928,41341,32784,33142,8193,64,10589,38161,4469,2421,34133,33108,257,341,46092,41512]

theorem envBound32288 : H12AffineFastState.Bounded env32288 := by
  intro p hp
  have h : env32288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32287_32288 : H12AffineEnvironment.transform 17 35189 env32287 = env32288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32287 == env32288) = true)

theorem identity32288 : scanCanonicalize (H12AffineFastState.compose env32288 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32288 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,32768,35,37988,35189,1025,32769,36928,33109,32784,33142,41,64,2421,38161,4469,2421,34133,33108,257,341,37924,33280]

theorem envBound32289 : H12AffineFastState.Bounded env32289 := by
  intro p hp
  have h : env32289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32288_32289 : H12AffineEnvironment.transform 12 40 env32288 = env32289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32288 == env32289) = true)

theorem identity32289 : scanCanonicalize (H12AffineFastState.compose env32289 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32289 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32290 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5237,32768,35,37988,34897,1025,32769,36928,32881,32784,32850,41,64,2129,37941,4177,2129,33905,32880,37,113,37924,33280]

theorem envBound32290 : H12AffineFastState.Bounded env32290 := by
  intro p hp
  have h : env32290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32289_32290 : H12AffineEnvironment.transform 7 36 env32289 = env32290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32289 == env32290) = true)

theorem identity32290 : scanCanonicalize (H12AffineFastState.compose env32290 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound32290 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env32291 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2065,40,3172,32768,35,35957,34897,1025,32769,34897,32881,32784,32850,41,64,2129,35876,2112,2129,33905,32880,37,113,35893,33280]

theorem envBound32291 : H12AffineFastState.Bounded env32291 := by
  intro p hp
  have h : env32291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32290_32291 : H12AffineEnvironment.transform 11 2065 env32290 = env32291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env32290 == env32291) = true)

theorem identity32291 : scanCanonicalize (H12AffineFastState.compose env32291 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32291 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env32292 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,2065,40,2049,32768,35,34832,34897,100,32769,34897,32881,32784,32850,41,64,2129,34881,2112,2129,32788,32880,37,113,34896,33280]

theorem envBound32292 : H12AffineFastState.Bounded env32292 := by
  intro p hp
  have h : env32292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32291_32292 : H12AffineEnvironment.transform 9 101 env32291 = env32292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32291 == env32292) = true)

theorem identity32292 : scanCanonicalize (H12AffineFastState.compose env32292 (packedSelected [2,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32292 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32293 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,2065,40,2049,2048,35,16,81,100,2049,81,2161,2064,2130,41,64,2129,65,2112,2129,2068,2160,37,113,80,2560]

theorem envBound32293 : H12AffineFastState.Bounded env32293 := by
  intro p hp
  have h : env32293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32292_32293 : H12AffineEnvironment.transform 14 2048 env32292 = env32293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env32292 == env32293) = true)

theorem identity32293 : scanCanonicalize (H12AffineFastState.compose env32293 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32293 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env32294 : List Nat := [2,4,8,16,32,64,9,36,512,101,81,64,40,80,81,35,16,81,100,80,81,32,65,3,41,64,0,65,17,0,69,33,37,113,80,593]

theorem envBound32294 : H12AffineFastState.Bounded env32294 := by
  intro p hp
  have h : env32294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32293_32294 : H12AffineEnvironment.transform 10 81 env32293 = env32294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32293 == env32294) = true)

theorem identity32294 : scanCanonicalize (H12AffineFastState.compose env32294 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound32294 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env32295 : List Nat := [2,4,8,16,32,64,9,36,96,101,81,64,40,80,81,35,16,81,100,80,81,32,65,3,41,64,0,65,17,0,69,33,37,113,80,49]

theorem envBound32295 : H12AffineFastState.Bounded env32295 := by
  intro p hp
  have h : env32295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32294_32295 : H12AffineEnvironment.transform 8 96 env32294 = env32295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env32294 == env32295) = true)

theorem identity32295 : scanCanonicalize (H12AffineFastState.compose env32295 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32295 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env32296 : List Nat := [2,4,8,16,0,64,9,4,64,69,81,64,8,80,81,3,16,81,68,80,81,0,65,3,9,64,0,65,17,0,69,1,5,81,80,17]

theorem envBound32296 : H12AffineFastState.Bounded env32296 := by
  intro p hp
  have h : env32296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32295_32296 : H12AffineEnvironment.transform 4 0 env32295 = env32296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32295 == env32296) = true)

theorem identity32296 : scanCanonicalize (H12AffineFastState.compose env32296 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32296 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env32297 : List Nat := [2,4,8,16,0,16,9,4,16,21,1,16,8,0,1,3,16,1,20,0,1,0,17,3,9,16,0,17,17,0,21,1,5,1,0,17]

theorem envBound32297 : H12AffineFastState.Bounded env32297 := by
  intro p hp
  have h : env32297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32296_32297 : H12AffineEnvironment.transform 5 16 env32296 = env32297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32296 == env32297) = true)

theorem identity32297 : scanCanonicalize (H12AffineFastState.compose env32297 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32298 : List Nat := [2,4,8,0,0,0,9,4,0,5,1,0,8,0,1,3,0,1,4,0,1,0,1,3,9,0,0,1,1,0,5,1,5,1,0,1]

theorem envBound32298 : H12AffineFastState.Bounded env32298 := by
  intro p hp
  have h : env32298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32297_32298 : H12AffineEnvironment.transform 3 0 env32297 = env32298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32297 == env32298) = true)

def env32299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound32299 : H12AffineFastState.Bounded env32299 := by
  intro p hp
  have h : env32299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31964_32299 : H12AffineEnvironment.transform 26 30393345 env31964 = env32299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env31964 == env32299) = true)

def env32300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound32300 : H12AffineFastState.Bounded env32300 := by
  intro p hp
  have h : env32300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32299_32300 : H12AffineEnvironment.transform 18 1024 env32299 = env32300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env32299 == env32300) = true)

theorem identity32300 : scanCanonicalize (H12AffineFastState.compose env32300 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601612) := by decide +kernel

theorem selectedBound32300 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601612,8328,64,6685837,8404992,10507600,8830977,2113692,12624205,256,32,57733,2189130]

theorem envBound32301 : H12AffineFastState.Bounded env32301 := by
  intro p hp
  have h : env32301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32300_32301 : H12AffineEnvironment.transform 23 10601612 env32300 = env32301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601612 env32300 == env32301) = true)

def env32302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685837,8393984,10485840,8819969,2102684,12624205,256,32,46213,2175562]

theorem envBound32302 : H12AffineFastState.Bounded env32302 := by
  intro p hp
  have h : env32302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32301_32302 : H12AffineEnvironment.transform 13 5376 env32301 = env32302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32301 == env32302) = true)

def env32303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685837,2098648,4232,2524633,2102684,6336917,256,32,46213,2175562]

theorem envBound32303 : H12AffineFastState.Bounded env32303 := by
  intro p hp
  have h : env32303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32302_32303 : H12AffineEnvironment.transform 22 2101464 env32302 = env32303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env32302 == env32303) = true)

def env32304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491565,2098648,4232,2524633,2102684,2142645,256,32,46213,2175562]

theorem envBound32304 : H12AffineFastState.Bounded env32304 := by
  intro p hp
  have h : env32304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32303_32304 : H12AffineEnvironment.transform 21 32 env32303 = env32304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32303 == env32304) = true)

theorem identity32304 : scanCanonicalize (H12AffineFastState.compose env32304 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32304 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98644,8192,64,2491429,2098512,4096,2524497,2102548,2142525,256,32,46093,2175562]

theorem envBound32305 : H12AffineFastState.Bounded env32305 := by
  intro p hp
  have h : env32305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32304_32305 : H12AffineEnvironment.transform 6 8 env32304 = env32305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32304 == env32305) = true)

def env32306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398437,5392,4096,431377,1364,41341,256,32,46093,74250]

theorem envBound32306 : H12AffineFastState.Bounded env32306 := by
  intro p hp
  have h : env32306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32305_32306 : H12AffineEnvironment.transform 20 4160 env32305 = env32306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32305 == env32306) = true)

theorem identity32306 : scanCanonicalize (H12AffineFastState.compose env32306 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32306 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41311,8192,64,398437,5392,4096,431377,1364,41341,256,32,46093,513]

theorem envBound32307 : H12AffineFastState.Bounded env32307 := by
  intro p hp
  have h : env32307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32306_32307 : H12AffineEnvironment.transform 15 8203 env32306 = env32307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32306 == env32307) = true)

theorem identity32307 : scanCanonicalize (H12AffineFastState.compose env32307 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32307 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,32,16,2,8192,64,398437,5392,4096,406604,1364,32,256,32,5456,513]

theorem envBound32308 : H12AffineFastState.Bounded env32308 := by
  intro p hp
  have h : env32308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32307_32308 : H12AffineEnvironment.transform 14 8541 env32307 = env32308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32307 == env32308) = true)

theorem identity32308 : scanCanonicalize (H12AffineFastState.compose env32308 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32308 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10360,1024,8540,4160,32,16,2,8192,64,146461,5392,4096,138292,1364,32,256,32,5456,513]

theorem envBound32309 : H12AffineFastState.Bounded env32309 := by
  intro p hp
  have h : env32309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32308_32309 : H12AffineEnvironment.transform 17 10360 env32308 = env32309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32308 == env32309) = true)

def env32310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398436,5393,4096,431376,1365,41340,256,32,46093,74251]

theorem envBound32310 : H12AffineFastState.Bounded env32310 := by
  intro p hp
  have h : env32310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32305_32310 : H12AffineEnvironment.transform 20 4161 env32305 = env32310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32305 == env32310) = true)

theorem identity32310 : scanCanonicalize (H12AffineFastState.compose env32310 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32310 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,4161,32,17,98644,8192,64,146508,5393,4096,179512,1365,41340,256,32,46093,74251]

theorem envBound32311 : H12AffineFastState.Bounded env32311 := by
  intro p hp
  have h : env32311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32310_32311 : H12AffineEnvironment.transform 17 10280 env32310 = env32311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32310 == env32311) = true)

def env32312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491564,2098648,4232,2524633,2102684,2142644,256,32,46213,2175562]

theorem envBound32312 : H12AffineFastState.Bounded env32312 := by
  intro p hp
  have h : env32312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32303_32312 : H12AffineEnvironment.transform 21 33 env32303 = env32312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32303 == env32312) = true)

theorem identity32312 : scanCanonicalize (H12AffineFastState.compose env32312 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound32312 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,152,98644,8328,64,398572,5528,4232,431513,1500,41460,256,32,46213,74250]

theorem envBound32313 : H12AffineFastState.Bounded env32313 := by
  intro p hp
  have h : env32313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32312_32313 : H12AffineEnvironment.transform 20 4160 env32312 = env32313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32312 == env32313) = true)

def env32314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398436,5392,4096,431377,1364,41340,256,32,46093,74250]

theorem envBound32314 : H12AffineFastState.Bounded env32314 := by
  intro p hp
  have h : env32314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32313_32314 : H12AffineEnvironment.transform 6 8 env32313 = env32314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32313 == env32314) = true)

theorem identity32314 : scanCanonicalize (H12AffineFastState.compose env32314 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32314 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41311,8192,64,398436,5392,4096,431377,1364,41340,256,32,46093,513]

theorem envBound32315 : H12AffineFastState.Bounded env32315 := by
  intro p hp
  have h : env32315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32314_32315 : H12AffineEnvironment.transform 15 8203 env32314 = env32315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32314 == env32315) = true)

theorem identity32315 : scanCanonicalize (H12AffineFastState.compose env32315 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32315 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,33,16,2,8192,64,398436,5392,4096,406604,1364,33,256,32,5456,513]

theorem envBound32316 : H12AffineFastState.Bounded env32316 := by
  intro p hp
  have h : env32316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32315_32316 : H12AffineEnvironment.transform 14 8541 env32315 = env32316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32315 == env32316) = true)

theorem identity32316 : scanCanonicalize (H12AffineFastState.compose env32316 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32316 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10360,1024,8540,4160,33,16,2,8192,64,146460,5392,4096,138292,1364,33,256,32,5456,513]

theorem envBound32317 : H12AffineFastState.Bounded env32317 := by
  intro p hp
  have h : env32317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32316_32317 : H12AffineEnvironment.transform 17 10360 env32316 = env32317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32316 == env32317) = true)

theorem identity32317 : scanCanonicalize (H12AffineFastState.compose env32317 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound32317 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13388,10360,1024,8540,4160,33,16,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5456,513]

theorem envBound32318 : H12AffineFastState.Bounded env32318 := by
  intro p hp
  have h : env32318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32317_32318 : H12AffineEnvironment.transform 16 13388 env32317 = env32318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env32317 == env32318) = true)

theorem identity32318 : scanCanonicalize (H12AffineFastState.compose env32318 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32318 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5392,2340,1024,0,4160,33,16,2,348,64,2128,5392,4096,2340,1364,33,256,32,5456,513]

theorem envBound32319 : H12AffineFastState.Bounded env32319 := by
  intro p hp
  have h : env32319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32318_32319 : H12AffineEnvironment.transform 12 348 env32318 = env32319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32318 == env32319) = true)

theorem identity32319 : scanCanonicalize (H12AffineFastState.compose env32319 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32319 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32320 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5156,1,115,5172,2048,1024,0,4160,33,16,2,120,64,2128,5172,4096,2048,1136,33,36,32,5236,513]

theorem envBound32320 : H12AffineFastState.Bounded env32320 := by
  intro p hp
  have h : env32320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32319_32320 : H12AffineEnvironment.transform 7 36 env32319 = env32320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32319 == env32320) = true)

theorem identity32320 : scanCanonicalize (H12AffineFastState.compose env32320 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32320 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32321 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,35,5172,2048,1024,0,4112,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound32321 : H12AffineFastState.Bounded env32321 := by
  intro p hp
  have h : env32321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32320_32321 : H12AffineEnvironment.transform 5 16 env32320 = env32321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32320 == env32321) = true)

def env32322 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,1,35,1028,2048,1024,0,32,33,16,2,40,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound32322 : H12AffineFastState.Bounded env32322 := by
  intro p hp
  have h : env32322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32321_32322 : H12AffineEnvironment.transform 11 48 env32321 = env32322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32321 == env32322) = true)

theorem identity32322 : scanCanonicalize (H12AffineFastState.compose env32322 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound32322 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32323 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,48,40,1044,1,35,1028,1077,1024,0,32,33,16,2,40,16,1077,1028,48,1077,1056,33,36,32,1044,513]

theorem envBound32323 : H12AffineFastState.Bounded env32323 := by
  intro p hp
  have h : env32323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32322_32323 : H12AffineEnvironment.transform 10 1077 env32322 = env32323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env32322 == env32323) = true)

def env32324 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,40,32,1,35,48,1,52,0,32,33,16,2,40,16,1,48,48,1,20,33,36,32,32,513]

theorem envBound32324 : H12AffineFastState.Bounded env32324 := by
  intro p hp
  have h : env32324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32323_32324 : H12AffineEnvironment.transform 9 52 env32323 = env32324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32323 == env32324) = true)

def leafEnv32324 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,40,32,1,35,48,1,52,0,32,33,16,2,20,40,1,16,1,48,48,1,20,33,36,32,4,35,32,513,1,32,0]

def active32324 : List Nat := [0,1,2,3,4,8]

def tree32324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32324 : H12WitnessSearch.Good tree32324 := H12GlobalWitnessIndex.good

theorem leafIdentity32324 : H12AffineFastState.composeSystem env32324 rootObs = leafEnv32324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32324 rootObs == leafEnv32324) = true)

theorem terminalChecked32324 : H12PackedTerminal.terminalCheckFast leafEnv32324 active32324 tree32324 = true := by decide +kernel

def env32325 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,33,1,35,49,0,53,0,32,33,16,2,40,16,0,49,48,0,21,33,36,32,33,513]

theorem envBound32325 : H12AffineFastState.Bounded env32325 := by
  intro p hp
  have h : env32325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32323_32325 : H12AffineEnvironment.transform 9 53 env32323 = env32325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32323 == env32325) = true)

theorem identity32325 : scanCanonicalize (H12AffineFastState.compose env32325 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32326 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,48,40,33,1,35,49,0,53,0,32,33,16,2,40,16,0,49,48,0,21,33,36,32,33,43]

theorem envBound32326 : H12AffineFastState.Bounded env32326 := by
  intro p hp
  have h : env32326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32325_32326 : H12AffineEnvironment.transform 8 42 env32325 = env32326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32325 == env32326) = true)

def leafEnv32326 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,48,40,33,1,35,49,0,53,0,32,33,16,2,21,40,1,16,0,49,48,0,21,33,36,32,4,35,33,43,1,32,0]

def active32326 : List Nat := [0,1,2,3,4]

def tree32326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32326 : H12WitnessSearch.Good tree32326 := H12GlobalWitnessIndex.good

theorem leafIdentity32326 : H12AffineFastState.composeSystem env32326 rootObs = leafEnv32326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32326 rootObs == leafEnv32326) = true)

theorem terminalChecked32326 : H12PackedTerminal.terminalCheckFast leafEnv32326 active32326 tree32326 = true := by decide +kernel

def env32327 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,1,35,1029,2048,1024,0,33,33,16,2,40,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound32327 : H12AffineFastState.Bounded env32327 := by
  intro p hp
  have h : env32327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32321_32327 : H12AffineEnvironment.transform 11 49 env32321 = env32327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32321 == env32327) = true)

theorem identity32327 : scanCanonicalize (H12AffineFastState.compose env32327 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32328 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,49,40,1045,1,35,1029,0,1024,0,33,33,16,2,40,16,0,1029,49,0,1056,33,36,32,1045,513]

theorem envBound32328 : H12AffineFastState.Bounded env32328 := by
  intro p hp
  have h : env32328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32327_32328 : H12AffineEnvironment.transform 10 0 env32327 = env32328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32327 == env32328) = true)

def env32329 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,33,1,35,49,0,52,0,33,33,16,2,40,16,0,49,49,0,20,33,36,32,33,513]

theorem envBound32329 : H12AffineFastState.Bounded env32329 := by
  intro p hp
  have h : env32329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32328_32329 : H12AffineEnvironment.transform 9 52 env32328 = env32329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32328 == env32329) = true)

def leafEnv32329 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,33,1,35,49,0,52,0,33,33,16,2,20,40,1,16,0,49,49,0,20,33,36,32,4,35,33,513,1,33,0]

def active32329 : List Nat := [0,1,2,3,4,8]

def tree32329 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32329 : H12WitnessSearch.Good tree32329 := H12GlobalWitnessIndex.good

theorem leafIdentity32329 : H12AffineFastState.composeSystem env32329 rootObs = leafEnv32329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32329 rootObs == leafEnv32329) = true)

theorem terminalChecked32329 : H12PackedTerminal.terminalCheckFast leafEnv32329 active32329 tree32329 = true := by decide +kernel

def env32330 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,40,32,1,35,48,0,53,0,33,33,16,2,40,16,0,48,49,0,21,33,36,32,32,513]

theorem envBound32330 : H12AffineFastState.Bounded env32330 := by
  intro p hp
  have h : env32330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32328_32330 : H12AffineEnvironment.transform 9 53 env32328 = env32330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32328 == env32330) = true)

theorem identity32330 : scanCanonicalize (H12AffineFastState.compose env32330 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32331 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,49,40,32,1,35,48,0,53,0,33,33,16,2,40,16,0,48,49,0,21,33,36,32,32,43]

theorem envBound32331 : H12AffineFastState.Bounded env32331 := by
  intro p hp
  have h : env32331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32330_32331 : H12AffineEnvironment.transform 8 42 env32330 = env32331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32330 == env32331) = true)

def leafEnv32331 : List Nat := [2,4,8,16,32,16,8,36,42,53,0,49,40,32,1,35,48,0,53,0,33,33,16,2,21,40,1,16,0,48,49,0,21,33,36,32,4,35,32,43,1,33,0]

def active32331 : List Nat := [0,1,2,3,4]

def tree32331 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32331 : H12WitnessSearch.Good tree32331 := H12GlobalWitnessIndex.good

theorem leafIdentity32331 : H12AffineFastState.composeSystem env32331 rootObs = leafEnv32331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32331 rootObs == leafEnv32331) = true)

theorem terminalChecked32331 : H12PackedTerminal.terminalCheckFast leafEnv32331 active32331 tree32331 = true := by decide +kernel

def env32332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,17,98644,8193,64,398437,5393,4097,431376,1365,41341,256,32,46092,74250]

theorem envBound32332 : H12AffineFastState.Bounded env32332 := by
  intro p hp
  have h : env32332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32313_32332 : H12AffineEnvironment.transform 6 9 env32313 = env32332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32313 == env32332) = true)

theorem identity32332 : scanCanonicalize (H12AffineFastState.compose env32332 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound32332 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1024,32769,4160,33,17,98644,8193,64,171281,5393,4097,138340,1365,41341,256,32,46092,74250]

theorem envBound32333 : H12AffineFastState.Bounded env32333 := by
  intro p hp
  have h : env32333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32332_32333 : H12AffineEnvironment.transform 17 35188 env32332 = env32333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env32332 == env32333) = true)

theorem identity32333 : scanCanonicalize (H12AffineFastState.compose env32333 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound32333 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,35188,1024,32769,4160,33,17,98644,8193,64,34816,5393,4097,2421,1365,41341,256,32,46092,74250]

theorem envBound32334 : H12AffineFastState.Bounded env32334 := by
  intro p hp
  have h : env32334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32333_32334 : H12AffineEnvironment.transform 16 5393 env32333 = env32334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env32333 == env32334) = true)

theorem identity32334 : scanCanonicalize (H12AffineFastState.compose env32334 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32334 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,35188,1024,32769,4160,33,17,41310,8193,64,34816,5393,4097,2421,1365,41341,256,32,46092,512]

theorem envBound32335 : H12AffineFastState.Bounded env32335 := by
  intro p hp
  have h : env32335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32334_32335 : H12AffineEnvironment.transform 15 8202 env32334 = env32335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32334 == env32335) = true)

theorem identity32335 : scanCanonicalize (H12AffineFastState.compose env32335 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound32335 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8201,8202,5393,10621,1024,8200,4160,33,17,343,8193,64,10249,5393,4097,2421,1365,372,256,32,5125,512]

theorem envBound32336 : H12AffineFastState.Bounded env32336 := by
  intro p hp
  have h : env32336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32335_32336 : H12AffineEnvironment.transform 14 8201 env32335 = env32336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env32335 == env32336) = true)

theorem identity32336 : scanCanonicalize (H12AffineFastState.compose env32336 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32336 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env32337 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8201,8202,5221,10249,1024,8200,4160,33,17,35,8193,64,10249,5221,4097,2049,1057,0,116,32,5125,512]

theorem envBound32337 : H12AffineFastState.Bounded env32337 := by
  intro p hp
  have h : env32337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32336_32337 : H12AffineEnvironment.transform 7 116 env32336 = env32337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32336 == env32337) = true)

theorem identity32337 : scanCanonicalize (H12AffineFastState.compose env32337 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6147) := by decide +kernel

theorem selectedBound32337 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32338 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,6147,5236,6154,6153,5221,4106,1024,6155,4160,33,17,35,6146,64,4106,5221,4097,2049,1057,0,116,32,5125,512]

theorem envBound32338 : H12AffineFastState.Bounded env32338 := by
  intro p hp
  have h : env32338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32337_32338 : H12AffineEnvironment.transform 12 6147 env32337 = env32338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6147 env32337 == env32338) = true)

theorem identity32338 : scanCanonicalize (H12AffineFastState.compose env32338 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2139) := by decide +kernel

theorem selectedBound32338 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32339 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2139,88,3119,81,82,3134,2129,1024,80,2075,33,17,35,89,64,2129,3134,2138,2049,1057,0,116,32,3166,512]

theorem envBound32339 : H12AffineFastState.Bounded env32339 := by
  intro p hp
  have h : env32339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32338_32339 : H12AffineEnvironment.transform 11 2139 env32338 = env32339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2139 env32338 == env32339) = true)

theorem identity32339 : scanCanonicalize (H12AffineFastState.compose env32339 (packedSelected [1,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32339 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env32340 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2059,8,3119,1,2,3134,2049,1024,0,2075,33,17,35,9,16,2049,3134,2058,2049,1057,0,36,32,3086,512]

theorem envBound32340 : H12AffineFastState.Bounded env32340 := by
  intro p hp
  have h : env32340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32339_32340 : H12AffineEnvironment.transform 5 16 env32339 = env32340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32339 == env32340) = true)

theorem identity32340 : scanCanonicalize (H12AffineFastState.compose env32340 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32340 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32341 : List Nat := [2,4,8,1,32,1,9,36,512,1024,2048,2059,8,3119,1,2,3119,2049,1024,0,2058,33,0,35,9,1,2049,3119,2058,2049,1057,0,36,32,3086,512]

theorem envBound32341 : H12AffineFastState.Bounded env32341 := by
  intro p hp
  have h : env32341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32340_32341 : H12AffineEnvironment.transform 3 1 env32340 = env32341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32340 == env32341) = true)

theorem identity32341 : scanCanonicalize (H12AffineFastState.compose env32341 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32342 : List Nat := [2,4,8,1,0,1,9,4,512,1024,2048,2059,8,3087,1,2,3087,2049,1024,0,2058,1,0,3,9,1,2049,3087,2058,2049,1025,0,4,0,3086,512]

theorem envBound32342 : H12AffineFastState.Bounded env32342 := by
  intro p hp
  have h : env32342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32341_32342 : H12AffineEnvironment.transform 4 0 env32341 = env32342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32341 == env32342) = true)

theorem identity32342 : scanCanonicalize (H12AffineFastState.compose env32342 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound32342 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32343 : List Nat := [2,4,8,1,0,1,9,4,512,1024,512,523,8,1551,1,2,1551,513,1024,0,522,1,0,3,9,1,513,1551,522,513,1025,0,4,0,1550,512]

theorem envBound32343 : H12AffineFastState.Bounded env32343 := by
  intro p hp
  have h : env32343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32342_32343 : H12AffineEnvironment.transform 10 512 env32342 = env32343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env32342 == env32343) = true)

theorem identity32343 : scanCanonicalize (H12AffineFastState.compose env32343 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound32343 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32344 : List Nat := [2,4,8,1,0,1,9,4,2,1024,2,9,8,1037,1,2,1037,3,1024,0,8,1,0,3,9,1,3,1037,8,3,1025,0,4,0,1036,2]

theorem envBound32344 : H12AffineFastState.Bounded env32344 := by
  intro p hp
  have h : env32344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32343_32344 : H12AffineEnvironment.transform 8 2 env32343 = env32344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env32343 == env32344) = true)

theorem identity32344 : scanCanonicalize (H12AffineFastState.compose env32344 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound32344 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32345 : List Nat := [2,4,8,1,0,1,9,4,2,15,2,9,8,2,1,2,2,3,15,0,8,1,0,3,9,1,3,2,8,3,14,0,4,0,3,2]

theorem envBound32345 : H12AffineFastState.Bounded env32345 := by
  intro p hp
  have h : env32345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32344_32345 : H12AffineEnvironment.transform 9 15 env32344 = env32345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env32344 == env32345) = true)

def env32346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685837,2098649,4233,2524632,2102684,6336916,256,32,46213,2175562]

theorem envBound32346 : H12AffineFastState.Bounded env32346 := by
  intro p hp
  have h : env32346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32302_32346 : H12AffineEnvironment.transform 22 2101465 env32302 = env32346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env32302 == env32346) = true)

def env32347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491565,2098649,4233,2524632,2102684,2142644,256,32,46213,2175562]

theorem envBound32347 : H12AffineFastState.Bounded env32347 := by
  intro p hp
  have h : env32347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32346_32347 : H12AffineEnvironment.transform 21 32 env32346 = env32347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32346 == env32347) = true)

theorem identity32347 : scanCanonicalize (H12AffineFastState.compose env32347 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32347 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,2097152,32,2101465,73736,8328,64,2491565,2098649,4233,2499717,2102684,2101481,256,32,5592,2175562]

theorem envBound32348 : H12AffineFastState.Bounded env32348 := by
  intro p hp
  have h : env32348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32347_32348 : H12AffineEnvironment.transform 14 8541 env32347 = env32348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32347 == env32348) = true)

def env32349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,2097152,32,2101465,73736,8328,64,2239501,2098649,4233,2231333,2102684,2101481,256,32,5592,2175562]

theorem envBound32349 : H12AffineFastState.Bounded env32349 := by
  intro p hp
  have h : env32349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32348_32349 : H12AffineEnvironment.transform 17 10400 env32348 = env32349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32348 == env32349) = true)

def env32350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,132568,32,136449,73736,8328,64,10709,131073,4233,2557,135236,136497,256,32,5592,210834]

theorem envBound32350 : H12AffineFastState.Bounded env32350 := by
  intro p hp
  have h : env32350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32349_32350 : H12AffineEnvironment.transform 20 132568 env32349 = env32350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132568 env32349 == env32350) = true)

theorem identity32350 : scanCanonicalize (H12AffineFastState.compose env32350 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound32350 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env32351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10400,1024,8540,78019,32,73754,73736,8328,64,10709,79130,4233,2557,75103,73770,256,32,5592,649]

theorem envBound32351 : H12AffineFastState.Bounded env32351 := by
  intro p hp
  have h : env32351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32350_32351 : H12AffineEnvironment.transform 16 79131 env32350 = env32351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env32350 == env32351) = true)

theorem identity32351 : scanCanonicalize (H12AffineFastState.compose env32351 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32351 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10280,1024,8540,77899,32,73754,73736,8192,64,10589,79130,4097,2421,75103,73770,256,32,5456,513]

theorem envBound32352 : H12AffineFastState.Bounded env32352 := by
  intro p hp
  have h : env32352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32351_32352 : H12AffineEnvironment.transform 6 8 env32351 = env32352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32351 == env32352) = true)

theorem identity32352 : scanCanonicalize (H12AffineFastState.compose env32352 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32352 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10280,1024,8540,4161,32,16,2,8192,64,10589,5392,4097,2421,1365,32,256,32,5456,513]

theorem envBound32353 : H12AffineFastState.Bounded env32353 := by
  intro p hp
  have h : env32353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32352_32353 : H12AffineEnvironment.transform 15 8202 env32352 = env32353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32352 == env32353) = true)

def env32354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,132569,32,136448,73736,8328,64,10708,131072,4233,2556,135237,136496,256,32,5592,210835]

theorem envBound32354 : H12AffineFastState.Bounded env32354 := by
  intro p hp
  have h : env32354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32349_32354 : H12AffineEnvironment.transform 20 132569 env32349 = env32354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132569 env32349 == env32354) = true)

theorem identity32354 : scanCanonicalize (H12AffineFastState.compose env32354 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound32354 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env32355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79250,10400,1024,8540,77899,32,73874,73736,8328,64,10708,79250,4233,2556,75223,73890,256,32,5592,513]

theorem envBound32355 : H12AffineFastState.Bounded env32355 := by
  intro p hp
  have h : env32355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32354_32355 : H12AffineEnvironment.transform 16 79250 env32354 = env32355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env32354 == env32355) = true)

theorem identity32355 : scanCanonicalize (H12AffineFastState.compose env32355 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32355 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8202,5528,10400,1024,8540,4161,32,152,2,8328,64,10708,5528,4233,2556,1501,168,256,32,5592,513]

theorem envBound32356 : H12AffineFastState.Bounded env32356 := by
  intro p hp
  have h : env32356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32355_32356 : H12AffineEnvironment.transform 15 8202 env32355 = env32356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32355 == env32356) = true)

theorem identity32356 : scanCanonicalize (H12AffineFastState.compose env32356 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32356 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env32357 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5236,8233,8202,5356,10400,1024,8232,4161,32,152,2,8328,64,10400,5356,4233,2184,1193,168,116,32,5292,513]

theorem envBound32357 : H12AffineFastState.Bounded env32357 := by
  intro p hp
  have h : env32357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32356_32357 : H12AffineEnvironment.transform 7 116 env32356 = env32357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32356 == env32357) = true)

theorem identity32357 : scanCanonicalize (H12AffineFastState.compose env32357 (packedSelected [3,4,5,6,9,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32357 : packedSelected [3,4,5,6,9,10,20] rootPS < 2^1333 := by decide +kernel

def env32358 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,8202,5220,10280,1024,8232,4161,32,16,2,8192,64,10280,5220,4097,2048,1057,32,116,32,5156,513]

theorem envBound32358 : H12AffineFastState.Bounded env32358 := by
  intro p hp
  have h : env32358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32357_32358 : H12AffineEnvironment.transform 6 8 env32357 = env32358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32357 == env32358) = true)

theorem identity32358 : scanCanonicalize (H12AffineFastState.compose env32358 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32358 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32359 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,1,34,5220,2048,1024,0,4161,32,16,2,40,64,2048,5220,4097,2048,1057,32,116,32,5156,513]

theorem envBound32359 : H12AffineFastState.Bounded env32359 := by
  intro p hp
  have h : env32359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32358_32359 : H12AffineEnvironment.transform 12 40 env32358 = env32359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32358 == env32359) = true)

theorem identity32359 : scanCanonicalize (H12AffineFastState.compose env32359 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound32359 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32360 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1647,4096,40,5236,1,34,5220,1647,1024,0,4161,32,16,2,40,64,1647,5220,4097,1647,1057,32,116,32,5156,513]

theorem envBound32360 : H12AffineFastState.Bounded env32360 := by
  intro p hp
  have h : env32360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32359_32360 : H12AffineEnvironment.transform 10 1647 env32359 = env32360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env32359 == env32360) = true)

theorem identity32360 : scanCanonicalize (H12AffineFastState.compose env32360 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound32360 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32361 : List Nat := [2,4,8,16,32,64,8,116,512,623,0,4096,40,4635,1,34,4619,0,623,0,4161,32,16,2,40,64,0,4619,4097,0,590,32,116,32,4683,513]

theorem envBound32361 : H12AffineFastState.Bounded env32361 := by
  intro p hp
  have h : env32361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32360_32361 : H12AffineEnvironment.transform 9 623 env32360 = env32361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env32360 == env32361) = true)

theorem identity32361 : scanCanonicalize (H12AffineFastState.compose env32361 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound32361 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32362 : List Nat := [2,4,8,16,32,64,8,116,122,21,0,4096,40,4193,1,34,4209,0,21,0,4161,32,16,2,40,64,0,4209,4097,0,52,32,116,32,4145,123]

theorem envBound32362 : H12AffineFastState.Bounded env32362 := by
  intro p hp
  have h : env32362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32361_32362 : H12AffineEnvironment.transform 8 122 env32361 = env32362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env32361 == env32362) = true)

theorem identity32362 : scanCanonicalize (H12AffineFastState.compose env32362 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound32362 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env32363 : List Nat := [2,4,8,16,24,64,8,76,66,21,0,4096,16,4185,1,26,4169,0,21,0,4161,24,16,2,16,64,0,4169,4097,0,12,24,76,24,4105,67]

theorem envBound32363 : H12AffineFastState.Bounded env32363 := by
  intro p hp
  have h : env32363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32362_32363 : H12AffineEnvironment.transform 4 24 env32362 = env32363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env32362 == env32363) = true)

def env32364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,2097152,32,2101465,73736,8328,64,2239500,2098649,4233,2231332,2102684,2101481,256,32,5592,2175562]

theorem envBound32364 : H12AffineFastState.Bounded env32364 := by
  intro p hp
  have h : env32364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32348_32364 : H12AffineEnvironment.transform 17 10401 env32348 = env32364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32348 == env32364) = true)

theorem identity32364 : scanCanonicalize (H12AffineFastState.compose env32364 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound32364 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,4297,32,16,73736,8328,64,146629,5392,4233,138477,1365,32,256,32,5592,74371]

theorem envBound32365 : H12AffineFastState.Bounded env32365 := by
  intro p hp
  have h : env32365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32364_32365 : H12AffineEnvironment.transform 20 4297 env32364 = env32365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env32364 == env32365) = true)

theorem identity32365 : scanCanonicalize (H12AffineFastState.compose env32365 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound32365 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,70862,10401,1024,8540,4297,32,16,73736,8328,64,75787,5392,4233,67619,1365,32,256,32,5592,74371]

theorem envBound32366 : H12AffineFastState.Bounded env32366 := by
  intro p hp
  have h : env32366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32365_32366 : H12AffineEnvironment.transform 16 70862 env32365 = env32366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env32365 == env32366) = true)

theorem identity32366 : scanCanonicalize (H12AffineFastState.compose env32366 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound32366 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env32367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,343,5529,10401,1024,8540,4297,32,16,8543,8328,64,10588,5392,4233,2420,1365,32,256,32,5592,9172]

theorem envBound32367 : H12AffineFastState.Bounded env32367 := by
  intro p hp
  have h : env32367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32366_32367 : H12AffineEnvironment.transform 15 343 env32366 = env32367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env32366 == env32367) = true)

theorem identity32367 : scanCanonicalize (H12AffineFastState.compose env32367 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound32367 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,136,343,5529,2420,1024,137,4297,32,16,138,349,64,2185,5392,4233,2420,1365,32,256,32,5592,513]

theorem envBound32368 : H12AffineFastState.Bounded env32368 := by
  intro p hp
  have h : env32368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32367_32368 : H12AffineEnvironment.transform 12 469 env32367 = env32368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env32367 == env32368) = true)

theorem identity32368 : scanCanonicalize (H12AffineFastState.compose env32368 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound32368 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32369 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,469,4249,136,343,4096,2420,409,137,4297,32,16,138,349,64,2185,4233,4233,2420,204,32,256,32,4161,513]

theorem envBound32369 : H12AffineFastState.Bounded env32369 := by
  intro p hp
  have h : env32369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32368_32369 : H12AffineEnvironment.transform 9 409 env32368 = env32369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env32368 == env32369) = true)

theorem identity32369 : scanCanonicalize (H12AffineFastState.compose env32369 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32369 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32370 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4113,0,343,4096,2420,273,1,4161,32,16,2,349,64,2049,4097,4097,2420,68,32,256,32,4161,513]

theorem envBound32370 : H12AffineFastState.Bounded env32370 := by
  intro p hp
  have h : env32370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32369_32370 : H12AffineEnvironment.transform 6 8 env32369 = env32370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32369 == env32370) = true)

theorem identity32370 : scanCanonicalize (H12AffineFastState.compose env32370 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32371 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,4096,72,4113,0,66,4096,2145,4,1,4161,32,16,2,72,64,2049,4097,4097,2145,68,32,21,32,4161,513]

theorem envBound32371 : H12AffineFastState.Bounded env32371 := by
  intro p hp
  have h : env32371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32370_32371 : H12AffineEnvironment.transform 7 21 env32370 = env32371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32370 == env32371) = true)

theorem identity32371 : scanCanonicalize (H12AffineFastState.compose env32371 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound32371 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32372 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,545,72,560,0,66,545,2145,4,1,608,32,16,2,72,64,2049,544,544,2145,68,32,21,32,608,513]

theorem envBound32372 : H12AffineFastState.Bounded env32372 := by
  intro p hp
  have h : env32372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32371_32372 : H12AffineEnvironment.transform 11 545 env32371 = env32372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env32371 == env32372) = true)

def env32373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491564,2098649,4233,2524632,2102684,2142645,256,32,46213,2175562]

theorem envBound32373 : H12AffineFastState.Bounded env32373 := by
  intro p hp
  have h : env32373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32346_32373 : H12AffineEnvironment.transform 21 33 env32346 = env32373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32346 == env32373) = true)

theorem identity32373 : scanCanonicalize (H12AffineFastState.compose env32373 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound32373 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,45460,33,41293,98645,8328,64,439608,46157,4233,406604,41992,33,256,32,46213,99294]

theorem envBound32374 : H12AffineFastState.Bounded env32374 := by
  intro p hp
  have h : env32374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32373_32374 : H12AffineEnvironment.transform 20 45460 env32373 = env32374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env32373 == env32374) = true)

theorem identity32374 : scanCanonicalize (H12AffineFastState.compose env32374 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound32374 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env32375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,45460,33,41293,98645,8328,64,203847,46157,4233,236851,41992,33,256,32,46213,99294]

theorem envBound32375 : H12AffineFastState.Bounded env32375 := by
  intro p hp
  have h : env32375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32374_32375 : H12AffineEnvironment.transform 17 108927 env32374 = env32375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env32374 == env32375) = true)

def env32376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67619,1024,8541,4296,33,17,73737,8328,64,203847,5393,4233,212079,1364,33,256,32,5593,74370]

theorem envBound32376 : H12AffineFastState.Bounded env32376 := by
  intro p hp
  have h : env32376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32375_32376 : H12AffineEnvironment.transform 14 8540 env32375 = env32376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32375 == env32376) = true)

theorem identity32376 : scanCanonicalize (H12AffineFastState.compose env32376 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32376 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,131072,10280,1024,8541,4296,33,17,2,8328,64,146508,5393,4233,138340,1364,33,256,32,5593,649]

theorem envBound32377 : H12AffineFastState.Bounded env32377 := by
  intro p hp
  have h : env32377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32376_32377 : H12AffineEnvironment.transform 15 8203 env32376 = env32377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32376 == env32377) = true)

theorem identity32377 : scanCanonicalize (H12AffineFastState.compose env32377 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32377 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,263,131072,2340,1024,81,4296,33,17,2,388,64,138560,5393,4233,138340,1364,33,256,32,5593,649]

theorem envBound32378 : H12AffineFastState.Bounded env32378 := by
  intro p hp
  have h : env32378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32377_32378 : H12AffineEnvironment.transform 12 268 env32377 = env32378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32377 == env32378) = true)

theorem identity32378 : scanCanonicalize (H12AffineFastState.compose env32378 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound32378 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env32379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,263,5576,2340,1024,81,4296,33,17,2,388,64,2184,5393,4233,2476,1364,33,256,32,5593,649]

theorem envBound32379 : H12AffineFastState.Bounded env32379 := by
  intro p hp
  have h : env32379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32378_32379 : H12AffineEnvironment.transform 16 5576 env32378 = env32379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env32378 == env32379) = true)

theorem identity32379 : scanCanonicalize (H12AffineFastState.compose env32379 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32379 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env32380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,263,5441,2340,1024,81,4161,33,17,2,269,64,2049,5393,4096,2341,1364,33,256,32,5456,512]

theorem envBound32380 : H12AffineFastState.Bounded env32380 := by
  intro p hp
  have h : env32380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32379_32380 : H12AffineEnvironment.transform 6 9 env32379 = env32380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32379 == env32380) = true)

theorem identity32380 : scanCanonicalize (H12AffineFastState.compose env32380 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1888) := by decide +kernel

theorem selectedBound32380 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1888,268,608,80,263,545,2340,1024,81,1825,33,17,2,269,64,2049,625,1888,2341,1364,33,256,32,560,512]

theorem envBound32381 : H12AffineFastState.Bounded env32381 := by
  intro p hp
  have h : env32381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32380_32381 : H12AffineEnvironment.transform 11 1888 env32380 = env32381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1888 env32380 == env32381) = true)

theorem identity32381 : scanCanonicalize (H12AffineFastState.compose env32381 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32381 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32382 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1856,268,576,80,263,513,2308,1024,81,1793,1,17,2,269,64,2049,593,1856,2309,1364,1,256,0,528,512]

theorem envBound32382 : H12AffineFastState.Bounded env32382 := by
  intro p hp
  have h : env32382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32381_32382 : H12AffineEnvironment.transform 4 0 env32381 = env32382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32381 == env32382) = true)

theorem identity32382 : scanCanonicalize (H12AffineFastState.compose env32382 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound32382 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32383 : List Nat := [2,4,8,16,0,64,9,256,512,533,2048,341,268,576,80,263,513,2308,533,81,276,1,17,2,269,64,2049,593,341,2309,833,1,256,0,528,512]

theorem envBound32383 : H12AffineFastState.Bounded env32383 := by
  intro p hp
  have h : env32383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32382_32383 : H12AffineEnvironment.transform 9 533 env32382 = env32383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env32382 == env32383) = true)

theorem identity32383 : scanCanonicalize (H12AffineFastState.compose env32383 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound32383 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env32384 : List Nat := [2,4,8,16,0,64,9,256,80,69,2048,341,268,16,80,263,81,2308,69,81,276,1,17,2,269,64,2049,1,341,2309,273,1,256,0,64,80]

theorem envBound32384 : H12AffineFastState.Bounded env32384 := by
  intro p hp
  have h : env32384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32383_32384 : H12AffineEnvironment.transform 8 80 env32383 = env32384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env32383 == env32384) = true)

def env32385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67618,1024,8540,4297,33,16,73736,8328,64,203847,5392,4233,212078,1365,33,256,32,5592,74371]

theorem envBound32385 : H12AffineFastState.Bounded env32385 := by
  intro p hp
  have h : env32385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32375_32385 : H12AffineEnvironment.transform 14 8541 env32375 = env32385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32375 == env32385) = true)

theorem identity32385 : scanCanonicalize (H12AffineFastState.compose env32385 (packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70815) := by decide +kernel

theorem selectedBound32385 : packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env32386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,70815,67618,1024,8540,4297,33,16,73736,8328,64,2264,5392,4233,10481,1365,33,256,32,5592,74371]

theorem envBound32386 : H12AffineFastState.Bounded env32386 := by
  intro p hp
  have h : env32386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32385_32386 : H12AffineEnvironment.transform 16 70815 env32385 = env32386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70815 env32385 == env32386) = true)

theorem identity32386 : scanCanonicalize (H12AffineFastState.compose env32386 (packedSelected [0,2,3,5,6,7,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32386 : packedSelected [0,2,3,5,6,7,14,19] rootPS < 2^1333 := by decide +kernel

def env32387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,80,65536,70815,67618,1024,81,4297,33,16,65797,389,64,2264,5392,4233,2556,1365,33,256,32,5592,66446]

theorem envBound32387 : H12AffineFastState.Bounded env32387 := by
  intro p hp
  have h : env32387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32386_32387 : H12AffineEnvironment.transform 12 269 env32386 = env32387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32386 == env32387) = true)

theorem identity32387 : scanCanonicalize (H12AffineFastState.compose env32387 (packedSelected [3,14,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32387 : packedSelected [3,14,20,24] rootPS < 2^1333 := by decide +kernel

def env32388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,65536,70678,67618,1024,81,4160,33,16,65797,268,64,2129,5392,4096,2421,1365,33,256,32,5457,66311]

theorem envBound32388 : H12AffineFastState.Bounded env32388 := by
  intro p hp
  have h : env32388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32387_32388 : H12AffineEnvironment.transform 6 9 env32387 = env32388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32387 == env32388) = true)

theorem identity32388 : scanCanonicalize (H12AffineFastState.compose env32388 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32388 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env32389 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,65536,70678,67618,1024,81,4160,33,16,65648,121,64,2129,5221,4096,2048,1056,33,117,32,5156,66162]

theorem envBound32389 : H12AffineFastState.Bounded env32389 := by
  intro p hp
  have h : env32389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32388_32389 : H12AffineEnvironment.transform 7 117 env32388 = env32389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32388 == env32389) = true)

theorem identity32389 : scanCanonicalize (H12AffineFastState.compose env32389 (packedSelected [3,4,5,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound32389 : packedSelected [3,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env32390 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,35,5173,2049,1024,81,4160,33,16,83,121,64,2129,5221,4096,2048,1056,33,117,32,5156,593]

theorem envBound32390 : H12AffineFastState.Bounded env32390 := by
  intro p hp
  have h : env32390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32389_32390 : H12AffineEnvironment.transform 15 35 env32389 = env32390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env32389 == env32390) = true)

theorem identity32390 : scanCanonicalize (H12AffineFastState.compose env32390 (packedSelected [4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound32390 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env32391 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2112,120,3125,80,35,3189,2049,1024,81,2048,33,16,83,121,64,2129,3109,2112,2048,1056,33,117,32,3172,593]

theorem envBound32391 : H12AffineFastState.Bounded env32391 := by
  intro p hp
  have h : env32391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32390_32391 : H12AffineEnvironment.transform 11 2112 env32390 = env32391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env32390 == env32391) = true)

theorem identity32391 : scanCanonicalize (H12AffineFastState.compose env32391 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32391 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env32392 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,2112,120,2129,80,35,2065,2049,100,81,2048,33,16,83,121,64,2129,2113,2112,2048,68,33,117,32,2048,593]

theorem envBound32392 : H12AffineFastState.Bounded env32392 := by
  intro p hp
  have h : env32392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32391_32392 : H12AffineEnvironment.transform 9 100 env32391 = env32392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32391 == env32392) = true)

theorem identity32392 : scanCanonicalize (H12AffineFastState.compose env32392 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32392 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env32393 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,40,2049,0,35,2065,2049,52,1,2048,33,16,3,41,16,2049,2065,2064,2048,20,33,37,32,2048,513]

theorem envBound32393 : H12AffineFastState.Bounded env32393 := by
  intro p hp
  have h : env32393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32392_32393 : H12AffineEnvironment.transform 5 16 env32392 = env32393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32392 == env32393) = true)

theorem identity32393 : scanCanonicalize (H12AffineFastState.compose env32393 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32394 : List Nat := [2,4,8,16,32,16,9,37,0,52,2048,2064,40,2049,0,35,2065,2049,52,1,2048,33,16,3,41,16,2049,2065,2064,2048,20,33,37,32,2048,1]

theorem envBound32394 : H12AffineFastState.Bounded env32394 := by
  intro p hp
  have h : env32394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32393_32394 : H12AffineEnvironment.transform 8 0 env32393 = env32394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32393 == env32394) = true)

theorem identity32394 : scanCanonicalize (H12AffineFastState.compose env32394 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound32394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32395 : List Nat := [2,4,8,16,32,16,9,37,0,52,11,27,40,10,0,35,26,10,52,1,11,33,16,3,41,16,10,26,27,11,20,33,37,32,11,1]

theorem envBound32395 : H12AffineFastState.Bounded env32395 := by
  intro p hp
  have h : env32395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32394_32395 : H12AffineEnvironment.transform 10 11 env32394 = env32395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env32394 == env32395) = true)

def env32396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685837,8393985,10485841,8819968,2102685,12624205,256,32,46212,2175563]

theorem envBound32396 : H12AffineFastState.Bounded env32396 := by
  intro p hp
  have h : env32396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32301_32396 : H12AffineEnvironment.transform 13 5377 env32301 = env32396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32301 == env32396) = true)

def env32397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685837,2098649,4233,2524632,2102685,6336917,256,32,46212,2175563]

theorem envBound32397 : H12AffineFastState.Bounded env32397 := by
  intro p hp
  have h : env32397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32396_32397 : H12AffineEnvironment.transform 22 2101464 env32396 = env32397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env32396 == env32397) = true)

def env32398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491565,2098649,4233,2524632,2102685,2142645,256,32,46212,2175563]

theorem envBound32398 : H12AffineFastState.Bounded env32398 := by
  intro p hp
  have h : env32398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32397_32398 : H12AffineEnvironment.transform 21 32 env32397 = env32398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32397 == env32398) = true)

theorem identity32398 : scanCanonicalize (H12AffineFastState.compose env32398 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102679) := by decide +kernel

theorem selectedBound32398 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98767,98645,8328,64,497082,103630,4233,464079,99466,73890,256,32,46212,41820]

theorem envBound32399 : H12AffineFastState.Bounded env32399 := by
  intro p hp
  have h : env32399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32398_32399 : H12AffineEnvironment.transform 20 102679 env32398 = env32399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102679 env32398 == env32399) = true)

def env32400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1024,32769,102679,32,98767,98645,8328,64,245018,103630,4233,212079,99466,73890,256,32,46212,41820]

theorem envBound32400 : H12AffineFastState.Bounded env32400 := by
  intro p hp
  have h : env32400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32399_32400 : H12AffineEnvironment.transform 17 10400 env32399 = env32400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32399 == env32400) = true)

def env32401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102679,32,98631,98645,8192,64,245018,103494,4097,212079,99330,73770,256,32,46092,41820]

theorem envBound32401 : H12AffineFastState.Bounded env32401 := by
  intro p hp
  have h : env32401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32400_32401 : H12AffineEnvironment.transform 6 8 env32400 = env32401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32400 == env32401) = true)

theorem identity32401 : scanCanonicalize (H12AffineFastState.compose env32401 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound32401 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env32402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,70727,10280,1024,32769,102679,32,98631,98645,8192,64,43357,103494,4097,10280,99330,73770,256,32,46092,41820]

theorem envBound32402 : H12AffineFastState.Bounded env32402 := by
  intro p hp
  have h : env32402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32401_32402 : H12AffineEnvironment.transform 16 70727 env32401 = env32402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env32401 == env32402) = true)

theorem identity32402 : scanCanonicalize (H12AffineFastState.compose env32402 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32402 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,65536,70727,10280,1024,0,69910,32,65862,65876,8192,64,10588,70727,4097,10280,66563,73770,256,32,13325,9053]

theorem envBound32403 : H12AffineFastState.Bounded env32403 := by
  intro p hp
  have h : env32403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32402_32403 : H12AffineEnvironment.transform 14 1 env32402 = env32403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32402 == env32403) = true)

theorem identity32403 : scanCanonicalize (H12AffineFastState.compose env32403 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32403 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,13389,10280,1024,0,12572,32,8524,8542,8192,64,10588,13389,4097,10280,9225,32,256,32,13325,9053]

theorem envBound32404 : H12AffineFastState.Bounded env32404 := by
  intro p hp
  have h : env32404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32403_32404 : H12AffineEnvironment.transform 15 8202 env32403 = env32404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32403 == env32404) = true)

theorem identity32404 : scanCanonicalize (H12AffineFastState.compose env32404 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32404 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,1,34,5221,2048,1024,0,4404,32,356,374,40,64,2420,5221,4097,2048,1057,32,256,32,5157,885]

theorem envBound32405 : H12AffineFastState.Bounded env32405 := by
  intro p hp
  have h : env32405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32404_32405 : H12AffineEnvironment.transform 12 40 env32404 = env32405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32404 == env32405) = true)

theorem identity32405 : scanCanonicalize (H12AffineFastState.compose env32405 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32405 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env32406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,40,5377,1,34,5221,1,1024,0,4404,32,356,374,40,64,373,5221,4097,1,1057,32,256,32,5157,885]

theorem envBound32406 : H12AffineFastState.Bounded env32406 := by
  intro p hp
  have h : env32406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32405_32406 : H12AffineEnvironment.transform 10 1 env32405 = env32406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32405 == env32406) = true)

theorem identity32406 : scanCanonicalize (H12AffineFastState.compose env32406 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound32406 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32407 : List Nat := [2,4,8,16,32,64,8,256,512,69,1,4096,40,4420,1,34,4128,1,69,0,4404,32,356,374,40,64,373,4128,4097,1,100,32,256,32,4192,885]

theorem envBound32407 : H12AffineFastState.Bounded env32407 := by
  intro p hp
  have h : env32407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32406_32407 : H12AffineEnvironment.transform 9 69 env32406 = env32407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env32406 == env32407) = true)

theorem identity32407 : scanCanonicalize (H12AffineFastState.compose env32407 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32407 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env32408 : List Nat := [2,4,8,16,32,64,8,117,512,69,1,4096,40,4145,1,34,4128,1,69,0,4161,32,17,3,40,64,0,4128,4097,1,100,32,117,32,4192,512]

theorem envBound32408 : H12AffineFastState.Bounded env32408 := by
  intro p hp
  have h : env32408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32407_32408 : H12AffineEnvironment.transform 7 117 env32407 = env32408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32407 == env32408) = true)

theorem identity32408 : scanCanonicalize (H12AffineFastState.compose env32408 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound32408 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32409 : List Nat := [2,4,8,16,32,64,8,117,512,69,1,27,40,42,1,34,59,1,69,0,90,32,17,3,40,64,0,59,26,1,100,32,117,32,123,512]

theorem envBound32409 : H12AffineFastState.Bounded env32409 := by
  intro p hp
  have h : env32409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32408_32409 : H12AffineEnvironment.transform 11 27 env32408 = env32409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env32408 == env32409) = true)

theorem identity32409 : scanCanonicalize (H12AffineFastState.compose env32409 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound32409 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32410 : List Nat := [2,4,8,16,32,49,8,4,512,52,1,27,40,42,1,34,59,1,52,0,43,32,17,3,40,49,0,59,26,1,21,32,4,32,10,512]

theorem envBound32410 : H12AffineFastState.Bounded env32410 := by
  intro p hp
  have h : env32410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32409_32410 : H12AffineEnvironment.transform 5 49 env32409 = env32410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env32409 == env32410) = true)

theorem identity32410 : scanCanonicalize (H12AffineFastState.compose env32410 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound32410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32411 : List Nat := [2,4,8,16,32,49,8,4,46,52,1,27,40,42,1,34,59,1,52,0,43,32,17,3,40,49,0,59,26,1,21,32,4,32,10,46]

theorem envBound32411 : H12AffineFastState.Bounded env32411 := by
  intro p hp
  have h : env32411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32410_32411 : H12AffineEnvironment.transform 8 46 env32410 = env32411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env32410 == env32411) = true)

theorem identity32411 : scanCanonicalize (H12AffineFastState.compose env32411 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32412 : List Nat := [2,4,8,1,32,32,8,4,46,37,1,10,40,42,1,34,42,1,37,0,43,32,0,3,40,32,0,42,11,1,4,32,4,32,10,46]

theorem envBound32412 : H12AffineFastState.Bounded env32412 := by
  intro p hp
  have h : env32412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32411_32412 : H12AffineEnvironment.transform 3 1 env32411 = env32412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32411 == env32412) = true)

theorem identity32412 : scanCanonicalize (H12AffineFastState.compose env32412 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32412 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32413 : List Nat := [2,4,8,1,11,11,8,4,5,14,1,10,3,1,1,9,1,1,14,0,0,11,0,3,3,11,0,1,11,1,4,11,4,11,10,5]

theorem envBound32413 : H12AffineFastState.Bounded env32413 := by
  intro p hp
  have h : env32413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32412_32413 : H12AffineEnvironment.transform 4 11 env32412 = env32413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32412 == env32413) = true)

theorem identity32413 : scanCanonicalize (H12AffineFastState.compose env32413 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32413 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32414 : List Nat := [2,4,2,1,1,1,2,4,5,4,1,0,3,1,1,3,1,1,4,0,0,1,0,3,3,1,0,1,1,1,4,1,4,1,0,5]

theorem envBound32414 : H12AffineFastState.Bounded env32414 := by
  intro p hp
  have h : env32414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32413_32414 : H12AffineEnvironment.transform 2 2 env32413 = env32414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32413 == env32414) = true)

theorem identity32414 : scanCanonicalize (H12AffineFastState.compose env32414 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32415 : List Nat := [1,4,1,1,1,1,1,4,5,4,1,0,0,1,1,0,1,1,4,0,0,1,0,0,0,1,0,1,1,1,4,1,4,1,0,5]

theorem envBound32415 : H12AffineFastState.Bounded env32415 := by
  intro p hp
  have h : env32415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32414_32415 : H12AffineEnvironment.transform 0 1 env32414 = env32415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32414 == env32415) = true)

def env32416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102679,32,98630,98645,8193,64,245018,103495,4096,212079,99331,73771,256,32,46093,41820]

theorem envBound32416 : H12AffineFastState.Bounded env32416 := by
  intro p hp
  have h : env32416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32400_32416 : H12AffineEnvironment.transform 6 9 env32400 = env32416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32400 == env32416) = true)

theorem identity32416 : scanCanonicalize (H12AffineFastState.compose env32416 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,32,73755,73736,8193,64,203847,79130,4096,212079,75102,73771,256,32,5456,513]

theorem envBound32417 : H12AffineFastState.Bounded env32417 := by
  intro p hp
  have h : env32417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32416_32417 : H12AffineEnvironment.transform 14 8541 env32416 = env32417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32416 == env32417) = true)

theorem identity32417 : scanCanonicalize (H12AffineFastState.compose env32417 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound32417 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,13673,10281,1024,8540,77898,32,73755,73736,8193,64,76078,79130,4096,67846,75102,73771,256,32,5456,513]

theorem envBound32418 : H12AffineFastState.Bounded env32418 := by
  intro p hp
  have h : env32418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32417_32418 : H12AffineEnvironment.transform 16 13673 env32417 = env32418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env32417 == env32418) = true)

theorem identity32418 : scanCanonicalize (H12AffineFastState.compose env32418 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound32418 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,9498,13673,10281,1024,8540,5456,32,1281,1298,8193,64,3124,4096,4096,11292,68,1329,256,32,5456,513]

theorem envBound32419 : H12AffineFastState.Bounded env32419 := by
  intro p hp
  have h : env32419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32418_32419 : H12AffineEnvironment.transform 15 9498 env32418 = env32419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env32418 == env32419) = true)

theorem identity32419 : scanCanonicalize (H12AffineFastState.compose env32419 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32419 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env32420 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,8541,8202,12409,10281,272,8540,4160,32,17,2,8193,64,2340,4096,4096,10508,68,33,256,32,4160,513]

theorem envBound32420 : H12AffineFastState.Bounded env32420 := by
  intro p hp
  have h : env32420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32419_32420 : H12AffineEnvironment.transform 9 272 env32419 = env32420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32419 == env32420) = true)

theorem identity32420 : scanCanonicalize (H12AffineFastState.compose env32420 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32421 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,8192,4113,8232,8202,12409,10281,101,8233,4160,32,17,2,8193,64,2129,4096,4096,10361,68,33,117,32,4160,513]

theorem envBound32421 : H12AffineFastState.Bounded env32421 := by
  intro p hp
  have h : env32421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32420_32421 : H12AffineEnvironment.transform 7 117 env32420 = env32421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32420 == env32421) = true)

theorem identity32421 : scanCanonicalize (H12AffineFastState.compose env32421 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound32421 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32422 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,8192,2129,8232,8202,10297,10281,101,8233,2048,32,17,2,8193,64,2129,2112,2112,10361,68,33,117,32,2048,513]

theorem envBound32422 : H12AffineFastState.Bounded env32422 := by
  intro p hp
  have h : env32422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32421_32422 : H12AffineEnvironment.transform 11 2112 env32421 = env32422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env32421 == env32422) = true)

theorem identity32422 : scanCanonicalize (H12AffineFastState.compose env32422 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound32422 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32423 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,121,2129,81,115,2112,2128,101,80,2048,32,17,2,120,64,2129,2112,2112,2048,68,33,117,32,2048,513]

theorem envBound32423 : H12AffineFastState.Bounded env32423 := by
  intro p hp
  have h : env32423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32422_32423 : H12AffineEnvironment.transform 12 121 env32422 = env32423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env32422 == env32423) = true)

theorem identity32423 : scanCanonicalize (H12AffineFastState.compose env32423 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound32423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32424 : List Nat := [2,4,8,16,32,64,9,117,59,101,2048,2112,121,2129,81,115,2112,2128,101,80,2048,32,17,2,120,64,2129,2112,2112,2048,68,33,117,32,2048,58]

theorem envBound32424 : H12AffineFastState.Bounded env32424 := by
  intro p hp
  have h : env32424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32423_32424 : H12AffineEnvironment.transform 8 59 env32423 = env32424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env32423 == env32424) = true)

theorem identity32424 : scanCanonicalize (H12AffineFastState.compose env32424 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32425 : List Nat := [2,4,8,16,32,64,9,117,59,101,81,17,121,0,81,115,17,1,101,80,81,32,17,2,120,64,0,17,17,81,68,33,117,32,81,58]

theorem envBound32425 : H12AffineFastState.Bounded env32425 := by
  intro p hp
  have h : env32425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32424_32425 : H12AffineEnvironment.transform 10 81 env32424 = env32425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32424 == env32425) = true)

theorem identity32425 : scanCanonicalize (H12AffineFastState.compose env32425 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32425 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32426 : List Nat := [2,4,8,16,32,16,9,37,59,53,1,17,41,0,1,35,17,1,53,0,1,32,17,2,40,16,0,17,17,1,20,33,37,32,1,58]

theorem envBound32426 : H12AffineFastState.Bounded env32426 := by
  intro p hp
  have h : env32426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32425_32426 : H12AffineEnvironment.transform 5 16 env32425 = env32426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32425 == env32426) = true)

def env32427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1024,32769,102679,32,98767,98645,8328,64,245019,103630,4233,212078,99466,73890,256,32,46212,41820]

theorem envBound32427 : H12AffineFastState.Bounded env32427 := by
  intro p hp
  have h : env32427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32399_32427 : H12AffineEnvironment.transform 17 10401 env32399 = env32427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32399 == env32427) = true)

theorem identity32427 : scanCanonicalize (H12AffineFastState.compose env32427 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound32427 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,103495,10401,1024,32769,102679,32,98767,98645,8328,64,10588,103630,4233,43049,99466,73890,256,32,46212,41820]

theorem envBound32428 : H12AffineFastState.Bounded env32428 := by
  intro p hp
  have h : env32428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32427_32428 : H12AffineEnvironment.transform 16 103495 env32427 = env32428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env32427 == env32428) = true)

theorem identity32428 : scanCanonicalize (H12AffineFastState.compose env32428 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound32428 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env32429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5528,10401,1024,32769,4296,32,16,138,8328,64,10588,5393,4233,43049,1365,41341,256,32,46212,41820]

theorem envBound32429 : H12AffineFastState.Bounded env32429 := by
  intro p hp
  have h : env32429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32428_32429 : H12AffineEnvironment.transform 15 33247 env32428 = env32429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env32428 == env32429) = true)

theorem identity32429 : scanCanonicalize (H12AffineFastState.compose env32429 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound32429 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env32430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,216,263,5528,10401,1024,217,4296,32,16,138,8328,64,10588,5393,4233,10481,1365,8613,256,32,13404,9092]

theorem envBound32430 : H12AffineFastState.Bounded env32430 := by
  intro p hp
  have h : env32430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32429_32430 : H12AffineEnvironment.transform 14 216 env32429 = env32430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env32429 == env32430) = true)

theorem identity32430 : scanCanonicalize (H12AffineFastState.compose env32430 (packedSelected [0,5,8,9,11,15,16,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32430 : packedSelected [0,5,8,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,80,263,5392,10281,1024,81,4160,32,16,2,8192,64,10588,5393,4097,10361,1365,8493,256,32,13404,8972]

theorem envBound32431 : H12AffineFastState.Bounded env32431 := by
  intro p hp
  have h : env32431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32430_32431 : H12AffineEnvironment.transform 6 8 env32430 = env32431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32430 == env32431) = true)

theorem identity32431 : scanCanonicalize (H12AffineFastState.compose env32431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32432 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,80,263,4096,10281,272,81,4160,32,16,2,8192,64,10588,4097,4097,10361,69,8493,256,32,12620,8972]

theorem envBound32432 : H12AffineFastState.Bounded env32432 := by
  intro p hp
  have h : env32432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32431_32432 : H12AffineEnvironment.transform 9 272 env32431 = env32432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32431 == env32432) = true)

theorem identity32432 : scanCanonicalize (H12AffineFastState.compose env32432 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32432 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env32433 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,8192,4113,32,263,4096,10281,272,33,4144,32,16,2,8192,48,10540,4097,4097,10249,53,8493,256,32,12604,8972]

theorem envBound32433 : H12AffineFastState.Bounded env32433 := by
  intro p hp
  have h : env32433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32432_32433 : H12AffineEnvironment.transform 5 48 env32432 = env32433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32432 == env32433) = true)

def env32434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491564,2098649,4233,2524632,2102685,2142644,256,32,46212,2175563]

theorem envBound32434 : H12AffineFastState.Bounded env32434 := by
  intro p hp
  have h : env32434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32397_32434 : H12AffineEnvironment.transform 21 33 env32397 = env32434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32397 == env32434) = true)

theorem identity32434 : scanCanonicalize (H12AffineFastState.compose env32434 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound32434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491564,2098649,4233,2524632,2102685,2142644,256,32,46212,2143124]

theorem envBound32435 : H12AffineFastState.Bounded env32435 := by
  intro p hp
  have h : env32435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32434_32435 : H12AffineEnvironment.transform 15 33247 env32434 = env32435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env32434 == env32435) = true)

theorem identity32435 : scanCanonicalize (H12AffineFastState.compose env32435 (packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 301365) := by decide +kernel

theorem selectedBound32435 : packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env32436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,301365,33,297453,138,8328,64,171417,302316,4233,138477,298152,272513,256,32,46212,273057]

theorem envBound32436 : H12AffineFastState.Bounded env32436 := by
  intro p hp
  have h : env32436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32435_32436 : H12AffineEnvironment.transform 20 301365 env32435 = env32436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301365 env32435 == env32436) = true)

theorem identity32436 : scanCanonicalize (H12AffineFastState.compose env32436 (packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound32436 : packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS < 2^1333 := by decide +kernel

def env32437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10400,1024,32769,45461,33,41293,138,8328,64,171417,46156,4233,138477,41992,33,256,32,46212,513]

theorem envBound32437 : H12AffineFastState.Bounded env32437 := by
  intro p hp
  have h : env32437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32436_32437 : H12AffineEnvironment.transform 17 10400 env32436 = env32437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32436 == env32437) = true)

theorem identity32437 : scanCanonicalize (H12AffineFastState.compose env32437 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound32437 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env32438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13340,10400,1024,32769,45461,33,41293,138,8328,64,43397,46156,4233,10481,41992,33,256,32,46212,513]

theorem envBound32438 : H12AffineFastState.Bounded env32438 := by
  intro p hp
  have h : env32438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32437_32438 : H12AffineEnvironment.transform 16 13340 env32437 = env32438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env32437 == env32438) = true)

theorem identity32438 : scanCanonicalize (H12AffineFastState.compose env32438 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound32438 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env32439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13340,10400,1024,8661,4161,33,153,138,8328,64,2129,5528,4233,10481,1500,33,256,32,5456,513]

theorem envBound32439 : H12AffineFastState.Bounded env32439 := by
  intro p hp
  have h : env32439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32438_32439 : H12AffineEnvironment.transform 14 8660 env32438 = env32439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env32438 == env32439) = true)

theorem identity32439 : scanCanonicalize (H12AffineFastState.compose env32439 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound32439 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5377,1481,1046,4097,3261,1024,1480,4161,33,153,138,1173,64,2129,5528,4233,3308,1500,33,256,32,5456,513]

theorem envBound32440 : H12AffineFastState.Bounded env32440 := by
  intro p hp
  have h : env32440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32439_32440 : H12AffineEnvironment.transform 12 1053 env32439 = env32440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env32439 == env32440) = true)

theorem identity32440 : scanCanonicalize (H12AffineFastState.compose env32440 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound32440 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32441 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,4160,136,343,4097,2556,321,137,4161,33,153,138,468,64,2129,4313,4233,2477,157,33,256,32,4113,513]

theorem envBound32441 : H12AffineFastState.Bounded env32441 := by
  intro p hp
  have h : env32441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32440_32441 : H12AffineEnvironment.transform 9 321 env32440 = env32441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32440 == env32441) = true)

theorem identity32441 : scanCanonicalize (H12AffineFastState.compose env32441 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32442 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,4112,136,263,4097,2476,273,137,4113,33,153,138,388,16,2049,4233,4233,2477,157,33,256,32,4113,513]

theorem envBound32442 : H12AffineFastState.Bounded env32442 := by
  intro p hp
  have h : env32442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32441_32442 : H12AffineEnvironment.transform 5 16 env32441 = env32442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32441 == env32442) = true)

theorem identity32442 : scanCanonicalize (H12AffineFastState.compose env32442 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound32442 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32443 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,2493,268,2477,136,263,2492,2476,273,137,2476,33,153,138,388,16,2049,2356,2356,2477,157,33,256,32,2476,513]

theorem envBound32443 : H12AffineFastState.Bounded env32443 := by
  intro p hp
  have h : env32443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32442_32443 : H12AffineEnvironment.transform 11 2493 env32442 = env32443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env32442 == env32443) = true)

theorem identity32443 : scanCanonicalize (H12AffineFastState.compose env32443 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound32443 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32444 : List Nat := [2,4,8,16,32,16,128,256,512,273,396,49,268,33,136,263,48,32,273,137,32,33,153,138,388,16,397,184,184,33,157,33,256,32,32,513]

theorem envBound32444 : H12AffineFastState.Bounded env32444 := by
  intro p hp
  have h : env32444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32443_32444 : H12AffineEnvironment.transform 10 396 env32443 = env32444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env32443 == env32444) = true)

theorem identity32444 : scanCanonicalize (H12AffineFastState.compose env32444 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound32444 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env32445 : List Nat := [2,4,8,16,32,16,128,173,512,188,33,49,161,33,136,170,48,32,188,137,32,33,153,138,41,16,32,184,184,33,157,33,173,32,32,513]

theorem envBound32445 : H12AffineFastState.Bounded env32445 := by
  intro p hp
  have h : env32445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32444_32445 : H12AffineEnvironment.transform 7 173 env32444 = env32445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32444 == env32445) = true)

def env32446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685837,2098648,4232,2524633,2102685,6336916,256,32,46212,2175563]

theorem envBound32446 : H12AffineFastState.Bounded env32446 := by
  intro p hp
  have h : env32446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32396_32446 : H12AffineEnvironment.transform 22 2101465 env32396 = env32446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env32396 == env32446) = true)

def env32447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491565,2098648,4232,2524633,2102685,2142644,256,32,46212,2175563]

theorem envBound32447 : H12AffineFastState.Bounded env32447 := by
  intro p hp
  have h : env32447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32446_32447 : H12AffineEnvironment.transform 21 32 env32446 = env32447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env32446 == env32447) = true)

theorem identity32447 : scanCanonicalize (H12AffineFastState.compose env32447 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound32447 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,73755,98644,8328,64,472175,79130,4232,505115,75103,98678,256,32,46212,649]

theorem envBound32448 : H12AffineFastState.Bounded env32448 := by
  intro p hp
  have h : env32448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32447_32448 : H12AffineEnvironment.transform 20 78018 env32447 = env32448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env32447 == env32448) = true)

theorem identity32448 : scanCanonicalize (H12AffineFastState.compose env32448 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32448 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,21,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env32449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472175,79130,4096,505115,75103,98678,256,32,46092,513]

theorem envBound32449 : H12AffineFastState.Bounded env32449 := by
  intro p hp
  have h : env32449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32448_32449 : H12AffineEnvironment.transform 6 8 env32448 = env32449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32448 == env32449) = true)

theorem identity32449 : scanCanonicalize (H12AffineFastState.compose env32449 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32449 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env32450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,32,73755,73737,8192,64,472175,79130,4096,463942,75103,73771,256,32,5457,513]

theorem envBound32450 : H12AffineFastState.Bounded env32450 := by
  intro p hp
  have h : env32450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32449_32450 : H12AffineEnvironment.transform 14 8541 env32449 = env32450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32449 == env32450) = true)

theorem identity32450 : scanCanonicalize (H12AffineFastState.compose env32450 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32450 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4161,32,16,2,8192,64,398436,5393,4096,406605,1364,32,256,32,5457,513]

theorem envBound32451 : H12AffineFastState.Bounded env32451 := by
  intro p hp
  have h : env32451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32450_32451 : H12AffineEnvironment.transform 15 8203 env32450 = env32451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32450 == env32451) = true)

theorem identity32451 : scanCanonicalize (H12AffineFastState.compose env32451 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound32451 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10360,1024,8540,4161,32,16,2,8192,64,146460,5393,4096,138293,1364,32,256,32,5457,513]

theorem envBound32452 : H12AffineFastState.Bounded env32452 := by
  intro p hp
  have h : env32452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32451_32452 : H12AffineEnvironment.transform 17 10360 env32451 = env32452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env32451 == env32452) = true)

def env32453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491564,2098648,4232,2524633,2102685,2142645,256,32,46212,2175563]

theorem envBound32453 : H12AffineFastState.Bounded env32453 := by
  intro p hp
  have h : env32453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32446_32453 : H12AffineEnvironment.transform 21 33 env32446 = env32453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env32446 == env32453) = true)

theorem identity32453 : scanCanonicalize (H12AffineFastState.compose env32453 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32453 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101465,41311,8328,64,2491564,2098648,4232,2524633,2102685,2142645,256,32,46212,2101824]

theorem envBound32454 : H12AffineFastState.Bounded env32454 := by
  intro p hp
  have h : env32454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32453_32454 : H12AffineEnvironment.transform 15 8203 env32453 = env32454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32453 == env32454) = true)

def env32455 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101385,41231,8328,16,2491564,2098568,4232,2524553,2102685,2142645,256,32,46212,2101776]

theorem envBound32455 : H12AffineFastState.Bounded env32455 := by
  intro p hp
  have h : env32455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32454_32455 : H12AffineEnvironment.transform 5 16 env32454 = env32455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32454 == env32455) = true)

theorem identity32455 : scanCanonicalize (H12AffineFastState.compose env32455 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound32455 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env32456 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35245,1024,32769,2097152,33,2101385,41231,8328,16,2264321,2098568,4232,2231332,2102685,2142645,256,32,46212,2101776]

theorem envBound32456 : H12AffineFastState.Bounded env32456 := by
  intro p hp
  have h : env32456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32455_32456 : H12AffineEnvironment.transform 17 35245 env32455 = env32456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env32455 == env32456) = true)

theorem identity32456 : scanCanonicalize (H12AffineFastState.compose env32456 (packedSelected [0,3,9,10,22,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32456 : packedSelected [0,3,9,10,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32457 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35109,1024,32769,2097152,33,2101249,41231,8192,16,2264321,2098432,4096,2231332,2102549,2142525,256,32,46092,2101776]

theorem envBound32457 : H12AffineFastState.Bounded env32457 := by
  intro p hp
  have h : env32457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32456_32457 : H12AffineEnvironment.transform 6 8 env32456 = env32457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32456 == env32457) = true)

theorem identity32457 : scanCanonicalize (H12AffineFastState.compose env32457 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(20+1) ^^^ 4113) := by decide +kernel

theorem selectedBound32457 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32458 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35109,1024,32769,4113,33,16,41231,8192,16,171280,5393,4096,138293,1284,41260,256,32,46092,513]

theorem envBound32458 : H12AffineFastState.Bounded env32458 := by
  intro p hp
  have h : env32458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32457_32458 : H12AffineEnvironment.transform 20 4113 env32457 = env32458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4113 env32457 == env32458) = true)

theorem identity32458 : scanCanonicalize (H12AffineFastState.compose env32458 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32458 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32459 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,13341,35109,1024,32769,4113,33,16,41231,8192,16,43277,5393,4096,10280,1284,41260,256,32,46092,513]

theorem envBound32459 : H12AffineFastState.Bounded env32459 := by
  intro p hp
  have h : env32459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32458_32459 : H12AffineEnvironment.transform 16 13341 env32458 = env32459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env32458 == env32459) = true)

theorem identity32459 : scanCanonicalize (H12AffineFastState.compose env32459 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32459 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32460 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,1,8203,13341,2340,1024,0,4113,33,16,8462,8192,16,10508,5393,4096,10280,1284,8493,256,32,13325,513]

theorem envBound32460 : H12AffineFastState.Bounded env32460 := by
  intro p hp
  have h : env32460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32459_32460 : H12AffineEnvironment.transform 14 1 env32459 = env32460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32459 == env32460) = true)

theorem identity32460 : scanCanonicalize (H12AffineFastState.compose env32460 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32460 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32461 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1024,0,4113,33,16,2,268,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound32461 : H12AffineFastState.Bounded env32461 := by
  intro p hp
  have h : env32461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32460_32461 : H12AffineEnvironment.transform 12 268 env32460 = env32461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32460 == env32461) = true)

theorem identity32461 : scanCanonicalize (H12AffineFastState.compose env32461 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32462 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5173,2048,1024,0,4113,33,16,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound32462 : H12AffineFastState.Bounded env32462 := by
  intro p hp
  have h : env32462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32461_32462 : H12AffineEnvironment.transform 7 36 env32461 = env32462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32461 == env32462) = true)

def env32463 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101384,41230,8328,17,2491564,2098569,4232,2524552,2102685,2142645,256,32,46212,2101777]

theorem envBound32463 : H12AffineFastState.Bounded env32463 := by
  intro p hp
  have h : env32463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32454_32463 : H12AffineEnvironment.transform 5 17 env32454 = env32463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32454 == env32463) = true)

theorem identity32463 : scanCanonicalize (H12AffineFastState.compose env32463 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32463 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env32464 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101248,41230,8192,17,2491428,2098433,4096,2524416,2102549,2142525,256,32,46092,2101777]

theorem envBound32464 : H12AffineFastState.Bounded env32464 := by
  intro p hp
  have h : env32464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32463_32464 : H12AffineEnvironment.transform 6 8 env32463 = env32464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32463 == env32464) = true)

theorem identity32464 : scanCanonicalize (H12AffineFastState.compose env32464 (packedSelected [3,4,5,9,10,12,14,15,16,18,19,21,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound32464 : packedSelected [3,4,5,9,10,12,14,15,16,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env32465 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,262144,1024,8460,2097152,33,2101248,3,8192,17,2491428,2098433,4096,2499597,2102549,2101296,256,32,5377,2101777]

theorem envBound32465 : H12AffineFastState.Bounded env32465 := by
  intro p hp
  have h : env32465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32464_32465 : H12AffineEnvironment.transform 14 8461 env32464 = env32465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env32464 == env32465) = true)

theorem identity32465 : scanCanonicalize (H12AffineFastState.compose env32465 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound32465 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env32466 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,10281,1024,8460,2097152,33,2101248,3,8192,17,2239501,2098433,4096,2231332,2102549,2101296,256,32,5377,2101777]

theorem envBound32466 : H12AffineFastState.Bounded env32466 := by
  intro p hp
  have h : env32466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32465_32466 : H12AffineEnvironment.transform 17 10281 env32465 = env32466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32465 == env32466) = true)

theorem identity32466 : scanCanonicalize (H12AffineFastState.compose env32466 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 4128) := by decide +kernel

theorem selectedBound32466 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env32467 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,4128,10281,1024,8460,2097152,33,2101248,3,8192,17,2112557,2098433,4096,2104324,2102549,2101296,256,32,5377,2101777]

theorem envBound32467 : H12AffineFastState.Bounded env32467 := by
  intro p hp
  have h : env32467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32466_32467 : H12AffineEnvironment.transform 16 4128 env32466 = env32467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4128 env32466 == env32467) = true)

theorem identity32467 : scanCanonicalize (H12AffineFastState.compose env32467 (packedSelected [6,14] rootPS)) = affineNative (2^(20+1) ^^^ 12605) := by decide +kernel

theorem selectedBound32467 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env32468 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,4128,10281,1024,8460,12605,33,8509,3,8192,17,3344,13372,4096,11577,9256,8461,256,32,5377,9004]

theorem envBound32468 : H12AffineFastState.Bounded env32468 := by
  intro p hp
  have h : env32468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32467_32468 : H12AffineEnvironment.transform 20 12605 env32467 = env32468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12605 env32467 == env32468) = true)

theorem identity32468 : scanCanonicalize (H12AffineFastState.compose env32468 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound32468 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env32469 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,5377,1297,1047,4128,3125,1024,1296,5409,33,1313,3,1052,17,3344,4128,4096,2341,52,1297,256,32,5377,1840]

theorem envBound32469 : H12AffineFastState.Bounded env32469 := by
  intro p hp
  have h : env32469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32468_32469 : H12AffineEnvironment.transform 12 1052 env32468 = env32469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env32468 == env32469) = true)

theorem identity32469 : scanCanonicalize (H12AffineFastState.compose env32469 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32469 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32470 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,1052,5377,1297,1047,4096,3093,1024,1296,5377,1,1281,3,1052,17,3344,4096,4096,2309,20,1297,256,0,5377,1808]

theorem envBound32470 : H12AffineFastState.Bounded env32470 := by
  intro p hp
  have h : env32470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32469_32470 : H12AffineEnvironment.transform 4 0 env32469 = env32470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32469 == env32470) = true)

theorem identity32470 : scanCanonicalize (H12AffineFastState.compose env32470 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound32470 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32471 : List Nat := [2,4,8,16,0,17,8,256,512,1024,1808,4096,1052,5377,1297,1047,4096,773,1024,1296,5377,1,1281,3,1052,17,512,4096,4096,1557,20,1297,256,0,5377,1808]

theorem envBound32471 : H12AffineFastState.Bounded env32471 := by
  intro p hp
  have h : env32471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32470_32471 : H12AffineEnvironment.transform 10 1808 env32470 = env32471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env32470 == env32471) = true)

theorem identity32471 : scanCanonicalize (H12AffineFastState.compose env32471 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound32471 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32472 : List Nat := [2,4,8,16,0,17,8,256,512,257,529,4096,285,4096,16,278,4096,773,257,17,4096,1,0,3,285,17,512,4096,4096,788,20,16,256,0,4096,529]

theorem envBound32472 : H12AffineFastState.Bounded env32472 := by
  intro p hp
  have h : env32472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32471_32472 : H12AffineEnvironment.transform 9 257 env32471 = env32472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env32471 == env32472) = true)

theorem identity32472 : scanCanonicalize (H12AffineFastState.compose env32472 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32472 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32473 : List Nat := [2,4,8,1,0,0,8,256,512,257,512,4096,268,4096,1,263,4096,773,257,0,4096,1,0,3,268,0,512,4096,4096,773,5,1,256,0,4096,512]

theorem envBound32473 : H12AffineFastState.Bounded env32473 := by
  intro p hp
  have h : env32473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32472_32473 : H12AffineEnvironment.transform 3 1 env32472 = env32473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32472 == env32473) = true)

theorem identity32473 : scanCanonicalize (H12AffineFastState.compose env32473 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound32473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32474 : List Nat := [2,4,8,1,0,0,8,256,512,257,512,513,268,513,1,263,513,773,257,0,513,1,0,3,268,0,512,513,513,773,5,1,256,0,513,512]

theorem envBound32474 : H12AffineFastState.Bounded env32474 := by
  intro p hp
  have h : env32474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32473_32474 : H12AffineEnvironment.transform 11 513 env32473 = env32474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env32473 == env32474) = true)

theorem identity32474 : scanCanonicalize (H12AffineFastState.compose env32474 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound32474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32475 : List Nat := [2,4,7,1,0,0,7,256,512,257,512,513,259,513,1,263,513,773,257,0,513,1,0,3,259,0,512,513,513,773,5,1,256,0,513,512]

theorem envBound32475 : H12AffineFastState.Bounded env32475 := by
  intro p hp
  have h : env32475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32474_32475 : H12AffineEnvironment.transform 2 7 env32474 = env32475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env32474 == env32475) = true)

theorem identity32475 : scanCanonicalize (H12AffineFastState.compose env32475 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound32475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32476 : List Nat := [2,4,7,1,0,0,7,256,260,257,260,261,259,261,1,263,261,1,257,0,261,1,0,3,259,0,260,261,261,1,5,1,256,0,261,260]

theorem envBound32476 : H12AffineFastState.Bounded env32476 := by
  intro p hp
  have h : env32476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32475_32476 : H12AffineEnvironment.transform 8 260 env32475 = env32476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env32475 == env32476) = true)

theorem identity32476 : scanCanonicalize (H12AffineFastState.compose env32476 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32476 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32477 : List Nat := [2,4,7,1,0,0,7,4,0,5,0,1,7,1,1,3,1,1,5,0,1,1,0,3,7,0,0,1,1,1,5,1,4,0,1,0]

theorem envBound32477 : H12AffineFastState.Bounded env32477 := by
  intro p hp
  have h : env32477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32476_32477 : H12AffineEnvironment.transform 7 4 env32476 = env32477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32476 == env32477) = true)

end H12CloudChart1