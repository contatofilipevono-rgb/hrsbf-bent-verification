import H12CloudChart1Data113

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound28894 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28895 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5125,0,3,5141,2049,1024,1,4113,0,17,3,9,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound28895 : H12AffineFastState.Bounded env28895 := by
  intro p hp
  have h : env28895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28894_28895 : H12AffineEnvironment.transform 4 0 env28894 = env28895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28894 == env28895) = true)

def env28896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21763,8328,65,4291883,115151,17665,10281,119042,4268163,256,98814,90203,63189]

theorem envBound28896 : H12AffineFastState.Bounded env28896 := by
  intro p hp
  have h : env28896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28870_28896 : H12AffineEnvironment.transform 20 4161 env28870 = env28896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28870 == env28896) = true)

def env28897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21763,8192,65,4291883,115015,17665,10281,119042,4268043,256,98678,90203,63069]

theorem envBound28897 : H12AffineFastState.Bounded env28897 := by
  intro p hp
  have h : env28897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28896_28897 : H12AffineEnvironment.transform 6 8 env28896 = env28897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28896 == env28897) = true)

theorem identity28897 : scanCanonicalize (H12AffineFastState.compose env28897 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound28897 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28898 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4161,4194304,16,21763,8192,65,4291883,115015,17665,10281,119042,4268043,256,98678,90203,63069]

theorem envBound28898 : H12AffineFastState.Bounded env28898 := by
  intro p hp
  have h : env28898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28897_28898 : H12AffineEnvironment.transform 16 13388 env28897 = env28898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env28897 == env28898) = true)

theorem identity28898 : scanCanonicalize (H12AffineFastState.compose env28898 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(21+1) ^^^ 87159) := by decide +kernel

theorem selectedBound28898 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env28899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4161,87159,16,21763,8192,65,10588,115015,17665,10281,119042,29820,256,98678,90203,63069]

theorem envBound28899 : H12AffineFastState.Bounded env28899 := by
  intro p hp
  have h : env28899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28898_28899 : H12AffineEnvironment.transform 21 87159 env28898 = env28899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87159 env28898 == env28899) = true)

theorem identity28899 : scanCanonicalize (H12AffineFastState.compose env28899 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28899 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env28900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,13388,23669,1024,1,4161,87159,16,21763,8192,65,10588,82247,17665,10281,86274,29820,256,65910,90203,30301]

theorem envBound28900 : H12AffineFastState.Bounded env28900 := by
  intro p hp
  have h : env28900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28899_28900 : H12AffineEnvironment.transform 14 0 env28899 = env28900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28899 == env28900) = true)

theorem identity28900 : scanCanonicalize (H12AffineFastState.compose env28900 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28900 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env28901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,65536,5393,23669,1024,1,4161,87159,16,21763,349,65,2049,82247,17665,2420,86274,21793,256,65910,82182,22272]

theorem envBound28901 : H12AffineFastState.Bounded env28901 := by
  intro p hp
  have h : env28901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28900_28901 : H12AffineEnvironment.transform 12 349 env28900 = env28901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28900 == env28901) = true)

theorem identity28901 : scanCanonicalize (H12AffineFastState.compose env28901 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound28901 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21590,5393,23669,1024,1,4161,33,16,21763,349,65,2049,5393,17665,2420,1364,21793,256,21792,5456,22272]

theorem envBound28902 : H12AffineFastState.Bounded env28902 := by
  intro p hp
  have h : env28902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28901_28902 : H12AffineEnvironment.transform 15 21590 env28901 = env28902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env28901 == env28902) = true)

theorem identity28902 : scanCanonicalize (H12AffineFastState.compose env28902 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound28902 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5408,0,374,5393,2389,1024,1,4161,33,16,35,349,65,2049,5393,4129,2420,1364,1,256,0,5456,544]

theorem envBound28903 : H12AffineFastState.Bounded env28903 := by
  intro p hp
  have h : env28903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28902_28903 : H12AffineEnvironment.transform 13 5408 env28902 = env28903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env28902 == env28903) = true)

theorem identity28903 : scanCanonicalize (H12AffineFastState.compose env28903 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28903 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28904 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5408,0,295,5393,2308,1024,1,4112,33,16,35,268,16,2049,5393,4129,2341,1285,1,256,0,5377,544]

theorem envBound28904 : H12AffineFastState.Bounded env28904 := by
  intro p hp
  have h : env28904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28903_28904 : H12AffineEnvironment.transform 5 17 env28903 = env28904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28903 == env28904) = true)

theorem identity28904 : scanCanonicalize (H12AffineFastState.compose env28904 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28904 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28905 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,0,263,5393,2308,1024,1,4112,1,16,3,268,16,2049,5393,4097,2309,1285,1,256,0,5377,512]

theorem envBound28905 : H12AffineFastState.Bounded env28905 := by
  intro p hp
  have h : env28905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28904_28905 : H12AffineEnvironment.transform 4 0 env28904 = env28905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28904 == env28905) = true)

theorem identity28905 : scanCanonicalize (H12AffineFastState.compose env28905 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound28905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28906 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,4096,268,4373,0,263,4356,2308,21,1,4112,1,16,3,268,16,2049,4356,4097,2309,272,1,256,0,4372,512]

theorem envBound28906 : H12AffineFastState.Bounded env28906 := by
  intro p hp
  have h : env28906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28905_28906 : H12AffineEnvironment.transform 9 21 env28905 = env28906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env28905 == env28906) = true)

theorem identity28906 : scanCanonicalize (H12AffineFastState.compose env28906 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound28906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28907 : List Nat := [2,4,8,16,0,17,8,256,512,21,523,4096,268,4373,0,263,4356,783,21,1,4112,1,16,3,268,16,522,4356,4097,782,272,1,256,0,4372,512]

theorem envBound28907 : H12AffineFastState.Bounded env28907 := by
  intro p hp
  have h : env28907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28906_28907 : H12AffineEnvironment.transform 10 523 env28906 = env28907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env28906 == env28907) = true)

theorem identity28907 : scanCanonicalize (H12AffineFastState.compose env28907 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound28907 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28908 : List Nat := [2,4,8,16,0,17,8,256,261,21,270,4096,268,4373,0,263,4356,10,21,1,4112,1,16,3,268,16,271,4356,4097,11,272,1,256,0,4372,261]

theorem envBound28908 : H12AffineFastState.Bounded env28908 := by
  intro p hp
  have h : env28908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28907_28908 : H12AffineEnvironment.transform 8 261 env28907 = env28908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env28907 == env28908) = true)

theorem identity28908 : scanCanonicalize (H12AffineFastState.compose env28908 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound28908 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28909 : List Nat := [2,4,8,16,0,17,8,256,261,21,270,261,268,16,0,263,1,10,21,1,277,1,16,3,268,16,271,1,260,11,272,1,256,0,17,261]

theorem envBound28909 : H12AffineFastState.Bounded env28909 := by
  intro p hp
  have h : env28909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28908_28909 : H12AffineEnvironment.transform 11 261 env28908 = env28909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env28908 == env28909) = true)

theorem identity28909 : scanCanonicalize (H12AffineFastState.compose env28909 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 23) := by decide +kernel

theorem selectedBound28909 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28910 : List Nat := [2,4,8,16,0,17,8,23,18,21,25,18,27,16,0,16,1,10,21,1,2,1,16,3,27,16,24,1,19,11,7,1,23,0,17,18]

theorem envBound28910 : H12AffineFastState.Bounded env28910 := by
  intro p hp
  have h : env28910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28909_28910 : H12AffineEnvironment.transform 7 23 env28909 = env28910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 23 env28909 == env28910) = true)

theorem identity28910 : scanCanonicalize (H12AffineFastState.compose env28910 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound28910 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28911 : List Nat := [2,4,8,3,0,2,8,4,1,6,10,1,8,3,0,3,1,10,6,1,2,1,3,3,8,3,11,1,0,11,7,1,4,0,2,1]

theorem envBound28911 : H12AffineFastState.Bounded env28911 := by
  intro p hp
  have h : env28911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28910_28911 : H12AffineEnvironment.transform 3 3 env28910 = env28911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env28910 == env28911) = true)

theorem identity28911 : scanCanonicalize (H12AffineFastState.compose env28911 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28912 : List Nat := [2,3,8,3,0,2,8,3,1,1,10,1,8,3,0,3,1,10,1,1,2,1,3,3,8,3,11,1,0,11,0,1,3,0,2,1]

theorem envBound28912 : H12AffineFastState.Bounded env28912 := by
  intro p hp
  have h : env28912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28911_28912 : H12AffineEnvironment.transform 1 3 env28911 = env28912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28911 == env28912) = true)

def env28913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21763,8193,65,4291883,115014,17665,10281,119042,4268042,256,98679,90203,63068]

theorem envBound28913 : H12AffineFastState.Bounded env28913 := by
  intro p hp
  have h : env28913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28896_28913 : H12AffineEnvironment.transform 6 9 env28896 = env28913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28896 == env28913) = true)

theorem identity28913 : scanCanonicalize (H12AffineFastState.compose env28913 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound28913 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,32041,1024,32769,4161,4194304,16,21763,8193,65,4291883,115014,17665,10281,119042,4268042,256,98679,90203,63068]

theorem envBound28914 : H12AffineFastState.Bounded env28914 := by
  intro p hp
  have h : env28914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28913_28914 : H12AffineEnvironment.transform 16 38160 env28913 = env28914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28913 == env28914) = true)

theorem identity28914 : scanCanonicalize (H12AffineFastState.compose env28914 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound28914 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env28915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,32041,1024,32769,4161,4194304,16,21763,8193,65,4229153,13388,17665,10281,9224,4248832,256,29821,38225,63068]

theorem envBound28915 : H12AffineFastState.Bounded env28915 := by
  intro p hp
  have h : env28915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28914_28915 : H12AffineEnvironment.transform 15 62730 env28914 = env28915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env28914 == env28915) = true)

theorem identity28915 : scanCanonicalize (H12AffineFastState.compose env28915 (packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS)) = affineNative (2^(21+1) ^^^ 62729) := by decide +kernel

theorem selectedBound28915 : packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS < 2^1333 := by decide +kernel

def env28916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,32041,1024,32769,4161,62729,16,21763,8193,65,32040,13388,17665,10281,9224,8201,256,29821,38225,63068]

theorem envBound28916 : H12AffineFastState.Bounded env28916 := by
  intro p hp
  have h : env28916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28915_28916 : H12AffineEnvironment.transform 21 62729 env28915 = env28916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62729 env28915 == env28916) = true)

theorem identity28916 : scanCanonicalize (H12AffineFastState.compose env28916 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28916 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env28917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,24909,32041,1024,29788,4161,340,16,21763,8193,65,32040,13388,17665,10281,9224,8201,256,29821,24844,513]

theorem envBound28917 : H12AffineFastState.Bounded env28917 := by
  intro p hp
  have h : env28917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28916_28917 : H12AffineEnvironment.transform 14 29789 env28916 = env28917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28916 == env28917) = true)

theorem identity28917 : scanCanonicalize (H12AffineFastState.compose env28917 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28917 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,9292,343,12636,11576,1024,9293,4161,340,16,1298,8193,65,11577,13388,5392,10281,9224,8201,256,9324,12573,513]

theorem envBound28918 : H12AffineFastState.Bounded env28918 := by
  intro p hp
  have h : env28918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28917_28918 : H12AffineEnvironment.transform 13 4113 env28917 = env28918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28917 == env28918) = true)

theorem identity28918 : scanCanonicalize (H12AffineFastState.compose env28918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1296,343,4096,3172,1024,1297,4161,340,16,1298,349,65,3173,5392,5392,2421,1364,341,256,1328,4161,513]

theorem envBound28919 : H12AffineFastState.Bounded env28919 := by
  intro p hp
  have h : env28919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28918_28919 : H12AffineEnvironment.transform 12 348 env28918 = env28919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28918 == env28919) = true)

theorem identity28919 : scanCanonicalize (H12AffineFastState.compose env28919 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound28919 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,0,348,17,1296,343,0,3172,1024,1297,65,340,16,1298,349,65,3173,1296,1296,2421,1364,341,256,1328,65,513]

theorem envBound28920 : H12AffineFastState.Bounded env28920 := by
  intro p hp
  have h : env28920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28919_28920 : H12AffineEnvironment.transform 11 0 env28919 = env28920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env28919 == env28920) = true)

theorem identity28920 : scanCanonicalize (H12AffineFastState.compose env28920 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28920 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env28921 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,0,120,17,1076,115,0,3172,1024,1077,65,112,16,1078,121,65,3173,1076,1076,2129,1136,113,36,1044,65,513]

theorem envBound28921 : H12AffineFastState.Bounded env28921 := by
  intro p hp
  have h : env28921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28920_28921 : H12AffineEnvironment.transform 7 36 env28920 = env28921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28920 == env28921) = true)

theorem identity28921 : scanCanonicalize (H12AffineFastState.compose env28921 (packedSelected [1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound28921 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env28922 : List Nat := [2,4,8,16,32,64,9,36,113,1024,2048,0,120,17,1076,115,0,3172,1024,1077,65,112,16,1078,121,65,3173,1076,1076,2129,1136,113,36,1044,65,112]

theorem envBound28922 : H12AffineFastState.Bounded env28922 := by
  intro p hp
  have h : env28922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28921_28922 : H12AffineEnvironment.transform 8 113 env28921 = env28922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env28921 == env28922) = true)

theorem identity28922 : scanCanonicalize (H12AffineFastState.compose env28922 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28922 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28923 : List Nat := [2,4,8,16,32,48,9,36,1,1024,2048,0,8,17,1076,3,0,3092,1024,1077,49,0,16,1078,9,49,3093,1076,1076,2081,1024,1,36,1044,49,0]

theorem envBound28923 : H12AffineFastState.Bounded env28923 := by
  intro p hp
  have h : env28923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28922_28923 : H12AffineEnvironment.transform 5 48 env28922 = env28923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28922 == env28923) = true)

theorem identity28923 : scanCanonicalize (H12AffineFastState.compose env28923 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28924 : List Nat := [2,4,8,16,1,17,9,5,1,1024,2048,0,8,17,1045,3,0,3092,1024,1044,16,0,16,1047,9,16,3093,1045,1045,2048,1024,1,5,1044,16,0]

theorem envBound28924 : H12AffineFastState.Bounded env28924 := by
  intro p hp
  have h : env28924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28923_28924 : H12AffineEnvironment.transform 4 1 env28923 = env28924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28923 == env28924) = true)

theorem identity28924 : scanCanonicalize (H12AffineFastState.compose env28924 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound28924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28925 : List Nat := [2,4,8,16,1,17,9,5,1,1024,16,0,8,17,1045,3,0,1028,1024,1044,16,0,16,1047,9,16,1029,1045,1045,16,1024,1,5,1044,16,0]

theorem envBound28925 : H12AffineFastState.Bounded env28925 := by
  intro p hp
  have h : env28925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28924_28925 : H12AffineEnvironment.transform 10 16 env28924 = env28925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env28924 == env28925) = true)

theorem identity28925 : scanCanonicalize (H12AffineFastState.compose env28925 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28925 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28926 : List Nat := [2,4,8,16,1,17,9,5,1,4,16,0,8,17,17,3,0,0,4,16,16,0,16,19,9,16,1,17,17,16,4,1,5,16,16,0]

theorem envBound28926 : H12AffineFastState.Bounded env28926 := by
  intro p hp
  have h : env28926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28925_28926 : H12AffineEnvironment.transform 9 4 env28925 = env28926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28925 == env28926) = true)

theorem identity28926 : scanCanonicalize (H12AffineFastState.compose env28926 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28927 : List Nat := [2,4,8,1,1,0,9,5,1,4,1,0,8,0,0,3,0,0,4,1,1,0,1,2,9,1,1,0,0,1,4,1,5,1,1,0]

theorem envBound28927 : H12AffineFastState.Bounded env28927 := by
  intro p hp
  have h : env28927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28926_28927 : H12AffineEnvironment.transform 3 1 env28926 = env28927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28926 == env28927) = true)

def env28928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound28928 : H12AffineFastState.Bounded env28928 := by
  intro p hp
  have h : env28928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28727_28928 : H12AffineEnvironment.transform 18 1025 env28727 = env28928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28727 == env28928) = true)

theorem identity28928 : scanCanonicalize (H12AffineFastState.compose env28928 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444795) := by decide +kernel

theorem selectedBound28928 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444795,16777216,8328,65,23236091,18973836,333995,2330106,19188202,23160257,257,17074518,17066226,19263036]

theorem envBound28929 : H12AffineFastState.Bounded env28929 := by
  intro p hp
  have h : env28929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28928_28929 : H12AffineEnvironment.transform 22 2444795 env28928 = env28929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444795 env28928 == env28929) = true)

def env28930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,16777216,8328,65,16959643,18973836,333995,2330106,19188202,16851105,257,17074518,17066226,19263036]

theorem envBound28930 : H12AffineFastState.Bounded env28930 := by
  intro p hp
  have h : env28930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28929_28930 : H12AffineEnvironment.transform 21 2114912 env28929 = env28930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env28929 == env28930) = true)

def env28931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431208,8328,65,2609267,302180,333995,2330106,119042,2373705,257,2199998,2191386,63188]

theorem envBound28931 : H12AffineFastState.Bounded env28931 := by
  intro p hp
  have h : env28931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28930_28931 : H12AffineEnvironment.transform 23 2431208 env28930 = env28931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env28930 == env28931) = true)

def env28932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329896,8328,65,507955,302180,333995,236986,119042,272393,257,98814,90202,63188]

theorem envBound28932 : H12AffineFastState.Bounded env28932 := by
  intro p hp
  have h : env28932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28931_28932 : H12AffineEnvironment.transform 20 4160 env28931 = env28932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28931 == env28932) = true)

def env28933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,21792,95515,73736,8328,65,256147,46276,77835,236986,119042,169,257,98814,90202,63188]

theorem envBound28933 : H12AffineFastState.Bounded env28933 := by
  intro p hp
  have h : env28933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28932_28933 : H12AffineEnvironment.transform 17 10400 env28932 = env28933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env28932 == env28933) = true)

def env28934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,21792,95515,73736,8192,65,256027,46156,77835,236850,119042,33,257,98678,90202,63068]

theorem envBound28934 : H12AffineFastState.Bounded env28934 := by
  intro p hp
  have h : env28934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28933_28934 : H12AffineEnvironment.transform 6 8 env28933 = env28934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28933 == env28934) = true)

theorem identity28934 : scanCanonicalize (H12AffineFastState.compose env28934 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28934 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,32,73755,73736,8192,65,245019,46156,77835,236850,99330,33,257,98678,79194,41820]

theorem envBound28935 : H12AffineFastState.Bounded env28935 := by
  intro p hp
  have h : env28935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28934_28935 : H12AffineEnvironment.transform 13 5376 env28934 = env28935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28934 == env28935) = true)

theorem identity28935 : scanCanonicalize (H12AffineFastState.compose env28935 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound28935 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103495,10280,1025,32769,4160,32,73755,73736,8192,65,10588,46156,77835,2421,99330,33,257,98678,79194,41820]

theorem envBound28936 : H12AffineFastState.Bounded env28936 := by
  intro p hp
  have h : env28936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28935_28936 : H12AffineEnvironment.transform 16 103495 env28935 = env28936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env28935 == env28936) = true)

theorem identity28936 : scanCanonicalize (H12AffineFastState.compose env28936 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound28936 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,9498,45405,10280,1025,32769,4160,32,1281,1298,8192,65,10588,46156,5393,2421,41240,33,257,42092,4160,41820]

theorem envBound28937 : H12AffineFastState.Bounded env28937 := by
  intro p hp
  have h : env28937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28936_28937 : H12AffineEnvironment.transform 15 9498 env28936 = env28937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env28936 == env28937) = true)

theorem identity28937 : scanCanonicalize (H12AffineFastState.compose env28937 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28937 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9498,4097,10280,1025,8541,4160,32,1281,1298,8192,65,10588,5392,5393,2421,68,33,257,1328,4160,512]

theorem envBound28938 : H12AffineFastState.Bounded env28938 := by
  intro p hp
  have h : env28938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28937_28938 : H12AffineEnvironment.transform 14 8540 env28937 = env28938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28937 == env28938) = true)

theorem identity28938 : scanCanonicalize (H12AffineFastState.compose env28938 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4428) := by decide +kernel

theorem selectedBound28938 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4428,5376,4112,5206,4097,6500,1025,4113,4160,32,1281,1298,4428,65,6160,5392,5393,2421,68,33,257,1328,4160,512]

theorem envBound28939 : H12AffineFastState.Bounded env28939 := by
  intro p hp
  have h : env28939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28938_28939 : H12AffineEnvironment.transform 12 4428 env28938 = env28939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4428 env28938 == env28939) = true)

theorem identity28939 : scanCanonicalize (H12AffineFastState.compose env28939 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28939 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env28940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,4428,5376,4112,5206,4097,4452,1025,4113,4160,32,1281,1298,4428,65,4112,5392,5393,373,68,33,257,1328,4160,512]

theorem envBound28940 : H12AffineFastState.Bounded env28940 := by
  intro p hp
  have h : env28940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28939_28940 : H12AffineEnvironment.transform 10 0 env28939 = env28940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28939 == env28940) = true)

theorem identity28940 : scanCanonicalize (H12AffineFastState.compose env28940 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound28940 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28941 : List Nat := [2,4,8,16,32,64,8,256,512,69,0,4096,4428,4421,4112,4115,4097,4452,68,4113,4160,32,324,343,4428,65,4112,4437,4436,373,68,33,257,373,4160,512]

theorem envBound28941 : H12AffineFastState.Bounded env28941 := by
  intro p hp
  have h : env28941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28940_28941 : H12AffineEnvironment.transform 9 69 env28940 = env28941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env28940 == env28941) = true)

theorem identity28941 : scanCanonicalize (H12AffineFastState.compose env28941 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28941 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28942 : List Nat := [2,4,8,16,32,64,8,256,512,69,0,17,349,340,1,2,16,373,68,0,81,32,324,343,349,65,1,324,325,373,68,33,257,373,81,512]

theorem envBound28942 : H12AffineFastState.Bounded env28942 := by
  intro p hp
  have h : env28942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28941_28942 : H12AffineEnvironment.transform 11 17 env28941 = env28942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28941 == env28942) = true)

theorem identity28942 : scanCanonicalize (H12AffineFastState.compose env28942 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28942 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28943 : List Nat := [2,4,8,16,32,48,8,256,512,53,0,17,301,292,1,2,16,261,52,0,33,32,308,295,301,49,1,308,309,261,52,33,257,261,33,512]

theorem envBound28943 : H12AffineFastState.Bounded env28943 := by
  intro p hp
  have h : env28943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28942_28943 : H12AffineEnvironment.transform 5 48 env28942 = env28943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28942 == env28943) = true)

theorem identity28943 : scanCanonicalize (H12AffineFastState.compose env28943 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28943 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28944 : List Nat := [2,4,8,16,32,48,8,5,512,53,0,17,40,33,1,2,16,0,52,0,33,32,49,34,40,49,1,49,48,0,52,33,4,0,33,512]

theorem envBound28944 : H12AffineFastState.Bounded env28944 := by
  intro p hp
  have h : env28944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28943_28944 : H12AffineEnvironment.transform 7 5 env28943 = env28944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28943 == env28944) = true)

theorem identity28944 : scanCanonicalize (H12AffineFastState.compose env28944 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound28944 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env28945 : List Nat := [2,4,8,16,32,48,8,5,16,53,0,17,40,33,1,2,16,0,52,0,33,32,49,34,40,49,1,49,48,0,52,33,4,0,33,16]

theorem envBound28945 : H12AffineFastState.Bounded env28945 := by
  intro p hp
  have h : env28945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28944_28945 : H12AffineEnvironment.transform 8 16 env28944 = env28945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env28944 == env28945) = true)

theorem identity28945 : scanCanonicalize (H12AffineFastState.compose env28945 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28945 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28946 : List Nat := [2,4,8,16,1,17,8,5,16,20,0,17,9,0,1,2,16,0,21,0,0,1,16,3,9,16,1,16,17,0,21,0,4,0,0,16]

theorem envBound28946 : H12AffineFastState.Bounded env28946 := by
  intro p hp
  have h : env28946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28945_28946 : H12AffineEnvironment.transform 4 1 env28945 = env28946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28945 == env28946) = true)

theorem identity28946 : scanCanonicalize (H12AffineFastState.compose env28946 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28947 : List Nat := [2,0,8,16,1,17,8,1,16,16,0,17,9,0,1,2,16,0,17,0,0,1,16,3,9,16,1,16,17,0,17,0,0,0,0,16]

theorem envBound28947 : H12AffineFastState.Bounded env28947 := by
  intro p hp
  have h : env28947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28946_28947 : H12AffineEnvironment.transform 1 0 env28946 = env28947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28946 == env28947) = true)

def env28948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,21792,95515,73736,8193,65,256026,46157,77835,236851,119042,32,257,98679,90202,63069]

theorem envBound28948 : H12AffineFastState.Bounded env28948 := by
  intro p hp
  have h : env28948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28933_28948 : H12AffineEnvironment.transform 6 9 env28933 = env28948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28933 == env28948) = true)

theorem identity28948 : scanCanonicalize (H12AffineFastState.compose env28948 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28948 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,4160,21792,95515,73736,8193,65,203846,16401,77835,223599,75102,32,257,95531,90202,513]

theorem envBound28949 : H12AffineFastState.Bounded env28949 := by
  intro p hp
  have h : env28949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28948_28949 : H12AffineEnvironment.transform 14 29788 env28948 = env28949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28948 == env28949) = true)

theorem identity28949 : scanCanonicalize (H12AffineFastState.compose env28949 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound28949 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env28950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,131072,10281,1025,29789,4160,21792,21824,83,8193,65,146461,16401,4176,149812,1285,32,257,21872,16385,513]

theorem envBound28950 : H12AffineFastState.Bounded env28950 := by
  intro p hp
  have h : env28950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28949_28950 : H12AffineEnvironment.transform 15 8283 env28949 = env28950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env28949 == env28950) = true)

theorem identity28950 : scanCanonicalize (H12AffineFastState.compose env28950 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound28950 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8283,24860,10281,1025,29789,4160,21792,21824,83,8193,65,23809,16401,4176,10280,1285,32,257,21872,16385,513]

theorem envBound28951 : H12AffineFastState.Bounded env28951 := by
  intro p hp
  have h : env28951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28950_28951 : H12AffineEnvironment.transform 16 24860 env28950 = env28951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env28950 == env28951) = true)

theorem identity28951 : scanCanonicalize (H12AffineFastState.compose env28951 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28951 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28952 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8203,24860,10281,1025,29709,4112,21792,21776,3,8193,17,23809,16401,4096,10280,1285,32,257,21792,16385,513]

theorem envBound28952 : H12AffineFastState.Bounded env28952 := by
  intro p hp
  have h : env28952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28951_28952 : H12AffineEnvironment.transform 5 16 env28951 = env28952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28951 == env28952) = true)

theorem identity28952 : scanCanonicalize (H12AffineFastState.compose env28952 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28952 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28953 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8203,13340,10281,1025,8461,4112,32,16,3,8193,17,2049,5393,4096,10280,1285,32,257,32,5377,513]

theorem envBound28953 : H12AffineFastState.Bounded env28953 := by
  intro p hp
  have h : env28953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28952_28953 : H12AffineEnvironment.transform 13 5376 env28952 = env28953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28952 == env28953) = true)

theorem identity28953 : scanCanonicalize (H12AffineFastState.compose env28953 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound28953 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28954 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1280,8192,0,8460,8203,8476,10281,1025,8461,1296,32,16,3,8193,17,2049,17,1280,10280,1285,32,257,32,1,513]

theorem envBound28954 : H12AffineFastState.Bounded env28954 := by
  intro p hp
  have h : env28954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28953_28954 : H12AffineEnvironment.transform 11 1280 env28953 = env28954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env28953 == env28954) = true)

theorem identity28954 : scanCanonicalize (H12AffineFastState.compose env28954 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound28954 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28955 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1280,3384,0,3124,3379,3108,1297,1025,3125,1296,32,16,3,3385,17,2049,17,1280,1296,1285,32,257,32,1,513]

theorem envBound28955 : H12AffineFastState.Bounded env28955 := by
  intro p hp
  have h : env28955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28954_28955 : H12AffineEnvironment.transform 12 3384 env28954 = env28955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env28954 == env28955) = true)

theorem identity28955 : scanCanonicalize (H12AffineFastState.compose env28955 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound28955 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28956 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1296,1280,40,0,292,35,308,1297,1025,293,1296,32,16,3,41,17,1297,17,1280,1296,1285,32,257,32,1,513]

theorem envBound28956 : H12AffineFastState.Bounded env28956 := by
  intro p hp
  have h : env28956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28955_28956 : H12AffineEnvironment.transform 10 1296 env28955 = env28956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env28955 == env28956) = true)

theorem identity28956 : scanCanonicalize (H12AffineFastState.compose env28956 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28956 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env28957 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1060,40,0,0,35,16,1077,1025,1,1076,32,16,3,41,17,1077,17,1060,1076,1057,32,37,32,1,513]

theorem envBound28957 : H12AffineFastState.Bounded env28957 := by
  intro p hp
  have h : env28957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28956_28957 : H12AffineEnvironment.transform 7 36 env28956 = env28957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28956 == env28957) = true)

theorem identity28957 : scanCanonicalize (H12AffineFastState.compose env28957 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28957 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28958 : List Nat := [2,4,8,0,32,0,9,36,512,1024,1060,1060,40,0,0,35,0,1061,1025,1,1060,32,0,3,41,1,1061,1,1060,1060,1057,32,37,32,1,513]

theorem envBound28958 : H12AffineFastState.Bounded env28958 := by
  intro p hp
  have h : env28958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28957_28958 : H12AffineEnvironment.transform 3 0 env28957 = env28958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28957 == env28958) = true)

theorem identity28958 : scanCanonicalize (H12AffineFastState.compose env28958 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound28958 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28959 : List Nat := [2,4,8,0,32,0,9,36,512,46,10,10,40,0,0,35,0,11,47,1,10,32,0,3,41,1,11,1,10,10,15,32,37,32,1,513]

theorem envBound28959 : H12AffineFastState.Bounded env28959 := by
  intro p hp
  have h : env28959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28958_28959 : H12AffineEnvironment.transform 9 46 env28958 = env28959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env28958 == env28959) = true)

theorem identity28959 : scanCanonicalize (H12AffineFastState.compose env28959 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28959 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28960 : List Nat := [2,4,8,0,11,0,9,15,512,5,10,10,3,0,0,8,0,11,4,1,10,11,0,3,2,1,11,1,10,10,15,11,14,11,1,513]

theorem envBound28960 : H12AffineFastState.Bounded env28960 := by
  intro p hp
  have h : env28960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28959_28960 : H12AffineEnvironment.transform 4 11 env28959 = env28960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28959 == env28960) = true)

theorem identity28960 : scanCanonicalize (H12AffineFastState.compose env28960 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound28960 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28961 : List Nat := [2,4,8,0,11,0,9,15,14,5,10,10,3,0,0,8,0,11,4,1,10,11,0,3,2,1,11,1,10,10,15,11,14,11,1,15]

theorem envBound28961 : H12AffineFastState.Bounded env28961 := by
  intro p hp
  have h : env28961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28960_28961 : H12AffineEnvironment.transform 8 14 env28960 = env28961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env28960 == env28961) = true)

theorem identity28961 : scanCanonicalize (H12AffineFastState.compose env28961 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28961 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28962 : List Nat := [2,4,3,0,0,0,2,4,5,5,1,1,3,0,0,3,0,0,4,1,1,0,0,3,2,1,0,1,1,1,4,0,5,0,1,4]

theorem envBound28962 : H12AffineFastState.Bounded env28962 := by
  intro p hp
  have h : env28962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28961_28962 : H12AffineEnvironment.transform 2 3 env28961 = env28962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28961 == env28962) = true)

theorem identity28962 : scanCanonicalize (H12AffineFastState.compose env28962 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28963 : List Nat := [1,4,0,0,0,0,1,4,5,5,1,1,0,0,0,0,0,0,4,1,1,0,0,0,1,1,0,1,1,1,4,0,5,0,1,4]

theorem envBound28963 : H12AffineFastState.Bounded env28963 := by
  intro p hp
  have h : env28963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28962_28963 : H12AffineEnvironment.transform 0 1 env28962 = env28963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28962 == env28963) = true)

def env28964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,21792,95514,73737,8328,65,256146,46277,77834,236986,119042,168,257,98814,90202,63188]

theorem envBound28964 : H12AffineFastState.Bounded env28964 := by
  intro p hp
  have h : env28964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28932_28964 : H12AffineEnvironment.transform 17 10401 env28932 = env28964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28932 == env28964) = true)

theorem identity28964 : scanCanonicalize (H12AffineFastState.compose env28964 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound28964 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10401,1025,32769,4160,21792,95514,73737,8328,65,68062,46277,77834,97526,119042,168,257,98814,90202,63188]

theorem envBound28965 : H12AffineFastState.Bounded env28965 := by
  intro p hp
  have h : env28965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28964_28965 : H12AffineEnvironment.transform 16 57676 env28964 = env28965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env28964 == env28965) = true)

theorem identity28965 : scanCanonicalize (H12AffineFastState.compose env28965 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound28965 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env28966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,57676,10401,1025,32769,4160,21792,41413,62678,8328,65,56577,46277,58581,43049,1501,168,257,21793,46213,63188]

theorem envBound28966 : H12AffineFastState.Bounded env28966 := by
  intro p hp
  have h : env28966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28965_28966 : H12AffineEnvironment.transform 15 54495 env28965 = env28966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env28965 == env28966) = true)

theorem identity28966 : scanCanonicalize (H12AffineFastState.compose env28966 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28966 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env28967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33111,46276,10401,1025,32769,4160,168,41413,41310,8328,65,34953,46277,45405,43049,1501,168,257,169,46213,41820]

theorem envBound28967 : H12AffineFastState.Bounded env28967 := by
  intro p hp
  have h : env28967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28966_28967 : H12AffineEnvironment.transform 13 5512 env28966 = env28967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28966 == env28967) = true)

theorem identity28967 : scanCanonicalize (H12AffineFastState.compose env28967 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28967 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,46157,10280,1025,32769,4160,33,41292,41310,8193,65,34816,46156,45405,43049,1364,33,257,32,46092,41820]

theorem envBound28968 : H12AffineFastState.Bounded env28968 := by
  intro p hp
  have h : env28968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28967_28968 : H12AffineEnvironment.transform 6 9 env28967 = env28968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28967 == env28968) = true)

theorem identity28968 : scanCanonicalize (H12AffineFastState.compose env28968 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28968 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28969 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,32768,33111,45405,10280,273,32769,4160,33,41292,41310,8193,65,34816,45404,45405,43049,68,33,257,32,45340,41820]

theorem envBound28969 : H12AffineFastState.Bounded env28969 := by
  intro p hp
  have h : env28969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28968_28969 : H12AffineEnvironment.transform 9 272 env28968 = env28969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28968 == env28969) = true)

theorem identity28969 : scanCanonicalize (H12AffineFastState.compose env28969 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28969 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28970 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4113,32768,33111,36945,2340,273,32769,4160,33,32832,32850,269,65,34816,36944,36945,35109,68,33,257,32,36880,33360]

theorem envBound28970 : H12AffineFastState.Bounded env28970 := by
  intro p hp
  have h : env28970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28969_28970 : H12AffineEnvironment.transform 12 268 env28969 = env28970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28969 == env28970) = true)

theorem identity28970 : scanCanonicalize (H12AffineFastState.compose env28970 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound28970 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28971 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4113,261,82,4436,2340,273,260,4160,33,325,343,269,65,2309,4437,4436,2080,68,33,257,32,4373,853]

theorem envBound28971 : H12AffineFastState.Bounded env28971 := by
  intro p hp
  have h : env28971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28970_28971 : H12AffineEnvironment.transform 14 261 env28970 = env28971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env28970 == env28971) = true)

theorem identity28971 : scanCanonicalize (H12AffineFastState.compose env28971 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28971 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env28972 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,268,4113,261,82,4436,2308,273,260,4160,1,325,343,269,65,2309,4437,4436,2048,68,1,257,0,4373,853]

theorem envBound28972 : H12AffineFastState.Bounded env28972 := by
  intro p hp
  have h : env28972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28971_28972 : H12AffineEnvironment.transform 4 0 env28971 = env28972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28971 == env28972) = true)

theorem identity28972 : scanCanonicalize (H12AffineFastState.compose env28972 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound28972 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28973 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,89,4113,80,82,4097,2129,68,81,4160,1,16,2,88,65,2128,4096,4097,2048,68,1,84,0,4160,512]

theorem envBound28973 : H12AffineFastState.Bounded env28973 := by
  intro p hp
  have h : env28973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28972_28973 : H12AffineEnvironment.transform 7 85 env28972 = env28973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env28972 == env28973) = true)

theorem identity28973 : scanCanonicalize (H12AffineFastState.compose env28973 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28974 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,89,0,80,82,16,2129,68,81,81,1,16,2,88,65,2128,17,16,2048,68,1,84,0,81,512]

theorem envBound28974 : H12AffineFastState.Bounded env28974 := by
  intro p hp
  have h : env28974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28973_28974 : H12AffineEnvironment.transform 11 17 env28973 = env28974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28973 == env28974) = true)

theorem identity28974 : scanCanonicalize (H12AffineFastState.compose env28974 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28975 : List Nat := [2,4,8,16,0,64,9,85,512,69,0,17,89,0,80,82,16,81,68,81,81,1,16,2,88,65,80,17,16,0,68,1,84,0,81,512]

theorem envBound28975 : H12AffineFastState.Bounded env28975 := by
  intro p hp
  have h : env28975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28974_28975 : H12AffineEnvironment.transform 10 0 env28974 = env28975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28974 == env28975) = true)

theorem identity28975 : scanCanonicalize (H12AffineFastState.compose env28975 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28976 : List Nat := [2,0,8,16,0,64,9,81,512,65,0,17,89,0,80,82,16,81,64,81,81,1,16,2,88,65,80,17,16,0,64,1,80,0,81,512]

theorem envBound28976 : H12AffineFastState.Bounded env28976 := by
  intro p hp
  have h : env28976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28975_28976 : H12AffineEnvironment.transform 1 0 env28975 = env28976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28975 == env28976) = true)

def env28977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329897,8328,65,507954,302180,333995,236987,119042,272392,257,98815,90203,63188]

theorem envBound28977 : H12AffineFastState.Bounded env28977 := by
  intro p hp
  have h : env28977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28931_28977 : H12AffineEnvironment.transform 20 4161 env28931 = env28977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28931 == env28977) = true)

theorem identity28977 : scanCanonicalize (H12AffineFastState.compose env28977 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound28977 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21793,73755,95496,8328,65,245139,57797,91402,236987,119042,21929,257,98815,90203,63188]

theorem envBound28978 : H12AffineFastState.Bounded env28978 := by
  intro p hp
  have h : env28978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28977_28978 : H12AffineEnvironment.transform 17 32161 env28977 = env28978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env28977 == env28978) = true)

def env28979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1025,32769,4161,33,73755,73736,8328,65,245139,46277,77834,236987,99330,169,257,98815,79195,41940]

theorem envBound28979 : H12AffineFastState.Bounded env28979 := by
  intro p hp
  have h : env28979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28978_28979 : H12AffineEnvironment.transform 13 5376 env28978 = env28979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28978 == env28979) = true)

theorem identity28979 : scanCanonicalize (H12AffineFastState.compose env28979 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28979 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10401,1025,32769,4161,33,73755,73736,8328,65,108675,46277,77834,100523,99330,169,257,98815,79195,41940]

theorem envBound28980 : H12AffineFastState.Bounded env28980 := by
  intro p hp
  have h : env28980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28979_28980 : H12AffineEnvironment.transform 16 5392 env28979 = env28980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28979 == env28980) = true)

theorem identity28980 : scanCanonicalize (H12AffineFastState.compose env28980 (packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28980 : packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env28981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10280,1025,32769,4161,33,73755,73736,8193,65,108554,46156,77834,100386,99330,32,257,98678,79195,41821]

theorem envBound28981 : H12AffineFastState.Bounded env28981 := by
  intro p hp
  have h : env28981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28980_28981 : H12AffineEnvironment.transform 6 9 env28980 = env28981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28980 == env28981) = true)

theorem identity28981 : scanCanonicalize (H12AffineFastState.compose env28981 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,5392,10280,1025,32769,4161,33,41293,41310,8193,65,10588,46156,45404,2420,1364,32,257,32,46093,41821]

theorem envBound28982 : H12AffineFastState.Bounded env28982 := by
  intro p hp
  have h : env28982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28981_28982 : H12AffineEnvironment.transform 15 33110 env28981 = env28982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28981 == env28982) = true)

theorem identity28982 : scanCanonicalize (H12AffineFastState.compose env28982 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound28982 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9292,9498,5392,10280,1025,9293,4161,33,1281,1298,8193,65,10588,4096,5392,2420,1364,32,257,32,4161,1809]

theorem envBound28983 : H12AffineFastState.Bounded env28983 := by
  intro p hp
  have h : env28983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28982_28983 : H12AffineEnvironment.transform 14 9292 env28982 = env28983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env28982 == env28983) = true)

theorem identity28983 : scanCanonicalize (H12AffineFastState.compose env28983 (packedSelected [0,2,6,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 3433) := by decide +kernel

theorem selectedBound28983 : packedSelected [0,2,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3433,5376,2341,2163,5392,1345,1025,2340,4161,33,1281,1298,3432,65,1077,4096,5392,2420,1364,32,257,32,4161,1809]

theorem envBound28984 : H12AffineFastState.Bounded env28984 := by
  intro p hp
  have h : env28984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28983_28984 : H12AffineEnvironment.transform 12 3433 env28983 = env28984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3433 env28983 == env28984) = true)

theorem identity28984 : scanCanonicalize (H12AffineFastState.compose env28984 (packedSelected [0,1,2,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound28984 : packedSelected [0,1,2,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,49,3433,1329,2341,2163,1313,1345,1025,2340,112,33,1281,1298,3432,65,1077,49,1313,2420,1364,32,257,32,112,1809]

theorem envBound28985 : H12AffineFastState.Bounded env28985 := by
  intro p hp
  have h : env28985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28984_28985 : H12AffineEnvironment.transform 11 49 env28984 = env28985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env28984 == env28985) = true)

theorem identity28985 : scanCanonicalize (H12AffineFastState.compose env28985 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound28985 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1328,49,89,1329,1045,1347,1313,1345,1025,1044,112,33,1281,1298,88,65,1077,49,1313,1092,1364,32,257,32,112,1809]

theorem envBound28986 : H12AffineFastState.Bounded env28986 := by
  intro p hp
  have h : env28986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28985_28986 : H12AffineEnvironment.transform 10 1328 env28985 = env28986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env28985 == env28986) = true)

theorem identity28986 : scanCanonicalize (H12AffineFastState.compose env28986 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound28986 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env28987 : List Nat := [2,4,8,16,32,64,9,256,512,305,1,49,89,0,292,114,16,112,304,293,112,33,48,35,88,65,260,49,16,373,101,32,257,32,112,544]

theorem envBound28987 : H12AffineFastState.Bounded env28987 := by
  intro p hp
  have h : env28987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28986_28987 : H12AffineEnvironment.transform 9 305 env28986 = env28987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env28986 == env28987) = true)

def env28988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1025,32769,4161,32,73755,73737,8328,65,245139,46276,77835,236987,99331,168,257,98815,79194,41941]

theorem envBound28988 : H12AffineFastState.Bounded env28988 := by
  intro p hp
  have h : env28988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28978_28988 : H12AffineEnvironment.transform 13 5377 env28978 = env28988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28978 == env28988) = true)

theorem identity28988 : scanCanonicalize (H12AffineFastState.compose env28988 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28988 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4161,32,73755,73737,8193,65,245018,46157,77835,236850,99331,33,257,98678,79194,41820]

theorem envBound28989 : H12AffineFastState.Bounded env28989 := by
  intro p hp
  have h : env28989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28988_28989 : H12AffineEnvironment.transform 6 9 env28988 = env28989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28988 == env28989) = true)

theorem identity28989 : scanCanonicalize (H12AffineFastState.compose env28989 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28989 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1025,8540,4161,32,73755,73737,8193,65,203847,5392,77835,212079,75102,33,257,73771,79194,513]

theorem envBound28990 : H12AffineFastState.Bounded env28990 := by
  intro p hp
  have h : env28990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28989_28990 : H12AffineEnvironment.transform 14 8541 env28989 = env28990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28989 == env28990) = true)

theorem identity28990 : scanCanonicalize (H12AffineFastState.compose env28990 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound28990 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8282,131072,10281,1025,8540,4161,32,65,83,8193,65,146461,5392,4177,138293,1284,33,257,113,5376,513]

theorem envBound28991 : H12AffineFastState.Bounded env28991 := by
  intro p hp
  have h : env28991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28990_28991 : H12AffineEnvironment.transform 15 8282 env28990 = env28991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env28990 == env28991) = true)

theorem identity28991 : scanCanonicalize (H12AffineFastState.compose env28991 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound28991 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env28992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8282,5440,10281,1025,8540,4161,32,65,83,8193,65,10589,5392,4177,2421,1284,33,257,113,5376,513]

theorem envBound28992 : H12AffineFastState.Bounded env28992 := by
  intro p hp
  have h : env28992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28991_28992 : H12AffineEnvironment.transform 16 5440 env28991 = env28992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env28991 == env28992) = true)

theorem identity28992 : scanCanonicalize (H12AffineFastState.compose env28992 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28992 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,342,5440,2341,1025,80,4161,32,65,83,269,65,2129,5392,4177,2421,1284,33,257,113,5376,513]

theorem envBound28993 : H12AffineFastState.Bounded env28993 := by
  intro p hp
  have h : env28993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28992_28993 : H12AffineEnvironment.transform 12 268 env28992 = env28993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28992 == env28993) = true)

theorem identity28993 : scanCanonicalize (H12AffineFastState.compose env28993 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound28993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2415,268,3182,81,342,3119,2341,1025,80,2350,32,65,83,269,65,2129,3199,2366,2421,1284,33,257,113,3183,513]

theorem envBound28994 : H12AffineFastState.Bounded env28994 := by
  intro p hp
  have h : env28994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28993_28994 : H12AffineEnvironment.transform 11 2415 env28993 = env28994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env28993 == env28994) = true)

def env28995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431209,8328,65,2609266,302181,333995,2330106,119043,2373704,257,2199999,2191387,63189]

theorem envBound28995 : H12AffineFastState.Bounded env28995 := by
  intro p hp
  have h : env28995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28930_28995 : H12AffineEnvironment.transform 23 2431209 env28930 = env28995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env28930 == env28995) = true)

def env28996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329897,8328,65,507954,302181,333995,236986,119043,272392,257,98815,90203,63189]

theorem envBound28996 : H12AffineFastState.Bounded env28996 := by
  intro p hp
  have h : env28996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28995_28996 : H12AffineEnvironment.transform 20 4160 env28995 = env28996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28995 == env28996) = true)

theorem identity28996 : scanCanonicalize (H12AffineFastState.compose env28996 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound28996 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,4160,21792,120015,98781,8328,65,215366,5393,102879,236986,119043,41340,257,98815,90203,63189]

theorem envBound28997 : H12AffineFastState.Bounded env28997 := by
  intro p hp
  have h : env28997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28996_28997 : H12AffineEnvironment.transform 17 35188 env28996 = env28997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env28996 == env28997) = true)

def env28998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1025,8661,4160,21792,95515,73737,8328,65,215366,5393,77835,212078,94423,168,257,73771,90203,22273]

theorem envBound28998 : H12AffineFastState.Bounded env28998 := by
  intro p hp
  have h : env28998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28997_28998 : H12AffineEnvironment.transform 14 8660 env28997 = env28998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env28997 == env28998) = true)

theorem identity28998 : scanCanonicalize (H12AffineFastState.compose env28998 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28998 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,65536,131072,10400,1025,8661,4160,169,73874,73737,8328,65,203983,5393,77835,212078,75102,168,257,73771,79314,648]

theorem envBound28999 : H12AffineFastState.Bounded env28999 := by
  intro p hp
  have h : env28999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28998_28999 : H12AffineEnvironment.transform 13 5513 env28998 = env28999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28998 == env28999) = true)

theorem identity28999 : scanCanonicalize (H12AffineFastState.compose env28999 (packedSelected [0,1,2,3,4,6,7,9,11,14,16,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28999 : packedSelected [0,1,2,3,4,6,7,9,11,14,16,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env29000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,262,131072,10400,1025,8661,4160,169,8596,8463,8328,65,138697,5393,12557,146792,9304,168,257,8493,13524,648]

theorem envBound29000 : H12AffineFastState.Bounded env29000 := by
  intro p hp
  have h : env29000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28999_29000 : H12AffineEnvironment.transform 15 262 env28999 = env29000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28999 == env29000) = true)

theorem identity29000 : scanCanonicalize (H12AffineFastState.compose env29000 (packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound29000 : packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS < 2^1333 := by decide +kernel

def env29001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,262,5528,10400,1025,8661,4160,169,8596,8463,8328,65,2129,5393,12557,10480,9304,168,257,8493,13524,648]

theorem envBound29001 : H12AffineFastState.Bounded env29001 := by
  intro p hp
  have h : env29001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29000_29001 : H12AffineEnvironment.transform 16 5528 env29000 = env29001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env29000 == env29001) = true)

theorem identity29001 : scanCanonicalize (H12AffineFastState.compose env29001 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29001 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,216,262,5528,2476,1025,217,4160,169,152,3,388,65,2129,5393,4097,2556,1364,168,257,33,5592,648]

theorem envBound29002 : H12AffineFastState.Bounded env29002 := by
  intro p hp
  have h : env29002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29001_29002 : H12AffineEnvironment.transform 12 268 env29001 = env29002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29001 == env29002) = true)

theorem identity29002 : scanCanonicalize (H12AffineFastState.compose env29002 (packedSelected [1,4,6,8,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound29002 : packedSelected [1,4,6,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3156,268,2525,216,262,2508,2476,1025,217,3092,169,152,3,388,65,2129,2373,3157,2556,1364,168,257,33,2444,648]

theorem envBound29003 : H12AffineFastState.Bounded env29003 := by
  intro p hp
  have h : env29003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29002_29003 : H12AffineEnvironment.transform 11 3156 env29002 = env29003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env29002 == env29003) = true)

theorem identity29003 : scanCanonicalize (H12AffineFastState.compose env29003 (packedSelected [11,12] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound29003 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env29004 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,3156,209,2048,216,219,2065,2161,1025,217,3092,169,152,3,89,65,2129,2200,3157,2081,1161,168,220,33,2129,648]

theorem envBound29004 : H12AffineFastState.Bounded env29004 := by
  intro p hp
  have h : env29004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29003_29004 : H12AffineEnvironment.transform 7 221 env29003 = env29004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env29003 == env29004) = true)

theorem identity29004 : scanCanonicalize (H12AffineFastState.compose env29004 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29004 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29005 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3156,88,2048,81,82,2065,2161,1025,80,3092,32,17,3,89,65,2129,2065,3157,2081,1024,33,85,33,2129,513]

theorem envBound29005 : H12AffineFastState.Bounded env29005 := by
  intro p hp
  have h : env29005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29004_29005 : H12AffineEnvironment.transform 6 9 env29004 = env29005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29004 == env29005) = true)

theorem identity29005 : scanCanonicalize (H12AffineFastState.compose env29005 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound29005 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29006 : List Nat := [2,4,8,16,32,64,9,84,512,1024,75,1055,88,75,81,82,90,58,1025,80,1119,32,17,3,89,65,26,90,1054,106,1024,33,85,33,26,513]

theorem envBound29006 : H12AffineFastState.Bounded env29006 := by
  intro p hp
  have h : env29006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29005_29006 : H12AffineEnvironment.transform 10 75 env29005 = env29006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env29005 == env29006) = true)

theorem identity29006 : scanCanonicalize (H12AffineFastState.compose env29006 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound29006 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29007 : List Nat := [2,4,8,16,32,64,9,84,512,580,75,603,88,75,81,82,90,58,581,80,539,32,17,3,89,65,26,90,602,106,580,33,85,33,26,513]

theorem envBound29007 : H12AffineFastState.Bounded env29007 := by
  intro p hp
  have h : env29007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29006_29007 : H12AffineEnvironment.transform 9 580 env29006 = env29007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env29006 == env29007) = true)

theorem identity29007 : scanCanonicalize (H12AffineFastState.compose env29007 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29007 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29008 : List Nat := [2,4,8,16,32,32,9,52,512,548,43,571,56,43,49,50,58,58,549,48,539,32,17,3,57,33,26,58,570,10,548,33,53,33,26,513]

theorem envBound29008 : H12AffineFastState.Bounded env29008 := by
  intro p hp
  have h : env29008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29007_29008 : H12AffineEnvironment.transform 5 32 env29007 = env29008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29007 == env29008) = true)

theorem identity29008 : scanCanonicalize (H12AffineFastState.compose env29008 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29009 : List Nat := [2,4,8,16,17,17,9,5,512,533,26,522,9,26,0,3,11,11,532,1,539,17,17,3,8,16,26,11,523,10,533,16,4,16,26,513]

theorem envBound29009 : H12AffineFastState.Bounded env29009 := by
  intro p hp
  have h : env29009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29008_29009 : H12AffineEnvironment.transform 4 17 env29008 = env29009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29008 == env29009) = true)

theorem identity29009 : scanCanonicalize (H12AffineFastState.compose env29009 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29010 : List Nat := [2,4,8,10,11,11,9,5,512,527,0,522,9,0,0,3,11,11,526,1,513,11,11,3,8,10,0,11,523,10,527,10,4,10,0,513]

theorem envBound29010 : H12AffineFastState.Bounded env29010 := by
  intro p hp
  have h : env29010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29009_29010 : H12AffineEnvironment.transform 3 10 env29009 = env29010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29009 == env29010) = true)

theorem identity29010 : scanCanonicalize (H12AffineFastState.compose env29010 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29010 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29011 : List Nat := [2,4,1,3,2,2,0,5,512,518,0,515,0,0,0,3,2,2,519,1,513,2,2,3,1,3,0,2,514,3,518,3,4,3,0,513]

theorem envBound29011 : H12AffineFastState.Bounded env29011 := by
  intro p hp
  have h : env29011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29010_29011 : H12AffineEnvironment.transform 2 1 env29010 = env29011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29010 == env29011) = true)

def env29012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1025,8660,4160,21792,95514,73736,8328,65,215366,5393,77834,212079,94422,169,257,73770,90203,22272]

theorem envBound29012 : H12AffineFastState.Bounded env29012 := by
  intro p hp
  have h : env29012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28997_29012 : H12AffineEnvironment.transform 14 8661 env28997 = env29012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env28997 == env29012) = true)

theorem identity29012 : scanCanonicalize (H12AffineFastState.compose env29012 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29012 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,131072,10401,1025,8660,4160,21792,21776,2,8328,65,158028,5393,4096,138341,20700,169,257,32,16465,22272]

theorem envBound29013 : H12AffineFastState.Bounded env29013 := by
  intro p hp
  have h : env29013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29012_29013 : H12AffineEnvironment.transform 15 8202 env29012 = env29013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29012 == env29013) = true)

theorem identity29013 : scanCanonicalize (H12AffineFastState.compose env29013 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound29013 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8661,8202,131072,10401,1025,8660,4160,248,200,2,8328,65,146580,5393,4096,138341,1284,169,257,32,5513,728]

theorem envBound29014 : H12AffineFastState.Bounded env29014 := by
  intro p hp
  have h : env29014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29013_29014 : H12AffineEnvironment.transform 13 5592 env29013 = env29014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env29013 == env29014) = true)

theorem identity29014 : scanCanonicalize (H12AffineFastState.compose env29014 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29014 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env29015 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5292,8353,8202,131072,10401,1025,8352,4160,248,200,2,8328,65,146580,5221,4096,138341,1136,169,117,32,5373,728]

theorem envBound29015 : H12AffineFastState.Bounded env29015 := by
  intro p hp
  have h : env29015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29014_29015 : H12AffineEnvironment.transform 7 116 env29014 = env29015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29014 == env29015) = true)

theorem identity29015 : scanCanonicalize (H12AffineFastState.compose env29015 (packedSelected [0,1,2,3,5,6,7,8,10,11,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29015 : packedSelected [0,1,2,3,5,6,7,8,10,11,19,20,23] rootPS < 2^1333 := by decide +kernel

def env29016 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5292,136,35,131072,2184,1025,137,4160,248,200,2,161,65,138429,5221,4096,138341,1136,169,117,32,5373,728]

theorem envBound29016 : H12AffineFastState.Bounded env29016 := by
  intro p hp
  have h : env29016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29015_29016 : H12AffineEnvironment.transform 12 41 env29015 = env29016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29015 == env29016) = true)

theorem identity29016 : scanCanonicalize (H12AffineFastState.compose env29016 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29016 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29017 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5292,136,35,131072,2184,1025,137,4112,168,152,2,161,17,138429,5173,4096,138293,1056,169,37,32,5293,648]

theorem envBound29017 : H12AffineFastState.Bounded env29017 := by
  intro p hp
  have h : env29017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29016_29017 : H12AffineEnvironment.transform 5 16 env29016 = env29017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29016 == env29017) = true)

theorem identity29017 : scanCanonicalize (H12AffineFastState.compose env29017 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound29017 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29018 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5292,136,35,5277,2184,1025,137,4112,168,152,2,161,17,2080,5173,4096,2216,1056,169,37,32,5293,648]

theorem envBound29018 : H12AffineFastState.Bounded env29018 := by
  intro p hp
  have h : env29018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29017_29018 : H12AffineEnvironment.transform 16 5277 env29017 = env29018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env29017 == env29018) = true)

theorem identity29018 : scanCanonicalize (H12AffineFastState.compose env29018 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29018 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29019 : List Nat := [2,4,8,16,0,16,128,4,512,1024,2048,4096,9,5260,136,3,5277,2184,1025,137,4112,136,152,2,129,17,2048,5141,4096,2184,1024,137,5,0,5261,648]

theorem envBound29019 : H12AffineFastState.Bounded env29019 := by
  intro p hp
  have h : env29019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29018_29019 : H12AffineEnvironment.transform 4 0 env29018 = env29019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29018 == env29019) = true)

theorem identity29019 : scanCanonicalize (H12AffineFastState.compose env29019 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29019 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29020 : List Nat := [2,4,8,16,0,16,128,4,512,1024,2048,0,9,1164,136,3,1181,2184,1025,137,16,136,152,2,129,17,2048,1045,0,2184,1024,137,5,0,1165,648]

theorem envBound29020 : H12AffineFastState.Bounded env29020 := by
  intro p hp
  have h : env29020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29019_29020 : H12AffineEnvironment.transform 11 0 env29019 = env29020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29019 == env29020) = true)

theorem identity29020 : scanCanonicalize (H12AffineFastState.compose env29020 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound29020 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29021 : List Nat := [2,4,8,16,0,16,128,4,512,157,2048,0,9,17,136,3,0,2184,156,137,16,136,152,2,129,17,2048,136,0,2184,157,137,5,0,16,648]

theorem envBound29021 : H12AffineFastState.Bounded env29021 := by
  intro p hp
  have h : env29021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29020_29021 : H12AffineEnvironment.transform 9 157 env29020 = env29021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env29020 == env29021) = true)

theorem identity29021 : scanCanonicalize (H12AffineFastState.compose env29021 (packedSelected [3,5,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound29021 : packedSelected [3,5,11,12] rootPS < 2^1333 := by decide +kernel

def env29022 : List Nat := [2,4,8,16,0,16,128,4,512,157,16,0,9,17,136,3,0,152,156,137,16,136,152,2,129,17,16,136,0,152,157,137,5,0,16,648]

theorem envBound29022 : H12AffineFastState.Bounded env29022 := by
  intro p hp
  have h : env29022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29021_29022 : H12AffineEnvironment.transform 10 16 env29021 = env29022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env29021 == env29022) = true)

theorem identity29022 : scanCanonicalize (H12AffineFastState.compose env29022 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29022 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29023 : List Nat := [2,4,8,16,0,16,9,4,512,20,16,0,9,17,1,3,0,17,21,0,16,1,17,2,8,17,16,1,0,17,20,0,5,0,16,513]

theorem envBound29023 : H12AffineFastState.Bounded env29023 := by
  intro p hp
  have h : env29023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29022_29023 : H12AffineEnvironment.transform 6 9 env29022 = env29023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29022 == env29023) = true)

theorem identity29023 : scanCanonicalize (H12AffineFastState.compose env29023 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29024 : List Nat := [2,0,8,16,0,16,9,0,512,16,16,0,9,17,1,3,0,17,17,0,16,1,17,2,8,17,16,1,0,17,16,0,1,0,16,513]

theorem envBound29024 : H12AffineFastState.Bounded env29024 := by
  intro p hp
  have h : env29024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29023_29024 : H12AffineEnvironment.transform 1 0 env29023 = env29024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29023 == env29024) = true)

theorem identity29024 : scanCanonicalize (H12AffineFastState.compose env29024 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound29024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29025 : List Nat := [2,0,8,16,0,16,9,0,9,16,16,0,9,17,1,3,0,17,17,0,16,1,17,2,8,17,16,1,0,17,16,0,1,0,16,8]

theorem envBound29025 : H12AffineFastState.Bounded env29025 := by
  intro p hp
  have h : env29025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29024_29025 : H12AffineEnvironment.transform 8 9 env29024 = env29025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env29024 == env29025) = true)

theorem identity29025 : scanCanonicalize (H12AffineFastState.compose env29025 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29025 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29026 : List Nat := [2,0,8,10,0,10,9,0,9,10,10,0,9,11,1,3,0,11,11,0,10,1,11,2,8,11,10,1,0,11,10,0,1,0,10,8]

theorem envBound29026 : H12AffineFastState.Bounded env29026 := by
  intro p hp
  have h : env29026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29025_29026 : H12AffineEnvironment.transform 3 10 env29025 = env29026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29025 == env29026) = true)

theorem identity29026 : scanCanonicalize (H12AffineFastState.compose env29026 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29026 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29027 : List Nat := [2,0,0,2,0,2,1,0,1,2,2,0,1,3,1,3,0,3,3,0,2,1,3,2,0,3,2,1,0,3,2,0,1,0,2,0]

theorem envBound29027 : H12AffineFastState.Bounded env29027 := by
  intro p hp
  have h : env29027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29026_29027 : H12AffineEnvironment.transform 2 0 env29026 = env29027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29026 == env29027) = true)

theorem identity29027 : scanCanonicalize (H12AffineFastState.compose env29027 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29027 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29028 : List Nat := [1,0,0,1,0,1,1,0,1,1,1,0,1,0,1,0,0,0,0,0,1,1,0,1,0,0,1,1,0,0,1,0,1,0,1,0]

theorem envBound29028 : H12AffineFastState.Bounded env29028 := by
  intro p hp
  have h : env29028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29027_29028 : H12AffineEnvironment.transform 0 1 env29027 = env29028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29027 == env29028) = true)

def env29029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329896,8328,65,507955,302181,333995,236987,119043,272393,257,98814,90202,63189]

theorem envBound29029 : H12AffineFastState.Bounded env29029 := by
  intro p hp
  have h : env29029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28995_29029 : H12AffineEnvironment.transform 20 4161 env28995 = env29029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28995 == env29029) = true)

theorem identity29029 : scanCanonicalize (H12AffineFastState.compose env29029 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,21793,351674,329896,8328,65,472295,288945,333995,223599,75223,272393,257,95530,90202,513]

theorem envBound29030 : H12AffineFastState.Bounded env29030 := by
  intro p hp
  have h : env29030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29029_29030 : H12AffineEnvironment.transform 14 29908 env29029 = env29030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29029 == env29030) = true)

def env29031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,21793,351538,329760,8192,65,472175,288825,333859,223599,75103,272393,257,95530,90202,513]

theorem envBound29031 : H12AffineFastState.Bounded env29031 := by
  intro p hp
  have h : env29031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29030_29031 : H12AffineEnvironment.transform 6 8 env29030 = env29031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29030 == env29031) = true)

theorem identity29031 : scanCanonicalize (H12AffineFastState.compose env29031 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound29031 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,4161,21793,351538,329760,8192,65,283765,288825,333859,2421,75103,272393,257,95530,90202,513]

theorem envBound29032 : H12AffineFastState.Bounded env29032 := by
  intro p hp
  have h : env29032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29031_29032 : H12AffineEnvironment.transform 16 90138 env29031 = env29032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env29031 == env29032) = true)

theorem identity29032 : scanCanonicalize (H12AffineFastState.compose env29032 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 77131) := by decide +kernel

theorem selectedBound29032 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env29033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,77131,1025,29789,4161,21793,28793,9579,8192,65,96574,83314,13672,2421,75103,66882,257,95530,90202,513]

theorem envBound29033 : H12AffineFastState.Bounded env29033 := by
  intro p hp
  have h : env29033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29032_29033 : H12AffineEnvironment.transform 17 77131 env29032 = env29033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77131 env29032 == env29033) = true)

theorem identity29033 : scanCanonicalize (H12AffineFastState.compose env29033 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound29033 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env29034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,9499,17665,2128,1025,29789,4161,21793,28793,9579,8192,65,23589,24681,13672,2421,68,8281,257,20529,17729,513]

theorem envBound29034 : H12AffineFastState.Bounded env29034 := by
  intro p hp
  have h : env29034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29033_29034 : H12AffineEnvironment.transform 15 9499 env29033 = env29034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env29033 == env29034) = true)

theorem identity29034 : scanCanonicalize (H12AffineFastState.compose env29034 (packedSelected [3,5,7,10,14,15,18,20,23,27,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29034 : packedSelected [3,5,7,10,14,15,18,20,23,27,41] rootPS < 2^1333 := by decide +kernel

def env29035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9499,4096,2128,1025,8540,4161,32,9592,9579,8192,65,2340,13672,13672,2421,68,8281,257,1328,4160,513]

theorem envBound29035 : H12AffineFastState.Bounded env29035 := by
  intro p hp
  have h : env29035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29034_29035 : H12AffineEnvironment.transform 13 5377 env29034 = env29035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29034 == env29035) = true)

theorem identity29035 : scanCanonicalize (H12AffineFastState.compose env29035 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29035 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29036 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8541,8202,4096,2128,272,8540,4161,32,8297,8314,8192,65,2340,12409,12409,2421,68,8281,257,33,4160,513]

theorem envBound29036 : H12AffineFastState.Bounded env29036 := by
  intro p hp
  have h : env29036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29035_29036 : H12AffineEnvironment.transform 9 273 env29035 = env29036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29035 == env29036) = true)

theorem identity29036 : scanCanonicalize (H12AffineFastState.compose env29036 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound29036 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29037 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,8192,293,8541,8202,309,2128,272,8540,372,32,8297,8314,8192,65,2340,8524,8524,2421,68,8281,257,33,373,513]

theorem envBound29037 : H12AffineFastState.Bounded env29037 := by
  intro p hp
  have h : env29037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29036_29037 : H12AffineEnvironment.transform 11 309 env29036 = env29037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env29036 == env29037) = true)

theorem identity29037 : scanCanonicalize (H12AffineFastState.compose env29037 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29037 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29038 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,120,293,293,114,309,2128,272,292,372,32,17,2,120,65,2340,308,308,2421,68,33,257,33,373,513]

theorem envBound29038 : H12AffineFastState.Bounded env29038 := by
  intro p hp
  have h : env29038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29037_29038 : H12AffineEnvironment.transform 12 120 env29037 = env29038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29037 == env29038) = true)

theorem identity29038 : scanCanonicalize (H12AffineFastState.compose env29038 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29038 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29039 : List Nat := [2,4,8,16,32,49,8,256,512,273,2048,309,9,293,293,3,309,2081,272,292,261,32,17,2,9,48,2340,308,308,2308,53,33,257,33,260,513]

theorem envBound29039 : H12AffineFastState.Bounded env29039 := by
  intro p hp
  have h : env29039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29038_29039 : H12AffineEnvironment.transform 5 49 env29038 = env29039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29038 == env29039) = true)

theorem identity29039 : scanCanonicalize (H12AffineFastState.compose env29039 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29039 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29040 : List Nat := [2,4,8,16,1,16,8,256,512,273,2048,276,9,260,260,3,276,2048,272,261,261,1,17,2,9,17,2309,277,277,2308,20,0,257,0,260,513]

theorem envBound29040 : H12AffineFastState.Bounded env29040 := by
  intro p hp
  have h : env29040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29039_29040 : H12AffineEnvironment.transform 4 1 env29039 = env29040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29039 == env29040) = true)

theorem identity29040 : scanCanonicalize (H12AffineFastState.compose env29040 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29040 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29041 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,17,9,1,1,3,17,2048,21,0,0,1,17,2,9,17,2048,16,16,2049,20,0,4,0,1,513]

theorem envBound29041 : H12AffineFastState.Bounded env29041 := by
  intro p hp
  have h : env29041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29040_29041 : H12AffineEnvironment.transform 7 5 env29040 = env29041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29040 == env29041) = true)

theorem identity29041 : scanCanonicalize (H12AffineFastState.compose env29041 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29042 : List Nat := [2,4,8,16,1,16,8,5,512,20,0,17,9,1,1,3,17,0,21,0,0,1,17,2,9,17,0,16,16,1,20,0,4,0,1,513]

theorem envBound29042 : H12AffineFastState.Bounded env29042 := by
  intro p hp
  have h : env29042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29041_29042 : H12AffineEnvironment.transform 10 0 env29041 = env29042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29041 == env29042) = true)

theorem identity29042 : scanCanonicalize (H12AffineFastState.compose env29042 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29042 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29043 : List Nat := [2,4,8,16,1,16,8,5,1,20,0,17,9,1,1,3,17,0,21,0,0,1,17,2,9,17,0,16,16,1,20,0,4,0,1,0]

theorem envBound29043 : H12AffineFastState.Bounded env29043 := by
  intro p hp
  have h : env29043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29042_29043 : H12AffineEnvironment.transform 8 1 env29042 = env29043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29042 == env29043) = true)

theorem identity29043 : scanCanonicalize (H12AffineFastState.compose env29043 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29043 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29044 : List Nat := [2,4,8,0,1,0,8,5,1,4,0,1,9,1,1,3,1,0,5,0,0,1,1,2,9,1,0,0,0,1,4,0,4,0,1,0]

theorem envBound29044 : H12AffineFastState.Bounded env29044 := by
  intro p hp
  have h : env29044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29043_29044 : H12AffineEnvironment.transform 3 0 env29043 = env29044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29043 == env29044) = true)

def env29045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,21793,351539,329761,8193,65,472174,288824,333858,223599,75102,272393,257,95530,90202,513]

theorem envBound29045 : H12AffineFastState.Bounded env29045 := by
  intro p hp
  have h : env29045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29030_29045 : H12AffineEnvironment.transform 6 9 env29030 = env29045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29030 == env29045) = true)

theorem identity29045 : scanCanonicalize (H12AffineFastState.compose env29045 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound29045 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env29046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138293,1025,29788,4161,21793,213254,201748,8193,65,75867,160781,197655,223599,75102,144444,257,95530,90202,513]

theorem envBound29046 : H12AffineFastState.Bounded env29046 := by
  intro p hp
  have h : env29046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29045_29046 : H12AffineEnvironment.transform 17 138293 env29045 = env29046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env29045 == env29046) = true)

theorem identity29046 : scanCanonicalize (H12AffineFastState.compose env29046 (packedSelected [0,2,3,5,6,7,10,12,15,19,20,26] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound29046 : packedSelected [0,2,3,5,6,7,10,12,15,19,20,26] rootPS < 2^1333 := by decide +kernel

def env29047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,24861,32040,1025,29788,4161,21793,73755,95497,8193,65,75867,5392,91402,67698,75102,21793,257,95530,90202,513]

theorem envBound29047 : H12AffineFastState.Bounded env29047 := by
  intro p hp
  have h : env29047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29046_29047 : H12AffineEnvironment.transform 16 24861 env29046 = env29047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env29046 == env29047) = true)

theorem identity29047 : scanCanonicalize (H12AffineFastState.compose env29047 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29047 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env29048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24861,32040,1025,29788,4161,21793,16,21762,8193,65,2128,5392,17665,10361,1365,21793,257,21793,16465,513]

theorem envBound29048 : H12AffineFastState.Bounded env29048 := by
  intro p hp
  have h : env29048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29047_29048 : H12AffineEnvironment.transform 15 8203 env29047 = env29048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29047 == env29048) = true)

theorem identity29048 : scanCanonicalize (H12AffineFastState.compose env29048 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound29048 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,8203,5392,2341,1025,81,4161,8492,16,8463,8193,65,2128,5392,12556,10361,1365,8492,257,8492,13404,513]

theorem envBound29049 : H12AffineFastState.Bounded env29049 := by
  intro p hp
  have h : env29049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29048_29049 : H12AffineEnvironment.transform 13 13325 env29048 = env29049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env29048 == env29049) = true)

theorem identity29049 : scanCanonicalize (H12AffineFastState.compose env29049 (packedSelected [1,2,3,5,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound29049 : packedSelected [1,2,3,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3385,6452,80,3378,5392,2341,1025,81,4161,3093,16,3126,3384,65,2128,5392,7221,1344,1365,3093,257,3093,6501,513]

theorem envBound29050 : H12AffineFastState.Bounded env29050 := by
  intro p hp
  have h : env29050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29049_29050 : H12AffineEnvironment.transform 12 3385 env29049 = env29050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env29049 == env29050) = true)

theorem identity29050 : scanCanonicalize (H12AffineFastState.compose env29050 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound29050 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env29051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,120,5237,80,115,5392,1124,1025,81,4161,340,16,375,121,65,1297,5392,4468,1344,1365,340,257,340,5156,513]

theorem envBound29051 : H12AffineFastState.Bounded env29051 := by
  intro p hp
  have h : env29051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29050_29051 : H12AffineEnvironment.transform 10 1345 env29050 = env29051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29050 == env29051) = true)

theorem identity29051 : scanCanonicalize (H12AffineFastState.compose env29051 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29051 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29052 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1076,4096,120,5237,80,115,5221,1124,1025,81,4161,33,16,2,121,65,1124,5221,4097,1077,1056,33,116,33,5156,513]

theorem envBound29052 : H12AffineFastState.Bounded env29052 := by
  intro p hp
  have h : env29052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29051_29052 : H12AffineEnvironment.transform 7 117 env29051 = env29052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29051 == env29052) = true)

theorem identity29052 : scanCanonicalize (H12AffineFastState.compose env29052 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound29052 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29053 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1076,10,120,1151,80,115,1135,1124,1025,81,75,33,16,2,121,65,1124,1135,11,1077,1056,33,116,33,1070,513]

theorem envBound29053 : H12AffineFastState.Bounded env29053 := by
  intro p hp
  have h : env29053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29052_29053 : H12AffineEnvironment.transform 11 10 env29052 = env29053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env29052 == env29053) = true)

theorem identity29053 : scanCanonicalize (H12AffineFastState.compose env29053 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29053 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env29054 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,10,120,26,80,115,10,1,100,81,75,33,16,2,121,65,1,10,11,80,69,33,116,33,75,513]

theorem envBound29054 : H12AffineFastState.Bounded env29054 := by
  intro p hp
  have h : env29054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29053_29054 : H12AffineEnvironment.transform 9 101 env29053 = env29054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29053 == env29054) = true)

theorem identity29054 : scanCanonicalize (H12AffineFastState.compose env29054 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound29054 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29055 : List Nat := [2,4,8,16,32,64,9,117,38,101,81,10,120,26,80,115,10,1,100,81,75,33,16,2,121,65,1,10,11,80,69,33,116,33,75,39]

theorem envBound29055 : H12AffineFastState.Bounded env29055 := by
  intro p hp
  have h : env29055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29054_29055 : H12AffineEnvironment.transform 8 38 env29054 = env29055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env29054 == env29055) = true)

theorem identity29055 : scanCanonicalize (H12AffineFastState.compose env29055 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29056 : List Nat := [2,4,8,0,32,64,9,101,38,101,65,10,104,10,64,99,10,1,100,65,75,33,0,2,105,65,1,10,11,64,69,33,100,33,75,39]

theorem envBound29056 : H12AffineFastState.Bounded env29056 := by
  intro p hp
  have h : env29056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29055_29056 : H12AffineEnvironment.transform 3 0 env29055 = env29056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29055 == env29056) = true)

theorem identity29056 : scanCanonicalize (H12AffineFastState.compose env29056 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29056 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29057 : List Nat := [2,4,1,0,32,64,0,101,38,101,65,3,97,3,64,99,3,1,100,65,66,33,0,2,96,65,1,3,2,64,69,33,100,33,66,39]

theorem envBound29057 : H12AffineFastState.Bounded env29057 := by
  intro p hp
  have h : env29057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29056_29057 : H12AffineEnvironment.transform 2 1 env29056 = env29057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29056 == env29057) = true)

def env29058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,16777216,8328,65,16959642,18973836,333995,2330106,19188202,16851104,257,17074518,17066226,19263036]

theorem envBound29058 : H12AffineFastState.Bounded env29058 := by
  intro p hp
  have h : env29058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28929_29058 : H12AffineEnvironment.transform 21 2114913 env28929 = env29058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env28929 == env29058) = true)

def env29059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431208,8328,65,2609266,302180,333995,2330106,119042,2373704,257,2199998,2191386,63188]

theorem envBound29059 : H12AffineFastState.Bounded env29059 := by
  intro p hp
  have h : env29059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29058_29059 : H12AffineEnvironment.transform 23 2431208 env29058 = env29059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env29058 == env29059) = true)

def env29060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329896,8328,65,507954,302180,333995,236986,119042,272392,257,98814,90202,63188]

theorem envBound29060 : H12AffineFastState.Bounded env29060 := by
  intro p hp
  have h : env29060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29059_29060 : H12AffineEnvironment.transform 20 4160 env29059 = env29060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29059 == env29060) = true)

theorem identity29060 : scanCanonicalize (H12AffineFastState.compose env29060 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound29060 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89514,1025,32769,4160,21793,17,21762,8328,65,171416,115150,17665,236986,119042,95650,257,98814,90202,63188]

theorem envBound29061 : H12AffineFastState.Bounded env29061 := by
  intro p hp
  have h : env29061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29060_29061 : H12AffineEnvironment.transform 17 89514 env29060 = env29061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env29060 == env29061) = true)

def env29062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4160,21793,17,21762,8192,65,171280,115014,17665,236850,119042,95530,257,98678,90202,63068]

theorem envBound29062 : H12AffineFastState.Bounded env29062 := by
  intro p hp
  have h : env29062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29061_29062 : H12AffineEnvironment.transform 6 8 env29061 = env29062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29061 == env29062) = true)

theorem identity29062 : scanCanonicalize (H12AffineFastState.compose env29062 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29062 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1025,32769,4160,33,17,2,8192,65,171280,103494,4097,236850,99330,73770,257,98678,79194,41820]

theorem envBound29063 : H12AffineFastState.Bounded env29063 := by
  intro p hp
  have h : env29063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29062_29063 : H12AffineEnvironment.transform 13 5376 env29062 = env29063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29062 == env29063) = true)

theorem identity29063 : scanCanonicalize (H12AffineFastState.compose env29063 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound29063 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env29064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,342,131072,2420,1025,32769,4160,33,17,2,8192,65,171280,38160,4097,171108,34132,8572,257,32800,13324,41820]

theorem envBound29064 : H12AffineFastState.Bounded env29064 := by
  intro p hp
  have h : env29064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29063_29064 : H12AffineEnvironment.transform 15 342 env29063 = env29064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env29063 == env29064) = true)

theorem identity29064 : scanCanonicalize (H12AffineFastState.compose env29064 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29064 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env29065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,131072,2420,1025,0,4160,33,17,2,8192,65,138513,5393,4097,138341,1365,8572,257,33,13324,9053]

theorem envBound29065 : H12AffineFastState.Bounded env29065 := by
  intro p hp
  have h : env29065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29064_29065 : H12AffineEnvironment.transform 14 1 env29064 = env29065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29064 == env29065) = true)

theorem identity29065 : scanCanonicalize (H12AffineFastState.compose env29065 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound29065 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,5221,2420,1025,0,4160,33,17,2,8192,65,2420,5393,4097,2048,1365,8572,257,33,13324,9053]

theorem envBound29066 : H12AffineFastState.Bounded env29066 := by
  intro p hp
  have h : env29066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29065_29066 : H12AffineEnvironment.transform 16 5221 env29065 = env29066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env29065 == env29066) = true)

theorem identity29066 : scanCanonicalize (H12AffineFastState.compose env29066 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29066 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,1,342,5221,2420,1025,0,4160,33,17,2,120,65,2420,5393,4097,2048,1365,260,257,33,5236,805]

theorem envBound29067 : H12AffineFastState.Bounded env29067 := by
  intro p hp
  have h : env29067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29066_29067 : H12AffineEnvironment.transform 12 120 env29066 = env29067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29066 == env29067) = true)

theorem identity29067 : scanCanonicalize (H12AffineFastState.compose env29067 (packedSelected [0,1,2,4,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound29067 : packedSelected [0,1,2,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,120,3392,1,342,3109,2420,1025,0,2048,33,17,2,120,65,2420,3409,2113,2048,1365,260,257,33,3124,805]

theorem envBound29068 : H12AffineFastState.Bounded env29068 := by
  intro p hp
  have h : env29068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29067_29068 : H12AffineEnvironment.transform 11 2112 env29067 = env29068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env29067 == env29068) = true)

theorem identity29068 : scanCanonicalize (H12AffineFastState.compose env29068 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29068 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29069 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2112,120,3125,1,35,3109,2049,1025,0,2048,33,17,2,120,65,2049,3108,2113,2048,1056,113,116,33,3124,592]

theorem envBound29069 : H12AffineFastState.Bounded env29069 := by
  intro p hp
  have h : env29069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29068_29069 : H12AffineEnvironment.transform 7 117 env29068 = env29069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29068 == env29069) = true)

theorem identity29069 : scanCanonicalize (H12AffineFastState.compose env29069 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29069 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29070 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2112,120,2048,1,35,2064,2049,52,0,2048,33,17,2,120,65,2049,2065,2113,2048,21,113,116,33,2049,592]

theorem envBound29070 : H12AffineFastState.Bounded env29070 := by
  intro p hp
  have h : env29070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29069_29070 : H12AffineEnvironment.transform 9 53 env29069 = env29070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29069 == env29070) = true)

theorem identity29070 : scanCanonicalize (H12AffineFastState.compose env29070 (packedSelected [0,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29070 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env29071 : List Nat := [2,4,8,0,32,64,8,101,512,37,2048,2112,104,2048,1,35,2048,2049,36,0,2048,33,1,2,104,65,2049,2049,2113,2048,5,97,100,33,2049,576]

theorem envBound29071 : H12AffineFastState.Bounded env29071 := by
  intro p hp
  have h : env29071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29070_29071 : H12AffineEnvironment.transform 3 0 env29070 = env29071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29070 == env29071) = true)

theorem identity29071 : scanCanonicalize (H12AffineFastState.compose env29071 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29071 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29072 : List Nat := [2,4,8,0,32,1,8,36,512,37,2048,2049,41,2048,1,35,2048,2049,36,0,2048,33,1,2,41,0,2049,2049,2048,2048,5,32,37,33,2049,513]

theorem envBound29072 : H12AffineFastState.Bounded env29072 := by
  intro p hp
  have h : env29072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29071_29072 : H12AffineEnvironment.transform 5 1 env29071 = env29072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29071 == env29072) = true)

def env29073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4160,21793,17,21762,8193,65,171281,115015,17665,236851,119042,95531,257,98679,90202,63069]

theorem envBound29073 : H12AffineFastState.Bounded env29073 := by
  intro p hp
  have h : env29073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29061_29073 : H12AffineEnvironment.transform 6 9 env29061 = env29073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29061 == env29073) = true)

theorem identity29073 : scanCanonicalize (H12AffineFastState.compose env29073 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29073 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89379,1025,29789,4160,21793,17,21762,8193,65,158029,79131,17665,223599,75102,95531,257,95531,90202,513]

theorem envBound29074 : H12AffineFastState.Bounded env29074 := by
  intro p hp
  have h : env29074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29073_29074 : H12AffineEnvironment.transform 14 29788 env29073 = env29074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29073 == env29074) = true)

theorem identity29074 : scanCanonicalize (H12AffineFastState.compose env29074 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound29074 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8233,65536,131072,67926,1025,8232,4160,340,17,375,8193,65,146744,79131,4468,212250,75102,74078,257,74078,78895,513]

theorem envBound29075 : H12AffineFastState.Bounded env29075 := by
  intro p hp
  have h : env29075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29074_29075 : H12AffineEnvironment.transform 13 5237 env29074 = env29075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env29074 == env29075) = true)

theorem identity29075 : scanCanonicalize (H12AffineFastState.compose env29075 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29075 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env29076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8233,8203,131072,10589,1025,8232,4160,340,17,375,8193,65,146744,5392,4468,138513,1365,341,257,341,5156,513]

theorem envBound29076 : H12AffineFastState.Bounded env29076 := by
  intro p hp
  have h : env29076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29075_29076 : H12AffineEnvironment.transform 15 8203 env29075 = env29076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29075 == env29076) = true)

theorem identity29076 : scanCanonicalize (H12AffineFastState.compose env29076 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound29076 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,1,35,131072,2421,1025,0,4160,340,17,375,41,65,138512,5392,4468,138513,1365,341,257,341,5156,513]

theorem envBound29077 : H12AffineFastState.Bounded env29077 := by
  intro p hp
  have h : env29077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29076_29077 : H12AffineEnvironment.transform 12 40 env29076 = env29077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env29076 == env29077) = true)

theorem identity29077 : scanCanonicalize (H12AffineFastState.compose env29077 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29077 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env29078 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,1,35,131072,2049,1025,0,4160,32,17,3,41,65,138340,5220,4096,138341,1057,33,117,33,5156,513]

theorem envBound29078 : H12AffineFastState.Bounded env29078 := by
  intro p hp
  have h : env29078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29077_29078 : H12AffineEnvironment.transform 7 116 env29077 = env29078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29077 == env29078) = true)

theorem identity29078 : scanCanonicalize (H12AffineFastState.compose env29078 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound29078 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29079 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,1,35,5221,2049,1025,0,4160,32,17,3,41,65,2049,5220,4096,2048,1057,33,117,33,5156,513]

theorem envBound29079 : H12AffineFastState.Bounded env29079 := by
  intro p hp
  have h : env29079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29078_29079 : H12AffineEnvironment.transform 16 5221 env29078 = env29079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env29078 == env29079) = true)

theorem identity29079 : scanCanonicalize (H12AffineFastState.compose env29079 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound29079 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29080 : List Nat := [2,4,8,16,32,64,9,116,512,1024,602,4096,40,5237,1,35,5221,603,1025,0,4160,32,17,3,41,65,603,5220,4096,602,1057,33,117,33,5156,513]

theorem envBound29080 : H12AffineFastState.Bounded env29080 := by
  intro p hp
  have h : env29080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29079_29080 : H12AffineEnvironment.transform 10 602 env29079 = env29080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env29079 == env29080) = true)

theorem identity29080 : scanCanonicalize (H12AffineFastState.compose env29080 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29080 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29081 : List Nat := [2,4,8,16,32,64,9,116,512,100,602,4096,40,4113,1,35,4097,603,101,0,4160,32,17,3,41,65,603,4096,4096,602,69,33,117,33,4160,513]

theorem envBound29081 : H12AffineFastState.Bounded env29081 := by
  intro p hp
  have h : env29081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29080_29081 : H12AffineEnvironment.transform 9 100 env29080 = env29081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29080 == env29081) = true)

theorem identity29081 : scanCanonicalize (H12AffineFastState.compose env29081 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound29081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29082 : List Nat := [2,4,8,16,32,64,9,116,512,100,602,64,40,81,1,35,65,603,101,0,0,32,17,3,41,65,603,64,64,602,69,33,117,33,0,513]

theorem envBound29082 : H12AffineFastState.Bounded env29082 := by
  intro p hp
  have h : env29082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29081_29082 : H12AffineEnvironment.transform 11 64 env29081 = env29082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env29081 == env29082) = true)

theorem identity29082 : scanCanonicalize (H12AffineFastState.compose env29082 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound29082 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29083 : List Nat := [2,4,7,16,32,64,6,116,512,100,597,64,39,81,1,35,65,596,101,0,0,32,17,3,38,65,596,64,64,597,69,33,117,33,0,513]

theorem envBound29083 : H12AffineFastState.Bounded env29083 := by
  intro p hp
  have h : env29083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29082_29083 : H12AffineEnvironment.transform 2 7 env29082 = env29083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env29082 == env29083) = true)

theorem identity29083 : scanCanonicalize (H12AffineFastState.compose env29083 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound29083 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29084 : List Nat := [2,4,7,16,32,64,6,116,37,100,112,64,39,81,1,35,65,113,101,0,0,32,17,3,38,65,113,64,64,112,69,33,117,33,0,36]

theorem envBound29084 : H12AffineFastState.Bounded env29084 := by
  intro p hp
  have h : env29084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29083_29084 : H12AffineEnvironment.transform 8 37 env29083 = env29084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env29083 == env29084) = true)

theorem identity29084 : scanCanonicalize (H12AffineFastState.compose env29084 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29084 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29085 : List Nat := [1,4,4,16,32,64,5,116,37,100,112,64,36,81,1,32,65,113,101,0,0,32,17,0,37,65,113,64,64,112,69,33,117,33,0,36]

theorem envBound29085 : H12AffineFastState.Bounded env29085 := by
  intro p hp
  have h : env29085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29084_29085 : H12AffineEnvironment.transform 0 1 env29084 = env29085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29084 == env29085) = true)

theorem identity29085 : scanCanonicalize (H12AffineFastState.compose env29085 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29085 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env29086 : List Nat := [1,4,4,16,1,64,5,85,4,69,81,64,5,81,1,1,65,80,68,0,0,1,17,0,4,65,80,64,64,81,69,0,84,0,0,5]

theorem envBound29086 : H12AffineFastState.Bounded env29086 := by
  intro p hp
  have h : env29086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29085_29086 : H12AffineEnvironment.transform 4 1 env29085 = env29086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29085 == env29086) = true)

def env29087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329897,8328,65,507955,302180,333995,236987,119042,272393,257,98815,90203,63188]

theorem envBound29087 : H12AffineFastState.Bounded env29087 := by
  intro p hp
  have h : env29087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29059_29087 : H12AffineEnvironment.transform 20 4161 env29059 = env29087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29059 == env29087) = true)

theorem identity29087 : scanCanonicalize (H12AffineFastState.compose env29087 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29087 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294320,272547,8328,65,450617,302180,276641,179633,61704,272393,257,41461,16465,63188]

theorem envBound29088 : H12AffineFastState.Bounded env29088 := by
  intro p hp
  have h : env29088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29087_29088 : H12AffineEnvironment.transform 15 8202 env29087 = env29088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29087 == env29088) = true)

def env29089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294200,272427,8192,65,450617,302180,276521,179513,61704,272393,257,41341,16465,63068]

theorem envBound29089 : H12AffineFastState.Bounded env29089 := by
  intro p hp
  have h : env29089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29088_29089 : H12AffineEnvironment.transform 6 8 env29088 = env29089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29088 == env29089) = true)

theorem identity29089 : scanCanonicalize (H12AffineFastState.compose env29089 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound29089 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,262144,1025,32769,4161,21792,294200,272427,8192,65,283764,302180,276521,2420,61704,272393,257,41341,16465,63068]

theorem envBound29090 : H12AffineFastState.Bounded env29090 := by
  intro p hp
  have h : env29090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29089_29090 : H12AffineEnvironment.transform 16 46157 env29089 = env29090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env29089 == env29090) = true)

theorem identity29090 : scanCanonicalize (H12AffineFastState.compose env29090 (packedSelected [0,9,17,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound29090 : packedSelected [0,9,17,22,27] rootPS < 2^1333 := by decide +kernel

def env29091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,8202,5440,262144,1025,8460,4161,21792,294200,272427,8192,65,283764,277865,276521,2420,20485,272393,257,112,16465,22353]

theorem envBound29091 : H12AffineFastState.Bounded env29091 := by
  intro p hp
  have h : env29091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29090_29091 : H12AffineEnvironment.transform 14 8461 env29090 = env29091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env29090 == env29091) = true)

theorem identity29091 : scanCanonicalize (H12AffineFastState.compose env29091 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29091 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29092 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8233,8202,5220,262144,1025,8232,4161,21508,293916,272427,8192,65,283764,277581,276521,2128,20485,272393,37,112,16465,22133]

theorem envBound29092 : H12AffineFastState.Bounded env29092 := by
  intro p hp
  have h : env29092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29091_29092 : H12AffineEnvironment.transform 7 36 env29091 = env29092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29091 == env29092) = true)

theorem identity29092 : scanCanonicalize (H12AffineFastState.compose env29092 (packedSelected [2,6,9,11,14,17,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29092 : packedSelected [2,6,9,11,14,17,22,23] rootPS < 2^1333 := by decide +kernel

def env29093 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,81,114,5220,262144,1025,80,4161,21508,285796,264275,120,65,283764,269365,268369,2128,20485,264305,37,112,16465,22133]

theorem envBound29093 : H12AffineFastState.Bounded env29093 := by
  intro p hp
  have h : env29093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29092_29093 : H12AffineEnvironment.transform 12 120 env29092 = env29093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29092 == env29093) = true)

theorem identity29093 : scanCanonicalize (H12AffineFastState.compose env29093 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound29093 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29094 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,81,114,5220,23669,1025,80,4161,21508,17,21542,120,65,2049,16448,17444,2128,20485,21508,37,112,16465,22133]

theorem envBound29094 : H12AffineFastState.Bounded env29094 := by
  intro p hp
  have h : env29094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29093_29094 : H12AffineEnvironment.transform 17 23669 env29093 = env29094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env29093 == env29094) = true)

def env29095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294201,272426,8193,65,450617,302180,276520,179512,61704,272393,257,41340,16465,63069]

theorem envBound29095 : H12AffineFastState.Bounded env29095 := by
  intro p hp
  have h : env29095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29088_29095 : H12AffineEnvironment.transform 6 9 env29088 = env29095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29088 == env29095) = true)

theorem identity29095 : scanCanonicalize (H12AffineFastState.compose env29095 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29095 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,262144,1025,29789,4161,21792,294201,272426,8193,65,398437,288824,276520,149860,1364,272393,257,21792,16465,513]

theorem envBound29096 : H12AffineFastState.Bounded env29096 := by
  intro p hp
  have h : env29096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29095_29096 : H12AffineEnvironment.transform 14 29788 env29095 = env29096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29095 == env29096) = true)

theorem identity29096 : scanCanonicalize (H12AffineFastState.compose env29096 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound29096 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env29097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4161,21792,17,21762,8193,65,158029,5392,17664,149860,1364,21793,257,21792,16465,513]

theorem envBound29097 : H12AffineFastState.Bounded env29097 := by
  intro p hp
  have h : env29097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29096_29097 : H12AffineEnvironment.transform 17 32040 env29096 = env29097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env29096 == env29097) = true)

theorem identity29097 : scanCanonicalize (H12AffineFastState.compose env29097 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29097 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,263,131072,23589,1025,21840,4161,21792,17,21762,268,65,149568,5392,17664,149860,1364,21793,257,21792,16465,513]

theorem envBound29098 : H12AffineFastState.Bounded env29098 := by
  intro p hp
  have h : env29098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29097_29098 : H12AffineEnvironment.transform 12 269 env29097 = env29098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29097 == env29098) = true)

theorem identity29098 : scanCanonicalize (H12AffineFastState.compose env29098 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29098 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env29099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,263,131072,2340,1025,81,4161,33,17,3,268,65,138561,5392,4097,138341,1364,32,257,33,5456,513]

theorem envBound29099 : H12AffineFastState.Bounded env29099 := by
  intro p hp
  have h : env29099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29098_29099 : H12AffineEnvironment.transform 13 5377 env29098 = env29099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29098 == env29099) = true)

theorem identity29099 : scanCanonicalize (H12AffineFastState.compose env29099 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound29099 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,263,5441,2340,1025,81,4161,33,17,3,268,65,2048,5392,4097,2340,1364,32,257,33,5456,513]

theorem envBound29100 : H12AffineFastState.Bounded env29100 := by
  intro p hp
  have h : env29100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29099_29100 : H12AffineEnvironment.transform 16 5441 env29099 = env29100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29099 == env29100) = true)

theorem identity29100 : scanCanonicalize (H12AffineFastState.compose env29100 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound29100 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,269,3344,80,263,3408,2340,1025,81,2128,33,17,3,268,65,2048,3329,2064,2340,1364,32,257,33,3393,513]

theorem envBound29101 : H12AffineFastState.Bounded env29101 := by
  intro p hp
  have h : env29101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29100_29101 : H12AffineEnvironment.transform 11 2065 env29100 = env29101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env29100 == env29101) = true)

theorem identity29101 : scanCanonicalize (H12AffineFastState.compose env29101 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29101 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29102 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,269,3344,1,263,3329,2340,1025,0,2049,33,17,3,268,16,2048,3329,2064,2340,1285,32,257,33,3344,513]

theorem envBound29102 : H12AffineFastState.Bounded env29102 := by
  intro p hp
  have h : env29102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29101_29102 : H12AffineEnvironment.transform 5 17 env29101 = env29102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29101 == env29102) = true)

theorem identity29102 : scanCanonicalize (H12AffineFastState.compose env29102 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound29102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29103 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1060,1077,269,308,1,263,293,1280,1025,0,1061,33,17,3,268,16,1060,293,1076,1280,1285,32,257,33,308,513]

theorem envBound29103 : H12AffineFastState.Bounded env29103 := by
  intro p hp
  have h : env29103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29102_29103 : H12AffineEnvironment.transform 10 1060 env29102 = env29103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env29102 == env29103) = true)

theorem identity29103 : scanCanonicalize (H12AffineFastState.compose env29103 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound29103 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29104 : List Nat := [2,4,8,16,32,17,9,256,512,267,303,318,269,308,1,263,293,11,266,0,302,33,17,3,268,16,303,293,319,11,14,32,257,33,308,513]

theorem envBound29104 : H12AffineFastState.Bounded env29104 := by
  intro p hp
  have h : env29104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29103_29104 : H12AffineEnvironment.transform 9 267 env29103 = env29104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env29103 == env29104) = true)

theorem identity29104 : scanCanonicalize (H12AffineFastState.compose env29104 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29104 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29105 : List Nat := [2,4,8,16,32,17,9,14,512,5,33,48,3,58,1,9,43,11,4,0,32,33,17,3,2,16,33,43,49,11,14,32,15,33,58,513]

theorem envBound29105 : H12AffineFastState.Bounded env29105 := by
  intro p hp
  have h : env29105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29104_29105 : H12AffineEnvironment.transform 7 14 env29104 = env29105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29104 == env29105) = true)

def env29106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431209,8328,65,2609267,302181,333995,2330106,119043,2373705,257,2199999,2191387,63189]

theorem envBound29106 : H12AffineFastState.Bounded env29106 := by
  intro p hp
  have h : env29106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29058_29106 : H12AffineEnvironment.transform 23 2431209 env29058 = env29106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env29058 == env29106) = true)

def env29107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329897,8328,65,507955,302181,333995,236986,119043,272393,257,98815,90203,63189]

theorem envBound29107 : H12AffineFastState.Bounded env29107 := by
  intro p hp
  have h : env29107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29106_29107 : H12AffineEnvironment.transform 20 4160 env29106 = env29107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29106 == env29107) = true)

theorem identity29107 : scanCanonicalize (H12AffineFastState.compose env29107 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound29107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,21793,297317,318583,8328,65,398573,302181,314485,149860,1501,272393,257,21793,46213,63189]

theorem envBound29108 : H12AffineFastState.Bounded env29108 := by
  intro p hp
  have h : env29108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29107_29108 : H12AffineEnvironment.transform 15 54494 env29107 = env29108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env29107 == env29108) = true)

def env29109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4160,21793,41293,62559,8328,65,146629,46157,58461,149860,1501,33,257,21793,46213,63189]

theorem envBound29109 : H12AffineFastState.Bounded env29109 := by
  intro p hp
  have h : env29109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29108_29109 : H12AffineEnvironment.transform 17 10280 env29108 = env29109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29108 == env29109) = true)

theorem identity29109 : scanCanonicalize (H12AffineFastState.compose env29109 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10280,1025,32769,4160,32,41293,41310,8328,65,146629,46157,45404,138341,1501,33,257,32,46213,41940]

theorem envBound29110 : H12AffineFastState.Bounded env29110 := by
  intro p hp
  have h : env29110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29109_29110 : H12AffineEnvironment.transform 13 5377 env29109 = env29110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29109 == env29110) = true)

theorem identity29110 : scanCanonicalize (H12AffineFastState.compose env29110 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29110 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env29111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5393,10280,1025,32769,4160,32,41293,41310,8328,65,10708,46157,45404,2420,1501,33,257,32,46213,41940]

theorem envBound29111 : H12AffineFastState.Bounded env29111 := by
  intro p hp
  have h : env29111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29110_29111 : H12AffineEnvironment.transform 16 5393 env29110 = env29111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29110 == env29111) = true)

theorem identity29111 : scanCanonicalize (H12AffineFastState.compose env29111 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound29111 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env29112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5393,10280,1025,8660,4160,32,152,139,8328,65,10708,5528,4233,2420,1501,33,257,32,5456,513]

theorem envBound29112 : H12AffineFastState.Bounded env29112 := by
  intro p hp
  have h : env29112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29111_29112 : H12AffineEnvironment.transform 14 8661 env29111 = env29112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env29111 == env29112) = true)

theorem identity29112 : scanCanonicalize (H12AffineFastState.compose env29112 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound29112 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29113 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4249,8661,8202,4233,10280,409,8660,4160,32,152,139,8328,65,10708,4096,4233,2420,69,33,257,32,4296,513]

theorem envBound29113 : H12AffineFastState.Bounded env29113 := by
  intro p hp
  have h : env29113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29112_29113 : H12AffineEnvironment.transform 9 408 env29112 = env29113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env29112 == env29113) = true)

theorem identity29113 : scanCanonicalize (H12AffineFastState.compose env29113 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29113 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29114 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,8192,4249,8433,8202,4233,10280,189,8432,4160,32,152,139,8328,65,10480,4096,4233,2128,69,33,37,32,4296,513]

theorem envBound29114 : H12AffineFastState.Bounded env29114 := by
  intro p hp
  have h : env29114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29113_29114 : H12AffineEnvironment.transform 7 36 env29113 = env29114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29113 == env29114) = true)

theorem identity29114 : scanCanonicalize (H12AffineFastState.compose env29114 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound29114 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env29115 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,121,4249,136,115,4233,2129,189,137,4160,32,152,139,241,65,2185,4096,4233,2128,69,33,37,32,4296,513]

theorem envBound29115 : H12AffineFastState.Bounded env29115 := by
  intro p hp
  have h : env29115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29114_29115 : H12AffineEnvironment.transform 12 121 env29114 = env29115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env29114 == env29115) = true)

theorem identity29115 : scanCanonicalize (H12AffineFastState.compose env29115 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound29115 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29116 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,2249,121,2128,136,115,2112,2129,189,137,2185,32,152,139,241,65,2185,2249,2112,2128,69,33,37,32,2049,513]

theorem envBound29116 : H12AffineFastState.Bounded env29116 := by
  intro p hp
  have h : env29116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29115_29116 : H12AffineEnvironment.transform 11 2249 env29115 = env29116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env29115 == env29116) = true)

def env29117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4160,21793,41292,62558,8328,65,146628,46156,58460,149860,1501,32,257,21793,46213,63189]

theorem envBound29117 : H12AffineFastState.Bounded env29117 := by
  intro p hp
  have h : env29117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29108_29117 : H12AffineEnvironment.transform 17 10281 env29108 = env29117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29108 == env29117) = true)

theorem identity29117 : scanCanonicalize (H12AffineFastState.compose env29117 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29117 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,10281,1025,29909,4160,21793,21912,138,8328,65,146628,16536,4232,149860,1501,32,257,21793,16465,513]

theorem envBound29118 : H12AffineFastState.Bounded env29118 := by
  intro p hp
  have h : env29118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29117_29118 : H12AffineEnvironment.transform 14 29908 env29117 = env29118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29117 == env29118) = true)

theorem identity29118 : scanCanonicalize (H12AffineFastState.compose env29118 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29118 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env29119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21977,263,131072,2340,1025,21976,4160,21793,21912,138,389,65,138697,16536,4232,149860,1501,32,257,21793,16465,513]

theorem envBound29119 : H12AffineFastState.Bounded env29119 := by
  intro p hp
  have h : env29119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29118_29119 : H12AffineEnvironment.transform 12 269 env29118 = env29119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29118 == env29119) = true)

theorem identity29119 : scanCanonicalize (H12AffineFastState.compose env29119 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29119 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env29120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,263,131072,2340,1025,21841,4160,21793,21777,3,268,65,138560,16401,4097,149860,1364,32,257,21793,16465,513]

theorem envBound29120 : H12AffineFastState.Bounded env29120 := by
  intro p hp
  have h : env29120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29119_29120 : H12AffineEnvironment.transform 6 9 env29119 = env29120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29119 == env29120) = true)

theorem identity29120 : scanCanonicalize (H12AffineFastState.compose env29120 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29120 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,263,5393,2340,1025,21841,4160,21793,21777,3,268,65,2129,16401,4097,23669,1364,32,257,21793,16465,513]

theorem envBound29121 : H12AffineFastState.Bounded env29121 := by
  intro p hp
  have h : env29121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29120_29121 : H12AffineEnvironment.transform 16 5393 env29120 = env29121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29120 == env29121) = true)

theorem identity29121 : scanCanonicalize (H12AffineFastState.compose env29121 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29121 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,263,5393,2340,1025,81,4160,33,17,3,268,65,2129,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound29122 : H12AffineFastState.Bounded env29122 := by
  intro p hp
  have h : env29122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29121_29122 : H12AffineEnvironment.transform 13 5376 env29121 = env29122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29121 == env29122) = true)

theorem identity29122 : scanCanonicalize (H12AffineFastState.compose env29122 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound29122 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3354,269,2074,80,263,2059,2340,1025,81,3418,33,17,3,268,65,2129,2059,3355,2421,1364,32,257,33,2123,513]

theorem envBound29123 : H12AffineFastState.Bounded env29123 := by
  intro p hp
  have h : env29123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29122_29123 : H12AffineEnvironment.transform 11 3354 env29122 = env29123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env29122 == env29123) = true)

theorem identity29123 : scanCanonicalize (H12AffineFastState.compose env29123 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 346) := by decide +kernel

theorem selectedBound29123 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env29124 : List Nat := [2,4,8,16,32,64,9,256,512,346,2048,2112,269,2074,80,263,2059,2340,347,81,2048,33,17,3,268,65,2129,2059,2113,2421,14,32,257,33,2123,513]

theorem envBound29124 : H12AffineFastState.Bounded env29124 := by
  intro p hp
  have h : env29124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29123_29124 : H12AffineEnvironment.transform 9 346 env29123 = env29124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 346 env29123 == env29124) = true)

theorem identity29124 : scanCanonicalize (H12AffineFastState.compose env29124 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29124 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29125 : List Nat := [2,4,8,16,32,64,9,14,512,84,2048,2112,3,2074,80,9,2059,2090,85,81,2048,33,17,3,2,65,2129,2059,2113,2171,14,32,15,33,2123,513]

theorem envBound29125 : H12AffineFastState.Bounded env29125 := by
  intro p hp
  have h : env29125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29124_29125 : H12AffineEnvironment.transform 7 14 env29124 = env29125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29124 == env29125) = true)

theorem identity29125 : scanCanonicalize (H12AffineFastState.compose env29125 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29125 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29126 : List Nat := [2,4,8,16,32,17,9,14,512,5,2048,2065,3,2074,1,9,2059,2090,4,0,2048,33,17,3,2,16,2048,2059,2064,2090,14,32,15,33,2074,513]

theorem envBound29126 : H12AffineFastState.Bounded env29126 := by
  intro p hp
  have h : env29126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29125_29126 : H12AffineEnvironment.transform 5 17 env29125 = env29126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29125 == env29126) = true)

theorem identity29126 : scanCanonicalize (H12AffineFastState.compose env29126 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound29126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29127 : List Nat := [2,4,8,16,32,17,9,14,512,5,32,49,3,58,1,9,43,10,4,0,32,33,17,3,2,16,32,43,48,10,14,32,15,33,58,513]

theorem envBound29127 : H12AffineFastState.Bounded env29127 := by
  intro p hp
  have h : env29127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29126_29127 : H12AffineEnvironment.transform 10 32 env29126 = env29127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env29126 == env29127) = true)

def env29128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329896,8328,65,507954,302181,333995,236987,119043,272392,257,98814,90202,63189]

theorem envBound29128 : H12AffineFastState.Bounded env29128 := by
  intro p hp
  have h : env29128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29106_29128 : H12AffineEnvironment.transform 20 4161 env29106 = env29128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29106 == env29128) = true)

theorem identity29128 : scanCanonicalize (H12AffineFastState.compose env29128 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound29128 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108927,1025,32769,4161,21792,62661,41431,8328,65,158029,79130,45524,236987,119043,98679,257,98814,90202,63189]

theorem envBound29129 : H12AffineFastState.Bounded env29129 := by
  intro p hp
  have h : env29129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29128_29129 : H12AffineEnvironment.transform 17 108927 env29128 = env29129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env29128 == env29129) = true)

theorem identity29129 : scanCanonicalize (H12AffineFastState.compose env29129 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29129 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env29130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89515,1025,29909,4161,21792,17,21763,8328,65,158029,79130,17664,223599,75223,95651,257,95530,90202,513]

theorem envBound29130 : H12AffineFastState.Bounded env29130 := by
  intro p hp
  have h : env29130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29129_29130 : H12AffineEnvironment.transform 14 29908 env29129 = env29130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29129 == env29130) = true)

theorem identity29130 : scanCanonicalize (H12AffineFastState.compose env29130 (packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound29130 : packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env29131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82247,89515,1025,29909,4161,21792,17,21763,8328,65,75786,79130,17664,10280,75223,95651,257,95530,90202,513]

theorem envBound29131 : H12AffineFastState.Bounded env29131 := by
  intro p hp
  have h : env29131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29130_29131 : H12AffineEnvironment.transform 16 82247 env29130 = env29131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env29130 == env29131) = true)

theorem identity29131 : scanCanonicalize (H12AffineFastState.compose env29131 (packedSelected [0,1,2,3,8,9,10,11,12,14,15,18,19,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound29131 : packedSelected [0,1,2,3,8,9,10,11,12,14,15,18,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8352,65536,70963,68063,1025,8353,4161,340,17,375,8328,65,75786,79130,4468,10280,75223,74199,257,74078,78894,513]

theorem envBound29132 : H12AffineFastState.Bounded env29132 := by
  intro p hp
  have h : env29132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29131_29132 : H12AffineEnvironment.transform 13 5236 env29131 = env29132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env29131 == env29132) = true)

theorem identity29132 : scanCanonicalize (H12AffineFastState.compose env29132 (packedSelected [0,2,4,7,11,14,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound29132 : packedSelected [0,2,4,7,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env29133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8352,8574,13389,10401,1025,8353,4161,340,17,375,8328,65,2420,5220,4468,10280,1193,169,257,32,5456,513]

theorem envBound29133 : H12AffineFastState.Bounded env29133 := by
  intro p hp
  have h : env29133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29132_29133 : H12AffineEnvironment.transform 15 8574 env29132 = env29133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env29132 == env29133) = true)

theorem identity29133 : scanCanonicalize (H12AffineFastState.compose env29133 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3544) := by decide +kernel

theorem selectedBound29133 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3544,8192,2476,8352,8574,10645,10401,1025,8353,3481,340,17,375,8328,65,2420,2492,3244,10280,1193,169,257,32,2184,513]

theorem envBound29134 : H12AffineFastState.Bounded env29134 := by
  intro p hp
  have h : env29134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29133_29134 : H12AffineEnvironment.transform 11 3544 env29133 = env29134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3544 env29133 == env29134) = true)

theorem identity29134 : scanCanonicalize (H12AffineFastState.compose env29134 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound29134 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env29135 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2113,8192,2476,8352,8574,10645,10401,408,8353,2048,340,17,375,8328,65,2420,2492,2357,10280,304,169,257,32,2184,513]

theorem envBound29135 : H12AffineFastState.Bounded env29135 := by
  intro p hp
  have h : env29135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29134_29135 : H12AffineEnvironment.transform 9 409 env29134 = env29135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env29134 == env29135) = true)

theorem identity29135 : scanCanonicalize (H12AffineFastState.compose env29135 (packedSelected [0,1,2,3,5,6,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound29135 : packedSelected [0,1,2,3,5,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29136 : List Nat := [2,4,8,16,32,64,128,256,512,409,1,64,8192,429,8352,8574,8596,8352,408,8353,1,340,17,375,8328,65,373,445,308,8233,304,169,257,32,137,513]

theorem envBound29136 : H12AffineFastState.Bounded env29136 := by
  intro p hp
  have h : env29136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29135_29136 : H12AffineEnvironment.transform 10 1 env29135 = env29136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env29135 == env29136) = true)

theorem identity29136 : scanCanonicalize (H12AffineFastState.compose env29136 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound29136 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29137 : List Nat := [2,4,8,16,32,64,128,256,512,409,1,64,160,429,0,478,308,0,408,1,1,340,17,375,40,65,373,445,308,137,304,169,257,32,137,513]

theorem envBound29137 : H12AffineFastState.Bounded env29137 := by
  intro p hp
  have h : env29137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29136_29137 : H12AffineEnvironment.transform 12 160 env29136 = env29137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env29136 == env29137) = true)

theorem identity29137 : scanCanonicalize (H12AffineFastState.compose env29137 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29137 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29138 : List Nat := [2,4,8,16,32,64,89,256,512,320,1,64,121,372,0,263,308,0,321,1,1,340,17,375,40,65,373,356,308,80,304,112,257,32,80,513]

theorem envBound29138 : H12AffineFastState.Bounded env29138 := by
  intro p hp
  have h : env29138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29137_29138 : H12AffineEnvironment.transform 6 89 env29137 = env29138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29137 == env29138) = true)

theorem identity29138 : scanCanonicalize (H12AffineFastState.compose env29138 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29138 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29139 : List Nat := [2,4,8,16,32,64,89,36,512,100,1,64,121,80,0,35,16,0,101,1,1,112,17,83,40,65,81,64,16,80,20,112,37,32,80,513]

theorem envBound29139 : H12AffineFastState.Bounded env29139 := by
  intro p hp
  have h : env29139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29138_29139 : H12AffineEnvironment.transform 7 36 env29138 = env29139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29138 == env29139) = true)

def env29140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound29140 : H12AffineFastState.Bounded env29140 := by
  intro p hp
  have h : env29140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26148_29140 : H12AffineEnvironment.transform 31 145662401 env26148 = env29140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env26148 == env29140) = true)

def env29141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound29141 : H12AffineFastState.Bounded env29141 := by
  intro p hp
  have h : env29141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29140_29141 : H12AffineEnvironment.transform 29 155254784 env29140 = env29141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env29140 == env29141) = true)

def env29142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound29142 : H12AffineFastState.Bounded env29142 := by
  intro p hp
  have h : env29142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29141_29142 : H12AffineEnvironment.transform 25 64 env29141 = env29142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env29141 == env29142) = true)

def env29143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound29143 : H12AffineFastState.Bounded env29143 := by
  intro p hp
  have h : env29143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29142_29143 : H12AffineEnvironment.transform 26 30393344 env29142 = env29143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env29142 == env29143) = true)

def env29144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound29144 : H12AffineFastState.Bounded env29144 := by
  intro p hp
  have h : env29144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29143_29144 : H12AffineEnvironment.transform 18 1024 env29143 = env29144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29143 == env29144) = true)

theorem identity29144 : scanCanonicalize (H12AffineFastState.compose env29144 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91587) := by decide +kernel

theorem selectedBound29144 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,16777216,8328,64,29868032,16834894,8466578,8830976,25265168,20971522,256,25207151,25182410,25207750]

theorem envBound29145 : H12AffineFastState.Bounded env29145 := by
  intro p hp
  have h : env29145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29144_29145 : H12AffineEnvironment.transform 20 91587 env29144 = env29145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91587 env29144 == env29145) = true)

def env29146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119892,8328,64,12981332,79130,8466578,8830976,8409156,4314198,256,8484155,8492190,8484754]

theorem envBound29146 : H12AffineFastState.Bounded env29146 := by
  intro p hp
  have h : env29146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29145_29146 : H12AffineEnvironment.transform 23 119892 env29145 = env29146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119892 env29145 == env29146) = true)

def env29147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981332,79130,8466578,8819968,8389956,4292950,256,8462395,8492190,8462994]

theorem envBound29147 : H12AffineFastState.Bounded env29147 := by
  intro p hp
  have h : env29147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29146_29147 : H12AffineEnvironment.transform 13 5376 env29146 = env29147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29146 == env29147) = true)

def env29148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787060,79130,8466578,8819968,8389956,98678,256,8462395,8492190,8462994]

theorem envBound29148 : H12AffineFastState.Bounded env29148 := by
  intro p hp
  have h : env29148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29147_29148 : H12AffineEnvironment.transform 21 32 env29147 = env29148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29147 == env29148) = true)

theorem identity29148 : scanCanonicalize (H12AffineFastState.compose env29148 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound29148 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,73875,98644,8328,64,472295,79130,4097,505235,75223,98678,256,168,46093,513]

theorem envBound29149 : H12AffineFastState.Bounded env29149 := by
  intro p hp
  have h : env29149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29148_29149 : H12AffineEnvironment.transform 22 73875 env29148 = env29149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env29148 == env29149) = true)

def env29150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98644,8192,64,472175,79130,4097,505115,75103,98678,256,32,46093,513]

theorem envBound29150 : H12AffineFastState.Bounded env29150 := by
  intro p hp
  have h : env29150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29149_29150 : H12AffineEnvironment.transform 6 8 env29149 = env29150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29149 == env29150) = true)

theorem identity29150 : scanCanonicalize (H12AffineFastState.compose env29150 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound29150 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,77899,32,73755,98644,8192,64,262516,79130,4097,294912,75103,98678,256,32,46093,513]

theorem envBound29151 : H12AffineFastState.Bounded env29151 := by
  intro p hp
  have h : env29151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29150_29151 : H12AffineEnvironment.transform 16 79131 env29150 = env29151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env29150 == env29151) = true)

theorem identity29151 : scanCanonicalize (H12AffineFastState.compose env29151 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound29151 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1