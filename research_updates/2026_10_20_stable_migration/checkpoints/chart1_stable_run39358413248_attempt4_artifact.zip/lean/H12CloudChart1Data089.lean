import H12CloudChart1Data088

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound22529 : H12AffineFastState.Bounded env22529 := by
  intro p hp
  have h : env22529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22528_22529 : H12AffineEnvironment.transform 0 0 env22528 = env22529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22528 == env22529) = true)

def leafEnv22529 : List Nat := [0,4,8,16,0,17,8,5,28,0,20,17,8,21,0,0,5,21,1,1,0,0,17,0,1,8,1,17,21,4,17,20,1,1,4,0,4,0,20,28,1,1,0]

def active22529 : List Nat := [1,2,3]

def tree22529 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22529 : H12WitnessSearch.Good tree22529 := H12GlobalWitnessIndex.good

theorem leafIdentity22529 : H12AffineFastState.composeSystem env22529 rootObs = leafEnv22529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22529 rootObs == leafEnv22529) = true)

theorem terminalChecked22529 : H12PackedTerminal.terminalCheckFast leafEnv22529 active22529 tree22529 = true := by decide +kernel

def env22530 : List Nat := [2,4,8,16,0,17,8,5,30,1,20,17,8,20,0,2,4,21,0,1,0,0,17,2,8,17,21,5,17,20,0,1,4,0,21,30]

theorem envBound22530 : H12AffineFastState.Bounded env22530 := by
  intro p hp
  have h : env22530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22527_22530 : H12AffineEnvironment.transform 9 1 env22527 = env22530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env22527 == env22530) = true)

theorem identity22530 : scanCanonicalize (H12AffineFastState.compose env22530 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound22530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22531 : List Nat := [2,4,8,6,0,7,8,5,8,1,2,7,8,2,0,2,4,3,0,1,0,0,7,2,8,7,3,5,7,2,0,1,4,0,3,8]

theorem envBound22531 : H12AffineFastState.Bounded env22531 := by
  intro p hp
  have h : env22531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22530_22531 : H12AffineEnvironment.transform 3 6 env22530 = env22531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env22530 == env22531) = true)

def leafEnv22531 : List Nat := [2,4,8,6,0,7,8,5,8,1,2,7,8,2,0,2,4,3,0,1,0,0,7,2,0,8,1,7,3,5,7,2,0,1,4,0,4,2,3,8,1,1,0]

def active22531 : List Nat := [0,1,2]

def tree22531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22531 : H12WitnessSearch.Good tree22531 := H12GlobalWitnessIndex.good

theorem leafIdentity22531 : H12AffineFastState.composeSystem env22531 rootObs = leafEnv22531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22531 rootObs == leafEnv22531) = true)

theorem terminalChecked22531 : H12PackedTerminal.terminalCheckFast leafEnv22531 active22531 tree22531 = true := by decide +kernel

def env22532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,73770,119879,21763,8193,64,64604,115014,102743,35188,1364,32,257,21793,46092,74250]

theorem envBound22532 : H12AffineFastState.Bounded env22532 := by
  intro p hp
  have h : env22532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22510_22532 : H12AffineEnvironment.transform 6 9 env22510 = env22532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22510 == env22532) = true)

theorem identity22532 : scanCanonicalize (H12AffineFastState.compose env22532 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound22532 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82247,10280,1025,29789,4160,73770,73755,21763,8193,64,2048,79130,91403,32040,1364,32,257,21793,16464,74250]

theorem envBound22533 : H12AffineFastState.Bounded env22533 := by
  intro p hp
  have h : env22533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22532_22533 : H12AffineEnvironment.transform 14 29788 env22532 = env22533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env22532 == env22533) = true)

theorem identity22533 : scanCanonicalize (H12AffineFastState.compose env22533 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound22533 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,16400,10280,1025,29789,4160,8573,8524,21763,8193,64,2048,13389,25692,32040,1364,32,257,21793,16464,9053]

theorem envBound22534 : H12AffineFastState.Bounded env22534 := by
  intro p hp
  have h : env22534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22533_22534 : H12AffineEnvironment.transform 15 343 env22533 = env22534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env22533 == env22534) = true)

theorem identity22534 : scanCanonicalize (H12AffineFastState.compose env22534 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound22534 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1296,343,12636,10280,1025,1297,4160,8573,8524,9295,8193,64,2048,13389,5392,3172,1364,32,257,9325,12572,9053]

theorem envBound22535 : H12AffineFastState.Bounded env22535 := by
  intro p hp
  have h : env22535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22534_22535 : H12AffineEnvironment.transform 13 12620 env22534 = env22535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env22534 == env22535) = true)

theorem identity22535 : scanCanonicalize (H12AffineFastState.compose env22535 (packedSelected [0,2,6,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound22535 : packedSelected [0,2,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env22536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,3173,1296,343,3189,5377,1025,1297,4160,7252,7269,6502,7464,64,2048,2404,5392,3172,1364,32,257,6468,3125,7796]

theorem envBound22536 : H12AffineFastState.Bounded env22536 := by
  intro p hp
  have h : env22536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22535_22536 : H12AffineEnvironment.transform 12 7465 env22535 = env22536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env22535 == env22536) = true)

theorem identity22536 : scanCanonicalize (H12AffineFastState.compose env22536 (packedSelected [2,4,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound22536 : packedSelected [2,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env22537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,522,4096,5923,1647,1296,343,1663,5377,1025,1297,4160,5726,5743,4972,5922,64,522,878,5392,1646,1364,32,257,4942,1599,5246]

theorem envBound22537 : H12AffineFastState.Bounded env22537 := by
  intro p hp
  have h : env22537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22536_22537 : H12AffineEnvironment.transform 10 522 env22536 = env22537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env22536 == env22537) = true)

theorem identity22537 : scanCanonicalize (H12AffineFastState.compose env22537 (packedSelected [1,3,4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22537 : packedSelected [1,3,4,9,14] rootPS < 2^1333 := by decide +kernel

def env22538 : List Nat := [2,4,8,16,32,64,9,256,512,53,522,4096,4886,602,293,343,586,4404,52,292,4160,4715,4698,4972,4887,64,522,878,4389,603,353,32,257,4942,522,4171]

theorem envBound22538 : H12AffineFastState.Bounded env22538 := by
  intro p hp
  have h : env22538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22537_22538 : H12AffineEnvironment.transform 9 53 env22537 = env22538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22537 == env22538) = true)

theorem identity22538 : scanCanonicalize (H12AffineFastState.compose env22538 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22538 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22539 : List Nat := [2,4,8,16,32,64,9,36,512,53,522,4096,4658,602,1,115,586,4112,52,0,4160,4715,4698,4680,4659,64,522,586,4097,603,69,32,37,4714,522,4171]

theorem envBound22539 : H12AffineFastState.Bounded env22539 := by
  intro p hp
  have h : env22539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22538_22539 : H12AffineEnvironment.transform 7 36 env22538 = env22539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22538 == env22539) = true)

theorem identity22539 : scanCanonicalize (H12AffineFastState.compose env22539 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound22539 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22540 : List Nat := [2,4,8,16,32,64,9,36,512,53,522,539,41,602,1,115,586,523,52,0,603,112,65,83,40,64,522,586,538,603,69,32,37,113,522,592]

theorem envBound22540 : H12AffineFastState.Bounded env22540 := by
  intro p hp
  have h : env22540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22539_22540 : H12AffineEnvironment.transform 11 539 env22539 = env22540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env22539 == env22540) = true)

theorem identity22540 : scanCanonicalize (H12AffineFastState.compose env22540 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22540 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22541 : List Nat := [2,4,8,16,1,64,9,5,512,20,522,539,8,602,1,82,586,523,21,0,603,81,65,83,9,64,522,586,538,603,69,1,4,80,522,592]

theorem envBound22541 : H12AffineFastState.Bounded env22541 := by
  intro p hp
  have h : env22541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22540_22541 : H12AffineEnvironment.transform 4 1 env22540 = env22541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22540 == env22541) = true)

theorem identity22541 : scanCanonicalize (H12AffineFastState.compose env22541 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22541 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22542 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,539,8,523,1,3,539,523,21,0,522,0,16,2,9,17,522,539,538,522,20,1,4,1,522,513]

theorem envBound22542 : H12AffineFastState.Bounded env22542 := by
  intro p hp
  have h : env22542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22541_22542 : H12AffineEnvironment.transform 5 17 env22541 = env22542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22541 == env22542) = true)

theorem identity22542 : scanCanonicalize (H12AffineFastState.compose env22542 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound22542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22543 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,527,8,523,1,3,527,523,1,0,522,0,4,2,9,5,522,527,526,522,0,1,4,1,522,513]

theorem envBound22543 : H12AffineFastState.Bounded env22543 := by
  intro p hp
  have h : env22543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22542_22543 : H12AffineEnvironment.transform 3 4 env22542 = env22543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22542 == env22543) = true)

theorem identity22543 : scanCanonicalize (H12AffineFastState.compose env22543 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22544 : List Nat := [1,4,8,4,1,5,9,5,512,0,521,524,8,520,1,0,524,520,1,0,521,0,4,1,9,5,521,524,525,521,0,1,4,1,521,513]

theorem envBound22544 : H12AffineFastState.Bounded env22544 := by
  intro p hp
  have h : env22544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22543_22544 : H12AffineEnvironment.transform 0 1 env22543 = env22544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22543 == env22544) = true)

theorem identity22544 : scanCanonicalize (H12AffineFastState.compose env22544 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound22544 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22545 : List Nat := [1,4,8,4,1,5,9,5,8,0,1,4,8,0,1,0,4,0,1,0,1,0,4,1,9,5,1,4,5,1,0,1,4,1,1,9]

theorem envBound22545 : H12AffineFastState.Bounded env22545 := by
  intro p hp
  have h : env22545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22544_22545 : H12AffineEnvironment.transform 8 8 env22544 = env22545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env22544 == env22545) = true)

def env22546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,21762,8328,64,215367,115151,140484,303573,241863,498962,257,254010,197022,169744]

theorem envBound22546 : H12AffineFastState.Bounded env22546 := by
  intro p hp
  have h : env22546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22499_22546 : H12AffineEnvironment.transform 20 4161 env22499 = env22546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22499 == env22546) = true)

theorem identity22546 : scanCanonicalize (H12AffineFastState.compose env22546 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22546 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,441745,156117,21762,8328,64,158028,57796,140484,303573,168140,441625,257,180273,139669,169744]

theorem envBound22547 : H12AffineFastState.Bounded env22547 := by
  intro p hp
  have h : env22547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22546_22547 : H12AffineEnvironment.transform 15 8203 env22546 = env22547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22546 == env22547) = true)

theorem identity22547 : scanCanonicalize (H12AffineFastState.compose env22547 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound22547 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4161,272512,62660,21762,8328,64,64605,57796,45525,303573,1501,272392,257,21792,46212,513]

theorem envBound22548 : H12AffineFastState.Bounded env22548 := by
  intro p hp
  have h : env22548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22547_22548 : H12AffineEnvironment.transform 16 38161 env22547 = env22548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22547 == env22548) = true)

theorem identity22548 : scanCanonicalize (H12AffineFastState.compose env22548 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound22548 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env22549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,38161,262144,1025,32769,4161,264532,54544,21762,348,64,56713,49168,36865,294913,1501,264668,257,21792,38224,513]

theorem envBound22549 : H12AffineFastState.Bounded env22549 := by
  intro p hp
  have h : env22549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22548_22549 : H12AffineEnvironment.transform 12 468 env22548 = env22549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env22548 == env22549) = true)

theorem identity22549 : scanCanonicalize (H12AffineFastState.compose env22549 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound22549 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env22550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,38161,2557,1025,32769,4161,169,54544,21762,348,64,56713,49168,36865,35324,1501,33,257,21792,38224,513]

theorem envBound22550 : H12AffineFastState.Bounded env22550 := by
  intro p hp
  have h : env22550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22549_22550 : H12AffineEnvironment.transform 17 2557 env22549 = env22550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env22549 == env22550) = true)

theorem identity22550 : scanCanonicalize (H12AffineFastState.compose env22550 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22550 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,16400,2557,1025,21760,4161,169,17,21762,348,64,2184,5393,17664,23805,1501,33,257,21792,16465,513]

theorem envBound22551 : H12AffineFastState.Bounded env22551 := by
  intro p hp
  have h : env22551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22550_22551 : H12AffineEnvironment.transform 14 21761 env22550 = env22551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22550 == env22551) = true)

theorem identity22551 : scanCanonicalize (H12AffineFastState.compose env22551 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22551 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,343,16400,2421,1025,21760,4161,33,17,21762,348,64,2048,5393,17664,23669,1365,33,257,21792,16465,513]

theorem envBound22552 : H12AffineFastState.Bounded env22552 := by
  intro p hp
  have h : env22552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22551_22552 : H12AffineEnvironment.transform 6 8 env22551 = env22552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22551 == env22552) = true)

theorem identity22552 : scanCanonicalize (H12AffineFastState.compose env22552 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound22552 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,7285,2420,343,7269,2421,1025,2421,4161,33,17,2423,348,64,2048,5393,6517,0,1365,33,257,2389,7204,513]

theorem envBound22553 : H12AffineFastState.Bounded env22553 := by
  intro p hp
  have h : env22553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22552_22553 : H12AffineEnvironment.transform 13 7285 env22552 = env22553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env22552 == env22553) = true)

theorem identity22553 : scanCanonicalize (H12AffineFastState.compose env22553 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound22553 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env22554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3103,348,106,2420,343,122,2421,1025,2421,3166,33,17,2423,348,64,2048,2318,1386,0,1365,33,257,2389,59,513]

theorem envBound22554 : H12AffineFastState.Bounded env22554 := by
  intro p hp
  have h : env22554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22553_22554 : H12AffineEnvironment.transform 11 3103 env22553 = env22554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env22553 == env22554) = true)

theorem identity22554 : scanCanonicalize (H12AffineFastState.compose env22554 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound22554 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env22555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,123,348,106,1296,343,122,1297,1025,1297,58,33,17,1299,348,64,1124,1386,1386,0,1365,33,257,1329,59,513]

theorem envBound22555 : H12AffineFastState.Bounded env22555 := by
  intro p hp
  have h : env22555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22554_22555 : H12AffineEnvironment.transform 10 1124 env22554 = env22555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env22554 == env22555) = true)

theorem identity22555 : scanCanonicalize (H12AffineFastState.compose env22555 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 378) := by decide +kernel

theorem selectedBound22555 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22556 : List Nat := [2,4,8,16,32,64,8,256,512,378,286,123,348,106,106,343,122,107,379,107,58,33,17,105,348,64,286,16,16,0,47,33,257,75,59,513]

theorem envBound22556 : H12AffineFastState.Bounded env22556 := by
  intro p hp
  have h : env22556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22555_22556 : H12AffineEnvironment.transform 9 378 env22555 = env22556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 378 env22555 == env22556) = true)

theorem identity22556 : scanCanonicalize (H12AffineFastState.compose env22556 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound22556 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22557 : List Nat := [2,4,8,16,32,64,8,111,512,21,113,123,51,106,106,56,122,107,20,107,58,33,17,105,51,64,113,16,16,0,47,33,110,75,59,513]

theorem envBound22557 : H12AffineFastState.Bounded env22557 := by
  intro p hp
  have h : env22557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22556_22557 : H12AffineEnvironment.transform 7 111 env22556 = env22557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env22556 == env22557) = true)

theorem identity22557 : scanCanonicalize (H12AffineFastState.compose env22557 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22557 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env22558 : List Nat := [2,4,3,16,32,64,3,100,512,21,113,112,51,97,97,51,113,96,20,96,49,33,17,98,51,64,113,16,16,0,36,33,101,64,48,513]

theorem envBound22558 : H12AffineFastState.Bounded env22558 := by
  intro p hp
  have h : env22558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22557_22558 : H12AffineEnvironment.transform 2 3 env22557 = env22558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22557 == env22558) = true)

theorem identity22558 : scanCanonicalize (H12AffineFastState.compose env22558 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound22558 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22559 : List Nat := [2,4,3,16,32,64,3,100,34,21,113,112,51,97,97,51,113,96,20,96,49,33,17,98,51,64,113,16,16,0,36,33,101,64,48,35]

theorem envBound22559 : H12AffineFastState.Bounded env22559 := by
  intro p hp
  have h : env22559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22558_22559 : H12AffineEnvironment.transform 8 34 env22558 = env22559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env22558 == env22559) = true)

theorem identity22559 : scanCanonicalize (H12AffineFastState.compose env22559 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22559 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env22560 : List Nat := [2,4,3,16,1,64,3,69,3,21,80,81,18,64,64,18,80,65,20,65,16,0,17,67,18,64,80,16,16,0,5,0,68,64,17,2]

theorem envBound22560 : H12AffineFastState.Bounded env22560 := by
  intro p hp
  have h : env22560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22559_22560 : H12AffineEnvironment.transform 4 1 env22559 = env22560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22559 == env22560) = true)

theorem identity22560 : scanCanonicalize (H12AffineFastState.compose env22560 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22561 : List Nat := [2,4,3,0,1,64,3,69,3,5,64,65,2,64,64,2,64,65,4,65,0,0,1,67,2,64,64,0,0,0,5,0,68,64,1,2]

theorem envBound22561 : H12AffineFastState.Bounded env22561 := by
  intro p hp
  have h : env22561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22560_22561 : H12AffineEnvironment.transform 3 0 env22560 = env22561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22560 == env22561) = true)

theorem identity22561 : scanCanonicalize (H12AffineFastState.compose env22561 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound22561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22562 : List Nat := [2,4,3,0,1,7,3,2,3,5,7,6,2,7,7,2,7,6,4,6,0,0,1,4,2,7,7,0,0,0,5,0,3,7,1,2]

theorem envBound22562 : H12AffineFastState.Bounded env22562 := by
  intro p hp
  have h : env22562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22561_22562 : H12AffineEnvironment.transform 5 7 env22561 = env22562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env22561 == env22562) = true)

def env22563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156117,2114883,8328,64,215366,115151,2241669,303573,2334854,2592082,257,254010,197022,2262865]

theorem envBound22563 : H12AffineFastState.Bounded env22563 := by
  intro p hp
  have h : env22563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22498_22563 : H12AffineEnvironment.transform 21 2534865 env22498 = env22563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env22498 == env22563) = true)

def env22564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,21763,8328,64,215366,115151,140485,303573,241862,498962,257,254010,197022,169745]

theorem envBound22564 : H12AffineFastState.Bounded env22564 := by
  intro p hp
  have h : env22564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22563_22564 : H12AffineEnvironment.transform 20 4160 env22563 = env22564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22563 == env22564) = true)

theorem identity22564 : scanCanonicalize (H12AffineFastState.compose env22564 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound22564 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,441745,156117,21763,8328,64,171417,5392,140485,303573,156697,412109,257,144613,185665,169745]

theorem envBound22565 : H12AffineFastState.Bounded env22565 := by
  intro p hp
  have h : env22565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22564_22565 : H12AffineEnvironment.transform 15 54495 env22564 = env22565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env22564 == env22565) = true)

def env22566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4160,169401,156117,21763,8328,64,171417,5392,140485,35325,156697,156133,257,144613,185665,169745]

theorem envBound22566 : H12AffineFastState.Bounded env22566 := by
  intro p hp
  have h : env22566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22565_22566 : H12AffineEnvironment.transform 17 10280 env22565 = env22566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22565 == env22566) = true)

theorem identity22566 : scanCanonicalize (H12AffineFastState.compose env22566 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 37236) := by decide +kernel

theorem selectedBound22566 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env22567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,37236,10280,1025,32769,4160,1229,61601,21763,8328,64,3309,5392,46513,35325,62829,61585,257,42385,17461,1637]

theorem envBound22567 : H12AffineFastState.Bounded env22567 := by
  intro p hp
  have h : env22567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22566_22567 : H12AffineEnvironment.transform 16 37236 env22566 = env22567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37236 env22566 == env22567) = true)

theorem identity22567 : scanCanonicalize (H12AffineFastState.compose env22567 (packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22567 : packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS < 2^1333 := by decide +kernel

def env22568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,30163,12408,10280,1025,8461,4160,1229,20909,21763,8328,64,3309,5392,5309,10481,21601,20893,257,1181,17461,1637]

theorem envBound22568 : H12AffineFastState.Bounded env22568 := by
  intro p hp
  have h : env22568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22567_22568 : H12AffineEnvironment.transform 14 8460 env22567 = env22568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22567 == env22568) = true)

theorem identity22568 : scanCanonicalize (H12AffineFastState.compose env22568 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound22568 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env22569 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,8460,28746,12408,10280,408,8461,4160,340,20909,20634,8328,64,2420,4233,4388,10481,20984,20893,257,260,16812,1020]

theorem envBound22569 : H12AffineFastState.Bounded env22569 := by
  intro p hp
  have h : env22569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22568_22569 : H12AffineEnvironment.transform 9 409 env22568 = env22569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env22568 == env22569) = true)

theorem identity22569 : scanCanonicalize (H12AffineFastState.compose env22569 (packedSelected [3,4,5,9,10,11,14,19,20,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound22569 : packedSelected [3,4,5,9,10,11,14,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env22570 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,4161,8460,8203,12408,10280,408,8461,4160,340,492,219,8328,64,2420,4233,4388,10481,441,476,257,260,4589,1020]

theorem envBound22570 : H12AffineFastState.Bounded env22570 := by
  intro p hp
  have h : env22570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22569_22570 : H12AffineEnvironment.transform 13 4161 env22569 = env22570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env22569 == env22570) = true)

theorem identity22570 : scanCanonicalize (H12AffineFastState.compose env22570 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound22570 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env22571 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8,4161,260,3,4208,2080,408,261,4160,340,492,219,128,64,2420,4233,4388,2297,441,476,257,260,4589,1020]

theorem envBound22571 : H12AffineFastState.Bounded env22571 := by
  intro p hp
  have h : env22571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22570_22571 : H12AffineEnvironment.transform 12 8 env22570 = env22571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22570 == env22571) = true)

theorem identity22571 : scanCanonicalize (H12AffineFastState.compose env22571 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22571 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22572 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4161,260,3,4208,2080,272,261,4160,340,356,83,8,64,2420,4097,4388,2161,305,340,257,260,4453,884]

theorem envBound22572 : H12AffineFastState.Bounded env22572 := by
  intro p hp
  have h : env22572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22571_22572 : H12AffineEnvironment.transform 6 8 env22571 = env22572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22571 == env22572) = true)

theorem identity22572 : scanCanonicalize (H12AffineFastState.compose env22572 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22572 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env22573 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8,4113,260,3,4128,2080,272,261,4112,260,308,3,8,16,2340,4097,4388,2081,305,260,257,260,4405,804]

theorem envBound22573 : H12AffineFastState.Bounded env22573 := by
  intro p hp
  have h : env22573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22572_22573 : H12AffineEnvironment.transform 5 16 env22572 = env22573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22572 == env22573) = true)

theorem identity22573 : scanCanonicalize (H12AffineFastState.compose env22573 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22573 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22574 : List Nat := [2,4,8,16,1,16,8,256,512,273,2048,4096,8,4113,260,3,4097,2049,272,261,4112,260,277,3,8,16,2309,4097,4357,2048,272,260,257,260,4372,773]

theorem envBound22574 : H12AffineFastState.Bounded env22574 := by
  intro p hp
  have h : env22574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22573_22574 : H12AffineEnvironment.transform 4 1 env22573 = env22574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22573 == env22574) = true)

theorem identity22574 : scanCanonicalize (H12AffineFastState.compose env22574 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22575 : List Nat := [2,4,8,16,1,16,8,20,512,5,2048,4096,8,4113,16,3,4097,2049,4,17,4112,16,1,3,8,16,2065,4097,4113,2048,4,16,21,16,4096,529]

theorem envBound22575 : H12AffineFastState.Bounded env22575 := by
  intro p hp
  have h : env22575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22574_22575 : H12AffineEnvironment.transform 7 20 env22574 = env22575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22574 == env22575) = true)

def env22576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4160,169400,156117,21763,8328,64,171417,5392,140485,35324,156697,156132,257,144613,185665,169745]

theorem envBound22576 : H12AffineFastState.Bounded env22576 := by
  intro p hp
  have h : env22576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22565_22576 : H12AffineEnvironment.transform 17 10281 env22565 = env22576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22565 == env22576) = true)

theorem identity22576 : scanCanonicalize (H12AffineFastState.compose env22576 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22576 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env22577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,478,131072,10281,1025,21760,4160,147641,156117,21763,8328,64,149656,5392,140485,23805,156697,156132,257,144613,131136,147984]

theorem envBound22577 : H12AffineFastState.Bounded env22577 := by
  intro p hp
  have h : env22577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22576_22577 : H12AffineEnvironment.transform 14 21761 env22576 = env22577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22576 == env22577) = true)

theorem identity22577 : scanCanonicalize (H12AffineFastState.compose env22577 (packedSelected [0,2,4,5,6,9,11,17,18,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22577 : packedSelected [0,2,4,5,6,9,11,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,478,16401,10281,1025,21760,4160,168,8644,21763,8328,64,2185,5392,25812,23805,9224,8693,257,29940,16465,513]

theorem envBound22578 : H12AffineFastState.Bounded env22578 := by
  intro p hp
  have h : env22578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22577_22578 : H12AffineEnvironment.transform 16 16401 env22577 = env22578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22577 == env22578) = true)

theorem identity22578 : scanCanonicalize (H12AffineFastState.compose env22578 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22578 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,342,16401,10281,1025,21760,4160,32,8524,21763,8192,64,2049,5392,25692,23669,9224,8573,257,29820,16465,513]

theorem envBound22579 : H12AffineFastState.Bounded env22579 := by
  intro p hp
  have h : env22579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22578_22579 : H12AffineEnvironment.transform 6 8 env22578 = env22579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22578 == env22579) = true)

theorem identity22579 : scanCanonicalize (H12AffineFastState.compose env22579 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound22579 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,9292,342,12636,10281,1025,9293,4160,32,8524,9294,8192,64,2049,5392,5393,11576,9224,8573,257,1329,12572,513]

theorem envBound22580 : H12AffineFastState.Bounded env22580 := by
  intro p hp
  have h : env22580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22579_22580 : H12AffineEnvironment.transform 13 12621 env22579 = env22580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env22579 == env22580) = true)

theorem identity22580 : scanCanonicalize (H12AffineFastState.compose env22580 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound22580 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env22581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,10589,9292,342,10572,10281,1025,9293,2128,32,8524,9294,8192,64,2049,3328,3329,11576,9224,8573,257,1329,10508,513]

theorem envBound22581 : H12AffineFastState.Bounded env22581 := by
  intro p hp
  have h : env22581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22580_22581 : H12AffineEnvironment.transform 11 2064 env22580 = env22581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env22580 == env22581) = true)

theorem identity22581 : scanCanonicalize (H12AffineFastState.compose env22581 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22581 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env22582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,349,2048,1297,342,2065,2420,1025,1296,2128,32,17,1299,349,64,2049,3328,3329,3173,1365,32,257,1329,2129,513]

theorem envBound22582 : H12AffineFastState.Bounded env22582 := by
  intro p hp
  have h : env22582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22581_22582 : H12AffineEnvironment.transform 12 349 env22581 = env22582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22581 == env22582) = true)

theorem identity22582 : scanCanonicalize (H12AffineFastState.compose env22582 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound22582 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,609,625,349,609,1297,342,624,789,1025,1296,561,32,17,1299,349,64,608,1889,1888,1540,1365,32,257,1329,560,513]

theorem envBound22583 : H12AffineFastState.Bounded env22583 := by
  intro p hp
  have h : env22583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22582_22583 : H12AffineEnvironment.transform 10 609 env22582 = env22583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env22582 == env22583) = true)

theorem identity22583 : scanCanonicalize (H12AffineFastState.compose env22583 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 628) := by decide +kernel

theorem selectedBound22583 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env22584 : List Nat := [2,4,8,16,32,64,8,256,512,628,609,625,349,609,869,342,624,789,629,868,561,32,17,871,349,64,608,277,276,112,801,32,257,837,560,513]

theorem envBound22584 : H12AffineFastState.Bounded env22584 := by
  intro p hp
  have h : env22584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22583_22584 : H12AffineEnvironment.transform 9 628 env22583 = env22584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 628 env22583 == env22584) = true)

theorem identity22584 : scanCanonicalize (H12AffineFastState.compose env22584 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound22584 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env22585 : List Nat := [2,4,8,16,32,64,8,256,276,352,373,357,349,373,113,342,356,1,353,112,293,32,17,115,349,64,372,277,276,112,53,32,257,81,292,277]

theorem envBound22585 : H12AffineFastState.Bounded env22585 := by
  intro p hp
  have h : env22585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22584_22585 : H12AffineEnvironment.transform 8 276 env22584 = env22585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env22584 == env22585) = true)

theorem identity22585 : scanCanonicalize (H12AffineFastState.compose env22585 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound22585 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22586 : List Nat := [2,4,8,16,32,64,8,46,58,78,91,75,115,91,113,120,74,1,79,112,11,32,17,115,115,64,90,59,58,112,53,32,47,81,10,59]

theorem envBound22586 : H12AffineFastState.Bounded env22586 := by
  intro p hp
  have h : env22586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22585_22586 : H12AffineEnvironment.transform 7 46 env22585 = env22586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env22585 == env22586) = true)

theorem identity22586 : scanCanonicalize (H12AffineFastState.compose env22586 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22586 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env22587 : List Nat := [2,4,8,16,0,64,8,14,26,78,91,75,83,91,81,88,74,1,79,80,11,0,17,83,83,64,90,27,26,80,21,0,15,81,10,27]

theorem envBound22587 : H12AffineFastState.Bounded env22587 := by
  intro p hp
  have h : env22587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22586_22587 : H12AffineEnvironment.transform 4 0 env22586 = env22587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22586 == env22587) = true)

theorem identity22587 : scanCanonicalize (H12AffineFastState.compose env22587 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22587 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22588 : List Nat := [2,4,8,0,0,64,8,14,10,78,75,75,67,75,65,72,74,1,79,64,11,0,1,67,67,64,74,11,10,64,5,0,15,65,10,11]

theorem envBound22588 : H12AffineFastState.Bounded env22588 := by
  intro p hp
  have h : env22588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22587_22588 : H12AffineEnvironment.transform 3 0 env22587 = env22588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22587 == env22588) = true)

theorem identity22588 : scanCanonicalize (H12AffineFastState.compose env22588 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound22588 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env22589 : List Nat := [2,4,8,0,0,1,8,14,10,15,10,10,2,10,0,9,11,1,14,1,11,0,1,2,2,1,11,11,10,1,5,0,15,0,10,11]

theorem envBound22589 : H12AffineFastState.Bounded env22589 := by
  intro p hp
  have h : env22589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22588_22589 : H12AffineEnvironment.transform 5 1 env22588 = env22589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env22588 == env22589) = true)

theorem identity22589 : scanCanonicalize (H12AffineFastState.compose env22589 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22589 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22590 : List Nat := [2,4,3,0,0,1,3,5,1,4,1,1,2,1,0,2,0,1,5,1,0,0,1,2,2,1,0,0,1,1,5,0,4,0,1,0]

theorem envBound22590 : H12AffineFastState.Bounded env22590 := by
  intro p hp
  have h : env22590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22589_22590 : H12AffineEnvironment.transform 2 3 env22589 = env22590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22589 == env22590) = true)

def env22591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,21762,8328,64,215366,115151,140484,303573,241863,498963,257,254010,197022,169744]

theorem envBound22591 : H12AffineFastState.Bounded env22591 := by
  intro p hp
  have h : env22591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22563_22591 : H12AffineEnvironment.transform 20 4161 env22563 = env22591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22563 == env22591) = true)

theorem identity22591 : scanCanonicalize (H12AffineFastState.compose env22591 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound22591 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4161,392287,73754,21762,8328,64,2185,115151,91403,303573,61704,318684,257,41461,16465,120543]

theorem envBound22592 : H12AffineFastState.Bounded env22592 := by
  intro p hp
  have h : env22592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22591_22592 : H12AffineEnvironment.transform 16 82383 env22591 = env22592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env22591 == env22592) = true)

def env22593 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,4113,392207,73754,21762,8328,16,2185,115103,91403,303493,61704,318604,257,41381,16385,120463]

theorem envBound22593 : H12AffineFastState.Bounded env22593 := by
  intro p hp
  have h : env22593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22592_22593 : H12AffineEnvironment.transform 5 16 env22592 = env22593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22592 == env22593) = true)

theorem identity22593 : scanCanonicalize (H12AffineFastState.compose env22593 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound22593 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env22594 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,2341,1025,32769,4113,128298,73754,21762,8328,16,2185,115103,91403,43168,61704,54697,257,41381,16385,120463]

theorem envBound22594 : H12AffineFastState.Bounded env22594 := by
  intro p hp
  have h : env22594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22593_22594 : H12AffineEnvironment.transform 17 2341 env22593 = env22594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env22593 == env22594) = true)

theorem identity22594 : scanCanonicalize (H12AffineFastState.compose env22594 (packedSelected [3,4,7,9,10,16,17,19,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound22594 : packedSelected [3,4,7,9,10,16,17,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env22595 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,65536,82335,2341,1025,8581,4113,87214,73754,21762,8328,16,2185,90139,91403,2340,20620,29741,257,33,16385,96011]

theorem envBound22595 : H12AffineFastState.Bounded env22595 := by
  intro p hp
  have h : env22595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22594_22595 : H12AffineEnvironment.transform 14 8580 env22594 = env22595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env22594 == env22595) = true)

theorem identity22595 : scanCanonicalize (H12AffineFastState.compose env22595 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound22595 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env22596 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,21647,5392,2341,1025,8581,4113,33,29845,21762,8328,16,2185,13460,12676,2340,20620,29741,257,33,16385,9092]

theorem envBound22596 : H12AffineFastState.Bounded env22596 := by
  intro p hp
  have h : env22596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22595_22596 : H12AffineEnvironment.transform 15 21647 env22595 = env22596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env22595 == env22596) = true)

theorem identity22596 : scanCanonicalize (H12AffineFastState.compose env22596 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22596 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env22597 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,21510,5392,2341,1025,8460,4113,33,29724,21762,8193,16,2048,13341,12557,2340,20485,29741,257,33,16385,8973]

theorem envBound22597 : H12AffineFastState.Bounded env22597 := by
  intro p hp
  have h : env22597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22596_22597 : H12AffineEnvironment.transform 6 9 env22596 = env22597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22596 == env22597) = true)

theorem identity22597 : scanCanonicalize (H12AffineFastState.compose env22597 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22597 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22598 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,21510,5392,2341,1025,1,4113,33,21777,21762,268,16,2048,5392,4096,2340,20485,21792,257,33,16385,512]

theorem envBound22598 : H12AffineFastState.Bounded env22598 := by
  intro p hp
  have h : env22598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22597_22598 : H12AffineEnvironment.transform 12 269 env22597 = env22598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22597 == env22598) = true)

theorem identity22598 : scanCanonicalize (H12AffineFastState.compose env22598 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22598 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22599 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,0,21510,5392,2308,1025,1,4113,0,21777,21762,268,16,2048,5392,4096,2309,20485,21761,257,0,16385,512]

theorem envBound22599 : H12AffineFastState.Bounded env22599 := by
  intro p hp
  have h : env22599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22598_22599 : H12AffineEnvironment.transform 4 1 env22598 = env22599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22598 == env22599) = true)

theorem identity22599 : scanCanonicalize (H12AffineFastState.compose env22599 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound22599 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env22600 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,3329,269,16384,0,18695,2065,2308,1025,1,3344,0,18448,18435,268,16,2048,2065,3329,2309,19716,18432,257,0,16385,512]

theorem envBound22600 : H12AffineFastState.Bounded env22600 := by
  intro p hp
  have h : env22600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22599_22600 : H12AffineEnvironment.transform 11 3329 env22599 = env22600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env22599 == env22600) = true)

theorem identity22600 : scanCanonicalize (H12AffineFastState.compose env22600 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound22600 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env22601 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,3329,269,2049,0,262,2065,2308,1025,1,3344,0,17,2,268,16,2048,2065,3329,2309,1285,1,257,0,2048,512]

theorem envBound22601 : H12AffineFastState.Bounded env22601 := by
  intro p hp
  have h : env22601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22600_22601 : H12AffineEnvironment.transform 13 2049 env22600 = env22601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env22600 == env22601) = true)

theorem identity22601 : scanCanonicalize (H12AffineFastState.compose env22601 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound22601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22602 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1045,276,269,1044,0,262,1028,1297,1025,1,261,0,17,2,268,16,1045,1028,276,1296,1285,1,257,0,1045,512]

theorem envBound22602 : H12AffineFastState.Bounded env22602 := by
  intro p hp
  have h : env22602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22601_22602 : H12AffineEnvironment.transform 10 1045 env22601 = env22602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env22601 == env22602) = true)

theorem identity22602 : scanCanonicalize (H12AffineFastState.compose env22602 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22602 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22603 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1045,16,9,1044,0,2,1028,1045,1025,1,1,0,17,2,8,16,1045,1028,16,1044,1025,1,5,0,1045,512]

theorem envBound22603 : H12AffineFastState.Bounded env22603 := by
  intro p hp
  have h : env22603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22602_22603 : H12AffineEnvironment.transform 7 4 env22602 = env22603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22602 == env22603) = true)

theorem identity22603 : scanCanonicalize (H12AffineFastState.compose env22603 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22604 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1045,16,9,1044,0,2,1028,1045,1025,1,1,0,17,2,8,16,1045,1028,16,1044,1025,1,5,0,1045,0]

theorem envBound22604 : H12AffineFastState.Bounded env22604 := by
  intro p hp
  have h : env22604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22603_22604 : H12AffineEnvironment.transform 8 0 env22603 = env22604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22603 == env22604) = true)

theorem identity22604 : scanCanonicalize (H12AffineFastState.compose env22604 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22604 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env22605 : List Nat := [2,4,8,16,1,16,9,4,0,21,0,16,9,1,0,2,17,0,20,1,1,0,17,2,8,16,0,17,16,1,20,1,5,0,0,0]

theorem envBound22605 : H12AffineFastState.Bounded env22605 := by
  intro p hp
  have h : env22605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22604_22605 : H12AffineEnvironment.transform 9 21 env22604 = env22605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22604 == env22605) = true)

theorem identity22605 : scanCanonicalize (H12AffineFastState.compose env22605 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound22605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22606 : List Nat := [2,4,8,15,1,15,9,4,0,10,0,15,9,1,0,2,14,0,11,1,1,0,14,2,8,15,0,14,15,1,11,1,5,0,0,0]

theorem envBound22606 : H12AffineFastState.Bounded env22606 := by
  intro p hp
  have h : env22606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22605_22606 : H12AffineEnvironment.transform 3 15 env22605 = env22606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env22605 == env22606) = true)

def env22607 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,4112,392206,73754,21762,8328,17,2185,115102,91403,303492,61704,318605,257,41380,16384,120462]

theorem envBound22607 : H12AffineFastState.Bounded env22607 := by
  intro p hp
  have h : env22607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22592_22607 : H12AffineEnvironment.transform 5 17 env22592 = env22607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22592 == env22607) = true)

theorem identity22607 : scanCanonicalize (H12AffineFastState.compose env22607 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22607 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env22608 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,65536,82334,262144,1025,1,4112,359438,73754,21762,8328,17,2185,82334,91403,270724,28936,285837,257,8612,16384,87694]

theorem envBound22608 : H12AffineFastState.Bounded env22608 := by
  intro p hp
  have h : env22608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22607_22608 : H12AffineEnvironment.transform 14 0 env22607 = env22608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22607 == env22608) = true)

theorem identity22608 : scanCanonicalize (H12AffineFastState.compose env22608 (packedSelected [0,1,3,5,8,9,16,18,20,22,23,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound22608 : packedSelected [0,1,3,5,8,9,16,18,20,22,23,26,27,31] rootPS < 2^1333 := by decide +kernel

def env22609 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,65536,82334,97327,1025,1,4112,33,73754,21762,8328,17,2185,82334,91403,89515,28936,73890,257,8612,16384,87694]

theorem envBound22609 : H12AffineFastState.Bounded env22609 := by
  intro p hp
  have h : env22609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22608_22609 : H12AffineEnvironment.transform 17 97327 env22608 = env22609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env22608 == env22609) = true)

theorem identity22609 : scanCanonicalize (H12AffineFastState.compose env22609 (packedSelected [0,1,4,7,8,9,10,12,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound22609 : packedSelected [0,1,4,7,8,9,10,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env22610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,0,65536,82334,89515,1025,1,4112,33,65950,21762,268,17,2185,82334,83087,89515,20620,65830,257,32,16384,87694]

theorem envBound22610 : H12AffineFastState.Bounded env22610 := by
  intro p hp
  have h : env22610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22609_22610 : H12AffineEnvironment.transform 12 388 env22609 = env22610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env22609 == env22610) = true)

theorem identity22610 : scanCanonicalize (H12AffineFastState.compose env22610 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound22610 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env22611 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,0,21646,5392,2341,1025,1,4112,33,21776,21762,268,17,2185,5392,4097,2341,20620,21928,257,32,16384,512]

theorem envBound22611 : H12AffineFastState.Bounded env22611 := by
  intro p hp
  have h : env22611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22610_22611 : H12AffineEnvironment.transform 15 21646 env22610 = env22611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env22610 == env22611) = true)

theorem identity22611 : scanCanonicalize (H12AffineFastState.compose env22611 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound22611 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22612 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5156,0,170,5392,2341,1025,1,4112,33,308,294,268,17,2185,5392,4097,2341,1192,396,257,32,5156,512]

theorem envBound22612 : H12AffineFastState.Bounded env22612 := by
  intro p hp
  have h : env22612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22611_22612 : H12AffineEnvironment.transform 13 5156 env22611 = env22612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env22611 == env22612) = true)

theorem identity22612 : scanCanonicalize (H12AffineFastState.compose env22612 (packedSelected [0,1,2,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 418) := by decide +kernel

theorem selectedBound22612 : packedSelected [0,1,2,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22613 : List Nat := [2,4,8,16,32,17,128,256,512,418,2048,4096,388,4486,0,170,4274,2341,419,1,4112,33,308,294,268,17,2185,4274,4097,2341,266,396,257,32,4486,512]

theorem envBound22613 : H12AffineFastState.Bounded env22613 := by
  intro p hp
  have h : env22613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22612_22613 : H12AffineEnvironment.transform 9 418 env22612 = env22613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 418 env22612 == env22613) = true)

theorem identity22613 : scanCanonicalize (H12AffineFastState.compose env22613 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22613 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env22614 : List Nat := [2,4,8,16,32,17,9,256,512,299,2048,4096,269,4367,0,35,4155,2341,298,1,4112,33,308,294,268,17,2048,4155,4097,2341,266,261,257,32,4367,512]

theorem envBound22614 : H12AffineFastState.Bounded env22614 := by
  intro p hp
  have h : env22614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22613_22614 : H12AffineEnvironment.transform 6 9 env22613 = env22614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22613 == env22614) = true)

theorem identity22614 : scanCanonicalize (H12AffineFastState.compose env22614 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22614 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22615 : List Nat := [2,4,8,16,32,17,9,5,512,46,2048,4096,8,4106,0,35,4155,2080,47,1,4112,33,49,35,9,17,2048,4155,4097,2080,15,0,4,32,4106,512]

theorem envBound22615 : H12AffineFastState.Bounded env22615 := by
  intro p hp
  have h : env22615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22614_22615 : H12AffineEnvironment.transform 7 5 env22614 = env22615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22614 == env22615) = true)

theorem identity22615 : scanCanonicalize (H12AffineFastState.compose env22615 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound22615 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env22616 : List Nat := [2,4,8,16,32,17,9,5,512,46,2048,2064,8,2074,0,35,2091,2080,47,1,2048,33,49,35,9,17,2048,2091,2065,2080,15,0,4,32,2074,512]

theorem envBound22616 : H12AffineFastState.Bounded env22616 := by
  intro p hp
  have h : env22616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22615_22616 : H12AffineEnvironment.transform 11 2064 env22615 = env22616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env22615 == env22616) = true)

theorem identity22616 : scanCanonicalize (H12AffineFastState.compose env22616 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound22616 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env22617 : List Nat := [2,4,8,16,32,17,9,5,512,46,11,27,8,17,0,35,32,43,47,1,11,33,49,35,9,17,11,32,26,43,15,0,4,32,17,512]

theorem envBound22617 : H12AffineFastState.Bounded env22617 := by
  intro p hp
  have h : env22617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22616_22617 : H12AffineEnvironment.transform 10 11 env22616 = env22617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env22616 == env22617) = true)

theorem identity22617 : scanCanonicalize (H12AffineFastState.compose env22617 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound22617 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env22618 : List Nat := [2,4,8,10,32,11,9,5,512,46,11,1,8,11,0,35,32,43,47,1,11,33,43,35,9,11,11,32,0,43,15,0,4,32,11,512]

theorem envBound22618 : H12AffineFastState.Bounded env22618 := by
  intro p hp
  have h : env22618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22617_22618 : H12AffineEnvironment.transform 3 10 env22617 = env22618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env22617 == env22618) = true)

theorem identity22618 : scanCanonicalize (H12AffineFastState.compose env22618 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound22618 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22619 : List Nat := [2,4,8,10,32,11,9,5,35,46,11,1,8,11,0,35,32,43,47,1,11,33,43,35,9,11,11,32,0,43,15,0,4,32,11,35]

theorem envBound22619 : H12AffineFastState.Bounded env22619 := by
  intro p hp
  have h : env22619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22618_22619 : H12AffineEnvironment.transform 8 35 env22618 = env22619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env22618 == env22619) = true)

theorem identity22619 : scanCanonicalize (H12AffineFastState.compose env22619 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound22619 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env22620 : List Nat := [2,4,8,10,13,11,9,5,14,3,11,1,8,11,0,14,13,6,2,1,11,12,6,14,9,11,11,13,0,6,15,0,4,13,11,14]

theorem envBound22620 : H12AffineFastState.Bounded env22620 := by
  intro p hp
  have h : env22620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22619_22620 : H12AffineEnvironment.transform 4 13 env22619 = env22620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env22619 == env22620) = true)

theorem identity22620 : scanCanonicalize (H12AffineFastState.compose env22620 (packedSelected [0,1,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound22620 : packedSelected [0,1,10] rootPS < 2^1333 := by decide +kernel

def env22621 : List Nat := [2,4,4,6,1,7,5,5,2,3,7,1,4,7,0,2,1,6,2,1,7,0,6,2,5,7,7,1,0,6,3,0,4,1,7,2]

theorem envBound22621 : H12AffineFastState.Bounded env22621 := by
  intro p hp
  have h : env22621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22620_22621 : H12AffineEnvironment.transform 2 4 env22620 = env22621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env22620 == env22621) = true)

theorem identity22621 : scanCanonicalize (H12AffineFastState.compose env22621 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22622 : List Nat := [1,4,4,5,1,4,5,5,1,0,4,1,4,4,0,1,1,5,1,1,4,0,5,1,5,4,4,1,0,5,0,0,4,1,4,1]

theorem envBound22622 : H12AffineFastState.Bounded env22622 := by
  intro p hp
  have h : env22622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22621_22622 : H12AffineEnvironment.transform 0 1 env22621 = env22622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22621 == env22622) = true)

def env22623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound22623 : H12AffineFastState.Bounded env22623 := by
  intro p hp
  have h : env22623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22190_22623 : H12AffineEnvironment.transform 26 30393345 env22190 = env22623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env22190 == env22623) = true)

def env22624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound22624 : H12AffineFastState.Bounded env22624 := by
  intro p hp
  have h : env22624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22623_22624 : H12AffineEnvironment.transform 18 1024 env22623 = env22624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22623 == env22624) = true)

theorem identity22624 : scanCanonicalize (H12AffineFastState.compose env22624 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41431) := by decide +kernel

theorem selectedBound22624 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41431,8328,64,13066710,2172250,10507600,8830976,8463815,6407190,256,10577275,10585311,8389137]

theorem envBound22625 : H12AffineFastState.Bounded env22625 := by
  intro p hp
  have h : env22625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22624_22625 : H12AffineEnvironment.transform 23 41431 env22624 = env22625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41431 env22624 == env22625) = true)

def env22626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,8388608,41431,8328,64,13066710,115150,8434116,8830976,8463815,4268162,256,8487407,8478795,8389137]

theorem envBound22626 : H12AffineFastState.Bounded env22626 := by
  intro p hp
  have h : env22626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22625_22626 : H12AffineEnvironment.transform 20 58516 env22625 = env22626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env22625 == env22626) = true)

def env22627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,16,41431,8328,64,4678086,115150,45524,442384,75223,4268162,256,98815,90203,513]

theorem envBound22627 : H12AffineFastState.Bounded env22627 := by
  intro p hp
  have h : env22627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22626_22627 : H12AffineEnvironment.transform 22 16 env22626 = env22627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22626 == env22627) = true)

theorem identity22627 : scanCanonicalize (H12AffineFastState.compose env22627 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22627 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58516,4194304,16,41431,8328,64,4604364,57796,45524,442384,1501,4194440,256,41461,16465,513]

theorem envBound22628 : H12AffineFastState.Bounded env22628 := by
  intro p hp
  have h : env22628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22627_22628 : H12AffineEnvironment.transform 15 8202 env22627 = env22628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22627 == env22628) = true)

theorem identity22628 : scanCanonicalize (H12AffineFastState.compose env22628 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound22628 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env22629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58516,419913,16,41431,8328,64,10629,57796,45524,442384,1501,420033,256,41461,16465,513]

theorem envBound22629 : H12AffineFastState.Bounded env22629 := by
  intro p hp
  have h : env22629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22628_22629 : H12AffineEnvironment.transform 21 419913 env22628 = env22629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env22628 == env22629) = true)

def env22630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419913,16,41311,8192,64,10509,57676,45404,442384,1365,419913,256,41341,16465,513]

theorem envBound22630 : H12AffineFastState.Bounded env22630 := by
  intro p hp
  have h : env22630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22629_22630 : H12AffineEnvironment.transform 6 8 env22629 = env22630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22629 == env22630) = true)

theorem identity22630 : scanCanonicalize (H12AffineFastState.compose env22630 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22630 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,262144,1024,8540,17729,419913,16,2,8192,64,10509,16401,4097,418125,1365,419913,256,32,16465,513]

theorem envBound22631 : H12AffineFastState.Bounded env22631 := by
  intro p hp
  have h : env22631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22630_22631 : H12AffineEnvironment.transform 14 8541 env22630 = env22631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22630 == env22631) = true)

theorem identity22631 : scanCanonicalize (H12AffineFastState.compose env22631 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,10281,1024,8540,17729,147552,16,2,8192,64,10509,16401,4097,149860,1365,147552,256,32,16465,513]

theorem envBound22632 : H12AffineFastState.Bounded env22632 := by
  intro p hp
  have h : env22632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22631_22632 : H12AffineEnvironment.transform 17 10281 env22631 = env22632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22631 == env22632) = true)

theorem identity22632 : scanCanonicalize (H12AffineFastState.compose env22632 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 8477) := by decide +kernel

theorem selectedBound22632 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,8477,10281,1024,8540,17729,24957,16,2,8192,64,10509,16401,4097,26745,1365,24957,256,32,16465,513]

theorem envBound22633 : H12AffineFastState.Bounded env22633 := by
  intro p hp
  have h : env22633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22632_22633 : H12AffineEnvironment.transform 16 8477 env22632 = env22633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8477 env22632 == env22633) = true)

theorem identity22633 : scanCanonicalize (H12AffineFastState.compose env22633 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound22633 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,8192,16384,8541,8202,8477,8461,1024,8540,17729,24957,16,2,8192,64,8233,16401,4097,24925,1365,24957,256,32,16465,513]

theorem envBound22634 : H12AffineFastState.Bounded env22634 := by
  intro p hp
  have h : env22634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22633_22634 : H12AffineEnvironment.transform 10 292 env22633 = env22634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env22633 == env22634) = true)

theorem identity22634 : scanCanonicalize (H12AffineFastState.compose env22634 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound22634 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env22635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,8192,16384,8541,8202,8477,8461,1024,8540,17729,24957,16,2,8192,64,8233,16401,1281,24925,1365,24957,256,32,16465,513]

theorem envBound22635 : H12AffineFastState.Bounded env22635 := by
  intro p hp
  have h : env22635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22634_22635 : H12AffineEnvironment.transform 11 1280 env22634 = env22635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env22634 == env22635) = true)

theorem identity22635 : scanCanonicalize (H12AffineFastState.compose env22635 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22635 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,8192,1296,8541,8202,8477,8461,1024,8540,81,9325,16,2,8192,64,8233,1281,1281,9293,1365,9325,256,32,1345,513]

theorem envBound22636 : H12AffineFastState.Bounded env22636 := by
  intro p hp
  have h : env22636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22635_22636 : H12AffineEnvironment.transform 13 1296 env22635 = env22636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env22635 == env22636) = true)

theorem identity22636 : scanCanonicalize (H12AffineFastState.compose env22636 (packedSelected [9,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound22636 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env22637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,1053,1296,1344,1047,1280,1296,1024,1345,81,112,16,2,1053,64,1076,1281,1281,80,1365,112,256,32,1345,513]

theorem envBound22637 : H12AffineFastState.Bounded env22637 := by
  intro p hp
  have h : env22637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22636_22637 : H12AffineEnvironment.transform 12 1053 env22636 = env22637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env22636 == env22637) = true)

theorem identity22637 : scanCanonicalize (H12AffineFastState.compose env22637 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22638 : List Nat := [2,4,8,16,32,64,8,256,512,52,292,308,41,292,372,35,308,292,52,373,81,112,16,2,41,64,0,309,309,80,353,112,256,32,373,513]

theorem envBound22638 : H12AffineFastState.Bounded env22638 := by
  intro p hp
  have h : env22638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22637_22638 : H12AffineEnvironment.transform 9 52 env22637 = env22638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22637 == env22638) = true)

theorem identity22638 : scanCanonicalize (H12AffineFastState.compose env22638 (packedSelected [5,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22638 : packedSelected [5,7] rootPS < 2^1333 := by decide +kernel

def env22639 : List Nat := [2,4,8,16,32,64,8,20,512,52,48,32,41,48,96,35,32,48,52,97,81,112,16,2,41,64,0,33,33,80,117,112,20,32,97,513]

theorem envBound22639 : H12AffineFastState.Bounded env22639 := by
  intro p hp
  have h : env22639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22638_22639 : H12AffineEnvironment.transform 7 20 env22638 = env22639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22638 == env22639) = true)

theorem identity22639 : scanCanonicalize (H12AffineFastState.compose env22639 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound22639 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env22640 : List Nat := [2,4,8,16,32,33,8,20,512,52,48,32,41,48,1,35,32,48,52,0,48,17,16,2,41,33,0,33,33,49,20,17,20,32,0,513]

theorem envBound22640 : H12AffineFastState.Bounded env22640 := by
  intro p hp
  have h : env22640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22639_22640 : H12AffineEnvironment.transform 5 33 env22639 = env22640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env22639 == env22640) = true)

theorem identity22640 : scanCanonicalize (H12AffineFastState.compose env22640 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound22640 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env22641 : List Nat := [2,4,8,16,32,33,8,20,48,52,48,32,41,48,1,35,32,48,52,0,48,17,16,2,41,33,0,33,33,49,20,17,20,32,0,49]

theorem envBound22641 : H12AffineFastState.Bounded env22641 := by
  intro p hp
  have h : env22641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22640_22641 : H12AffineEnvironment.transform 8 48 env22640 = env22641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env22640 == env22641) = true)

theorem identity22641 : scanCanonicalize (H12AffineFastState.compose env22641 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22642 : List Nat := [2,4,8,16,17,16,8,20,1,5,1,17,24,1,1,18,17,1,5,0,1,17,16,2,24,16,0,16,16,0,20,17,20,17,0,0]

theorem envBound22642 : H12AffineFastState.Bounded env22642 := by
  intro p hp
  have h : env22642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22641_22642 : H12AffineEnvironment.transform 4 17 env22641 = env22642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22641 == env22642) = true)

def env22643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419913,16,41310,8193,64,10508,57677,45405,442384,1364,419912,256,41340,16465,513]

theorem envBound22643 : H12AffineFastState.Bounded env22643 := by
  intro p hp
  have h : env22643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22629_22643 : H12AffineEnvironment.transform 6 9 env22629 = env22643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22629 == env22643) = true)

def env22644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58397,272393,16,41310,8193,64,10508,57677,45405,294992,1364,272392,256,41340,16465,513]

theorem envBound22644 : H12AffineFastState.Bounded env22644 := by
  intro p hp
  have h : env22644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22643_22644 : H12AffineEnvironment.transform 16 16448 env22643 = env22644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env22643 == env22644) = true)

theorem identity22644 : scanCanonicalize (H12AffineFastState.compose env22644 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound22644 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,35108,1024,32769,58397,41261,16,41310,8193,64,10508,57677,45405,2420,1364,41260,256,41340,16465,513]

theorem envBound22645 : H12AffineFastState.Bounded env22645 := by
  intro p hp
  have h : env22645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22644_22645 : H12AffineEnvironment.transform 17 35108 env22644 = env22645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env22644 == env22645) = true)

theorem identity22645 : scanCanonicalize (H12AffineFastState.compose env22645 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22645 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env22646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16448,35108,1024,32769,50496,32880,16,32771,348,64,2129,49168,36864,2420,1364,32881,256,32801,16465,513]

theorem envBound22646 : H12AffineFastState.Bounded env22646 := by
  intro p hp
  have h : env22646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22645_22646 : H12AffineEnvironment.transform 12 349 env22645 = env22646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22645 == env22646) = true)

theorem identity22646 : scanCanonicalize (H12AffineFastState.compose env22646 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound22646 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,80,343,16448,2420,1024,81,17680,32,16,83,348,64,2129,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound22647 : H12AffineFastState.Bounded env22647 := by
  intro p hp
  have h : env22647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22646_22647 : H12AffineEnvironment.transform 14 80 env22646 = env22647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env22646 == env22647) = true)

theorem identity22647 : scanCanonicalize (H12AffineFastState.compose env22647 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22647 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22648 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,263,16400,2340,1024,1,17680,32,16,3,268,16,2049,16400,4096,2340,1284,33,256,33,16385,513]

theorem envBound22648 : H12AffineFastState.Bounded env22648 := by
  intro p hp
  have h : env22648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22647_22648 : H12AffineEnvironment.transform 5 16 env22647 = env22648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22647 == env22648) = true)

theorem identity22648 : scanCanonicalize (H12AffineFastState.compose env22648 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22649 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,0,263,16400,2309,1024,1,17680,1,16,3,268,16,2049,16400,4096,2309,1284,0,256,0,16385,513]

theorem envBound22649 : H12AffineFastState.Bounded env22649 := by
  intro p hp
  have h : env22649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22648_22649 : H12AffineEnvironment.transform 4 1 env22648 = env22649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22648 == env22649) = true)

theorem identity22649 : scanCanonicalize (H12AffineFastState.compose env22649 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22650 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,16,269,16384,0,263,16400,2309,1024,1,17680,1,16,3,268,16,2049,16400,16,2309,1284,0,256,0,16385,513]

theorem envBound22650 : H12AffineFastState.Bounded env22650 := by
  intro p hp
  have h : env22650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22649_22650 : H12AffineEnvironment.transform 11 16 env22649 = env22650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22649 == env22650) = true)

theorem identity22650 : scanCanonicalize (H12AffineFastState.compose env22650 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound22650 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22651 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,16,269,1809,0,263,1793,2309,1024,1,513,1,16,3,268,16,2049,1793,16,2309,1284,0,256,0,1808,513]

theorem envBound22651 : H12AffineFastState.Bounded env22651 := by
  intro p hp
  have h : env22651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22650_22651 : H12AffineEnvironment.transform 13 1809 env22650 = env22651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env22650 == env22651) = true)

theorem identity22651 : scanCanonicalize (H12AffineFastState.compose env22651 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound22651 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22652 : List Nat := [2,4,8,16,1,16,9,256,512,1024,529,16,269,1809,0,263,1793,788,1024,1,513,1,16,3,268,16,528,1793,16,788,1284,0,256,0,1808,513]

theorem envBound22652 : H12AffineFastState.Bounded env22652 := by
  intro p hp
  have h : env22652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22651_22652 : H12AffineEnvironment.transform 10 529 env22651 = env22652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env22651 == env22652) = true)

theorem identity22652 : scanCanonicalize (H12AffineFastState.compose env22652 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound22652 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22653 : List Nat := [2,4,8,16,1,16,9,256,512,256,529,16,269,529,0,263,513,788,256,1,513,1,16,3,268,16,528,513,16,788,4,0,256,0,528,513]

theorem envBound22653 : H12AffineFastState.Bounded env22653 := by
  intro p hp
  have h : env22653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22652_22653 : H12AffineEnvironment.transform 9 256 env22652 = env22653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env22652 == env22653) = true)

theorem identity22653 : scanCanonicalize (H12AffineFastState.compose env22653 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound22653 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22654 : List Nat := [2,4,8,16,1,16,9,256,260,256,277,16,269,277,0,263,261,16,256,1,261,1,16,3,268,16,276,261,16,16,4,0,256,0,276,261]

theorem envBound22654 : H12AffineFastState.Bounded env22654 := by
  intro p hp
  have h : env22654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22653_22654 : H12AffineEnvironment.transform 8 260 env22653 = env22654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22653 == env22654) = true)

def env22655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58397,272392,16,41310,8193,64,10508,57677,45405,294993,1364,272393,256,41340,16465,513]

theorem envBound22655 : H12AffineFastState.Bounded env22655 := by
  intro p hp
  have h : env22655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22643_22655 : H12AffineEnvironment.transform 16 16449 env22643 = env22655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env22643 == env22655) = true)

theorem identity22655 : scanCanonicalize (H12AffineFastState.compose env22655 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22655 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,43048,1024,32769,58397,32800,16,41310,8193,64,10508,57677,45405,10361,1364,32801,256,41340,16465,513]

theorem envBound22656 : H12AffineFastState.Bounded env22656 := by
  intro p hp
  have h : env22656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22655_22656 : H12AffineEnvironment.transform 17 43048 env22655 = env22656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22655 == env22656) = true)

theorem identity22656 : scanCanonicalize (H12AffineFastState.compose env22656 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22656 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env22657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16449,10281,1024,0,25628,33,16,8543,8193,64,10508,24908,12636,10361,1364,32,256,8573,16465,513]

theorem envBound22657 : H12AffineFastState.Bounded env22657 := by
  intro p hp
  have h : env22657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22656_22657 : H12AffineEnvironment.transform 14 1 env22656 = env22657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22656 == env22657) = true)

theorem identity22657 : scanCanonicalize (H12AffineFastState.compose env22657 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22658 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,16401,10281,1024,0,25628,33,16,8463,8193,16,10508,24860,12556,10281,1284,32,256,8493,16385,513]

theorem envBound22658 : H12AffineFastState.Bounded env22658 := by
  intro p hp
  have h : env22658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22657_22658 : H12AffineEnvironment.transform 5 16 env22657 = env22658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22657 == env22658) = true)

theorem identity22658 : scanCanonicalize (H12AffineFastState.compose env22658 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11271) := by decide +kernel

theorem selectedBound22658 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env22659 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,11271,1,8202,11286,10281,1024,0,2075,33,16,8463,8193,16,10508,3355,12556,10281,1284,32,256,8493,11270,513]

theorem envBound22659 : H12AffineFastState.Bounded env22659 := by
  intro p hp
  have h : env22659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22658_22659 : H12AffineEnvironment.transform 13 11271 env22658 = env22659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11271 env22658 == env22659) = true)

theorem identity22659 : scanCanonicalize (H12AffineFastState.compose env22659 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound22659 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22660 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2090,8192,11271,1,8202,11286,10281,1024,0,2075,33,16,8463,8193,16,10508,3355,10534,10281,1284,32,256,8493,11270,513]

theorem envBound22660 : H12AffineFastState.Bounded env22660 := by
  intro p hp
  have h : env22660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22659_22660 : H12AffineEnvironment.transform 11 2090 env22659 = env22660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env22659 == env22660) = true)

theorem identity22660 : scanCanonicalize (H12AffineFastState.compose env22660 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22660 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22661 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2090,268,3339,1,262,3354,2341,1024,0,2075,33,16,3,269,16,2048,3355,2090,2341,1284,32,256,33,3338,513]

theorem envBound22661 : H12AffineFastState.Bounded env22661 := by
  intro p hp
  have h : env22661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22660_22661 : H12AffineEnvironment.transform 12 268 env22660 = env22661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22660 == env22661) = true)

theorem identity22661 : scanCanonicalize (H12AffineFastState.compose env22661 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound22661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22662 : List Nat := [2,4,8,16,32,16,9,256,512,1024,270,292,268,1029,1,262,1044,43,1024,0,277,33,16,3,269,16,270,1045,292,43,1284,32,256,33,1028,513]

theorem envBound22662 : H12AffineFastState.Bounded env22662 := by
  intro p hp
  have h : env22662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22661_22662 : H12AffineEnvironment.transform 10 270 env22661 = env22662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env22661 == env22662) = true)

theorem identity22662 : scanCanonicalize (H12AffineFastState.compose env22662 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22662 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22663 : List Nat := [2,4,8,16,32,16,9,37,512,1024,43,1,41,1029,1,35,1044,43,1024,0,48,33,16,3,40,16,43,1045,1,43,1057,32,37,33,1028,513]

theorem envBound22663 : H12AffineFastState.Bounded env22663 := by
  intro p hp
  have h : env22663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22662_22663 : H12AffineEnvironment.transform 7 37 env22662 = env22663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22662 == env22663) = true)

theorem identity22663 : scanCanonicalize (H12AffineFastState.compose env22663 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22663 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22664 : List Nat := [2,4,8,16,32,16,9,37,512,21,43,1,41,16,1,35,1,43,21,0,48,33,16,3,40,16,43,0,1,43,52,32,37,33,17,513]

theorem envBound22664 : H12AffineFastState.Bounded env22664 := by
  intro p hp
  have h : env22664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22663_22664 : H12AffineEnvironment.transform 9 21 env22663 = env22664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22663 == env22664) = true)

theorem identity22664 : scanCanonicalize (H12AffineFastState.compose env22664 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22664 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22665 : List Nat := [2,4,8,16,0,16,9,5,512,21,11,1,9,16,1,3,1,11,21,0,16,1,16,3,8,16,11,0,1,11,20,0,5,1,17,513]

theorem envBound22665 : H12AffineFastState.Bounded env22665 := by
  intro p hp
  have h : env22665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22664_22665 : H12AffineEnvironment.transform 4 0 env22664 = env22665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22664 == env22665) = true)

theorem identity22665 : scanCanonicalize (H12AffineFastState.compose env22665 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound22665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22666 : List Nat := [2,4,8,16,0,16,9,5,31,21,11,1,9,16,1,3,1,11,21,0,16,1,16,3,8,16,11,0,1,11,20,0,5,1,17,30]

theorem envBound22666 : H12AffineFastState.Bounded env22666 := by
  intro p hp
  have h : env22666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22665_22666 : H12AffineEnvironment.transform 8 31 env22665 = env22666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env22665 == env22666) = true)

theorem identity22666 : scanCanonicalize (H12AffineFastState.compose env22666 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound22666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22667 : List Nat := [2,4,8,7,0,7,9,5,8,2,11,1,9,7,1,3,1,11,2,0,7,1,7,3,8,7,11,0,1,11,3,0,5,1,6,9]

theorem envBound22667 : H12AffineFastState.Bounded env22667 := by
  intro p hp
  have h : env22667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22666_22667 : H12AffineEnvironment.transform 3 7 env22666 = env22667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env22666 == env22667) = true)

def env22668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,17,41431,8328,64,4678087,115150,45525,442385,75222,4268162,256,98814,90202,512]

theorem envBound22668 : H12AffineFastState.Bounded env22668 := by
  intro p hp
  have h : env22668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22626_22668 : H12AffineEnvironment.transform 22 17 env22626 = env22668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env22626 == env22668) = true)

theorem identity22668 : scanCanonicalize (H12AffineFastState.compose env22668 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound22668 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58516,4194304,17,41431,8328,64,4409363,115150,45525,190917,75222,4268162,256,98814,90202,512]

theorem envBound22669 : H12AffineFastState.Bounded env22669 := by
  intro p hp
  have h : env22669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22668_22669 : H12AffineEnvironment.transform 17 10708 env22668 = env22669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env22668 == env22669) = true)

theorem identity22669 : scanCanonicalize (H12AffineFastState.compose env22669 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 120202) := by decide +kernel

theorem selectedBound22669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58516,120202,17,41431,8328,64,171417,115150,45525,190917,75222,62728,256,98814,90202,512]

theorem envBound22670 : H12AffineFastState.Bounded env22670 := by
  intro p hp
  have h : env22670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22669_22670 : H12AffineEnvironment.transform 21 120202 env22669 = env22670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 120202 env22669 == env22670) = true)

theorem identity22670 : scanCanonicalize (H12AffineFastState.compose env22670 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound22670 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10708,1024,32769,58516,120202,17,41431,8328,64,56713,115150,45525,43477,75222,62728,256,98814,90202,512]

theorem envBound22671 : H12AffineFastState.Bounded env22671 := by
  intro p hp
  have h : env22671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22670_22671 : H12AffineEnvironment.transform 16 16400 env22670 = env22671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22670 == env22671) = true)

theorem identity22671 : scanCanonicalize (H12AffineFastState.compose env22671 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound22671 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16400,10708,1024,29908,4161,74079,17,21762,8328,64,10588,79131,17664,23808,75222,477,256,95531,90202,512]

theorem envBound22672 : H12AffineFastState.Bounded env22672 := by
  intro p hp
  have h : env22672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22671_22672 : H12AffineEnvironment.transform 14 29909 env22671 = env22672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env22671 == env22672) = true)

theorem identity22672 : scanCanonicalize (H12AffineFastState.compose env22672 (packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound22672 : packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env22673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8322,16400,10708,1024,29908,4161,477,17,21762,8328,64,10588,5529,17664,23808,1364,477,256,21929,16600,512]

theorem envBound22673 : H12AffineFastState.Bounded env22673 := by
  intro p hp
  have h : env22673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22672_22673 : H12AffineEnvironment.transform 15 8322 env22672 = env22673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env22672 == env22673) = true)

theorem identity22673 : scanCanonicalize (H12AffineFastState.compose env22673 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13777) := by decide +kernel

theorem selectedBound22673 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env22674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13777,260,8322,13761,10708,1024,261,4161,477,17,8403,8328,64,10588,5529,12497,10449,1364,477,256,8312,13577,512]

theorem envBound22674 : H12AffineFastState.Bounded env22674 := by
  intro p hp
  have h : env22674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22673_22674 : H12AffineEnvironment.transform 13 13777 env22673 = env22674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13777 env22673 == env22674) = true)

theorem identity22674 : scanCanonicalize (H12AffineFastState.compose env22674 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound22674 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env22675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5237,260,294,5221,2160,1024,261,4161,477,17,375,300,64,2296,5529,4469,2421,1364,477,256,476,5293,512]

theorem envBound22675 : H12AffineFastState.Bounded env22675 := by
  intro p hp
  have h : env22675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22674_22675 : H12AffineEnvironment.transform 12 420 env22674 = env22675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env22674 == env22675) = true)

theorem identity22675 : scanCanonicalize (H12AffineFastState.compose env22675 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22675 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env22676 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,209,5237,113,83,5221,2160,1024,112,4161,168,17,2,89,64,2296,5356,4096,2048,1057,168,117,169,5293,512]

theorem envBound22676 : H12AffineFastState.Bounded env22676 := by
  intro p hp
  have h : env22676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22675_22676 : H12AffineEnvironment.transform 7 117 env22675 = env22676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22675 == env22676) = true)

theorem identity22676 : scanCanonicalize (H12AffineFastState.compose env22676 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound22676 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22677 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,121,5237,113,83,5221,2160,1024,112,4161,0,17,2,89,64,2128,5188,4096,2048,1057,0,117,1,5125,512]

theorem envBound22677 : H12AffineFastState.Bounded env22677 := by
  intro p hp
  have h : env22677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22676_22677 : H12AffineEnvironment.transform 6 40 env22676 = env22677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env22676 == env22677) = true)

theorem identity22677 : scanCanonicalize (H12AffineFastState.compose env22677 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22677 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22678 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,80,83,5188,2129,1024,81,4161,0,17,2,89,64,2128,5188,4096,2048,1024,0,84,1,5125,512]

theorem envBound22678 : H12AffineFastState.Bounded env22678 := by
  intro p hp
  have h : env22678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22677_22678 : H12AffineEnvironment.transform 4 1 env22677 = env22678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22677 == env22678) = true)

theorem identity22678 : scanCanonicalize (H12AffineFastState.compose env22678 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound22678 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22679 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1045,4096,88,5204,80,83,5188,1092,1024,81,4161,0,17,2,89,64,1093,5188,4096,1045,1024,0,84,1,5125,512]

theorem envBound22679 : H12AffineFastState.Bounded env22679 := by
  intro p hp
  have h : env22679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22678_22679 : H12AffineEnvironment.transform 10 1045 env22678 = env22679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env22678 == env22679) = true)

theorem identity22679 : scanCanonicalize (H12AffineFastState.compose env22679 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound22679 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env22680 : List Nat := [2,4,8,16,1,64,9,84,512,69,80,4096,88,4113,80,83,4097,1,69,81,4161,0,17,2,89,64,0,4097,4096,80,69,0,84,1,4160,512]

theorem envBound22680 : H12AffineFastState.Bounded env22680 := by
  intro p hp
  have h : env22680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22679_22680 : H12AffineEnvironment.transform 9 69 env22679 = env22680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env22679 == env22680) = true)

theorem identity22680 : scanCanonicalize (H12AffineFastState.compose env22680 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 69) := by decide +kernel

theorem selectedBound22680 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22681 : List Nat := [2,4,8,16,1,64,9,84,512,69,80,69,88,84,80,83,68,1,69,81,4,0,17,2,89,64,0,68,69,80,69,0,84,1,5,512]

theorem envBound22681 : H12AffineFastState.Bounded env22681 := by
  intro p hp
  have h : env22681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22680_22681 : H12AffineEnvironment.transform 11 69 env22680 = env22681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 69 env22680 == env22681) = true)

theorem identity22681 : scanCanonicalize (H12AffineFastState.compose env22681 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound22681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22682 : List Nat := [2,1,8,16,1,64,9,81,512,64,80,64,88,81,80,83,65,1,64,81,1,0,17,2,89,64,0,65,64,80,64,0,81,1,0,512]

theorem envBound22682 : H12AffineFastState.Bounded env22682 := by
  intro p hp
  have h : env22682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22681_22682 : H12AffineEnvironment.transform 1 1 env22681 = env22682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env22681 == env22682) = true)

theorem identity22682 : scanCanonicalize (H12AffineFastState.compose env22682 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22683 : List Nat := [2,1,8,16,1,16,9,1,512,16,0,16,8,1,0,3,17,1,16,1,1,0,17,2,9,16,0,17,16,0,16,0,1,1,0,512]

theorem envBound22683 : H12AffineFastState.Bounded env22683 := by
  intro p hp
  have h : env22683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22682_22683 : H12AffineEnvironment.transform 5 16 env22682 = env22683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22682 == env22683) = true)

def env22684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,8388608,41431,8328,64,13066710,115151,8434117,8830976,8463815,4268163,256,8487406,8478794,8389137]

theorem envBound22684 : H12AffineFastState.Bounded env22684 := by
  intro p hp
  have h : env22684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22625_22684 : H12AffineEnvironment.transform 20 58517 env22625 = env22684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env22625 == env22684) = true)

def env22685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,16,41431,8328,64,4678086,115151,45525,442384,75223,4268163,256,98814,90202,513]

theorem envBound22685 : H12AffineFastState.Bounded env22685 := by
  intro p hp
  have h : env22685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22685 : H12AffineEnvironment.transform 22 16 env22684 = env22685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22684 == env22685) = true)

def env22686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677966,115015,45405,442384,75103,4268043,256,98678,90202,513]

theorem envBound22686 : H12AffineFastState.Bounded env22686 := by
  intro p hp
  have h : env22686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22685_22686 : H12AffineEnvironment.transform 6 8 env22685 = env22686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22685 == env22686) = true)

theorem identity22686 : scanCanonicalize (H12AffineFastState.compose env22686 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22686 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,17728,4194304,16,2,8192,64,4677966,90138,4096,418125,75103,4268043,256,73771,90202,513]

theorem envBound22687 : H12AffineFastState.Bounded env22687 := by
  intro p hp
  have h : env22687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22686_22687 : H12AffineEnvironment.transform 14 8541 env22686 = env22687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22686 == env22687) = true)

theorem identity22687 : scanCanonicalize (H12AffineFastState.compose env22687 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound22687 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,131072,262144,1024,8540,5457,4194304,16,2,8192,64,4665695,77835,4096,405852,75103,4268043,256,73771,77899,513]

theorem envBound22688 : H12AffineFastState.Bounded env22688 := by
  intro p hp
  have h : env22688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22687_22688 : H12AffineEnvironment.transform 13 4113 env22687 = env22688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env22687 == env22688) = true)

theorem identity22688 : scanCanonicalize (H12AffineFastState.compose env22688 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 77835) := by decide +kernel

theorem selectedBound22688 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env22689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,77835,4096,328023,75103,4268043,256,73771,77899,513]

theorem envBound22689 : H12AffineFastState.Bounded env22689 := by
  intro p hp
  have h : env22689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22688_22689 : H12AffineEnvironment.transform 16 77835 env22688 = env22689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77835 env22688 == env22689) = true)

theorem identity22689 : scanCanonicalize (H12AffineFastState.compose env22689 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound22689 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env22690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,262144,1024,8540,5457,33,16,2,8192,64,262517,77835,4096,328023,75103,73770,256,73771,77899,513]

theorem envBound22690 : H12AffineFastState.Bounded env22690 := by
  intro p hp
  have h : env22690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22689_22690 : H12AffineEnvironment.transform 21 33 env22689 = env22690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22689 == env22690) = true)

theorem identity22690 : scanCanonicalize (H12AffineFastState.compose env22690 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22690 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env22691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,65536,77835,10280,1024,8540,5457,33,16,2,8192,64,10589,77835,4096,76159,75103,73770,256,73771,77899,513]

theorem envBound22691 : H12AffineFastState.Bounded env22691 := by
  intro p hp
  have h : env22691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22690_22691 : H12AffineEnvironment.transform 17 10280 env22690 = env22691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22690 == env22691) = true)

theorem identity22691 : scanCanonicalize (H12AffineFastState.compose env22691 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15487) := by decide +kernel

theorem selectedBound22691 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,15487,3188,10280,1024,8540,5457,33,16,2,8192,64,10589,3188,4096,5376,6432,7253,256,7252,3124,513]

theorem envBound22692 : H12AffineFastState.Bounded env22692 := by
  intro p hp
  have h : env22692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22691_22692 : H12AffineEnvironment.transform 15 15487 env22691 = env22692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15487 env22691 == env22692) = true)

theorem identity22692 : scanCanonicalize (H12AffineFastState.compose env22692 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound22692 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env22693 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4113,8541,14362,2065,10280,101,8540,4404,33,16,2,8192,64,10589,2065,4096,4453,6432,6192,256,6193,2129,513]

theorem envBound22693 : H12AffineFastState.Bounded env22693 := by
  intro p hp
  have h : env22693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22692_22693 : H12AffineEnvironment.transform 9 101 env22692 = env22693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env22692 == env22693) = true)

theorem identity22693 : scanCanonicalize (H12AffineFastState.compose env22693 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22693 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env22694 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4113,1,6470,2065,2420,101,0,4404,33,16,2,348,64,2049,2065,4096,4453,6432,6192,256,6193,2129,513]

theorem envBound22694 : H12AffineFastState.Bounded env22694 := by
  intro p hp
  have h : env22694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22693_22694 : H12AffineEnvironment.transform 12 348 env22693 = env22694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22693 == env22694) = true)

theorem identity22694 : scanCanonicalize (H12AffineFastState.compose env22694 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound22694 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22695 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,348,2049,1,342,2065,2420,101,0,2340,33,16,2,348,64,2049,2065,2064,2421,304,32,256,33,2129,513]

theorem envBound22695 : H12AffineFastState.Bounded env22695 := by
  intro p hp
  have h : env22695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22694_22695 : H12AffineEnvironment.transform 11 2064 env22694 = env22695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env22694 == env22695) = true)

theorem identity22695 : scanCanonicalize (H12AffineFastState.compose env22695 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound22695 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22696 : List Nat := [2,4,8,16,32,64,8,256,512,101,302,318,348,303,1,342,319,90,101,0,10,33,16,2,348,64,303,319,318,91,304,32,256,33,383,513]

theorem envBound22696 : H12AffineFastState.Bounded env22696 := by
  intro p hp
  have h : env22696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22695_22696 : H12AffineEnvironment.transform 10 302 env22695 = env22696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env22695 == env22696) = true)

theorem identity22696 : scanCanonicalize (H12AffineFastState.compose env22696 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22697 : List Nat := [2,4,8,16,32,16,8,256,512,53,302,318,268,303,1,262,319,10,53,0,10,33,16,2,268,16,303,319,318,11,304,32,256,33,303,513]

theorem envBound22697 : H12AffineFastState.Bounded env22697 := by
  intro p hp
  have h : env22697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22696_22697 : H12AffineEnvironment.transform 5 16 env22696 = env22697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22696 == env22697) = true)

theorem identity22697 : scanCanonicalize (H12AffineFastState.compose env22697 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22697 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22698 : List Nat := [2,4,8,16,32,16,8,37,512,53,11,27,41,10,1,35,26,10,53,0,10,33,16,2,41,16,10,26,27,11,21,32,37,33,10,513]

theorem envBound22698 : H12AffineFastState.Bounded env22698 := by
  intro p hp
  have h : env22698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22697_22698 : H12AffineEnvironment.transform 7 37 env22697 = env22698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22697 == env22698) = true)

theorem identity22698 : scanCanonicalize (H12AffineFastState.compose env22698 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22698 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22699 : List Nat := [2,4,8,1,32,1,8,37,512,36,11,10,41,10,1,35,11,10,36,0,10,33,1,2,41,1,10,11,10,11,4,32,37,33,10,513]

theorem envBound22699 : H12AffineFastState.Bounded env22699 := by
  intro p hp
  have h : env22699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22698_22699 : H12AffineEnvironment.transform 3 1 env22698 = env22699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22698 == env22699) = true)

theorem identity22699 : scanCanonicalize (H12AffineFastState.compose env22699 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22699 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22700 : List Nat := [2,4,2,1,32,1,2,37,512,36,1,0,35,0,1,35,1,0,36,0,0,33,1,2,35,1,0,1,0,1,4,32,37,33,0,513]

theorem envBound22700 : H12AffineFastState.Bounded env22700 := by
  intro p hp
  have h : env22700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22699_22700 : H12AffineEnvironment.transform 2 2 env22699 = env22700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22699 == env22700) = true)

def env22701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8193,64,4677967,115014,45404,442384,75102,4268042,256,98679,90202,513]

theorem envBound22701 : H12AffineFastState.Bounded env22701 := by
  intro p hp
  have h : env22701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22685_22701 : H12AffineEnvironment.transform 6 9 env22685 = env22701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22685 == env22701) = true)

def env22702 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8193,16,4677919,114966,45324,442384,75022,4268042,256,98599,90122,513]

theorem envBound22702 : H12AffineFastState.Bounded env22702 := by
  intro p hp
  have h : env22702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22701_22702 : H12AffineEnvironment.transform 5 16 env22701 = env22702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22701 == env22702) = true)

def env22703 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8193,16,4409655,114966,45324,190520,75022,4268042,256,98599,90122,513]

theorem envBound22703 : H12AffineFastState.Bounded env22703 := by
  intro p hp
  have h : env22703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22702_22703 : H12AffineEnvironment.transform 17 10280 env22702 = env22703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22702 == env22703) = true)

theorem identity22703 : scanCanonicalize (H12AffineFastState.compose env22703 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound22703 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22704 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118034,16,41230,8193,16,164901,114966,45324,190520,75022,60696,256,98599,90122,513]

theorem envBound22704 : H12AffineFastState.Bounded env22704 := by
  intro p hp
  have h : env22704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22703_22704 : H12AffineEnvironment.transform 21 118034 env22703 = env22704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env22703 == env22704) = true)

theorem identity22704 : scanCanonicalize (H12AffineFastState.compose env22704 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound22704 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env22705 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,58396,118034,16,41230,8193,16,123967,114966,45324,100386,75022,60696,256,98599,90122,513]

theorem envBound22705 : H12AffineFastState.Bounded env22705 := by
  intro p hp
  have h : env22705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22704_22705 : H12AffineEnvironment.transform 16 90138 env22704 = env22705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env22704 == env22705) = true)

theorem identity22705 : scanCanonicalize (H12AffineFastState.compose env22705 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11293) := by decide +kernel

theorem selectedBound22705 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env22706 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11293,65536,90138,10280,1024,11292,18433,90383,16,3347,8193,16,84002,93451,7441,74815,75022,16645,256,77114,90122,513]

theorem envBound22706 : H12AffineFastState.Bounded env22706 := by
  intro p hp
  have h : env22706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22705_22706 : H12AffineEnvironment.transform 14 11293 env22705 = env22706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11293 env22705 == env22706) = true)

theorem identity22706 : scanCanonicalize (H12AffineFastState.compose env22706 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22706 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22707 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,11293,8203,16401,10280,1024,11292,18433,16644,16,3347,8193,16,26665,19712,7441,1076,1285,16645,256,3377,16385,513]

theorem envBound22707 : H12AffineFastState.Bounded env22707 := by
  intro p hp
  have h : env22707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22706_22707 : H12AffineEnvironment.transform 15 8203 env22706 = env22707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22706 == env22707) = true)

theorem identity22707 : scanCanonicalize (H12AffineFastState.compose env22707 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound22707 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22708 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,4113,11293,8203,4096,10280,1024,11292,6160,4373,16,3347,8193,16,14392,7441,7441,1076,1285,4372,256,3377,4112,513]

theorem envBound22708 : H12AffineFastState.Bounded env22708 := by
  intro p hp
  have h : env22708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22707_22708 : H12AffineEnvironment.transform 13 4113 env22707 = env22708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env22707 == env22708) = true)

theorem identity22708 : scanCanonicalize (H12AffineFastState.compose env22708 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound22708 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22709 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5416,4113,6453,5411,4096,7424,1024,6452,6160,4373,16,3347,5417,16,3344,7441,7441,1076,1285,4372,256,3377,4112,513]

theorem envBound22709 : H12AffineFastState.Bounded env22709 := by
  intro p hp
  have h : env22709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22708_22709 : H12AffineEnvironment.transform 12 5416 env22708 = env22709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env22708 == env22709) = true)

theorem identity22709 : scanCanonicalize (H12AffineFastState.compose env22709 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound22709 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22710 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,2089,3344,1076,2082,3329,1,1024,1077,1297,3092,16,3347,2088,16,3344,16,16,1076,1285,3093,256,3377,3345,513]

theorem envBound22710 : H12AffineFastState.Bounded env22710 := by
  intro p hp
  have h : env22710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22709_22710 : H12AffineEnvironment.transform 11 3329 env22709 = env22710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env22709 == env22710) = true)

theorem identity22710 : scanCanonicalize (H12AffineFastState.compose env22710 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22710 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env22711 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,3329,2089,3344,1076,2082,3329,1,1024,1077,1297,3092,16,3347,2088,16,3344,16,16,1076,1285,3093,256,3377,3345,1]

theorem envBound22711 : H12AffineFastState.Bounded env22711 := by
  intro p hp
  have h : env22711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22710_22711 : H12AffineEnvironment.transform 8 0 env22710 = env22711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22710 == env22711) = true)

theorem identity22711 : scanCanonicalize (H12AffineFastState.compose env22711 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22711 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22712 : List Nat := [2,4,8,16,32,16,9,256,0,273,2048,2064,2089,2049,293,2082,2064,1,273,292,0,2309,16,2050,2088,16,2049,16,16,293,20,2308,256,2080,2048,1]

theorem envBound22712 : H12AffineFastState.Bounded env22712 := by
  intro p hp
  have h : env22712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22711_22712 : H12AffineEnvironment.transform 9 273 env22711 = env22712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22711 == env22712) = true)

theorem identity22712 : scanCanonicalize (H12AffineFastState.compose env22712 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound22712 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22713 : List Nat := [2,4,8,16,32,16,9,256,0,273,293,309,268,292,293,263,309,1,273,292,0,32,16,295,269,16,292,16,16,293,20,33,256,261,293,1]

theorem envBound22713 : H12AffineFastState.Bounded env22713 := by
  intro p hp
  have h : env22713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22712_22713 : H12AffineEnvironment.transform 10 293 env22712 = env22713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env22712 == env22713) = true)

theorem identity22713 : scanCanonicalize (H12AffineFastState.compose env22713 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22714 : List Nat := [2,4,8,16,17,16,9,256,0,273,276,260,268,277,276,263,260,1,273,277,0,17,16,278,269,16,277,16,16,276,20,16,256,261,276,1]

theorem envBound22714 : H12AffineFastState.Bounded env22714 := by
  intro p hp
  have h : env22714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22713_22714 : H12AffineEnvironment.transform 4 17 env22713 = env22714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22713 == env22714) = true)

theorem identity22714 : scanCanonicalize (H12AffineFastState.compose env22714 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22715 : List Nat := [2,4,8,16,17,16,9,20,0,5,0,16,24,1,0,19,16,1,5,1,0,17,16,2,25,16,1,16,16,0,20,16,20,17,0,1]

theorem envBound22715 : H12AffineFastState.Bounded env22715 := by
  intro p hp
  have h : env22715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22714_22715 : H12AffineEnvironment.transform 7 20 env22714 = env22715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22714 == env22715) = true)

theorem identity22715 : scanCanonicalize (H12AffineFastState.compose env22715 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22715 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22716 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,0,8,1,0,3,0,1,5,1,0,1,0,2,9,0,1,0,0,0,4,0,4,1,0,1]

theorem envBound22716 : H12AffineFastState.Bounded env22716 := by
  intro p hp
  have h : env22716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22715_22716 : H12AffineEnvironment.transform 3 0 env22715 = env22716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22715 == env22716) = true)

def env22717 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8193,16,4409654,114966,45324,190521,75022,4268042,256,98599,90122,513]

theorem envBound22717 : H12AffineFastState.Bounded env22717 := by
  intro p hp
  have h : env22717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22702_22717 : H12AffineEnvironment.transform 17 10281 env22702 = env22717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22702 == env22717) = true)

theorem identity22717 : scanCanonicalize (H12AffineFastState.compose env22717 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound22717 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22718 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246071,16,41230,8193,16,34817,114966,45324,190521,75022,188733,256,98599,90122,513]

theorem envBound22718 : H12AffineFastState.Bounded env22718 := by
  intro p hp
  have h : env22718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22717_22718 : H12AffineEnvironment.transform 21 246071 env22717 = env22718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env22717 == env22718) = true)

theorem identity22718 : scanCanonicalize (H12AffineFastState.compose env22718 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound22718 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env22719 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,114966,10281,1024,32769,58396,33,16,41230,8193,16,34817,114966,45324,76079,75022,73771,256,98599,90122,513]

theorem envBound22719 : H12AffineFastState.Bounded env22719 := by
  intro p hp
  have h : env22719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22718_22719 : H12AffineEnvironment.transform 16 114966 env22718 = env22719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env22718 == env22719) = true)

theorem identity22719 : scanCanonicalize (H12AffineFastState.compose env22719 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22719 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22720 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,49168,10281,1024,32769,58396,33,16,41230,8193,16,34817,49168,45324,10281,9224,8493,256,32801,24844,513]

theorem envBound22720 : H12AffineFastState.Bounded env22720 := by
  intro p hp
  have h : env22720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22719_22720 : H12AffineEnvironment.transform 15 262 env22719 = env22720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22719 == env22720) = true)

theorem identity22720 : scanCanonicalize (H12AffineFastState.compose env22720 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22720 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22721 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,262,24860,10281,1024,8461,17680,33,16,2,8193,16,10509,24860,4096,10281,9224,8493,256,8493,24844,513]

theorem envBound22721 : H12AffineFastState.Bounded env22721 := by
  intro p hp
  have h : env22721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22720_22721 : H12AffineEnvironment.transform 14 8460 env22720 = env22721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22720 == env22721) = true)

theorem identity22721 : scanCanonicalize (H12AffineFastState.compose env22721 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22721 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22722 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1024,1,17680,33,16,2,269,16,2049,16400,4096,2341,1284,33,256,33,16384,513]

theorem envBound22722 : H12AffineFastState.Bounded env22722 := by
  intro p hp
  have h : env22722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22721_22722 : H12AffineEnvironment.transform 12 268 env22721 = env22722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22721 == env22722) = true)

theorem identity22722 : scanCanonicalize (H12AffineFastState.compose env22722 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22722 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22723 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,16,268,16384,0,262,16400,2341,1024,1,17680,33,16,2,269,16,2049,16400,16,2341,1284,33,256,33,16384,513]

theorem envBound22723 : H12AffineFastState.Bounded env22723 := by
  intro p hp
  have h : env22723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22722_22723 : H12AffineEnvironment.transform 11 16 env22722 = env22723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22722 == env22723) = true)

def env22724 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8193,17,4677918,114967,45325,442384,75023,4268042,256,98598,90123,513]

theorem envBound22724 : H12AffineFastState.Bounded env22724 := by
  intro p hp
  have h : env22724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22701_22724 : H12AffineEnvironment.transform 5 17 env22701 = env22724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22701 == env22724) = true)

theorem identity22724 : scanCanonicalize (H12AffineFastState.compose env22724 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22724 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env22725 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4409655,114967,45325,190521,75023,4268042,256,98598,90123,513]

theorem envBound22725 : H12AffineFastState.Bounded env22725 := by
  intro p hp
  have h : env22725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22724_22725 : H12AffineEnvironment.transform 17 10281 env22724 = env22725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22724 == env22725) = true)

theorem identity22725 : scanCanonicalize (H12AffineFastState.compose env22725 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound22725 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env22726 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4385085,24861,45325,190521,34053,4227072,256,8492,49153,513]

theorem envBound22726 : H12AffineFastState.Bounded env22726 := by
  intro p hp
  have h : env22726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22725_22726 : H12AffineEnvironment.transform 15 40970 env22725 = env22726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env22725 == env22726) = true)

theorem identity22726 : scanCanonicalize (H12AffineFastState.compose env22726 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound22726 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22727 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,147505,16,41231,8193,17,43276,24861,45325,190521,34053,180273,256,8492,49153,513]

theorem envBound22727 : H12AffineFastState.Bounded env22727 := by
  intro p hp
  have h : env22727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22726_22727 : H12AffineEnvironment.transform 21 147505 env22726 = env22727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env22726 == env22727) = true)

theorem identity22727 : scanCanonicalize (H12AffineFastState.compose env22727 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound22727 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22728 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,24861,10281,1024,32769,58396,8492,16,41231,8193,17,43276,24861,45325,35108,34053,41260,256,8492,49153,513]

theorem envBound22728 : H12AffineFastState.Bounded env22728 := by
  intro p hp
  have h : env22728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22727_22728 : H12AffineEnvironment.transform 16 24861 env22727 = env22728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env22727 == env22728) = true)

def env22729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,17,41431,8328,64,4678087,115151,45524,442385,75222,4268163,256,98815,90203,512]

theorem envBound22729 : H12AffineFastState.Bounded env22729 := by
  intro p hp
  have h : env22729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22729 : H12AffineEnvironment.transform 22 17 env22684 = env22729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env22684 == env22729) = true)

theorem identity22729 : scanCanonicalize (H12AffineFastState.compose env22729 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10709) := by decide +kernel

theorem selectedBound22729 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58517,4194304,17,41431,8328,64,4409362,115151,45524,190916,75222,4268163,256,98815,90203,512]

theorem envBound22730 : H12AffineFastState.Bounded env22730 := by
  intro p hp
  have h : env22730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22729_22730 : H12AffineEnvironment.transform 17 10709 env22729 = env22730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10709 env22729 == env22730) = true)

theorem identity22730 : scanCanonicalize (H12AffineFastState.compose env22730 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62848) := by decide +kernel

theorem selectedBound22730 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58517,62848,17,41431,8328,64,245138,115151,45524,190916,75222,120067,256,98815,90203,512]

theorem envBound22731 : H12AffineFastState.Bounded env22731 := by
  intro p hp
  have h : env22731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22730_22731 : H12AffineEnvironment.transform 21 62848 env22730 = env22731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62848 env22730 == env22731) = true)

theorem identity22731 : scanCanonicalize (H12AffineFastState.compose env22731 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound22731 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10709,1024,32769,58517,62848,17,41431,8328,64,130434,115151,45524,43476,75222,120067,256,98815,90203,512]

theorem envBound22732 : H12AffineFastState.Bounded env22732 := by
  intro p hp
  have h : env22732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22731_22732 : H12AffineEnvironment.transform 16 16400 env22731 = env22732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22731 == env22732) = true)

theorem identity22732 : scanCanonicalize (H12AffineFastState.compose env22732 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound22732 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16400,10709,1024,32769,58517,62848,17,41431,8328,64,10588,5393,45524,43476,61704,477,256,21793,46213,512]

theorem envBound22733 : H12AffineFastState.Bounded env22733 := by
  intro p hp
  have h : env22733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22732_22733 : H12AffineEnvironment.transform 15 54494 env22732 = env22733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env22732 == env22733) = true)

theorem identity22733 : scanCanonicalize (H12AffineFastState.compose env22733 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22733 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env22734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,32768,32938,5220,10709,1024,32769,45281,41460,17,41431,8328,64,10588,5393,45524,43476,42364,477,256,341,46213,512]

theorem envBound22734 : H12AffineFastState.Bounded env22734 := by
  intro p hp
  have h : env22734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22733_22734 : H12AffineEnvironment.transform 13 5236 env22733 = env22734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22733 == env22734) = true)

theorem identity22734 : scanCanonicalize (H12AffineFastState.compose env22734 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 397) := by decide +kernel

theorem selectedBound22734 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,397,295,5220,10709,1024,396,12652,8313,17,8282,8328,64,10588,5393,12377,10329,9457,477,256,341,13576,512]

theorem envBound22735 : H12AffineFastState.Bounded env22735 := by
  intro p hp
  have h : env22735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22734_22735 : H12AffineEnvironment.transform 14 397 env22734 = env22735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 397 env22734 == env22735) = true)

theorem identity22735 : scanCanonicalize (H12AffineFastState.compose env22735 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound22735 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env22736 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,113,219,5220,10281,1024,112,12432,8313,17,8282,8328,64,10400,5357,12377,10329,9457,33,252,169,13556,512]

theorem envBound22736 : H12AffineFastState.Bounded env22736 := by
  intro p hp
  have h : env22736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22735_22736 : H12AffineEnvironment.transform 7 252 env22735 = env22736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env22735 == env22736) = true)

theorem identity22736 : scanCanonicalize (H12AffineFastState.compose env22736 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound22736 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env22737 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,88,5236,113,219,5220,2161,1024,112,4296,33,17,2,208,64,2296,5357,4097,2049,1193,33,252,169,5292,512]

theorem envBound22737 : H12AffineFastState.Bounded env22737 := by
  intro p hp
  have h : env22737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22736_22737 : H12AffineEnvironment.transform 12 88 env22736 = env22737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env22736 == env22737) = true)

theorem identity22737 : scanCanonicalize (H12AffineFastState.compose env22737 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22737 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env22738 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,88,5236,113,82,5220,2161,1024,112,4161,33,17,2,89,64,2161,5220,4097,2049,1056,33,117,32,5157,512]

theorem envBound22738 : H12AffineFastState.Bounded env22738 := by
  intro p hp
  have h : env22738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22737_22738 : H12AffineEnvironment.transform 6 9 env22737 = env22738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22737 == env22738) = true)

theorem identity22738 : scanCanonicalize (H12AffineFastState.compose env22738 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22738 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22739 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8,5156,33,2,5172,2081,1024,32,4113,33,17,2,9,16,2081,5172,4097,2049,1056,33,37,32,5157,512]

theorem envBound22739 : H12AffineFastState.Bounded env22739 := by
  intro p hp
  have h : env22739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22738_22739 : H12AffineEnvironment.transform 5 16 env22738 = env22739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22738 == env22739) = true)

theorem identity22739 : scanCanonicalize (H12AffineFastState.compose env22739 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22739 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22740 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,8,4112,33,2,4096,2081,52,32,4113,33,17,2,9,16,2081,4096,4097,2049,20,33,37,32,4113,512]

theorem envBound22740 : H12AffineFastState.Bounded env22740 := by
  intro p hp
  have h : env22740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22739_22740 : H12AffineEnvironment.transform 9 52 env22739 = env22740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22739 == env22740) = true)

theorem identity22740 : scanCanonicalize (H12AffineFastState.compose env22740 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 517) := by decide +kernel

theorem selectedBound22740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22741 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,517,8,533,33,2,517,2081,52,32,532,33,17,2,9,16,2081,517,516,2049,20,33,37,32,532,512]

theorem envBound22741 : H12AffineFastState.Bounded env22741 := by
  intro p hp
  have h : env22741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22740_22741 : H12AffineEnvironment.transform 11 517 env22740 = env22741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 517 env22740 == env22741) = true)

theorem identity22741 : scanCanonicalize (H12AffineFastState.compose env22741 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound22741 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22742 : List Nat := [2,4,8,16,32,16,9,37,512,52,31,517,8,533,33,2,517,62,52,32,532,33,17,2,9,16,62,517,516,30,20,33,37,32,532,512]

theorem envBound22742 : H12AffineFastState.Bounded env22742 := by
  intro p hp
  have h : env22742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22741_22742 : H12AffineEnvironment.transform 10 31 env22741 = env22742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env22741 == env22742) = true)

theorem identity22742 : scanCanonicalize (H12AffineFastState.compose env22742 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound22742 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22743 : List Nat := [2,4,8,16,32,16,9,37,12,52,31,9,8,25,33,2,9,62,52,32,24,33,17,2,9,16,62,9,8,30,20,33,37,32,24,12]

theorem envBound22743 : H12AffineFastState.Bounded env22743 := by
  intro p hp
  have h : env22743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22742_22743 : H12AffineEnvironment.transform 8 12 env22742 = env22743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env22742 == env22743) = true)

theorem identity22743 : scanCanonicalize (H12AffineFastState.compose env22743 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound22743 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22744 : List Nat := [2,4,8,16,30,16,9,27,12,10,31,9,8,25,31,2,9,0,10,30,24,31,17,2,9,16,0,9,8,30,20,31,27,30,24,12]

theorem envBound22744 : H12AffineFastState.Bounded env22744 := by
  intro p hp
  have h : env22744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22743_22744 : H12AffineEnvironment.transform 4 30 env22743 = env22744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env22743 == env22744) = true)

theorem identity22744 : scanCanonicalize (H12AffineFastState.compose env22744 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound22744 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22745 : List Nat := [2,4,8,15,1,15,9,4,12,10,0,9,8,6,0,2,9,0,10,1,7,0,14,2,9,15,0,9,8,1,11,0,4,1,7,12]

theorem envBound22745 : H12AffineFastState.Bounded env22745 := by
  intro p hp
  have h : env22745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22744_22745 : H12AffineEnvironment.transform 3 15 env22744 = env22745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env22744 == env22745) = true)

theorem identity22745 : scanCanonicalize (H12AffineFastState.compose env22745 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound22745 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22746 : List Nat := [2,3,8,8,1,8,9,3,11,10,0,9,8,1,0,2,9,0,10,1,0,0,9,2,9,8,0,9,8,1,11,0,3,1,0,11]

theorem envBound22746 : H12AffineFastState.Bounded env22746 := by
  intro p hp
  have h : env22746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22745_22746 : H12AffineEnvironment.transform 1 3 env22745 = env22746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env22745 == env22746) = true)

def env22747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound22747 : H12AffineFastState.Bounded env22747 := by
  intro p hp
  have h : env22747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22623_22747 : H12AffineEnvironment.transform 18 1025 env22623 = env22747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22623 == env22747) = true)

theorem identity22747 : scanCanonicalize (H12AffineFastState.compose env22747 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213335) := by decide +kernel

theorem selectedBound22747 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213335,16777216,8328,64,21266775,18973836,2298887,360790,16958791,23160257,257,19039738,19031135,17031824]

theorem envBound22748 : H12AffineFastState.Bounded env22748 := by
  intro p hp
  have h : env22748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22747_22748 : H12AffineEnvironment.transform 22 213335 env22747 = env22748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213335 env22747 == env22748) = true)

def env22749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412108,213335,16777216,8328,64,16959643,18973836,2298887,360790,16958791,19344397,257,19039738,19031135,17031824]

theorem envBound22749 : H12AffineFastState.Bounded env22749 := by
  intro p hp
  have h : env22749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22748_22749 : H12AffineEnvironment.transform 21 412108 env22748 = env22749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412108 env22748 == env22749) = true)

def env22750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213335,16777216,8328,64,16959643,16974164,102879,360790,16958791,17148373,257,16777250,16834951,17031824]

theorem envBound22750 : H12AffineFastState.Bounded env22750 := by
  intro p hp
  have h : env22750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22749_22750 : H12AffineEnvironment.transform 20 165336 env22749 = env22750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env22749 == env22750) = true)

def env22751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213335,254096,8328,64,75787,57796,102879,360790,75223,411973,257,254130,196887,512]

theorem envBound22751 : H12AffineFastState.Bounded env22751 := by
  intro p hp
  have h : env22751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22750_22751 : H12AffineEnvironment.transform 23 254096 env22750 = env22751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env22750 == env22751) = true)

theorem identity22751 : scanCanonicalize (H12AffineFastState.compose env22751 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound22751 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4160,318548,120015,95496,8328,64,75787,57796,102879,360790,75223,318685,257,95530,103567,512]

theorem envBound22752 : H12AffineFastState.Bounded env22752 := by
  intro p hp
  have h : env22752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22751_22752 : H12AffineEnvironment.transform 16 38296 env22751 = env22752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env22751 == env22752) = true)

theorem identity22752 : scanCanonicalize (H12AffineFastState.compose env22752 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound22752 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,38296,262144,1025,32769,4160,318548,54680,29791,8328,64,10588,57796,37000,294913,9344,318685,257,29821,38360,512]

theorem envBound22753 : H12AffineFastState.Bounded env22753 := by
  intro p hp
  have h : env22753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22752_22753 : H12AffineEnvironment.transform 15 343 env22752 = env22753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env22752 == env22753) = true)

theorem identity22753 : scanCanonicalize (H12AffineFastState.compose env22753 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound22753 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,343,16400,262144,1025,21897,4160,264668,16,29791,8328,64,10588,13388,17664,284041,9344,264533,257,29821,16464,512]

theorem envBound22754 : H12AffineFastState.Bounded env22754 := by
  intro p hp
  have h : env22754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22753_22754 : H12AffineEnvironment.transform 14 21896 env22753 = env22754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env22753 == env22754) = true)

theorem identity22754 : scanCanonicalize (H12AffineFastState.compose env22754 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound22754 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,343,16400,2184,1025,21897,4160,340,16,29791,8328,64,10588,13388,17664,23809,9344,477,257,29821,16464,512]

theorem envBound22755 : H12AffineFastState.Bounded env22755 := by
  intro p hp
  have h : env22755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22754_22755 : H12AffineEnvironment.transform 17 2184 env22754 = env22755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env22754 == env22755) = true)

theorem identity22755 : scanCanonicalize (H12AffineFastState.compose env22755 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound22755 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22756 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,21620,171,16400,2184,1025,21621,4160,168,16,29791,8328,64,10400,13388,17660,23805,9344,33,253,29821,16464,512]

theorem envBound22756 : H12AffineFastState.Bounded env22756 := by
  intro p hp
  have h : env22756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22755_22756 : H12AffineEnvironment.transform 7 252 env22755 = env22756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env22755 == env22756) = true)

theorem identity22756 : scanCanonicalize (H12AffineFastState.compose env22756 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound22756 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env22757 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,16384,21620,171,16400,2184,1025,21621,4160,168,16,21758,41,64,2049,5357,17660,23805,1057,33,253,21724,16464,512]

theorem envBound22757 : H12AffineFastState.Bounded env22757 := by
  intro p hp
  have h : env22757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22756_22757 : H12AffineEnvironment.transform 12 161 env22756 = env22757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env22756 == env22757) = true)

theorem identity22757 : scanCanonicalize (H12AffineFastState.compose env22757 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22757 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22758 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,21620,34,16400,2049,1025,21621,4160,33,16,21623,41,64,2049,5220,17525,23668,1057,33,116,21589,16464,512]

theorem envBound22758 : H12AffineFastState.Bounded env22758 := by
  intro p hp
  have h : env22758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22757_22758 : H12AffineEnvironment.transform 6 9 env22757 = env22758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22757 == env22758) = true)

theorem identity22758 : scanCanonicalize (H12AffineFastState.compose env22758 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound22758 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22759 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5125,113,34,5141,2049,1025,112,4160,33,16,114,41,64,2049,5220,4208,2161,1057,33,116,80,5205,512]

theorem envBound22759 : H12AffineFastState.Bounded env22759 := by
  intro p hp
  have h : env22759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22758_22759 : H12AffineEnvironment.transform 13 5125 env22758 = env22759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env22758 == env22759) = true)

theorem identity22759 : scanCanonicalize (H12AffineFastState.compose env22759 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22759 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22760 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5125,32,34,5141,2049,1025,33,4113,33,16,35,41,17,2049,5173,4129,2080,1057,33,37,1,5124,512]

theorem envBound22760 : H12AffineFastState.Bounded env22760 := by
  intro p hp
  have h : env22760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22759_22760 : H12AffineEnvironment.transform 5 17 env22759 = env22760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22759 == env22760) = true)

theorem identity22760 : scanCanonicalize (H12AffineFastState.compose env22760 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound22760 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env22761 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1044,4096,40,5125,32,34,5141,1045,1025,33,4113,33,16,35,41,17,1045,5173,4129,1076,1057,33,37,1,5124,512]

theorem envBound22761 : H12AffineFastState.Bounded env22761 := by
  intro p hp
  have h : env22761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22760_22761 : H12AffineEnvironment.transform 10 1044 env22760 = env22761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env22760 == env22761) = true)

theorem identity22761 : scanCanonicalize (H12AffineFastState.compose env22761 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22761 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22762 : List Nat := [2,4,8,16,32,17,9,36,512,20,0,4096,40,4113,32,34,4097,1,21,33,4113,33,16,35,41,17,1,4129,4129,32,53,33,37,1,4112,512]

theorem envBound22762 : H12AffineFastState.Bounded env22762 := by
  intro p hp
  have h : env22762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22761_22762 : H12AffineEnvironment.transform 9 20 env22761 = env22762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22761 == env22762) = true)

theorem identity22762 : scanCanonicalize (H12AffineFastState.compose env22762 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound22762 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22763 : List Nat := [2,4,1,16,32,17,0,36,512,20,0,4096,33,4113,32,34,4097,1,21,33,4113,33,16,35,32,17,1,4129,4129,32,53,33,37,1,4112,512]

theorem envBound22763 : H12AffineFastState.Bounded env22763 := by
  intro p hp
  have h : env22763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22762_22763 : H12AffineEnvironment.transform 2 1 env22762 = env22763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env22762 == env22763) = true)

theorem identity22763 : scanCanonicalize (H12AffineFastState.compose env22763 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22764 : List Nat := [2,4,1,16,32,17,0,36,512,20,0,16,33,1,32,34,17,1,21,33,1,33,16,35,32,17,1,49,49,32,53,33,37,1,0,512]

theorem envBound22764 : H12AffineFastState.Bounded env22764 := by
  intro p hp
  have h : env22764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22763_22764 : H12AffineEnvironment.transform 11 16 env22763 = env22764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22763 == env22764) = true)

theorem identity22764 : scanCanonicalize (H12AffineFastState.compose env22764 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound22764 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env22765 : List Nat := [2,4,1,16,32,17,0,36,35,20,0,16,33,1,32,34,17,1,21,33,1,33,16,35,32,17,1,49,49,32,53,33,37,1,0,35]

theorem envBound22765 : H12AffineFastState.Bounded env22765 := by
  intro p hp
  have h : env22765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22764_22765 : H12AffineEnvironment.transform 8 35 env22764 = env22765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env22764 == env22765) = true)

theorem identity22765 : scanCanonicalize (H12AffineFastState.compose env22765 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22765 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22766 : List Nat := [2,4,1,16,0,17,0,4,3,20,0,16,1,1,0,2,17,1,21,1,1,1,16,3,0,17,1,17,17,0,21,1,5,1,0,3]

theorem envBound22766 : H12AffineFastState.Bounded env22766 := by
  intro p hp
  have h : env22766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22765_22766 : H12AffineEnvironment.transform 4 0 env22765 = env22766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22765 == env22766) = true)

theorem identity22766 : scanCanonicalize (H12AffineFastState.compose env22766 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound22766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22767 : List Nat := [2,4,1,7,0,6,0,4,3,3,0,7,1,1,0,2,6,1,2,1,1,1,7,3,0,6,1,6,6,0,2,1,5,1,0,3]

theorem envBound22767 : H12AffineFastState.Bounded env22767 := by
  intro p hp
  have h : env22767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22766_22767 : H12AffineEnvironment.transform 3 7 env22766 = env22767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env22766 == env22767) = true)

def env22768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213335,254097,8328,64,75786,57797,102879,360790,75222,411972,257,254131,196886,513]

theorem envBound22768 : H12AffineFastState.Bounded env22768 := by
  intro p hp
  have h : env22768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22750_22768 : H12AffineEnvironment.transform 23 254097 env22750 = env22768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env22750 == env22768) = true)

def env22769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213335,253977,8192,64,75786,57677,102743,360790,75102,411972,257,254011,196886,513]

theorem envBound22769 : H12AffineFastState.Bounded env22769 := by
  intro p hp
  have h : env22769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22768_22769 : H12AffineEnvironment.transform 6 8 env22768 = env22769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22768 == env22769) = true)

theorem identity22769 : scanCanonicalize (H12AffineFastState.compose env22769 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound22769 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env22770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,165200,180272,213335,253977,8192,64,75786,57677,102743,67618,75102,180272,257,254011,196886,513]

theorem envBound22770 : H12AffineFastState.Bounded env22770 := by
  intro p hp
  have h : env22770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22769_22770 : H12AffineEnvironment.transform 17 35188 env22769 = env22770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env22769 == env22770) = true)

theorem identity22770 : scanCanonicalize (H12AffineFastState.compose env22770 (packedSelected [1,3,4,5,8,9,10,14,15,16,19,38] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound22770 : packedSelected [1,3,4,5,8,9,10,14,15,16,19,38] rootPS < 2^1333 := by decide +kernel

def env22771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82198,35188,1025,32769,115782,98598,65,41231,8192,64,75786,57677,102743,67618,75102,98598,257,41261,16384,513]

theorem envBound22771 : H12AffineFastState.Bounded env22771 := by
  intro p hp
  have h : env22771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22770_22771 : H12AffineEnvironment.transform 16 82198 env22770 = env22771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env22770 == env22771) = true)

theorem identity22771 : scanCanonicalize (H12AffineFastState.compose env22771 (packedSelected [1,2,3,5,6,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22771 : packedSelected [1,2,3,5,6,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env22772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,82198,10360,1025,8461,91466,73770,65,3,8192,64,75786,16449,77915,67618,75102,73770,257,33,16384,513]

theorem envBound22772 : H12AffineFastState.Bounded env22772 := by
  intro p hp
  have h : env22772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22771_22772 : H12AffineEnvironment.transform 14 8460 env22771 = env22772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22771 == env22772) = true)

theorem identity22772 : scanCanonicalize (H12AffineFastState.compose env22772 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22772 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22773 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,82198,10281,1025,8461,91419,73770,16,3,8192,17,75786,16400,77834,67618,75023,73770,257,33,16384,513]

theorem envBound22773 : H12AffineFastState.Bounded env22773 := by
  intro p hp
  have h : env22773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22772_22773 : H12AffineEnvironment.transform 5 17 env22772 = env22773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22772 == env22773) = true)

theorem identity22773 : scanCanonicalize (H12AffineFastState.compose env22773 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22773 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22774 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,65536,82198,2340,1025,0,82966,65831,16,3,269,17,67847,16400,69895,67618,66562,65831,257,33,16384,513]

theorem envBound22774 : H12AffineFastState.Bounded env22774 := by
  intro p hp
  have h : env22774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22773_22774 : H12AffineEnvironment.transform 12 269 env22773 = env22774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22773 == env22774) = true)

theorem identity22774 : scanCanonicalize (H12AffineFastState.compose env22774 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22774 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22775 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1025,0,17680,33,16,3,269,17,2049,16400,4097,2340,1284,33,257,33,16384,513]

theorem envBound22775 : H12AffineFastState.Bounded env22775 := by
  intro p hp
  have h : env22775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22774_22775 : H12AffineEnvironment.transform 15 262 env22774 = env22775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22774 == env22775) = true)

theorem identity22775 : scanCanonicalize (H12AffineFastState.compose env22775 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1280) := by decide +kernel

theorem selectedBound22775 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22776 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,1280,1,262,1296,2340,1025,0,16,33,16,3,269,17,2049,1296,4097,2340,1284,33,257,33,1280,513]

theorem envBound22776 : H12AffineFastState.Bounded env22776 := by
  intro p hp
  have h : env22776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22775_22776 : H12AffineEnvironment.transform 13 1280 env22775 = env22776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1280 env22775 == env22776) = true)

theorem identity22776 : scanCanonicalize (H12AffineFastState.compose env22776 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2366) := by decide +kernel

theorem selectedBound22776 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22777 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2366,269,1280,1,262,1296,2340,1025,0,16,33,16,3,269,17,2049,1296,2367,2340,1284,33,257,33,1280,513]

theorem envBound22777 : H12AffineFastState.Bounded env22777 := by
  intro p hp
  have h : env22777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22776_22777 : H12AffineEnvironment.transform 11 2366 env22776 = env22777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2366 env22776 == env22777) = true)

theorem identity22777 : scanCanonicalize (H12AffineFastState.compose env22777 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1339) := by decide +kernel

theorem selectedBound22777 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22778 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1339,1029,269,1280,1,262,1296,1055,1025,0,16,33,16,3,269,17,1338,1296,1028,1055,1284,33,257,33,1280,513]

theorem envBound22778 : H12AffineFastState.Bounded env22778 := by
  intro p hp
  have h : env22778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22777_22778 : H12AffineEnvironment.transform 10 1339 env22777 = env22778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1339 env22777 == env22778) = true)

theorem identity22778 : scanCanonicalize (H12AffineFastState.compose env22778 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound22778 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22779 : List Nat := [2,4,8,16,32,17,8,256,512,30,293,27,269,286,1,262,270,1,31,0,16,33,16,3,269,17,292,270,26,1,282,33,257,33,286,513]

theorem envBound22779 : H12AffineFastState.Bounded env22779 := by
  intro p hp
  have h : env22779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22778_22779 : H12AffineEnvironment.transform 9 30 env22778 = env22779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env22778 == env22779) = true)

theorem identity22779 : scanCanonicalize (H12AffineFastState.compose env22779 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound22779 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22780 : List Nat := [2,4,8,16,32,17,8,62,512,30,27,27,51,32,1,56,48,1,31,0,16,33,16,3,51,17,26,48,26,1,36,33,63,33,32,513]

theorem envBound22780 : H12AffineFastState.Bounded env22780 := by
  intro p hp
  have h : env22780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1