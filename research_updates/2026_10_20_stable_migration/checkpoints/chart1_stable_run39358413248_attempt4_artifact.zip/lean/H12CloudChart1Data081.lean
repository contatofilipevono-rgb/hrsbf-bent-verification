import H12CloudChart1Data080

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans20479_20480 : H12AffineEnvironment.transform 8 3 env20479 = env20480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env20479 == env20480) = true)

theorem identity20480 : scanCanonicalize (H12AffineFastState.compose env20480 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20481 : List Nat := [2,1,8,16,0,17,9,1,3,16,0,16,9,1,1,3,16,1,16,0,1,0,17,3,8,16,0,16,17,1,17,1,1,0,1,3]

theorem envBound20481 : H12AffineFastState.Bounded env20481 := by
  intro p hp
  have h : env20481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20480_20481 : H12AffineEnvironment.transform 4 0 env20480 = env20481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20480 == env20481) = true)

theorem identity20481 : scanCanonicalize (H12AffineFastState.compose env20481 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20481 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20482 : List Nat := [2,1,0,16,0,17,1,1,3,16,0,16,1,1,1,3,16,1,16,0,1,0,17,3,0,16,0,16,17,1,17,1,1,0,1,3]

theorem envBound20482 : H12AffineFastState.Bounded env20482 := by
  intro p hp
  have h : env20482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20481_20482 : H12AffineEnvironment.transform 2 0 env20481 = env20482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20481 == env20482) = true)

def env20483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400636,498993,8328,65,295284,395772,416237,56573,1500,272392,256,21792,46213,74251]

theorem envBound20483 : H12AffineFastState.Bounded env20483 := by
  intro p hp
  have h : env20483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20455_20483 : H12AffineEnvironment.transform 20 4161 env20455 = env20483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20455 == env20483) = true)

theorem identity20483 : scanCanonicalize (H12AffineFastState.compose env20483 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound20483 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4161,180409,73754,41431,8328,65,245138,79130,91403,56573,1500,201966,256,21792,46213,74251]

theorem envBound20484 : H12AffineFastState.Bounded env20484 := by
  intro p hp
  have h : env20484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20483_20484 : H12AffineEnvironment.transform 17 212198 env20483 = env20484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env20483 == env20484) = true)

def env20485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67754,1024,32769,4161,62709,73754,41431,8328,65,100830,79130,91403,56573,1500,73890,256,21792,46213,74251]

theorem envBound20485 : H12AffineFastState.Bounded env20485 := by
  intro p hp
  have h : env20485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20484_20485 : H12AffineEnvironment.transform 16 13388 env20484 = env20485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env20484 == env20485) = true)

theorem identity20485 : scanCanonicalize (H12AffineFastState.compose env20485 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 34146) := by decide +kernel

theorem selectedBound20485 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env20486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,34146,13388,36296,1024,32769,4161,62709,42360,41431,8328,65,3260,45176,57449,56573,1500,42432,256,21792,46213,42857]

theorem envBound20486 : H12AffineFastState.Bounded env20486 := by
  intro p hp
  have h : env20486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20485_20486 : H12AffineEnvironment.transform 15 34146 env20485 = env20486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34146 env20485 == env20486) = true)

theorem identity20486 : scanCanonicalize (H12AffineFastState.compose env20486 (packedSelected [1,8,9,10,15,16,18,19,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 3261) := by decide +kernel

theorem selectedBound20486 : packedSelected [1,8,9,10,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env20487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,3261,32768,34146,13388,36296,1024,32769,4161,47176,42360,41431,8328,65,3260,45176,44244,36928,1500,42432,256,6557,46213,42857]

theorem envBound20487 : H12AffineFastState.Bounded env20487 := by
  intro p hp
  have h : env20487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20486_20487 : H12AffineEnvironment.transform 13 3261 env20486 = env20487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3261 env20486 == env20487) = true)

theorem identity20487 : scanCanonicalize (H12AffineFastState.compose env20487 (packedSelected [5,8,15,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20487 : packedSelected [5,8,15,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,3261,5512,4330,13388,6208,1024,5513,4161,11712,12528,13407,8328,65,3260,9712,14684,1480,1500,12360,256,6557,8461,13025]

theorem envBound20488 : H12AffineFastState.Bounded env20488 := by
  intro p hp
  have h : env20488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20487_20488 : H12AffineEnvironment.transform 14 5512 env20487 = env20488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5512 env20487 == env20488) = true)

theorem identity20488 : scanCanonicalize (H12AffineFastState.compose env20488 (packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20488 : packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env20489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,3261,5512,4330,5441,6208,1024,5513,4161,3277,4605,5458,389,65,3260,1277,6225,1480,1500,4421,256,6557,0,5100]

theorem envBound20489 : H12AffineFastState.Bounded env20489 := by
  intro p hp
  have h : env20489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20488_20489 : H12AffineEnvironment.transform 12 269 env20488 = env20489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20488 == env20489) = true)

theorem identity20489 : scanCanonicalize (H12AffineFastState.compose env20489 (packedSelected [0,2,6,7,9,10,11,12,16,19,20,22] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound20489 : packedSelected [0,2,6,7,9,10,11,12,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,4096,269,292,5512,4330,5441,5593,1024,5513,4161,340,4605,5458,389,65,293,1277,5576,1480,1500,4421,256,5124,0,5100]

theorem envBound20490 : H12AffineFastState.Bounded env20490 := by
  intro p hp
  have h : env20490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20489_20490 : H12AffineEnvironment.transform 10 1433 env20489 = env20490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env20489 == env20490) = true)

theorem identity20490 : scanCanonicalize (H12AffineFastState.compose env20490 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound20490 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,493,269,292,1125,263,1196,1076,1024,1124,428,340,16,1215,389,65,293,1277,1061,1480,1500,168,256,1513,0,513]

theorem envBound20491 : H12AffineFastState.Bounded env20491 := by
  intro p hp
  have h : env20491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20490_20491 : H12AffineEnvironment.transform 11 493 env20490 = env20491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env20490 == env20491) = true)

theorem identity20491 : scanCanonicalize (H12AffineFastState.compose env20491 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20491 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env20492 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1345,309,269,292,1125,263,1140,1076,1024,1124,372,340,16,1127,349,65,293,1061,1061,1296,1284,112,256,1329,0,513]

theorem envBound20492 : H12AffineFastState.Bounded env20492 := by
  intro p hp
  have h : env20492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20491_20492 : H12AffineEnvironment.transform 6 88 env20491 = env20492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20491 == env20492) = true)

theorem identity20492 : scanCanonicalize (H12AffineFastState.compose env20492 (packedSelected [2,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound20492 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env20493 : List Nat := [2,4,8,16,32,64,88,256,512,321,0,309,269,292,292,263,309,373,321,293,372,340,16,294,349,65,293,356,356,81,69,112,256,112,0,513]

theorem envBound20493 : H12AffineFastState.Bounded env20493 := by
  intro p hp
  have h : env20493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20492_20493 : H12AffineEnvironment.transform 9 321 env20492 = env20493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env20492 == env20493) = true)

theorem identity20493 : scanCanonicalize (H12AffineFastState.compose env20493 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20493 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20494 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,309,269,292,292,263,309,293,273,293,292,260,16,294,269,17,293,308,308,1,21,32,256,32,0,513]

theorem envBound20494 : H12AffineFastState.Bounded env20494 := by
  intro p hp
  have h : env20494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20493_20494 : H12AffineEnvironment.transform 5 16 env20493 = env20494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20493 == env20494) = true)

theorem identity20494 : scanCanonicalize (H12AffineFastState.compose env20494 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20495 : List Nat := [2,4,8,16,1,16,8,256,512,273,0,276,269,261,261,263,276,260,273,260,261,260,16,263,269,17,260,277,277,1,21,1,256,1,0,513]

theorem envBound20495 : H12AffineFastState.Bounded env20495 := by
  intro p hp
  have h : env20495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20494_20495 : H12AffineEnvironment.transform 4 1 env20494 = env20495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20494 == env20495) = true)

theorem identity20495 : scanCanonicalize (H12AffineFastState.compose env20495 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20496 : List Nat := [2,4,8,16,1,16,8,4,512,21,0,16,9,1,1,3,16,0,21,0,1,0,16,3,9,17,0,17,17,1,21,1,4,1,0,513]

theorem envBound20496 : H12AffineFastState.Bounded env20496 := by
  intro p hp
  have h : env20496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20495_20496 : H12AffineEnvironment.transform 7 4 env20495 = env20496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20495 == env20496) = true)

def env20497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,67755,1024,32769,4161,62708,73754,41431,8328,65,100831,79130,91403,56573,1500,73891,256,21792,46213,74251]

theorem envBound20497 : H12AffineFastState.Bounded env20497 := by
  intro p hp
  have h : env20497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20484_20497 : H12AffineEnvironment.transform 16 13389 env20484 = env20497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env20484 == env20497) = true)

theorem identity20497 : scanCanonicalize (H12AffineFastState.compose env20497 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20497 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env20498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,13389,67755,1024,0,4161,29941,73754,8662,8328,65,68062,79130,91403,23804,1500,73891,256,21792,13444,74251]

theorem envBound20498 : H12AffineFastState.Bounded env20498 := by
  intro p hp
  have h : env20498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20497_20498 : H12AffineEnvironment.transform 14 1 env20497 = env20498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20497 == env20498) = true)

theorem identity20498 : scanCanonicalize (H12AffineFastState.compose env20498 (packedSelected [0,1,2,5,6,7,8,9,10,11,15,16,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound20498 : packedSelected [0,1,2,5,6,7,8,9,10,11,15,16,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env20499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,29962,13389,32161,1024,0,4161,29941,21776,8662,8328,65,31956,16400,4097,23804,1500,21929,256,21792,13444,22273]

theorem envBound20499 : H12AffineFastState.Bounded env20499 := by
  intro p hp
  have h : env20499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20498_20499 : H12AffineEnvironment.transform 15 29962 env20498 = env20499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env20498 == env20499) = true)

theorem identity20499 : scanCanonicalize (H12AffineFastState.compose env20499 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20499 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env20500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,1,8322,13389,10281,1024,0,4161,8573,152,8662,8328,65,10588,5528,4097,2420,1500,33,256,168,13444,649]

theorem envBound20500 : H12AffineFastState.Bounded env20500 := by
  intro p hp
  have h : env20500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20499_20500 : H12AffineEnvironment.transform 13 5512 env20499 = env20500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20499 == env20500) = true)

theorem identity20500 : scanCanonicalize (H12AffineFastState.compose env20500 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20500 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env20501 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5456,1,8282,13389,10281,1024,0,4161,8573,64,8462,8272,65,10588,5440,4097,2420,1284,33,256,112,13404,593]

theorem envBound20501 : H12AffineFastState.Bounded env20501 := by
  intro p hp
  have h : env20501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20500_20501 : H12AffineEnvironment.transform 6 88 env20500 = env20501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20500 == env20501) = true)

theorem identity20501 : scanCanonicalize (H12AffineFastState.compose env20501 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20501 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env20502 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,1,343,5440,2340,1024,0,4161,112,64,3,349,65,2129,5440,4097,2420,1284,33,256,112,5457,593]

theorem envBound20502 : H12AffineFastState.Bounded env20502 := by
  intro p hp
  have h : env20502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20501_20502 : H12AffineEnvironment.transform 12 269 env20501 = env20502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20501 == env20502) = true)

theorem identity20502 : scanCanonicalize (H12AffineFastState.compose env20502 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound20502 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20503 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2049,269,3409,1,343,3393,2340,1024,0,2112,112,64,3,349,65,2129,3393,2048,2420,1284,33,256,112,3408,593]

theorem envBound20503 : H12AffineFastState.Bounded env20503 := by
  intro p hp
  have h : env20503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20502_20503 : H12AffineEnvironment.transform 11 2049 env20502 = env20503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env20502 == env20503) = true)

theorem identity20503 : scanCanonicalize (H12AffineFastState.compose env20503 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20503 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20504 : List Nat := [2,4,8,16,32,32,56,256,512,1024,2048,2049,269,3377,1,311,3361,2340,1024,0,2080,16,32,3,317,33,2097,3361,2048,2324,1284,33,256,16,3376,561]

theorem envBound20504 : H12AffineFastState.Bounded env20504 := by
  intro p hp
  have h : env20504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20503_20504 : H12AffineEnvironment.transform 5 32 env20503 = env20504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20503 == env20504) = true)

theorem identity20504 : scanCanonicalize (H12AffineFastState.compose env20504 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound20504 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env20505 : List Nat := [2,4,8,16,32,32,56,256,512,266,2048,2049,269,2107,1,311,2091,2340,266,0,2080,16,32,3,317,33,2097,2091,2048,2324,14,33,256,16,2106,561]

theorem envBound20505 : H12AffineFastState.Bounded env20505 := by
  intro p hp
  have h : env20505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20504_20505 : H12AffineEnvironment.transform 9 266 env20504 = env20505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env20504 == env20505) = true)

theorem identity20505 : scanCanonicalize (H12AffineFastState.compose env20505 (packedSelected [6,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20505 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env20506 : List Nat := [2,4,8,16,17,17,9,256,512,266,2048,2049,269,2058,1,262,2074,2325,266,0,2065,16,17,3,268,16,2048,2074,2048,2324,14,16,256,16,2059,512]

theorem envBound20506 : H12AffineFastState.Bounded env20506 := by
  intro p hp
  have h : env20506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20505_20506 : H12AffineEnvironment.transform 4 17 env20505 = env20506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20505 == env20506) = true)

theorem identity20506 : scanCanonicalize (H12AffineFastState.compose env20506 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound20506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20507 : List Nat := [2,4,8,16,17,17,9,256,512,266,270,271,269,260,1,262,276,27,266,0,287,16,17,3,268,16,270,276,270,26,14,16,256,16,261,512]

theorem envBound20507 : H12AffineFastState.Bounded env20507 := by
  intro p hp
  have h : env20507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20506_20507 : H12AffineEnvironment.transform 10 270 env20506 = env20507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env20506 == env20507) = true)

theorem identity20507 : scanCanonicalize (H12AffineFastState.compose env20507 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20507 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20508 : List Nat := [2,4,2,16,17,17,3,256,512,256,260,261,263,260,1,262,276,17,256,0,277,16,17,3,262,16,260,276,260,16,4,16,256,16,261,512]

theorem envBound20508 : H12AffineFastState.Bounded env20508 := by
  intro p hp
  have h : env20508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20507_20508 : H12AffineEnvironment.transform 2 2 env20507 = env20508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20507 == env20508) = true)

theorem identity20508 : scanCanonicalize (H12AffineFastState.compose env20508 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound20508 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20509 : List Nat := [2,4,2,16,17,17,3,256,276,256,260,261,263,260,1,262,276,17,256,0,277,16,17,3,262,16,260,276,260,16,4,16,256,16,261,276]

theorem envBound20509 : H12AffineFastState.Bounded env20509 := by
  intro p hp
  have h : env20509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20508_20509 : H12AffineEnvironment.transform 8 276 env20508 = env20509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env20508 == env20509) = true)

theorem identity20509 : scanCanonicalize (H12AffineFastState.compose env20509 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound20509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20510 : List Nat := [2,4,2,16,17,17,3,3,23,3,7,6,4,7,1,5,23,17,3,0,22,16,17,3,5,16,7,23,7,16,4,16,3,16,6,23]

theorem envBound20510 : H12AffineFastState.Bounded env20510 := by
  intro p hp
  have h : env20510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20509_20510 : H12AffineEnvironment.transform 7 3 env20509 = env20510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env20509 == env20510) = true)

theorem identity20510 : scanCanonicalize (H12AffineFastState.compose env20510 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20510 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20511 : List Nat := [2,4,2,1,0,0,3,3,6,3,7,6,4,7,1,5,6,0,3,0,7,1,0,3,5,1,7,6,7,1,4,1,3,1,6,6]

theorem envBound20511 : H12AffineFastState.Bounded env20511 := by
  intro p hp
  have h : env20511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20510_20511 : H12AffineEnvironment.transform 3 1 env20510 = env20511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20510 == env20511) = true)

theorem identity20511 : scanCanonicalize (H12AffineFastState.compose env20511 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound20511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20512 : List Nat := [0,4,0,1,0,0,1,1,4,1,5,4,4,5,1,5,4,0,1,0,5,1,0,1,5,1,5,4,5,1,4,1,1,1,4,4]

theorem envBound20512 : H12AffineFastState.Bounded env20512 := by
  intro p hp
  have h : env20512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20511_20512 : H12AffineEnvironment.transform 0 0 env20511 = env20512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env20511 == env20512) = true)

theorem identity20512 : scanCanonicalize (H12AffineFastState.compose env20512 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20512 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20513 : List Nat := [0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,1,0,0,1,0,1,1,0,1,1,1,1,0,1,1,0,1,1,1,0,0]

theorem envBound20513 : H12AffineFastState.Bounded env20513 := by
  intro p hp
  have h : env20513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20512_20513 : H12AffineEnvironment.transform 1 0 env20512 = env20513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20512 == env20513) = true)

def env20514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound20514 : H12AffineFastState.Bounded env20514 := by
  intro p hp
  have h : env20514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20318_20514 : H12AffineEnvironment.transform 18 1025 env20318 = env20514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20318 == env20514) = true)

theorem identity20514 : scanCanonicalize (H12AffineFastState.compose env20514 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485309) := by decide +kernel

theorem selectedBound20514 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485309,8328,65,14822460,288944,10507600,8830976,10774572,4491772,257,8661136,8702260,10833914]

theorem envBound20515 : H12AffineFastState.Bounded env20515 := by
  intro p hp
  have h : env20515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20514_20515 : H12AffineEnvironment.transform 23 2485309 env20514 = env20515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485309 env20514 == env20515) = true)

def env20516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294320,2485309,8328,65,6705548,288944,2369760,179632,2102684,4491772,257,21792,46212,2175562]

theorem envBound20516 : H12AffineFastState.Bounded env20516 := by
  intro p hp
  have h : env20516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20515_20516 : H12AffineEnvironment.transform 22 294320 env20515 = env20516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294320 env20515 == env20516) = true)

def env20517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294320,98781,8328,65,4340844,288944,17664,179632,292988,4491772,257,21792,46212,352170]

theorem envBound20517 : H12AffineFastState.Bounded env20517 := by
  intro p hp
  have h : env20517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20516_20517 : H12AffineEnvironment.transform 20 290272 env20516 = env20517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env20516 == env20517) = true)

def env20518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294320,98781,8328,65,398572,288944,17664,179632,292988,41340,257,21792,46212,352170]

theorem envBound20518 : H12AffineFastState.Bounded env20518 := by
  intro p hp
  have h : env20518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20517_20518 : H12AffineEnvironment.transform 21 272512 env20517 = env20518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20517 == env20518) = true)

def env20519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272392,294200,98645,8192,65,398436,288824,17664,179512,292988,41340,257,21792,46092,352034]

theorem envBound20519 : H12AffineFastState.Bounded env20519 := by
  intro p hp
  have h : env20519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20518_20519 : H12AffineEnvironment.transform 6 8 env20518 = env20519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20518 == env20519) = true)

theorem identity20519 : scanCanonicalize (H12AffineFastState.compose env20519 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204083) := by decide +kernel

theorem selectedBound20519 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,204083,1025,32769,225371,210235,221195,98645,8192,65,67927,226571,17664,179512,222543,41340,257,21792,46092,147985]

theorem envBound20520 : H12AffineFastState.Bounded env20520 := by
  intro p hp
  have h : env20520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20519_20520 : H12AffineEnvironment.transform 17 204083 env20519 = env20520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204083 env20519 == env20520) = true)

theorem identity20520 : scanCanonicalize (H12AffineFastState.compose env20520 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound20520 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103494,35189,1025,32769,58397,41341,62541,98645,8192,65,67927,57677,17664,76158,61705,41340,257,21792,46092,120407]

theorem envBound20521 : H12AffineFastState.Bounded env20521 := by
  intro p hp
  have h : env20521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20520_20521 : H12AffineEnvironment.transform 16 103494 env20520 = env20521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env20520 == env20521) = true)

theorem identity20521 : scanCanonicalize (H12AffineFastState.compose env20521 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20521 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,32040,1025,29788,4160,21792,16,95496,8192,65,67927,5392,17664,76158,1364,21793,257,21792,16465,74250]

theorem envBound20522 : H12AffineFastState.Bounded env20522 := by
  intro p hp
  have h : env20522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20521_20522 : H12AffineEnvironment.transform 14 29789 env20521 = env20522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20521 == env20522) = true)

theorem identity20522 : scanCanonicalize (H12AffineFastState.compose env20522 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,32040,1025,29788,4160,21792,16,21763,8192,65,10588,5392,17664,2421,1364,21793,257,21792,16465,513]

theorem envBound20523 : H12AffineFastState.Bounded env20523 := by
  intro p hp
  have h : env20523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20522_20523 : H12AffineEnvironment.transform 15 8203 env20522 = env20523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20522 == env20523) = true)

theorem identity20523 : scanCanonicalize (H12AffineFastState.compose env20523 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound20523 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,20545,1047,16400,22836,1025,20544,4160,21792,16,21763,1052,65,3392,5392,17664,2421,1364,21793,257,21792,16465,513]

theorem envBound20524 : H12AffineFastState.Bounded env20524 := by
  intro p hp
  have h : env20524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20523_20524 : H12AffineEnvironment.transform 12 1052 env20523 = env20524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env20523 == env20524) = true)

theorem identity20524 : scanCanonicalize (H12AffineFastState.compose env20524 (packedSelected [0,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound20524 : packedSelected [0,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env20525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,7204,3173,1047,7220,1296,1025,3172,4160,2308,16,2343,1052,65,3392,5392,6436,2421,1364,2309,257,2308,7285,513]

theorem envBound20525 : H12AffineFastState.Bounded env20525 := by
  intro p hp
  have h : env20525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20524_20525 : H12AffineEnvironment.transform 13 7204 env20524 = env20525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env20524 == env20525) = true)

theorem identity20525 : scanCanonicalize (H12AffineFastState.compose env20525 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound20525 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,1052,3173,3173,1047,3189,1296,1025,3172,1,2308,16,2343,1052,65,3392,1361,2405,2421,1364,2309,257,2308,3124,513]

theorem envBound20526 : H12AffineFastState.Bounded env20526 := by
  intro p hp
  have h : env20526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20525_20526 : H12AffineEnvironment.transform 11 65 env20525 = env20526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env20525 == env20526) = true)

theorem identity20526 : scanCanonicalize (H12AffineFastState.compose env20526 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20526 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env20527 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,65,41,2128,2128,34,2112,293,52,2129,1,2308,16,2343,41,65,2421,356,2405,2421,353,2309,257,2308,2049,513]

theorem envBound20527 : H12AffineFastState.Bounded env20527 := by
  intro p hp
  have h : env20527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20526_20527 : H12AffineEnvironment.transform 9 53 env20526 = env20527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20526 == env20527) = true)

theorem identity20527 : scanCanonicalize (H12AffineFastState.compose env20527 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20527 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20528 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,65,41,2128,2128,34,2112,1,52,2129,1,2080,16,2051,41,65,2129,64,2113,2129,69,2081,37,2080,2049,513]

theorem envBound20528 : H12AffineFastState.Bounded env20528 := by
  intro p hp
  have h : env20528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20527_20528 : H12AffineEnvironment.transform 7 36 env20527 = env20528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20527 == env20528) = true)

theorem identity20528 : scanCanonicalize (H12AffineFastState.compose env20528 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20528 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20529 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,16,41,2049,2049,34,2065,1,52,2048,1,2080,16,2051,41,16,2048,17,2064,2048,20,2081,37,2080,2049,513]

theorem envBound20529 : H12AffineFastState.Bounded env20529 := by
  intro p hp
  have h : env20529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20528_20529 : H12AffineEnvironment.transform 5 17 env20528 = env20529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20528 == env20529) = true)

theorem identity20529 : scanCanonicalize (H12AffineFastState.compose env20529 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound20529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20530 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,1,1,34,17,1,52,0,1,32,16,3,41,16,0,17,16,0,20,33,37,32,1,513]

theorem envBound20530 : H12AffineFastState.Bounded env20530 := by
  intro p hp
  have h : env20530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20529_20530 : H12AffineEnvironment.transform 10 0 env20529 = env20530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20529 == env20530) = true)

theorem identity20530 : scanCanonicalize (H12AffineFastState.compose env20530 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound20530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20531 : List Nat := [2,4,8,16,32,17,8,36,49,53,0,16,41,1,1,34,17,1,52,0,1,32,16,3,41,16,0,17,16,0,20,33,37,32,1,48]

theorem envBound20531 : H12AffineFastState.Bounded env20531 := by
  intro p hp
  have h : env20531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20530_20531 : H12AffineEnvironment.transform 8 49 env20530 = env20531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env20530 == env20531) = true)

def env20532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294201,98644,8193,65,398437,288825,17664,179513,292988,41340,257,21792,46093,352035]

theorem envBound20532 : H12AffineFastState.Bounded env20532 := by
  intro p hp
  have h : env20532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20518_20532 : H12AffineEnvironment.transform 6 9 env20518 = env20532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20518 == env20532) = true)

def env20533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,276585,272393,272441,98644,8193,65,398437,277817,4096,179513,273788,41340,257,32,46093,330275]

theorem envBound20533 : H12AffineFastState.Bounded env20533 := by
  intro p hp
  have h : env20533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20532_20533 : H12AffineEnvironment.transform 13 5376 env20532 = env20533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20532 == env20533) = true)

theorem identity20533 : scanCanonicalize (H12AffineFastState.compose env20533 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound20533 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1025,32769,77899,73771,73755,98644,8193,65,203847,79131,4096,179513,75102,41340,257,32,46093,513]

theorem envBound20534 : H12AffineFastState.Bounded env20534 := by
  intro p hp
  have h : env20534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20533_20534 : H12AffineEnvironment.transform 17 67618 env20533 = env20534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env20533 == env20534) = true)

theorem identity20534 : scanCanonicalize (H12AffineFastState.compose env20534 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20534 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67618,1025,8541,77899,73771,73755,73736,8193,65,203847,79131,4096,138341,75102,32,257,32,5457,513]

theorem envBound20535 : H12AffineFastState.Bounded env20535 := by
  intro p hp
  have h : env20535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20534_20535 : H12AffineEnvironment.transform 14 8540 env20534 = env20535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20534 == env20535) = true)

theorem identity20535 : scanCanonicalize (H12AffineFastState.compose env20535 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20535 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,131072,67618,1025,1,69911,65911,65863,65876,349,65,203847,70727,4096,138341,66562,32,257,32,5457,513]

theorem envBound20536 : H12AffineFastState.Bounded env20536 := by
  intro p hp
  have h : env20536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20535_20536 : H12AffineEnvironment.transform 12 348 env20535 = env20536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20535 == env20536) = true)

theorem identity20536 : scanCanonicalize (H12AffineFastState.compose env20536 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound20536 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env20537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,70679,67618,1025,1,69911,65911,65863,65876,349,65,2128,70727,4096,67698,66562,32,257,32,5457,513]

theorem envBound20537 : H12AffineFastState.Bounded env20537 := by
  intro p hp
  have h : env20537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20536_20537 : H12AffineEnvironment.transform 16 70679 env20536 = env20537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env20536 == env20537) = true)

theorem identity20537 : scanCanonicalize (H12AffineFastState.compose env20537 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound20537 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,7538,2405,5456,1025,1,3173,7173,7221,7206,349,65,2128,2357,4096,5376,6512,32,257,32,5457,513]

theorem envBound20538 : H12AffineFastState.Bounded env20538 := by
  intro p hp
  have h : env20538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20537_20538 : H12AffineEnvironment.transform 15 7538 env20537 = env20538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env20537 == env20538) = true)

theorem identity20538 : scanCanonicalize (H12AffineFastState.compose env20538 (packedSelected [1,3,4,5,8,9,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20538 : packedSelected [1,3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env20539 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,7458,2357,5376,1025,1,3125,7173,7221,7206,269,17,2048,2357,4096,5376,6432,32,257,32,5377,513]

theorem envBound20539 : H12AffineFastState.Bounded env20539 := by
  intro p hp
  have h : env20539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20538_20539 : H12AffineEnvironment.transform 5 16 env20538 = env20539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20538 == env20539) = true)

theorem identity20539 : scanCanonicalize (H12AffineFastState.compose env20539 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound20539 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env20540 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,268,3345,0,1331,2357,3345,1025,1,3125,1044,1060,1079,269,17,2048,2357,2065,3345,305,32,257,32,3344,513]

theorem envBound20540 : H12AffineFastState.Bounded env20540 := by
  intro p hp
  have h : env20540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20539_20540 : H12AffineEnvironment.transform 11 2065 env20539 = env20540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env20539 == env20540) = true)

theorem identity20540 : scanCanonicalize (H12AffineFastState.compose env20540 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20541 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2065,268,2340,0,262,2357,2340,52,1,2048,33,17,2,269,17,2048,2357,2065,2340,305,32,257,32,2341,513]

theorem envBound20541 : H12AffineFastState.Bounded env20541 := by
  intro p hp
  have h : env20541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20540_20541 : H12AffineEnvironment.transform 9 53 env20540 = env20541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20540 == env20541) = true)

theorem identity20541 : scanCanonicalize (H12AffineFastState.compose env20541 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20541 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20542 : List Nat := [2,4,8,16,0,16,9,256,512,21,2048,2065,268,2308,0,262,2325,2308,20,1,2048,1,17,2,269,17,2048,2325,2065,2308,273,0,257,0,2309,513]

theorem envBound20542 : H12AffineFastState.Bounded env20542 := by
  intro p hp
  have h : env20542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20541_20542 : H12AffineEnvironment.transform 4 0 env20541 = env20542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20541 == env20542) = true)

theorem identity20542 : scanCanonicalize (H12AffineFastState.compose env20542 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound20542 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20543 : List Nat := [2,4,8,16,0,16,9,256,512,21,773,788,268,513,0,262,528,513,20,1,773,1,17,2,269,17,773,528,788,513,273,0,257,0,512,513]

theorem envBound20543 : H12AffineFastState.Bounded env20543 := by
  intro p hp
  have h : env20543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20542_20543 : H12AffineEnvironment.transform 10 773 env20542 = env20543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env20542 == env20543) = true)

theorem identity20543 : scanCanonicalize (H12AffineFastState.compose env20543 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20543 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20544 : List Nat := [2,4,8,0,0,0,9,256,512,5,773,772,268,513,0,262,512,513,4,1,773,1,1,2,269,1,773,512,772,513,257,0,257,0,512,513]

theorem envBound20544 : H12AffineFastState.Bounded env20544 := by
  intro p hp
  have h : env20544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20543_20544 : H12AffineEnvironment.transform 3 0 env20543 = env20544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20543 == env20544) = true)

theorem identity20544 : scanCanonicalize (H12AffineFastState.compose env20544 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20544 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20545 : List Nat := [2,4,8,0,0,0,9,4,512,5,513,512,8,513,0,2,512,513,4,1,513,1,1,2,9,1,513,512,512,513,5,0,5,0,512,513]

theorem envBound20545 : H12AffineFastState.Bounded env20545 := by
  intro p hp
  have h : env20545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20544_20545 : H12AffineEnvironment.transform 7 4 env20544 = env20545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20544 == env20545) = true)

theorem identity20545 : scanCanonicalize (H12AffineFastState.compose env20545 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20546 : List Nat := [2,4,8,0,0,0,9,4,1,5,0,1,8,0,0,2,1,0,4,1,0,1,1,2,9,1,0,1,1,0,5,0,5,0,1,0]

theorem envBound20546 : H12AffineFastState.Bounded env20546 := by
  intro p hp
  have h : env20546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20545_20546 : H12AffineEnvironment.transform 8 1 env20545 = env20546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20545 == env20546) = true)

def env20547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1025,32769,276584,272393,272440,98644,8193,65,398437,277816,4097,179513,273789,41340,257,33,46093,330274]

theorem envBound20547 : H12AffineFastState.Bounded env20547 := by
  intro p hp
  have h : env20547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20532_20547 : H12AffineEnvironment.transform 13 5377 env20532 = env20547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20532 == env20547) = true)

theorem identity20547 : scanCanonicalize (H12AffineFastState.compose env20547 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1025,32769,276584,272393,272440,41310,8193,65,398437,277816,4097,179513,273789,41340,257,33,46093,272936]

theorem envBound20548 : H12AffineFastState.Bounded env20548 := by
  intro p hp
  have h : env20548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20547_20548 : H12AffineEnvironment.transform 15 8202 env20547 = env20548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20547 == env20548) = true)

theorem identity20548 : scanCanonicalize (H12AffineFastState.compose env20548 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20548 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env20549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,263,131072,262144,1025,32769,268645,264452,264501,32851,268,65,398437,269365,4097,171060,265328,32881,257,33,38144,264997]

theorem envBound20549 : H12AffineFastState.Bounded env20549 := by
  intro p hp
  have h : env20549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20548_20549 : H12AffineEnvironment.transform 12 269 env20548 = env20549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20548 == env20549) = true)

theorem identity20549 : scanCanonicalize (H12AffineFastState.compose env20549 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 38209) := by decide +kernel

theorem selectedBound20549 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env20550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,263,38209,262144,1025,32769,268645,264452,264501,32851,268,65,295204,269365,4097,2421,265328,32881,257,33,38144,264997]

theorem envBound20550 : H12AffineFastState.Bounded env20550 := by
  intro p hp
  have h : env20550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20549_20550 : H12AffineEnvironment.transform 16 38209 env20549 = env20550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38209 env20549 == env20550) = true)

theorem identity20550 : scanCanonicalize (H12AffineFastState.compose env20550 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound20550 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,263,5393,262144,1025,81,268645,264452,264501,3,268,65,262516,269365,4097,2421,265328,33,257,33,5456,264997]

theorem envBound20551 : H12AffineFastState.Bounded env20551 := by
  intro p hp
  have h : env20551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20550_20551 : H12AffineEnvironment.transform 14 80 env20550 = env20551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env20550 == env20551) = true)

theorem identity20551 : scanCanonicalize (H12AffineFastState.compose env20551 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20551 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,80,263,5393,4112,1025,81,2421,6420,6437,3,268,65,4452,3109,4097,2421,7264,33,257,33,5456,6965]

theorem envBound20552 : H12AffineFastState.Bounded env20552 := by
  intro p hp
  have h : env20552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20551_20552 : H12AffineEnvironment.transform 17 4112 env20551 = env20552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env20551 == env20552) = true)

theorem identity20552 : scanCanonicalize (H12AffineFastState.compose env20552 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound20552 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20553 : List Nat := [2,4,8,16,32,64,9,256,325,1024,2048,4096,269,5377,80,263,5393,4112,1025,81,2421,6420,6437,3,268,65,4452,3109,4097,2421,7264,33,257,33,5456,6256]

theorem envBound20553 : H12AffineFastState.Bounded env20553 := by
  intro p hp
  have h : env20553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20552_20553 : H12AffineEnvironment.transform 8 325 env20552 = env20553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env20552 == env20553) = true)

theorem identity20553 : scanCanonicalize (H12AffineFastState.compose env20553 (packedSelected [0,2,3,5,6,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound20553 : packedSelected [0,2,3,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env20554 : List Nat := [2,4,8,16,32,64,9,256,325,1024,2048,2097,269,3376,80,263,3360,2081,1025,81,2421,293,276,3,268,65,2389,3109,2096,2421,1105,33,257,33,3425,65]

theorem envBound20554 : H12AffineFastState.Bounded env20554 := by
  intro p hp
  have h : env20554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20553_20554 : H12AffineEnvironment.transform 11 2097 env20553 = env20554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env20553 == env20554) = true)

theorem identity20554 : scanCanonicalize (H12AffineFastState.compose env20554 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound20554 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env20555 : List Nat := [2,4,8,16,32,64,9,84,17,1024,2048,2097,89,3172,80,83,3188,2081,1025,81,2081,113,64,3,88,65,2049,3109,2096,2081,1105,33,85,33,3125,65]

theorem envBound20555 : H12AffineFastState.Bounded env20555 := by
  intro p hp
  have h : env20555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20554_20555 : H12AffineEnvironment.transform 7 84 env20554 = env20555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env20554 == env20555) = true)

theorem identity20555 : scanCanonicalize (H12AffineFastState.compose env20555 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1108) := by decide +kernel

theorem selectedBound20555 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20556 : List Nat := [2,4,8,16,32,64,9,84,17,1024,1108,1125,89,48,80,83,32,1141,1025,81,1141,113,64,3,88,65,1109,113,1124,1141,1105,33,85,33,97,65]

theorem envBound20556 : H12AffineFastState.Bounded env20556 := by
  intro p hp
  have h : env20556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20555_20556 : H12AffineEnvironment.transform 10 1108 env20555 = env20556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1108 env20555 == env20556) = true)

theorem identity20556 : scanCanonicalize (H12AffineFastState.compose env20556 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound20556 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env20557 : List Nat := [2,4,8,16,32,64,9,84,17,36,112,65,89,48,80,83,32,81,37,81,81,113,64,3,88,65,113,113,64,81,117,33,85,33,97,65]

theorem envBound20557 : H12AffineFastState.Bounded env20557 := by
  intro p hp
  have h : env20557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20556_20557 : H12AffineEnvironment.transform 9 36 env20556 = env20557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env20556 == env20557) = true)

theorem identity20557 : scanCanonicalize (H12AffineFastState.compose env20557 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound20557 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20558 : List Nat := [2,4,8,16,32,0,9,20,17,36,48,1,25,48,16,19,32,17,37,17,17,49,0,3,24,1,49,49,0,17,53,33,21,33,33,1]

theorem envBound20558 : H12AffineFastState.Bounded env20558 := by
  intro p hp
  have h : env20558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20557_20558 : H12AffineEnvironment.transform 5 0 env20557 = env20558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env20557 == env20558) = true)

theorem identity20558 : scanCanonicalize (H12AffineFastState.compose env20558 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20559 : List Nat := [2,4,8,0,32,0,9,4,1,36,32,1,9,32,0,3,32,1,37,1,1,33,0,3,8,1,33,33,0,1,37,33,5,33,33,1]

theorem envBound20559 : H12AffineFastState.Bounded env20559 := by
  intro p hp
  have h : env20559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20558_20559 : H12AffineEnvironment.transform 3 0 env20558 = env20559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20558 == env20559) = true)

theorem identity20559 : scanCanonicalize (H12AffineFastState.compose env20559 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20559 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20560 : List Nat := [2,4,8,0,0,0,9,4,1,4,0,1,9,0,0,3,0,1,5,1,1,1,0,3,8,1,1,1,0,1,5,1,5,1,1,1]

theorem envBound20560 : H12AffineFastState.Bounded env20560 := by
  intro p hp
  have h : env20560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20559_20560 : H12AffineEnvironment.transform 4 0 env20559 = env20560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20559 == env20560) = true)

theorem identity20560 : scanCanonicalize (H12AffineFastState.compose env20560 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20561 : List Nat := [2,1,8,0,0,0,9,1,1,1,0,1,9,0,0,3,0,1,0,1,1,1,0,3,8,1,1,1,0,1,0,1,0,1,1,1]

theorem envBound20561 : H12AffineFastState.Bounded env20561 := by
  intro p hp
  have h : env20561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20560_20561 : H12AffineEnvironment.transform 1 1 env20560 = env20561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20560 == env20561) = true)

def env20562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294320,98781,8328,65,398573,288944,17664,179632,292988,41341,257,21792,46212,352170]

theorem envBound20562 : H12AffineFastState.Bounded env20562 := by
  intro p hp
  have h : env20562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20517_20562 : H12AffineEnvironment.transform 21 272513 env20517 = env20562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20517 == env20562) = true)

theorem identity20562 : scanCanonicalize (H12AffineFastState.compose env20562 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound20562 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21792,17,98781,8328,65,158028,5393,17664,179632,1501,41341,257,21792,46212,74251]

theorem envBound20563 : H12AffineFastState.Bounded env20563 := by
  intro p hp
  have h : env20563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20562_20563 : H12AffineEnvironment.transform 17 32161 env20562 = env20563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env20562 == env20563) = true)

theorem identity20563 : scanCanonicalize (H12AffineFastState.compose env20563 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20563 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,17,41431,8328,65,158028,5393,17664,179632,1501,41341,257,21792,46212,513]

theorem envBound20564 : H12AffineFastState.Bounded env20564 := by
  intro p hp
  have h : env20564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20563_20564 : H12AffineEnvironment.transform 15 8202 env20563 = env20564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20563 == env20564) = true)

theorem identity20564 : scanCanonicalize (H12AffineFastState.compose env20564 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20564 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env20565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,131072,23589,1025,32769,4161,21792,17,32851,268,65,149704,5393,17664,171060,1501,33017,257,21792,38144,513]

theorem envBound20565 : H12AffineFastState.Bounded env20565 := by
  intro p hp
  have h : env20565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20564_20565 : H12AffineEnvironment.transform 12 388 env20564 = env20565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20564 == env20565) = true)

theorem identity20565 : scanCanonicalize (H12AffineFastState.compose env20565 (packedSelected [4,9,14,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound20565 : packedSelected [4,9,14,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env20566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,49305,23589,1025,32769,4161,21792,17,32851,268,65,34897,5393,17664,23725,1501,33017,257,21792,38144,513]

theorem envBound20566 : H12AffineFastState.Bounded env20566 := by
  intro p hp
  have h : env20566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20565_20566 : H12AffineEnvironment.transform 16 49305 env20565 = env20566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env20565 == env20566) = true)

theorem identity20566 : scanCanonicalize (H12AffineFastState.compose env20566 (packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20566 : packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,0,398,16537,23589,1025,1,4161,21792,17,83,268,65,2129,5393,17664,23725,1501,249,257,21792,5376,513]

theorem envBound20567 : H12AffineFastState.Bounded env20567 := by
  intro p hp
  have h : env20567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20566_20567 : H12AffineEnvironment.transform 14 0 env20566 = env20567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20566 == env20567) = true)

theorem identity20567 : scanCanonicalize (H12AffineFastState.compose env20567 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20567 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20568 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,0,343,16448,23589,1025,1,4161,21792,17,83,268,65,2129,5393,17664,23668,1284,32,257,21792,5376,513]

theorem envBound20568 : H12AffineFastState.Bounded env20568 := by
  intro p hp
  have h : env20568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20567_20568 : H12AffineEnvironment.transform 6 89 env20567 = env20568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20567 == env20568) = true)

theorem identity20568 : scanCanonicalize (H12AffineFastState.compose env20568 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound20568 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20569 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,3393,0,343,3329,4452,1025,1,4161,6241,17,83,268,65,2129,5393,2113,4405,1284,32,257,6241,5376,513]

theorem envBound20569 : H12AffineFastState.Bounded env20569 := by
  intro p hp
  have h : env20569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20568_20569 : H12AffineEnvironment.transform 13 3393 env20568 = env20569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env20568 == env20569) = true)

theorem identity20569 : scanCanonicalize (H12AffineFastState.compose env20569 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound20569 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env20570 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3108,349,3393,0,343,3329,3392,1025,1,3173,1093,17,83,268,65,2129,2357,2113,3345,1284,32,257,1093,2340,513]

theorem envBound20570 : H12AffineFastState.Bounded env20570 := by
  intro p hp
  have h : env20570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20569_20570 : H12AffineEnvironment.transform 11 3108 env20569 = env20570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env20569 == env20570) = true)

theorem identity20570 : scanCanonicalize (H12AffineFastState.compose env20570 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20570 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env20571 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,2064,349,2421,0,343,2357,2420,53,1,2129,113,17,83,268,65,2129,2357,2113,2341,304,32,257,113,2340,513]

theorem envBound20571 : H12AffineFastState.Bounded env20571 := by
  intro p hp
  have h : env20571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20570_20571 : H12AffineEnvironment.transform 9 52 env20570 = env20571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20570 == env20571) = true)

theorem identity20571 : scanCanonicalize (H12AffineFastState.compose env20571 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20571 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20572 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,268,2340,0,262,2357,2341,53,1,2048,32,17,2,268,16,2048,2357,2064,2341,304,32,257,32,2340,513]

theorem envBound20572 : H12AffineFastState.Bounded env20572 := by
  intro p hp
  have h : env20572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20571_20572 : H12AffineEnvironment.transform 5 17 env20571 = env20572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20571 == env20572) = true)

theorem identity20572 : scanCanonicalize (H12AffineFastState.compose env20572 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20573 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2064,41,2049,0,35,2064,2048,53,1,2048,32,17,2,41,16,2048,2064,2064,2048,21,32,36,32,2049,513]

theorem envBound20573 : H12AffineFastState.Bounded env20573 := by
  intro p hp
  have h : env20573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20572_20573 : H12AffineEnvironment.transform 7 37 env20572 = env20573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20572 == env20573) = true)

theorem identity20573 : scanCanonicalize (H12AffineFastState.compose env20573 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20574 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,8,2049,0,2,2064,2048,20,1,2048,1,17,2,8,16,2048,2064,2064,2048,21,1,5,1,2049,513]

theorem envBound20574 : H12AffineFastState.Bounded env20574 := by
  intro p hp
  have h : env20574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20573_20574 : H12AffineEnvironment.transform 4 1 env20573 = env20574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20573 == env20574) = true)

theorem identity20574 : scanCanonicalize (H12AffineFastState.compose env20574 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20575 : List Nat := [2,4,8,1,1,0,8,4,512,4,2048,2049,8,2049,0,2,2049,2048,5,1,2048,1,0,2,8,1,2048,2049,2049,2048,4,1,5,1,2049,513]

theorem envBound20575 : H12AffineFastState.Bounded env20575 := by
  intro p hp
  have h : env20575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20574_20575 : H12AffineEnvironment.transform 3 1 env20574 = env20575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20574 == env20575) = true)

def env20576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294320,98780,8328,65,4340845,288944,17665,179632,292989,4491772,257,21792,46212,352171]

theorem envBound20576 : H12AffineFastState.Bounded env20576 := by
  intro p hp
  have h : env20576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20516_20576 : H12AffineEnvironment.transform 20 290273 env20516 = env20576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env20516 == env20576) = true)

def env20577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294320,98780,8328,65,398573,288944,17665,179632,292989,41340,257,21792,46212,352171]

theorem envBound20577 : H12AffineFastState.Bounded env20577 := by
  intro p hp
  have h : env20577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20576_20577 : H12AffineEnvironment.transform 21 272512 env20576 = env20577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20576 == env20577) = true)

theorem identity20577 : scanCanonicalize (H12AffineFastState.compose env20577 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20577 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,290273,272512,294320,95497,8328,65,398573,288944,17665,149861,292989,21929,257,21792,16465,352171]

theorem envBound20578 : H12AffineFastState.Bounded env20578 := by
  intro p hp
  have h : env20578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20577_20578 : H12AffineEnvironment.transform 14 29909 env20577 = env20578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20577 == env20578) = true)

def env20579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1025,8660,276705,272512,272560,73737,8328,65,398573,277936,4097,138341,273789,169,257,32,5457,330411]

theorem envBound20579 : H12AffineFastState.Bounded env20579 := by
  intro p hp
  have h : env20579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20578_20579 : H12AffineEnvironment.transform 13 5376 env20578 = env20579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20578 == env20579) = true)

theorem identity20579 : scanCanonicalize (H12AffineFastState.compose env20579 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound20579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,67754,1025,8660,77899,73770,73754,73737,8328,65,203847,79130,4097,138341,75223,169,257,32,5457,513]

theorem envBound20580 : H12AffineFastState.Bounded env20580 := by
  intro p hp
  have h : env20580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20579_20580 : H12AffineEnvironment.transform 17 67754 env20579 = env20580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env20579 == env20580) = true)

theorem identity20580 : scanCanonicalize (H12AffineFastState.compose env20580 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound20580 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79131,67754,1025,8660,77899,73770,73754,73737,8328,65,10588,79130,4097,76158,75223,169,257,32,5457,513]

theorem envBound20581 : H12AffineFastState.Bounded env20581 := by
  intro p hp
  have h : env20581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20580_20581 : H12AffineEnvironment.transform 16 79131 env20580 = env20581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env20580 == env20581) = true)

theorem identity20581 : scanCanonicalize (H12AffineFastState.compose env20581 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20581 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env20582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,5393,10400,1025,8660,4161,32,16,3,8328,65,10588,5392,4097,2420,1501,169,257,32,5457,513]

theorem envBound20582 : H12AffineFastState.Bounded env20582 := by
  intro p hp
  have h : env20582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20581_20582 : H12AffineEnvironment.transform 15 8202 env20581 = env20582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20581 == env20582) = true)

theorem identity20582 : scanCanonicalize (H12AffineFastState.compose env20582 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound20582 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,88,5376,397,82,5393,2296,1025,396,4161,32,16,3,208,65,2308,5392,4097,2420,1501,169,257,32,5457,513]

theorem envBound20583 : H12AffineFastState.Bounded env20583 := by
  intro p hp
  have h : env20583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20582_20583 : H12AffineEnvironment.transform 12 88 env20582 = env20583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env20582 == env20583) = true)

theorem identity20583 : scanCanonicalize (H12AffineFastState.compose env20583 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20583 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env20584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,88,5376,260,82,5393,2161,1025,261,4161,32,16,3,89,65,2308,5392,4097,2420,1364,32,257,32,5457,513]

theorem envBound20584 : H12AffineFastState.Bounded env20584 := by
  intro p hp
  have h : env20584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20583_20584 : H12AffineEnvironment.transform 6 9 env20583 = env20584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20583 == env20584) = true)

def env20585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1025,8661,276704,272512,272561,73736,8328,65,398573,277937,4096,138340,273788,168,257,33,5456,330410]

theorem envBound20585 : H12AffineFastState.Bounded env20585 := by
  intro p hp
  have h : env20585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20578_20585 : H12AffineEnvironment.transform 13 5377 env20578 = env20585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20578 == env20585) = true)

theorem identity20585 : scanCanonicalize (H12AffineFastState.compose env20585 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20585 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,262144,1025,8661,276704,272512,272561,138,8328,65,398573,277937,4096,138340,273788,168,257,33,5456,272936]

theorem envBound20586 : H12AffineFastState.Bounded env20586 := by
  intro p hp
  have h : env20586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20585_20586 : H12AffineEnvironment.transform 15 8322 env20585 = env20586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20585 == env20586) = true)

theorem identity20586 : scanCanonicalize (H12AffineFastState.compose env20586 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20586 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env20587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1025,8541,276584,272392,272441,2,8192,65,398437,277817,4096,138340,273788,32,257,33,5456,272936]

theorem envBound20587 : H12AffineFastState.Bounded env20587 := by
  intro p hp
  have h : env20587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20586_20587 : H12AffineEnvironment.transform 6 8 env20586 = env20587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20586 == env20587) = true)

theorem identity20587 : scanCanonicalize (H12AffineFastState.compose env20587 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 3361) := by decide +kernel

theorem selectedBound20587 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env20588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,3361,262144,1025,8541,276584,272392,272441,2,8192,65,268612,277817,4096,4421,273788,32,257,33,5456,272936]

theorem envBound20588 : H12AffineFastState.Bounded env20588 := by
  intro p hp
  have h : env20588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20587_20588 : H12AffineEnvironment.transform 16 3361 env20587 = env20588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3361 env20587 == env20588) = true)

theorem identity20588 : scanCanonicalize (H12AffineFastState.compose env20588 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 4404) := by decide +kernel

theorem selectedBound20588 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env20589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,3361,4404,1025,8541,10588,14652,14605,2,8192,65,2160,11277,4096,4421,15432,32,257,33,5456,15132]

theorem envBound20589 : H12AffineFastState.Bounded env20589 := by
  intro p hp
  have h : env20589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20588_20589 : H12AffineEnvironment.transform 17 4404 env20588 = env20589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4404 env20588 == env20589) = true)

theorem identity20589 : scanCanonicalize (H12AffineFastState.compose env20589 (packedSelected [4,6,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound20589 : packedSelected [4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env20590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2348,5377,2160,2342,3361,4404,1025,2161,112,4112,4129,2,2348,65,2160,1313,4096,4421,5476,32,257,33,5456,4656]

theorem envBound20590 : H12AffineFastState.Bounded env20590 := by
  intro p hp
  have h : env20590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20589_20590 : H12AffineEnvironment.transform 12 2348 env20589 = env20590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env20589 == env20590) = true)

theorem identity20590 : scanCanonicalize (H12AffineFastState.compose env20590 (packedSelected [1,8,10,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound20590 : packedSelected [1,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env20591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,2348,2341,2160,2342,3361,3344,1025,2161,112,3124,3077,2,2348,65,2160,1313,3108,3425,2368,32,257,33,2420,3604]

theorem envBound20591 : H12AffineFastState.Bounded env20591 := by
  intro p hp
  have h : env20591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20590_20591 : H12AffineEnvironment.transform 11 3108 env20590 = env20591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env20590 == env20591) = true)

theorem identity20591 : scanCanonicalize (H12AffineFastState.compose env20591 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound20591 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env20592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,1028,268,261,80,262,1281,1328,1025,81,112,1044,1061,2,268,65,80,1313,1028,1345,352,32,257,33,340,1588]

theorem envBound20592 : H12AffineFastState.Bounded env20592 := by
  intro p hp
  have h : env20592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20591_20592 : H12AffineEnvironment.transform 10 32 env20591 = env20592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env20591 == env20592) = true)

theorem identity20592 : scanCanonicalize (H12AffineFastState.compose env20592 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound20592 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20593 : List Nat := [2,4,8,16,32,64,8,256,512,769,32,773,268,261,80,262,512,561,768,81,112,789,804,2,268,65,80,544,773,576,352,32,257,33,340,309]

theorem envBound20593 : H12AffineFastState.Bounded env20593 := by
  intro p hp
  have h : env20593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20592_20593 : H12AffineEnvironment.transform 9 769 env20592 = env20593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env20592 == env20593) = true)

theorem identity20593 : scanCanonicalize (H12AffineFastState.compose env20593 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20593 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env20594 : List Nat := [2,4,8,16,32,64,8,37,512,548,32,544,41,32,80,35,512,561,549,81,112,560,513,2,41,65,80,544,544,576,69,32,36,33,113,16]

theorem envBound20594 : H12AffineFastState.Bounded env20594 := by
  intro p hp
  have h : env20594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20593_20594 : H12AffineEnvironment.transform 7 37 env20593 = env20594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20593 == env20594) = true)

theorem identity20594 : scanCanonicalize (H12AffineFastState.compose env20594 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20594 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env20595 : List Nat := [2,4,8,16,32,32,8,37,512,548,32,544,41,32,48,35,512,561,549,49,16,560,513,2,41,33,48,544,544,544,37,32,36,33,17,16]

theorem envBound20595 : H12AffineFastState.Bounded env20595 := by
  intro p hp
  have h : env20595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20594_20595 : H12AffineEnvironment.transform 5 32 env20594 = env20595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20594 == env20595) = true)

theorem identity20595 : scanCanonicalize (H12AffineFastState.compose env20595 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20595 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20596 : List Nat := [2,4,8,16,17,17,8,20,512,533,17,529,24,17,1,18,512,512,532,0,16,513,513,2,24,16,1,529,529,529,20,17,21,16,17,16]

theorem envBound20596 : H12AffineFastState.Bounded env20596 := by
  intro p hp
  have h : env20596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20595_20596 : H12AffineEnvironment.transform 4 17 env20595 = env20596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20595 == env20596) = true)

theorem identity20596 : scanCanonicalize (H12AffineFastState.compose env20596 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20596 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20597 : List Nat := [2,4,8,0,1,1,8,4,512,517,1,513,8,1,1,2,512,512,516,0,0,513,513,2,8,0,1,513,513,513,4,1,5,0,1,0]

theorem envBound20597 : H12AffineFastState.Bounded env20597 := by
  intro p hp
  have h : env20597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20596_20597 : H12AffineEnvironment.transform 3 0 env20596 = env20597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20596 == env20597) = true)

theorem identity20597 : scanCanonicalize (H12AffineFastState.compose env20597 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20598 : List Nat := [2,1,8,0,1,1,8,1,512,512,1,513,8,1,1,2,512,512,513,0,0,513,513,2,8,0,1,513,513,513,1,1,0,0,1,0]

theorem envBound20598 : H12AffineFastState.Bounded env20598 := by
  intro p hp
  have h : env20598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20597_20598 : H12AffineEnvironment.transform 1 1 env20597 = env20598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20597 == env20598) = true)

theorem identity20598 : scanCanonicalize (H12AffineFastState.compose env20598 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound20598 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20599 : List Nat := [2,1,8,0,1,1,8,1,10,10,1,11,8,1,1,2,10,10,11,0,0,11,11,2,8,0,1,11,11,11,1,1,0,0,1,0]

theorem envBound20599 : H12AffineFastState.Bounded env20599 := by
  intro p hp
  have h : env20599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20598_20599 : H12AffineEnvironment.transform 8 10 env20598 = env20599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env20598 == env20599) = true)

theorem identity20599 : scanCanonicalize (H12AffineFastState.compose env20599 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20599 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20600 : List Nat := [2,1,1,0,1,1,1,1,3,3,1,2,1,1,1,2,3,3,2,0,0,2,2,2,1,0,1,2,2,2,1,1,0,0,1,0]

theorem envBound20600 : H12AffineFastState.Bounded env20600 := by
  intro p hp
  have h : env20600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20599_20600 : H12AffineEnvironment.transform 2 1 env20599 = env20600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20599 == env20600) = true)

theorem identity20600 : scanCanonicalize (H12AffineFastState.compose env20600 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20600 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20601 : List Nat := [1,1,1,0,1,1,1,1,0,0,1,1,1,1,1,1,0,0,1,0,0,1,1,1,1,0,1,1,1,1,1,1,0,0,1,0]

theorem envBound20601 : H12AffineFastState.Bounded env20601 := by
  intro p hp
  have h : env20601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20600_20601 : H12AffineEnvironment.transform 0 1 env20600 = env20601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20600 == env20601) = true)

def env20602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294320,98780,8328,65,398572,288944,17665,179632,292989,41341,257,21792,46212,352171]

theorem envBound20602 : H12AffineFastState.Bounded env20602 := by
  intro p hp
  have h : env20602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20576_20602 : H12AffineEnvironment.transform 21 272513 env20576 = env20602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20576 == env20602) = true)

theorem identity20602 : scanCanonicalize (H12AffineFastState.compose env20602 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound20602 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,58517,41461,62660,98780,8328,65,171416,57796,17665,179632,61705,41341,257,21792,46212,120543]

theorem envBound20603 : H12AffineFastState.Bounded env20603 := by
  intro p hp
  have h : env20603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20602_20603 : H12AffineEnvironment.transform 17 35188 env20602 = env20603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env20602 == env20603) = true)

def env20604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,35188,1025,32769,45341,41461,41292,98780,8328,65,171416,46156,4233,179632,42113,41341,257,168,46212,99159]

theorem envBound20604 : H12AffineFastState.Bounded env20604 := by
  intro p hp
  have h : env20604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20603_20604 : H12AffineEnvironment.transform 13 5512 env20603 = env20604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20603 == env20604) = true)

theorem identity20604 : scanCanonicalize (H12AffineFastState.compose env20604 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20604 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,131072,35188,1025,32769,45341,41461,41292,41431,8328,65,171416,46156,4233,179632,42113,41341,257,168,46212,41820]

theorem envBound20605 : H12AffineFastState.Bounded env20605 := by
  intro p hp
  have h : env20605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20604_20605 : H12AffineEnvironment.transform 15 8203 env20604 = env20605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20604 == env20605) = true)

theorem identity20605 : scanCanonicalize (H12AffineFastState.compose env20605 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20605 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env20606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,131072,10281,1025,8540,4160,168,17,138,8328,65,146629,5393,4233,138477,1500,32,257,168,5593,513]

theorem envBound20606 : H12AffineFastState.Bounded env20606 := by
  intro p hp
  have h : env20606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20605_20606 : H12AffineEnvironment.transform 14 8541 env20605 = env20606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20605 == env20606) = true)

theorem identity20606 : scanCanonicalize (H12AffineFastState.compose env20606 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20606 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env20607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,1,343,131072,2421,1025,0,4160,168,17,138,468,65,138649,5393,4233,138477,1500,32,257,168,5593,513]

theorem envBound20607 : H12AffineFastState.Bounded env20607 := by
  intro p hp
  have h : env20607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20606_20607 : H12AffineEnvironment.transform 12 348 env20606 = env20607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20606 == env20607) = true)

theorem identity20607 : scanCanonicalize (H12AffineFastState.compose env20607 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20607 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,131072,2421,1025,0,4160,32,17,2,348,65,138513,5393,4097,138341,1364,32,257,32,5457,513]

theorem envBound20608 : H12AffineFastState.Bounded env20608 := by
  intro p hp
  have h : env20608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20607_20608 : H12AffineEnvironment.transform 6 8 env20607 = env20608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20607 == env20608) = true)

theorem identity20608 : scanCanonicalize (H12AffineFastState.compose env20608 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5392,2421,1025,0,4160,32,17,2,348,65,2049,5393,4097,2421,1364,32,257,32,5457,513]

theorem envBound20609 : H12AffineFastState.Bounded env20609 := by
  intro p hp
  have h : env20609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20608_20609 : H12AffineEnvironment.transform 16 5392 env20608 = env20609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20608 == env20609) = true)

theorem identity20609 : scanCanonicalize (H12AffineFastState.compose env20609 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound20609 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,821,348,1589,1,343,1573,2421,1025,0,885,32,17,2,348,65,2049,1572,820,2421,1364,32,257,32,1636,513]

theorem envBound20610 : H12AffineFastState.Bounded env20610 := by
  intro p hp
  have h : env20610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20609_20610 : H12AffineEnvironment.transform 11 821 env20609 = env20610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env20609 == env20610) = true)

theorem identity20610 : scanCanonicalize (H12AffineFastState.compose env20610 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound20610 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1572,821,348,1589,1,343,1573,1873,1025,0,885,32,17,2,348,65,1573,1572,820,1873,1364,32,257,32,1636,513]

theorem envBound20611 : H12AffineFastState.Bounded env20611 := by
  intro p hp
  have h : env20611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20610_20611 : H12AffineEnvironment.transform 10 1572 env20610 = env20611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env20610 == env20611) = true)

theorem identity20611 : scanCanonicalize (H12AffineFastState.compose env20611 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound20611 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20612 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1572,609,8,1589,1,3,1573,1541,1025,0,545,32,17,2,8,65,1573,1572,608,1541,1024,32,85,32,1636,513]

theorem envBound20612 : H12AffineFastState.Bounded env20612 := by
  intro p hp
  have h : env20612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20611_20612 : H12AffineEnvironment.transform 7 84 env20611 = env20612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env20611 == env20612) = true)

theorem identity20612 : scanCanonicalize (H12AffineFastState.compose env20612 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound20612 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env20613 : List Nat := [2,4,8,16,32,64,8,84,512,613,65,609,8,80,1,3,64,96,612,0,545,32,17,2,8,65,64,65,608,96,613,32,85,32,1,513]

theorem envBound20613 : H12AffineFastState.Bounded env20613 := by
  intro p hp
  have h : env20613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20612_20613 : H12AffineEnvironment.transform 9 613 env20612 = env20613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env20612 == env20613) = true)

theorem identity20613 : scanCanonicalize (H12AffineFastState.compose env20613 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20613 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20614 : List Nat := [2,4,8,16,32,48,8,36,512,533,49,529,8,32,1,3,48,16,532,0,545,32,17,2,8,49,48,49,528,16,533,32,37,32,1,513]

theorem envBound20614 : H12AffineFastState.Bounded env20614 := by
  intro p hp
  have h : env20614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20613_20614 : H12AffineEnvironment.transform 5 48 env20613 = env20614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20613 == env20614) = true)

theorem identity20614 : scanCanonicalize (H12AffineFastState.compose env20614 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20614 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env20615 : List Nat := [2,4,8,16,32,48,8,36,0,21,49,17,8,32,1,3,48,16,20,0,33,32,17,2,8,49,48,49,16,16,21,32,37,32,1,1]

theorem envBound20615 : H12AffineFastState.Bounded env20615 := by
  intro p hp
  have h : env20615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20614_20615 : H12AffineEnvironment.transform 8 0 env20614 = env20615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20614 == env20615) = true)

theorem identity20615 : scanCanonicalize (H12AffineFastState.compose env20615 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20616 : List Nat := [2,4,8,0,32,32,8,36,0,5,33,1,8,32,1,3,32,0,4,0,33,32,1,2,8,33,32,33,0,0,5,32,37,32,1,1]

theorem envBound20616 : H12AffineFastState.Bounded env20616 := by
  intro p hp
  have h : env20616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20615_20616 : H12AffineEnvironment.transform 3 0 env20615 = env20616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20615 == env20616) = true)

theorem identity20616 : scanCanonicalize (H12AffineFastState.compose env20616 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20617 : List Nat := [2,4,8,0,0,0,8,4,0,5,1,1,8,0,1,3,0,0,4,0,1,0,1,2,8,1,0,1,0,0,5,0,5,0,1,1]

theorem envBound20617 : H12AffineFastState.Bounded env20617 := by
  intro p hp
  have h : env20617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20616_20617 : H12AffineEnvironment.transform 4 0 env20616 = env20617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20616 == env20617) = true)

theorem identity20617 : scanCanonicalize (H12AffineFastState.compose env20617 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20618 : List Nat := [2,4,3,0,0,0,3,4,0,5,1,1,3,0,1,3,0,0,4,0,1,0,1,2,3,1,0,1,0,0,5,0,5,0,1,1]

theorem envBound20618 : H12AffineFastState.Bounded env20618 := by
  intro p hp
  have h : env20618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20617_20618 : H12AffineEnvironment.transform 2 3 env20617 = env20618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20617 == env20618) = true)

def env20619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,35188,1025,32769,45340,41461,41293,98780,8328,65,171416,46157,4232,179632,42112,41341,257,169,46212,99158]

theorem envBound20619 : H12AffineFastState.Bounded env20619 := by
  intro p hp
  have h : env20619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20603_20619 : H12AffineEnvironment.transform 13 5513 env20603 = env20619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20603 == env20619) = true)

theorem identity20619 : scanCanonicalize (H12AffineFastState.compose env20619 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound20619 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,35188,1025,32769,45340,41461,41293,2,8328,65,171416,46157,4232,179632,42112,41341,257,169,46212,648]

theorem envBound20620 : H12AffineFastState.Bounded env20620 := by
  intro p hp
  have h : env20620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20619_20620 : H12AffineEnvironment.transform 15 33246 env20619 = env20620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env20619 == env20620) = true)

theorem identity20620 : scanCanonicalize (H12AffineFastState.compose env20620 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20620 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,35188,1025,32769,45340,41340,41293,2,8193,65,171281,46157,4097,179513,41993,41341,257,32,46093,513]

theorem envBound20621 : H12AffineFastState.Bounded env20621 := by
  intro p hp
  have h : env20621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20620_20621 : H12AffineEnvironment.transform 6 9 env20620 = env20621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20620 == env20621) = true)

theorem identity20621 : scanCanonicalize (H12AffineFastState.compose env20621 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20621 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,342,131072,2421,1025,0,12573,8573,8524,2,8193,65,138512,13388,4097,146744,9224,8572,257,32,13324,513]

theorem envBound20622 : H12AffineFastState.Bounded env20622 := by
  intro p hp
  have h : env20622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20621_20622 : H12AffineEnvironment.transform 14 1 env20621 = env20622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20621 == env20622) = true)

theorem identity20622 : scanCanonicalize (H12AffineFastState.compose env20622 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20622 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20623 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,262,131072,2341,1025,0,12573,8493,8476,2,8193,17,138512,13340,4097,146744,9224,8492,257,32,13324,513]

theorem envBound20623 : H12AffineFastState.Bounded env20623 := by
  intro p hp
  have h : env20623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20622_20623 : H12AffineEnvironment.transform 5 16 env20622 = env20623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20622 == env20623) = true)

theorem identity20623 : scanCanonicalize (H12AffineFastState.compose env20623 (packedSelected [0,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound20623 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env20624 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,262,13340,2341,1025,0,12573,8493,8476,2,8193,17,10508,13340,4097,2340,9224,8492,257,32,13324,513]

theorem envBound20624 : H12AffineFastState.Bounded env20624 := by
  intro p hp
  have h : env20624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20623_20624 : H12AffineEnvironment.transform 16 13340 env20623 = env20624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env20623 == env20624) = true)

theorem identity20624 : scanCanonicalize (H12AffineFastState.compose env20624 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound20624 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20625 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,8192,2049,1,262,10525,2341,1025,0,11292,8493,8476,2,8193,17,10508,10525,3328,2340,9224,8492,257,32,10509,513]

theorem envBound20625 : H12AffineFastState.Bounded env20625 := by
  intro p hp
  have h : env20625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20624_20625 : H12AffineEnvironment.transform 11 3329 env20624 = env20625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env20624 == env20625) = true)

theorem identity20625 : scanCanonicalize (H12AffineFastState.compose env20625 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound20625 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env20626 : List Nat := [2,4,8,16,32,16,9,256,512,1024,815,1582,8192,814,1,262,8754,522,1025,0,10035,8493,8476,2,8193,17,8739,8754,1583,523,9224,8492,257,32,8738,513]

theorem envBound20626 : H12AffineFastState.Bounded env20626 := by
  intro p hp
  have h : env20626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20625_20626 : H12AffineEnvironment.transform 10 815 env20625 = env20626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env20625 == env20626) = true)

theorem identity20626 : scanCanonicalize (H12AffineFastState.compose env20626 (packedSelected [1,3,11] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound20626 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env20627 : List Nat := [2,4,8,16,32,16,9,256,512,1024,815,1582,1337,814,1,262,1803,522,1025,0,522,1044,1061,2,1336,17,1818,1803,1583,523,305,1045,257,32,1819,513]

theorem envBound20627 : H12AffineFastState.Bounded env20627 := by
  intro p hp
  have h : env20627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20626_20627 : H12AffineEnvironment.transform 12 1337 env20626 = env20627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env20626 == env20627) = true)

theorem identity20627 : scanCanonicalize (H12AffineFastState.compose env20627 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound20627 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20628 : List Nat := [2,4,8,16,32,16,9,256,512,575,815,17,774,814,1,262,308,522,574,0,522,555,538,2,775,17,293,308,16,523,305,554,257,32,292,513]

theorem envBound20628 : H12AffineFastState.Bounded env20628 := by
  intro p hp
  have h : env20628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20627_20628 : H12AffineEnvironment.transform 9 575 env20627 = env20628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env20627 == env20628) = true)

def env20629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294321,2485309,8328,65,6705549,288944,2369761,179633,2102685,4491772,257,21793,46213,2175563]

theorem envBound20629 : H12AffineFastState.Bounded env20629 := by
  intro p hp
  have h : env20629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20515_20629 : H12AffineEnvironment.transform 22 294321 env20515 = env20629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294321 env20515 == env20629) = true)

def env20630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,4194304,294321,98781,8328,65,4340845,288944,17665,179633,292989,4491772,257,21793,46213,352171]

theorem envBound20630 : H12AffineFastState.Bounded env20630 := by
  intro p hp
  have h : env20630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20629_20630 : H12AffineEnvironment.transform 20 290272 env20629 = env20630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290272 env20629 == env20630) = true)

def env20631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272512,294321,98781,8328,65,398573,288944,17665,179633,292989,41340,257,21793,46213,352171]

theorem envBound20631 : H12AffineFastState.Bounded env20631 := by
  intro p hp
  have h : env20631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20630_20631 : H12AffineEnvironment.transform 21 272512 env20630 = env20631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20630 == env20631) = true)

theorem identity20631 : scanCanonicalize (H12AffineFastState.compose env20631 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound20631 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89514,1025,32769,77898,95530,73755,98781,8328,65,215367,79130,17665,179633,75223,41340,257,21793,46213,513]

theorem envBound20632 : H12AffineFastState.Bounded env20632 := by
  intro p hp
  have h : env20632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20631_20632 : H12AffineEnvironment.transform 17 89514 env20631 = env20632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env20631 == env20632) = true)

def env20633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77898,95530,73755,98645,8192,65,215367,79130,17665,179513,75103,41340,257,21793,46093,513]

theorem envBound20633 : H12AffineFastState.Bounded env20633 := by
  intro p hp
  have h : env20633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20632_20633 : H12AffineEnvironment.transform 6 8 env20632 = env20633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20632 == env20633) = true)

theorem identity20633 : scanCanonicalize (H12AffineFastState.compose env20633 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound20633 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,17665,89378,1025,32769,77898,95530,73755,98645,8192,65,68678,79130,17665,63544,75103,41340,257,21793,46093,513]

theorem envBound20634 : H12AffineFastState.Bounded env20634 := by
  intro p hp
  have h : env20634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20633_20634 : H12AffineEnvironment.transform 16 17665 env20633 = env20634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env20633 == env20634) = true)

theorem identity20634 : scanCanonicalize (H12AffineFastState.compose env20634 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound20634 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env20635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,9498,17665,30776,1025,32769,5456,20528,1281,42063,8192,65,10588,4096,17665,63544,69,41340,257,21793,46093,513]

theorem envBound20635 : H12AffineFastState.Bounded env20635 := by
  intro p hp
  have h : env20635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20634_20635 : H12AffineEnvironment.transform 15 9498 env20634 = env20635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env20634 == env20635) = true)

theorem identity20635 : scanCanonicalize (H12AffineFastState.compose env20635 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20635 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env20636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,9498,17665,30776,1025,8540,5456,20528,1281,1298,8192,65,10588,4096,17665,22885,69,33,257,21793,5456,513]

theorem envBound20636 : H12AffineFastState.Bounded env20636 := by
  intro p hp
  have h : env20636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20635_20636 : H12AffineEnvironment.transform 14 8541 env20635 = env20636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20635 == env20636) = true)

theorem identity20636 : scanCanonicalize (H12AffineFastState.compose env20636 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20636 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,4096,11577,1025,8540,5456,1329,1281,1298,8192,65,10588,4096,4096,3172,69,33,257,32,5456,513]

theorem envBound20637 : H12AffineFastState.Bounded env20637 := by
  intro p hp
  have h : env20637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20636_20637 : H12AffineEnvironment.transform 13 5377 env20636 = env20637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20636 == env20637) = true)

theorem identity20637 : scanCanonicalize (H12AffineFastState.compose env20637 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20637 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20638 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,8202,4096,10281,273,8540,4160,33,17,2,8192,65,10588,4096,4096,2420,69,33,257,32,4160,513]

theorem envBound20638 : H12AffineFastState.Bounded env20638 := by
  intro p hp
  have h : env20638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20637_20638 : H12AffineEnvironment.transform 9 272 env20637 = env20638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20637 == env20638) = true)

theorem identity20638 : scanCanonicalize (H12AffineFastState.compose env20638 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound20638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20639 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,88,4113,261,82,4096,2161,273,260,4160,33,17,2,88,65,2308,4096,4096,2420,69,33,257,32,4160,513]

theorem envBound20639 : H12AffineFastState.Bounded env20639 := by
  intro p hp
  have h : env20639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20638_20639 : H12AffineEnvironment.transform 12 88 env20638 = env20639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env20638 == env20639) = true)

theorem identity20639 : scanCanonicalize (H12AffineFastState.compose env20639 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20639 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20640 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8,4113,261,2,4096,2081,273,260,4112,33,17,2,8,17,2308,4096,4096,2340,21,33,257,32,4112,513]

theorem envBound20640 : H12AffineFastState.Bounded env20640 := by
  intro p hp
  have h : env20640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20639_20640 : H12AffineEnvironment.transform 5 16 env20639 = env20640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20639 == env20640) = true)

theorem identity20640 : scanCanonicalize (H12AffineFastState.compose env20640 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound20640 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20641 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,276,8,261,261,2,276,2081,273,260,260,33,17,2,8,17,2308,276,276,2340,21,33,257,32,260,513]

theorem envBound20641 : H12AffineFastState.Bounded env20641 := by
  intro p hp
  have h : env20641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20640_20641 : H12AffineEnvironment.transform 11 276 env20640 = env20641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env20640 == env20641) = true)

theorem identity20641 : scanCanonicalize (H12AffineFastState.compose env20641 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound20641 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20642 : List Nat := [2,4,8,16,32,16,8,256,512,272,49,276,8,261,261,2,276,16,273,260,260,33,17,2,8,17,309,276,276,277,21,33,257,32,260,513]

theorem envBound20642 : H12AffineFastState.Bounded env20642 := by
  intro p hp
  have h : env20642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20641_20642 : H12AffineEnvironment.transform 10 49 env20641 = env20642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env20641 == env20642) = true)

theorem identity20642 : scanCanonicalize (H12AffineFastState.compose env20642 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20642 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20643 : List Nat := [2,4,8,16,32,16,8,36,512,52,49,48,8,33,33,2,48,16,53,32,32,33,17,2,8,17,17,48,48,49,21,33,37,32,32,513]

theorem envBound20643 : H12AffineFastState.Bounded env20643 := by
  intro p hp
  have h : env20643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20642_20643 : H12AffineEnvironment.transform 7 36 env20642 = env20643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20642 == env20643) = true)

theorem identity20643 : scanCanonicalize (H12AffineFastState.compose env20643 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20644 : List Nat := [2,4,8,16,32,16,8,36,1,52,49,48,8,33,33,2,48,16,53,32,32,33,17,2,8,17,17,48,48,49,21,33,37,32,32,0]

theorem envBound20644 : H12AffineFastState.Bounded env20644 := by
  intro p hp
  have h : env20644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20643_20644 : H12AffineEnvironment.transform 8 1 env20643 = env20644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20643 == env20644) = true)

def env20645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73755,98644,8193,65,215367,79130,17665,179512,75102,41340,257,21793,46092,513]

theorem envBound20645 : H12AffineFastState.Bounded env20645 := by
  intro p hp
  have h : env20645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20632_20645 : H12AffineEnvironment.transform 6 9 env20632 = env20645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20632 == env20645) = true)

theorem identity20645 : scanCanonicalize (H12AffineFastState.compose env20645 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20645 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89379,1025,29788,77898,95530,73755,95497,8193,65,215367,79130,17665,149861,75102,21793,257,21793,16465,513]

theorem envBound20646 : H12AffineFastState.Bounded env20646 := by
  intro p hp
  have h : env20646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20645_20646 : H12AffineEnvironment.transform 14 29789 env20645 = env20646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20645 == env20646) = true)

theorem identity20646 : scanCanonicalize (H12AffineFastState.compose env20646 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound20646 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env20647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5441,89379,1025,29788,77898,95530,73755,95497,8193,65,89094,79130,17665,23588,75102,21793,257,21793,16465,513]

theorem envBound20647 : H12AffineFastState.Bounded env20647 := by
  intro p hp
  have h : env20647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20646_20647 : H12AffineEnvironment.transform 16 5441 env20646 = env20647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env20646 == env20647) = true)

theorem identity20647 : scanCanonicalize (H12AffineFastState.compose env20647 (packedSelected [0,2,4,6,7,9,14,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound20647 : packedSelected [0,2,4,6,7,9,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env20648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8282,5441,32121,1025,29788,4112,21872,65,21843,8193,65,31836,5440,17665,23588,1284,21793,257,21793,16465,513]

theorem envBound20648 : H12AffineFastState.Bounded env20648 := by
  intro p hp
  have h : env20648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20647_20648 : H12AffineEnvironment.transform 15 8282 env20647 = env20648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env20647 == env20648) = true)

def env20649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290272,272513,294321,98781,8328,65,398572,288944,17665,179633,292989,41341,257,21793,46213,352171]

theorem envBound20649 : H12AffineFastState.Bounded env20649 := by
  intro p hp
  have h : env20649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20630_20649 : H12AffineEnvironment.transform 21 272513 env20630 = env20649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20630 == env20649) = true)

theorem identity20649 : scanCanonicalize (H12AffineFastState.compose env20649 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20649 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,290272,272513,294321,41431,8328,65,398572,288944,17665,179633,292989,41341,257,21793,46213,294817]

theorem envBound20650 : H12AffineFastState.Bounded env20650 := by
  intro p hp
  have h : env20650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20649_20650 : H12AffineEnvironment.transform 15 8202 env20649 = env20650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20649 == env20650) = true)

def env20651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4160,21793,17,41431,8328,65,158028,5392,17665,179633,1501,41341,257,21793,46213,513]

theorem envBound20651 : H12AffineFastState.Bounded env20651 := by
  intro p hp
  have h : env20651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20650_20651 : H12AffineEnvironment.transform 17 32160 env20650 = env20651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env20650 == env20651) = true)

theorem identity20651 : scanCanonicalize (H12AffineFastState.compose env20651 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20651 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env20652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,131072,23588,1025,32769,4160,21793,17,32851,268,65,149704,5392,17665,171061,1501,33017,257,21793,38145,513]

theorem envBound20652 : H12AffineFastState.Bounded env20652 := by
  intro p hp
  have h : env20652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20651_20652 : H12AffineEnvironment.transform 12 388 env20651 = env20652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20651 == env20652) = true)

theorem identity20652 : scanCanonicalize (H12AffineFastState.compose env20652 (packedSelected [4,9,14,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound20652 : packedSelected [4,9,14,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env20653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,32768,398,49305,23588,1025,32769,4160,21793,17,32851,268,65,34897,5392,17665,23724,1501,33017,257,21793,38145,513]

theorem envBound20653 : H12AffineFastState.Bounded env20653 := by
  intro p hp
  have h : env20653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20652_20653 : H12AffineEnvironment.transform 16 49305 env20652 = env20653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env20652 == env20653) = true)

theorem identity20653 : scanCanonicalize (H12AffineFastState.compose env20653 (packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20653 : packedSelected [1,2,3,4,5,6,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,0,398,16537,23588,1025,1,4160,21793,17,83,268,65,2129,5392,17665,23724,1501,249,257,21793,5377,513]

theorem envBound20654 : H12AffineFastState.Bounded env20654 := by
  intro p hp
  have h : env20654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20653_20654 : H12AffineEnvironment.transform 14 0 env20653 = env20654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20653 == env20654) = true)

theorem identity20654 : scanCanonicalize (H12AffineFastState.compose env20654 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20654 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20655 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,0,343,16448,23588,1025,1,4160,21793,17,83,268,65,2129,5392,17665,23669,1284,32,257,21793,5377,513]

theorem envBound20655 : H12AffineFastState.Bounded env20655 := by
  intro p hp
  have h : env20655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20654_20655 : H12AffineEnvironment.transform 6 89 env20654 = env20655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20654 == env20655) = true)

theorem identity20655 : scanCanonicalize (H12AffineFastState.compose env20655 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound20655 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env20656 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,3344,0,343,3408,4404,1025,1,4160,6193,17,83,268,65,2129,5392,2065,4453,1284,32,257,6193,5377,513]

theorem envBound20656 : H12AffineFastState.Bounded env20656 := by
  intro p hp
  have h : env20656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20655_20656 : H12AffineEnvironment.transform 13 3344 env20655 = env20656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env20655 == env20656) = true)

theorem identity20656 : scanCanonicalize (H12AffineFastState.compose env20656 (packedSelected [4,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound20656 : packedSelected [4,6,7,10] rootPS < 2^1333 := by decide +kernel

def env20657 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3109,349,3344,0,343,3408,3345,1025,1,3173,1044,17,83,268,65,2129,2357,2065,3392,1284,32,257,1044,2340,513]

theorem envBound20657 : H12AffineFastState.Bounded env20657 := by
  intro p hp
  have h : env20657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20656_20657 : H12AffineEnvironment.transform 11 3109 env20656 = env20657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env20656 == env20657) = true)

theorem identity20657 : scanCanonicalize (H12AffineFastState.compose env20657 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20657 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env20658 : List Nat := [2,4,8,16,32,64,89,256,512,101,2048,2112,349,2421,0,343,2357,2420,100,1,2048,113,17,83,268,65,2129,2357,2065,2341,353,32,257,113,2340,513]

theorem envBound20658 : H12AffineFastState.Bounded env20658 := by
  intro p hp
  have h : env20658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20657_20658 : H12AffineEnvironment.transform 9 101 env20657 = env20658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20657 == env20658) = true)

theorem identity20658 : scanCanonicalize (H12AffineFastState.compose env20658 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20658 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20659 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2065,268,2340,0,262,2357,2341,53,1,2048,32,17,2,268,16,2048,2357,2065,2341,304,32,257,32,2340,513]

theorem envBound20659 : H12AffineFastState.Bounded env20659 := by
  intro p hp
  have h : env20659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20658_20659 : H12AffineEnvironment.transform 5 17 env20658 = env20659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20658 == env20659) = true)

theorem identity20659 : scanCanonicalize (H12AffineFastState.compose env20659 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20660 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2049,0,35,2064,2048,53,1,2048,32,17,2,41,16,2048,2064,2065,2048,21,32,36,32,2049,513]

theorem envBound20660 : H12AffineFastState.Bounded env20660 := by
  intro p hp
  have h : env20660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20659_20660 : H12AffineEnvironment.transform 7 37 env20659 = env20660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20659 == env20660) = true)

theorem identity20660 : scanCanonicalize (H12AffineFastState.compose env20660 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound20660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20661 : List Nat := [2,4,8,16,32,17,8,37,512,52,17,0,41,16,0,35,1,17,53,1,17,32,17,2,41,16,17,1,0,17,21,32,36,32,16,513]

theorem envBound20661 : H12AffineFastState.Bounded env20661 := by
  intro p hp
  have h : env20661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20660_20661 : H12AffineEnvironment.transform 10 17 env20660 = env20661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env20660 == env20661) = true)

theorem identity20661 : scanCanonicalize (H12AffineFastState.compose env20661 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20662 : List Nat := [2,4,2,16,32,17,2,37,512,52,17,0,35,16,0,35,1,17,53,1,17,32,17,2,35,16,17,1,0,17,21,32,36,32,16,513]

theorem envBound20662 : H12AffineFastState.Bounded env20662 := by
  intro p hp
  have h : env20662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20661_20662 : H12AffineEnvironment.transform 2 2 env20661 = env20662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20661 == env20662) = true)

def env20663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4161,21792,16,41431,8328,65,158029,5393,17665,179633,1500,41341,257,21793,46213,512]

theorem envBound20663 : H12AffineFastState.Bounded env20663 := by
  intro p hp
  have h : env20663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20650_20663 : H12AffineEnvironment.transform 17 32161 env20650 = env20663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env20650 == env20663) = true)

theorem identity20663 : scanCanonicalize (H12AffineFastState.compose env20663 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound20663 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,8202,131072,32161,1025,8353,4161,21792,16,375,8328,65,158029,5393,17665,138513,1500,477,257,21793,5157,512]

theorem envBound20664 : H12AffineFastState.Bounded env20664 := by
  intro p hp
  have h : env20664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20663_20664 : H12AffineEnvironment.transform 14 8352 env20663 = env20664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env20663 == env20664) = true)

theorem identity20664 : scanCanonicalize (H12AffineFastState.compose env20664 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound20664 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env20665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8352,8202,131072,10629,1025,8353,4161,260,16,375,8328,65,146793,5393,4389,138513,1500,477,257,261,5157,512]

theorem envBound20665 : H12AffineFastState.Bounded env20665 := by
  intro p hp
  have h : env20665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20664_20665 : H12AffineEnvironment.transform 13 5156 env20664 = env20665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env20664 == env20665) = true)

theorem identity20665 : scanCanonicalize (H12AffineFastState.compose env20665 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13540) := by decide +kernel

theorem selectedBound20665 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env20666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8352,8202,13540,10629,1025,8353,4161,260,16,375,8328,65,2445,5393,4389,10741,1500,477,257,261,5157,512]

theorem envBound20666 : H12AffineFastState.Bounded env20666 := by
  intro p hp
  have h : env20666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20665_20666 : H12AffineEnvironment.transform 16 13540 env20665 = env20666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13540 env20665 == env20666) = true)

theorem identity20666 : scanCanonicalize (H12AffineFastState.compose env20666 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound20666 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5156,477,375,5529,2296,1025,476,4161,260,16,375,501,65,2445,5393,4389,2184,1500,477,257,261,5157,512]

theorem envBound20667 : H12AffineFastState.Bounded env20667 := by
  intro p hp
  have h : env20667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20666_20667 : H12AffineEnvironment.transform 12 381 env20666 = env20667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env20666 == env20667) = true)

theorem identity20667 : scanCanonicalize (H12AffineFastState.compose env20667 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20667 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env20668 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,128,5156,32,138,5220,2296,1025,33,4161,249,16,138,8,65,2160,5356,4312,2184,1057,32,252,248,5157,512]

theorem envBound20668 : H12AffineFastState.Bounded env20668 := by
  intro p hp
  have h : env20668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20667_20668 : H12AffineEnvironment.transform 7 253 env20667 = env20668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20667 == env20668) = true)

theorem identity20668 : scanCanonicalize (H12AffineFastState.compose env20668 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20668 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20669 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,128,5156,32,138,5141,2185,1025,33,4144,136,16,138,8,48,2049,5277,4265,2184,1057,32,141,137,5157,512]

theorem envBound20669 : H12AffineFastState.Bounded env20669 := by
  intro p hp
  have h : env20669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20668_20669 : H12AffineEnvironment.transform 5 49 env20668 = env20669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20668 == env20669) = true)

theorem identity20669 : scanCanonicalize (H12AffineFastState.compose env20669 (packedSelected [0,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20669 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env20670 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,4096,128,5125,1,138,5141,2185,1025,0,4113,136,16,138,8,17,2049,5277,4232,2184,1024,1,141,137,5124,512]

theorem envBound20670 : H12AffineFastState.Bounded env20670 := by
  intro p hp
  have h : env20670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20669_20670 : H12AffineEnvironment.transform 4 1 env20669 = env20670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20669 == env20670) = true)

theorem identity20670 : scanCanonicalize (H12AffineFastState.compose env20670 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound20670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20671 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,0,128,1029,1,138,1045,2185,1025,0,17,136,16,138,8,17,2049,1181,136,2184,1024,1,141,137,1028,512]

theorem envBound20671 : H12AffineFastState.Bounded env20671 := by
  intro p hp
  have h : env20671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20670_20671 : H12AffineEnvironment.transform 11 0 env20670 = env20671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env20670 == env20671) = true)

theorem identity20671 : scanCanonicalize (H12AffineFastState.compose env20671 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound20671 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env20672 : List Nat := [2,4,8,16,1,16,128,140,512,517,2048,0,128,512,1,138,528,2185,516,0,17,136,16,138,8,17,2049,664,136,2184,517,1,141,137,513,512]

theorem envBound20672 : H12AffineFastState.Bounded env20672 := by
  intro p hp
  have h : env20672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20671_20672 : H12AffineEnvironment.transform 9 517 env20671 = env20672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env20671 == env20672) = true)

theorem identity20672 : scanCanonicalize (H12AffineFastState.compose env20672 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound20672 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20673 : List Nat := [2,4,8,16,1,16,128,140,512,517,152,0,128,512,1,138,528,17,516,0,17,136,16,138,8,17,153,664,136,16,517,1,141,137,513,512]

theorem envBound20673 : H12AffineFastState.Bounded env20673 := by
  intro p hp
  have h : env20673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20672_20673 : H12AffineEnvironment.transform 10 152 env20672 = env20673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env20672 == env20673) = true)

theorem identity20673 : scanCanonicalize (H12AffineFastState.compose env20673 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20673 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20674 : List Nat := [2,4,8,16,1,16,8,4,512,517,16,0,8,512,1,2,528,17,516,0,17,0,16,2,8,17,17,528,0,16,517,1,5,1,513,512]

theorem envBound20674 : H12AffineFastState.Bounded env20674 := by
  intro p hp
  have h : env20674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20673_20674 : H12AffineEnvironment.transform 6 8 env20673 = env20674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20673 == env20674) = true)

theorem identity20674 : scanCanonicalize (H12AffineFastState.compose env20674 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20674 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20675 : List Nat := [2,4,8,16,1,16,8,4,0,5,16,0,8,0,1,2,16,17,4,0,17,0,16,2,8,17,17,16,0,16,5,1,5,1,1,0]

theorem envBound20675 : H12AffineFastState.Bounded env20675 := by
  intro p hp
  have h : env20675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20674_20675 : H12AffineEnvironment.transform 8 0 env20674 = env20675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20674 == env20675) = true)

theorem identity20675 : scanCanonicalize (H12AffineFastState.compose env20675 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20675 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20676 : List Nat := [2,4,8,1,1,1,8,4,0,5,1,0,8,0,1,2,1,0,4,0,0,0,1,2,8,0,0,1,0,1,5,1,5,1,1,0]

theorem envBound20676 : H12AffineFastState.Bounded env20676 := by
  intro p hp
  have h : env20676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20675_20676 : H12AffineEnvironment.transform 3 1 env20675 = env20676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20675 == env20676) = true)

theorem identity20676 : scanCanonicalize (H12AffineFastState.compose env20676 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20676 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20677 : List Nat := [2,0,8,1,1,1,8,0,0,1,1,0,8,0,1,2,1,0,0,0,0,0,1,2,8,0,0,1,0,1,1,1,1,1,1,0]

theorem envBound20677 : H12AffineFastState.Bounded env20677 := by
  intro p hp
  have h : env20677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20676_20677 : H12AffineEnvironment.transform 1 0 env20676 = env20677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20676 == env20677) = true)

def env20678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,4194304,294321,98780,8328,65,4340844,288944,17664,179633,292988,4491772,257,21793,46213,352170]

theorem envBound20678 : H12AffineFastState.Bounded env20678 := by
  intro p hp
  have h : env20678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20629_20678 : H12AffineEnvironment.transform 20 290273 env20629 = env20678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290273 env20629 == env20678) = true)

def env20679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272512,294321,98780,8328,65,398572,288944,17664,179633,292988,41340,257,21793,46213,352170]

theorem envBound20679 : H12AffineFastState.Bounded env20679 := by
  intro p hp
  have h : env20679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20678_20679 : H12AffineEnvironment.transform 21 272512 env20678 = env20679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20678 == env20679) = true)

theorem identity20679 : scanCanonicalize (H12AffineFastState.compose env20679 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound20679 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108927,1025,32769,115870,98815,120014,98780,8328,65,245139,115151,17664,179633,119043,41340,257,21793,46213,63189]

theorem envBound20680 : H12AffineFastState.Bounded env20680 := by
  intro p hp
  have h : env20680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20679_20680 : H12AffineEnvironment.transform 17 108927 env20679 = env20680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env20679 == env20680) = true)

def env20681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1025,32769,102814,98815,98766,98780,8328,65,245139,103631,4096,179633,99331,41340,257,33,46213,41941]

theorem envBound20681 : H12AffineFastState.Bounded env20681 := by
  intro p hp
  have h : env20681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20680_20681 : H12AffineEnvironment.transform 13 5376 env20680 = env20681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20680 == env20681) = true)

theorem identity20681 : scanCanonicalize (H12AffineFastState.compose env20681 (packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20681 : packedSelected [0,5,8,9,14,17,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env20682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,131072,35325,1025,32769,45340,41341,41292,41310,8328,65,171281,46157,4096,179633,42113,41340,257,33,46213,41941]

theorem envBound20682 : H12AffineFastState.Bounded env20682 := by
  intro p hp
  have h : env20682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20681_20682 : H12AffineEnvironment.transform 15 8322 env20681 = env20682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20681 == env20682) = true)

theorem identity20682 : scanCanonicalize (H12AffineFastState.compose env20682 (packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20682 : packedSelected [0,5,8,9,10,18,19,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env20683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8322,5392,35325,1025,32769,45340,41341,41292,41310,8328,65,34817,46157,4096,43169,42113,41340,257,33,46213,41941]

theorem envBound20683 : H12AffineFastState.Bounded env20683 := by
  intro p hp
  have h : env20683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20682_20683 : H12AffineEnvironment.transform 16 5392 env20682 = env20683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20682 == env20683) = true)

theorem identity20683 : scanCanonicalize (H12AffineFastState.compose env20683 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20683 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35188,1025,32769,45340,41341,41292,41310,8193,65,34817,46157,4096,43048,41992,41340,257,33,46092,41820]

theorem envBound20684 : H12AffineFastState.Bounded env20684 := by
  intro p hp
  have h : env20684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20683_20684 : H12AffineEnvironment.transform 6 9 env20683 = env20684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20683 == env20684) = true)

theorem identity20684 : scanCanonicalize (H12AffineFastState.compose env20684 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound20684 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,8203,5392,2340,1025,81,12620,8493,8476,8462,8193,65,2129,13341,4096,10360,9304,8492,257,33,13404,8972]

theorem envBound20685 : H12AffineFastState.Bounded env20685 := by
  intro p hp
  have h : env20685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20684_20685 : H12AffineEnvironment.transform 14 80 env20684 = env20685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env20684 == env20685) = true)

theorem identity20685 : scanCanonicalize (H12AffineFastState.compose env20685 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound20685 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env20686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7544,5376,80,7539,5392,2340,1025,81,3124,7253,7268,7286,7545,65,2129,2405,4096,5376,6432,7252,257,33,2340,7796]

theorem envBound20686 : H12AffineFastState.Bounded env20686 := by
  intro p hp
  have h : env20686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20685_20686 : H12AffineEnvironment.transform 12 7544 env20685 = env20686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env20685 == env20686) = true)

theorem identity20686 : scanCanonicalize (H12AffineFastState.compose env20686 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound20686 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env20687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2048,1400,3328,80,1395,3344,2340,1025,81,3124,1109,1124,1142,1401,65,2129,2405,2048,3328,288,1108,257,33,2340,1652]

theorem envBound20687 : H12AffineFastState.Bounded env20687 := by
  intro p hp
  have h : env20687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20686_20687 : H12AffineEnvironment.transform 11 2048 env20686 = env20687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env20686 == env20687) = true)

theorem identity20687 : scanCanonicalize (H12AffineFastState.compose env20687 (packedSelected [1,2,3,4,5,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20687 : packedSelected [1,2,3,4,5,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env20688 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2048,1037,3189,80,1030,3173,2129,1025,81,3124,1109,1124,1142,1036,65,2129,2064,2048,3189,85,1108,116,33,2129,1652]

theorem envBound20688 : H12AffineFastState.Bounded env20688 := by
  intro p hp
  have h : env20688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20687_20688 : H12AffineEnvironment.transform 7 117 env20687 = env20688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20687 == env20688) = true)

theorem identity20688 : scanCanonicalize (H12AffineFastState.compose env20688 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound20688 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env20689 : List Nat := [2,4,8,16,32,64,9,117,512,37,2048,2048,40,2128,80,35,2112,2129,36,81,2065,112,65,83,41,65,2129,2064,2048,2128,85,113,116,33,2129,593]

theorem envBound20689 : H12AffineFastState.Bounded env20689 := by
  intro p hp
  have h : env20689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20688_20689 : H12AffineEnvironment.transform 9 37 env20688 = env20689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env20688 == env20689) = true)

theorem identity20689 : scanCanonicalize (H12AffineFastState.compose env20689 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20689 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env20690 : List Nat := [2,4,8,16,32,17,9,36,512,37,2048,2048,40,2049,1,35,2065,2048,36,0,2065,33,16,2,41,16,2048,2064,2048,2049,4,32,37,33,2048,512]

theorem envBound20690 : H12AffineFastState.Bounded env20690 := by
  intro p hp
  have h : env20690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20689_20690 : H12AffineEnvironment.transform 5 17 env20689 = env20690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20689 == env20690) = true)

theorem identity20690 : scanCanonicalize (H12AffineFastState.compose env20690 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20691 : List Nat := [2,4,8,16,16,17,9,20,512,21,2048,2048,24,2049,1,19,2065,2048,20,0,2065,17,16,2,25,16,2048,2064,2048,2049,4,16,21,17,2048,512]

theorem envBound20691 : H12AffineFastState.Bounded env20691 := by
  intro p hp
  have h : env20691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20690_20691 : H12AffineEnvironment.transform 4 16 env20690 = env20691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20690 == env20691) = true)

theorem identity20691 : scanCanonicalize (H12AffineFastState.compose env20691 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20691 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20692 : List Nat := [2,4,2,16,16,17,3,20,512,21,2048,2048,18,2049,1,19,2065,2048,20,0,2065,17,16,2,19,16,2048,2064,2048,2049,4,16,21,17,2048,512]

theorem envBound20692 : H12AffineFastState.Bounded env20692 := by
  intro p hp
  have h : env20692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20691_20692 : H12AffineEnvironment.transform 2 2 env20691 = env20692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20691 == env20692) = true)

theorem identity20692 : scanCanonicalize (H12AffineFastState.compose env20692 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20692 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20693 : List Nat := [2,4,2,0,0,1,3,4,512,5,2048,2048,2,2049,1,3,2049,2048,4,0,2049,1,0,2,3,0,2048,2048,2048,2049,4,0,5,1,2048,512]

theorem envBound20693 : H12AffineFastState.Bounded env20693 := by
  intro p hp
  have h : env20693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20692_20693 : H12AffineEnvironment.transform 3 0 env20692 = env20693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20692 == env20693) = true)

theorem identity20693 : scanCanonicalize (H12AffineFastState.compose env20693 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound20693 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20694 : List Nat := [2,4,2,0,0,1,3,4,512,5,516,516,2,517,1,3,517,516,4,0,517,1,0,2,3,0,516,516,516,517,4,0,5,1,516,512]

theorem envBound20694 : H12AffineFastState.Bounded env20694 := by
  intro p hp
  have h : env20694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20693_20694 : H12AffineEnvironment.transform 10 516 env20693 = env20694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env20693 == env20694) = true)

theorem identity20694 : scanCanonicalize (H12AffineFastState.compose env20694 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound20694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20695 : List Nat := [2,4,2,0,0,1,3,4,7,5,3,3,2,2,1,3,2,3,4,0,2,1,0,2,3,0,3,3,3,2,4,0,5,1,3,7]

theorem envBound20695 : H12AffineFastState.Bounded env20695 := by
  intro p hp
  have h : env20695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20694_20695 : H12AffineEnvironment.transform 8 7 env20694 = env20695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env20694 == env20695) = true)

def env20696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1025,32769,102815,98815,98767,98780,8328,65,245139,103630,4097,179633,99330,41340,257,32,46213,41940]

theorem envBound20696 : H12AffineFastState.Bounded env20696 := by
  intro p hp
  have h : env20696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20680_20696 : H12AffineEnvironment.transform 13 5377 env20680 = env20696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20680 == env20696) = true)

theorem identity20696 : scanCanonicalize (H12AffineFastState.compose env20696 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20696 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env20697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8202,131072,35189,1025,32769,45461,41461,41413,41430,8328,65,171417,46276,4097,179633,41992,41340,257,32,46213,41940]

theorem envBound20697 : H12AffineFastState.Bounded env20697 := by
  intro p hp
  have h : env20697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20696_20697 : H12AffineEnvironment.transform 15 8202 env20696 = env20697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20696 == env20697) = true)

theorem identity20697 : scanCanonicalize (H12AffineFastState.compose env20697 (packedSelected [3,5,6,12,17,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound20697 : packedSelected [3,5,6,12,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env20698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,32768,2,131072,35189,1025,32769,37277,33277,33229,33246,128,65,171417,38092,4097,171449,33792,33140,257,32,38029,33756]

theorem envBound20698 : H12AffineFastState.Bounded env20698 := by
  intro p hp
  have h : env20698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20697_20698 : H12AffineEnvironment.transform 12 8 env20697 = env20698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env20697 == env20698) = true)

theorem identity20698 : scanCanonicalize (H12AffineFastState.compose env20698 (packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound20698 : packedSelected [0,1,2,3,5,7,8,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env20699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,32768,2,5577,35189,1025,32769,37277,33277,33229,33246,128,65,34896,38092,4097,34928,33792,33140,257,32,38029,33756]

theorem envBound20699 : H12AffineFastState.Bounded env20699 := by
  intro p hp
  have h : env20699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20698_20699 : H12AffineEnvironment.transform 16 5577 env20698 = env20699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env20698 == env20699) = true)

theorem identity20699 : scanCanonicalize (H12AffineFastState.compose env20699 (packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 397) := by decide +kernel

theorem selectedBound20699 : packedSelected [0,2,6,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env20700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5377,397,2,5577,2296,1025,396,4112,112,64,83,128,65,2525,5441,4097,2557,1421,249,257,32,5376,593]

theorem envBound20700 : H12AffineFastState.Bounded env20700 := by
  intro p hp
  have h : env20700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20699_20700 : H12AffineEnvironment.transform 14 397 env20699 = env20700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 397 env20699 == env20700) = true)

theorem identity20700 : scanCanonicalize (H12AffineFastState.compose env20700 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20700 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5377,260,2,5440,2161,1025,261,4112,112,64,83,9,65,2388,5441,4097,2420,1284,112,257,32,5376,593]

theorem envBound20701 : H12AffineFastState.Bounded env20701 := by
  intro p hp
  have h : env20701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20700_20701 : H12AffineEnvironment.transform 6 9 env20700 = env20701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20700 == env20701) = true)

theorem identity20701 : scanCanonicalize (H12AffineFastState.compose env20701 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20701 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20702 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8,5124,1,2,5189,2161,1025,0,4112,112,64,83,9,65,2129,5188,4097,2161,1025,112,4,32,5125,593]

theorem envBound20702 : H12AffineFastState.Bounded env20702 := by
  intro p hp
  have h : env20702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20701_20702 : H12AffineEnvironment.transform 7 5 env20701 = env20702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20701 == env20702) = true)

theorem identity20702 : scanCanonicalize (H12AffineFastState.compose env20702 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound20702 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20703 : List Nat := [2,4,8,16,32,64,9,5,512,1024,65,4096,8,5124,1,2,5189,48,1025,0,4112,112,64,83,9,65,16,5188,4097,48,1025,112,4,32,5125,593]

theorem envBound20703 : H12AffineFastState.Bounded env20703 := by
  intro p hp
  have h : env20703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20702_20703 : H12AffineEnvironment.transform 10 65 env20702 = env20703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env20702 == env20703) = true)

theorem identity20703 : scanCanonicalize (H12AffineFastState.compose env20703 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound20703 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env20704 : List Nat := [2,4,8,16,32,64,9,5,512,1024,65,545,8,1573,1,2,1636,48,1025,0,561,112,64,83,9,65,16,1637,544,48,1025,112,4,32,1572,593]

theorem envBound20704 : H12AffineFastState.Bounded env20704 := by
  intro p hp
  have h : env20704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20703_20704 : H12AffineEnvironment.transform 11 545 env20703 = env20704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env20703 == env20704) = true)

theorem identity20704 : scanCanonicalize (H12AffineFastState.compose env20704 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20704 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env20705 : List Nat := [2,4,8,16,32,64,9,5,512,100,65,545,8,577,1,2,512,48,101,0,561,112,64,83,9,65,16,513,544,48,101,112,4,32,576,593]

theorem envBound20705 : H12AffineFastState.Bounded env20705 := by
  intro p hp
  have h : env20705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20704_20705 : H12AffineEnvironment.transform 9 100 env20704 = env20705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20704 == env20705) = true)

def env20706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290273,272513,294321,98780,8328,65,398573,288944,17664,179633,292988,41341,257,21793,46213,352170]

theorem envBound20706 : H12AffineFastState.Bounded env20706 := by
  intro p hp
  have h : env20706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20678_20706 : H12AffineEnvironment.transform 21 272513 env20678 = env20706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20678 == env20706) = true)

theorem identity20706 : scanCanonicalize (H12AffineFastState.compose env20706 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound20706 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,290273,272513,294321,21763,8328,65,398573,288944,17664,179633,292988,41341,257,21793,46213,297845]

theorem envBound20707 : H12AffineFastState.Bounded env20707 := by
  intro p hp
  have h : env20707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20706_20707 : H12AffineEnvironment.transform 15 54495 env20706 = env20707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env20706 == env20707) = true)

def env20708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,290153,272393,294201,21763,8192,65,398437,288824,17664,179513,292988,41341,257,21793,46093,297845]

theorem envBound20708 : H12AffineFastState.Bounded env20708 := by
  intro p hp
  have h : env20708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20707_20708 : H12AffineEnvironment.transform 6 8 env20707 = env20708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20707 == env20708) = true)

theorem identity20708 : scanCanonicalize (H12AffineFastState.compose env20708 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound20708 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,146744,1025,32769,151633,136497,147457,21763,8192,65,10589,152832,17664,179513,148804,41341,257,21793,46093,177741]

theorem envBound20709 : H12AffineFastState.Bounded env20709 := by
  intro p hp
  have h : env20709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20708_20709 : H12AffineEnvironment.transform 17 146744 env20708 = env20709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env20708 == env20709) = true)

theorem identity20709 : scanCanonicalize (H12AffineFastState.compose env20709 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20709 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env20710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,146744,1025,29788,151633,136497,147457,21763,8192,65,10589,152832,17664,149860,148804,21792,257,21793,16464,147984]

theorem envBound20710 : H12AffineFastState.Bounded env20710 := by
  intro p hp
  have h : env20710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20709_20710 : H12AffineEnvironment.transform 14 29789 env20709 = env20710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20709 == env20710) = true)

theorem identity20710 : scanCanonicalize (H12AffineFastState.compose env20710 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound20710 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env20711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,32040,1025,29788,4161,21793,17,21763,8192,65,10589,5392,17664,2420,1364,21792,257,21793,16464,512]

theorem envBound20711 : H12AffineFastState.Bounded env20711 := by
  intro p hp
  have h : env20711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20710_20711 : H12AffineEnvironment.transform 16 16400 env20710 = env20711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20710 == env20711) = true)

theorem identity20711 : scanCanonicalize (H12AffineFastState.compose env20711 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20711 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21541,114,16400,23888,1025,21540,4161,21793,17,21763,120,65,2341,5392,17664,2420,1364,21792,257,21793,16464,512]

theorem envBound20712 : H12AffineFastState.Bounded env20712 := by
  intro p hp
  have h : env20712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20711_20712 : H12AffineEnvironment.transform 12 120 env20711 = env20712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20711 == env20712) = true)

theorem identity20712 : scanCanonicalize (H12AffineFastState.compose env20712 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20712 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env20713 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,16384,21509,82,16400,23888,1025,21508,4161,21761,17,21763,88,65,2309,5392,17664,2388,1364,21760,257,21761,16464,512]

theorem envBound20713 : H12AffineFastState.Bounded env20713 := by
  intro p hp
  have h : env20713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20712_20713 : H12AffineEnvironment.transform 4 0 env20712 = env20713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20712 == env20713) = true)

theorem identity20713 : scanCanonicalize (H12AffineFastState.compose env20713 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound20713 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env20714 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,5205,80,82,5189,2309,1025,81,4161,340,17,342,88,65,2309,5392,4437,2388,1364,341,257,340,5125,512]

theorem envBound20714 : H12AffineFastState.Bounded env20714 := by
  intro p hp
  have h : env20714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20713_20714 : H12AffineEnvironment.transform 13 5205 env20713 = env20714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env20713 == env20714) = true)

theorem identity20714 : scanCanonicalize (H12AffineFastState.compose env20714 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound20714 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env20715 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5205,80,82,5189,2129,1025,81,4161,0,17,2,88,65,2129,5188,4097,2048,1024,1,85,0,5125,512]

theorem envBound20715 : H12AffineFastState.Bounded env20715 := by
  intro p hp
  have h : env20715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20714_20715 : H12AffineEnvironment.transform 7 84 env20714 = env20715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env20714 == env20715) = true)

theorem identity20715 : scanCanonicalize (H12AffineFastState.compose env20715 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20715 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20716 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,0,2,5141,2049,1025,1,4113,0,17,2,8,17,2049,5140,4097,2048,1024,1,5,0,5125,512]

theorem envBound20716 : H12AffineFastState.Bounded env20716 := by
  intro p hp
  have h : env20716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20715_20716 : H12AffineEnvironment.transform 5 16 env20715 = env20716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20715 == env20716) = true)

def env20717 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1045,0,2,1029,2049,1025,1,1,0,17,2,8,17,2049,1028,17,2048,1024,1,5,0,1045,512]

theorem envBound20717 : H12AffineFastState.Bounded env20717 := by
  intro p hp
  have h : env20717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20716_20717 : H12AffineEnvironment.transform 11 16 env20716 = env20717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20716 == env20717) = true)

theorem identity20717 : scanCanonicalize (H12AffineFastState.compose env20717 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound20717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20718 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1045,0,2,1029,1,1025,1,1,0,17,2,8,17,1,1028,17,0,1024,1,5,0,1045,512]

theorem envBound20718 : H12AffineFastState.Bounded env20718 := by
  intro p hp
  have h : env20718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20717_20718 : H12AffineEnvironment.transform 10 0 env20717 = env20718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20717 == env20718) = true)

def env20719 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,1,0,2,17,1,21,1,1,0,17,2,8,17,1,16,17,0,20,1,5,0,1,512]

theorem envBound20719 : H12AffineFastState.Bounded env20719 := by
  intro p hp
  have h : env20719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20718_20719 : H12AffineEnvironment.transform 9 20 env20718 = env20719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20718 == env20719) = true)

theorem identity20719 : scanCanonicalize (H12AffineFastState.compose env20719 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound20719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20720 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,8,1,0,2,17,1,21,1,1,0,17,2,8,17,1,16,17,0,20,1,5,0,1,31]

theorem envBound20720 : H12AffineFastState.Bounded env20720 := by
  intro p hp
  have h : env20720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20719_20720 : H12AffineEnvironment.transform 8 31 env20719 = env20720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env20719 == env20720) = true)

def leafEnv20720 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,8,1,0,2,17,1,21,1,1,0,17,2,21,8,1,17,1,16,17,0,20,1,5,0,5,2,1,31,1,1,0]

def active20720 : List Nat := [0,1,2,3]

def tree20720 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20720 : H12WitnessSearch.Good tree20720 := H12GlobalWitnessIndex.good

theorem leafIdentity20720 : H12AffineFastState.composeSystem env20720 rootObs = leafEnv20720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20720 rootObs == leafEnv20720) = true)

theorem terminalChecked20720 : H12PackedTerminal.terminalCheckFast leafEnv20720 active20720 tree20720 = true := by decide +kernel

def env20721 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,0,2,16,1,20,1,1,0,17,2,8,17,1,17,17,0,21,1,5,0,0,512]

theorem envBound20721 : H12AffineFastState.Bounded env20721 := by
  intro p hp
  have h : env20721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20718_20721 : H12AffineEnvironment.transform 9 21 env20718 = env20721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20718 == env20721) = true)

theorem identity20721 : scanCanonicalize (H12AffineFastState.compose env20721 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound20721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20722 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,0,2,5,1,1,1,1,0,4,2,8,4,1,4,4,0,0,1,5,0,0,512]

theorem envBound20722 : H12AffineFastState.Bounded env20722 := by
  intro p hp
  have h : env20722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20721_20722 : H12AffineEnvironment.transform 3 5 env20721 = env20722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env20721 == env20722) = true)

def leafEnv20722 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,0,2,5,1,1,1,1,0,4,2,1,8,1,4,1,4,4,0,0,1,5,0,5,2,0,512,1,1,0]

def active20722 : List Nat := [0,1,2,8]

def tree20722 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20722 : H12WitnessSearch.Good tree20722 := H12GlobalWitnessIndex.good

theorem leafIdentity20722 : H12AffineFastState.composeSystem env20722 rootObs = leafEnv20722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20722 rootObs == leafEnv20722) = true)

theorem terminalChecked20722 : H12PackedTerminal.terminalCheckFast leafEnv20722 active20722 tree20722 = true := by decide +kernel

def env20723 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1044,0,2,1028,2049,1025,1,0,0,17,2,8,17,2049,1029,16,2048,1024,1,5,0,1044,512]

theorem envBound20723 : H12AffineFastState.Bounded env20723 := by
  intro p hp
  have h : env20723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20716_20723 : H12AffineEnvironment.transform 11 17 env20716 = env20723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20716 == env20723) = true)

theorem identity20723 : scanCanonicalize (H12AffineFastState.compose env20723 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound20723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20724 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,17,8,1044,0,2,1028,1044,1025,1,0,0,17,2,8,17,1044,1029,16,1045,1024,1,5,0,1044,512]

theorem envBound20724 : H12AffineFastState.Bounded env20724 := by
  intro p hp
  have h : env20724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20723_20724 : H12AffineEnvironment.transform 10 1045 env20723 = env20724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env20723 == env20724) = true)

def env20725 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,0,0,2,16,0,21,1,0,0,17,2,8,17,0,17,16,1,20,1,5,0,0,512]

theorem envBound20725 : H12AffineFastState.Bounded env20725 := by
  intro p hp
  have h : env20725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20724_20725 : H12AffineEnvironment.transform 9 20 env20724 = env20725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20724 == env20725) = true)

theorem identity20725 : scanCanonicalize (H12AffineFastState.compose env20725 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound20725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20726 : List Nat := [2,4,8,16,0,16,8,4,30,20,1,17,8,0,0,2,16,0,21,1,0,0,17,2,8,17,0,17,16,1,20,1,5,0,0,30]

theorem envBound20726 : H12AffineFastState.Bounded env20726 := by
  intro p hp
  have h : env20726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20725_20726 : H12AffineEnvironment.transform 8 30 env20725 = env20726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env20725 == env20726) = true)

def leafEnv20726 : List Nat := [2,4,8,16,0,16,8,4,30,20,1,17,8,0,0,2,16,0,21,1,0,0,17,2,21,8,1,17,0,17,16,1,20,1,5,0,5,2,0,30,1,0,0]

def active20726 : List Nat := [0,1,2,3]

def tree20726 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20726 : H12WitnessSearch.Good tree20726 := H12GlobalWitnessIndex.good

theorem leafIdentity20726 : H12AffineFastState.composeSystem env20726 rootObs = leafEnv20726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20726 rootObs == leafEnv20726) = true)

theorem terminalChecked20726 : H12PackedTerminal.terminalCheckFast leafEnv20726 active20726 tree20726 = true := by decide +kernel

def env20727 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,1,0,2,17,1,20,1,0,0,17,2,8,17,1,16,16,0,21,1,5,0,1,512]

theorem envBound20727 : H12AffineFastState.Bounded env20727 := by
  intro p hp
  have h : env20727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20724_20727 : H12AffineEnvironment.transform 9 21 env20724 = env20727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env20724 == env20727) = true)

theorem identity20727 : scanCanonicalize (H12AffineFastState.compose env20727 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound20727 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20728 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,8,1,0,2,4,1,1,1,0,0,4,2,8,4,1,5,5,0,0,1,5,0,1,512]

theorem envBound20728 : H12AffineFastState.Bounded env20728 := by
  intro p hp
  have h : env20728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20727_20728 : H12AffineEnvironment.transform 3 5 env20727 = env20728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env20727 == env20728) = true)

def leafEnv20728 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,8,1,0,2,4,1,1,1,0,0,4,2,1,8,1,4,1,5,5,0,0,1,5,0,5,2,1,512,1,0,0]

def active20728 : List Nat := [0,1,2,8]

def tree20728 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20728 : H12WitnessSearch.Good tree20728 := H12GlobalWitnessIndex.good

theorem leafIdentity20728 : H12AffineFastState.composeSystem env20728 rootObs = leafEnv20728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20728 rootObs == leafEnv20728) = true)

theorem terminalChecked20728 : H12PackedTerminal.terminalCheckFast leafEnv20728 active20728 tree20728 = true := by decide +kernel

def env20729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,290152,272392,294200,21763,8193,65,398436,288825,17664,179512,292988,41341,257,21793,46092,297845]

theorem envBound20729 : H12AffineFastState.Bounded env20729 := by
  intro p hp
  have h : env20729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20707_20729 : H12AffineEnvironment.transform 6 9 env20707 = env20729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20707 == env20729) = true)

theorem identity20729 : scanCanonicalize (H12AffineFastState.compose env20729 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound20729 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35188,1025,32769,58396,41340,62540,21763,8193,65,171280,57677,17664,179512,61704,41341,257,21793,46092,513]

theorem envBound20730 : H12AffineFastState.Bounded env20730 := by
  intro p hp
  have h : env20730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20729_20730 : H12AffineEnvironment.transform 17 35188 env20729 = env20730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env20729 == env20730) = true)

theorem identity20730 : scanCanonicalize (H12AffineFastState.compose env20730 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound20730 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env20731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16400,35188,1025,32769,58396,41340,62540,21763,8193,65,56576,57677,17664,64808,61704,41341,257,21793,46092,513]

theorem envBound20731 : H12AffineFastState.Bounded env20731 := by
  intro p hp
  have h : env20731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20730_20731 : H12AffineEnvironment.transform 16 16400 env20730 = env20731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20730 == env20731) = true)

end H12CloudChart1