import H12CloudChart1Data056

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity14323 : scanCanonicalize (H12AffineFastState.compose env14323 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound14323 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14324 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,4112,11293,8203,4096,10280,1024,11292,6161,4372,16,3347,8193,16,14393,7441,7441,1076,1285,4373,256,3377,4113,513]

theorem envBound14324 : H12AffineFastState.Bounded env14324 := by
  intro p hp
  have h : env14324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14323_14324 : H12AffineEnvironment.transform 13 4112 env14323 = env14324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env14323 == env14324) = true)

theorem identity14324 : scanCanonicalize (H12AffineFastState.compose env14324 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound14324 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14325 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5417,4112,6452,5410,4096,7425,1024,6453,6161,4372,16,3347,5416,16,3344,7441,7441,1076,1285,4373,256,3377,4113,513]

theorem envBound14325 : H12AffineFastState.Bounded env14325 := by
  intro p hp
  have h : env14325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14324_14325 : H12AffineEnvironment.transform 12 5417 env14324 = env14325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env14324 == env14325) = true)

theorem identity14325 : scanCanonicalize (H12AffineFastState.compose env14325 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound14325 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14326 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,2089,3344,1076,2082,3328,1,1024,1077,1297,3092,16,3347,2088,16,3344,17,17,1076,1285,3093,256,3377,3345,513]

theorem envBound14326 : H12AffineFastState.Bounded env14326 := by
  intro p hp
  have h : env14326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14325_14326 : H12AffineEnvironment.transform 11 3328 env14325 = env14326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env14325 == env14326) = true)

theorem identity14326 : scanCanonicalize (H12AffineFastState.compose env14326 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14326 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env14327 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,3328,2089,3344,1076,2082,3328,1,1024,1077,1297,3092,16,3347,2088,16,3344,17,17,1076,1285,3093,256,3377,3345,1]

theorem envBound14327 : H12AffineFastState.Bounded env14327 := by
  intro p hp
  have h : env14327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14326_14327 : H12AffineEnvironment.transform 8 0 env14326 = env14327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14326 == env14327) = true)

theorem identity14327 : scanCanonicalize (H12AffineFastState.compose env14327 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14327 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14328 : List Nat := [2,4,8,16,32,16,9,256,0,273,2048,2065,2089,2049,293,2082,2065,1,273,292,0,2309,16,2050,2088,16,2049,17,17,293,20,2308,256,2080,2048,1]

theorem envBound14328 : H12AffineFastState.Bounded env14328 := by
  intro p hp
  have h : env14328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14327_14328 : H12AffineEnvironment.transform 9 273 env14327 = env14328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14327 == env14328) = true)

theorem identity14328 : scanCanonicalize (H12AffineFastState.compose env14328 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound14328 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14329 : List Nat := [2,4,8,16,32,16,9,256,0,273,293,308,268,292,293,263,308,1,273,292,0,32,16,295,269,16,292,17,17,293,20,33,256,261,293,1]

theorem envBound14329 : H12AffineFastState.Bounded env14329 := by
  intro p hp
  have h : env14329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14328_14329 : H12AffineEnvironment.transform 10 293 env14328 = env14329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env14328 == env14329) = true)

theorem identity14329 : scanCanonicalize (H12AffineFastState.compose env14329 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound14329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14330 : List Nat := [2,4,8,16,32,16,9,20,0,5,49,32,24,48,49,19,32,1,5,48,0,32,16,51,25,16,48,17,17,49,20,33,20,17,49,1]

theorem envBound14330 : H12AffineFastState.Bounded env14330 := by
  intro p hp
  have h : env14330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14329_14330 : H12AffineEnvironment.transform 7 20 env14329 = env14330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env14329 == env14330) = true)

theorem identity14330 : scanCanonicalize (H12AffineFastState.compose env14330 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14330 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14331 : List Nat := [2,4,8,16,1,16,9,20,0,5,16,1,24,17,16,19,1,1,5,17,0,1,16,18,25,16,17,17,17,16,20,0,20,17,16,1]

theorem envBound14331 : H12AffineFastState.Bounded env14331 := by
  intro p hp
  have h : env14331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14330_14331 : H12AffineEnvironment.transform 4 1 env14330 = env14331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14330 == env14331) = true)

def env14332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8193,16,4409655,114967,45324,190520,75022,4268042,256,98599,90122,513]

theorem envBound14332 : H12AffineFastState.Bounded env14332 := by
  intro p hp
  have h : env14332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14318_14332 : H12AffineEnvironment.transform 17 10281 env14318 = env14332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14318 == env14332) = true)

theorem identity14332 : scanCanonicalize (H12AffineFastState.compose env14332 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound14332 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env14333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246070,16,41230,8193,16,34817,114967,45324,190520,75022,188732,256,98599,90122,513]

theorem envBound14333 : H12AffineFastState.Bounded env14333 := by
  intro p hp
  have h : env14333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14332_14333 : H12AffineEnvironment.transform 21 246070 env14332 = env14333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env14332 == env14333) = true)

theorem identity14333 : scanCanonicalize (H12AffineFastState.compose env14333 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound14333 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env14334 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,114967,10281,1024,32769,58396,33,16,41230,8193,16,34817,114967,45324,76079,75022,73771,256,98599,90122,513]

theorem envBound14334 : H12AffineFastState.Bounded env14334 := by
  intro p hp
  have h : env14334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14333_14334 : H12AffineEnvironment.transform 16 114967 env14333 = env14334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env14333 == env14334) = true)

theorem identity14334 : scanCanonicalize (H12AffineFastState.compose env14334 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14334 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env14335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,49169,10281,1024,32769,58396,33,16,41230,8193,16,34817,49169,45324,10281,9224,8493,256,32801,24844,513]

theorem envBound14335 : H12AffineFastState.Bounded env14335 := by
  intro p hp
  have h : env14335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14334_14335 : H12AffineEnvironment.transform 15 262 env14334 = env14335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14334 == env14335) = true)

theorem identity14335 : scanCanonicalize (H12AffineFastState.compose env14335 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound14335 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14336 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,262,24861,10281,1024,8461,17680,33,16,2,8193,16,10509,24861,4096,10281,9224,8493,256,8493,24844,513]

theorem envBound14336 : H12AffineFastState.Bounded env14336 := by
  intro p hp
  have h : env14336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14335_14336 : H12AffineEnvironment.transform 14 8460 env14335 = env14336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env14335 == env14336) = true)

theorem identity14336 : scanCanonicalize (H12AffineFastState.compose env14336 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14336 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14337 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1024,1,17680,33,16,2,269,16,2049,16401,4096,2341,1284,33,256,33,16384,513]

theorem envBound14337 : H12AffineFastState.Bounded env14337 := by
  intro p hp
  have h : env14337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14336_14337 : H12AffineEnvironment.transform 12 268 env14336 = env14337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14336 == env14337) = true)

theorem identity14337 : scanCanonicalize (H12AffineFastState.compose env14337 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound14337 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14338 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,17,268,16384,0,262,16401,2341,1024,1,17680,33,16,2,269,16,2049,16401,17,2341,1284,33,256,33,16384,513]

theorem envBound14338 : H12AffineFastState.Bounded env14338 := by
  intro p hp
  have h : env14338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14337_14338 : H12AffineEnvironment.transform 11 17 env14337 = env14338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14337 == env14338) = true)

def env14339 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8193,17,4677919,114966,45325,442385,75023,4268042,256,98598,90123,513]

theorem envBound14339 : H12AffineFastState.Bounded env14339 := by
  intro p hp
  have h : env14339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14317_14339 : H12AffineEnvironment.transform 5 17 env14317 = env14339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14317 == env14339) = true)

theorem identity14339 : scanCanonicalize (H12AffineFastState.compose env14339 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14339 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env14340 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4409654,114966,45325,190520,75023,4268042,256,98598,90123,513]

theorem envBound14340 : H12AffineFastState.Bounded env14340 := by
  intro p hp
  have h : env14340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14339_14340 : H12AffineEnvironment.transform 17 10281 env14339 = env14340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14339 == env14340) = true)

theorem identity14340 : scanCanonicalize (H12AffineFastState.compose env14340 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound14340 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env14341 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4385084,24860,45325,190520,34053,4227072,256,8492,49153,513]

theorem envBound14341 : H12AffineFastState.Bounded env14341 := by
  intro p hp
  have h : env14341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14340_14341 : H12AffineEnvironment.transform 15 40970 env14340 = env14341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env14340 == env14341) = true)

theorem identity14341 : scanCanonicalize (H12AffineFastState.compose env14341 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound14341 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14342 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58396,147504,16,41231,8193,17,43276,24860,45325,190520,34053,180272,256,8492,49153,513]

theorem envBound14342 : H12AffineFastState.Bounded env14342 := by
  intro p hp
  have h : env14342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14341_14342 : H12AffineEnvironment.transform 21 147504 env14341 = env14342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env14341 == env14342) = true)

theorem identity14342 : scanCanonicalize (H12AffineFastState.compose env14342 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound14342 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14343 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,24860,10281,1024,32769,58396,8492,16,41231,8193,17,43276,24860,45325,35108,34053,41260,256,8492,49153,513]

theorem envBound14343 : H12AffineFastState.Bounded env14343 := by
  intro p hp
  have h : env14343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14342_14343 : H12AffineEnvironment.transform 16 24860 env14342 = env14343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env14342 == env14343) = true)

def env14344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4677966,115014,45405,442385,75102,4268043,256,98678,90203,513]

theorem envBound14344 : H12AffineFastState.Bounded env14344 := by
  intro p hp
  have h : env14344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14316_14344 : H12AffineEnvironment.transform 20 58397 env14316 = env14344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env14316 == env14344) = true)

theorem identity14344 : scanCanonicalize (H12AffineFastState.compose env14344 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14344 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,4194304,16,41310,8193,64,4604228,57676,45405,442385,1364,4194305,256,41340,16465,513]

theorem envBound14345 : H12AffineFastState.Bounded env14345 := by
  intro p hp
  have h : env14345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14344_14345 : H12AffineEnvironment.transform 15 8202 env14344 = env14345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14344 == env14345) = true)

theorem identity14345 : scanCanonicalize (H12AffineFastState.compose env14345 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound14345 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env14346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419912,16,41310,8193,64,10508,57676,45405,442385,1364,419913,256,41340,16465,513]

theorem envBound14346 : H12AffineFastState.Bounded env14346 := by
  intro p hp
  have h : env14346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14345_14346 : H12AffineEnvironment.transform 21 419912 env14345 = env14346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env14345 == env14346) = true)

def env14347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58397,272392,16,41310,8193,64,10508,57676,45405,294993,1364,272393,256,41340,16465,513]

theorem envBound14347 : H12AffineFastState.Bounded env14347 := by
  intro p hp
  have h : env14347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14346_14347 : H12AffineEnvironment.transform 16 16448 env14346 = env14347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env14346 == env14347) = true)

theorem identity14347 : scanCanonicalize (H12AffineFastState.compose env14347 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound14347 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,43048,1024,32769,58397,32800,16,41310,8193,64,10508,57676,45405,10361,1364,32801,256,41340,16465,513]

theorem envBound14348 : H12AffineFastState.Bounded env14348 := by
  intro p hp
  have h : env14348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14347_14348 : H12AffineEnvironment.transform 17 43048 env14347 = env14348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env14347 == env14348) = true)

theorem identity14348 : scanCanonicalize (H12AffineFastState.compose env14348 (packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14348 : packedSelected [0,1,2,3,5,6,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env14349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16448,10281,1024,0,25628,33,16,8543,8193,64,10508,24909,12636,10361,1364,32,256,8573,16465,513]

theorem envBound14349 : H12AffineFastState.Bounded env14349 := by
  intro p hp
  have h : env14349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14348_14349 : H12AffineEnvironment.transform 14 1 env14348 = env14349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14348 == env14349) = true)

theorem identity14349 : scanCanonicalize (H12AffineFastState.compose env14349 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14350 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,16400,10281,1024,0,25628,33,16,8463,8193,16,10508,24861,12556,10281,1284,32,256,8493,16385,513]

theorem envBound14350 : H12AffineFastState.Bounded env14350 := by
  intro p hp
  have h : env14350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14349_14350 : H12AffineEnvironment.transform 5 16 env14349 = env14350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14349 == env14350) = true)

theorem identity14350 : scanCanonicalize (H12AffineFastState.compose env14350 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11270) := by decide +kernel

theorem selectedBound14350 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env14351 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,11270,1,8202,11286,10281,1024,0,2074,33,16,8463,8193,16,10508,3355,12556,10281,1284,32,256,8493,11271,513]

theorem envBound14351 : H12AffineFastState.Bounded env14351 := by
  intro p hp
  have h : env14351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14350_14351 : H12AffineEnvironment.transform 13 11270 env14350 = env14351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11270 env14350 == env14351) = true)

theorem identity14351 : scanCanonicalize (H12AffineFastState.compose env14351 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound14351 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env14352 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2091,8192,11270,1,8202,11286,10281,1024,0,2074,33,16,8463,8193,16,10508,3355,10535,10281,1284,32,256,8493,11271,513]

theorem envBound14352 : H12AffineFastState.Bounded env14352 := by
  intro p hp
  have h : env14352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14351_14352 : H12AffineEnvironment.transform 11 2091 env14351 = env14352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env14351 == env14352) = true)

theorem identity14352 : scanCanonicalize (H12AffineFastState.compose env14352 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14352 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14353 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2091,268,3338,1,262,3354,2341,1024,0,2074,33,16,3,269,16,2048,3355,2091,2341,1284,32,256,33,3339,513]

theorem envBound14353 : H12AffineFastState.Bounded env14353 := by
  intro p hp
  have h : env14353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14352_14353 : H12AffineEnvironment.transform 12 268 env14352 = env14353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14352 == env14353) = true)

theorem identity14353 : scanCanonicalize (H12AffineFastState.compose env14353 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound14353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14354 : List Nat := [2,4,8,16,32,16,9,256,512,1024,271,292,268,1029,1,262,1045,42,1024,0,277,33,16,3,269,16,271,1044,292,42,1284,32,256,33,1028,513]

theorem envBound14354 : H12AffineFastState.Bounded env14354 := by
  intro p hp
  have h : env14354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14353_14354 : H12AffineEnvironment.transform 10 271 env14353 = env14354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env14353 == env14354) = true)

theorem identity14354 : scanCanonicalize (H12AffineFastState.compose env14354 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14354 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14355 : List Nat := [2,4,8,16,32,16,9,37,512,1024,42,1,41,1029,1,35,1045,42,1024,0,48,33,16,3,40,16,42,1044,1,42,1057,32,37,33,1028,513]

theorem envBound14355 : H12AffineFastState.Bounded env14355 := by
  intro p hp
  have h : env14355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14354_14355 : H12AffineEnvironment.transform 7 37 env14354 = env14355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14354 == env14355) = true)

theorem identity14355 : scanCanonicalize (H12AffineFastState.compose env14355 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound14355 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14356 : List Nat := [2,4,8,16,32,16,9,37,512,21,42,1,41,16,1,35,0,42,21,0,48,33,16,3,40,16,42,1,1,42,52,32,37,33,17,513]

theorem envBound14356 : H12AffineFastState.Bounded env14356 := by
  intro p hp
  have h : env14356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14355_14356 : H12AffineEnvironment.transform 9 21 env14355 = env14356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14355 == env14356) = true)

def env14357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58397,272393,16,41310,8193,64,10508,57676,45405,294992,1364,272392,256,41340,16465,513]

theorem envBound14357 : H12AffineFastState.Bounded env14357 := by
  intro p hp
  have h : env14357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14346_14357 : H12AffineEnvironment.transform 16 16449 env14346 = env14357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env14346 == env14357) = true)

theorem identity14357 : scanCanonicalize (H12AffineFastState.compose env14357 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound14357 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,35108,1024,32769,58397,41261,16,41310,8193,64,10508,57676,45405,2420,1364,41260,256,41340,16465,513]

theorem envBound14358 : H12AffineFastState.Bounded env14358 := by
  intro p hp
  have h : env14358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14357_14358 : H12AffineEnvironment.transform 17 35108 env14357 = env14358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env14357 == env14358) = true)

theorem identity14358 : scanCanonicalize (H12AffineFastState.compose env14358 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14358 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env14359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,35108,1024,32769,50496,32880,16,32771,348,64,2129,49169,36864,2420,1364,32881,256,32801,16465,513]

theorem envBound14359 : H12AffineFastState.Bounded env14359 := by
  intro p hp
  have h : env14359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14358_14359 : H12AffineEnvironment.transform 12 349 env14358 = env14359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14358 == env14359) = true)

theorem identity14359 : scanCanonicalize (H12AffineFastState.compose env14359 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound14359 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,80,343,16449,2420,1024,81,17680,32,16,83,348,64,2129,16449,4176,2420,1364,33,256,113,16465,513]

theorem envBound14360 : H12AffineFastState.Bounded env14360 := by
  intro p hp
  have h : env14360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14359_14360 : H12AffineEnvironment.transform 14 80 env14359 = env14360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env14359 == env14360) = true)

theorem identity14360 : scanCanonicalize (H12AffineFastState.compose env14360 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14360 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14361 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,263,16401,2340,1024,1,17680,32,16,3,268,16,2049,16401,4096,2340,1284,33,256,33,16385,513]

theorem envBound14361 : H12AffineFastState.Bounded env14361 := by
  intro p hp
  have h : env14361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14360_14361 : H12AffineEnvironment.transform 5 16 env14360 = env14361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14360 == env14361) = true)

theorem identity14361 : scanCanonicalize (H12AffineFastState.compose env14361 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14362 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,16384,0,263,16401,2309,1024,1,17680,1,16,3,268,16,2049,16401,4096,2309,1284,0,256,0,16385,513]

theorem envBound14362 : H12AffineFastState.Bounded env14362 := by
  intro p hp
  have h : env14362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14361_14362 : H12AffineEnvironment.transform 4 1 env14361 = env14362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14361 == env14362) = true)

theorem identity14362 : scanCanonicalize (H12AffineFastState.compose env14362 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound14362 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14363 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,17,269,16384,0,263,16401,2309,1024,1,17680,1,16,3,268,16,2049,16401,17,2309,1284,0,256,0,16385,513]

theorem envBound14363 : H12AffineFastState.Bounded env14363 := by
  intro p hp
  have h : env14363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14362_14363 : H12AffineEnvironment.transform 11 17 env14362 = env14363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14362 == env14363) = true)

theorem identity14363 : scanCanonicalize (H12AffineFastState.compose env14363 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound14363 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14364 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,17,269,1809,0,263,1792,2309,1024,1,513,1,16,3,268,16,2049,1792,17,2309,1284,0,256,0,1808,513]

theorem envBound14364 : H12AffineFastState.Bounded env14364 := by
  intro p hp
  have h : env14364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14363_14364 : H12AffineEnvironment.transform 13 1809 env14363 = env14364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env14363 == env14364) = true)

theorem identity14364 : scanCanonicalize (H12AffineFastState.compose env14364 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound14364 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14365 : List Nat := [2,4,8,16,1,16,9,256,512,1024,528,17,269,1809,0,263,1792,789,1024,1,513,1,16,3,268,16,529,1792,17,789,1284,0,256,0,1808,513]

theorem envBound14365 : H12AffineFastState.Bounded env14365 := by
  intro p hp
  have h : env14365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14364_14365 : H12AffineEnvironment.transform 10 528 env14364 = env14365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env14364 == env14365) = true)

theorem identity14365 : scanCanonicalize (H12AffineFastState.compose env14365 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound14365 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14366 : List Nat := [2,4,8,16,1,16,9,256,512,257,528,17,269,528,0,263,513,789,257,1,513,1,16,3,268,16,529,513,17,789,5,0,256,0,529,513]

theorem envBound14366 : H12AffineFastState.Bounded env14366 := by
  intro p hp
  have h : env14366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14365_14366 : H12AffineEnvironment.transform 9 257 env14365 = env14366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env14365 == env14366) = true)

theorem identity14366 : scanCanonicalize (H12AffineFastState.compose env14366 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound14366 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14367 : List Nat := [2,4,8,16,1,16,9,256,260,257,276,17,269,276,0,263,261,17,257,1,261,1,16,3,268,16,277,261,17,17,5,0,256,0,277,261]

theorem envBound14367 : H12AffineFastState.Bounded env14367 := by
  intro p hp
  have h : env14367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14366_14367 : H12AffineEnvironment.transform 8 260 env14366 = env14367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env14366 == env14367) = true)

def env14368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound14368 : H12AffineFastState.Bounded env14368 := by
  intro p hp
  have h : env14368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14278_14368 : H12AffineEnvironment.transform 18 1025 env14278 = env14368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14278 == env14368) = true)

theorem identity14368 : scanCanonicalize (H12AffineFastState.compose env14368 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 254096) := by decide +kernel

theorem selectedBound14368 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,254096,8328,64,12853393,2253853,10507600,8830976,8545408,6456657,257,10626109,10667416,8602455]

theorem envBound14369 : H12AffineFastState.Bounded env14369 := by
  intro p hp
  have h : env14369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14368_14369 : H12AffineEnvironment.transform 23 254096 env14368 = env14369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env14368 == env14369) = true)

def env14370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257180,254096,8328,64,6705549,2253853,140364,2404636,2102684,6456657,257,21793,46212,2175563]

theorem envBound14370 : H12AffineFastState.Bounded env14370 := by
  intro p hp
  have h : env14370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14369_14370 : H12AffineEnvironment.transform 22 2257180 env14369 = env14370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257180 env14369 == env14370) = true)

def env14371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257180,254096,8328,64,2157717,2253853,140364,2404636,2102684,2373705,257,21793,46212,2175563]

theorem envBound14371 : H12AffineFastState.Bounded env14371 := by
  intro p hp
  have h : env14371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14370_14371 : H12AffineEnvironment.transform 21 441624 env14370 = env14371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env14370 == env14371) = true)

def env14372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,254096,8328,64,64725,160861,140364,303452,1500,272393,257,21793,46212,74251]

theorem envBound14372 : H12AffineFastState.Bounded env14372 := by
  intro p hp
  have h : env14372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14371_14372 : H12AffineEnvironment.transform 20 4160 env14371 = env14372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14371 == env14372) = true)

theorem identity14372 : scanCanonicalize (H12AffineFastState.compose env14372 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14372 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,441624,155996,180378,8328,64,64725,160861,140364,303452,1500,272393,257,21793,46212,513]

theorem envBound14373 : H12AffineFastState.Bounded env14373 := by
  intro p hp
  have h : env14373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14372_14373 : H12AffineEnvironment.transform 15 8202 env14372 = env14373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14372 == env14373) = true)

def env14374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,326920,8524,32906,8328,64,64725,13389,25692,303452,1500,272393,257,21793,46212,513]

theorem envBound14374 : H12AffineFastState.Bounded env14374 := by
  intro p hp
  have h : env14374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14373_14374 : H12AffineEnvironment.transform 16 16400 env14373 = env14374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14373 == env14374) = true)

theorem identity14374 : scanCanonicalize (H12AffineFastState.compose env14374 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14374 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,262144,1025,32769,4160,318549,17,32906,469,64,56712,5392,17665,294913,1500,264532,257,21793,38361,513]

theorem envBound14375 : H12AffineFastState.Bounded env14375 := by
  intro p hp
  have h : env14375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14374_14375 : H12AffineEnvironment.transform 12 349 env14374 = env14375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14374 == env14375) = true)

theorem identity14375 : scanCanonicalize (H12AffineFastState.compose env14375 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound14375 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,56573,1025,32769,4160,168,17,32906,469,64,56712,5392,17665,23804,1500,54697,257,21793,38361,513]

theorem envBound14376 : H12AffineFastState.Bounded env14376 := by
  intro p hp
  have h : env14376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14375_14376 : H12AffineEnvironment.transform 17 56573 env14375 = env14376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env14375 == env14376) = true)

theorem identity14376 : scanCanonicalize (H12AffineFastState.compose env14376 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14376 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env14377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,16400,56437,1025,32769,4160,32,17,32770,349,64,56576,5392,17665,23668,1364,54561,257,21793,38225,513]

theorem envBound14377 : H12AffineFastState.Bounded env14377 := by
  intro p hp
  have h : env14377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14376_14377 : H12AffineEnvironment.transform 6 8 env14376 = env14377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14376 == env14377) = true)

theorem identity14377 : scanCanonicalize (H12AffineFastState.compose env14377 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound14377 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16400,2420,1025,21760,4160,32,17,21763,349,64,2049,5392,17665,23668,1364,32,257,21793,16464,513]

theorem envBound14378 : H12AffineFastState.Bounded env14378 := by
  intro p hp
  have h : env14378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14377_14378 : H12AffineEnvironment.transform 14 21761 env14377 = env14378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env14377 == env14378) = true)

theorem identity14378 : scanCanonicalize (H12AffineFastState.compose env14378 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14378 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,343,5440,2420,1025,80,4160,32,17,83,349,64,2049,5392,4177,2340,1364,32,257,113,5376,513]

theorem envBound14379 : H12AffineFastState.Bounded env14379 := by
  intro p hp
  have h : env14379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14378_14379 : H12AffineEnvironment.transform 13 5456 env14378 = env14379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14378 == env14379) = true)

theorem identity14379 : scanCanonicalize (H12AffineFastState.compose env14379 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound14379 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env14380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1054,349,334,81,343,350,2420,1025,80,1118,32,17,83,349,64,2049,270,1103,2340,1364,32,257,113,286,513]

theorem envBound14380 : H12AffineFastState.Bounded env14380 := by
  intro p hp
  have h : env14380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14379_14380 : H12AffineEnvironment.transform 11 1054 env14379 = env14380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env14379 == env14380) = true)

theorem identity14380 : scanCanonicalize (H12AffineFastState.compose env14380 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 350) := by decide +kernel

theorem selectedBound14380 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env14381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,350,1054,349,334,81,343,350,42,1025,80,1118,32,17,83,349,64,351,270,1103,122,1364,32,257,113,286,513]

theorem envBound14381 : H12AffineFastState.Bounded env14381 := by
  intro p hp
  have h : env14381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14380_14381 : H12AffineEnvironment.transform 10 350 env14380 = env14381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 350 env14380 == env14381) = true)

theorem identity14381 : scanCanonicalize (H12AffineFastState.compose env14381 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound14381 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env14382 : List Nat := [2,4,8,16,32,64,8,52,512,1024,106,1054,105,122,81,99,106,42,1025,80,1118,32,17,83,105,64,107,58,1103,122,1120,32,53,113,42,513]

theorem envBound14382 : H12AffineFastState.Bounded env14382 := by
  intro p hp
  have h : env14382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14381_14382 : H12AffineEnvironment.transform 7 52 env14381 = env14382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env14381 == env14382) = true)

theorem identity14382 : scanCanonicalize (H12AffineFastState.compose env14382 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14382 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env14383 : List Nat := [2,4,8,16,32,64,8,52,512,53,106,43,105,122,81,99,106,42,52,80,107,32,17,83,105,64,107,58,122,122,85,32,53,113,42,513]

theorem envBound14383 : H12AffineFastState.Bounded env14383 := by
  intro p hp
  have h : env14383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14382_14383 : H12AffineEnvironment.transform 9 53 env14382 = env14383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14382 == env14383) = true)

theorem identity14383 : scanCanonicalize (H12AffineFastState.compose env14383 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound14383 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14384 : List Nat := [2,4,8,16,32,26,8,52,512,53,48,43,51,32,11,57,48,42,52,10,49,32,17,9,51,26,49,58,32,32,15,32,53,43,42,513]

theorem envBound14384 : H12AffineFastState.Bounded env14384 := by
  intro p hp
  have h : env14384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14383_14384 : H12AffineEnvironment.transform 5 26 env14383 = env14384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env14383 == env14384) = true)

theorem identity14384 : scanCanonicalize (H12AffineFastState.compose env14384 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound14384 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14385 : List Nat := [2,4,4,16,32,22,4,52,512,53,48,39,51,32,7,53,48,38,52,6,49,32,17,5,51,22,49,54,32,32,3,32,53,39,38,513]

theorem envBound14385 : H12AffineFastState.Bounded env14385 := by
  intro p hp
  have h : env14385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14384_14385 : H12AffineEnvironment.transform 2 4 env14384 = env14385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env14384 == env14385) = true)

theorem identity14385 : scanCanonicalize (H12AffineFastState.compose env14385 (packedSelected [0,2,3,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound14385 : packedSelected [0,2,3,11] rootPS < 2^1333 := by decide +kernel

def env14386 : List Nat := [2,3,3,16,32,17,3,51,512,50,48,32,51,32,0,50,48,33,51,1,49,32,17,2,51,17,49,49,32,32,3,32,50,32,33,513]

theorem envBound14386 : H12AffineFastState.Bounded env14386 := by
  intro p hp
  have h : env14386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14385_14386 : H12AffineEnvironment.transform 1 3 env14385 = env14386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env14385 == env14386) = true)

theorem identity14386 : scanCanonicalize (H12AffineFastState.compose env14386 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14387 : List Nat := [2,3,3,1,32,0,3,34,512,35,33,32,34,32,0,35,33,33,34,1,32,32,0,2,34,0,32,32,32,32,3,32,35,32,33,513]

theorem envBound14387 : H12AffineFastState.Bounded env14387 := by
  intro p hp
  have h : env14387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14386_14387 : H12AffineEnvironment.transform 3 1 env14386 = env14387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14386 == env14387) = true)

theorem identity14387 : scanCanonicalize (H12AffineFastState.compose env14387 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound14387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14388 : List Nat := [2,3,3,1,32,0,3,34,35,35,33,32,34,32,0,35,33,33,34,1,32,32,0,2,34,0,32,32,32,32,3,32,35,32,33,34]

theorem envBound14388 : H12AffineFastState.Bounded env14388 := by
  intro p hp
  have h : env14388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14387_14388 : H12AffineEnvironment.transform 8 35 env14387 = env14388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env14387 == env14388) = true)

theorem identity14388 : scanCanonicalize (H12AffineFastState.compose env14388 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14388 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14389 : List Nat := [2,3,3,1,0,0,3,2,3,3,1,0,2,0,0,3,1,1,2,1,0,0,0,2,2,0,0,0,0,0,3,0,3,0,1,2]

theorem envBound14389 : H12AffineFastState.Bounded env14389 := by
  intro p hp
  have h : env14389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14388_14389 : H12AffineEnvironment.transform 4 0 env14388 = env14389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14388 == env14389) = true)

def env14390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326921,8525,32907,8328,64,64725,13388,25693,303452,1500,272393,257,21793,46212,513]

theorem envBound14390 : H12AffineFastState.Bounded env14390 := by
  intro p hp
  have h : env14390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14373_14390 : H12AffineEnvironment.transform 16 16401 env14373 = env14390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14373 == env14390) = true)

def env14391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326921,8525,32771,8192,64,64605,13388,25693,303452,1364,272393,257,21793,46092,513]

theorem envBound14391 : H12AffineFastState.Bounded env14391 := by
  intro p hp
  have h : env14391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14390_14391 : H12AffineEnvironment.transform 6 8 env14390 = env14391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14390 == env14391) = true)

def env14392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,326921,8525,32770,8193,64,64604,13388,25693,303452,1365,272393,257,21793,46093,513]

theorem envBound14392 : H12AffineFastState.Bounded env14392 := by
  intro p hp
  have h : env14392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14390_14392 : H12AffineEnvironment.transform 6 9 env14390 = env14392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14390 == env14392) = true)

theorem identity14392 : scanCanonicalize (H12AffineFastState.compose env14392 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound14392 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env14393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,32768,8202,12637,262144,1025,32769,4160,298053,8525,32770,8193,64,36112,13388,5393,303452,1365,272393,257,9325,46093,513]

theorem envBound14393 : H12AffineFastState.Bounded env14393 := by
  intro p hp
  have h : env14393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14392_14393 : H12AffineEnvironment.transform 13 12620 env14392 = env14393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env14392 == env14393) = true)

theorem identity14393 : scanCanonicalize (H12AffineFastState.compose env14393 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound14393 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env14394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1297,8202,12637,262144,1025,1296,4160,264532,8525,1299,8193,64,2049,13388,5393,271437,1365,272393,257,9325,12572,513]

theorem envBound14394 : H12AffineFastState.Bounded env14394 := by
  intro p hp
  have h : env14394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14393_14394 : H12AffineEnvironment.transform 14 1297 env14393 = env14394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env14393 == env14394) = true)

theorem identity14394 : scanCanonicalize (H12AffineFastState.compose env14394 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound14394 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1297,8202,12637,10280,1025,1296,4160,8572,8525,1299,8193,64,2049,13388,5393,3173,1365,33,257,9325,12572,513]

theorem envBound14395 : H12AffineFastState.Bounded env14395 := by
  intro p hp
  have h : env14395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14394_14395 : H12AffineEnvironment.transform 17 10280 env14394 = env14395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14394 == env14395) = true)

theorem identity14395 : scanCanonicalize (H12AffineFastState.compose env14395 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound14395 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env14396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,8192,11624,1297,8202,11641,10280,1025,1296,3172,8572,8525,1299,8193,64,2049,10344,2357,3173,1365,33,257,9325,11576,513]

theorem envBound14396 : H12AffineFastState.Bounded env14396 := by
  intro p hp
  have h : env14396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14395_14396 : H12AffineEnvironment.transform 11 3108 env14395 = env14396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env14395 == env14396) = true)

theorem identity14396 : scanCanonicalize (H12AffineFastState.compose env14396 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14396 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14397 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,8192,10360,1,8202,10345,10280,273,0,2420,8572,8525,3,8193,64,2049,10344,2357,2421,69,33,257,8573,10280,513]

theorem envBound14397 : H12AffineFastState.Bounded env14397 := by
  intro p hp
  have h : env14397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14396_14397 : H12AffineEnvironment.transform 9 272 env14396 = env14397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14396 == env14397) = true)

theorem identity14397 : scanCanonicalize (H12AffineFastState.compose env14397 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14397 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14398 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2356,349,2341,1,343,2356,2421,273,0,2420,33,16,3,348,64,2049,2357,2357,2421,69,33,257,32,2421,513]

theorem envBound14398 : H12AffineFastState.Bounded env14398 := by
  intro p hp
  have h : env14398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14397_14398 : H12AffineEnvironment.transform 12 349 env14397 = env14398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14397 == env14398) = true)

theorem identity14398 : scanCanonicalize (H12AffineFastState.compose env14398 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14399 : List Nat := [2,4,8,16,17,64,9,256,512,272,2048,2309,349,2324,1,343,2309,2372,273,0,2373,16,16,3,348,64,2049,2308,2308,2372,69,16,257,17,2372,513]

theorem envBound14399 : H12AffineFastState.Bounded env14399 := by
  intro p hp
  have h : env14399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14398_14399 : H12AffineEnvironment.transform 4 17 env14398 = env14399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14398 == env14399) = true)

theorem identity14399 : scanCanonicalize (H12AffineFastState.compose env14399 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound14399 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14400 : List Nat := [2,4,8,16,17,64,9,256,512,272,513,772,349,789,1,343,772,837,273,0,836,16,16,3,348,64,512,773,773,837,69,16,257,17,837,513]

theorem envBound14400 : H12AffineFastState.Bounded env14400 := by
  intro p hp
  have h : env14400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14399_14400 : H12AffineEnvironment.transform 10 513 env14399 = env14400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env14399 == env14400) = true)

theorem identity14400 : scanCanonicalize (H12AffineFastState.compose env14400 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14400 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14401 : List Nat := [2,4,8,16,17,64,9,256,1,272,0,261,349,276,1,343,261,324,273,0,325,16,16,3,348,64,1,260,260,324,69,16,257,17,324,0]

theorem envBound14401 : H12AffineFastState.Bounded env14401 := by
  intro p hp
  have h : env14401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14400_14401 : H12AffineEnvironment.transform 8 1 env14400 = env14401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14400 == env14401) = true)

theorem identity14401 : scanCanonicalize (H12AffineFastState.compose env14401 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14401 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14402 : List Nat := [2,4,8,16,17,64,9,5,1,21,0,0,88,17,1,82,0,65,20,0,64,16,16,3,89,64,1,1,1,65,69,16,4,17,65,0]

theorem envBound14402 : H12AffineFastState.Bounded env14402 := by
  intro p hp
  have h : env14402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14401_14402 : H12AffineEnvironment.transform 7 5 env14401 = env14402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14401 == env14402) = true)

theorem identity14402 : scanCanonicalize (H12AffineFastState.compose env14402 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14402 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14403 : List Nat := [2,4,3,16,17,64,2,5,1,21,0,0,83,17,1,82,0,65,20,0,64,16,16,3,82,64,1,1,1,65,69,16,4,17,65,0]

theorem envBound14403 : H12AffineFastState.Bounded env14403 := by
  intro p hp
  have h : env14403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14402_14403 : H12AffineEnvironment.transform 2 3 env14402 = env14403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14402 == env14403) = true)

theorem identity14403 : scanCanonicalize (H12AffineFastState.compose env14403 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14403 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14404 : List Nat := [2,4,3,16,17,17,2,5,1,21,0,0,2,17,1,3,0,16,20,0,17,16,16,3,3,17,1,1,1,16,20,16,4,17,16,0]

theorem envBound14404 : H12AffineFastState.Bounded env14404 := by
  intro p hp
  have h : env14404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14403_14404 : H12AffineEnvironment.transform 5 17 env14403 = env14404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14403 == env14404) = true)

theorem identity14404 : scanCanonicalize (H12AffineFastState.compose env14404 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14404 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14405 : List Nat := [2,4,3,0,1,1,2,5,1,5,0,0,2,1,1,3,0,0,4,0,1,0,0,3,3,1,1,1,1,0,4,0,4,1,0,0]

theorem envBound14405 : H12AffineFastState.Bounded env14405 := by
  intro p hp
  have h : env14405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14404_14405 : H12AffineEnvironment.transform 3 0 env14404 = env14405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14404 == env14405) = true)

def env14406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,254096,8328,64,64724,160860,140364,303453,1501,272392,257,21793,46212,74250]

theorem envBound14406 : H12AffineFastState.Bounded env14406 := by
  intro p hp
  have h : env14406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14371_14406 : H12AffineEnvironment.transform 20 4161 env14371 = env14406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14371 == env14406) = true)

theorem identity14406 : scanCanonicalize (H12AffineFastState.compose env14406 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound14406 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,4161,329867,120014,21763,8328,64,64724,115151,102879,303453,1501,272392,257,21793,46212,74250]

theorem envBound14407 : H12AffineFastState.Bounded env14407 := by
  intro p hp
  have h : env14407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14406_14407 : H12AffineEnvironment.transform 16 112019 env14406 = env14407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env14406 == env14407) = true)

def env14408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10400,1025,32769,4161,73771,120014,21763,8328,64,64724,115151,102879,35325,1501,168,257,21793,46212,74250]

theorem envBound14408 : H12AffineFastState.Bounded env14408 := by
  intro p hp
  have h : env14408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14407_14408 : H12AffineEnvironment.transform 17 10400 env14407 = env14408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env14407 == env14408) = true)

theorem identity14408 : scanCanonicalize (H12AffineFastState.compose env14408 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound14408 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,25029,10400,1025,32769,4161,62589,152,21763,8328,64,64724,5529,17801,35325,1501,168,257,21793,46212,63068]

theorem envBound14409 : H12AffineFastState.Bounded env14409 := by
  intro p hp
  have h : env14409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14408_14409 : H12AffineEnvironment.transform 15 54358 env14408 = env14409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env14408 == env14409) = true)

theorem identity14409 : scanCanonicalize (H12AffineFastState.compose env14409 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound14409 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,478,25029,10400,1025,21897,4161,8693,152,21763,8328,64,10588,5529,17801,23669,1501,168,257,21793,24844,9172]

theorem envBound14410 : H12AffineFastState.Bounded env14410 := by
  intro p hp
  have h : env14410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14409_14410 : H12AffineEnvironment.transform 14 21896 env14409 = env14410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env14409 == env14410) = true)

theorem identity14410 : scanCanonicalize (H12AffineFastState.compose env14410 (packedSelected [1,2,3,4,6,7,8,10,11,12,14,15,18,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound14410 : packedSelected [1,2,3,4,6,7,8,10,11,12,14,15,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env14411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,373,478,13624,10400,1025,372,4161,8693,152,510,8328,64,10588,5529,4468,2184,1501,168,257,476,13809,9172]

theorem envBound14411 : H12AffineFastState.Bounded env14411 := by
  intro p hp
  have h : env14411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14410_14411 : H12AffineEnvironment.transform 13 5373 env14410 = env14411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env14410 == env14411) = true)

theorem identity14411 : scanCanonicalize (H12AffineFastState.compose env14411 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound14411 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env14412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,373,478,5357,2421,1025,372,4161,32,152,510,349,64,2185,5529,4468,2184,1501,168,257,476,5156,513]

theorem envBound14412 : H12AffineFastState.Bounded env14412 := by
  intro p hp
  have h : env14412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14411_14412 : H12AffineEnvironment.transform 12 469 env14411 = env14412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env14411 == env14412) = true)

theorem identity14412 : scanCanonicalize (H12AffineFastState.compose env14412 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14412 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env14413 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,469,4296,373,478,4312,2421,52,372,4161,32,152,510,349,64,2185,4524,4468,2184,488,168,257,476,4113,513]

theorem envBound14413 : H12AffineFastState.Bounded env14413 := by
  intro p hp
  have h : env14413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14412_14413 : H12AffineEnvironment.transform 9 53 env14412 = env14413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14412 == env14413) = true)

def env14414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10401,1025,32769,4161,73770,120014,21763,8328,64,64724,115151,102879,35324,1501,169,257,21793,46212,74250]

theorem envBound14414 : H12AffineFastState.Bounded env14414 := by
  intro p hp
  have h : env14414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14407_14414 : H12AffineEnvironment.transform 17 10401 env14407 = env14414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env14407 == env14414) = true)

theorem identity14414 : scanCanonicalize (H12AffineFastState.compose env14414 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14414 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,103495,2421,1025,32769,4161,66046,120014,21763,348,64,56576,115151,102879,35324,1501,169,257,21793,38224,66526]

theorem envBound14415 : H12AffineFastState.Bounded env14415 := by
  intro p hp
  have h : env14415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14414_14415 : H12AffineEnvironment.transform 12 468 env14414 = env14415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14414 == env14415) = true)

theorem identity14415 : scanCanonicalize (H12AffineFastState.compose env14415 (packedSelected [2,3,4,5,6,7,10,11,12,14,16,17,18,20,22,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14415 : packedSelected [2,3,4,5,6,7,10,11,12,14,16,17,18,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env14416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,103495,2421,1025,32769,4161,65911,119879,21763,348,64,56576,115014,102742,35189,1364,32,257,21793,38224,66391]

theorem envBound14416 : H12AffineFastState.Bounded env14416 := by
  intro p hp
  have h : env14416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14415_14416 : H12AffineEnvironment.transform 6 9 env14415 = env14416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14415 == env14416) = true)

theorem identity14416 : scanCanonicalize (H12AffineFastState.compose env14416 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound14416 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1297,65536,69974,2421,1025,1296,4161,65911,86358,21763,348,64,22545,83031,70727,3172,1364,32,257,21793,4161,66391]

theorem envBound14417 : H12AffineFastState.Bounded env14417 := by
  intro p hp
  have h : env14417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14416_14417 : H12AffineEnvironment.transform 14 1297 env14416 = env14417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env14416 == env14417) = true)

theorem identity14417 : scanCanonicalize (H12AffineFastState.compose env14417 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound14417 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1297,1094,5392,2421,1025,1296,4161,1329,21776,21763,348,64,22545,16401,4097,3172,1364,32,257,21793,4161,1809]

theorem envBound14418 : H12AffineFastState.Bounded env14418 := by
  intro p hp
  have h : env14418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14417_14418 : H12AffineEnvironment.transform 15 1094 env14417 = env14418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env14417 == env14418) = true)

theorem identity14418 : scanCanonicalize (H12AffineFastState.compose env14418 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14418 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env14419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1297,1094,5392,2421,1025,1296,4161,1329,16,3,348,64,3345,5393,4097,3172,1364,32,257,33,4161,1809]

theorem envBound14419 : H12AffineFastState.Bounded env14419 := by
  intro p hp
  have h : env14419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14418_14419 : H12AffineEnvironment.transform 13 5376 env14418 = env14419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14418 == env14419) = true)

theorem identity14419 : scanCanonicalize (H12AffineFastState.compose env14419 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound14419 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env14420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,349,2341,1297,1094,2357,2421,1025,1296,3172,1329,16,3,348,64,3345,2356,3108,3172,1364,32,257,33,3172,1809]

theorem envBound14420 : H12AffineFastState.Bounded env14420 := by
  intro p hp
  have h : env14420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14419_14420 : H12AffineEnvironment.transform 11 3109 env14419 = env14420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env14419 == env14420) = true)

theorem identity14420 : scanCanonicalize (H12AffineFastState.compose env14420 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14420 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env14421 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,40,2128,1124,1094,2112,2048,1025,1125,3172,1092,16,3,41,64,3172,2113,3108,3172,1057,32,116,33,3172,1636]

theorem envBound14421 : H12AffineFastState.Bounded env14421 := by
  intro p hp
  have h : env14421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14420_14421 : H12AffineEnvironment.transform 7 117 env14420 = env14421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14420 == env14421) = true)

theorem identity14421 : scanCanonicalize (H12AffineFastState.compose env14421 (packedSelected [0,1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14421 : packedSelected [0,1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env14422 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,2064,40,2128,81,115,2112,2048,52,80,2129,113,16,3,41,64,2129,2113,2065,2129,20,32,116,33,2129,593]

theorem envBound14422 : H12AffineFastState.Bounded env14422 := by
  intro p hp
  have h : env14422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14421_14422 : H12AffineEnvironment.transform 9 53 env14421 = env14422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14421 == env14422) = true)

def env14423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257180,254096,8328,64,2157716,2253853,140364,2404636,2102684,2373704,257,21793,46212,2175563]

theorem envBound14423 : H12AffineFastState.Bounded env14423 := by
  intro p hp
  have h : env14423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14370_14423 : H12AffineEnvironment.transform 21 441625 env14370 = env14423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env14370 == env14423) = true)

def env14424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,254096,8328,64,64724,160861,140364,303452,1500,272392,257,21793,46212,74251]

theorem envBound14424 : H12AffineFastState.Bounded env14424 := by
  intro p hp
  have h : env14424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14423_14424 : H12AffineEnvironment.transform 20 4160 env14423 = env14424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14423 == env14424) = true)

theorem identity14424 : scanCanonicalize (H12AffineFastState.compose env14424 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound14424 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,392286,73755,41431,8328,64,64724,79130,91403,303452,1500,272392,257,21793,46212,74251]

theorem envBound14425 : H12AffineFastState.Bounded env14425 := by
  intro p hp
  have h : env14425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14424_14425 : H12AffineEnvironment.transform 16 82247 env14424 = env14425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env14424 == env14425) = true)

def env14426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10400,1025,32769,4160,120062,73755,41431,8328,64,64724,79130,91403,35324,1500,168,257,21793,46212,74251]

theorem envBound14426 : H12AffineFastState.Bounded env14426 := by
  intro p hp
  have h : env14426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14425_14426 : H12AffineEnvironment.transform 17 10400 env14425 = env14426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env14425 == env14426) = true)

theorem identity14426 : scanCanonicalize (H12AffineFastState.compose env14426 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14426 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env14427 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,81970,10400,1025,32769,4160,120062,73755,41122,8328,64,64724,78959,91262,34953,1193,168,116,21588,46212,74251]

theorem envBound14427 : H12AffineFastState.Bounded env14427 := by
  intro p hp
  have h : env14427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14426_14427 : H12AffineEnvironment.transform 7 117 env14426 = env14427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14426 == env14427) = true)

theorem identity14427 : scanCanonicalize (H12AffineFastState.compose env14427 (packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound14427 : packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env14428 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,29942,13508,10400,1025,32769,4160,40968,21741,41122,8328,64,64724,16537,4232,34953,1193,168,116,21588,46212,22269]

theorem envBound14428 : H12AffineFastState.Bounded env14428 := by
  intro p hp
  have h : env14428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14427_14428 : H12AffineEnvironment.transform 15 29942 env14427 = env14428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env14427 == env14428) = true)

theorem identity14428 : scanCanonicalize (H12AffineFastState.compose env14428 (packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14428 : packedSelected [2,3,4,5,6,10,11,12,15,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14429 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,16384,32768,21726,5356,2184,1025,32769,4160,32800,21741,32906,160,64,56572,16537,4232,34953,1193,168,116,21588,38060,22269]

theorem envBound14429 : H12AffineFastState.Bounded env14429 := by
  intro p hp
  have h : env14429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14428_14429 : H12AffineEnvironment.transform 12 40 env14428 = env14429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14428 == env14429) = true)

theorem identity14429 : scanCanonicalize (H12AffineFastState.compose env14429 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound14429 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14430 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,16384,137,21726,5356,2184,1025,136,4160,169,21741,3,160,64,23669,16537,4232,2048,1193,168,116,21588,5157,22269]

theorem envBound14430 : H12AffineFastState.Bounded env14430 := by
  intro p hp
  have h : env14430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14429_14430 : H12AffineEnvironment.transform 14 137 env14429 = env14430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env14429 == env14430) = true)

theorem identity14430 : scanCanonicalize (H12AffineFastState.compose env14430 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14430 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14431 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,0,21591,5221,2049,1025,1,4160,32,21604,3,41,64,23669,16400,4097,2048,1056,33,116,21588,5157,22132]

theorem envBound14431 : H12AffineFastState.Bounded env14431 := by
  intro p hp
  have h : env14431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14430_14431 : H12AffineEnvironment.transform 6 9 env14430 = env14431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14430 == env14431) = true)

theorem identity14431 : scanCanonicalize (H12AffineFastState.compose env14431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound14431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14432 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,0,35,5221,2049,1025,1,4160,32,16,3,41,64,2049,5220,4097,2048,1056,33,116,32,5157,512]

theorem envBound14432 : H12AffineFastState.Bounded env14432 := by
  intro p hp
  have h : env14432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14431_14432 : H12AffineEnvironment.transform 13 5236 env14431 = env14432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env14431 == env14432) = true)

theorem identity14432 : scanCanonicalize (H12AffineFastState.compose env14432 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14432 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14433 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5205,0,2,5188,2049,1025,1,4160,1,16,3,8,64,2049,5189,4097,2048,1025,0,85,1,5124,512]

theorem envBound14433 : H12AffineFastState.Bounded env14433 := by
  intro p hp
  have h : env14433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14432_14433 : H12AffineEnvironment.transform 4 1 env14432 = env14433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14432 == env14433) = true)

theorem identity14433 : scanCanonicalize (H12AffineFastState.compose env14433 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14433 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14434 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,0,2,5141,2049,1025,1,4113,1,16,3,8,17,2049,5140,4097,2048,1025,0,4,1,5124,512]

theorem envBound14434 : H12AffineFastState.Bounded env14434 := by
  intro p hp
  have h : env14434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14433_14434 : H12AffineEnvironment.transform 5 17 env14433 = env14434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14433 == env14434) = true)

def env14435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10401,1025,32769,4160,120063,73755,41431,8328,64,64724,79130,91403,35325,1500,169,257,21793,46212,74251]

theorem envBound14435 : H12AffineFastState.Bounded env14435 := by
  intro p hp
  have h : env14435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14425_14435 : H12AffineEnvironment.transform 17 10401 env14425 = env14435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env14425 == env14435) = true)

theorem identity14435 : scanCanonicalize (H12AffineFastState.compose env14435 (packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14435 : packedSelected [0,2,3,6,8,10,12,14,23,24,26,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env14436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82247,10401,1025,29908,4160,73770,73755,21762,8328,64,2049,79130,91403,32040,1500,169,257,21793,16465,74251]

theorem envBound14436 : H12AffineFastState.Bounded env14436 := by
  intro p hp
  have h : env14436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14435_14436 : H12AffineEnvironment.transform 14 29909 env14435 = env14436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14435 == env14436) = true)

theorem identity14436 : scanCanonicalize (H12AffineFastState.compose env14436 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound14436 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16400,10401,1025,29908,4160,8573,8524,21762,8328,64,2049,13389,25692,32040,1500,169,257,21793,16465,9052]

theorem envBound14437 : H12AffineFastState.Bounded env14437 := by
  intro p hp
  have h : env14437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14436_14437 : H12AffineEnvironment.transform 15 343 env14436 = env14437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env14436 == env14437) = true)

theorem identity14437 : scanCanonicalize (H12AffineFastState.compose env14437 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14437 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env14438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,343,16400,2557,1025,21896,4160,33,16,21762,468,64,2049,5393,17664,23668,1500,169,257,21793,16465,512]

theorem envBound14438 : H12AffineFastState.Bounded env14438 := by
  intro p hp
  have h : env14438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14437_14438 : H12AffineEnvironment.transform 12 348 env14437 = env14438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14437 == env14438) = true)

theorem identity14438 : scanCanonicalize (H12AffineFastState.compose env14438 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound14438 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14439 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,4096,348,16384,20804,343,16400,2557,204,20805,4160,33,16,20943,468,64,2049,4572,16845,22713,273,169,257,20972,16465,512]

theorem envBound14439 : H12AffineFastState.Bounded env14439 := by
  intro p hp
  have h : env14439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14438_14439 : H12AffineEnvironment.transform 9 205 env14438 = env14439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env14438 == env14439) = true)

theorem identity14439 : scanCanonicalize (H12AffineFastState.compose env14439 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound14439 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env14440 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,2325,348,16384,18513,343,16400,2557,204,18512,2389,33,16,18650,468,64,2049,2249,16845,16812,273,169,257,18681,16465,512]

theorem envBound14440 : H12AffineFastState.Bounded env14440 := by
  intro p hp
  have h : env14440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14439_14440 : H12AffineEnvironment.transform 11 2325 env14439 = env14440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env14439 == env14440) = true)

theorem identity14440 : scanCanonicalize (H12AffineFastState.compose env14440 (packedSelected [1,2,6,7,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 65) := by decide +kernel

theorem selectedBound14440 : packedSelected [1,2,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env14441 : List Nat := [2,4,8,16,32,64,128,256,512,205,2048,2325,348,65,2064,343,81,2557,204,2065,2389,33,16,2203,468,64,2049,2249,396,493,273,169,257,2232,16,512]

theorem envBound14441 : H12AffineFastState.Bounded env14441 := by
  intro p hp
  have h : env14441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14440_14441 : H12AffineEnvironment.transform 13 65 env14440 = env14441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 65 env14440 == env14441) = true)

theorem identity14441 : scanCanonicalize (H12AffineFastState.compose env14441 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14441 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env14442 : List Nat := [2,4,8,16,32,64,128,116,512,205,2048,2145,40,65,2064,35,81,2185,204,2065,2081,33,16,2203,160,64,2049,2249,248,153,101,169,117,2232,16,512]

theorem envBound14442 : H12AffineFastState.Bounded env14442 := by
  intro p hp
  have h : env14442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14441_14442 : H12AffineEnvironment.transform 7 116 env14441 = env14442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14441 == env14442) = true)

theorem identity14442 : scanCanonicalize (H12AffineFastState.compose env14442 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound14442 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14443 : List Nat := [2,4,8,16,32,64,128,116,512,205,65,32,40,65,81,35,81,200,204,80,96,33,16,218,160,64,64,136,248,153,101,169,117,249,16,512]

theorem envBound14443 : H12AffineFastState.Bounded env14443 := by
  intro p hp
  have h : env14443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14442_14443 : H12AffineEnvironment.transform 10 65 env14442 = env14443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env14442 == env14443) = true)

theorem identity14443 : scanCanonicalize (H12AffineFastState.compose env14443 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14443 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14444 : List Nat := [2,4,8,16,32,64,8,116,512,69,65,32,40,65,81,35,81,64,68,80,96,33,16,82,40,64,64,0,112,17,101,33,117,113,16,512]

theorem envBound14444 : H12AffineFastState.Bounded env14444 := by
  intro p hp
  have h : env14444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14443_14444 : H12AffineEnvironment.transform 6 8 env14443 = env14444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14443 == env14444) = true)

theorem identity14444 : scanCanonicalize (H12AffineFastState.compose env14444 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14444 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14445 : List Nat := [2,4,8,16,0,64,8,84,512,69,65,0,8,65,81,3,81,64,68,80,64,1,16,82,8,64,64,0,80,17,69,1,85,81,16,512]

theorem envBound14445 : H12AffineFastState.Bounded env14445 := by
  intro p hp
  have h : env14445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14444_14445 : H12AffineEnvironment.transform 4 0 env14444 = env14445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14444 == env14445) = true)

theorem identity14445 : scanCanonicalize (H12AffineFastState.compose env14445 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound14445 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14446 : List Nat := [2,4,8,16,0,31,8,11,512,26,30,0,8,30,14,3,14,31,27,15,31,1,16,13,8,31,31,0,15,17,26,1,10,14,16,512]

theorem envBound14446 : H12AffineFastState.Bounded env14446 := by
  intro p hp
  have h : env14446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14445_14446 : H12AffineEnvironment.transform 5 31 env14445 = env14446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env14445 == env14446) = true)

theorem identity14446 : scanCanonicalize (H12AffineFastState.compose env14446 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14446 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14447 : List Nat := [2,4,8,11,0,4,8,11,512,1,5,0,8,5,14,3,14,4,0,15,4,1,11,13,8,4,4,0,15,10,1,1,10,14,11,512]

theorem envBound14447 : H12AffineFastState.Bounded env14447 := by
  intro p hp
  have h : env14447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14446_14447 : H12AffineEnvironment.transform 3 11 env14446 = env14447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14446 == env14447) = true)

def env14448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,254096,8328,64,64725,160860,140364,303453,1501,272393,257,21793,46212,74250]

theorem envBound14448 : H12AffineFastState.Bounded env14448 := by
  intro p hp
  have h : env14448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14423_14448 : H12AffineEnvironment.transform 20 4161 env14423 = env14448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14423 == env14448) = true)

theorem identity14448 : scanCanonicalize (H12AffineFastState.compose env14448 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound14448 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,441625,155997,144463,8328,64,64725,160860,140364,303453,1501,272393,257,21793,46212,63189]

theorem envBound14449 : H12AffineFastState.Bounded env14449 := by
  intro p hp
  have h : env14449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14448_14449 : H12AffineEnvironment.transform 15 54495 env14448 = env14449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env14448 == env14449) = true)

def env14450 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441625,155917,144415,8328,16,64645,160780,140316,303373,1421,272393,257,21793,46212,63109]

theorem envBound14450 : H12AffineFastState.Bounded env14450 := by
  intro p hp
  have h : env14450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14449_14450 : H12AffineEnvironment.transform 5 16 env14449 = env14450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14449 == env14450) = true)

theorem identity14450 : scanCanonicalize (H12AffineFastState.compose env14450 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound14450 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env14451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,171060,1025,32769,4113,8493,155917,144415,8328,16,64645,160780,140316,146745,1421,177213,257,21793,46212,63109]

theorem envBound14451 : H12AffineFastState.Bounded env14451 := by
  intro p hp
  have h : env14451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14450_14451 : H12AffineEnvironment.transform 17 171060 env14450 = env14451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env14450 == env14451) = true)

theorem identity14451 : scanCanonicalize (H12AffineFastState.compose env14451 (packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound14451 : packedSelected [1,3,4,5,7,8,9,16,18,19,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env14452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,49169,23589,1025,32769,4113,8493,41244,62478,8328,16,64645,46109,58381,64808,1421,29740,257,21793,46212,63109]

theorem envBound14452 : H12AffineFastState.Bounded env14452 := by
  intro p hp
  have h : env14452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14451_14452 : H12AffineEnvironment.transform 16 49169 env14451 = env14452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14451 == env14452) = true)

theorem identity14452 : scanCanonicalize (H12AffineFastState.compose env14452 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound14452 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env14453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,30083,24861,23589,1025,8461,4113,8493,16,21762,8328,16,23945,5393,17665,23588,1421,29740,257,21793,5512,22409]

theorem envBound14453 : H12AffineFastState.Bounded env14453 := by
  intro p hp
  have h : env14453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14452_14453 : H12AffineEnvironment.transform 14 8460 env14452 = env14453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env14452 == env14453) = true)

theorem identity14453 : scanCanonicalize (H12AffineFastState.compose env14453 (packedSelected [0,1,4,6,7,8,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound14453 : packedSelected [0,1,4,6,7,8,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14454 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,16384,1213,20530,17580,23589,1025,1212,4113,1180,16,21762,1337,16,23945,5393,17665,23588,1421,20893,257,21793,5512,22409]

theorem envBound14454 : H12AffineFastState.Bounded env14454 := by
  intro p hp
  have h : env14454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14453_14454 : H12AffineEnvironment.transform 12 1457 env14453 = env14454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env14453 == env14454) = true)

theorem identity14454 : scanCanonicalize (H12AffineFastState.compose env14454 (packedSelected [0,1,2,4,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14454 : packedSelected [0,1,2,4,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env14455 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,5376,1213,1330,4524,2341,1025,1212,4113,1180,16,2,1337,16,2185,5393,4097,2340,1421,1181,257,33,5512,649]

theorem envBound14455 : H12AffineFastState.Bounded env14455 := by
  intro p hp
  have h : env14455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14454_14455 : H12AffineEnvironment.transform 13 5376 env14454 = env14455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14454 == env14455) = true)

theorem identity14455 : scanCanonicalize (H12AffineFastState.compose env14455 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14455 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14456 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1336,5376,1076,1330,4389,2341,1025,1077,4113,1045,16,2,1337,16,2048,5393,4097,2340,1284,1044,257,33,5377,512]

theorem envBound14456 : H12AffineFastState.Bounded env14456 := by
  intro p hp
  have h : env14456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14455_14456 : H12AffineEnvironment.transform 6 9 env14455 = env14456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14455 == env14456) = true)

theorem identity14456 : scanCanonicalize (H12AffineFastState.compose env14456 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14456 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14457 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,4096,1304,5376,1044,1298,4357,2309,1025,1045,4113,1045,16,2,1305,16,2048,5393,4097,2308,1284,1044,257,1,5377,512]

theorem envBound14457 : H12AffineFastState.Bounded env14457 := by
  intro p hp
  have h : env14457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14456_14457 : H12AffineEnvironment.transform 4 0 env14456 = env14457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14456 == env14457) = true)

theorem identity14457 : scanCanonicalize (H12AffineFastState.compose env14457 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound14457 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14458 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,3329,1304,2049,1044,1298,3076,2309,1025,1045,3344,1045,16,2,1305,16,2048,2064,3328,2308,1284,1044,257,1,2048,512]

theorem envBound14458 : H12AffineFastState.Bounded env14458 := by
  intro p hp
  have h : env14458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14457_14458 : H12AffineEnvironment.transform 11 3329 env14457 = env14458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env14457 == env14458) = true)

theorem identity14458 : scanCanonicalize (H12AffineFastState.compose env14458 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14458 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14459 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3077,1052,2049,1044,1046,3076,2049,1025,1045,3092,1045,16,2,1053,16,2048,2064,3076,2048,1024,1044,5,1,2048,512]

theorem envBound14459 : H12AffineFastState.Bounded env14459 := by
  intro p hp
  have h : env14459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14458_14459 : H12AffineEnvironment.transform 7 4 env14458 = env14459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14458 == env14459) = true)

def env14460 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441625,155916,144414,8328,17,64644,160781,140317,303372,1420,272393,257,21793,46212,63108]

theorem envBound14460 : H12AffineFastState.Bounded env14460 := by
  intro p hp
  have h : env14460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14449_14460 : H12AffineEnvironment.transform 5 17 env14449 = env14460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14449 == env14460) = true)

theorem identity14460 : scanCanonicalize (H12AffineFastState.compose env14460 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 157873) := by decide +kernel

theorem selectedBound14460 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env14461 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,157873,1025,32769,4112,54696,155916,144414,8328,17,64644,160781,140317,182717,1420,147640,257,21793,46212,63108]

theorem envBound14461 : H12AffineFastState.Bounded env14461 := by
  intro p hp
  have h : env14461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14460_14461 : H12AffineEnvironment.transform 17 157873 env14460 = env14461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env14460 == env14461) = true)

theorem identity14461 : scanCanonicalize (H12AffineFastState.compose env14461 (packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound14461 : packedSelected [0,3,5,8,9,16,17,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env14462 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,5528,32041,1025,32769,4112,54696,29844,8582,8328,17,64644,24981,12677,56357,1420,21792,257,21793,46212,63108]

theorem envBound14462 : H12AffineFastState.Bounded env14462 := by
  intro p hp
  have h : env14462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14461_14462 : H12AffineEnvironment.transform 16 5528 env14461 = env14462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env14461 == env14462) = true)

theorem identity14462 : scanCanonicalize (H12AffineFastState.compose env14462 (packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound14462 : packedSelected [3,5,9,10,11,14,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14463 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,5528,32041,1025,29828,4112,8493,29844,8582,8328,17,2049,24981,12677,10400,1420,21792,257,21793,16385,513]

theorem envBound14463 : H12AffineFastState.Bounded env14463 := by
  intro p hp
  have h : env14463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14462_14463 : H12AffineEnvironment.transform 14 29829 env14462 = env14463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env14462 == env14463) = true)

theorem identity14463 : scanCanonicalize (H12AffineFastState.compose env14463 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14463 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env14464 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8203,5392,32041,1025,29708,4112,8493,29724,8462,8192,17,2049,24861,12557,10280,1284,21792,257,21793,16385,513]

theorem envBound14464 : H12AffineFastState.Bounded env14464 := by
  intro p hp
  have h : env14464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14463_14464 : H12AffineEnvironment.transform 6 8 env14463 = env14464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14463 == env14464) = true)

theorem identity14464 : scanCanonicalize (H12AffineFastState.compose env14464 (packedSelected [11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14464 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env14465 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,1,8203,5392,2341,1025,0,4112,8493,16,8462,8192,17,2049,5393,12557,10280,1284,8492,257,8493,13325,513]

theorem envBound14465 : H12AffineFastState.Bounded env14465 := by
  intro p hp
  have h : env14465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14464_14465 : H12AffineEnvironment.transform 13 13324 env14464 = env14465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14464 == env14465) = true)

theorem identity14465 : scanCanonicalize (H12AffineFastState.compose env14465 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14465 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env14466 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,13324,1,8203,5173,2048,1025,0,4112,8200,16,8235,8192,17,2049,5172,12328,10280,1057,8201,36,8200,13325,513]

theorem envBound14466 : H12AffineFastState.Bounded env14466 := by
  intro p hp
  have h : env14466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14465_14466 : H12AffineEnvironment.transform 7 37 env14465 = env14466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14465 == env14466) = true)

theorem identity14466 : scanCanonicalize (H12AffineFastState.compose env14466 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14466 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14467 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,12345,1,8203,4096,2048,52,0,4112,8200,16,8235,8192,17,2049,4097,12328,10280,20,8201,36,8200,12344,513]

theorem envBound14467 : H12AffineFastState.Bounded env14467 := by
  intro p hp
  have h : env14467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14466_14467 : H12AffineEnvironment.transform 9 53 env14466 = env14467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14466 == env14467) = true)

theorem identity14467 : scanCanonicalize (H12AffineFastState.compose env14467 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14467 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env14468 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4113,1,35,4096,2048,52,0,4112,32,16,3,40,17,2049,4097,4096,2048,20,33,36,32,4112,513]

theorem envBound14468 : H12AffineFastState.Bounded env14468 := by
  intro p hp
  have h : env14468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14467_14468 : H12AffineEnvironment.transform 12 40 env14467 = env14468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14467 == env14468) = true)

theorem identity14468 : scanCanonicalize (H12AffineFastState.compose env14468 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2581) := by decide +kernel

theorem selectedBound14468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14469 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2581,40,2564,1,35,2581,2048,52,0,2565,32,16,3,40,17,2049,2580,2581,2048,20,33,36,32,2565,513]

theorem envBound14469 : H12AffineFastState.Bounded env14469 := by
  intro p hp
  have h : env14469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14468_14469 : H12AffineEnvironment.transform 11 2581 env14468 = env14469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2581 env14468 == env14469) = true)

theorem identity14469 : scanCanonicalize (H12AffineFastState.compose env14469 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 547) := by decide +kernel

theorem selectedBound14469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14470 : List Nat := [2,4,8,16,32,17,8,37,512,53,547,54,40,39,1,35,54,547,52,0,38,32,16,3,40,17,546,55,54,547,20,33,36,32,38,513]

theorem envBound14470 : H12AffineFastState.Bounded env14470 := by
  intro p hp
  have h : env14470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14469_14470 : H12AffineEnvironment.transform 10 547 env14469 = env14470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 547 env14469 == env14470) = true)

theorem identity14470 : scanCanonicalize (H12AffineFastState.compose env14470 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound14470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14471 : List Nat := [2,4,8,16,23,17,8,18,512,2,532,1,31,16,1,20,1,532,3,0,17,23,16,3,31,17,533,0,1,532,20,22,19,23,17,513]

theorem envBound14471 : H12AffineFastState.Bounded env14471 := by
  intro p hp
  have h : env14471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14470_14471 : H12AffineEnvironment.transform 4 23 env14470 = env14471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env14470 == env14471) = true)

theorem identity14471 : scanCanonicalize (H12AffineFastState.compose env14471 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound14471 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14472 : List Nat := [2,4,8,16,23,17,8,18,14,2,26,1,31,16,1,20,1,26,3,0,17,23,16,3,31,17,27,0,1,26,20,22,19,23,17,15]

theorem envBound14472 : H12AffineFastState.Bounded env14472 := by
  intro p hp
  have h : env14472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14471_14472 : H12AffineEnvironment.transform 8 14 env14471 = env14472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env14471 == env14472) = true)

theorem identity14472 : scanCanonicalize (H12AffineFastState.compose env14472 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound14472 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14473 : List Nat := [2,4,8,7,0,6,8,5,14,2,13,1,8,7,1,3,1,13,3,0,6,0,7,3,8,6,12,0,1,13,3,1,4,0,6,15]

theorem envBound14473 : H12AffineFastState.Bounded env14473 := by
  intro p hp
  have h : env14473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14472_14473 : H12AffineEnvironment.transform 3 7 env14472 = env14473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env14472 == env14473) = true)

theorem identity14473 : scanCanonicalize (H12AffineFastState.compose env14473 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound14473 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14474 : List Nat := [2,3,8,0,0,1,8,2,9,2,10,1,8,0,1,3,1,10,3,0,1,0,0,3,8,1,11,0,1,10,3,1,3,0,1,8]

theorem envBound14474 : H12AffineFastState.Bounded env14474 := by
  intro p hp
  have h : env14474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14473_14474 : H12AffineEnvironment.transform 1 3 env14473 = env14474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env14473 == env14474) = true)

theorem identity14474 : scanCanonicalize (H12AffineFastState.compose env14474 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14474 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14475 : List Nat := [2,3,3,0,0,1,3,2,2,2,1,1,3,0,1,3,1,1,3,0,1,0,0,3,3,1,0,0,1,1,3,1,3,0,1,3]

theorem envBound14475 : H12AffineFastState.Bounded env14475 := by
  intro p hp
  have h : env14475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14474_14475 : H12AffineEnvironment.transform 2 3 env14474 = env14475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14474 == env14475) = true)

def env14476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257181,254096,8328,64,6705548,2253853,140365,2404637,2102685,6456657,257,21792,46213,2175562]

theorem envBound14476 : H12AffineFastState.Bounded env14476 := by
  intro p hp
  have h : env14476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14369_14476 : H12AffineEnvironment.transform 22 2257181 env14369 = env14476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257181 env14369 == env14476) = true)

def env14477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257181,254096,8328,64,2157716,2253853,140365,2404637,2102685,2373705,257,21792,46213,2175562]

theorem envBound14477 : H12AffineFastState.Bounded env14477 := by
  intro p hp
  have h : env14477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14476_14477 : H12AffineEnvironment.transform 21 441624 env14476 = env14477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env14476 == env14477) = true)

def env14478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,254096,8328,64,64724,160861,140365,303453,1501,272393,257,21792,46213,74250]

theorem envBound14478 : H12AffineFastState.Bounded env14478 := by
  intro p hp
  have h : env14478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14477_14478 : H12AffineEnvironment.transform 20 4160 env14477 = env14478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14477 == env14478) = true)

theorem identity14478 : scanCanonicalize (H12AffineFastState.compose env14478 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14478 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,412109,155997,201797,8328,64,2049,160861,140365,284040,1501,272393,257,21792,16464,74250]

theorem envBound14479 : H12AffineFastState.Bounded env14479 := by
  intro p hp
  have h : env14479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14478_14479 : H12AffineEnvironment.transform 14 29909 env14478 = env14479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14478 == env14479) = true)

def env14480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,411973,155997,201797,8192,64,2049,160861,140365,283904,1365,272393,257,21792,16464,74250]

theorem envBound14480 : H12AffineFastState.Bounded env14480 := by
  intro p hp
  have h : env14480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14479_14480 : H12AffineEnvironment.transform 6 8 env14479 = env14480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14479 == env14480) = true)

theorem identity14480 : scanCanonicalize (H12AffineFastState.compose env14480 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 157800) := by decide +kernel

theorem selectedBound14480 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,157800,1025,29788,4160,8493,155997,201797,8192,64,2049,160861,140365,146792,1365,147553,257,21792,16464,74250]

theorem envBound14481 : H12AffineFastState.Bounded env14481 := by
  intro p hp
  have h : env14481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14480_14481 : H12AffineEnvironment.transform 17 157800 env14480 = env14481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157800 env14480 == env14481) = true)

theorem identity14481 : scanCanonicalize (H12AffineFastState.compose env14481 (packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound14481 : packedSelected [0,3,4,7,14,18,19,22,23,24,31,35] rootPS < 2^1333 := by decide +kernel

def env14482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,79130,89458,1025,29788,4160,8493,87111,8543,8192,64,2049,82247,69975,67698,1365,95611,257,21792,16464,74250]

theorem envBound14482 : H12AffineFastState.Bounded env14482 := by
  intro p hp
  have h : env14482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14481_14482 : H12AffineEnvironment.transform 16 79130 env14481 = env14482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env14481 == env14482) = true)

theorem identity14482 : scanCanonicalize (H12AffineFastState.compose env14482 (packedSelected [0,7,8,9,10,12,14,15,16,17,19,22,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14482 : packedSelected [0,7,8,9,10,12,14,15,16,17,19,22,26,28] rootPS < 2^1333 := by decide +kernel

def env14483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,70727,89458,1025,21761,4160,112,87111,2,349,64,2049,82247,69975,67698,1365,87078,257,21792,16464,66391]

theorem envBound14483 : H12AffineFastState.Bounded env14483 := by
  intro p hp
  have h : env14483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14482_14483 : H12AffineEnvironment.transform 12 349 env14482 = env14483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14482 == env14483) = true)

theorem identity14483 : scanCanonicalize (H12AffineFastState.compose env14483 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound14483 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env14484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,5393,23588,1025,21761,4160,112,21777,2,349,64,2049,16401,4097,2340,1365,21872,257,21792,16464,513]

theorem envBound14484 : H12AffineFastState.Bounded env14484 := by
  intro p hp
  have h : env14484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14483_14484 : H12AffineEnvironment.transform 15 342 env14483 = env14484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env14483 == env14484) = true)

theorem identity14484 : scanCanonicalize (H12AffineFastState.compose env14484 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound14484 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env14485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,293,342,5393,2049,1025,292,4160,112,308,2,349,64,2049,5172,4097,2340,1365,341,257,261,5237,513]

theorem envBound14485 : H12AffineFastState.Bounded env14485 := by
  intro p hp
  have h : env14485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14484_14485 : H12AffineEnvironment.transform 13 5157 env14484 = env14485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env14484 == env14485) = true)

theorem identity14485 : scanCanonicalize (H12AffineFastState.compose env14485 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14485 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14486 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,293,262,5393,2049,1025,292,4112,32,308,2,269,16,2049,5172,4097,2340,1285,261,257,261,5157,513]

theorem envBound14486 : H12AffineFastState.Bounded env14486 := by
  intro p hp
  have h : env14486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14485_14486 : H12AffineEnvironment.transform 5 16 env14485 = env14486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14485 == env14486) = true)

theorem identity14486 : scanCanonicalize (H12AffineFastState.compose env14486 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound14486 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14487 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,5157,293,262,5393,1076,1025,292,4112,32,308,2,269,16,1076,5172,4097,1297,1285,261,257,261,5157,513]

theorem envBound14487 : H12AffineFastState.Bounded env14487 := by
  intro p hp
  have h : env14487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14486_14487 : H12AffineEnvironment.transform 10 1077 env14486 = env14487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env14486 == env14487) = true)

theorem identity14487 : scanCanonicalize (H12AffineFastState.compose env14487 (packedSelected [0,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound14487 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env14488 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,309,269,1296,293,262,1060,1076,1025,292,293,32,308,2,269,16,1076,1281,308,1297,1285,261,257,261,1296,513]

theorem envBound14488 : H12AffineFastState.Bounded env14488 := by
  intro p hp
  have h : env14488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14487_14488 : H12AffineEnvironment.transform 11 309 env14487 = env14488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env14487 == env14488) = true)

theorem identity14488 : scanCanonicalize (H12AffineFastState.compose env14488 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14488 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14489 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,17,41,1076,1,34,1060,1076,1025,0,1,32,16,2,41,16,1076,1061,16,1077,1057,33,37,33,1076,513]

theorem envBound14489 : H12AffineFastState.Bounded env14489 := by
  intro p hp
  have h : env14489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14488_14489 : H12AffineEnvironment.transform 7 36 env14488 = env14489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14488 == env14489) = true)

theorem identity14489 : scanCanonicalize (H12AffineFastState.compose env14489 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14490 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,0,1,34,16,0,53,0,1,32,16,2,41,16,0,17,16,1,21,33,37,33,0,513]

theorem envBound14490 : H12AffineFastState.Bounded env14490 := by
  intro p hp
  have h : env14490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14489_14490 : H12AffineEnvironment.transform 9 52 env14489 = env14490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14489 == env14490) = true)

theorem identity14490 : scanCanonicalize (H12AffineFastState.compose env14490 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14491 : List Nat := [2,4,8,16,17,16,8,21,512,5,1,17,24,0,1,19,16,0,4,0,1,17,16,2,24,16,0,17,16,1,21,16,20,16,0,513]

theorem envBound14491 : H12AffineFastState.Bounded env14491 := by
  intro p hp
  have h : env14491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14490_14491 : H12AffineEnvironment.transform 4 17 env14490 = env14491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14490 == env14491) = true)

theorem identity14491 : scanCanonicalize (H12AffineFastState.compose env14491 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14492 : List Nat := [2,4,8,0,1,0,8,5,512,5,1,1,8,0,1,3,0,0,4,0,1,1,0,2,8,0,0,1,0,1,5,0,4,0,0,513]

theorem envBound14492 : H12AffineFastState.Bounded env14492 := by
  intro p hp
  have h : env14492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14491_14492 : H12AffineEnvironment.transform 3 0 env14491 = env14492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14491 == env14492) = true)

def env14493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,411972,155997,201797,8193,64,2049,160861,140365,283905,1364,272393,257,21792,16464,74250]

theorem envBound14493 : H12AffineFastState.Bounded env14493 := by
  intro p hp
  have h : env14493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14479_14493 : H12AffineEnvironment.transform 6 9 env14479 = env14493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14479 == env14493) = true)

theorem identity14493 : scanCanonicalize (H12AffineFastState.compose env14493 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound14493 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env14494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,215091,1025,29789,4160,65911,155997,201797,8193,64,2049,160861,140365,204082,1364,221242,257,21792,16464,74250]

theorem envBound14494 : H12AffineFastState.Bounded env14494 := by
  intro p hp
  have h : env14494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14493_14494 : H12AffineEnvironment.transform 17 215091 env14493 = env14494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env14493 == env14494) = true)

theorem identity14494 : scanCanonicalize (H12AffineFastState.compose env14494 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14494 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,4160,65911,65862,29790,8193,64,2049,70726,83030,32041,1364,33,257,21792,16464,74250]

theorem envBound14495 : H12AffineFastState.Bounded env14495 := by
  intro p hp
  have h : env14495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14494_14495 : H12AffineEnvironment.transform 16 90139 env14494 = env14495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14494 == env14495) = true)

theorem identity14495 : scanCanonicalize (H12AffineFastState.compose env14495 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14495 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14496 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5392,10280,1025,29789,4160,29820,29773,29790,8193,64,2049,24909,12637,32041,1364,33,257,21792,16464,22273]

theorem envBound14496 : H12AffineFastState.Bounded env14496 := by
  intro p hp
  have h : env14496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14495_14496 : H12AffineEnvironment.transform 15 29963 env14495 = env14496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14495 == env14496) = true)

theorem identity14496 : scanCanonicalize (H12AffineFastState.compose env14496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound14496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20496,20807,5392,3172,1025,20497,4160,20528,20481,20498,1101,64,2049,17665,5393,22885,1364,33,257,21792,16464,22273]

theorem envBound14497 : H12AffineFastState.Bounded env14497 := by
  intro p hp
  have h : env14497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14496_14497 : H12AffineEnvironment.transform 12 1100 env14496 = env14497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env14496 == env14497) = true)

theorem identity14497 : scanCanonicalize (H12AffineFastState.compose env14497 (packedSelected [0,1,3,4,5,7,8,9,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14497 : packedSelected [0,1,3,4,5,7,8,9,14,15,18] rootPS < 2^1333 := by decide +kernel

def env14498 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,16384,20496,20758,5392,3125,1025,20497,4113,20528,20481,20498,1052,17,2049,17665,5393,22836,1285,33,257,21792,16385,22273]

theorem envBound14498 : H12AffineFastState.Bounded env14498 := by
  intro p hp
  have h : env14498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14497_14498 : H12AffineEnvironment.transform 5 17 env14497 = env14498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14497 == env14498) = true)

theorem identity14498 : scanCanonicalize (H12AffineFastState.compose env14498 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14498 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env14499 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1053,5377,1297,1047,5392,3125,1025,1296,4113,1329,1280,1299,1052,17,2049,4096,5393,3125,1285,33,257,33,5376,512]

theorem envBound14499 : H12AffineFastState.Bounded env14499 := by
  intro p hp
  have h : env14499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14498_14499 : H12AffineEnvironment.transform 13 5377 env14498 = env14499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14498 == env14499) = true)

theorem identity14499 : scanCanonicalize (H12AffineFastState.compose env14499 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 59) := by decide +kernel

theorem selectedBound14499 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14500 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,59,1053,1338,1297,1047,1323,3125,1025,1296,42,1329,1280,1299,1052,17,2049,59,1322,3125,1285,33,257,33,1339,512]

theorem envBound14500 : H12AffineFastState.Bounded env14500 := by
  intro p hp
  have h : env14500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14499_14500 : H12AffineEnvironment.transform 11 59 env14499 = env14500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 59 env14499 == env14500) = true)

theorem identity14500 : scanCanonicalize (H12AffineFastState.compose env14500 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14500 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14501 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,27,1053,1306,1297,1047,1291,3093,1025,1296,10,1297,1280,1299,1052,17,2049,27,1290,3093,1285,1,257,1,1307,512]

theorem envBound14501 : H12AffineFastState.Bounded env14501 := by
  intro p hp
  have h : env14501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14500_14501 : H12AffineEnvironment.transform 4 0 env14500 = env14501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14500 == env14501) = true)

theorem identity14501 : scanCanonicalize (H12AffineFastState.compose env14501 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound14501 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14502 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1028,27,1053,1306,1297,1047,1291,17,1025,1296,10,1297,1280,1299,1052,17,1029,27,1290,17,1285,1,257,1,1307,512]

theorem envBound14502 : H12AffineFastState.Bounded env14502 := by
  intro p hp
  have h : env14502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14501_14502 : H12AffineEnvironment.transform 10 1028 env14501 = env14502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env14501 == env14502) = true)

theorem identity14502 : scanCanonicalize (H12AffineFastState.compose env14502 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound14502 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14503 : List Nat := [2,4,8,16,0,17,9,256,512,14,10,27,19,276,287,25,261,17,15,286,10,287,270,285,18,17,11,27,260,17,267,1,257,1,277,512]

theorem envBound14503 : H12AffineFastState.Bounded env14503 := by
  intro p hp
  have h : env14503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14502_14503 : H12AffineEnvironment.transform 9 14 env14502 = env14503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env14502 == env14503) = true)

theorem identity14503 : scanCanonicalize (H12AffineFastState.compose env14503 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14503 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env14504 : List Nat := [2,4,8,16,0,17,9,5,512,14,10,27,19,17,26,25,0,17,15,27,10,26,11,24,18,17,11,27,1,17,14,1,4,1,16,512]

theorem envBound14504 : H12AffineFastState.Bounded env14504 := by
  intro p hp
  have h : env14504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14503_14504 : H12AffineEnvironment.transform 7 5 env14503 = env14504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14503 == env14504) = true)

theorem identity14504 : scanCanonicalize (H12AffineFastState.compose env14504 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound14504 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14505 : List Nat := [2,4,8,16,0,17,9,5,25,14,10,27,19,17,26,25,0,17,15,27,10,26,11,24,18,17,11,27,1,17,14,1,4,1,16,25]

theorem envBound14505 : H12AffineFastState.Bounded env14505 := by
  intro p hp
  have h : env14505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14504_14505 : H12AffineEnvironment.transform 8 25 env14504 = env14505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env14504 == env14505) = true)

theorem identity14505 : scanCanonicalize (H12AffineFastState.compose env14505 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14506 : List Nat := [2,4,2,16,0,17,3,5,19,4,0,17,19,17,16,19,0,17,5,17,0,16,1,18,18,17,1,17,1,17,4,1,4,1,16,19]

theorem envBound14506 : H12AffineFastState.Bounded env14506 := by
  intro p hp
  have h : env14506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14505_14506 : H12AffineEnvironment.transform 2 2 env14505 = env14506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14505 == env14506) = true)

theorem identity14506 : scanCanonicalize (H12AffineFastState.compose env14506 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound14506 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14507 : List Nat := [2,3,2,16,0,17,3,2,19,3,0,17,19,17,16,19,0,17,2,17,0,16,1,18,18,17,1,17,1,17,3,1,3,1,16,19]

theorem envBound14507 : H12AffineFastState.Bounded env14507 := by
  intro p hp
  have h : env14507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14506_14507 : H12AffineEnvironment.transform 1 3 env14506 = env14507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env14506 == env14507) = true)

def env14508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,254096,8328,64,64725,160860,140365,303452,1500,272392,257,21792,46213,74251]

theorem envBound14508 : H12AffineFastState.Bounded env14508 := by
  intro p hp
  have h : env14508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14477_14508 : H12AffineEnvironment.transform 20 4161 env14477 = env14508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14477 == env14508) = true)

theorem identity14508 : scanCanonicalize (H12AffineFastState.compose env14508 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound14508 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,98781,8328,64,64725,5393,17664,303452,1500,272392,257,21792,46213,74251]

theorem envBound14509 : H12AffineFastState.Bounded env14509 := by
  intro p hp
  have h : env14509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14508_14509 : H12AffineEnvironment.transform 16 24909 env14508 = env14509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env14508 == env14509) = true)

def env14510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,98645,8192,64,64605,5393,17664,303452,1364,272392,257,21792,46093,74251]

theorem envBound14510 : H12AffineFastState.Bounded env14510 := by
  intro p hp
  have h : env14510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14509_14510 : H12AffineEnvironment.transform 6 8 env14509 = env14510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14509 == env14510) = true)

theorem identity14510 : scanCanonicalize (H12AffineFastState.compose env14510 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound14510 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67619,1025,32769,4161,119926,17,98645,8192,64,64605,5393,17664,108927,1364,73771,257,21792,46093,74251]

theorem envBound14511 : H12AffineFastState.Bounded env14511 := by
  intro p hp
  have h : env14511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14510_14511 : H12AffineEnvironment.transform 17 67619 env14510 = env14511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env14510 == env14511) = true)

theorem identity14511 : scanCanonicalize (H12AffineFastState.compose env14511 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound14511 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env14512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,64808,1025,32769,4161,8573,17,29790,8192,64,64605,5393,17664,23668,1364,54560,257,21792,46093,55040]

theorem envBound14512 : H12AffineFastState.Bounded env14512 := by
  intro p hp
  have h : env14512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14511_14512 : H12AffineEnvironment.transform 15 62731 env14511 = env14512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env14511 == env14512) = true)

theorem identity14512 : scanCanonicalize (H12AffineFastState.compose env14512 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14512 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,16401,56436,1025,32769,4161,33,17,21762,348,64,56577,5393,17664,23668,1364,54560,257,21792,38225,55040]

theorem envBound14513 : H12AffineFastState.Bounded env14513 := by
  intro p hp
  have h : env14513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14512_14513 : H12AffineEnvironment.transform 12 348 env14512 = env14513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14512 == env14513) = true)

theorem identity14513 : scanCanonicalize (H12AffineFastState.compose env14513 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14513 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env14514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21591,16401,23668,1025,1,4161,33,17,21762,348,64,23809,5393,17664,23668,1364,21792,257,21792,5457,22272]

theorem envBound14514 : H12AffineFastState.Bounded env14514 := by
  intro p hp
  have h : env14514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14513_14514 : H12AffineEnvironment.transform 14 0 env14513 = env14514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14513 == env14514) = true)

theorem identity14514 : scanCanonicalize (H12AffineFastState.compose env14514 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound14514 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env14515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5204,0,3,5189,2080,1025,1,4161,33,17,342,348,64,2389,5393,4436,2080,1364,372,257,372,5457,852]

theorem envBound14515 : H12AffineFastState.Bounded env14515 := by
  intro p hp
  have h : env14515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14514_14515 : H12AffineEnvironment.transform 13 5204 env14514 = env14515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env14514 == env14515) = true)

def env14516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,98644,8193,64,64604,5393,17664,303452,1365,272392,257,21792,46092,74251]

theorem envBound14516 : H12AffineFastState.Bounded env14516 := by
  intro p hp
  have h : env14516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14509_14516 : H12AffineEnvironment.transform 6 9 env14509 = env14516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14509 == env14516) = true)

theorem identity14516 : scanCanonicalize (H12AffineFastState.compose env14516 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound14516 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,108926,1025,32769,4161,95531,17,98644,8193,64,64604,5393,17664,67618,1365,98678,257,21792,46092,74251]

theorem envBound14517 : H12AffineFastState.Bounded env14517 := by
  intro p hp
  have h : env14517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14516_14517 : H12AffineEnvironment.transform 17 108926 env14516 = env14517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env14516 == env14517) = true)

theorem identity14517 : scanCanonicalize (H12AffineFastState.compose env14517 (packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound14517 : packedSelected [0,1,7,8,9,10,12,14,15,16,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env14518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21794,24909,64604,1025,32769,4161,8201,17,54390,8193,64,64604,5393,17664,23808,1365,54356,257,21792,46092,30505]

theorem envBound14518 : H12AffineFastState.Bounded env14518 := by
  intro p hp
  have h : env14518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14517_14518 : H12AffineEnvironment.transform 15 21794 env14517 = env14518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env14517 == env14518) = true)

theorem identity14518 : scanCanonicalize (H12AffineFastState.compose env14518 (packedSelected [0,2,3,4,6,8,9,11,12,15,20,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14518 : packedSelected [0,2,3,4,6,8,9,11,12,15,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env14519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8575,5392,34817,1025,32769,4161,8201,17,41003,8193,64,34817,5393,12637,10589,1365,40969,257,8573,46092,884]

theorem envBound14519 : H12AffineFastState.Bounded env14519 := by
  intro p hp
  have h : env14519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14518_14519 : H12AffineEnvironment.transform 13 13405 env14518 = env14519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14518 == env14519) = true)

theorem identity14519 : scanCanonicalize (H12AffineFastState.compose env14519 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14519 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env14520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,32768,343,5392,34817,1025,32769,4161,33,17,32771,41,64,34817,5393,4469,2421,1365,32801,257,341,37924,884]

theorem envBound14520 : H12AffineFastState.Bounded env14520 := by
  intro p hp
  have h : env14520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14519_14520 : H12AffineEnvironment.transform 12 40 env14519 = env14520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14519 == env14520) = true)

theorem identity14520 : scanCanonicalize (H12AffineFastState.compose env14520 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14520 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14521 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,32768,35,5220,34817,1025,32769,4161,33,17,32771,41,64,34817,5221,4097,2049,1057,32801,117,33,37924,512]

theorem envBound14521 : H12AffineFastState.Bounded env14521 := by
  intro p hp
  have h : env14521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14520_14521 : H12AffineEnvironment.transform 7 116 env14520 = env14521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14520 == env14521) = true)

theorem identity14521 : scanCanonicalize (H12AffineFastState.compose env14521 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound14521 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14522 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,113,35,5220,2160,1025,112,4161,33,17,114,41,64,2160,5221,4097,2049,1057,80,117,33,5205,512]

theorem envBound14522 : H12AffineFastState.Bounded env14522 := by
  intro p hp
  have h : env14522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14521_14522 : H12AffineEnvironment.transform 14 113 env14521 = env14522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env14521 == env14522) = true)

theorem identity14522 : scanCanonicalize (H12AffineFastState.compose env14522 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2672) := by decide +kernel

theorem selectedBound14522 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14523 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2672,40,3589,113,35,3604,2160,1025,112,2609,33,17,114,41,64,2160,3605,2673,2049,1057,80,117,33,3621,512]

theorem envBound14523 : H12AffineFastState.Bounded env14523 := by
  intro p hp
  have h : env14523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14522_14523 : H12AffineEnvironment.transform 11 2672 env14522 = env14523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2672 env14522 == env14523) = true)

theorem identity14523 : scanCanonicalize (H12AffineFastState.compose env14523 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1620) := by decide +kernel

theorem selectedBound14523 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env14524 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1620,1060,40,81,113,35,64,1572,1025,112,1125,33,17,114,41,64,1572,65,1061,1621,1057,80,117,33,113,512]

theorem envBound14524 : H12AffineFastState.Bounded env14524 := by
  intro p hp
  have h : env14524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14523_14524 : H12AffineEnvironment.transform 10 1620 env14523 = env14524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1620 env14523 == env14524) = true)

theorem identity14524 : scanCanonicalize (H12AffineFastState.compose env14524 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound14524 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14525 : List Nat := [2,4,8,16,32,64,9,116,512,68,528,96,40,81,113,35,64,608,69,112,33,33,17,114,41,64,608,65,97,529,101,80,117,33,113,512]

theorem envBound14525 : H12AffineFastState.Bounded env14525 := by
  intro p hp
  have h : env14525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14524_14525 : H12AffineEnvironment.transform 9 68 env14524 = env14525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env14524 == env14525) = true)

theorem identity14525 : scanCanonicalize (H12AffineFastState.compose env14525 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound14525 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14526 : List Nat := [2,4,8,16,32,64,9,116,16,68,0,96,40,81,113,35,64,112,69,112,33,33,17,114,41,64,112,65,97,1,101,80,117,33,113,16]

theorem envBound14526 : H12AffineFastState.Bounded env14526 := by
  intro p hp
  have h : env14526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14525_14526 : H12AffineEnvironment.transform 8 16 env14525 = env14526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env14525 == env14526) = true)

theorem identity14526 : scanCanonicalize (H12AffineFastState.compose env14526 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound14526 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14527 : List Nat := [2,4,8,16,32,33,9,21,16,37,0,1,40,48,16,35,33,17,36,17,33,33,17,19,41,33,17,32,0,1,4,49,20,33,16,16]

theorem envBound14527 : H12AffineFastState.Bounded env14527 := by
  intro p hp
  have h : env14527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14526_14527 : H12AffineEnvironment.transform 5 33 env14526 = env14527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env14526 == env14527) = true)

theorem identity14527 : scanCanonicalize (H12AffineFastState.compose env14527 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14527 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14528 : List Nat := [2,4,8,16,1,0,9,21,16,4,0,1,9,17,16,2,0,17,5,17,0,0,17,19,8,0,17,1,0,1,4,16,20,0,16,16]

theorem envBound14528 : H12AffineFastState.Bounded env14528 := by
  intro p hp
  have h : env14528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14527_14528 : H12AffineEnvironment.transform 4 1 env14527 = env14528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14527 == env14528) = true)

def env14529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441625,2257181,254096,8328,64,2157717,2253853,140365,2404637,2102685,2373704,257,21792,46213,2175562]

theorem envBound14529 : H12AffineFastState.Bounded env14529 := by
  intro p hp
  have h : env14529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14476_14529 : H12AffineEnvironment.transform 21 441625 env14476 = env14529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441625 env14476 == env14529) = true)

def env14530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,254096,8328,64,64725,160861,140365,303453,1501,272392,257,21792,46213,74250]

theorem envBound14530 : H12AffineFastState.Bounded env14530 := by
  intro p hp
  have h : env14530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14529_14530 : H12AffineEnvironment.transform 20 4160 env14529 = env14530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14529 == env14530) = true)

theorem identity14530 : scanCanonicalize (H12AffineFastState.compose env14530 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound14530 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,272512,62660,95497,8328,64,64725,57796,45524,303453,1501,272392,257,21792,46213,74250]

theorem envBound14531 : H12AffineFastState.Bounded env14531 := by
  intro p hp
  have h : env14531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14530_14531 : H12AffineEnvironment.transform 16 38297 env14530 = env14531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env14530 == env14531) = true)

theorem identity14531 : scanCanonicalize (H12AffineFastState.compose env14531 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14531 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env14532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38297,262144,1025,32769,4160,272512,62660,21762,8328,64,64725,57796,45524,303453,1501,272392,257,21792,46213,513]

theorem envBound14532 : H12AffineFastState.Bounded env14532 := by
  intro p hp
  have h : env14532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14531_14532 : H12AffineEnvironment.transform 15 8203 env14531 = env14532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14531 == env14532) = true)

theorem identity14532 : scanCanonicalize (H12AffineFastState.compose env14532 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound14532 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38297,2421,1025,32769,4160,8693,62660,21762,8328,64,64725,57796,45524,43048,1501,8573,257,21792,46213,513]

theorem envBound14533 : H12AffineFastState.Bounded env14533 := by
  intro p hp
  have h : env14533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14532_14533 : H12AffineEnvironment.transform 17 2421 env14532 = env14533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env14532 == env14533) = true)

theorem identity14533 : scanCanonicalize (H12AffineFastState.compose env14533 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound14533 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8203,16400,2421,1025,21896,4160,8693,8525,21762,8328,64,10588,13389,25693,32161,1501,8573,257,21792,24844,513]

theorem envBound14534 : H12AffineFastState.Bounded env14534 := by
  intro p hp
  have h : env14534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14533_14534 : H12AffineEnvironment.transform 14 21897 env14533 = env14534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env14533 == env14534) = true)

theorem identity14534 : scanCanonicalize (H12AffineFastState.compose env14534 (packedSelected [2,3,5,6,8,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14534 : packedSelected [2,3,5,6,8,28] rootPS < 2^1333 := by decide +kernel

def env14535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,217,8203,5440,2421,1025,216,4160,8693,8525,82,8328,64,10588,13389,12557,10481,1501,8573,257,112,13404,513]

theorem envBound14535 : H12AffineFastState.Bounded env14535 := by
  intro p hp
  have h : env14535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14534_14535 : H12AffineEnvironment.transform 13 5456 env14534 = env14535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14534 == env14535) = true)

theorem identity14535 : scanCanonicalize (H12AffineFastState.compose env14535 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound14535 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env14536 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,0,8203,5440,2421,1025,1,4160,8492,8525,82,8273,64,10588,13389,12557,10280,1284,8573,257,112,13404,513]

theorem envBound14536 : H12AffineFastState.Bounded env14536 := by
  intro p hp
  have h : env14536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14535_14536 : H12AffineEnvironment.transform 6 89 env14535 = env14536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14535 == env14536) = true)

theorem identity14536 : scanCanonicalize (H12AffineFastState.compose env14536 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14536 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14537 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,0,263,5440,2421,1025,1,4160,32,65,82,349,64,2128,5441,4097,2340,1284,113,257,112,5456,513]

theorem envBound14537 : H12AffineFastState.Bounded env14537 := by
  intro p hp
  have h : env14537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14536_14537 : H12AffineEnvironment.transform 12 268 env14536 = env14537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14536 == env14537) = true)

theorem identity14537 : scanCanonicalize (H12AffineFastState.compose env14537 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound14537 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14538 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3408,268,2048,0,263,2064,2421,1025,1,3344,32,65,82,349,64,2128,2065,3409,2340,1284,113,257,112,2048,513]

theorem envBound14538 : H12AffineFastState.Bounded env14538 := by
  intro p hp
  have h : env14538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14537_14538 : H12AffineEnvironment.transform 11 3408 env14537 = env14538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env14537 == env14538) = true)

theorem identity14538 : scanCanonicalize (H12AffineFastState.compose env14538 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14538 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env14539 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,2404,268,2048,0,263,2064,2421,53,1,2340,32,65,82,349,64,2128,2065,2405,2340,304,113,257,112,2048,513]

theorem envBound14539 : H12AffineFastState.Bounded env14539 := by
  intro p hp
  have h : env14539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14538_14539 : H12AffineEnvironment.transform 9 52 env14538 = env14539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14538 == env14539) = true)

theorem identity14539 : scanCanonicalize (H12AffineFastState.compose env14539 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound14539 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14540 : List Nat := [2,4,8,16,32,64,89,256,512,52,372,16,268,372,0,263,356,1,53,1,80,32,65,82,349,64,292,357,17,80,304,113,257,112,372,513]

theorem envBound14540 : H12AffineFastState.Bounded env14540 := by
  intro p hp
  have h : env14540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14539_14540 : H12AffineEnvironment.transform 10 372 env14539 = env14540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env14539 == env14540) = true)

theorem identity14540 : scanCanonicalize (H12AffineFastState.compose env14540 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14540 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env14541 : List Nat := [2,4,8,16,32,17,8,256,512,52,293,16,268,293,0,263,309,1,53,1,1,32,16,3,268,17,292,308,17,1,304,32,257,33,293,513]

theorem envBound14541 : H12AffineFastState.Bounded env14541 := by
  intro p hp
  have h : env14541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14540_14541 : H12AffineEnvironment.transform 5 17 env14540 = env14541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14540 == env14541) = true)

theorem identity14541 : scanCanonicalize (H12AffineFastState.compose env14541 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14541 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14542 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,0,0,34,16,1,53,1,1,32,16,3,41,17,1,17,17,1,21,32,36,33,0,513]

theorem envBound14542 : H12AffineFastState.Bounded env14542 := by
  intro p hp
  have h : env14542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14541_14542 : H12AffineEnvironment.transform 7 37 env14541 = env14542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14541 == env14542) = true)

theorem identity14542 : scanCanonicalize (H12AffineFastState.compose env14542 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14543 : List Nat := [2,4,8,0,32,1,8,37,512,36,0,0,41,0,0,34,0,1,37,1,1,32,0,3,41,1,1,1,1,1,5,32,36,33,0,513]

theorem envBound14543 : H12AffineFastState.Bounded env14543 := by
  intro p hp
  have h : env14543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14542_14543 : H12AffineEnvironment.transform 3 0 env14542 = env14543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14542 == env14543) = true)

theorem identity14543 : scanCanonicalize (H12AffineFastState.compose env14543 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14544 : List Nat := [2,4,3,0,32,1,3,37,512,36,0,0,34,0,0,34,0,1,37,1,1,32,0,3,34,1,1,1,1,1,5,32,36,33,0,513]

theorem envBound14544 : H12AffineFastState.Bounded env14544 := by
  intro p hp
  have h : env14544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14543_14544 : H12AffineEnvironment.transform 2 3 env14543 = env14544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14543 == env14544) = true)

def env14545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,254096,8328,64,64724,160860,140365,303452,1500,272393,257,21792,46213,74251]

theorem envBound14545 : H12AffineFastState.Bounded env14545 := by
  intro p hp
  have h : env14545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14529_14545 : H12AffineEnvironment.transform 20 4161 env14529 = env14545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14529 == env14545) = true)

def env14546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169265,155996,254096,8328,64,64724,160860,140365,35188,1500,33,257,21792,46213,74251]

theorem envBound14546 : H12AffineFastState.Bounded env14546 := by
  intro p hp
  have h : env14546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14545_14546 : H12AffineEnvironment.transform 17 10280 env14545 = env14546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14545 == env14546) = true)

def env14547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21793,41292,73856,8328,64,64724,46156,58461,35188,1500,33,257,21792,46213,74251]

theorem envBound14547 : H12AffineFastState.Bounded env14547 := by
  intro p hp
  have h : env14547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14546_14547 : H12AffineEnvironment.transform 16 49168 env14546 = env14547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14546 == env14547) = true)

theorem identity14547 : scanCanonicalize (H12AffineFastState.compose env14547 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49168,10280,1025,32769,4161,21793,41292,41430,8328,64,64724,46156,58461,35188,1500,33,257,21792,46213,41821]

theorem envBound14548 : H12AffineFastState.Bounded env14548 := by
  intro p hp
  have h : env14548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14547_14548 : H12AffineEnvironment.transform 15 33110 env14547 = env14548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14547 == env14548) = true)

theorem identity14548 : scanCanonicalize (H12AffineFastState.compose env14548 (packedSelected [0,1,4,5,7,8,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14548 : packedSelected [0,1,4,5,7,8,22,24] rootPS < 2^1333 := by decide +kernel

def env14549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10280,1025,8541,4161,21793,16,138,8328,64,23944,5392,17665,10280,1500,33,257,21792,5593,513]

theorem envBound14549 : H12AffineFastState.Bounded env14549 := by
  intro p hp
  have h : env14549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14548_14549 : H12AffineEnvironment.transform 14 8540 env14548 = env14549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14548 == env14549) = true)

theorem identity14549 : scanCanonicalize (H12AffineFastState.compose env14549 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14549 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,343,16401,2421,1025,0,4161,21793,16,138,469,64,23944,5392,17665,2421,1500,33,257,21792,5593,513]

theorem envBound14550 : H12AffineFastState.Bounded env14550 := by
  intro p hp
  have h : env14550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14549_14550 : H12AffineEnvironment.transform 12 349 env14549 = env14550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14549 == env14550) = true)

theorem identity14550 : scanCanonicalize (H12AffineFastState.compose env14550 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14550 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14551 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,1,343,16401,2421,1025,0,4161,21793,16,82,269,64,23888,5392,17665,2421,1284,33,257,21792,5377,513]

theorem envBound14551 : H12AffineFastState.Bounded env14551 := by
  intro p hp
  have h : env14551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14550_14551 : H12AffineEnvironment.transform 6 88 env14550 = env14551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14550 == env14551) = true)

theorem identity14551 : scanCanonicalize (H12AffineFastState.compose env14551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound14551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14552 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,4113,1,343,4096,2421,1025,0,4161,1328,16,82,269,64,3393,5392,5392,2421,1284,33,257,1329,5377,513]

theorem envBound14552 : H12AffineFastState.Bounded env14552 := by
  intro p hp
  have h : env14552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14551_14552 : H12AffineEnvironment.transform 13 4113 env14551 = env14552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env14551 == env14552) = true)

theorem identity14552 : scanCanonicalize (H12AffineFastState.compose env14552 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound14552 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14553 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,4096,56,4113,1,50,4096,2064,1025,0,4161,1109,16,82,104,64,3108,5237,5237,2064,1121,33,100,1108,5220,513]

theorem envBound14553 : H12AffineFastState.Bounded env14553 := by
  intro p hp
  have h : env14553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14552_14553 : H12AffineEnvironment.transform 7 101 env14552 = env14553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env14552 == env14553) = true)

theorem identity14553 : scanCanonicalize (H12AffineFastState.compose env14553 (packedSelected [1,2,4,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound14553 : packedSelected [1,2,4,7,11,12] rootPS < 2^1333 := by decide +kernel

def env14554 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,555,56,570,1,50,555,2064,1025,0,618,1109,16,82,104,64,3108,1630,1630,2064,1121,33,100,1108,1615,513]

theorem envBound14554 : H12AffineFastState.Bounded env14554 := by
  intro p hp
  have h : env14554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14553_14554 : H12AffineEnvironment.transform 11 555 env14553 = env14554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env14553 == env14554) = true)

theorem identity14554 : scanCanonicalize (H12AffineFastState.compose env14554 (packedSelected [14] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound14554 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env14555 : List Nat := [2,4,8,16,32,64,88,101,512,37,2048,555,56,570,1,50,555,2064,36,0,618,112,16,82,104,64,2049,635,635,2064,68,33,100,113,618,513]

theorem envBound14555 : H12AffineFastState.Bounded env14555 := by
  intro p hp
  have h : env14555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14554_14555 : H12AffineEnvironment.transform 9 37 env14554 = env14555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env14554 == env14555) = true)

theorem identity14555 : scanCanonicalize (H12AffineFastState.compose env14555 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound14555 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14556 : List Nat := [2,4,8,16,32,10,18,47,512,37,2048,555,56,570,1,50,555,2064,36,0,544,58,16,24,34,10,2049,561,561,2064,14,33,46,59,544,513]

theorem envBound14556 : H12AffineFastState.Bounded env14556 := by
  intro p hp
  have h : env14556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14555_14556 : H12AffineEnvironment.transform 5 10 env14555 = env14556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env14555 == env14556) = true)

theorem identity14556 : scanCanonicalize (H12AffineFastState.compose env14556 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound14556 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14557 : List Nat := [2,4,8,16,32,10,18,47,512,37,522,555,56,570,1,50,555,538,36,0,544,58,16,24,34,10,523,561,561,538,14,33,46,59,544,513]

theorem envBound14557 : H12AffineFastState.Bounded env14557 := by
  intro p hp
  have h : env14557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14556_14557 : H12AffineEnvironment.transform 10 522 env14556 = env14557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env14556 == env14557) = true)

theorem identity14557 : scanCanonicalize (H12AffineFastState.compose env14557 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound14557 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env14558 : List Nat := [2,4,8,16,32,10,18,47,59,37,49,16,56,1,1,50,16,33,36,0,27,58,16,24,34,10,48,10,10,33,14,33,46,59,27,58]

theorem envBound14558 : H12AffineFastState.Bounded env14558 := by
  intro p hp
  have h : env14558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14557_14558 : H12AffineEnvironment.transform 8 59 env14557 = env14558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env14557 == env14558) = true)

theorem identity14558 : scanCanonicalize (H12AffineFastState.compose env14558 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14558 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env14559 : List Nat := [2,4,8,16,17,10,18,30,10,20,0,16,9,1,1,3,16,16,21,0,27,11,16,24,19,10,1,10,10,16,14,16,31,10,27,11]

theorem envBound14559 : H12AffineFastState.Bounded env14559 := by
  intro p hp
  have h : env14559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14558_14559 : H12AffineEnvironment.transform 4 17 env14558 = env14559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14558 == env14559) = true)

theorem identity14559 : scanCanonicalize (H12AffineFastState.compose env14559 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14560 : List Nat := [2,4,8,11,10,10,9,5,10,15,0,11,9,1,1,3,11,11,14,0,0,11,11,3,8,10,1,10,10,11,14,11,4,10,0,11]

theorem envBound14560 : H12AffineFastState.Bounded env14560 := by
  intro p hp
  have h : env14560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14559_14560 : H12AffineEnvironment.transform 3 11 env14559 = env14560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14559 == env14560) = true)

theorem identity14560 : scanCanonicalize (H12AffineFastState.compose env14560 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14560 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14561 : List Nat := [2,4,2,1,0,0,3,5,0,5,0,1,3,1,1,3,1,1,4,0,0,1,1,3,2,0,1,0,0,1,4,1,4,0,0,1]

theorem envBound14561 : H12AffineFastState.Bounded env14561 := by
  intro p hp
  have h : env14561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14560_14561 : H12AffineEnvironment.transform 2 2 env14560 = env14561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14560 == env14561) = true)

def env14562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21792,41293,73857,8328,64,64724,46157,58460,35188,1500,33,257,21792,46213,74251]

theorem envBound14562 : H12AffineFastState.Bounded env14562 := by
  intro p hp
  have h : env14562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14546_14562 : H12AffineEnvironment.transform 16 49169 env14546 = env14562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14546 == env14562) = true)

theorem identity14562 : scanCanonicalize (H12AffineFastState.compose env14562 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound14562 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,49169,10280,1025,32769,4161,21792,41293,41310,8328,64,64724,46157,58460,35188,1500,33,257,21792,46213,41940]

theorem envBound14563 : H12AffineFastState.Bounded env14563 := by
  intro p hp
  have h : env14563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14562_14563 : H12AffineEnvironment.transform 15 33247 env14562 = env14563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env14562 == env14563) = true)

theorem identity14563 : scanCanonicalize (H12AffineFastState.compose env14563 (packedSelected [5,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound14563 : packedSelected [5,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env14564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,32768,33247,49169,3309,1025,32769,4161,21792,34184,34203,1101,64,55313,37000,49305,35188,1500,33,257,21792,36928,34577]

theorem envBound14564 : H12AffineFastState.Bounded env14564 := by
  intro p hp
  have h : env14564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14563_14564 : H12AffineEnvironment.transform 12 1221 env14563 = env14564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env14563 == env14564) = true)

theorem identity14564 : scanCanonicalize (H12AffineFastState.compose env14564 (packedSelected [4,7,9,11,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1212) := by decide +kernel

theorem selectedBound14564 : packedSelected [4,7,9,11,23,27] rootPS < 2^1333 := by decide +kernel

def env14565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,1212,1379,17581,3309,1025,1213,4161,21792,308,295,1101,64,23725,5172,17445,3528,1500,33,257,21792,5372,941]

theorem envBound14565 : H12AffineFastState.Bounded env14565 := by
  intro p hp
  have h : env14565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14564_14565 : H12AffineEnvironment.transform 14 1212 env14564 = env14565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1212 env14564 == env14565) = true)

theorem identity14565 : scanCanonicalize (H12AffineFastState.compose env14565 (packedSelected [0,3,7,9,10,11,14,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound14565 : packedSelected [0,3,7,9,10,11,14,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env14566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,5237,1212,1379,4312,3309,1025,1213,4161,341,308,295,1101,64,2264,5172,4176,3528,1500,33,257,341,5372,941]

theorem envBound14566 : H12AffineFastState.Bounded env14566 := by
  intro p hp
  have h : env14566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14565_14566 : H12AffineEnvironment.transform 13 5237 env14565 = env14566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env14565 == env14566) = true)

theorem identity14566 : scanCanonicalize (H12AffineFastState.compose env14566 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14566 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14567 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1172,5156,1212,1330,4233,3260,1025,1213,4112,260,308,295,1052,17,2185,5172,4097,3481,1421,33,257,260,5293,941]

theorem envBound14567 : H12AffineFastState.Bounded env14567 := by
  intro p hp
  have h : env14567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14566_14567 : H12AffineEnvironment.transform 5 17 env14566 = env14567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14566 == env14567) = true)

theorem identity14567 : scanCanonicalize (H12AffineFastState.compose env14567 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3496) := by decide +kernel

theorem selectedBound14567 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env14568 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3496,1172,2444,1212,1330,3361,3260,1025,1213,3512,260,308,295,1052,17,2185,2460,3497,3481,1421,33,257,260,2309,941]

theorem envBound14568 : H12AffineFastState.Bounded env14568 := by
  intro p hp
  have h : env14568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14567_14568 : H12AffineEnvironment.transform 11 3496 env14567 = env14568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3496 env14567 == env14568) = true)

theorem identity14568 : scanCanonicalize (H12AffineFastState.compose env14568 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound14568 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env14569 : List Nat := [2,4,8,16,32,17,128,140,512,1024,2048,3108,1172,2048,1212,1214,3245,3260,1025,1213,3124,136,184,171,1052,17,2185,2064,3109,3093,1025,33,141,136,2185,545]

theorem envBound14569 : H12AffineFastState.Bounded env14569 := by
  intro p hp
  have h : env14569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14568_14569 : H12AffineEnvironment.transform 7 140 env14568 = env14569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env14568 == env14569) = true)

theorem identity14569 : scanCanonicalize (H12AffineFastState.compose env14569 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound14569 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14570 : List Nat := [2,4,8,16,32,17,128,140,49,1024,2048,3108,1172,2048,1212,1214,3245,3260,1025,1213,3124,136,184,171,1052,17,2185,2064,3109,3093,1025,33,141,136,2185,16]

theorem envBound14570 : H12AffineFastState.Bounded env14570 := by
  intro p hp
  have h : env14570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14569_14570 : H12AffineEnvironment.transform 8 49 env14569 = env14570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env14569 == env14570) = true)

theorem identity14570 : scanCanonicalize (H12AffineFastState.compose env14570 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound14570 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env14571 : List Nat := [2,4,8,16,32,17,128,140,49,1024,1213,153,1172,1213,1212,1214,16,1,1025,1213,137,136,184,171,1052,17,1076,1197,152,168,1025,33,141,136,1076,16]

theorem envBound14571 : H12AffineFastState.Bounded env14571 := by
  intro p hp
  have h : env14571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14570_14571 : H12AffineEnvironment.transform 10 1213 env14570 = env14571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env14570 == env14571) = true)

theorem identity14571 : scanCanonicalize (H12AffineFastState.compose env14571 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound14571 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env14572 : List Nat := [2,4,8,16,32,17,128,140,49,172,17,153,56,17,16,18,16,1,173,17,137,136,184,171,176,17,152,1,152,168,173,33,141,136,152,16]

theorem envBound14572 : H12AffineFastState.Bounded env14572 := by
  intro p hp
  have h : env14572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14571_14572 : H12AffineEnvironment.transform 9 172 env14571 = env14572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env14571 == env14572) = true)

theorem identity14572 : scanCanonicalize (H12AffineFastState.compose env14572 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14572 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14573 : List Nat := [2,4,8,16,32,17,25,21,49,53,17,0,56,17,16,18,16,1,52,17,16,17,33,50,41,17,1,1,1,49,52,33,20,17,1,16]

theorem envBound14573 : H12AffineFastState.Bounded env14573 := by
  intro p hp
  have h : env14573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14572_14573 : H12AffineEnvironment.transform 6 25 env14572 = env14573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14572 == env14573) = true)

theorem identity14573 : scanCanonicalize (H12AffineFastState.compose env14573 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14574 : List Nat := [2,4,8,16,0,17,25,21,17,21,17,0,24,17,16,18,16,1,20,17,16,17,1,18,9,17,1,1,1,17,20,1,20,17,1,16]

theorem envBound14574 : H12AffineFastState.Bounded env14574 := by
  intro p hp
  have h : env14574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14573_14574 : H12AffineEnvironment.transform 4 0 env14573 = env14574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14573 == env14574) = true)

def env14575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169264,155996,254096,8328,64,64724,160860,140365,35189,1500,32,257,21792,46213,74251]

theorem envBound14575 : H12AffineFastState.Bounded env14575 := by
  intro p hp
  have h : env14575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14545_14575 : H12AffineEnvironment.transform 17 10281 env14545 = env14575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14545 == env14575) = true)

def env14576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21792,41292,73856,8328,64,64724,46156,58461,35189,1500,32,257,21792,46213,74251]

theorem envBound14576 : H12AffineFastState.Bounded env14576 := by
  intro p hp
  have h : env14576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14575_14576 : H12AffineEnvironment.transform 16 49168 env14575 = env14576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14575 == env14576) = true)

theorem identity14576 : scanCanonicalize (H12AffineFastState.compose env14576 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14576 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1025,32769,4161,21792,41292,138,8328,64,64724,46156,58461,35189,1500,32,257,21792,46213,513]

theorem envBound14577 : H12AffineFastState.Bounded env14577 := by
  intro p hp
  have h : env14577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14576_14577 : H12AffineEnvironment.transform 15 8202 env14576 = env14577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14576 == env14577) = true)

theorem identity14577 : scanCanonicalize (H12AffineFastState.compose env14577 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14577 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49168,2557,1025,32769,4161,21792,32920,138,348,64,56576,38296,50569,35189,1500,32,257,21792,38225,513]

theorem envBound14578 : H12AffineFastState.Bounded env14578 := by
  intro p hp
  have h : env14578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14577_14578 : H12AffineEnvironment.transform 12 468 env14577 = env14578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14577 == env14578) = true)

theorem identity14578 : scanCanonicalize (H12AffineFastState.compose env14578 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14578 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,2421,1025,32769,4161,21792,32784,2,348,64,56576,38160,50433,35189,1364,32,257,21792,38225,513]

end H12CloudChart1