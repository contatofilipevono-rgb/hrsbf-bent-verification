import H12CloudChart1Data118

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound30177 : H12AffineFastState.Bounded env30177 := by
  intro p hp
  have h : env30177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30176_30177 : H12AffineEnvironment.transform 6 9 env30176 = env30177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30176 == env30177) = true)

theorem identity30177 : scanCanonicalize (H12AffineFastState.compose env30177 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 136512) := by decide +kernel

theorem selectedBound30177 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,131072,2421,1025,0,4161,136512,17,3,348,65,2160,5392,4097,138341,1364,136512,257,33,5457,512]

theorem envBound30178 : H12AffineFastState.Bounded env30178 := by
  intro p hp
  have h : env30178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30177_30178 : H12AffineEnvironment.transform 21 136512 env30177 = env30178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136512 env30177 == env30178) = true)

theorem identity30178 : scanCanonicalize (H12AffineFastState.compose env30178 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30178 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30179 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,131072,2341,1025,0,4113,136464,17,3,268,17,2080,5392,4097,138293,1284,136464,257,33,5377,512]

theorem envBound30179 : H12AffineFastState.Bounded env30179 := by
  intro p hp
  have h : env30179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30178_30179 : H12AffineEnvironment.transform 5 16 env30178 = env30179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30178 == env30179) = true)

theorem identity30179 : scanCanonicalize (H12AffineFastState.compose env30179 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound30179 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env30180 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5141,2341,1025,0,4113,261,17,3,268,17,2080,5392,4097,2080,1284,261,257,33,5377,512]

theorem envBound30180 : H12AffineFastState.Bounded env30180 := by
  intro p hp
  have h : env30180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30179_30180 : H12AffineEnvironment.transform 16 5141 env30179 = env30180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env30179 == env30180) = true)

theorem identity30180 : scanCanonicalize (H12AffineFastState.compose env30180 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30180 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30181 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,35,5141,2048,1025,0,4113,32,17,3,41,17,2080,5173,4097,2080,1057,32,36,33,5156,512]

theorem envBound30181 : H12AffineFastState.Bounded env30181 := by
  intro p hp
  have h : env30181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30180_30181 : H12AffineEnvironment.transform 7 37 env30180 = env30181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30180 == env30181) = true)

theorem identity30181 : scanCanonicalize (H12AffineFastState.compose env30181 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30181 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30182 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,1,2,5141,2048,1025,0,4113,1,17,3,8,17,2049,5140,4097,2049,1024,1,5,0,5125,512]

theorem envBound30182 : H12AffineFastState.Bounded env30182 := by
  intro p hp
  have h : env30182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30181_30182 : H12AffineEnvironment.transform 4 1 env30181 = env30182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30181 == env30182) = true)

def env30183 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1045,1,2,1029,2048,1025,0,1,1,17,3,8,17,2049,1028,17,2049,1024,1,5,0,1045,512]

theorem envBound30183 : H12AffineFastState.Bounded env30183 := by
  intro p hp
  have h : env30183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30182_30183 : H12AffineEnvironment.transform 11 16 env30182 = env30183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30182 == env30183) = true)

def env30184 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1044,1,2,1028,2048,1025,0,0,1,17,3,8,17,2049,1029,16,2049,1024,1,5,0,1044,512]

theorem envBound30184 : H12AffineFastState.Bounded env30184 := by
  intro p hp
  have h : env30184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30182_30184 : H12AffineEnvironment.transform 11 17 env30182 = env30184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30182 == env30184) = true)

theorem identity30184 : scanCanonicalize (H12AffineFastState.compose env30184 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30184 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30185 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,9,0,1,2,16,2048,21,0,0,1,17,3,8,17,2049,17,16,2049,20,1,5,0,0,512]

theorem envBound30185 : H12AffineFastState.Bounded env30185 := by
  intro p hp
  have h : env30185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30184_30185 : H12AffineEnvironment.transform 9 20 env30184 = env30185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30184 == env30185) = true)

theorem identity30185 : scanCanonicalize (H12AffineFastState.compose env30185 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound30185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30186 : List Nat := [2,4,8,16,1,16,9,4,512,20,543,17,9,0,1,2,16,543,21,0,0,1,17,3,8,17,542,17,16,542,20,1,5,0,0,512]

theorem envBound30186 : H12AffineFastState.Bounded env30186 := by
  intro p hp
  have h : env30186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30185_30186 : H12AffineEnvironment.transform 10 543 env30185 = env30186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env30185 == env30186) = true)

def leafEnv30186 : List Nat := [2,4,8,16,1,16,9,4,512,20,543,17,9,0,1,2,16,543,21,0,0,1,17,3,21,8,1,17,542,17,16,542,20,1,5,0,5,3,0,512,1,0,0]

def active30186 : List Nat := [0,1,2,3,8]

def tree30186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30186 : H12WitnessSearch.Good tree30186 := H12GlobalWitnessIndex.good

theorem leafIdentity30186 : H12AffineFastState.composeSystem env30186 rootObs = leafEnv30186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30186 rootObs == leafEnv30186) = true)

theorem terminalChecked30186 : H12PackedTerminal.terminalCheckFast leafEnv30186 active30186 tree30186 = true := by decide +kernel

def env30187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392437,8328,65,12729588,79130,8722483,8830977,8681700,4314199,257,8484155,8492191,8740658]

theorem envBound30187 : H12AffineFastState.Bounded env30187 := by
  intro p hp
  have h : env30187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30112_30187 : H12AffineEnvironment.transform 23 392437 env30112 = env30187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392437 env30112 == env30187) = true)

def env30188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98781,8328,65,12729588,79130,8480027,8568105,8390092,4314199,257,8484155,8492191,8462874]

theorem envBound30188 : H12AffineFastState.Bounded env30188 := by
  intro p hp
  have h : env30188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30187_30188 : H12AffineEnvironment.transform 17 32040 env30187 = env30188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30187 == env30188) = true)

def env30189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98781,8328,65,4340964,79130,91403,179513,1500,4314199,257,95531,103567,74250]

theorem envBound30189 : H12AffineFastState.Bounded env30189 := by
  intro p hp
  have h : env30189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30188_30189 : H12AffineEnvironment.transform 22 16 env30188 = env30189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env30188 == env30189) = true)

theorem identity30189 : scanCanonicalize (H12AffineFastState.compose env30189 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound30189 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,98678,16,98781,8328,65,245138,79130,91403,179513,1500,21793,257,95531,103567,74250]

theorem envBound30190 : H12AffineFastState.Bounded env30190 := by
  intro p hp
  have h : env30190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30189_30190 : H12AffineEnvironment.transform 21 98678 env30189 = env30190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env30189 == env30190) = true)

def env30191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,98678,16,98645,8192,65,245018,79130,91403,179513,1364,21793,257,95531,103431,74250]

theorem envBound30191 : H12AffineFastState.Bounded env30191 := by
  intro p hp
  have h : env30191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30190_30191 : H12AffineEnvironment.transform 6 8 env30190 = env30191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30190 == env30191) = true)

theorem identity30191 : scanCanonicalize (H12AffineFastState.compose env30191 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound30191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32040,1025,32769,17728,62589,16,62558,8192,65,182289,16401,4096,179513,1364,21793,257,32,57612,22273]

theorem envBound30192 : H12AffineFastState.Bounded env30192 := by
  intro p hp
  have h : env30192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30191_30192 : H12AffineEnvironment.transform 15 29963 env30191 = env30192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env30191 == env30192) = true)

theorem identity30192 : scanCanonicalize (H12AffineFastState.compose env30192 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30192 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,13388,32040,1025,32769,17728,62589,16,62558,8192,65,64605,16401,4096,35189,1364,21793,257,32,57612,22273]

theorem envBound30193 : H12AffineFastState.Bounded env30193 := by
  intro p hp
  have h : env30193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30192_30193 : H12AffineEnvironment.transform 16 13388 env30192 = env30193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30192 == env30193) = true)

theorem identity30193 : scanCanonicalize (H12AffineFastState.compose env30193 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound30193 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,29963,13388,32040,1025,0,17728,29820,16,29791,8192,65,31836,16401,4096,2420,1364,21793,257,32,24845,22273]

theorem envBound30194 : H12AffineFastState.Bounded env30194 := by
  intro p hp
  have h : env30194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30193_30194 : H12AffineEnvironment.transform 14 1 env30193 = env30194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env30193 == env30194) = true)

theorem identity30194 : scanCanonicalize (H12AffineFastState.compose env30194 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30194 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env30195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,21511,5440,23588,1025,0,17728,21872,16,21843,268,65,23888,16401,4096,2420,1364,21793,257,32,16385,22273]

theorem envBound30195 : H12AffineFastState.Bounded env30195 := by
  intro p hp
  have h : env30195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30194_30195 : H12AffineEnvironment.transform 12 268 env30194 = env30195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30194 == env30195) = true)

theorem identity30195 : scanCanonicalize (H12AffineFastState.compose env30195 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30195 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,1,262,5440,2341,1025,0,4161,113,16,82,268,65,2129,5392,4096,2420,1364,32,257,32,5376,512]

theorem envBound30196 : H12AffineFastState.Bounded env30196 := by
  intro p hp
  have h : env30196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30195_30196 : H12AffineEnvironment.transform 13 5377 env30195 = env30196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30195 == env30196) = true)

theorem identity30196 : scanCanonicalize (H12AffineFastState.compose env30196 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30196 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30197 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5377,1,262,5440,2308,1025,0,4161,80,16,82,268,65,2129,5392,4096,2389,1364,1,257,1,5376,512]

theorem envBound30197 : H12AffineFastState.Bounded env30197 := by
  intro p hp
  have h : env30197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30196_30197 : H12AffineEnvironment.transform 4 1 env30196 = env30197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30196 == env30197) = true)

theorem identity30197 : scanCanonicalize (H12AffineFastState.compose env30197 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound30197 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30198 : List Nat := [2,4,8,16,1,64,8,256,512,1024,260,4096,268,5377,1,262,5440,0,1025,0,4161,80,16,82,268,65,341,5392,4096,81,1364,1,257,1,5376,512]

theorem envBound30198 : H12AffineFastState.Bounded env30198 := by
  intro p hp
  have h : env30198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30197_30198 : H12AffineEnvironment.transform 10 260 env30197 = env30198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env30197 == env30198) = true)

def env30199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,98678,16,98644,8193,65,245019,79130,91403,179513,1365,21793,257,95531,103430,74250]

theorem envBound30199 : H12AffineFastState.Bounded env30199 := by
  intro p hp
  have h : env30199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30190_30199 : H12AffineEnvironment.transform 6 9 env30190 = env30199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30190 == env30199) = true)

theorem identity30199 : scanCanonicalize (H12AffineFastState.compose env30199 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound30199 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58396,21793,16,21763,8193,65,158028,57677,45404,179513,1365,21793,257,41340,16465,63069]

theorem envBound30200 : H12AffineFastState.Bounded env30200 := by
  intro p hp
  have h : env30200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30199_30200 : H12AffineEnvironment.transform 15 54359 env30199 = env30200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env30199 == env30200) = true)

theorem identity30200 : scanCanonicalize (H12AffineFastState.compose env30200 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30200 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,32040,1025,32769,58396,21793,16,21763,8193,65,10589,57677,45404,64808,1365,21793,257,41340,16465,63069]

theorem envBound30201 : H12AffineFastState.Bounded env30201 := by
  intro p hp
  have h : env30201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30200_30201 : H12AffineEnvironment.transform 16 16401 env30200 = env30201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30200 == env30201) = true)

theorem identity30201 : scanCanonicalize (H12AffineFastState.compose env30201 (packedSelected [1,4,6,8,9,11,12,15,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30201 : packedSelected [1,4,6,8,9,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env30202 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,16384,32768,54359,16401,31788,1025,32769,58396,21541,16,21511,8193,65,10329,57417,45144,64556,1105,21541,5,41080,16465,63069]

theorem envBound30202 : H12AffineFastState.Bounded env30202 := by
  intro p hp
  have h : env30202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30201_30202 : H12AffineEnvironment.transform 7 4 env30201 = env30202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30201 == env30202) = true)

theorem identity30202 : scanCanonicalize (H12AffineFastState.compose env30202 (packedSelected [0,1,6,7,8,9,11,12,15,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30202 : packedSelected [0,1,6,7,8,9,11,12,15,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env30203 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,8192,16384,29788,8203,16401,31788,1025,29789,4160,21541,16,21511,8193,65,10329,5141,17412,2160,1105,21541,5,21540,16465,513]

theorem envBound30203 : H12AffineFastState.Bounded env30203 := by
  intro p hp
  have h : env30203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30202_30203 : H12AffineEnvironment.transform 14 29788 env30202 = env30203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30202 == env30203) = true)

theorem identity30203 : scanCanonicalize (H12AffineFastState.compose env30203 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30203 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30204 : List Nat := [2,4,8,16,32,64,9,4,512,20,2048,4096,8192,16384,28744,8203,16401,30776,21,28745,4160,20529,16,20499,8193,65,10329,4097,16400,2160,69,20529,5,20528,16465,513]

theorem envBound30204 : H12AffineFastState.Bounded env30204 := by
  intro p hp
  have h : env30204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30203_30204 : H12AffineEnvironment.transform 9 20 env30203 = env30204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30203 == env30204) = true)

def env30205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98781,8328,65,4340965,79130,91402,179512,1501,4314199,257,95530,103566,74251]

theorem envBound30205 : H12AffineFastState.Bounded env30205 := by
  intro p hp
  have h : env30205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30188_30205 : H12AffineEnvironment.transform 22 17 env30188 = env30205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env30188 == env30205) = true)

theorem identity30205 : scanCanonicalize (H12AffineFastState.compose env30205 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound30205 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32040,1025,32769,58516,4194304,17,21762,8328,65,4340965,57797,45525,179512,1501,4194440,257,41461,16465,63188]

theorem envBound30206 : H12AffineFastState.Bounded env30206 := by
  intro p hp
  have h : env30206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30205_30206 : H12AffineEnvironment.transform 15 54495 env30205 = env30206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env30205 == env30206) = true)

def env30207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58396,4194304,17,21762,8192,65,4340845,57677,45405,179512,1365,4194304,257,41341,16465,63068]

theorem envBound30207 : H12AffineFastState.Bounded env30207 := by
  intro p hp
  have h : env30207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30206_30207 : H12AffineEnvironment.transform 6 8 env30206 = env30207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30206 == env30207) = true)

theorem identity30207 : scanCanonicalize (H12AffineFastState.compose env30207 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30207 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4161,4194304,17,21762,8192,65,4340845,5392,17664,149861,1365,4194304,257,21792,16465,513]

theorem envBound30208 : H12AffineFastState.Bounded env30208 := by
  intro p hp
  have h : env30208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30207_30208 : H12AffineEnvironment.transform 14 29789 env30207 = env30208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30207 == env30208) = true)

theorem identity30208 : scanCanonicalize (H12AffineFastState.compose env30208 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound30208 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env30209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4161,147505,17,21762,8192,65,31836,5392,17664,149861,1365,147505,257,21792,16465,513]

theorem envBound30209 : H12AffineFastState.Bounded env30209 := by
  intro p hp
  have h : env30209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30208_30209 : H12AffineEnvironment.transform 21 147505 env30208 = env30209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env30208 == env30209) = true)

theorem identity30209 : scanCanonicalize (H12AffineFastState.compose env30209 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30209 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,32040,1025,29788,4161,32,17,21762,8192,65,31836,5392,17664,2420,1365,32,257,21792,16465,513]

theorem envBound30210 : H12AffineFastState.Bounded env30210 := by
  intro p hp
  have h : env30210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30209_30210 : H12AffineEnvironment.transform 16 16401 env30209 = env30210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30209 == env30210) = true)

theorem identity30210 : scanCanonicalize (H12AffineFastState.compose env30210 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound30210 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13388,2421,1025,1,4161,32,17,8543,8192,65,2049,5392,12637,2420,1365,32,257,8573,13324,513]

theorem envBound30211 : H12AffineFastState.Bounded env30211 := by
  intro p hp
  have h : env30211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30210_30211 : H12AffineEnvironment.transform 13 13405 env30210 = env30211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env30210 == env30211) = true)

theorem identity30211 : scanCanonicalize (H12AffineFastState.compose env30211 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound30211 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env30212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4113,0,1094,4096,2421,1025,1,4161,32,17,1299,1100,65,2049,5392,5393,2420,1365,32,257,1329,4160,513]

theorem envBound30212 : H12AffineFastState.Bounded env30212 := by
  intro p hp
  have h : env30212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30211_30212 : H12AffineEnvironment.transform 12 1100 env30211 = env30212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env30211 == env30212) = true)

def env30213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58397,4194304,17,21762,8193,65,4340844,57676,45404,179512,1364,4194305,257,41340,16465,63069]

theorem envBound30213 : H12AffineFastState.Bounded env30213 := by
  intro p hp
  have h : env30213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30206_30213 : H12AffineEnvironment.transform 6 9 env30206 = env30213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30206 == env30213) = true)

theorem identity30213 : scanCanonicalize (H12AffineFastState.compose env30213 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30213 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1025,32769,45340,4194304,17,3,8193,65,4340844,46157,45404,179512,1364,4194305,257,41340,5456,41820]

theorem envBound30214 : H12AffineFastState.Bounded env30214 := by
  intro p hp
  have h : env30214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30213_30214 : H12AffineEnvironment.transform 13 5377 env30213 = env30214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30213 == env30214) = true)

theorem identity30214 : scanCanonicalize (H12AffineFastState.compose env30214 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 169312) := by decide +kernel

theorem selectedBound30214 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env30215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10281,1025,32769,45340,169312,17,3,8193,65,43276,46157,45404,179512,1364,169313,257,41340,5456,41820]

theorem envBound30215 : H12AffineFastState.Bounded env30215 := by
  intro p hp
  have h : env30215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30214_30215 : H12AffineEnvironment.transform 21 169312 env30214 = env30215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169312 env30214 == env30215) = true)

theorem identity30215 : scanCanonicalize (H12AffineFastState.compose env30215 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound30215 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env30216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,4097,10281,1025,32769,45340,34145,17,3,8193,65,43276,46157,45404,44345,1364,34144,257,41340,5456,41820]

theorem envBound30216 : H12AffineFastState.Bounded env30216 := by
  intro p hp
  have h : env30216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30215_30216 : H12AffineEnvironment.transform 16 4097 env30215 = env30216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env30215 == env30216) = true)

theorem identity30216 : scanCanonicalize (H12AffineFastState.compose env30216 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound30216 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env30217 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,4405,32768,33111,4097,10281,53,32769,45340,33109,17,3,8193,65,43276,45177,45404,43277,352,33108,257,41340,4452,41820]

theorem envBound30217 : H12AffineFastState.Bounded env30217 := by
  intro p hp
  have h : env30217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30216_30217 : H12AffineEnvironment.transform 9 52 env30216 = env30217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env30216 == env30217) = true)

theorem identity30217 : scanCanonicalize (H12AffineFastState.compose env30217 (packedSelected [0,4,7,12,15,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30217 : packedSelected [0,4,7,12,15,22] rootPS < 2^1333 := by decide +kernel

def env30218 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4112,32768,32882,4097,10281,53,32769,45113,32880,17,3,8193,65,43049,45177,45177,43048,69,32881,36,41049,4161,41593]

theorem envBound30218 : H12AffineFastState.Bounded env30218 := by
  intro p hp
  have h : env30218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30217_30218 : H12AffineEnvironment.transform 7 37 env30217 = env30218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30217 == env30218) = true)

theorem identity30218 : scanCanonicalize (H12AffineFastState.compose env30218 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound30218 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30219 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4112,0,114,4097,10281,53,1,12345,112,17,3,8193,65,10281,12409,12409,10280,69,113,36,8281,4161,8825]

theorem envBound30219 : H12AffineFastState.Bounded env30219 := by
  intro p hp
  have h : env30219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30218_30219 : H12AffineEnvironment.transform 14 0 env30218 = env30219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env30218 == env30219) = true)

theorem identity30219 : scanCanonicalize (H12AffineFastState.compose env30219 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30219 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30220 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,8192,4112,0,34,4097,10281,53,1,12345,32,17,3,8193,17,10281,12329,12329,10280,21,33,36,8201,4113,8745]

theorem envBound30220 : H12AffineFastState.Bounded env30220 := by
  intro p hp
  have h : env30220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30219_30220 : H12AffineEnvironment.transform 5 16 env30219 = env30220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30219 == env30220) = true)

theorem identity30220 : scanCanonicalize (H12AffineFastState.compose env30220 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2095) := by decide +kernel

theorem selectedBound30220 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env30221 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2095,8192,2111,0,34,2094,10281,53,1,10262,32,17,3,8193,17,10281,10246,10246,10280,21,33,36,8201,2110,8745]

theorem envBound30221 : H12AffineFastState.Bounded env30221 := by
  intro p hp
  have h : env30221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30220_30221 : H12AffineEnvironment.transform 11 2095 env30220 = env30221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2095 env30220 == env30221) = true)

theorem identity30221 : scanCanonicalize (H12AffineFastState.compose env30221 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound30221 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env30222 : List Nat := [2,4,8,16,32,16,9,37,512,52,523,548,8192,564,0,34,549,8738,53,1,8733,32,17,3,8193,17,8738,8717,8717,8739,21,33,36,8201,565,8745]

theorem envBound30222 : H12AffineFastState.Bounded env30222 := by
  intro p hp
  have h : env30222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30221_30222 : H12AffineEnvironment.transform 10 523 env30221 = env30222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env30221 == env30222) = true)

theorem identity30222 : scanCanonicalize (H12AffineFastState.compose env30222 (packedSelected [0,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 37) := by decide +kernel

theorem selectedBound30222 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env30223 : List Nat := [2,4,8,16,32,16,9,37,512,52,523,548,37,564,0,34,549,519,53,1,568,32,17,3,36,17,519,552,552,518,21,33,36,44,565,524]

theorem envBound30223 : H12AffineFastState.Bounded env30223 := by
  intro p hp
  have h : env30223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30222_30223 : H12AffineEnvironment.transform 12 37 env30222 = env30223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 37 env30222 == env30223) = true)

theorem identity30223 : scanCanonicalize (H12AffineFastState.compose env30223 (packedSelected [2,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound30223 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env30224 : List Nat := [2,4,8,3,32,3,9,37,512,39,523,548,37,551,0,34,549,519,38,1,555,32,2,3,36,2,519,552,552,518,6,33,36,44,550,524]

theorem envBound30224 : H12AffineFastState.Bounded env30224 := by
  intro p hp
  have h : env30224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30223_30224 : H12AffineEnvironment.transform 3 3 env30223 = env30224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env30223 == env30224) = true)

theorem identity30224 : scanCanonicalize (H12AffineFastState.compose env30224 (packedSelected [0,2,6] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound30224 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env30225 : List Nat := [2,4,8,3,32,3,9,37,43,39,32,15,37,12,0,34,14,44,38,1,0,32,2,3,36,2,44,3,3,45,6,33,36,44,13,39]

theorem envBound30225 : H12AffineFastState.Bounded env30225 := by
  intro p hp
  have h : env30225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30224_30225 : H12AffineEnvironment.transform 8 43 env30224 = env30225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env30224 == env30225) = true)

theorem identity30225 : scanCanonicalize (H12AffineFastState.compose env30225 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30225 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env30226 : List Nat := [2,4,8,3,12,3,9,9,7,11,12,15,9,12,0,14,14,0,10,1,0,12,2,3,8,2,0,3,3,1,6,13,8,0,13,11]

theorem envBound30226 : H12AffineFastState.Bounded env30226 := by
  intro p hp
  have h : env30226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30225_30226 : H12AffineEnvironment.transform 4 12 env30225 = env30226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30225 == env30226) = true)

theorem identity30226 : scanCanonicalize (H12AffineFastState.compose env30226 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30227 : List Nat := [2,4,4,3,0,3,5,5,7,7,0,3,5,0,0,2,2,0,6,1,0,0,2,3,4,2,0,3,3,1,6,1,4,0,1,7]

theorem envBound30227 : H12AffineFastState.Bounded env30227 := by
  intro p hp
  have h : env30227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30226_30227 : H12AffineEnvironment.transform 2 4 env30226 = env30227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30226 == env30227) = true)

theorem identity30227 : scanCanonicalize (H12AffineFastState.compose env30227 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30228 : List Nat := [2,0,0,3,0,3,1,1,3,3,0,3,1,0,0,2,2,0,2,1,0,0,2,3,0,2,0,3,3,1,2,1,0,0,1,3]

theorem envBound30228 : H12AffineFastState.Bounded env30228 := by
  intro p hp
  have h : env30228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30227_30228 : H12AffineEnvironment.transform 1 0 env30227 = env30228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30227 == env30228) = true)

theorem identity30228 : scanCanonicalize (H12AffineFastState.compose env30228 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30229 : List Nat := [0,0,0,1,0,1,1,1,1,1,0,1,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1]

theorem envBound30229 : H12AffineFastState.Bounded env30229 := by
  intro p hp
  have h : env30229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30228_30229 : H12AffineEnvironment.transform 0 0 env30228 = env30229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30228 == env30229) = true)

def env30230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98780,8328,65,12729588,79130,8480026,8568104,8390093,4314199,257,8484155,8492191,8462875]

theorem envBound30230 : H12AffineFastState.Bounded env30230 := by
  intro p hp
  have h : env30230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30187_30230 : H12AffineEnvironment.transform 17 32041 env30187 = env30230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env30187 == env30230) = true)

def env30231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98780,8328,65,4340964,79130,91402,179512,1501,4314199,257,95531,103567,74251]

theorem envBound30231 : H12AffineFastState.Bounded env30231 := by
  intro p hp
  have h : env30231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30231 : H12AffineEnvironment.transform 22 16 env30230 = env30231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env30230 == env30231) = true)

theorem identity30231 : scanCanonicalize (H12AffineFastState.compose env30231 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95651) := by decide +kernel

theorem selectedBound30231 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,95651,16,98780,8328,65,215367,79130,91402,179512,1501,41460,257,95531,103567,74251]

theorem envBound30232 : H12AffineFastState.Bounded env30232 := by
  intro p hp
  have h : env30232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30231_30232 : H12AffineEnvironment.transform 21 95651 env30231 = env30232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95651 env30231 == env30232) = true)

def env30233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,95531,16,98644,8192,65,215367,79130,91402,179512,1365,41340,257,95531,103431,74251]

theorem envBound30233 : H12AffineFastState.Bounded env30233 := by
  intro p hp
  have h : env30233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30232_30233 : H12AffineEnvironment.transform 6 8 env30232 = env30233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30232 == env30233) = true)

theorem identity30233 : scanCanonicalize (H12AffineFastState.compose env30233 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound30233 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32041,1025,32769,17729,32,16,62559,8192,65,146508,16401,4097,179512,1365,41340,257,32,57612,22272]

theorem envBound30234 : H12AffineFastState.Bounded env30234 := by
  intro p hp
  have h : env30234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30233_30234 : H12AffineEnvironment.transform 15 29963 env30233 = env30234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env30233 == env30234) = true)

theorem identity30234 : scanCanonicalize (H12AffineFastState.compose env30234 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30234 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,131072,10280,1025,32769,4160,32,16,41310,8192,65,146508,5392,4097,179512,1365,41340,257,32,46093,513]

theorem envBound30235 : H12AffineFastState.Bounded env30235 := by
  intro p hp
  have h : env30235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30234_30235 : H12AffineEnvironment.transform 13 5377 env30234 = env30235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30234 == env30235) = true)

theorem identity30235 : scanCanonicalize (H12AffineFastState.compose env30235 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30235 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,263,131072,2341,1025,32769,4160,32,16,32851,269,65,138561,5392,4097,171061,1365,32881,257,32,38144,513]

theorem envBound30236 : H12AffineFastState.Bounded env30236 := by
  intro p hp
  have h : env30236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30235_30236 : H12AffineEnvironment.transform 12 269 env30235 = env30236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30235 == env30236) = true)

theorem identity30236 : scanCanonicalize (H12AffineFastState.compose env30236 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound30236 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env30237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,263,5441,2341,1025,32769,4160,32,16,32851,269,65,2048,5392,4097,35188,1365,32881,257,32,38144,513]

theorem envBound30237 : H12AffineFastState.Bounded env30237 := by
  intro p hp
  have h : env30237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30236_30237 : H12AffineEnvironment.transform 16 5441 env30236 = env30237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env30236 == env30237) = true)

def env30238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,95530,16,98645,8193,65,215367,79130,91402,179512,1364,41341,257,95531,103430,74251]

theorem envBound30238 : H12AffineFastState.Bounded env30238 := by
  intro p hp
  have h : env30238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30232_30238 : H12AffineEnvironment.transform 6 9 env30232 = env30238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30232 == env30238) = true)

theorem identity30238 : scanCanonicalize (H12AffineFastState.compose env30238 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound30238 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58397,41341,16,21762,8193,65,171280,57677,45405,179512,1364,41341,257,41340,16465,63068]

theorem envBound30239 : H12AffineFastState.Bounded env30239 := by
  intro p hp
  have h : env30239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30238_30239 : H12AffineEnvironment.transform 15 54359 env30238 = env30239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env30238 == env30239) = true)

theorem identity30239 : scanCanonicalize (H12AffineFastState.compose env30239 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30239 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env30240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4160,21792,16,21762,8193,65,158029,5392,17664,149861,1364,21792,257,21793,16465,513]

theorem envBound30240 : H12AffineFastState.Bounded env30240 := by
  intro p hp
  have h : env30240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30239_30240 : H12AffineEnvironment.transform 14 29789 env30239 = env30240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30239 == env30240) = true)

theorem identity30240 : scanCanonicalize (H12AffineFastState.compose env30240 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound30240 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,16384,20544,1047,131072,22836,1025,20545,4160,21792,16,21762,1052,65,150864,5392,17664,149861,1364,21792,257,21793,16465,513]

theorem envBound30241 : H12AffineFastState.Bounded env30241 := by
  intro p hp
  have h : env30241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30240_30241 : H12AffineEnvironment.transform 12 1053 env30240 = env30241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env30240 == env30241) = true)

theorem identity30241 : scanCanonicalize (H12AffineFastState.compose env30241 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30241 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,16384,20544,1047,16400,22836,1025,20545,4160,21792,16,21762,1052,65,3392,5392,17664,2421,1364,21792,257,21793,16465,513]

theorem envBound30242 : H12AffineFastState.Bounded env30242 := by
  intro p hp
  have h : env30242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30241_30242 : H12AffineEnvironment.transform 16 16400 env30241 = env30242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30241 == env30242) = true)

theorem identity30242 : scanCanonicalize (H12AffineFastState.compose env30242 (packedSelected [0,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 7284) := by decide +kernel

theorem selectedBound30242 : packedSelected [0,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env30243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,7284,3124,1047,7268,1344,1025,3125,4160,2388,16,2422,1052,65,3392,5392,6516,2421,1364,2388,257,2389,7205,513]

theorem envBound30243 : H12AffineFastState.Bounded env30243 := by
  intro p hp
  have h : env30243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30242_30243 : H12AffineEnvironment.transform 13 7284 env30242 = env30243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7284 env30242 == env30243) = true)

theorem identity30243 : scanCanonicalize (H12AffineFastState.compose env30243 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound30243 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env30244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,1053,81,3124,1047,65,1344,1025,3125,3173,2388,16,2422,1052,65,3392,2357,1361,2421,1364,2388,257,2389,0,513]

theorem envBound30244 : H12AffineFastState.Bounded env30244 := by
  intro p hp
  have h : env30244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30243_30244 : H12AffineEnvironment.transform 11 3109 env30243 = env30244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env30243 == env30244) = true)

theorem identity30244 : scanCanonicalize (H12AffineFastState.compose env30244 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound30244 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env30245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,1280,1053,81,1297,1047,65,1344,1025,1296,1344,113,16,83,1052,65,1125,16,1361,80,1364,113,257,112,0,513]

theorem envBound30245 : H12AffineFastState.Bounded env30245 := by
  intro p hp
  have h : env30245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30244_30245 : H12AffineEnvironment.transform 10 293 env30244 = env30245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env30244 == env30245) = true)

theorem identity30245 : scanCanonicalize (H12AffineFastState.compose env30245 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30245 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30246 : List Nat := [2,4,8,16,32,64,9,116,512,1024,81,1140,1053,81,1125,1047,65,1076,1025,1124,1076,113,16,83,1052,65,1125,16,1061,80,1056,113,117,112,0,513]

theorem envBound30246 : H12AffineFastState.Bounded env30246 := by
  intro p hp
  have h : env30246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30245_30246 : H12AffineEnvironment.transform 7 116 env30245 = env30246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30245 == env30246) = true)

theorem identity30246 : scanCanonicalize (H12AffineFastState.compose env30246 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30246 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30247 : List Nat := [2,4,8,16,32,64,9,116,512,53,81,65,40,81,80,34,65,1,52,81,1,113,16,83,41,65,80,16,16,80,21,113,117,112,0,513]

theorem envBound30247 : H12AffineFastState.Bounded env30247 := by
  intro p hp
  have h : env30247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30246_30247 : H12AffineEnvironment.transform 9 53 env30246 = env30247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30246 == env30247) = true)

theorem identity30247 : scanCanonicalize (H12AffineFastState.compose env30247 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30248 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,1,0,34,17,1,52,1,1,33,16,3,41,17,0,16,16,0,21,33,37,32,0,513]

theorem envBound30248 : H12AffineFastState.Bounded env30248 := by
  intro p hp
  have h : env30248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30247_30248 : H12AffineEnvironment.transform 5 16 env30247 = env30248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30247 == env30248) = true)

theorem identity30248 : scanCanonicalize (H12AffineFastState.compose env30248 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound30248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30249 : List Nat := [2,4,8,16,32,16,9,36,10,53,1,17,40,1,0,34,17,1,52,1,1,33,16,3,41,17,0,16,16,0,21,33,37,32,0,11]

theorem envBound30249 : H12AffineFastState.Bounded env30249 := by
  intro p hp
  have h : env30249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30248_30249 : H12AffineEnvironment.transform 8 10 env30248 = env30249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env30248 == env30249) = true)

def env30250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98780,8328,65,4340965,79130,91403,179513,1500,4314199,257,95530,103566,74250]

theorem envBound30250 : H12AffineFastState.Bounded env30250 := by
  intro p hp
  have h : env30250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30250 : H12AffineEnvironment.transform 22 17 env30230 = env30250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env30230 == env30250) = true)

theorem identity30250 : scanCanonicalize (H12AffineFastState.compose env30250 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30250 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41431,8328,65,4340965,5393,17664,179513,1500,4256860,257,21793,46213,513]

theorem envBound30251 : H12AffineFastState.Bounded env30251 := by
  intro p hp
  have h : env30251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30250_30251 : H12AffineEnvironment.transform 15 8203 env30250 = env30251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30250 == env30251) = true)

theorem identity30251 : scanCanonicalize (H12AffineFastState.compose env30251 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41381) := by decide +kernel

theorem selectedBound30251 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41381,17,41431,8328,65,171328,5393,17664,179513,1500,22009,257,21793,46213,513]

theorem envBound30252 : H12AffineFastState.Bounded env30252 := by
  intro p hp
  have h : env30252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30251_30252 : H12AffineEnvironment.transform 21 41381 env30251 = env30252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41381 env30251 == env30252) = true)

def env30253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41261,17,41311,8192,65,171328,5393,17664,179513,1364,21873,257,21793,46093,513]

theorem envBound30253 : H12AffineFastState.Bounded env30253 := by
  intro p hp
  have h : env30253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30252_30253 : H12AffineEnvironment.transform 6 8 env30252 = env30253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30252 == env30253) = true)

theorem identity30253 : scanCanonicalize (H12AffineFastState.compose env30253 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30253 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env30254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,21873,17,21763,8192,65,157980,5393,17664,149861,1364,21873,257,21793,16465,513]

theorem envBound30254 : H12AffineFastState.Bounded env30254 := by
  intro p hp
  have h : env30254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30253_30254 : H12AffineEnvironment.transform 14 29788 env30253 = env30254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30253 == env30254) = true)

theorem identity30254 : scanCanonicalize (H12AffineFastState.compose env30254 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30254 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,32041,1025,29789,4161,21873,17,21763,8192,65,10508,5393,17664,2421,1364,21873,257,21793,16465,513]

theorem envBound30255 : H12AffineFastState.Bounded env30255 := by
  intro p hp
  have h : env30255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30254_30255 : H12AffineEnvironment.transform 16 16400 env30254 = env30255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30254 == env30255) = true)

theorem identity30255 : scanCanonicalize (H12AffineFastState.compose env30255 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30255 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10280,1025,8540,4161,112,17,2,8192,65,10508,5393,4097,2421,1364,112,257,32,5456,513]

theorem envBound30256 : H12AffineFastState.Bounded env30256 := by
  intro p hp
  have h : env30256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30255_30256 : H12AffineEnvironment.transform 13 5377 env30255 = env30256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30255 == env30256) = true)

theorem identity30256 : scanCanonicalize (H12AffineFastState.compose env30256 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30257 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,5393,10280,1025,8461,4112,33,17,2,8192,16,10508,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound30257 : H12AffineFastState.Bounded env30257 := by
  intro p hp
  have h : env30257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30256_30257 : H12AffineEnvironment.transform 5 17 env30256 = env30257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30256 == env30257) = true)

theorem identity30257 : scanCanonicalize (H12AffineFastState.compose env30257 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30258 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,8192,308,8460,8203,292,10280,1025,8461,1061,33,17,2,8192,16,10508,292,1076,2340,1285,33,257,32,308,513]

theorem envBound30258 : H12AffineFastState.Bounded env30258 := by
  intro p hp
  have h : env30258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30257_30258 : H12AffineEnvironment.transform 11 1077 env30257 = env30258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env30257 == env30258) = true)

theorem identity30258 : scanCanonicalize (H12AffineFastState.compose env30258 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound30258 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30259 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,2083,308,2351,2088,292,11,1025,2350,1061,33,17,2,2083,16,303,292,1076,2340,1285,33,257,32,308,513]

theorem envBound30259 : H12AffineFastState.Bounded env30259 := by
  intro p hp
  have h : env30259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30258_30259 : H12AffineEnvironment.transform 12 2083 env30258 = env30259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env30258 == env30259) = true)

theorem identity30259 : scanCanonicalize (H12AffineFastState.compose env30259 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound30259 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30260 : List Nat := [2,4,8,16,32,17,8,256,512,1024,302,1077,269,308,1,262,292,11,1025,0,1061,33,17,2,269,16,303,292,1076,10,1285,33,257,32,308,513]

theorem envBound30260 : H12AffineFastState.Bounded env30260 := by
  intro p hp
  have h : env30260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30259_30260 : H12AffineEnvironment.transform 10 302 env30259 = env30260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env30259 == env30260) = true)

theorem identity30260 : scanCanonicalize (H12AffineFastState.compose env30260 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30261 : List Nat := [2,4,8,16,32,17,8,256,512,273,302,292,269,308,1,262,292,11,272,0,308,33,17,2,269,16,303,292,293,10,20,33,257,32,308,513]

theorem envBound30261 : H12AffineFastState.Bounded env30261 := by
  intro p hp
  have h : env30261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30260_30261 : H12AffineEnvironment.transform 9 273 env30260 = env30261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30260 == env30261) = true)

theorem identity30261 : scanCanonicalize (H12AffineFastState.compose env30261 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound30261 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30262 : List Nat := [2,4,8,16,26,17,8,256,512,273,276,286,269,270,1,262,286,11,272,0,270,27,17,2,269,16,277,286,287,10,20,27,257,26,270,513]

theorem envBound30262 : H12AffineFastState.Bounded env30262 := by
  intro p hp
  have h : env30262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30261_30262 : H12AffineEnvironment.transform 4 26 env30261 = env30262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env30261 == env30262) = true)

def env30263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,41260,17,41310,8193,65,171328,5393,17664,179513,1365,21872,257,21793,46092,513]

theorem envBound30263 : H12AffineFastState.Bounded env30263 := by
  intro p hp
  have h : env30263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30252_30263 : H12AffineEnvironment.transform 6 9 env30252 = env30263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30252 == env30263) = true)

theorem identity30263 : scanCanonicalize (H12AffineFastState.compose env30263 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30263 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32041,1025,8540,4161,113,17,3,8193,65,146461,5393,17664,138340,1365,21872,257,21793,5457,513]

theorem envBound30264 : H12AffineFastState.Bounded env30264 := by
  intro p hp
  have h : env30264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30263_30264 : H12AffineEnvironment.transform 14 8541 env30263 = env30264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30263 == env30264) = true)

theorem identity30264 : scanCanonicalize (H12AffineFastState.compose env30264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,32041,1025,8540,4161,113,17,3,8193,65,31756,5393,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound30265 : H12AffineFastState.Bounded env30265 := by
  intro p hp
  have h : env30265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30264_30265 : H12AffineEnvironment.transform 16 16401 env30264 = env30265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30264 == env30265) = true)

theorem identity30265 : scanCanonicalize (H12AffineFastState.compose env30265 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30265 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,293,115,16401,23889,1025,292,4161,113,17,3,121,65,23668,5393,17664,23669,1365,21872,257,21793,5457,513]

theorem envBound30266 : H12AffineFastState.Bounded env30266 := by
  intro p hp
  have h : env30266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30265_30266 : H12AffineEnvironment.transform 12 120 env30265 = env30266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30265 == env30266) = true)

theorem identity30266 : scanCanonicalize (H12AffineFastState.compose env30266 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30266 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30267 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,120,16384,293,115,16401,22592,272,292,4161,113,17,3,121,65,22885,4096,16401,22884,68,20577,257,20528,4160,513]

theorem envBound30267 : H12AffineFastState.Bounded env30267 := by
  intro p hp
  have h : env30267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30266_30267 : H12AffineEnvironment.transform 9 273 env30266 = env30267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30266 == env30267) = true)

theorem identity30267 : scanCanonicalize (H12AffineFastState.compose env30267 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound30267 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env30268 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,120,4453,293,115,4468,2341,272,292,4161,113,17,3,121,65,2048,4096,4468,2049,68,260,257,341,4160,513]

theorem envBound30268 : H12AffineFastState.Bounded env30268 := by
  intro p hp
  have h : env30268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30267_30268 : H12AffineEnvironment.transform 13 4453 env30267 = env30268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env30267 == env30268) = true)

theorem identity30268 : scanCanonicalize (H12AffineFastState.compose env30268 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30268 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env30269 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,40,4405,293,35,4388,2341,272,292,4113,33,17,3,41,17,2048,4096,4388,2049,20,260,257,261,4112,513]

theorem envBound30269 : H12AffineFastState.Bounded env30269 := by
  intro p hp
  have h : env30269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30268_30269 : H12AffineEnvironment.transform 5 16 env30268 = env30269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30268 == env30269) = true)

theorem identity30269 : scanCanonicalize (H12AffineFastState.compose env30269 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound30269 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30270 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2325,40,2080,293,35,2097,2341,272,292,2308,33,17,3,41,17,2048,2325,2097,2049,20,260,257,261,2309,513]

theorem envBound30270 : H12AffineFastState.Bounded env30270 := by
  intro p hp
  have h : env30270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30269_30270 : H12AffineEnvironment.transform 11 2325 env30269 = env30270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env30269 == env30270) = true)

theorem identity30270 : scanCanonicalize (H12AffineFastState.compose env30270 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30270 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30271 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2096,40,2080,0,35,2097,2048,53,1,2081,33,17,3,41,17,2048,2096,2097,2049,20,33,36,32,2080,513]

theorem envBound30271 : H12AffineFastState.Bounded env30271 := by
  intro p hp
  have h : env30271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30270_30271 : H12AffineEnvironment.transform 7 37 env30270 = env30271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30270 == env30271) = true)

theorem identity30271 : scanCanonicalize (H12AffineFastState.compose env30271 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30272 : List Nat := [2,4,8,16,32,16,9,37,17,52,2048,2096,40,2080,0,35,2097,2048,53,1,2081,33,17,3,41,17,2048,2096,2097,2049,20,33,36,32,2080,16]

theorem envBound30272 : H12AffineFastState.Bounded env30272 := by
  intro p hp
  have h : env30272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30271_30272 : H12AffineEnvironment.transform 8 17 env30271 = env30272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30271 == env30272) = true)

theorem identity30272 : scanCanonicalize (H12AffineFastState.compose env30272 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound30272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30273 : List Nat := [2,4,8,16,32,16,9,37,17,52,26,42,40,58,0,35,43,26,53,1,59,33,17,3,41,17,26,42,43,27,20,33,36,32,58,16]

theorem envBound30273 : H12AffineFastState.Bounded env30273 := by
  intro p hp
  have h : env30273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30272_30273 : H12AffineEnvironment.transform 10 26 env30272 = env30273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env30272 == env30273) = true)

theorem identity30273 : scanCanonicalize (H12AffineFastState.compose env30273 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30273 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30274 : List Nat := [2,4,8,16,1,16,9,4,17,21,26,11,9,27,0,2,10,26,20,1,26,0,17,3,8,17,26,11,10,27,20,0,5,1,27,16]

theorem envBound30274 : H12AffineFastState.Bounded env30274 := by
  intro p hp
  have h : env30274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30273_30274 : H12AffineEnvironment.transform 4 1 env30273 = env30274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30273 == env30274) = true)

theorem identity30274 : scanCanonicalize (H12AffineFastState.compose env30274 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30274 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30275 : List Nat := [2,4,8,11,1,11,9,4,10,14,1,11,9,0,0,2,10,1,15,1,1,0,10,3,8,10,1,11,10,0,15,0,5,1,0,11]

theorem envBound30275 : H12AffineFastState.Bounded env30275 := by
  intro p hp
  have h : env30275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30274_30275 : H12AffineEnvironment.transform 3 11 env30274 = env30275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30274 == env30275) = true)

theorem identity30275 : scanCanonicalize (H12AffineFastState.compose env30275 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30275 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30276 : List Nat := [2,4,3,0,1,0,2,4,1,5,1,0,2,0,0,2,1,1,4,1,1,0,1,3,3,1,1,0,1,0,4,0,5,1,0,0]

theorem envBound30276 : H12AffineFastState.Bounded env30276 := by
  intro p hp
  have h : env30276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30275_30276 : H12AffineEnvironment.transform 2 3 env30275 = env30276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30275 == env30276) = true)

def env30277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound30277 : H12AffineFastState.Bounded env30277 := by
  intro p hp
  have h : env30277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29895_30277 : H12AffineEnvironment.transform 26 30393345 env29895 = env30277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env29895 == env30277) = true)

def env30278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound30278 : H12AffineFastState.Bounded env30278 := by
  intro p hp
  have h : env30278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30277_30278 : H12AffineEnvironment.transform 18 1024 env30277 = env30278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env30277 == env30278) = true)

theorem identity30278 : scanCanonicalize (H12AffineFastState.compose env30278 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 509987) := by decide +kernel

theorem selectedBound30278 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,509987,16777216,8328,65,20973602,18973837,2596211,67618,17189938,23160256,256,19270798,19328298,17263589]

theorem envBound30279 : H12AffineFastState.Bounded env30279 := by
  intro p hp
  have h : env30279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30278_30279 : H12AffineEnvironment.transform 22 509987 env30278 = env30279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 509987 env30278 == env30279) = true)

def env30280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,16777216,8328,65,16959642,18973837,2596211,67618,17189938,19113336,256,19270798,19328298,17263589]

theorem envBound30280 : H12AffineFastState.Bounded env30280 := by
  intro p hp
  have h : env30280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30279_30280 : H12AffineEnvironment.transform 21 180408 env30279 = env30280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env30279 == env30280) = true)

def env30281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,498992,8328,65,349610,2496957,2596211,67618,119042,2373704,256,2199998,2191386,63189]

theorem envBound30281 : H12AffineFastState.Bounded env30281 := by
  intro p hp
  have h : env30281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30280_30281 : H12AffineEnvironment.transform 23 498992 env30280 = env30281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env30280 == env30281) = true)

def env30282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509987,498992,8328,65,349610,395773,494899,67618,119042,272392,256,98814,90202,63189]

theorem envBound30282 : H12AffineFastState.Bounded env30282 := by
  intro p hp
  have h : env30282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30281_30282 : H12AffineEnvironment.transform 20 4160 env30281 = env30282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30281 == env30282) = true)

def env30283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,180408,254083,243088,8328,65,97546,139613,238995,67618,119042,168,256,98814,90202,63189]

theorem envBound30283 : H12AffineFastState.Bounded env30283 := by
  intro p hp
  have h : env30283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30282_30283 : H12AffineEnvironment.transform 17 10400 env30282 = env30283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30282 == env30283) = true)

def env30284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180272,253963,242968,8192,65,97546,139613,238875,67618,119042,32,256,98678,90202,63069]

theorem envBound30284 : H12AffineFastState.Bounded env30284 := by
  intro p hp
  have h : env30284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30283_30284 : H12AffineEnvironment.transform 6 8 env30283 = env30284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30283 == env30284) = true)

theorem identity30284 : scanCanonicalize (H12AffineFastState.compose env30284 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30284 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,4160,144492,201815,213316,8192,65,97546,139613,217415,67618,75102,32,256,95530,90202,513]

theorem envBound30285 : H12AffineFastState.Bounded env30285 := by
  intro p hp
  have h : env30285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30284_30285 : H12AffineEnvironment.transform 14 29788 env30284 = env30285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30284 == env30285) = true)

theorem identity30285 : scanCanonicalize (H12AffineFastState.compose env30285 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound30285 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env30286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29963,131072,10280,1024,29789,4160,144492,155996,144463,8192,65,2049,139613,140364,32041,20565,32,256,33,5457,513]

theorem envBound30286 : H12AffineFastState.Bounded env30286 := by
  intro p hp
  have h : env30286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30285_30286 : H12AffineEnvironment.transform 15 29963 env30285 = env30286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env30285 == env30286) = true)

theorem identity30286 : scanCanonicalize (H12AffineFastState.compose env30286 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30286 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,131072,2421,1024,21760,4160,136497,147457,136466,349,65,2049,131072,132369,23668,20565,32,256,33,5457,513]

theorem envBound30287 : H12AffineFastState.Bounded env30287 := by
  intro p hp
  have h : env30287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30286_30287 : H12AffineEnvironment.transform 12 349 env30286 = env30287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30286 == env30287) = true)

theorem identity30287 : scanCanonicalize (H12AffineFastState.compose env30287 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30287 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,131072,2421,1024,1,4160,136497,136448,136466,349,65,2049,131072,132369,2421,1364,32,256,33,5457,513]

theorem envBound30288 : H12AffineFastState.Bounded env30288 := by
  intro p hp
  have h : env30288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30287_30288 : H12AffineEnvironment.transform 13 5377 env30287 = env30288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30287 == env30288) = true)

theorem identity30288 : scanCanonicalize (H12AffineFastState.compose env30288 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound30288 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5392,2421,1024,1,4160,33,16,2,349,65,2049,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound30289 : H12AffineFastState.Bounded env30289 := by
  intro p hp
  have h : env30289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30288_30289 : H12AffineEnvironment.transform 16 5392 env30288 = env30289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env30288 == env30289) = true)

theorem identity30289 : scanCanonicalize (H12AffineFastState.compose env30289 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound30289 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3419,349,2138,0,343,2123,2421,1024,1,3355,33,16,2,349,65,2049,2123,3418,2421,1364,32,256,33,2058,513]

theorem envBound30290 : H12AffineFastState.Bounded env30290 := by
  intro p hp
  have h : env30290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30289_30290 : H12AffineEnvironment.transform 11 3419 env30289 = env30290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env30289 == env30290) = true)

theorem identity30290 : scanCanonicalize (H12AffineFastState.compose env30290 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound30290 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30291 : List Nat := [2,4,8,16,32,10,8,256,512,1024,2048,3345,279,2064,0,285,2049,2367,1024,1,3355,33,16,2,279,11,2049,2049,3344,2367,1310,32,256,33,2058,513]

theorem envBound30291 : H12AffineFastState.Bounded env30291 := by
  intro p hp
  have h : env30291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30290_30291 : H12AffineEnvironment.transform 5 10 env30290 = env30291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env30290 == env30291) = true)

theorem identity30291 : scanCanonicalize (H12AffineFastState.compose env30291 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30291 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30292 : List Nat := [2,4,8,16,0,10,8,256,512,1024,2048,3345,279,2064,0,285,2049,2335,1024,1,3355,1,16,2,279,11,2049,2049,3344,2335,1310,0,256,1,2058,513]

theorem envBound30292 : H12AffineFastState.Bounded env30292 := by
  intro p hp
  have h : env30292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30291_30292 : H12AffineEnvironment.transform 4 0 env30291 = env30292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30291 == env30292) = true)

theorem identity30292 : scanCanonicalize (H12AffineFastState.compose env30292 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30292 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env30293 : List Nat := [2,4,8,11,0,10,8,256,512,1024,2048,3338,268,2059,0,262,2049,2308,1024,1,3328,1,11,2,268,11,2049,2049,3339,2308,1285,0,256,1,2058,513]

theorem envBound30293 : H12AffineFastState.Bounded env30293 := by
  intro p hp
  have h : env30293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30292_30293 : H12AffineEnvironment.transform 3 11 env30292 = env30293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30292 == env30293) = true)

theorem identity30293 : scanCanonicalize (H12AffineFastState.compose env30293 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound30293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30294 : List Nat := [2,4,8,11,0,10,8,15,512,1024,2048,3077,3,2059,0,9,2049,2059,1024,1,3087,1,11,2,3,11,2049,2049,3076,2059,1034,0,15,1,2058,513]

theorem envBound30294 : H12AffineFastState.Bounded env30294 := by
  intro p hp
  have h : env30294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30293_30294 : H12AffineEnvironment.transform 7 15 env30293 = env30294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env30293 == env30294) = true)

theorem identity30294 : scanCanonicalize (H12AffineFastState.compose env30294 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound30294 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30295 : List Nat := [2,4,8,11,0,10,8,15,10,1024,2048,3077,3,2059,0,9,2049,2059,1024,1,3087,1,11,2,3,11,2049,2049,3076,2059,1034,0,15,1,2058,11]

theorem envBound30295 : H12AffineFastState.Bounded env30295 := by
  intro p hp
  have h : env30295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30294_30295 : H12AffineEnvironment.transform 8 10 env30294 = env30295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env30294 == env30295) = true)

theorem identity30295 : scanCanonicalize (H12AffineFastState.compose env30295 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1037) := by decide +kernel

theorem selectedBound30295 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30296 : List Nat := [2,4,8,11,0,10,8,15,10,1024,1037,8,3,1030,0,9,1036,1030,1024,1,2,1,11,2,3,11,1036,1036,9,1030,1034,0,15,1,1031,11]

theorem envBound30296 : H12AffineFastState.Bounded env30296 := by
  intro p hp
  have h : env30296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30295_30296 : H12AffineEnvironment.transform 10 1037 env30295 = env30296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1037 env30295 == env30296) = true)

theorem identity30296 : scanCanonicalize (H12AffineFastState.compose env30296 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30296 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30297 : List Nat := [0,4,8,9,0,8,8,13,8,1024,1037,8,1,1028,0,9,1036,1028,1024,1,0,1,9,0,1,9,1036,1036,9,1028,1032,0,13,1,1029,9]

theorem envBound30297 : H12AffineFastState.Bounded env30297 := by
  intro p hp
  have h : env30297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30296_30297 : H12AffineEnvironment.transform 0 0 env30296 = env30297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30296 == env30297) = true)

theorem identity30297 : scanCanonicalize (H12AffineFastState.compose env30297 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30298 : List Nat := [0,1,8,9,0,8,8,8,8,1024,1032,8,1,1025,0,9,1033,1025,1024,1,0,1,9,0,1,9,1033,1033,9,1025,1032,0,8,1,1024,9]

theorem envBound30298 : H12AffineFastState.Bounded env30298 := by
  intro p hp
  have h : env30298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30297_30298 : H12AffineEnvironment.transform 1 1 env30297 = env30298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30297 == env30298) = true)

theorem identity30298 : scanCanonicalize (H12AffineFastState.compose env30298 (packedSelected [8] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound30298 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env30299 : List Nat := [0,1,8,9,0,8,8,8,8,1,9,8,1,0,0,9,8,0,1,1,0,1,9,0,1,9,8,8,9,0,9,0,8,1,1,9]

theorem envBound30299 : H12AffineFastState.Bounded env30299 := by
  intro p hp
  have h : env30299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30298_30299 : H12AffineEnvironment.transform 9 1 env30298 = env30299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env30298 == env30299) = true)

def env30300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180273,253962,242969,8193,65,97546,139613,238874,67618,119042,33,256,98679,90202,63068]

theorem envBound30300 : H12AffineFastState.Bounded env30300 := by
  intro p hp
  have h : env30300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30283_30300 : H12AffineEnvironment.transform 6 9 env30283 = env30300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30283 == env30300) = true)

theorem identity30300 : scanCanonicalize (H12AffineFastState.compose env30300 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30300 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,4160,169264,242955,242969,8193,65,75787,139613,238874,67618,99331,33,256,98679,79195,41821]

theorem envBound30301 : H12AffineFastState.Bounded env30301 := by
  intro p hp
  have h : env30301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30300_30301 : H12AffineEnvironment.transform 13 5377 env30300 = env30301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30300 == env30301) = true)

theorem identity30301 : scanCanonicalize (H12AffineFastState.compose env30301 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 69974) := by decide +kernel

theorem selectedBound30301 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env30302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,69974,10281,1024,32769,4160,99430,42077,42063,8193,65,75787,77835,46156,67618,99331,33,256,98679,79195,41821]

theorem envBound30302 : H12AffineFastState.Bounded env30302 := by
  intro p hp
  have h : env30302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30301_30302 : H12AffineEnvironment.transform 16 69974 env30301 = env30302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69974 env30301 == env30302) = true)

theorem identity30302 : scanCanonicalize (H12AffineFastState.compose env30302 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30302 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env30303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,69974,10281,1024,8541,4160,75066,1281,1299,8193,65,75787,77835,5392,67618,75103,33,256,73771,79195,513]

theorem envBound30303 : H12AffineFastState.Bounded env30303 := by
  intro p hp
  have h : env30303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30302_30303 : H12AffineEnvironment.transform 14 8540 env30302 = env30303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30302 == env30303) = true)

theorem identity30303 : scanCanonicalize (H12AffineFastState.compose env30303 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 6194) := by decide +kernel

theorem selectedBound30303 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env30304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,6194,2404,10281,1024,8541,4160,15624,1281,1299,8193,65,12345,10297,5392,4112,15725,33,256,14361,11625,513]

theorem envBound30304 : H12AffineFastState.Bounded env30304 := by
  intro p hp
  have h : env30304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30303_30304 : H12AffineEnvironment.transform 15 6194 env30303 = env30304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6194 env30303 == env30304) = true)

theorem identity30304 : scanCanonicalize (H12AffineFastState.compose env30304 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound30304 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,5377,6500,6194,2404,4113,1024,6501,4160,1328,1281,1299,6201,65,2049,4097,5392,4112,1365,33,256,33,5457,513]

theorem envBound30305 : H12AffineFastState.Bounded env30305 := by
  intro p hp
  have h : env30305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30304_30305 : H12AffineEnvironment.transform 12 6200 env30304 = env30305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env30304 == env30305) = true)

theorem identity30305 : scanCanonicalize (H12AffineFastState.compose env30305 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound30305 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env30306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,5496,5377,5156,5490,1060,4113,1024,5157,4160,1328,1281,1299,5497,65,1345,4097,5392,4112,1365,33,256,33,5457,513]

theorem envBound30306 : H12AffineFastState.Bounded env30306 := by
  intro p hp
  have h : env30306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30305_30306 : H12AffineEnvironment.transform 10 1344 env30305 = env30306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env30305 == env30306) = true)

theorem identity30306 : scanCanonicalize (H12AffineFastState.compose env30306 (packedSelected [2,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30306 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env30307 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,4096,5132,5237,5156,5126,1060,4113,1024,5157,4160,1092,1141,1127,5133,65,1077,4097,5220,4112,1057,33,116,33,5157,513]

theorem envBound30307 : H12AffineFastState.Bounded env30307 := by
  intro p hp
  have h : env30307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30306_30307 : H12AffineEnvironment.transform 7 116 env30306 = env30307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30306 == env30307) = true)

theorem identity30307 : scanCanonicalize (H12AffineFastState.compose env30307 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound30307 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env30308 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,1140,120,1,80,114,1060,1125,1024,81,1076,1092,1141,1127,121,65,1077,1141,16,1124,1057,33,116,33,81,513]

theorem envBound30308 : H12AffineFastState.Bounded env30308 := by
  intro p hp
  have h : env30308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30307_30308 : H12AffineEnvironment.transform 11 1140 env30307 = env30308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env30307 == env30308) = true)

theorem identity30308 : scanCanonicalize (H12AffineFastState.compose env30308 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30308 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30309 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,1061,41,1,1,35,1060,1076,1024,0,1076,1045,1060,1078,40,16,1077,1060,16,1077,1057,33,37,33,0,513]

theorem envBound30309 : H12AffineFastState.Bounded env30309 := by
  intro p hp
  have h : env30309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30308_30309 : H12AffineEnvironment.transform 5 17 env30308 = env30309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30308 == env30309) = true)

theorem identity30309 : scanCanonicalize (H12AffineFastState.compose env30309 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound30309 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30310 : List Nat := [2,4,8,16,32,17,9,37,512,37,17,0,41,1,1,35,1,17,37,0,17,48,1,19,40,16,16,1,16,16,4,33,37,33,0,513]

theorem envBound30310 : H12AffineFastState.Bounded env30310 := by
  intro p hp
  have h : env30310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30309_30310 : H12AffineEnvironment.transform 9 37 env30309 = env30310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env30309 == env30310) = true)

theorem identity30310 : scanCanonicalize (H12AffineFastState.compose env30310 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30310 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env30311 : List Nat := [2,4,8,1,32,0,9,37,512,37,0,0,41,1,1,35,1,0,37,0,0,33,1,2,40,1,1,1,1,1,4,33,37,33,0,513]

theorem envBound30311 : H12AffineFastState.Bounded env30311 := by
  intro p hp
  have h : env30311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30310_30311 : H12AffineEnvironment.transform 3 1 env30310 = env30311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30310 == env30311) = true)

theorem identity30311 : scanCanonicalize (H12AffineFastState.compose env30311 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30312 : List Nat := [2,1,8,1,32,0,9,32,512,32,0,0,41,1,1,35,1,0,32,0,0,33,1,2,40,1,1,1,1,1,1,33,32,33,0,513]

theorem envBound30312 : H12AffineFastState.Bounded env30312 := by
  intro p hp
  have h : env30312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30311_30312 : H12AffineEnvironment.transform 1 1 env30311 = env30312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30311 == env30312) = true)

theorem identity30312 : scanCanonicalize (H12AffineFastState.compose env30312 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound30312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30313 : List Nat := [2,1,8,1,32,0,9,32,2,32,0,0,41,1,1,35,1,0,32,0,0,33,1,2,40,1,1,1,1,1,1,33,32,33,0,3]

theorem envBound30313 : H12AffineFastState.Bounded env30313 := by
  intro p hp
  have h : env30313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30312_30313 : H12AffineEnvironment.transform 8 2 env30312 = env30313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env30312 == env30313) = true)

theorem identity30313 : scanCanonicalize (H12AffineFastState.compose env30313 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30314 : List Nat := [2,1,8,1,0,0,9,0,2,0,0,0,9,1,1,3,1,0,0,0,0,1,1,2,8,1,1,1,1,1,1,1,0,1,0,3]

theorem envBound30314 : H12AffineFastState.Bounded env30314 := by
  intro p hp
  have h : env30314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30313_30314 : H12AffineEnvironment.transform 4 0 env30313 = env30314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30313 == env30314) = true)

theorem identity30314 : scanCanonicalize (H12AffineFastState.compose env30314 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30314 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30315 : List Nat := [2,1,2,1,0,0,3,0,2,0,0,0,3,1,1,3,1,0,0,0,0,1,1,2,2,1,1,1,1,1,1,1,0,1,0,3]

theorem envBound30315 : H12AffineFastState.Bounded env30315 := by
  intro p hp
  have h : env30315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30314_30315 : H12AffineEnvironment.transform 2 2 env30314 = env30315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30314 == env30315) = true)

theorem identity30315 : scanCanonicalize (H12AffineFastState.compose env30315 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30315 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30316 : List Nat := [1,1,1,1,0,0,0,0,1,0,0,0,0,1,1,0,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,1,0,0]

theorem envBound30316 : H12AffineFastState.Bounded env30316 := by
  intro p hp
  have h : env30316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30315_30316 : H12AffineEnvironment.transform 0 1 env30315 = env30316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30315 == env30316) = true)

def env30317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,180408,254082,243089,8328,65,97547,139612,238994,67618,119042,169,256,98814,90202,63189]

theorem envBound30317 : H12AffineFastState.Bounded env30317 := by
  intro p hp
  have h : env30317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30282_30317 : H12AffineEnvironment.transform 17 10401 env30282 = env30317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30282 == env30317) = true)

def env30318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180272,253962,242969,8192,65,97547,139612,238874,67618,119042,33,256,98678,90202,63069]

theorem envBound30318 : H12AffineFastState.Bounded env30318 := by
  intro p hp
  have h : env30318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30317_30318 : H12AffineEnvironment.transform 6 8 env30317 = env30318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30317 == env30318) = true)

theorem identity30318 : scanCanonicalize (H12AffineFastState.compose env30318 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound30318 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10281,1024,32769,4160,119927,62541,41310,8192,65,97547,79131,45405,67618,119042,33,256,98678,90202,63069]

theorem envBound30319 : H12AffineFastState.Bounded env30319 := by
  intro p hp
  have h : env30319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30318_30319 : H12AffineEnvironment.transform 16 70727 env30318 = env30319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env30318 == env30319) = true)

theorem identity30319 : scanCanonicalize (H12AffineFastState.compose env30319 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30319 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env30320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,70727,10281,1024,8540,4160,95530,21776,3,8192,65,97547,79131,4096,67618,94303,33,256,73771,90202,22272]

theorem envBound30320 : H12AffineFastState.Bounded env30320 := by
  intro p hp
  have h : env30320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30319_30320 : H12AffineEnvironment.transform 14 8541 env30319 = env30320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30319 == env30320) = true)

theorem identity30320 : scanCanonicalize (H12AffineFastState.compose env30320 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound30320 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env30321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,65536,70727,10281,1024,8540,4160,74078,356,3,8192,65,76159,79131,4096,67618,74795,33,256,73771,78894,884]

theorem envBound30321 : H12AffineFastState.Bounded env30321 := by
  intro p hp
  have h : env30321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30320_30321 : H12AffineEnvironment.transform 13 5236 env30320 = env30321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env30320 == env30321) = true)

theorem identity30321 : scanCanonicalize (H12AffineFastState.compose env30321 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30321 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env30322 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4404,8541,65536,69895,10281,320,8540,4160,74078,356,3,8192,65,76159,77915,4096,67618,74091,33,256,73771,78190,884]

theorem envBound30322 : H12AffineFastState.Bounded env30322 := by
  intro p hp
  have h : env30322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30321_30322 : H12AffineEnvironment.transform 9 320 env30321 = env30322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30321 == env30322) = true)

theorem identity30322 : scanCanonicalize (H12AffineFastState.compose env30322 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30322 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30323 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,41,4404,372,65536,69895,2048,320,373,4160,65911,356,3,41,65,67926,69746,4096,67618,65858,33,256,65538,69959,884]

theorem envBound30323 : H12AffineFastState.Bounded env30323 := by
  intro p hp
  have h : env30323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30322_30323 : H12AffineEnvironment.transform 12 41 env30322 = env30323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30322 == env30323) = true)

def env30324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180273,253963,242968,8193,65,97547,139612,238875,67618,119042,32,256,98679,90202,63068]

theorem envBound30324 : H12AffineFastState.Bounded env30324 := by
  intro p hp
  have h : env30324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30317_30324 : H12AffineEnvironment.transform 6 9 env30317 = env30324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30317 == env30324) = true)

theorem identity30324 : scanCanonicalize (H12AffineFastState.compose env30324 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound30324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1024,32769,4160,95530,21776,3,8193,65,97547,103495,4096,67618,119042,32,256,98679,90202,63068]

theorem envBound30325 : H12AffineFastState.Bounded env30325 := by
  intro p hp
  have h : env30325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30324_30325 : H12AffineEnvironment.transform 16 111899 env30324 = env30325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env30324 == env30325) = true)

theorem identity30325 : scanCanonicalize (H12AffineFastState.compose env30325 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30325 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,103495,2420,1024,32769,4160,87158,21776,3,349,65,89175,103495,4096,67618,119042,32,256,98679,82182,55040]

theorem envBound30326 : H12AffineFastState.Bounded env30326 := by
  intro p hp
  have h : env30326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30325_30326 : H12AffineEnvironment.transform 12 348 env30325 = env30326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30325 == env30326) = true)

theorem identity30326 : scanCanonicalize (H12AffineFastState.compose env30326 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30326 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30327 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,65536,103446,2341,1024,32769,4113,87079,21776,3,268,16,89094,103446,4096,67618,119042,32,256,98598,82182,55040]

theorem envBound30327 : H12AffineFastState.Bounded env30327 := by
  intro p hp
  have h : env30327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30326_30327 : H12AffineEnvironment.transform 5 17 env30326 = env30327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30326 == env30327) = true)

theorem identity30327 : scanCanonicalize (H12AffineFastState.compose env30327 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound30327 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env30328 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,35,37941,2341,1024,32769,4113,21508,21776,3,268,16,23589,37941,4096,2049,53537,32,256,33029,16677,55040]

theorem envBound30328 : H12AffineFastState.Bounded env30328 := by
  intro p hp
  have h : env30328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30327_30328 : H12AffineEnvironment.transform 15 35 env30327 = env30328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env30327 == env30328) = true)

theorem identity30328 : scanCanonicalize (H12AffineFastState.compose env30328 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound30328 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env30329 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21541,35,16400,2341,1024,21540,4113,21508,21776,3,268,16,23589,16400,4096,2049,1284,32,256,21792,16677,805]

theorem envBound30329 : H12AffineFastState.Bounded env30329 := by
  intro p hp
  have h : env30329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30328_30329 : H12AffineEnvironment.transform 14 21541 env30328 = env30329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env30328 == env30329) = true)

theorem identity30329 : scanCanonicalize (H12AffineFastState.compose env30329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound30329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30330 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,1,35,5172,2341,1024,0,4113,32,308,3,268,16,2049,5172,4096,2049,1284,32,256,260,5377,805]

theorem envBound30330 : H12AffineFastState.Bounded env30330 := by
  intro p hp
  have h : env30330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30329_30330 : H12AffineEnvironment.transform 13 5156 env30329 = env30330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env30329 == env30330) = true)

theorem identity30330 : scanCanonicalize (H12AffineFastState.compose env30330 (packedSelected [1,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30330 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env30331 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5124,1,3,5140,2309,1024,0,4113,0,276,3,268,16,2049,5140,4096,2049,1284,0,256,260,5377,773]

theorem envBound30331 : H12AffineFastState.Bounded env30331 := by
  intro p hp
  have h : env30331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30330_30331 : H12AffineEnvironment.transform 4 0 env30330 = env30331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30330 == env30331) = true)

theorem identity30331 : scanCanonicalize (H12AffineFastState.compose env30331 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30331 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30332 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,1,3,5140,2049,1024,0,4113,0,16,3,8,16,2049,5140,4096,2049,1024,0,4,0,5125,513]

theorem envBound30332 : H12AffineFastState.Bounded env30332 := by
  intro p hp
  have h : env30332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30331_30332 : H12AffineEnvironment.transform 7 4 env30331 = env30332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30331 == env30332) = true)

theorem identity30332 : scanCanonicalize (H12AffineFastState.compose env30332 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound30332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30333 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1045,1,3,1029,2049,1024,0,0,0,16,3,8,16,2049,1029,17,2049,1024,0,4,0,1044,513]

theorem envBound30333 : H12AffineFastState.Bounded env30333 := by
  intro p hp
  have h : env30333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30332_30333 : H12AffineEnvironment.transform 11 17 env30332 = env30333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30332 == env30333) = true)

theorem identity30333 : scanCanonicalize (H12AffineFastState.compose env30333 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30333 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30334 : List Nat := [2,4,8,16,0,17,9,4,17,1024,2048,17,9,1045,1,3,1029,2049,1024,0,0,0,16,3,8,16,2049,1029,17,2049,1024,0,4,0,1044,16]

theorem envBound30334 : H12AffineFastState.Bounded env30334 := by
  intro p hp
  have h : env30334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30333_30334 : H12AffineEnvironment.transform 8 17 env30333 = env30334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30333 == env30334) = true)

theorem identity30334 : scanCanonicalize (H12AffineFastState.compose env30334 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30334 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30335 : List Nat := [2,4,8,0,0,1,9,4,1,1024,2048,1,9,1029,1,3,1029,2049,1024,0,0,0,0,3,8,0,2049,1029,1,2049,1024,0,4,0,1028,0]

theorem envBound30335 : H12AffineFastState.Bounded env30335 := by
  intro p hp
  have h : env30335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30334_30335 : H12AffineEnvironment.transform 3 0 env30334 = env30335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30334 == env30335) = true)

theorem identity30335 : scanCanonicalize (H12AffineFastState.compose env30335 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound30335 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30336 : List Nat := [2,4,8,0,0,1,9,4,1,1024,1028,1,9,1029,1,3,1029,1029,1024,0,0,0,0,3,8,0,1029,1029,1,1029,1024,0,4,0,1028,0]

theorem envBound30336 : H12AffineFastState.Bounded env30336 := by
  intro p hp
  have h : env30336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30335_30336 : H12AffineEnvironment.transform 10 1028 env30335 = env30336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env30335 == env30336) = true)

theorem identity30336 : scanCanonicalize (H12AffineFastState.compose env30336 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30336 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30337 : List Nat := [2,4,8,0,0,1,9,4,1,4,0,1,9,1,1,3,1,1,4,0,0,0,0,3,8,0,1,1,1,1,4,0,4,0,0,0]

theorem envBound30337 : H12AffineFastState.Bounded env30337 := by
  intro p hp
  have h : env30337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30336_30337 : H12AffineEnvironment.transform 9 4 env30336 = env30337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30336 == env30337) = true)

def env30338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509987,498992,8328,65,349610,395772,494898,67618,119042,272393,256,98815,90203,63189]

theorem envBound30338 : H12AffineFastState.Bounded env30338 := by
  intro p hp
  have h : env30338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30281_30338 : H12AffineEnvironment.transform 20 4161 env30281 = env30338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30281 == env30338) = true)

theorem identity30338 : scanCanonicalize (H12AffineFastState.compose env30338 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound30338 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180408,73754,95497,8328,65,245139,57797,91403,67618,119042,180272,256,98815,90203,63189]

theorem envBound30339 : H12AffineFastState.Bounded env30339 := by
  intro p hp
  have h : env30339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30338_30339 : H12AffineEnvironment.transform 17 190521 env30338 = env30339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env30338 == env30339) = true)

def env30340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1024,32769,4161,32,73754,95497,8328,65,97547,57797,91403,67618,119042,168,256,98815,90203,63189]

theorem envBound30340 : H12AffineFastState.Bounded env30340 := by
  intro p hp
  have h : env30340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30339_30340 : H12AffineEnvironment.transform 16 49304 env30339 = env30340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env30339 == env30340) = true)

theorem identity30340 : scanCanonicalize (H12AffineFastState.compose env30340 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21676) := by decide +kernel

theorem selectedBound30340 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env30341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21676,65536,5172,10401,1024,21677,4161,32,73754,95497,8328,65,97547,13673,91403,67618,66990,168,256,87379,90203,8825]

theorem envBound30341 : H12AffineFastState.Bounded env30341 := by
  intro p hp
  have h : env30341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30340_30341 : H12AffineEnvironment.transform 14 21676 env30340 = env30341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21676 env30340 == env30341) = true)

theorem identity30341 : scanCanonicalize (H12AffineFastState.compose env30341 (packedSelected [2,5,6,7,8,9,10,12,16,19,22,23,24,27,28,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30341 : packedSelected [2,5,6,7,8,9,10,12,16,19,22,23,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env30342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,429,65536,5172,10401,1024,428,4161,32,73754,73736,8328,65,75786,13673,77834,67618,66990,168,256,65618,79194,8825]

theorem envBound30342 : H12AffineFastState.Bounded env30342 := by
  intro p hp
  have h : env30342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30341_30342 : H12AffineEnvironment.transform 13 5377 env30341 = env30342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30341 == env30342) = true)

theorem identity30342 : scanCanonicalize (H12AffineFastState.compose env30342 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30342 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,429,65536,5172,2557,1024,428,4161,32,65862,65876,468,65,67926,5173,69974,67618,66990,168,256,65618,70662,805]

theorem envBound30343 : H12AffineFastState.Bounded env30343 := by
  intro p hp
  have h : env30343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30342_30343 : H12AffineEnvironment.transform 12 348 env30342 = env30343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30342 == env30343) = true)

theorem identity30343 : scanCanonicalize (H12AffineFastState.compose env30343 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,19,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30343 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,19,20,23] rootPS < 2^1333 := by decide +kernel

def env30344 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,429,65536,5172,2477,1024,428,4113,32,65814,65796,388,17,67846,5173,69894,67618,66990,168,256,65538,70662,805]

theorem envBound30344 : H12AffineFastState.Bounded env30344 := by
  intro p hp
  have h : env30344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30343_30344 : H12AffineEnvironment.transform 5 16 env30343 = env30344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30343 == env30344) = true)

theorem identity30344 : scanCanonicalize (H12AffineFastState.compose env30344 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound30344 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30345 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,429,398,5172,2477,1024,428,4113,32,152,138,388,17,2184,5173,4232,2476,1056,168,256,396,5512,805]

theorem envBound30345 : H12AffineFastState.Bounded env30345 := by
  intro p hp
  have h : env30345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30344_30345 : H12AffineEnvironment.transform 15 398 env30344 = env30345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env30344 == env30345) = true)

theorem identity30345 : scanCanonicalize (H12AffineFastState.compose env30345 (packedSelected [0,1,2,3,5,6,7,8,14,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound30345 : packedSelected [0,1,2,3,5,6,7,8,14,17] rootPS < 2^1333 := by decide +kernel

def env30346 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,160,5293,1,34,5172,2049,1024,0,4113,32,152,138,40,17,2184,5173,4232,2048,1056,168,172,32,5156,649]

theorem envBound30346 : H12AffineFastState.Bounded env30346 := by
  intro p hp
  have h : env30346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30345_30346 : H12AffineEnvironment.transform 7 172 env30345 = env30346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30345 == env30346) = true)

theorem identity30346 : scanCanonicalize (H12AffineFastState.compose env30346 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30346 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env30347 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,128,5261,1,2,5140,2049,1024,0,4113,0,152,138,8,17,2184,5141,4232,2048,1024,136,140,0,5124,649]

theorem envBound30347 : H12AffineFastState.Bounded env30347 := by
  intro p hp
  have h : env30347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30346_30347 : H12AffineEnvironment.transform 4 0 env30346 = env30347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30346 == env30347) = true)

def env30348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1024,32769,4161,33,73754,95497,8328,65,97546,57797,91403,67618,119042,169,256,98815,90203,63189]

theorem envBound30348 : H12AffineFastState.Bounded env30348 := by
  intro p hp
  have h : env30348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30339_30348 : H12AffineEnvironment.transform 16 49305 env30339 = env30348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env30339 == env30348) = true)

theorem identity30348 : scanCanonicalize (H12AffineFastState.compose env30348 (packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound30348 : packedSelected [1,2,4,5,6,7,12,14,16,18,20,22,24,27,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env30349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,16400,10400,1024,136,4161,33,73754,95497,8328,65,97546,24908,91403,67618,86411,169,256,65910,90203,30300]

theorem envBound30349 : H12AffineFastState.Bounded env30349 := by
  intro p hp
  have h : env30349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30348_30349 : H12AffineEnvironment.transform 14 137 env30348 = env30349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env30348 == env30349) = true)

theorem identity30349 : scanCanonicalize (H12AffineFastState.compose env30349 (packedSelected [0,3,4,7,10,11,16,17,19,20,22,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound30349 : packedSelected [0,3,4,7,10,11,16,17,19,20,22,24,32] rootPS < 2^1333 := by decide +kernel

def env30350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,65536,16400,2420,1024,136,4161,33,65998,87261,348,65,89310,16536,83167,67618,86411,169,256,65910,82319,22408]

theorem envBound30350 : H12AffineFastState.Bounded env30350 := by
  intro p hp
  have h : env30350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30349_30350 : H12AffineEnvironment.transform 12 468 env30349 = env30350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env30349 == env30350) = true)

theorem identity30350 : scanCanonicalize (H12AffineFastState.compose env30350 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30350 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,65536,5393,2420,1024,136,4161,33,65998,66012,348,65,68063,5529,70110,67618,66698,169,256,65910,70798,649]

theorem envBound30351 : H12AffineFastState.Bounded env30351 := by
  intro p hp
  have h : env30351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30350_30351 : H12AffineEnvironment.transform 13 5377 env30350 = env30351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30350 == env30351) = true)

theorem identity30351 : scanCanonicalize (H12AffineFastState.compose env30351 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound30351 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,398,5393,2420,1024,136,4161,33,64,82,348,65,2129,5529,4176,2476,1284,169,256,248,5376,649]

theorem envBound30352 : H12AffineFastState.Bounded env30352 := by
  intro p hp
  have h : env30352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30351_30352 : H12AffineEnvironment.transform 15 398 env30351 = env30352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env30351 == env30352) = true)

theorem identity30352 : scanCanonicalize (H12AffineFastState.compose env30352 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30352 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env30353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,262,5393,2420,1024,0,4161,33,64,82,348,65,2129,5393,4176,2340,1284,33,256,112,5376,513]

theorem envBound30353 : H12AffineFastState.Bounded env30353 := by
  intro p hp
  have h : env30353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30352_30353 : H12AffineEnvironment.transform 6 8 env30352 = env30353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30352 == env30353) = true)

theorem identity30353 : scanCanonicalize (H12AffineFastState.compose env30353 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30353 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30354 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1024,0,4113,33,16,2,268,17,2049,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound30354 : H12AffineFastState.Bounded env30354 := by
  intro p hp
  have h : env30354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30353_30354 : H12AffineEnvironment.transform 5 16 env30353 = env30354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30353 == env30354) = true)

theorem identity30354 : scanCanonicalize (H12AffineFastState.compose env30354 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound30354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30355 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,268,1044,1,262,1028,2340,1024,0,260,33,16,2,268,17,2049,1028,277,2340,1284,33,256,32,1045,513]

theorem envBound30355 : H12AffineFastState.Bounded env30355 := by
  intro p hp
  have h : env30355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30354_30355 : H12AffineEnvironment.transform 11 277 env30354 = env30355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env30354 == env30355) = true)

theorem identity30355 : scanCanonicalize (H12AffineFastState.compose env30355 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound30355 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30356 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,277,268,293,1,262,309,2340,305,0,260,33,16,2,268,17,2049,309,277,2340,53,33,256,32,292,513]

theorem envBound30356 : H12AffineFastState.Bounded env30356 := by
  intro p hp
  have h : env30356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30355_30356 : H12AffineEnvironment.transform 9 305 env30355 = env30356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env30355 == env30356) = true)

theorem identity30356 : scanCanonicalize (H12AffineFastState.compose env30356 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound30356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30357 : List Nat := [2,4,8,16,32,16,8,256,292,305,2048,277,268,293,1,262,309,2340,305,0,260,33,16,2,268,17,2049,309,277,2340,53,33,256,32,292,293]

theorem envBound30357 : H12AffineFastState.Bounded env30357 := by
  intro p hp
  have h : env30357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30356_30357 : H12AffineEnvironment.transform 8 292 env30356 = env30357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env30356 == env30357) = true)

theorem identity30357 : scanCanonicalize (H12AffineFastState.compose env30357 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30357 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30358 : List Nat := [2,4,8,16,17,16,8,256,277,256,2048,277,268,276,1,262,260,2325,256,0,260,16,16,2,268,17,2049,260,277,2325,4,16,256,17,277,276]

theorem envBound30358 : H12AffineFastState.Bounded env30358 := by
  intro p hp
  have h : env30358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30357_30358 : H12AffineEnvironment.transform 4 17 env30357 = env30358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30357 == env30358) = true)

theorem identity30358 : scanCanonicalize (H12AffineFastState.compose env30358 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound30358 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30359 : List Nat := [2,4,8,16,17,16,8,256,277,256,17,277,268,276,1,262,260,260,256,0,260,16,16,2,268,17,16,260,277,260,4,16,256,17,277,276]

theorem envBound30359 : H12AffineFastState.Bounded env30359 := by
  intro p hp
  have h : env30359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30358_30359 : H12AffineEnvironment.transform 10 17 env30358 = env30359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env30358 == env30359) = true)

def env30360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,498993,8328,65,349611,2496956,2596211,67618,119043,2373705,256,2199999,2191387,63188]

theorem envBound30360 : H12AffineFastState.Bounded env30360 := by
  intro p hp
  have h : env30360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30280_30360 : H12AffineEnvironment.transform 23 498993 env30280 = env30360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env30280 == env30360) = true)

def env30361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509987,498993,8328,65,349611,395772,494899,67618,119043,272393,256,98815,90203,63188]

theorem envBound30361 : H12AffineFastState.Bounded env30361 := by
  intro p hp
  have h : env30361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30360_30361 : H12AffineEnvironment.transform 20 4160 env30360 = env30361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30360 == env30361) = true)

theorem identity30361 : scanCanonicalize (H12AffineFastState.compose env30361 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound30361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4160,180408,120015,98781,8328,65,215367,5392,102879,67618,119043,144613,256,98815,90203,63188]

theorem envBound30362 : H12AffineFastState.Bounded env30362 := by
  intro p hp
  have h : env30362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30361_30362 : H12AffineEnvironment.transform 17 138476 env30361 = env30362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env30361 == env30362) = true)

def env30363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1024,32769,4160,62708,120015,98781,8328,65,97547,5392,102879,67618,119043,169,256,98815,90203,63188]

theorem envBound30363 : H12AffineFastState.Bounded env30363 := by
  intro p hp
  have h : env30363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30362_30363 : H12AffineEnvironment.transform 16 13388 env30362 = env30363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30362 == env30363) = true)

theorem identity30363 : scanCanonicalize (H12AffineFastState.compose env30363 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound30363 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env30364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,13388,10400,1024,136,4160,29821,87110,65876,8328,65,97547,5392,69974,67618,86410,169,256,65910,90203,30301]

theorem envBound30364 : H12AffineFastState.Bounded env30364 := by
  intro p hp
  have h : env30364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30363_30364 : H12AffineEnvironment.transform 14 137 env30363 = env30364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env30363 == env30364) = true)

theorem identity30364 : scanCanonicalize (H12AffineFastState.compose env30364 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound30364 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env30365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,65536,5528,2420,1024,136,4160,21929,87110,65876,348,65,89311,5392,69974,67618,86410,169,256,65910,82319,22409]

theorem envBound30365 : H12AffineFastState.Bounded env30365 := by
  intro p hp
  have h : env30365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30364_30365 : H12AffineEnvironment.transform 12 468 env30364 = env30365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env30364 == env30365) = true)

theorem identity30365 : scanCanonicalize (H12AffineFastState.compose env30365 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,65536,5528,2420,1024,136,4160,169,65862,65876,348,65,68063,5392,69974,67618,66698,169,256,65910,70799,649]

theorem envBound30366 : H12AffineFastState.Bounded env30366 := by
  intro p hp
  have h : env30366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30365_30366 : H12AffineEnvironment.transform 13 5376 env30365 = env30366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30365 == env30366) = true)

theorem identity30366 : scanCanonicalize (H12AffineFastState.compose env30366 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound30366 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,262,5528,2420,1024,136,4160,169,64,82,348,65,2265,5392,4176,2340,1420,169,256,112,5513,649]

theorem envBound30367 : H12AffineFastState.Bounded env30367 := by
  intro p hp
  have h : env30367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30366_30367 : H12AffineEnvironment.transform 15 262 env30366 = env30367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env30366 == env30367) = true)

theorem identity30367 : scanCanonicalize (H12AffineFastState.compose env30367 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30367 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env30368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,262,5392,2420,1024,0,4160,33,64,82,348,65,2129,5392,4176,2340,1284,33,256,112,5377,513]

theorem envBound30368 : H12AffineFastState.Bounded env30368 := by
  intro p hp
  have h : env30368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30367_30368 : H12AffineEnvironment.transform 6 8 env30367 = env30368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30367 == env30368) = true)

theorem identity30368 : scanCanonicalize (H12AffineFastState.compose env30368 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30368 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30369 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1024,0,4112,33,16,2,268,17,2049,5392,4096,2340,1284,33,256,32,5377,513]

theorem envBound30369 : H12AffineFastState.Bounded env30369 := by
  intro p hp
  have h : env30369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30368_30369 : H12AffineEnvironment.transform 5 16 env30368 = env30369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30368 == env30369) = true)

theorem identity30369 : scanCanonicalize (H12AffineFastState.compose env30369 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound30369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30370 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,268,1044,1,262,1028,2340,1024,0,260,33,16,2,268,17,2049,1028,276,2340,1284,33,256,32,1045,513]

theorem envBound30370 : H12AffineFastState.Bounded env30370 := by
  intro p hp
  have h : env30370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30369_30370 : H12AffineEnvironment.transform 11 276 env30369 = env30370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env30369 == env30370) = true)

theorem identity30370 : scanCanonicalize (H12AffineFastState.compose env30370 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound30370 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30371 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,276,268,293,1,262,309,2340,305,0,260,33,16,2,268,17,2049,309,276,2340,53,33,256,32,292,513]

theorem envBound30371 : H12AffineFastState.Bounded env30371 := by
  intro p hp
  have h : env30371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30370_30371 : H12AffineEnvironment.transform 9 305 env30370 = env30371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env30370 == env30371) = true)

theorem identity30371 : scanCanonicalize (H12AffineFastState.compose env30371 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound30371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30372 : List Nat := [2,4,8,16,32,16,8,256,293,305,2048,276,268,293,1,262,309,2340,305,0,260,33,16,2,268,17,2049,309,276,2340,53,33,256,32,292,292]

theorem envBound30372 : H12AffineFastState.Bounded env30372 := by
  intro p hp
  have h : env30372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30371_30372 : H12AffineEnvironment.transform 8 293 env30371 = env30372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env30371 == env30372) = true)

theorem identity30372 : scanCanonicalize (H12AffineFastState.compose env30372 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30372 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30373 : List Nat := [2,4,8,16,17,16,8,256,276,256,2048,276,268,276,1,262,260,2325,256,0,260,16,16,2,268,17,2049,260,276,2325,4,16,256,17,277,277]

theorem envBound30373 : H12AffineFastState.Bounded env30373 := by
  intro p hp
  have h : env30373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30372_30373 : H12AffineEnvironment.transform 4 17 env30372 = env30373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30372 == env30373) = true)

theorem identity30373 : scanCanonicalize (H12AffineFastState.compose env30373 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound30373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30374 : List Nat := [2,4,8,16,17,16,8,256,276,256,17,276,268,276,1,262,260,260,256,0,260,16,16,2,268,17,16,260,276,260,4,16,256,17,277,277]

theorem envBound30374 : H12AffineFastState.Bounded env30374 := by
  intro p hp
  have h : env30374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30373_30374 : H12AffineEnvironment.transform 10 17 env30373 = env30374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env30373 == env30374) = true)

def env30375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10401,1024,32769,4160,62709,120015,98781,8328,65,97546,5392,102879,67618,119043,168,256,98815,90203,63188]

theorem envBound30375 : H12AffineFastState.Bounded env30375 := by
  intro p hp
  have h : env30375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30362_30375 : H12AffineEnvironment.transform 16 13389 env30362 = env30375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env30362 == env30375) = true)

theorem identity30375 : scanCanonicalize (H12AffineFastState.compose env30375 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 41262) := by decide +kernel

theorem selectedBound30375 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env30376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41262,13389,10401,1024,32769,4160,62709,30177,8435,8328,65,56356,5392,12529,43276,28717,168,256,8401,49525,63188]

theorem envBound30376 : H12AffineFastState.Bounded env30376 := by
  intro p hp
  have h : env30376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30375_30376 : H12AffineEnvironment.transform 15 41262 env30375 = env30376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41262 env30375 == env30376) = true)

theorem identity30376 : scanCanonicalize (H12AffineFastState.compose env30376 (packedSelected [2,4,5,6,8,10,14,15,19,20,22,23,24,28,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30376 : packedSelected [2,4,5,6,8,10,14,15,19,20,22,23,24,28,32,35,38] rootPS < 2^1333 := by decide +kernel

def env30377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,21875,13389,10401,1024,29788,4160,168,30177,8435,8328,65,10361,5392,12529,23889,28717,168,256,8401,13608,649]

theorem envBound30377 : H12AffineFastState.Bounded env30377 := by
  intro p hp
  have h : env30377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30376_30377 : H12AffineEnvironment.transform 14 29789 env30376 = env30377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30376 == env30377) = true)

theorem identity30377 : scanCanonicalize (H12AffineFastState.compose env30377 (packedSelected [2,6,9,14,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13808) := by decide +kernel

theorem selectedBound30377 : packedSelected [2,6,9,14,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env30378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,429,8323,13389,10401,1024,428,4160,168,17,8435,8328,65,10361,5392,12529,10401,1501,168,256,8401,13608,649]

theorem envBound30378 : H12AffineFastState.Bounded env30378 := by
  intro p hp
  have h : env30378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30377_30378 : H12AffineEnvironment.transform 13 13808 env30377 = env30378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13808 env30377 == env30378) = true)

theorem identity30378 : scanCanonicalize (H12AffineFastState.compose env30378 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30378 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,293,8203,13389,10281,1024,292,4160,32,17,8315,8192,65,10361,5392,12409,10281,1365,32,256,8281,13608,513]

theorem envBound30379 : H12AffineFastState.Bounded env30379 := by
  intro p hp
  have h : env30379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30378_30379 : H12AffineEnvironment.transform 6 8 env30378 = env30379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30378 == env30379) = true)

theorem identity30379 : scanCanonicalize (H12AffineFastState.compose env30379 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound30379 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env30380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4404,293,1095,4097,3173,1024,292,4160,32,17,1079,1100,65,3125,5392,5173,3173,1365,32,256,1045,4452,513]

theorem envBound30380 : H12AffineFastState.Bounded env30380 := by
  intro p hp
  have h : env30380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30379_30380 : H12AffineEnvironment.transform 12 1100 env30379 = env30380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env30379 == env30380) = true)

theorem identity30380 : scanCanonicalize (H12AffineFastState.compose env30380 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound30380 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env30381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,1100,4404,293,1095,4097,1,1024,292,4160,32,17,1079,1100,65,81,5392,5173,1,1365,32,256,1045,4452,513]

theorem envBound30381 : H12AffineFastState.Bounded env30381 := by
  intro p hp
  have h : env30381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30380_30381 : H12AffineEnvironment.transform 10 1124 env30380 = env30381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env30380 == env30381) = true)

theorem identity30381 : scanCanonicalize (H12AffineFastState.compose env30381 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound30381 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,1281,1100,1077,293,1095,1280,1,1024,292,1345,32,17,1079,1100,65,81,17,308,1,1365,32,256,1045,1125,513]

theorem envBound30382 : H12AffineFastState.Bounded env30382 := by
  intro p hp
  have h : env30382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30381_30382 : H12AffineEnvironment.transform 11 1281 env30381 = env30382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env30381 == env30382) = true)

theorem identity30382 : scanCanonicalize (H12AffineFastState.compose env30382 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30382 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30383 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1124,1060,1100,1077,0,1095,1061,1,1024,1,1124,32,17,1079,1100,65,81,17,17,1,1136,32,37,1045,1125,513]

theorem envBound30383 : H12AffineFastState.Bounded env30383 := by
  intro p hp
  have h : env30383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30382_30383 : H12AffineEnvironment.transform 7 37 env30382 = env30383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30382 == env30383) = true)

theorem identity30383 : scanCanonicalize (H12AffineFastState.compose env30383 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound30383 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30384 : List Nat := [2,4,8,16,32,64,8,37,512,111,11,75,35,90,0,40,74,1,111,1,11,32,17,88,35,65,81,17,17,1,31,32,37,122,10,513]

theorem envBound30384 : H12AffineFastState.Bounded env30384 := by
  intro p hp
  have h : env30384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30383_30384 : H12AffineEnvironment.transform 9 111 env30383 = env30384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env30383 == env30384) = true)

theorem identity30384 : scanCanonicalize (H12AffineFastState.compose env30384 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound30384 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30385 : List Nat := [2,4,8,16,32,58,8,37,512,21,11,49,35,32,0,40,48,1,21,1,11,32,17,34,35,59,43,17,17,1,31,32,37,0,10,513]

theorem envBound30385 : H12AffineFastState.Bounded env30385 := by
  intro p hp
  have h : env30385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30384_30385 : H12AffineEnvironment.transform 5 58 env30384 = env30385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env30384 == env30385) = true)

theorem identity30385 : scanCanonicalize (H12AffineFastState.compose env30385 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30385 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30386 : List Nat := [2,4,8,0,32,42,8,37,512,5,11,33,35,32,0,40,32,1,5,1,11,32,1,34,35,43,43,1,1,1,15,32,37,0,10,513]

theorem envBound30386 : H12AffineFastState.Bounded env30386 := by
  intro p hp
  have h : env30386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30385_30386 : H12AffineEnvironment.transform 3 0 env30385 = env30386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30385 == env30386) = true)

theorem identity30386 : scanCanonicalize (H12AffineFastState.compose env30386 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound30386 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30387 : List Nat := [2,4,8,0,32,42,8,37,34,5,11,33,35,32,0,40,32,1,5,1,11,32,1,34,35,43,43,1,1,1,15,32,37,0,10,35]

theorem envBound30387 : H12AffineFastState.Bounded env30387 := by
  intro p hp
  have h : env30387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30386_30387 : H12AffineEnvironment.transform 8 34 env30386 = env30387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env30386 == env30387) = true)

theorem identity30387 : scanCanonicalize (H12AffineFastState.compose env30387 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30387 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30388 : List Nat := [2,4,8,0,1,11,8,4,3,5,11,0,2,1,0,9,1,1,5,1,11,1,1,3,2,10,10,1,1,1,15,1,4,0,10,2]

theorem envBound30388 : H12AffineFastState.Bounded env30388 := by
  intro p hp
  have h : env30388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30387_30388 : H12AffineEnvironment.transform 4 1 env30387 = env30388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30387 == env30388) = true)

theorem identity30388 : scanCanonicalize (H12AffineFastState.compose env30388 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30388 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env30389 : List Nat := [2,4,3,0,1,0,3,4,3,5,0,0,2,1,0,2,1,1,5,1,0,1,1,3,2,1,1,1,1,1,4,1,4,0,1,2]

theorem envBound30389 : H12AffineFastState.Bounded env30389 := by
  intro p hp
  have h : env30389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30388_30389 : H12AffineEnvironment.transform 2 3 env30388 = env30389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30388 == env30389) = true)

theorem identity30389 : scanCanonicalize (H12AffineFastState.compose env30389 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30390 : List Nat := [2,1,3,0,1,0,3,1,3,0,0,0,2,1,0,2,1,1,0,1,0,1,1,3,2,1,1,1,1,1,1,1,1,0,1,2]

theorem envBound30390 : H12AffineFastState.Bounded env30390 := by
  intro p hp
  have h : env30390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30389_30390 : H12AffineEnvironment.transform 1 1 env30389 = env30390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30389 == env30390) = true)

def env30391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,509987,498993,8328,65,349611,395773,494898,67618,119043,272392,256,98814,90202,63188]

theorem envBound30391 : H12AffineFastState.Bounded env30391 := by
  intro p hp
  have h : env30391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30360_30391 : H12AffineEnvironment.transform 20 4161 env30360 = env30391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30360 == env30391) = true)

theorem identity30391 : scanCanonicalize (H12AffineFastState.compose env30391 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,144493,474358,485860,8328,65,349611,395773,489959,67618,75222,272392,256,95531,90202,513]

theorem envBound30392 : H12AffineFastState.Bounded env30392 := by
  intro p hp
  have h : env30392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30391_30392 : H12AffineEnvironment.transform 14 29909 env30391 = env30392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30391 == env30392) = true)

def env30393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,474238,485740,8192,65,349475,395637,489839,67618,75102,272392,256,95531,90202,513]

theorem envBound30393 : H12AffineFastState.Bounded env30393 := by
  intro p hp
  have h : env30393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30392_30393 : H12AffineEnvironment.transform 6 8 env30392 = env30393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30392 == env30393) = true)

theorem identity30393 : scanCanonicalize (H12AffineFastState.compose env30393 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound30393 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env30394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1024,29788,4161,144493,213334,201796,8192,65,75787,160861,197703,67618,75102,21792,256,95531,90202,513]

theorem envBound30394 : H12AffineFastState.Bounded env30394 := by
  intro p hp
  have h : env30394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30393_30394 : H12AffineEnvironment.transform 17 32040 env30393 = env30394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30393 == env30394) = true)

theorem identity30394 : scanCanonicalize (H12AffineFastState.compose env30394 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30394 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env30395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,131072,23668,1024,21760,4161,136497,213334,201796,348,65,67927,152833,197703,67618,66562,21792,256,87159,82182,513]

theorem envBound30395 : H12AffineFastState.Bounded env30395 := by
  intro p hp
  have h : env30395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30394_30395 : H12AffineEnvironment.transform 12 348 env30394 = env30395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30394 == env30395) = true)

theorem identity30395 : scanCanonicalize (H12AffineFastState.compose env30395 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound30395 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,82246,23668,1024,21760,4161,87159,16,21762,348,65,67927,70727,17665,67618,66562,21792,256,87159,82182,513]

theorem envBound30396 : H12AffineFastState.Bounded env30396 := by
  intro p hp
  have h : env30396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30395_30396 : H12AffineEnvironment.transform 16 82246 env30395 = env30396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env30395 == env30396) = true)

theorem identity30396 : scanCanonicalize (H12AffineFastState.compose env30396 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound30396 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21591,5393,23668,1024,21760,4161,32,16,21762,348,65,23808,16400,17665,23669,20565,21792,256,32,5457,513]

theorem envBound30397 : H12AffineFastState.Bounded env30397 := by
  intro p hp
  have h : env30397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30396_30397 : H12AffineEnvironment.transform 15 21591 env30396 = env30397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env30396 == env30397) = true)

theorem identity30397 : scanCanonicalize (H12AffineFastState.compose env30397 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound30397 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30398 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,21588,21591,5188,23668,1024,21589,4161,32,16,21591,9,65,23637,16400,17492,23669,20565,21621,85,32,5124,513]

theorem envBound30398 : H12AffineFastState.Bounded env30398 := by
  intro p hp
  have h : env30398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30397_30398 : H12AffineEnvironment.transform 7 85 env30397 = env30398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env30397 == env30398) = true)

theorem identity30398 : scanCanonicalize (H12AffineFastState.compose env30398 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30398 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30399 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,5124,80,83,5188,2160,1024,81,4161,32,16,83,9,65,2129,5140,4176,2161,1105,113,85,32,5124,513]

theorem envBound30399 : H12AffineFastState.Bounded env30399 := by
  intro p hp
  have h : env30399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30398_30399 : H12AffineEnvironment.transform 13 5124 env30398 = env30399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30398 == env30399) = true)

theorem identity30399 : scanCanonicalize (H12AffineFastState.compose env30399 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound30399 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30400 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1556,4096,9,5124,80,83,5188,1636,1024,81,4161,32,16,83,9,65,1605,5140,4176,1637,1105,113,85,32,5124,513]

theorem envBound30400 : H12AffineFastState.Bounded env30400 := by
  intro p hp
  have h : env30400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30399_30400 : H12AffineEnvironment.transform 10 1556 env30399 = env30400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env30399 == env30400) = true)

theorem identity30400 : scanCanonicalize (H12AffineFastState.compose env30400 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30400 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30401 : List Nat := [2,4,8,1,32,64,8,68,512,1024,1541,4096,9,5124,65,66,5188,1636,1024,64,4161,32,1,66,9,65,1605,5125,4161,1637,1088,96,68,32,5124,513]

theorem envBound30401 : H12AffineFastState.Bounded env30401 := by
  intro p hp
  have h : env30401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30400_30401 : H12AffineEnvironment.transform 3 1 env30400 = env30401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30400 == env30401) = true)

theorem identity30401 : scanCanonicalize (H12AffineFastState.compose env30401 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound30401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30402 : List Nat := [2,4,8,1,32,64,8,68,512,1024,1541,97,9,1125,65,66,1061,1636,1024,64,32,32,1,66,9,65,1605,1124,32,1637,1088,96,68,32,1125,513]

theorem envBound30402 : H12AffineFastState.Bounded env30402 := by
  intro p hp
  have h : env30402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30401_30402 : H12AffineEnvironment.transform 11 97 env30401 = env30402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env30401 == env30402) = true)

theorem identity30402 : scanCanonicalize (H12AffineFastState.compose env30402 (packedSelected [0,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound30402 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env30403 : List Nat := [2,4,8,1,32,64,8,68,512,68,577,97,9,33,65,66,97,544,68,64,32,32,1,66,9,65,513,32,32,545,4,96,68,32,33,513]

theorem envBound30403 : H12AffineFastState.Bounded env30403 := by
  intro p hp
  have h : env30403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30402_30403 : H12AffineEnvironment.transform 9 68 env30402 = env30403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env30402 == env30403) = true)

theorem identity30403 : scanCanonicalize (H12AffineFastState.compose env30403 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound30403 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30404 : List Nat := [2,4,8,1,32,32,8,36,512,36,545,1,9,33,33,34,1,544,36,32,32,32,1,34,9,33,513,32,32,545,4,0,36,32,33,513]

theorem envBound30404 : H12AffineFastState.Bounded env30404 := by
  intro p hp
  have h : env30404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30403_30404 : H12AffineEnvironment.transform 5 32 env30403 = env30404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env30403 == env30404) = true)

theorem identity30404 : scanCanonicalize (H12AffineFastState.compose env30404 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound30404 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30405 : List Nat := [2,4,8,1,32,32,8,36,32,36,1,1,9,33,33,34,1,0,36,32,32,32,1,34,9,33,33,32,32,1,4,0,36,32,33,33]

theorem envBound30405 : H12AffineFastState.Bounded env30405 := by
  intro p hp
  have h : env30405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30404_30405 : H12AffineEnvironment.transform 8 32 env30404 = env30405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env30404 == env30405) = true)

theorem identity30405 : scanCanonicalize (H12AffineFastState.compose env30405 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30406 : List Nat := [2,4,8,1,0,0,8,4,0,4,1,1,9,1,1,2,1,0,4,0,0,0,1,2,9,1,1,0,0,1,4,0,4,0,1,1]

theorem envBound30406 : H12AffineFastState.Bounded env30406 := by
  intro p hp
  have h : env30406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30405_30406 : H12AffineEnvironment.transform 4 0 env30405 = env30406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30405 == env30406) = true)

def env30407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,474239,485741,8193,65,349474,395636,489838,67618,75103,272392,256,95531,90202,513]

theorem envBound30407 : H12AffineFastState.Bounded env30407 := by
  intro p hp
  have h : env30407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30392_30407 : H12AffineEnvironment.transform 6 9 env30392 = env30407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30392 == env30407) = true)

theorem identity30407 : scanCanonicalize (H12AffineFastState.compose env30407 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound30407 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,4161,87159,285797,264567,8193,65,349474,354670,268660,67618,75103,272392,256,95531,90202,513]

theorem envBound30408 : H12AffineFastState.Bounded env30408 := by
  intro p hp
  have h : env30408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30407_30408 : H12AffineEnvironment.transform 16 90138 env30407 = env30408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env30407 == env30408) = true)

theorem identity30408 : scanCanonicalize (H12AffineFastState.compose env30408 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound30408 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env30409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,22885,1024,29789,4161,87159,1280,20498,8193,65,68679,77835,16401,67618,75103,29037,256,95531,90202,513]

theorem envBound30409 : H12AffineFastState.Bounded env30409 := by
  intro p hp
  have h : env30409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30408_30409 : H12AffineEnvironment.transform 17 22885 env30408 = env30409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env30408 == env30409) = true)

theorem identity30409 : scanCanonicalize (H12AffineFastState.compose env30409 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound30409 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env30410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,1046,25612,22885,1024,29789,4161,20577,1280,20498,8193,65,2129,13341,16401,3124,8521,29037,256,28989,25676,513]

theorem envBound30410 : H12AffineFastState.Bounded env30410 := by
  intro p hp
  have h : env30410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30409_30410 : H12AffineEnvironment.transform 15 1046 env30409 = env30410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env30409 == env30410) = true)

theorem identity30410 : scanCanonicalize (H12AffineFastState.compose env30410 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound30410 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env30411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1296,1046,5440,10281,1024,1297,4161,8493,1280,8542,8193,65,2129,13341,12637,3124,8521,33,256,113,5376,513]

theorem envBound30411 : H12AffineFastState.Bounded env30411 := by
  intro p hp
  have h : env30411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30410_30411 : H12AffineEnvironment.transform 13 12620 env30410 = env30411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env30410 == env30411) = true)

theorem identity30411 : scanCanonicalize (H12AffineFastState.compose env30411 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound30411 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,5457,1296,1046,5440,3124,1024,1297,4161,1328,1280,1347,1052,65,2129,4096,5440,3124,1364,33,256,113,5376,513]

theorem envBound30412 : H12AffineFastState.Bounded env30412 := by
  intro p hp
  have h : env30412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30411_30412 : H12AffineEnvironment.transform 12 1053 env30411 = env30412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env30411 == env30412) = true)

def env30413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,16777216,8328,65,16959643,18973837,2596211,67618,17189938,19113337,256,19270798,19328298,17263589]

theorem envBound30413 : H12AffineFastState.Bounded env30413 := by
  intro p hp
  have h : env30413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30279_30413 : H12AffineEnvironment.transform 21 180409 env30279 = env30413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env30279 == env30413) = true)

def env30414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,498992,8328,65,349611,2496957,2596211,67618,119042,2373705,256,2199998,2191386,63189]

theorem envBound30414 : H12AffineFastState.Bounded env30414 := by
  intro p hp
  have h : env30414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30413_30414 : H12AffineEnvironment.transform 23 498992 env30413 = env30414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env30413 == env30414) = true)

def env30415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509987,498992,8328,65,349611,395773,494899,67618,119042,272393,256,98814,90202,63189]

theorem envBound30415 : H12AffineFastState.Bounded env30415 := by
  intro p hp
  have h : env30415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30414_30415 : H12AffineEnvironment.transform 20 4160 env30414 = env30415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30414 == env30415) = true)

theorem identity30415 : scanCanonicalize (H12AffineFastState.compose env30415 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound30415 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180409,16,21763,8328,65,171416,115150,17664,67618,119042,254010,256,98814,90202,63189]

theorem envBound30416 : H12AffineFastState.Bounded env30416 := by
  intro p hp
  have h : env30416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30415_30416 : H12AffineEnvironment.transform 17 247859 env30415 = env30416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env30415 == env30416) = true)

def env30417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180273,16,21763,8192,65,171280,115014,17664,67618,119042,254010,256,98678,90202,63069]

theorem envBound30417 : H12AffineFastState.Bounded env30417 := by
  intro p hp
  have h : env30417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30416_30417 : H12AffineEnvironment.transform 6 8 env30416 = env30417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30416 == env30417) = true)

theorem identity30417 : scanCanonicalize (H12AffineFastState.compose env30417 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound30417 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,56436,1024,32769,4160,119926,16,21763,8192,65,100695,115014,17664,67618,119042,62589,256,98678,90202,63069]

theorem envBound30418 : H12AffineFastState.Bounded env30418 := by
  intro p hp
  have h : env30418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30417_30418 : H12AffineEnvironment.transform 16 70727 env30417 = env30418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env30417 == env30418) = true)

theorem identity30418 : scanCanonicalize (H12AffineFastState.compose env30418 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound30418 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env30419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,57677,56436,1024,32769,4160,8572,16,21763,8192,65,31837,13388,17664,64808,9224,62589,256,29820,38224,63069]

theorem envBound30419 : H12AffineFastState.Bounded env30419 := by
  intro p hp
  have h : env30419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30418_30419 : H12AffineEnvironment.transform 15 62730 env30418 = env30419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env30418 == env30419) = true)

theorem identity30419 : scanCanonicalize (H12AffineFastState.compose env30419 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30419 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env30420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,41050,46109,35108,1024,32769,4160,8572,16,83,8192,65,10509,13388,4176,43128,9224,41261,256,8492,38224,41741]

theorem envBound30420 : H12AffineFastState.Bounded env30420 := by
  intro p hp
  have h : env30420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30419_30420 : H12AffineEnvironment.transform 13 5456 env30419 = env30420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30419 == env30420) = true)

theorem identity30420 : scanCanonicalize (H12AffineFastState.compose env30420 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30420 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,262,5441,10360,1024,8541,4160,8572,16,83,8192,65,10509,13388,4176,2340,9224,113,256,8492,13324,593]

theorem envBound30421 : H12AffineFastState.Bounded env30421 := by
  intro p hp
  have h : env30421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30420_30421 : H12AffineEnvironment.transform 14 8540 env30420 = env30421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30420 == env30421) = true)

theorem identity30421 : scanCanonicalize (H12AffineFastState.compose env30421 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30421 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env30422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,0,262,5441,2340,1024,1,4160,32,16,83,348,65,2129,5392,4176,2340,1364,113,256,112,5456,593]

theorem envBound30422 : H12AffineFastState.Bounded env30422 := by
  intro p hp
  have h : env30422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30421_30422 : H12AffineEnvironment.transform 12 348 env30421 = env30422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30421 == env30422) = true)

theorem identity30422 : scanCanonicalize (H12AffineFastState.compose env30422 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound30422 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30423 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,348,4404,0,262,4389,2340,100,1,4160,32,16,83,348,65,2129,4468,4176,2340,304,113,256,112,4404,593]

theorem envBound30423 : H12AffineFastState.Bounded env30423 := by
  intro p hp
  have h : env30423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30422_30423 : H12AffineEnvironment.transform 9 100 env30422 = env30423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env30422 == env30423) = true)

def env30424 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180272,16,21763,8193,65,171281,115015,17664,67618,119042,254010,256,98679,90202,63068]

theorem envBound30424 : H12AffineFastState.Bounded env30424 := by
  intro p hp
  have h : env30424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30416_30424 : H12AffineEnvironment.transform 6 9 env30416 = env30424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30416 == env30424) = true)

theorem identity30424 : scanCanonicalize (H12AffineFastState.compose env30424 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound30424 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,32040,1024,32769,4160,95531,16,21763,8193,65,75786,115015,17664,67618,119042,21793,256,98679,90202,63068]

theorem envBound30425 : H12AffineFastState.Bounded env30425 := by
  intro p hp
  have h : env30425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30424_30425 : H12AffineEnvironment.transform 16 111899 env30424 = env30425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env30424 == env30425) = true)

theorem identity30425 : scanCanonicalize (H12AffineFastState.compose env30425 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound30425 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49216,32040,1024,32769,4160,112,16,21763,8193,65,23889,46108,17664,32121,42073,21793,256,62508,5377,63068]

theorem envBound30426 : H12AffineFastState.Bounded env30426 := by
  intro p hp
  have h : env30426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30425_30426 : H12AffineEnvironment.transform 15 30043 env30425 = env30426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env30425 == env30426) = true)

theorem identity30426 : scanCanonicalize (H12AffineFastState.compose env30426 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound30426 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env30427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,30043,13672,32040,1024,29993,4160,112,16,21763,8193,65,23889,16692,17664,32121,20849,21793,256,260,5377,884]

theorem envBound30427 : H12AffineFastState.Bounded env30427 := by
  intro p hp
  have h : env30427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30426_30427 : H12AffineEnvironment.transform 14 29992 env30426 = env30427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env30426 == env30427) = true)

theorem identity30427 : scanCanonicalize (H12AffineFastState.compose env30427 (packedSelected [0,3,4,5,6,7,9,10,12,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30427 : packedSelected [0,3,4,5,6,7,9,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env30428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21840,21795,5392,23888,1024,21841,4160,112,16,21763,121,65,23889,16692,17664,23809,20849,21793,256,260,5377,884]

theorem envBound30428 : H12AffineFastState.Bounded env30428 := by
  intro p hp
  have h : env30428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30427_30428 : H12AffineEnvironment.transform 12 120 env30427 = env30428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30427 == env30428) = true)

theorem identity30428 : scanCanonicalize (H12AffineFastState.compose env30428 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30428 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env30429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,80,35,5392,2128,1024,81,4160,112,16,3,121,65,2129,5172,4096,2049,1137,33,256,260,5377,884]

theorem envBound30429 : H12AffineFastState.Bounded env30429 := by
  intro p hp
  have h : env30429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30428_30429 : H12AffineEnvironment.transform 13 5376 env30428 = env30429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30428 == env30429) = true)

theorem identity30429 : scanCanonicalize (H12AffineFastState.compose env30429 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30429 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30430 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,1,35,5392,2049,1024,0,4113,33,16,3,40,16,2048,5172,4096,2049,1056,33,256,260,5377,805]

theorem envBound30430 : H12AffineFastState.Bounded env30430 := by
  intro p hp
  have h : env30430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30429_30430 : H12AffineEnvironment.transform 5 17 env30429 = env30430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30429 == env30430) = true)

theorem identity30430 : scanCanonicalize (H12AffineFastState.compose env30430 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound30430 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env30431 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,41,1,1,35,17,2049,1024,0,1296,33,16,3,40,16,2048,309,1281,2049,1056,33,256,260,0,805]

theorem envBound30431 : H12AffineFastState.Bounded env30431 := by
  intro p hp
  have h : env30431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30430_30431 : H12AffineEnvironment.transform 11 1281 env30430 = env30431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env30430 == env30431) = true)

theorem identity30431 : scanCanonicalize (H12AffineFastState.compose env30431 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound30431 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env30432 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1281,41,1,1,35,17,1296,1024,0,1296,33,16,3,40,16,1297,309,1281,1296,1056,33,256,260,0,805]

theorem envBound30432 : H12AffineFastState.Bounded env30432 := by
  intro p hp
  have h : env30432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30431_30432 : H12AffineEnvironment.transform 10 1297 env30431 = env30432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env30431 == env30432) = true)

def env30433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509987,498992,8328,65,349611,395772,494898,67618,119042,272392,256,98815,90203,63189]

theorem envBound30433 : H12AffineFastState.Bounded env30433 := by
  intro p hp
  have h : env30433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30414_30433 : H12AffineEnvironment.transform 20 4161 env30414 = env30433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30414 == env30433) = true)

end H12CloudChart1