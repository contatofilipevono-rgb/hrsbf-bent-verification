import H12CloudChart1Data189

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound48128 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48129 : List Nat := [2,4,8,16,32,17,9,256,49,273,48,32,269,49,1,263,33,277,272,0,49,32,17,3,268,17,48,32,33,276,21,33,257,33,49,48]

theorem envBound48129 : H12AffineFastState.Bounded env48129 := by
  intro p hp
  have h : env48129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48128_48129 : H12AffineEnvironment.transform 9 273 env48128 = env48129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48128 == env48129) = true)

def env48130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,169370,8328,64,4691218,115151,17664,262280,119043,4268162,257,213351,237763,63188]

theorem envBound48130 : H12AffineFastState.Bounded env48130 := by
  intro p hp
  have h : env48130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48049_48130 : H12AffineEnvironment.transform 20 184537 env48049 = env48130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env48049 == env48130) = true)

def env48131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,169370,8328,64,245138,115151,17664,262280,119043,329730,257,213351,237763,63188]

theorem envBound48131 : H12AffineFastState.Bounded env48131 := by
  intro p hp
  have h : env48131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48130_48131 : H12AffineEnvironment.transform 21 272512 env48130 = env48131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48130 == env48131) = true)

theorem identity48131 : scanCanonicalize (H12AffineFastState.compose env48131 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48131 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140300,272512,144476,155983,8328,64,215367,79130,17664,262280,75222,329730,257,213351,218134,513]

theorem envBound48132 : H12AffineFastState.Bounded env48132 := by
  intro p hp
  have h : env48132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48131_48132 : H12AffineEnvironment.transform 14 29909 env48131 = env48132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48131 == env48132) = true)

def env48133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272392,144476,155983,8192,64,215367,79130,17664,262144,75102,329730,257,213351,218134,513]

theorem envBound48133 : H12AffineFastState.Bounded env48133 := by
  intro p hp
  have h : env48133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48132_48133 : H12AffineEnvironment.transform 6 8 env48132 = env48133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48132 == env48133) = true)

theorem identity48133 : scanCanonicalize (H12AffineFastState.compose env48133 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound48133 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,82966,272392,87110,65877,8192,64,10589,79130,17664,262144,75102,329730,257,8573,13324,513]

theorem envBound48134 : H12AffineFastState.Bounded env48134 := by
  intro p hp
  have h : env48134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48133_48134 : H12AffineEnvironment.transform 16 90138 env48133 = env48134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env48133 == env48134) = true)

theorem identity48134 : scanCanonicalize (H12AffineFastState.compose env48134 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound48134 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env48135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97327,1025,29788,82966,87079,87110,65877,8192,64,10589,79130,17664,97327,75102,29741,257,8573,13324,513]

theorem envBound48135 : H12AffineFastState.Bounded env48135 := by
  intro p hp
  have h : env48135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48134_48135 : H12AffineEnvironment.transform 17 97327 env48134 = env48135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env48134 == env48135) = true)

theorem identity48135 : scanCanonicalize (H12AffineFastState.compose env48135 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound48135 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env48136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2341,1025,29788,12572,8493,8524,29791,8192,64,10589,16400,17664,2341,20564,29741,257,8573,13324,513]

theorem envBound48136 : H12AffineFastState.Bounded env48136 := by
  intro p hp
  have h : env48136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48135_48136 : H12AffineEnvironment.transform 15 29962 env48135 = env48136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env48135 == env48136) = true)

theorem identity48136 : scanCanonicalize (H12AffineFastState.compose env48136 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48136 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env48137 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,29962,5392,2341,1025,29708,12572,8493,8476,29711,8192,16,10509,16400,17664,2341,20484,29741,257,8493,13324,513]

theorem envBound48137 : H12AffineFastState.Bounded env48137 := by
  intro p hp
  have h : env48137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48136_48137 : H12AffineEnvironment.transform 5 16 env48136 = env48137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48136 == env48137) = true)

theorem identity48137 : scanCanonicalize (H12AffineFastState.compose env48137 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48137 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48138 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,263,5392,2341,1025,1,12572,8493,8476,2,8192,16,10509,13341,12557,2341,9225,32,257,8493,13324,513]

theorem envBound48138 : H12AffineFastState.Bounded env48138 := by
  intro p hp
  have h : env48138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48137_48138 : H12AffineEnvironment.transform 13 13325 env48137 = env48138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48137 == env48138) = true)

theorem identity48138 : scanCanonicalize (H12AffineFastState.compose env48138 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 5660) := by decide +kernel

theorem selectedBound48138 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5660,529,0,263,5392,2341,1025,1,1792,5937,5888,2,5660,16,7953,513,1809,2341,4629,32,257,5937,528,513]

theorem envBound48139 : H12AffineFastState.Bounded env48139 := by
  intro p hp
  have h : env48139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48138_48139 : H12AffineEnvironment.transform 12 5660 env48138 = env48139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5660 env48138 == env48139) = true)

theorem identity48139 : scanCanonicalize (H12AffineFastState.compose env48139 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound48139 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env48140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,2617,529,0,263,2357,2341,1025,1,1792,2836,2853,2,2617,16,820,513,1809,2341,3632,32,257,2836,528,513]

theorem envBound48140 : H12AffineFastState.Bounded env48140 := by
  intro p hp
  have h : env48140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48139_48140 : H12AffineEnvironment.transform 11 3109 env48139 = env48140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env48139 == env48140) = true)

theorem identity48140 : scanCanonicalize (H12AffineFastState.compose env48140 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound48140 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env48141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,820,1809,269,529,0,263,513,529,1025,1,1792,32,17,2,269,16,820,513,1809,529,1284,32,257,32,528,513]

theorem envBound48141 : H12AffineFastState.Bounded env48141 := by
  intro p hp
  have h : env48141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48140_48141 : H12AffineEnvironment.transform 10 820 env48140 = env48141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env48140 == env48141) = true)

theorem identity48141 : scanCanonicalize (H12AffineFastState.compose env48141 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound48141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48142 : List Nat := [2,4,8,16,32,16,8,256,512,785,820,0,269,529,0,263,513,529,784,1,17,32,17,2,269,16,820,513,0,529,533,32,257,32,528,513]

theorem envBound48142 : H12AffineFastState.Bounded env48142 := by
  intro p hp
  have h : env48142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48141_48142 : H12AffineEnvironment.transform 9 785 env48141 = env48142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env48141 == env48142) = true)

theorem identity48142 : scanCanonicalize (H12AffineFastState.compose env48142 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48142 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48143 : List Nat := [2,4,8,16,32,16,8,37,512,564,529,0,40,529,0,34,513,529,565,1,17,32,17,2,40,16,529,513,0,529,533,32,36,32,528,513]

theorem envBound48143 : H12AffineFastState.Bounded env48143 := by
  intro p hp
  have h : env48143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48142_48143 : H12AffineEnvironment.transform 7 37 env48142 = env48143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48142 == env48143) = true)

theorem identity48143 : scanCanonicalize (H12AffineFastState.compose env48143 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48143 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48144 : List Nat := [2,4,8,0,32,0,8,37,512,548,513,0,40,513,0,34,513,513,549,1,1,32,1,2,40,0,513,513,0,513,517,32,36,32,512,513]

theorem envBound48144 : H12AffineFastState.Bounded env48144 := by
  intro p hp
  have h : env48144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48143_48144 : H12AffineEnvironment.transform 3 0 env48143 = env48144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48143 == env48144) = true)

def env48145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272393,144476,155983,8193,64,215367,79130,17664,262145,75103,329730,257,213351,218134,513]

theorem envBound48145 : H12AffineFastState.Bounded env48145 := by
  intro p hp
  have h : env48145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48132_48145 : H12AffineEnvironment.transform 6 9 env48132 = env48145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48132 == env48145) = true)

def env48146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,169370,8328,64,245139,115151,17664,262280,119043,329731,257,213351,237763,63188]

theorem envBound48146 : H12AffineFastState.Bounded env48146 := by
  intro p hp
  have h : env48146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48130_48146 : H12AffineEnvironment.transform 21 272513 env48130 = env48146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48130 == env48146) = true)

theorem identity48146 : scanCanonicalize (H12AffineFastState.compose env48146 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound48146 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58516,272513,62660,41431,8328,64,100830,115151,17664,262280,119043,329731,257,95530,103566,63188]

theorem envBound48147 : H12AffineFastState.Bounded env48147 := by
  intro p hp
  have h : env48147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48146_48147 : H12AffineEnvironment.transform 16 13389 env48146 = env48147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env48146 == env48147) = true)

def env48148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58516,169,62660,41431,8328,64,100830,115151,17664,10400,119043,73771,257,95530,103566,63188]

theorem envBound48148 : H12AffineFastState.Bounded env48148 := by
  intro p hp
  have h : env48148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48147_48148 : H12AffineEnvironment.transform 17 10280 env48147 = env48148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48147 == env48148) = true)

theorem identity48148 : scanCanonicalize (H12AffineFastState.compose env48148 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48148 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13389,10280,1025,8660,17729,169,21777,2,8328,64,75787,90138,17664,10400,94422,73771,257,95530,79195,22273]

theorem envBound48149 : H12AffineFastState.Bounded env48149 := by
  intro p hp
  have h : env48149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48148_48149 : H12AffineEnvironment.transform 14 8661 env48148 = env48149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48148 == env48149) = true)

theorem identity48149 : scanCanonicalize (H12AffineFastState.compose env48149 (packedSelected [0,2,5,6,7,11,17,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48149 : packedSelected [0,2,5,6,7,11,17,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8661,65536,13389,10280,1025,8660,12621,169,8477,2,8328,64,75787,70678,12556,10400,66778,73771,257,65830,79195,8973]

theorem envBound48150 : H12AffineFastState.Bounded env48150 := by
  intro p hp
  have h : env48150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48149_48150 : H12AffineEnvironment.transform 13 13324 env48149 = env48150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48149 == env48150) = true)

theorem identity48150 : scanCanonicalize (H12AffineFastState.compose env48150 (packedSelected [3,5,10,16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound48150 : packedSelected [3,5,10,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env48151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8661,478,13389,10280,1025,8660,12621,169,8477,2,8328,64,10709,5576,12556,10400,1284,8693,257,248,13445,8973]

theorem envBound48151 : H12AffineFastState.Bounded env48151 := by
  intro p hp
  have h : env48151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48150_48151 : H12AffineEnvironment.transform 15 478 env48150 = env48151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env48150 == env48151) = true)

theorem identity48151 : scanCanonicalize (H12AffineFastState.compose env48151 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound48151 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env48152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5592,1,478,5529,2556,1025,0,4249,169,201,2,348,64,2049,5576,4312,2420,1284,33,257,248,5457,729]

theorem envBound48152 : H12AffineFastState.Bounded env48152 := by
  intro p hp
  have h : env48152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48151_48152 : H12AffineEnvironment.transform 12 468 env48151 = env48152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env48151 == env48152) = true)

theorem identity48152 : scanCanonicalize (H12AffineFastState.compose env48152 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 2008) := by decide +kernel

theorem selectedBound48152 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env48153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2008,4096,468,5592,1,478,5529,1572,1025,0,4249,169,201,2,348,64,2009,5576,4312,1708,1284,33,257,248,5457,729]

theorem envBound48153 : H12AffineFastState.Bounded env48153 := by
  intro p hp
  have h : env48153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48152_48153 : H12AffineEnvironment.transform 10 2008 env48152 = env48153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2008 env48152 == env48153) = true)

theorem identity48153 : scanCanonicalize (H12AffineFastState.compose env48153 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound48153 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env48154 : List Nat := [2,4,8,16,32,64,121,256,512,1024,1825,4096,301,5409,1,295,5472,1572,1025,0,4192,80,48,2,348,64,1824,5425,4129,1621,1284,33,257,1,5457,544]

theorem envBound48154 : H12AffineFastState.Bounded env48154 := by
  intro p hp
  have h : env48154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48153_48154 : H12AffineEnvironment.transform 6 121 env48153 = env48154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env48153 == env48154) = true)

theorem identity48154 : scanCanonicalize (H12AffineFastState.compose env48154 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48154 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48155 : List Nat := [2,4,8,16,0,64,89,256,512,1024,1793,4096,269,5377,1,263,5440,1540,1025,0,4160,80,16,2,348,64,1792,5393,4097,1621,1284,1,257,1,5457,512]

theorem envBound48155 : H12AffineFastState.Bounded env48155 := by
  intro p hp
  have h : env48155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48154_48155 : H12AffineEnvironment.transform 4 0 env48154 = env48155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48154 == env48155) = true)

theorem identity48155 : scanCanonicalize (H12AffineFastState.compose env48155 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48155 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48156 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1793,4096,269,5377,1,263,5392,1540,1025,0,4112,0,16,2,268,16,1792,5393,4097,1541,1284,1,257,1,5377,512]

theorem envBound48156 : H12AffineFastState.Bounded env48156 := by
  intro p hp
  have h : env48156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48155_48156 : H12AffineEnvironment.transform 5 16 env48155 = env48156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48155 == env48156) = true)

theorem identity48156 : scanCanonicalize (H12AffineFastState.compose env48156 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48157 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1540,4096,8,5124,1,2,5141,1540,1025,0,4112,0,16,2,9,16,1541,5140,4097,1541,1025,1,4,1,5124,512]

theorem envBound48157 : H12AffineFastState.Bounded env48157 := by
  intro p hp
  have h : env48157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48156_48157 : H12AffineEnvironment.transform 7 5 env48156 = env48157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48156 == env48157) = true)

theorem identity48157 : scanCanonicalize (H12AffineFastState.compose env48157 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48157 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48158 : List Nat := [2,4,8,16,0,16,9,5,512,20,528,4096,8,4112,1,2,4097,528,21,0,4112,0,16,2,9,16,529,4096,4097,529,21,1,4,1,4112,512]

theorem envBound48158 : H12AffineFastState.Bounded env48158 := by
  intro p hp
  have h : env48158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48157_48158 : H12AffineEnvironment.transform 9 20 env48157 = env48158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48157 == env48158) = true)

theorem identity48158 : scanCanonicalize (H12AffineFastState.compose env48158 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound48158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48159 : List Nat := [2,4,8,16,0,16,9,5,512,20,528,16,8,0,1,2,17,528,21,0,0,0,16,2,9,16,529,16,17,529,21,1,4,1,0,512]

theorem envBound48159 : H12AffineFastState.Bounded env48159 := by
  intro p hp
  have h : env48159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48158_48159 : H12AffineEnvironment.transform 11 16 env48158 = env48159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48158 == env48159) = true)

theorem identity48159 : scanCanonicalize (H12AffineFastState.compose env48159 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound48159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48160 : List Nat := [2,4,8,4,0,4,9,5,512,0,516,4,8,0,1,2,5,516,1,0,0,0,4,2,9,4,517,4,5,517,1,1,4,1,0,512]

theorem envBound48160 : H12AffineFastState.Bounded env48160 := by
  intro p hp
  have h : env48160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48159_48160 : H12AffineEnvironment.transform 3 4 env48159 = env48160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env48159 == env48160) = true)

theorem identity48160 : scanCanonicalize (H12AffineFastState.compose env48160 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48160 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48161 : List Nat := [2,4,8,4,0,4,9,5,1,0,5,4,8,0,1,2,5,5,1,0,0,0,4,2,9,4,4,4,5,4,1,1,4,1,0,1]

theorem envBound48161 : H12AffineFastState.Bounded env48161 := by
  intro p hp
  have h : env48161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48160_48161 : H12AffineEnvironment.transform 8 1 env48160 = env48161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48160 == env48161) = true)

theorem identity48161 : scanCanonicalize (H12AffineFastState.compose env48161 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48161 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48162 : List Nat := [2,0,8,0,0,0,9,1,1,0,1,0,8,0,1,2,1,1,1,0,0,0,0,2,9,0,0,0,1,0,1,1,0,1,0,1]

theorem envBound48162 : H12AffineFastState.Bounded env48162 := by
  intro p hp
  have h : env48162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48161_48162 : H12AffineEnvironment.transform 1 0 env48161 = env48162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48161 == env48162) = true)

def env48163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58516,168,62660,41431,8328,64,100830,115151,17664,10401,119043,73770,257,95530,103566,63188]

theorem envBound48163 : H12AffineFastState.Bounded env48163 := by
  intro p hp
  have h : env48163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48147_48163 : H12AffineEnvironment.transform 17 10281 env48147 = env48163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48147 == env48163) = true)

theorem identity48163 : scanCanonicalize (H12AffineFastState.compose env48163 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound48163 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,13389,10281,1025,30113,4404,168,356,21623,8328,64,97406,78959,17664,10401,74915,73770,257,95530,90414,884]

theorem envBound48164 : H12AffineFastState.Bounded env48164 := by
  intro p hp
  have h : env48164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48163_48164 : H12AffineEnvironment.transform 14 30112 env48163 = env48164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env48163 == env48164) = true)

theorem identity48164 : scanCanonicalize (H12AffineFastState.compose env48164 (packedSelected [0,1,7,9,10,11,12,14,15,17,18,20,22,23,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound48164 : packedSelected [0,1,7,9,10,11,12,14,15,17,18,20,22,23,26,28,32] rootPS < 2^1333 := by decide +kernel

def env48165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,9279,13389,10281,1025,30113,4404,168,356,21623,8328,64,22593,4176,17664,10401,156,1045,257,20757,17681,884]

theorem envBound48165 : H12AffineFastState.Bounded env48165 := by
  intro p hp
  have h : env48165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48164_48165 : H12AffineEnvironment.transform 15 9279 env48164 = env48165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env48164 == env48165) = true)

theorem identity48165 : scanCanonicalize (H12AffineFastState.compose env48165 (packedSelected [0,7,8,9,10,12,15,17,18,20,22,23,28,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound48165 : packedSelected [0,7,8,9,10,12,15,17,18,20,22,23,28,35] rootPS < 2^1333 := by decide +kernel

def env48166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,509,9279,13389,10281,1025,508,4404,168,356,8234,8328,64,11292,4176,12637,10401,156,1045,257,9544,12620,884]

theorem envBound48166 : H12AffineFastState.Bounded env48166 := by
  intro p hp
  have h : env48166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48165_48166 : H12AffineEnvironment.transform 13 13405 env48165 = env48166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env48165 == env48166) = true)

theorem identity48166 : scanCanonicalize (H12AffineFastState.compose env48166 (packedSelected [1,2,3,6,8,9,10,11,14,16,17,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound48166 : packedSelected [1,2,3,6,8,9,10,11,14,16,17,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env48167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1172,4297,509,171,4313,3261,1025,508,4404,168,356,1214,1052,64,2184,4176,5577,3125,156,1045,257,476,5592,884]

theorem envBound48167 : H12AffineFastState.Bounded env48167 := by
  intro p hp
  have h : env48167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48166_48167 : H12AffineEnvironment.transform 12 1172 env48166 = env48167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env48166 == env48167) = true)

theorem identity48167 : scanCanonicalize (H12AffineFastState.compose env48167 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48167 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env48168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4161,373,35,4177,3125,1025,372,4404,32,356,1078,1052,64,2048,4176,5441,3125,20,1045,257,340,5456,884]

theorem envBound48168 : H12AffineFastState.Bounded env48168 := by
  intro p hp
  have h : env48168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48167_48168 : H12AffineEnvironment.transform 6 8 env48167 = env48168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48167 == env48168) = true)

theorem identity48168 : scanCanonicalize (H12AffineFastState.compose env48168 (packedSelected [2,3,4,5,6,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound48168 : packedSelected [2,3,4,5,6,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1076,1052,1141,373,35,1125,3125,1025,372,1280,32,356,1078,1052,64,2048,1124,373,3125,20,1045,257,340,356,884]

theorem envBound48169 : H12AffineFastState.Bounded env48169 := by
  intro p hp
  have h : env48169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48168_48169 : H12AffineEnvironment.transform 11 1076 env48168 = env48169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env48168 == env48169) = true)

theorem identity48169 : scanCanonicalize (H12AffineFastState.compose env48169 (packedSelected [2,3,5,6,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48169 : packedSelected [2,3,5,6,10,16] rootPS < 2^1333 := by decide +kernel

def env48170 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1052,1141,0,35,1125,3125,1025,1,1141,32,17,1078,1052,64,2048,1124,0,3125,20,1045,116,33,17,513]

theorem envBound48170 : H12AffineFastState.Bounded env48170 := by
  intro p hp
  have h : env48170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48169_48170 : H12AffineEnvironment.transform 7 117 env48169 = env48170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48169 == env48170) = true)

def env48171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound48171 : H12AffineFastState.Bounded env48171 := by
  intro p hp
  have h : env48171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47757_48171 : H12AffineEnvironment.transform 26 30393345 env47757 = env48171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env47757 == env48171) = true)

def env48172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound48172 : H12AffineFastState.Bounded env48172 := by
  intro p hp
  have h : env48172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48171_48172 : H12AffineEnvironment.transform 18 1024 env48171 = env48172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env48171 == env48172) = true)

theorem identity48172 : scanCanonicalize (H12AffineFastState.compose env48172 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound48172 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,138,8328,64,13090955,2196487,10507600,8830977,8488090,6382922,256,10601511,10560899,8430412]

theorem envBound48173 : H12AffineFastState.Bounded env48173 := by
  intro p hp
  have h : env48173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48172_48173 : H12AffineEnvironment.transform 23 138 env48172 = env48173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env48172 == env48173) = true)

def env48174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,138,8328,64,4554755,2196487,2233816,295049,246802,6382922,256,2327727,2319627,189380]

theorem envBound48174 : H12AffineFastState.Bounded env48174 := by
  intro p hp
  have h : env48174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48173_48174 : H12AffineEnvironment.transform 22 147592 env48173 = env48174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env48173 == env48174) = true)

def env48175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,138,8328,64,4450483,2196487,2233816,190521,246802,6382922,256,2327727,2319627,189380]

theorem envBound48175 : H12AffineFastState.Bounded env48175 := by
  intro p hp
  have h : env48175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48174_48175 : H12AffineEnvironment.transform 17 157872 env48174 = env48175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env48174 == env48175) = true)

theorem identity48175 : scanCanonicalize (H12AffineFastState.compose env48175 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound48175 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10280,1024,32769,2097152,4194304,16,138,8328,64,4302891,2196487,2118976,43169,99466,6382922,256,2212919,2172307,41820]

theorem envBound48176 : H12AffineFastState.Bounded env48176 := by
  intro p hp
  have h : env48176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48175_48176 : H12AffineEnvironment.transform 16 16536 env48175 = env48176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env48175 == env48176) = true)

def env48177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302891,2196487,2118976,43049,99330,6382922,256,2212919,2172187,41820]

theorem envBound48177 : H12AffineFastState.Bounded env48177 := by
  intro p hp
  have h : env48177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48176_48177 : H12AffineEnvironment.transform 6 8 env48176 = env48177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48176 == env48177) = true)

theorem identity48177 : scanCanonicalize (H12AffineFastState.compose env48177 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48177 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,2,8192,64,4262262,2172250,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound48178 : H12AffineFastState.Bounded env48178 := by
  intro p hp
  have h : env48178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48177_48178 : H12AffineEnvironment.transform 14 8541 env48177 = env48178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48177 == env48178) = true)

theorem identity48178 : scanCanonicalize (H12AffineFastState.compose env48178 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 79194) := by decide +kernel

theorem selectedBound48178 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,79194,4194304,16,2,8192,64,4262262,4096,90138,2420,75103,4214800,256,20528,4161,513]

theorem envBound48179 : H12AffineFastState.Bounded env48179 := by
  intro p hp
  have h : env48179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48178_48179 : H12AffineEnvironment.transform 20 79194 env48178 = env48179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79194 env48178 == env48179) = true)

theorem identity48179 : scanCanonicalize (H12AffineFastState.compose env48179 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48179 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env48180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1024,8540,5456,4194304,16,2,8192,64,4204924,4096,16400,2420,1365,4214800,256,20528,4161,513]

theorem envBound48180 : H12AffineFastState.Bounded env48180 := by
  intro p hp
  have h : env48180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48179_48180 : H12AffineEnvironment.transform 15 8202 env48179 = env48180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48179 == env48180) = true)

theorem identity48180 : scanCanonicalize (H12AffineFastState.compose env48180 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 4145) := by decide +kernel

theorem selectedBound48180 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env48181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1024,8540,5456,4145,16,2,8192,64,14669,4096,16400,2420,1365,16417,256,20528,4161,513]

theorem envBound48181 : H12AffineFastState.Bounded env48181 := by
  intro p hp
  have h : env48181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48180_48181 : H12AffineEnvironment.transform 21 4145 env48180 = env48181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4145 env48180 == env48181) = true)

theorem identity48181 : scanCanonicalize (H12AffineFastState.compose env48181 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound48181 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env48182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1296,1095,16400,3173,1024,1297,5456,4145,16,2,1101,64,7424,4096,16400,2420,1365,16417,256,20528,4161,513]

theorem envBound48182 : H12AffineFastState.Bounded env48182 := by
  intro p hp
  have h : env48182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48181_48182 : H12AffineEnvironment.transform 12 1101 env48181 = env48182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env48181 == env48182) = true)

theorem identity48182 : scanCanonicalize (H12AffineFastState.compose env48182 (packedSelected [4,9,23] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound48182 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env48183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,1101,16384,1296,1095,16400,3173,1024,1297,1345,32,16,2,1101,64,3345,17,16400,2420,1365,16417,256,16417,80,513]

theorem envBound48183 : H12AffineFastState.Bounded env48183 := by
  intro p hp
  have h : env48183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48182_48183 : H12AffineEnvironment.transform 11 17 env48182 = env48183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48182 == env48183) = true)

theorem identity48183 : scanCanonicalize (H12AffineFastState.compose env48183 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound48183 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,1101,80,1296,1095,64,3173,1024,1297,1345,32,16,2,1101,64,3345,17,64,2420,1365,113,256,113,80,513]

theorem envBound48184 : H12AffineFastState.Bounded env48184 := by
  intro p hp
  have h : env48184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48183_48184 : H12AffineEnvironment.transform 13 80 env48183 = env48184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env48183 == env48184) = true)

theorem identity48184 : scanCanonicalize (H12AffineFastState.compose env48184 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48184 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48185 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,17,1101,80,1124,1095,64,3173,1024,1125,1077,32,16,2,1101,64,3173,17,64,2048,1057,113,116,113,80,513]

theorem envBound48185 : H12AffineFastState.Bounded env48185 := by
  intro p hp
  have h : env48185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48184_48185 : H12AffineEnvironment.transform 7 116 env48184 = env48185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48184 == env48185) = true)

theorem identity48185 : scanCanonicalize (H12AffineFastState.compose env48185 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48185 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48186 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,17,1052,1,1077,1046,17,3124,1024,1076,1077,32,16,2,1052,17,3124,17,17,2048,1057,32,37,32,1,513]

theorem envBound48186 : H12AffineFastState.Bounded env48186 := by
  intro p hp
  have h : env48186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48185_48186 : H12AffineEnvironment.transform 5 17 env48185 = env48186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48185 == env48186) = true)

def env48187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4302891,2196487,2118976,43048,99331,6382922,256,2212919,2172186,41820]

theorem envBound48187 : H12AffineFastState.Bounded env48187 := by
  intro p hp
  have h : env48187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48176_48187 : H12AffineEnvironment.transform 6 9 env48176 = env48187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48176 == env48187) = true)

theorem identity48187 : scanCanonicalize (H12AffineFastState.compose env48187 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound48187 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env48188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10280,1024,32769,2097152,4194304,16,3,8193,64,4237693,2131281,2118976,43048,34133,6317084,256,2147681,2106444,41820]

theorem envBound48188 : H12AffineFastState.Bounded env48188 := by
  intro p hp
  have h : env48188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48187_48188 : H12AffineEnvironment.transform 15 342 env48187 = env48188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env48187 == env48188) = true)

theorem identity48188 : scanCanonicalize (H12AffineFastState.compose env48188 (packedSelected [1,2,4,5,6,8,11,16,17,18,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 50497) := by decide +kernel

theorem selectedBound48188 : packedSelected [1,2,4,5,6,8,11,16,17,18,22,24] rootPS < 2^1333 := by decide +kernel

def env48189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10280,1024,32769,50497,4194304,16,3,8193,64,4237693,16400,36865,43048,34133,4235613,256,32,57613,41820]

theorem envBound48189 : H12AffineFastState.Bounded env48189 := by
  intro p hp
  have h : env48189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48188_48189 : H12AffineEnvironment.transform 20 50497 env48188 = env48189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50497 env48188 == env48189) = true)

theorem identity48189 : scanCanonicalize (H12AffineFastState.compose env48189 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48189 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env48190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16401,10280,1024,8541,25629,4194304,16,3,8193,64,4196385,16400,12637,2420,9225,4194305,256,32,16465,512]

theorem envBound48190 : H12AffineFastState.Bounded env48190 := by
  intro p hp
  have h : env48190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48189_48190 : H12AffineEnvironment.transform 14 8540 env48189 = env48190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48189 == env48190) = true)

theorem identity48190 : scanCanonicalize (H12AffineFastState.compose env48190 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48190 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,5392,10280,1024,8541,12572,4194304,16,3,8193,64,4196385,5393,12637,2420,9225,4194305,256,32,5456,512]

theorem envBound48191 : H12AffineFastState.Bounded env48191 := by
  intro p hp
  have h : env48191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48190_48191 : H12AffineEnvironment.transform 13 5377 env48190 = env48191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48190 == env48191) = true)

theorem identity48191 : scanCanonicalize (H12AffineFastState.compose env48191 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 13436) := by decide +kernel

theorem selectedBound48191 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env48192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,342,5392,10280,1024,8541,12572,13436,16,3,8193,64,15453,5393,12637,2420,9225,13437,256,32,5456,512]

theorem envBound48192 : H12AffineFastState.Bounded env48192 := by
  intro p hp
  have h : env48192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48191_48192 : H12AffineEnvironment.transform 21 13436 env48191 = env48192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 13436 env48191 == env48192) = true)

theorem identity48192 : scanCanonicalize (H12AffineFastState.compose env48192 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 2429) := by decide +kernel

theorem selectedBound48192 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env48193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2429,5377,2081,342,5392,341,1024,2080,6241,7425,16,3,2428,64,5408,5393,6176,2420,3444,7424,256,32,5456,512]

theorem envBound48193 : H12AffineFastState.Bounded env48193 := by
  intro p hp
  have h : env48193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48192_48193 : H12AffineEnvironment.transform 12 2429 env48192 = env48193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2429 env48192 == env48193) = true)

theorem identity48193 : scanCanonicalize (H12AffineFastState.compose env48193 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48193 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env48194 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,2056,5236,2081,35,5221,32,1024,2080,6241,7284,16,3,2057,64,5205,5220,6176,2049,3073,7285,117,32,5157,512]

theorem envBound48194 : H12AffineFastState.Bounded env48194 := by
  intro p hp
  have h : env48194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48193_48194 : H12AffineEnvironment.transform 7 117 env48193 = env48194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48193 == env48194) = true)

def env48195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,138,8328,64,4450482,2196487,2233816,190520,246802,6382922,256,2327727,2319627,189380]

theorem envBound48195 : H12AffineFastState.Bounded env48195 := by
  intro p hp
  have h : env48195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48174_48195 : H12AffineEnvironment.transform 17 157873 env48174 = env48195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env48174 == env48195) = true)

def env48196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450362,2196487,2233680,190520,246802,6382922,256,2327591,2319627,189260]

theorem envBound48196 : H12AffineFastState.Bounded env48196 := by
  intro p hp
  have h : env48196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48195_48196 : H12AffineEnvironment.transform 6 8 env48195 = env48196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48195 == env48196) = true)

theorem identity48196 : scanCanonicalize (H12AffineFastState.compose env48196 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound48196 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35188,1024,32769,2097152,4194304,41293,2,8192,64,4262263,2196487,2159645,2421,75103,6382922,256,2188650,2196550,513]

theorem envBound48197 : H12AffineFastState.Bounded env48197 := by
  intro p hp
  have h : env48197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48196_48197 : H12AffineEnvironment.transform 16 57677 env48196 = env48197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env48196 == env48197) = true)

theorem identity48197 : scanCanonicalize (H12AffineFastState.compose env48197 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound48197 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,35188,1024,32769,2097152,4194304,41293,2,8192,64,4229152,2098512,2159645,2421,41992,6349853,256,2155581,2098449,513]

theorem envBound48198 : H12AffineFastState.Bounded env48198 := by
  intro p hp
  have h : env48198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48197_48198 : H12AffineEnvironment.transform 15 33111 env48197 = env48198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env48197 == env48198) = true)

theorem identity48198 : scanCanonicalize (H12AffineFastState.compose env48198 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound48198 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env48199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,35188,1024,32769,2097152,41340,41293,2,8192,64,10588,2098512,2159645,2421,41992,2114913,256,2155581,2098449,513]

theorem envBound48199 : H12AffineFastState.Bounded env48199 := by
  intro p hp
  have h : env48199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48198_48199 : H12AffineEnvironment.transform 21 41340 env48198 = env48199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env48198 == env48199) = true)

theorem identity48199 : scanCanonicalize (H12AffineFastState.compose env48199 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound48199 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,8282,16448,10361,1024,8460,2097152,113,64,2,8192,64,10588,2098512,2118928,2421,1285,2114913,256,2114864,2098449,513]

theorem envBound48200 : H12AffineFastState.Bounded env48200 := by
  intro p hp
  have h : env48200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48199_48200 : H12AffineEnvironment.transform 14 8461 env48199 = env48200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env48199 == env48200) = true)

theorem identity48200 : scanCanonicalize (H12AffineFastState.compose env48200 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48200 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10281,1024,8460,2097152,33,16,2,8192,16,10508,2098432,2118928,2341,1285,2114865,256,2114864,2098449,513]

theorem envBound48201 : H12AffineFastState.Bounded env48201 := by
  intro p hp
  have h : env48201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48200_48201 : H12AffineEnvironment.transform 5 16 env48200 = env48201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48200 == env48201) = true)

theorem identity48201 : scanCanonicalize (H12AffineFastState.compose env48201 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 16676) := by decide +kernel

theorem selectedBound48201 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10281,1024,8460,16676,33,16,2,8192,16,10508,17444,5172,2341,1285,1045,256,1044,17461,513]

theorem envBound48202 : H12AffineFastState.Bounded env48202 := by
  intro p hp
  have h : env48202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48201_48202 : H12AffineEnvironment.transform 20 16676 env48201 = env48202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16676 env48201 == env48202) = true)

theorem identity48202 : scanCanonicalize (H12AffineFastState.compose env48202 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48202 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env48203 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8192,16384,8461,8202,16400,10281,273,8460,16676,33,16,2,8192,16,10508,16693,4389,2341,20,260,256,261,16676,513]

theorem envBound48203 : H12AffineFastState.Bounded env48203 := by
  intro p hp
  have h : env48203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48202_48203 : H12AffineEnvironment.transform 9 273 env48202 = env48203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48202 == env48203) = true)

theorem identity48203 : scanCanonicalize (H12AffineFastState.compose env48203 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48203 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env48204 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,40,16384,293,34,16400,2049,273,292,16676,33,16,2,40,16,2340,16693,4389,2341,20,260,256,261,16676,513]

theorem envBound48204 : H12AffineFastState.Bounded env48204 := by
  intro p hp
  have h : env48204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48203_48204 : H12AffineEnvironment.transform 12 40 env48203 = env48204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48203 == env48204) = true)

theorem identity48204 : scanCanonicalize (H12AffineFastState.compose env48204 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48204 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48205 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,0,34,16400,2049,52,1,16385,33,16,2,40,16,2049,16400,4096,2048,20,33,37,32,16385,513]

theorem envBound48205 : H12AffineFastState.Bounded env48205 := by
  intro p hp
  have h : env48205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48204_48205 : H12AffineEnvironment.transform 7 37 env48204 = env48205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48204 == env48205) = true)

theorem identity48205 : scanCanonicalize (H12AffineFastState.compose env48205 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48205 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48206 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,16384,0,34,16400,2049,52,1,16385,33,16,2,40,16,2049,16400,2064,2048,20,33,37,32,16385,513]

theorem envBound48206 : H12AffineFastState.Bounded env48206 := by
  intro p hp
  have h : env48206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48205_48206 : H12AffineEnvironment.transform 11 2064 env48205 = env48206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48205 == env48206) = true)

theorem identity48206 : scanCanonicalize (H12AffineFastState.compose env48206 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound48206 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env48207 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,2048,0,34,2064,2049,52,1,2049,33,16,2,40,16,2049,2064,2064,2048,20,33,37,32,2049,513]

theorem envBound48207 : H12AffineFastState.Bounded env48207 := by
  intro p hp
  have h : env48207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48206_48207 : H12AffineEnvironment.transform 13 2048 env48206 = env48207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env48206 == env48207) = true)

theorem identity48207 : scanCanonicalize (H12AffineFastState.compose env48207 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound48207 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48208 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,0,34,33,48,52,1,48,33,16,2,40,16,48,33,33,49,20,33,37,32,48,513]

theorem envBound48208 : H12AffineFastState.Bounded env48208 := by
  intro p hp
  have h : env48208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48207_48208 : H12AffineEnvironment.transform 10 49 env48207 = env48208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env48207 == env48208) = true)

def leafEnv48208 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,0,34,33,48,52,1,48,33,16,2,20,40,1,16,48,33,33,49,20,33,37,32,4,34,48,513,1,49,0]

def active48208 : List Nat := [0,1,2,3,4,8]

def tree48208 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48208 : H12WitnessSearch.Good tree48208 := H12GlobalWitnessIndex.good

theorem leafIdentity48208 : H12AffineFastState.composeSystem env48208 rootObs = leafEnv48208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48208 rootObs == leafEnv48208) = true)

theorem terminalChecked48208 : H12PackedTerminal.terminalCheckFast leafEnv48208 active48208 tree48208 = true := by decide +kernel

def env48209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,64,4450363,2196487,2233681,190520,246802,6382922,256,2327590,2319627,189261]

theorem envBound48209 : H12AffineFastState.Bounded env48209 := by
  intro p hp
  have h : env48209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48195_48209 : H12AffineEnvironment.transform 6 9 env48195 = env48209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48195 == env48209) = true)

def env48210 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,16,4450363,2196487,2233601,190520,246802,6382874,256,2327590,2319627,189213]

theorem envBound48210 : H12AffineFastState.Bounded env48210 := by
  intro p hp
  have h : env48210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48209_48210 : H12AffineEnvironment.transform 5 16 env48209 = env48210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48209 == env48210) = true)

def env48211 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,4194304,147457,3,8193,16,4450363,2195767,2232369,190520,246050,6381610,256,2326806,2318395,189213]

theorem envBound48211 : H12AffineFastState.Bounded env48211 := by
  intro p hp
  have h : env48211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48210_48211 : H12AffineEnvironment.transform 9 304 env48210 = env48211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env48210 == env48211) = true)

theorem identity48211 : scanCanonicalize (H12AffineFastState.compose env48211 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound48211 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env48212 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,246071,147457,3,8193,16,10508,2195767,2232369,190520,246050,2269469,256,2326806,2318395,189213]

theorem envBound48212 : H12AffineFastState.Bounded env48212 := by
  intro p hp
  have h : env48212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48211_48212 : H12AffineEnvironment.transform 21 246071 env48211 = env48212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env48211 == env48212) = true)

theorem identity48212 : scanCanonicalize (H12AffineFastState.compose env48212 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound48212 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env48213 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,8460,65536,131072,157752,304,8461,2097152,221243,147457,3,8193,16,10508,2170939,2232369,149812,221230,2228241,256,2301978,2318395,147985]

theorem envBound48213 : H12AffineFastState.Bounded env48213 := by
  intro p hp
  have h : env48213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48212_48213 : H12AffineEnvironment.transform 14 8460 env48212 = env48213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env48212 == env48213) = true)

theorem identity48213 : scanCanonicalize (H12AffineFastState.compose env48213 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound48213 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48214 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,8192,16384,8460,65536,131072,157752,304,8461,82215,221243,147457,3,8193,16,10508,24860,217366,149812,221230,213302,256,155965,139548,147985]

theorem envBound48214 : H12AffineFastState.Bounded env48214 := by
  intro p hp
  have h : env48214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48213_48214 : H12AffineEnvironment.transform 20 82215 env48213 = env48214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env48213 == env48214) = true)

theorem identity48214 : scanCanonicalize (H12AffineFastState.compose env48214 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48214 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env48215 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,16384,0,65536,131072,149812,304,1,82215,213303,147457,3,269,16,2048,16400,217366,149812,213282,213302,256,147505,131088,147985]

theorem envBound48215 : H12AffineFastState.Bounded env48215 := by
  intro p hp
  have h : env48215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48214_48215 : H12AffineEnvironment.transform 12 268 env48214 = env48215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48214 == env48215) = true)

theorem identity48215 : scanCanonicalize (H12AffineFastState.compose env48215 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48215 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48216 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,4113,0,65536,131072,137509,304,1,69942,200998,135184,3,269,16,2048,4097,196871,137509,201011,200999,256,135200,131088,135680]

theorem envBound48216 : H12AffineFastState.Bounded env48216 := by
  intro p hp
  have h : env48216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48215_48216 : H12AffineEnvironment.transform 13 4113 env48215 = env48216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48215 == env48216) = true)

theorem identity48216 : scanCanonicalize (H12AffineFastState.compose env48216 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound48216 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env48217 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,4096,268,4113,0,65536,69894,67619,304,1,69942,32,65814,3,269,16,2048,4097,4097,67619,53,33,256,65830,69910,66310]

theorem envBound48217 : H12AffineFastState.Bounded env48217 := by
  intro p hp
  have h : env48217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48216_48217 : H12AffineEnvironment.transform 16 69894 env48216 = env48217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env48216 == env48217) = true)

theorem identity48217 : scanCanonicalize (H12AffineFastState.compose env48217 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound48217 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env48218 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,2325,268,2308,0,65536,67603,67619,304,1,67619,32,65814,3,269,16,2048,2324,2324,67619,53,33,256,65830,67587,66310]

theorem envBound48218 : H12AffineFastState.Bounded env48218 := by
  intro p hp
  have h : env48218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48217_48218 : H12AffineEnvironment.transform 11 2325 env48217 = env48218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env48217 == env48218) = true)

theorem identity48218 : scanCanonicalize (H12AffineFastState.compose env48218 (packedSelected [4,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48218 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env48219 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,2064,9,2049,0,65536,67603,67619,53,1,67619,32,65555,3,8,16,2048,2065,2065,67619,53,33,5,65571,67587,66051]

theorem envBound48219 : H12AffineFastState.Bounded env48219 := by
  intro p hp
  have h : env48219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48218_48219 : H12AffineEnvironment.transform 7 5 env48218 = env48219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48218 == env48219) = true)

theorem identity48219 : scanCanonicalize (H12AffineFastState.compose env48219 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound48219 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env48220 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,2064,9,2049,0,3,2064,2080,53,1,2080,32,16,3,8,16,2048,2065,2065,2080,53,33,5,32,2048,512]

theorem envBound48220 : H12AffineFastState.Bounded env48220 := by
  intro p hp
  have h : env48220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48219_48220 : H12AffineEnvironment.transform 15 3 env48219 = env48220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env48219 == env48220) = true)

theorem identity48220 : scanCanonicalize (H12AffineFastState.compose env48220 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound48220 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48221 : List Nat := [2,4,8,16,32,16,9,5,21,53,2048,2064,9,2049,0,3,2064,2080,53,1,2080,32,16,3,8,16,2048,2065,2065,2080,53,33,5,32,2048,21]

theorem envBound48221 : H12AffineFastState.Bounded env48221 := by
  intro p hp
  have h : env48221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48220_48221 : H12AffineEnvironment.transform 8 21 env48220 = env48221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env48220 == env48221) = true)

theorem identity48221 : scanCanonicalize (H12AffineFastState.compose env48221 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48222 : List Nat := [2,4,8,16,0,16,9,5,21,21,2048,2064,9,2049,0,3,2064,2048,21,1,2048,0,16,3,8,16,2048,2065,2065,2048,21,1,5,0,2048,21]

theorem envBound48222 : H12AffineFastState.Bounded env48222 := by
  intro p hp
  have h : env48222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48221_48222 : H12AffineEnvironment.transform 4 0 env48221 = env48222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48221 == env48222) = true)

theorem identity48222 : scanCanonicalize (H12AffineFastState.compose env48222 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48223 : List Nat := [2,4,8,5,0,5,9,5,0,0,2048,2053,9,2049,0,3,2053,2048,0,1,2048,0,5,3,8,5,2048,2052,2052,2048,0,1,5,0,2048,0]

theorem envBound48223 : H12AffineFastState.Bounded env48223 := by
  intro p hp
  have h : env48223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48222_48223 : H12AffineEnvironment.transform 3 5 env48222 = env48223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48222 == env48223) = true)

def leafEnv48223 : List Nat := [2,4,8,5,0,5,9,5,0,0,2048,2053,9,2049,0,3,2053,2048,0,1,2048,0,5,3,0,8,1,5,2048,2052,2052,2048,0,1,5,0,4,2,2048,0,1,2049,0]

def active48223 : List Nat := [0,1,2,10]

def tree48223 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48223 : H12WitnessSearch.Good tree48223 := H12GlobalWitnessIndex.good

theorem leafIdentity48223 : H12AffineFastState.composeSystem env48223 rootObs = leafEnv48223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48223 rootObs == leafEnv48223) = true)

theorem terminalChecked48223 : H12PackedTerminal.terminalCheckFast leafEnv48223 active48223 tree48223 = true := by decide +kernel

def env48224 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,4194304,147457,3,8193,16,4450363,2195766,2232368,190520,246051,6381611,256,2326807,2318394,189213]

theorem envBound48224 : H12AffineFastState.Bounded env48224 := by
  intro p hp
  have h : env48224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48210_48224 : H12AffineEnvironment.transform 9 305 env48210 = env48224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env48210 == env48224) = true)

theorem identity48224 : scanCanonicalize (H12AffineFastState.compose env48224 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound48224 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env48225 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,73771,147457,3,8193,16,182288,2195766,2232368,190520,246051,2113536,256,2326807,2318394,189213]

theorem envBound48225 : H12AffineFastState.Bounded env48225 := by
  intro p hp
  have h : env48225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48224_48225 : H12AffineEnvironment.transform 21 73771 env48224 = env48225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env48224 == env48225) = true)

theorem identity48225 : scanCanonicalize (H12AffineFastState.compose env48225 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(20+1) ^^^ 49185) := by decide +kernel

theorem selectedBound48225 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env48226 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,49185,73771,147457,3,8193,16,182288,82199,184337,190520,246051,32801,256,213302,237595,189213]

theorem envBound48226 : H12AffineFastState.Bounded env48226 := by
  intro p hp
  have h : env48226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48225_48226 : H12AffineEnvironment.transform 20 49185 env48225 = env48226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49185 env48225 == env48226) = true)

theorem identity48226 : scanCanonicalize (H12AffineFastState.compose env48226 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48226 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env48227 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,0,65536,131072,157752,305,1,16417,73771,147457,3,8193,16,149520,82199,151569,157752,213283,33,256,213302,204827,156445]

theorem envBound48227 : H12AffineFastState.Bounded env48227 := by
  intro p hp
  have h : env48227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48226_48227 : H12AffineEnvironment.transform 14 0 env48226 = env48227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48226 == env48227) = true)

theorem identity48227 : scanCanonicalize (H12AffineFastState.compose env48227 (packedSelected [1,3,4,5,8,10,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48227 : packedSelected [1,3,4,5,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48228 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,0,263,131072,157752,305,1,16417,8492,147457,3,8193,16,149520,16400,151569,157752,147492,33,256,147505,139548,156445]

theorem envBound48228 : H12AffineFastState.Bounded env48228 := by
  intro p hp
  have h : env48228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48227_48228 : H12AffineEnvironment.transform 15 263 env48227 = env48228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48227 == env48228) = true)

theorem identity48228 : scanCanonicalize (H12AffineFastState.compose env48228 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 12296) := by decide +kernel

theorem selectedBound48228 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48229 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,16384,0,263,12296,22576,305,1,16417,8492,28681,3,8193,16,30744,16400,24601,22576,28716,33,256,28729,4372,21269]

theorem envBound48229 : H12AffineFastState.Bounded env48229 := by
  intro p hp
  have h : env48229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48228_48229 : H12AffineEnvironment.transform 16 12296 env48228 = env48229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12296 env48228 == env48229) = true)

theorem identity48229 : scanCanonicalize (H12AffineFastState.compose env48229 (packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound48229 : packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env48230 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,8192,4373,0,263,12296,2341,305,1,4404,8492,8476,3,8193,16,10509,4357,12556,2341,8505,33,256,8492,4372,512]

theorem envBound48230 : H12AffineFastState.Bounded env48230 := by
  intro p hp
  have h : env48230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48229_48230 : H12AffineEnvironment.transform 13 4373 env48229 = env48230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env48229 == env48230) = true)

theorem identity48230 : scanCanonicalize (H12AffineFastState.compose env48230 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound48230 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48231 : List Nat := [2,4,8,16,32,16,9,256,512,305,783,4096,8192,4373,0,263,12296,554,305,1,4404,8492,8476,3,8193,16,8706,4357,12556,554,8505,33,256,8492,4372,512]

theorem envBound48231 : H12AffineFastState.Bounded env48231 := by
  intro p hp
  have h : env48231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48230_48231 : H12AffineEnvironment.transform 10 783 env48230 = env48231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env48230 == env48231) = true)

theorem identity48231 : scanCanonicalize (H12AffineFastState.compose env48231 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48231 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48232 : List Nat := [2,4,8,16,1,16,9,256,512,272,783,4096,8192,4373,0,263,12296,523,272,1,4373,8461,8476,3,8193,16,8706,4357,12556,523,8472,0,256,8461,4372,512]

theorem envBound48232 : H12AffineFastState.Bounded env48232 := by
  intro p hp
  have h : env48232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48231_48232 : H12AffineEnvironment.transform 4 1 env48231 = env48232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48231 == env48232) = true)

theorem identity48232 : scanCanonicalize (H12AffineFastState.compose env48232 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48232 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48233 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,4096,8192,4112,0,2,12296,523,21,1,4112,8200,8217,3,8193,16,8706,4096,12297,523,8221,0,5,8200,4113,512]

theorem envBound48233 : H12AffineFastState.Bounded env48233 := by
  intro p hp
  have h : env48233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48232_48233 : H12AffineEnvironment.transform 7 5 env48232 = env48233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48232 == env48233) = true)

theorem identity48233 : scanCanonicalize (H12AffineFastState.compose env48233 (packedSelected [0,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound48233 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env48234 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,4096,5,4112,0,2,4109,523,21,1,4112,13,28,3,4,16,519,4096,4108,523,24,0,5,13,4113,512]

theorem envBound48234 : H12AffineFastState.Bounded env48234 := by
  intro p hp
  have h : env48234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48233_48234 : H12AffineEnvironment.transform 12 5 env48233 = env48234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env48233 == env48234) = true)

theorem identity48234 : scanCanonicalize (H12AffineFastState.compose env48234 (packedSelected [1,7] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound48234 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env48235 : List Nat := [2,4,8,16,1,16,9,5,14,21,4,4096,5,4112,0,2,4109,5,21,1,4112,13,28,3,4,16,9,4096,4108,5,24,0,5,13,4113,14]

theorem envBound48235 : H12AffineFastState.Bounded env48235 := by
  intro p hp
  have h : env48235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48234_48235 : H12AffineEnvironment.transform 8 14 env48234 = env48235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env48234 == env48235) = true)

theorem identity48235 : scanCanonicalize (H12AffineFastState.compose env48235 (packedSelected [2,11] rootPS)) = affineNative (2^(11+1) ^^^ 28) := by decide +kernel

theorem selectedBound48235 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env48236 : List Nat := [2,4,8,16,1,16,9,5,14,21,4,28,5,12,0,2,17,5,21,1,12,13,28,3,4,16,9,28,16,5,24,0,5,13,13,14]

theorem envBound48236 : H12AffineFastState.Bounded env48236 := by
  intro p hp
  have h : env48236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48235_48236 : H12AffineEnvironment.transform 11 28 env48235 = env48236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 28 env48235 == env48236) = true)

theorem identity48236 : scanCanonicalize (H12AffineFastState.compose env48236 (packedSelected [0,1,12] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48236 : packedSelected [0,1,12] rootPS < 2^1333 := by decide +kernel

def env48237 : List Nat := [2,0,8,16,1,16,9,1,10,17,0,24,1,8,0,2,17,1,17,1,8,9,24,3,0,16,9,24,16,1,24,0,1,9,9,10]

theorem envBound48237 : H12AffineFastState.Bounded env48237 := by
  intro p hp
  have h : env48237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48236_48237 : H12AffineEnvironment.transform 1 0 env48236 = env48237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48236 == env48237) = true)

theorem identity48237 : scanCanonicalize (H12AffineFastState.compose env48237 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48237 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48238 : List Nat := [2,0,1,16,1,16,0,1,3,17,0,17,1,1,0,2,17,1,17,1,1,0,17,3,0,16,0,17,16,1,17,0,1,0,0,3]

theorem envBound48238 : H12AffineFastState.Bounded env48238 := by
  intro p hp
  have h : env48238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48237_48238 : H12AffineEnvironment.transform 2 1 env48237 = env48238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48237 == env48238) = true)

def env48239 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1024,32769,2097152,4194304,147457,3,8193,17,4450363,2196487,2233600,190520,246802,6382875,256,2327590,2319627,189212]

theorem envBound48239 : H12AffineFastState.Bounded env48239 := by
  intro p hp
  have h : env48239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48209_48239 : H12AffineEnvironment.transform 5 17 env48209 = env48239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48209 == env48239) = true)

def env48240 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,4194304,147457,3,8193,17,4450363,2195767,2232368,190520,246050,6381611,256,2326806,2318395,189212]

theorem envBound48240 : H12AffineFastState.Bounded env48240 := by
  intro p hp
  have h : env48240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48239_48240 : H12AffineEnvironment.transform 9 304 env48239 = env48240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env48239 == env48240) = true)

theorem identity48240 : scanCanonicalize (H12AffineFastState.compose env48240 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 188733) := by decide +kernel

theorem selectedBound48240 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env48241 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,131072,157752,304,32769,2097152,188733,147457,3,8193,17,67846,2195767,2232368,190520,246050,2326806,256,2326806,2318395,189212]

theorem envBound48241 : H12AffineFastState.Bounded env48241 := by
  intro p hp
  have h : env48241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48240_48241 : H12AffineEnvironment.transform 21 188733 env48240 = env48241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188733 env48240 == env48241) = true)

theorem identity48241 : scanCanonicalize (H12AffineFastState.compose env48241 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound48241 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env48242 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,114966,108846,304,32769,2097152,73771,98583,3,8193,17,67846,2195767,2216230,76078,52,2113536,256,2113536,2138413,74250]

theorem envBound48242 : H12AffineFastState.Bounded env48242 := by
  intro p hp
  have h : env48242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48241_48242 : H12AffineEnvironment.transform 16 114966 env48241 = env48242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env48241 == env48242) = true)

theorem identity48242 : scanCanonicalize (H12AffineFastState.compose env48242 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 16417) := by decide +kernel

theorem selectedBound48242 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env48243 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,65536,114966,108846,304,32769,16417,73771,98583,3,8193,17,67846,114966,102663,76078,52,33,256,33,57612,74250]

theorem envBound48243 : H12AffineFastState.Bounded env48243 := by
  intro p hp
  have h : env48243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48242_48243 : H12AffineEnvironment.transform 20 16417 env48242 = env48243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16417 env48242 == env48243) = true)

theorem identity48243 : scanCanonicalize (H12AffineFastState.compose env48243 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound48243 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48244 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,32768,40971,24861,2341,304,32769,16417,32800,8476,3,8193,17,43277,24861,12556,35109,52,33,256,33,57612,33281]

theorem envBound48244 : H12AffineFastState.Bounded env48244 := by
  intro p hp
  have h : env48244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48243_48244 : H12AffineEnvironment.transform 15 40971 env48243 = env48244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env48243 == env48244) = true)

theorem identity48244 : scanCanonicalize (H12AffineFastState.compose env48244 (packedSelected [0,6,7,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 31037) := by decide +kernel

theorem selectedBound48244 : packedSelected [0,6,7,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48245 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,16384,31037,22838,24861,2341,304,31036,16417,31005,8476,3,8193,17,20528,24861,12556,28696,52,33,256,33,6193,31548]

theorem envBound48245 : H12AffineFastState.Bounded env48245 := by
  intro p hp
  have h : env48245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48244_48245 : H12AffineEnvironment.transform 14 31037 env48244 = env48245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 31037 env48244 == env48245) = true)

theorem identity48245 : scanCanonicalize (H12AffineFastState.compose env48245 (packedSelected [6,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48245 : packedSelected [6,14,15,17] rootPS < 2^1333 := by decide +kernel

def env48246 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,269,16384,22576,22838,16400,2341,304,22577,16417,22544,17,3,268,17,20528,16400,4097,20757,52,33,256,33,6193,23089]

theorem envBound48246 : H12AffineFastState.Bounded env48246 := by
  intro p hp
  have h : env48246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48245_48246 : H12AffineEnvironment.transform 12 269 env48245 = env48246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48245 == env48246) = true)

theorem identity48246 : scanCanonicalize (H12AffineFastState.compose env48246 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48246 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48247 : List Nat := [2,4,8,16,32,17,9,256,512,304,1,4096,269,16384,20529,20791,16400,292,304,20528,16417,20497,17,3,268,17,20528,16400,4097,20757,52,33,256,33,4144,21040]

theorem envBound48247 : H12AffineFastState.Bounded env48247 := by
  intro p hp
  have h : env48247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48246_48247 : H12AffineEnvironment.transform 10 1 env48246 = env48247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48246 == env48247) = true)

theorem identity48247 : scanCanonicalize (H12AffineFastState.compose env48247 (packedSelected [2,4,7] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound48247 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48248 : List Nat := [2,4,8,16,32,17,9,256,512,304,1,4096,269,292,4373,4115,308,292,304,4372,261,4405,17,3,268,17,4372,308,4097,4145,52,33,256,33,4144,4884]

theorem envBound48248 : H12AffineFastState.Bounded env48248 := by
  intro p hp
  have h : env48248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48247_48248 : H12AffineEnvironment.transform 13 292 env48247 = env48248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env48247 == env48248) = true)

theorem identity48248 : scanCanonicalize (H12AffineFastState.compose env48248 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48248 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env48249 : List Nat := [2,4,8,16,32,17,9,37,512,21,1,4096,40,1,4144,4115,17,1,21,4145,32,4112,17,3,41,17,4145,17,4097,4145,52,33,37,33,4144,4657]

theorem envBound48249 : H12AffineFastState.Bounded env48249 := by
  intro p hp
  have h : env48249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48248_48249 : H12AffineEnvironment.transform 7 37 env48248 = env48249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48248 == env48249) = true)

theorem identity48249 : scanCanonicalize (H12AffineFastState.compose env48249 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 543) := by decide +kernel

theorem selectedBound48249 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env48250 : List Nat := [2,4,8,16,32,17,9,37,512,21,1,543,40,1,559,524,17,1,21,558,32,527,17,3,41,17,558,17,542,558,52,33,37,33,559,46]

theorem envBound48250 : H12AffineFastState.Bounded env48250 := by
  intro p hp
  have h : env48250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48249_48250 : H12AffineEnvironment.transform 11 543 env48249 = env48250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 543 env48249 == env48250) = true)

theorem identity48250 : scanCanonicalize (H12AffineFastState.compose env48250 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound48250 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48251 : List Nat := [2,4,8,16,32,17,9,37,46,21,1,49,40,1,1,34,17,1,21,0,32,33,17,3,41,17,0,17,48,0,52,33,37,33,1,46]

theorem envBound48251 : H12AffineFastState.Bounded env48251 := by
  intro p hp
  have h : env48251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48250_48251 : H12AffineEnvironment.transform 8 46 env48250 = env48251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env48250 == env48251) = true)

theorem identity48251 : scanCanonicalize (H12AffineFastState.compose env48251 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48252 : List Nat := [2,1,8,16,32,17,9,32,43,16,1,49,40,1,1,34,17,1,16,0,32,33,17,3,41,17,0,17,48,0,49,33,32,33,1,43]

theorem envBound48252 : H12AffineFastState.Bounded env48252 := by
  intro p hp
  have h : env48252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48251_48252 : H12AffineEnvironment.transform 1 1 env48251 = env48252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48251 == env48252) = true)

theorem identity48252 : scanCanonicalize (H12AffineFastState.compose env48252 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound48252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48253 : List Nat := [2,1,8,16,9,17,9,9,2,16,1,24,1,1,1,11,17,1,16,0,9,8,17,3,0,17,0,17,25,0,24,8,9,8,1,2]

theorem envBound48253 : H12AffineFastState.Bounded env48253 := by
  intro p hp
  have h : env48253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48252_48253 : H12AffineEnvironment.transform 4 9 env48252 = env48253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env48252 == env48253) = true)

theorem identity48253 : scanCanonicalize (H12AffineFastState.compose env48253 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48254 : List Nat := [2,1,0,16,1,17,1,1,2,16,1,16,1,1,1,3,17,1,16,0,1,0,17,3,0,17,0,17,17,0,16,0,1,0,1,2]

theorem envBound48254 : H12AffineFastState.Bounded env48254 := by
  intro p hp
  have h : env48254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48253_48254 : H12AffineEnvironment.transform 2 0 env48253 = env48254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48253 == env48254) = true)

def env48255 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,4194304,147457,3,8193,17,4450363,2195766,2232369,190520,246051,6381610,256,2326807,2318394,189212]

theorem envBound48255 : H12AffineFastState.Bounded env48255 := by
  intro p hp
  have h : env48255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48239_48255 : H12AffineEnvironment.transform 9 305 env48239 = env48255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env48239 == env48255) = true)

theorem identity48255 : scanCanonicalize (H12AffineFastState.compose env48255 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound48255 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env48256 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,32768,65536,131072,157752,305,32769,2097152,32,147457,3,8193,17,256027,2195766,2232369,190520,246051,2187274,256,2326807,2318394,189212]

theorem envBound48256 : H12AffineFastState.Bounded env48256 := by
  intro p hp
  have h : env48256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48255_48256 : H12AffineEnvironment.transform 21 32 env48255 = env48256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env48255 == env48256) = true)

theorem identity48256 : scanCanonicalize (H12AffineFastState.compose env48256 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound48256 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env48257 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,8192,16384,8461,65536,131072,157752,305,8460,2097152,32,147457,3,8193,17,215318,2170939,2232369,149813,221230,2187274,256,2301978,2318394,147985]

theorem envBound48257 : H12AffineFastState.Bounded env48257 := by
  intro p hp
  have h : env48257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48256_48257 : H12AffineEnvironment.transform 14 8461 env48256 = env48257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env48256 == env48257) = true)

theorem identity48257 : scanCanonicalize (H12AffineFastState.compose env48257 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48257 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env48258 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,1,65536,131072,149812,305,0,2097152,32,147457,3,269,17,215318,2162999,2232369,149813,213282,2179334,256,2294038,2310454,147985]

theorem envBound48258 : H12AffineFastState.Bounded env48258 := by
  intro p hp
  have h : env48258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48257_48258 : H12AffineEnvironment.transform 12 268 env48257 = env48258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48257 == env48258) = true)

theorem identity48258 : scanCanonicalize (H12AffineFastState.compose env48258 (packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 196918) := by decide +kernel

theorem selectedBound48258 : packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS < 2^1333 := by decide +kernel

def env48259 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,1,65536,131072,149812,305,0,196918,32,147457,3,269,17,215318,131073,69895,149813,213282,147504,256,32,16384,147985]

theorem envBound48259 : H12AffineFastState.Bounded env48259 := by
  intro p hp
  have h : env48259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48258_48259 : H12AffineEnvironment.transform 20 196918 env48258 = env48259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 196918 env48258 == env48259) = true)

theorem identity48259 : scanCanonicalize (H12AffineFastState.compose env48259 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound48259 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48260 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,16384,1,65536,82199,67619,305,0,16417,32,65814,3,269,17,2049,82198,69895,67618,53,65831,256,32,16384,66310]

theorem envBound48260 : H12AffineFastState.Bounded env48260 := by
  intro p hp
  have h : env48260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48259_48260 : H12AffineEnvironment.transform 16 82199 env48259 = env48260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env48259 == env48260) = true)

theorem identity48260 : scanCanonicalize (H12AffineFastState.compose env48260 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound48260 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env48261 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,4405,1,65536,69666,67619,305,0,4372,32,65814,3,269,17,2049,69667,69895,67618,53,65831,256,32,4405,66310]

theorem envBound48261 : H12AffineFastState.Bounded env48261 := by
  intro p hp
  have h : env48261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48260_48261 : H12AffineEnvironment.transform 13 4405 env48260 = env48261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env48260 == env48261) = true)

theorem identity48261 : scanCanonicalize (H12AffineFastState.compose env48261 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound48261 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env48262 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,4096,268,4405,1,295,4357,2308,305,0,4372,32,49,3,269,17,2049,4356,4128,2309,53,0,256,32,4405,545]

theorem envBound48262 : H12AffineFastState.Bounded env48262 := by
  intro p hp
  have h : env48262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48261_48262 : H12AffineEnvironment.transform 15 295 env48261 = env48262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env48261 == env48262) = true)

theorem identity48262 : scanCanonicalize (H12AffineFastState.compose env48262 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48262 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48263 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,268,4372,1,262,4357,2308,272,0,4372,1,16,3,269,17,2049,4356,4097,2309,20,0,256,1,4372,512]

theorem envBound48263 : H12AffineFastState.Bounded env48263 := by
  intro p hp
  have h : env48263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48262_48263 : H12AffineEnvironment.transform 4 1 env48262 = env48263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48262 == env48263) = true)

theorem identity48263 : scanCanonicalize (H12AffineFastState.compose env48263 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48264 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4113,1,3,4096,2049,21,0,4113,1,16,3,8,17,2049,4097,4097,2048,20,0,5,1,4113,512]

theorem envBound48264 : H12AffineFastState.Bounded env48264 := by
  intro p hp
  have h : env48264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48263_48264 : H12AffineEnvironment.transform 7 5 env48263 = env48264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48263 == env48264) = true)

theorem identity48264 : scanCanonicalize (H12AffineFastState.compose env48264 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound48264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48265 : List Nat := [2,4,8,16,1,17,9,5,512,21,512,4096,9,4113,1,3,4096,513,21,0,4113,1,16,3,8,17,513,4097,4097,512,20,0,5,1,4113,512]

theorem envBound48265 : H12AffineFastState.Bounded env48265 := by
  intro p hp
  have h : env48265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48264_48265 : H12AffineEnvironment.transform 10 512 env48264 = env48265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env48264 == env48265) = true)

theorem identity48265 : scanCanonicalize (H12AffineFastState.compose env48265 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48266 : List Nat := [2,4,8,5,1,4,9,5,512,0,512,4096,9,4100,1,3,4096,513,0,0,4100,1,5,3,8,4,513,4097,4097,512,1,0,5,1,4100,512]

theorem envBound48266 : H12AffineFastState.Bounded env48266 := by
  intro p hp
  have h : env48266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48265_48266 : H12AffineEnvironment.transform 3 5 env48265 = env48266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48265 == env48266) = true)

def env48267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,138,8328,64,4554754,2196487,2233817,295048,246803,6382922,256,2327726,2319626,189381]

theorem envBound48267 : H12AffineFastState.Bounded env48267 := by
  intro p hp
  have h : env48267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48173_48267 : H12AffineEnvironment.transform 22 147593 env48173 = env48267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env48173 == env48267) = true)

def env48268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,138,8328,64,4450482,2196487,2233817,190520,246803,6382922,256,2327726,2319626,189381]

theorem envBound48268 : H12AffineFastState.Bounded env48268 := by
  intro p hp
  have h : env48268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48267_48268 : H12AffineEnvironment.transform 17 157872 env48267 = env48268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env48267 == env48268) = true)

theorem identity48268 : scanCanonicalize (H12AffineFastState.compose env48268 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound48268 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,4194304,41293,138,8328,64,4262262,2196487,2159645,2556,75223,6382922,256,2188650,2196686,513]

theorem envBound48269 : H12AffineFastState.Bounded env48269 := by
  intro p hp
  have h : env48269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48268_48269 : H12AffineEnvironment.transform 16 57796 env48268 = env48269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env48268 == env48269) = true)

theorem identity48269 : scanCanonicalize (H12AffineFastState.compose env48269 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound48269 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,57796,35188,1024,32769,2097152,4194304,41293,138,8328,64,4229288,2098649,2159645,2556,41993,6349972,256,2155700,2098448,513]

theorem envBound48270 : H12AffineFastState.Bounded env48270 := by
  intro p hp
  have h : env48270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48269_48270 : H12AffineEnvironment.transform 15 33246 env48269 = env48270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env48269 == env48270) = true)

def env48271 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,57748,35108,1024,32769,2097152,4194304,41245,138,8328,16,4229288,2098569,2159645,2476,41993,6349972,256,2155700,2098448,513]

theorem envBound48271 : H12AffineFastState.Bounded env48271 := by
  intro p hp
  have h : env48271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48270_48271 : H12AffineEnvironment.transform 5 16 env48270 = env48271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48270 == env48271) = true)

theorem identity48271 : scanCanonicalize (H12AffineFastState.compose env48271 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound48271 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env48272 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,57748,35108,1024,32769,2097152,8612,41245,138,8328,16,43276,2098569,2159645,2476,41993,2147632,256,2155700,2098448,513]

theorem envBound48272 : H12AffineFastState.Bounded env48272 := by
  intro p hp
  have h : env48272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48271_48272 : H12AffineEnvironment.transform 21 8612 env48271 = env48272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env48271 == env48272) = true)

theorem identity48272 : scanCanonicalize (H12AffineFastState.compose env48272 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48272 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env48273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,33166,49305,35108,1024,32769,2097152,169,32784,138,389,16,34817,2098569,2151696,2476,34052,2147632,256,2147769,2098448,513]

theorem envBound48273 : H12AffineFastState.Bounded env48273 := by
  intro p hp
  have h : env48273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48272_48273 : H12AffineEnvironment.transform 12 269 env48272 = env48273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48272 == env48273) = true)

theorem identity48273 : scanCanonicalize (H12AffineFastState.compose env48273 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48273 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env48274 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,0,398,16537,2340,1024,1,2097152,169,16,138,389,16,2049,2098569,2118928,2476,1284,2114864,256,2115001,2098448,513]

theorem envBound48274 : H12AffineFastState.Bounded env48274 := by
  intro p hp
  have h : env48274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48273_48274 : H12AffineEnvironment.transform 14 0 env48273 = env48274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48273 == env48274) = true)

theorem identity48274 : scanCanonicalize (H12AffineFastState.compose env48274 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound48274 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48275 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,4249,0,398,4096,2340,1024,1,2097152,169,16,138,389,16,2049,2098569,2098569,2476,1284,2102697,256,2102560,2098448,513]

theorem envBound48275 : H12AffineFastState.Bounded env48275 := by
  intro p hp
  have h : env48275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48274_48275 : H12AffineEnvironment.transform 13 4249 env48274 = env48275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env48274 == env48275) = true)

theorem identity48275 : scanCanonicalize (H12AffineFastState.compose env48275 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48275 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48276 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4113,0,262,4096,2340,1024,1,2097152,33,16,2,269,16,2049,2098433,2098433,2340,1284,2102561,256,2102560,2098448,513]

theorem envBound48276 : H12AffineFastState.Bounded env48276 := by
  intro p hp
  have h : env48276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48275_48276 : H12AffineEnvironment.transform 6 8 env48275 = env48276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48275 == env48276) = true)

theorem identity48276 : scanCanonicalize (H12AffineFastState.compose env48276 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 4129) := by decide +kernel

theorem selectedBound48276 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48277 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,4113,0,262,4096,2340,1024,1,4129,33,16,2,269,16,2049,5408,5408,2340,1284,1280,256,1281,5425,513]

theorem envBound48277 : H12AffineFastState.Bounded env48277 := by
  intro p hp
  have h : env48277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48276_48277 : H12AffineEnvironment.transform 20 4129 env48276 = env48277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4129 env48276 == env48277) = true)

theorem identity48277 : scanCanonicalize (H12AffineFastState.compose env48277 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound48277 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48278 : List Nat := [2,4,8,16,32,16,8,256,512,1024,560,4096,269,4113,0,262,4096,788,1024,1,4129,33,16,2,269,16,561,5408,5408,788,1284,1280,256,1281,5425,513]

theorem envBound48278 : H12AffineFastState.Bounded env48278 := by
  intro p hp
  have h : env48278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48277_48278 : H12AffineEnvironment.transform 10 560 env48277 = env48278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env48277 == env48278) = true)

theorem identity48278 : scanCanonicalize (H12AffineFastState.compose env48278 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48278 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48279 : List Nat := [2,4,8,16,32,16,8,256,512,20,560,4096,269,4113,0,262,4096,788,20,1,4129,33,16,2,269,16,561,4404,4404,788,272,276,256,277,4389,513]

theorem envBound48279 : H12AffineFastState.Bounded env48279 := by
  intro p hp
  have h : env48279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48278_48279 : H12AffineEnvironment.transform 9 20 env48278 = env48279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48278 == env48279) = true)

theorem identity48279 : scanCanonicalize (H12AffineFastState.compose env48279 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48279 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env48280 : List Nat := [2,4,8,16,0,16,8,256,512,20,528,4096,269,4113,0,262,4096,788,20,1,4097,1,16,2,269,16,529,4372,4372,788,272,276,256,277,4357,513]

theorem envBound48280 : H12AffineFastState.Bounded env48280 := by
  intro p hp
  have h : env48280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48279_48280 : H12AffineEnvironment.transform 4 0 env48279 = env48280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48279 == env48280) = true)

theorem identity48280 : scanCanonicalize (H12AffineFastState.compose env48280 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound48280 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48281 : List Nat := [2,4,8,16,0,16,8,256,512,20,528,772,269,789,0,262,772,788,20,1,773,1,16,2,269,16,529,528,528,788,272,276,256,277,513,513]

theorem envBound48281 : H12AffineFastState.Bounded env48281 := by
  intro p hp
  have h : env48281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48280_48281 : H12AffineEnvironment.transform 11 772 env48280 = env48281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env48280 == env48281) = true)

theorem identity48281 : scanCanonicalize (H12AffineFastState.compose env48281 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48281 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48282 : List Nat := [2,4,8,16,0,16,8,4,512,20,528,512,9,529,0,2,512,528,20,1,513,1,16,2,9,16,529,528,528,528,20,16,4,17,513,513]

theorem envBound48282 : H12AffineFastState.Bounded env48282 := by
  intro p hp
  have h : env48282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48281_48282 : H12AffineEnvironment.transform 7 4 env48281 = env48282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48281 == env48282) = true)

def env48283 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33167,57749,35109,1024,32769,2097152,4194304,41244,138,8328,17,4229288,2098568,2159645,2477,41993,6349972,256,2155700,2098448,513]

theorem envBound48283 : H12AffineFastState.Bounded env48283 := by
  intro p hp
  have h : env48283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48270_48283 : H12AffineEnvironment.transform 5 17 env48270 = env48283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48270 == env48283) = true)

theorem identity48283 : scanCanonicalize (H12AffineFastState.compose env48283 (packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound48283 : packedSelected [2,4,6,7,9,15,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env48284 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,262,24860,2476,1024,136,2097152,4194304,8597,138,8328,17,4196385,2098568,2126996,2477,9344,6317085,256,2122813,2098448,513]

theorem envBound48284 : H12AffineFastState.Bounded env48284 := by
  intro p hp
  have h : env48284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48283_48284 : H12AffineEnvironment.transform 14 137 env48283 = env48284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env48283 == env48284) = true)

theorem identity48284 : scanCanonicalize (H12AffineFastState.compose env48284 (packedSelected [7,14,18,20,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound48284 : packedSelected [7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env48285 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,262,24860,2476,1024,136,2097152,8492,8597,138,8328,17,10509,2098568,2126996,2477,9344,2114865,256,2122813,2098448,513]

theorem envBound48285 : H12AffineFastState.Bounded env48285 := by
  intro p hp
  have h : env48285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48284_48285 : H12AffineEnvironment.transform 21 8492 env48284 = env48285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env48284 == env48285) = true)

theorem identity48285 : scanCanonicalize (H12AffineFastState.compose env48285 (packedSelected [2,6,17] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound48285 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env48286 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,262,24860,2476,1024,136,17680,8492,8597,138,8328,17,10509,16536,12676,2477,9344,33,256,8493,16384,513]

theorem envBound48286 : H12AffineFastState.Bounded env48286 := by
  intro p hp
  have h : env48286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48285_48286 : H12AffineEnvironment.transform 20 17680 env48285 = env48286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env48285 == env48286) = true)

theorem identity48286 : scanCanonicalize (H12AffineFastState.compose env48286 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound48286 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48287 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,262,16537,2476,1024,136,17680,169,16,138,269,17,2184,16536,4097,2477,1285,33,256,168,16384,513]

theorem envBound48287 : H12AffineFastState.Bounded env48287 := by
  intro p hp
  have h : env48287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48286_48287 : H12AffineEnvironment.transform 12 389 env48286 = env48287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env48286 == env48287) = true)

theorem identity48287 : scanCanonicalize (H12AffineFastState.compose env48287 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound48287 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48288 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,4249,137,262,4096,2476,1024,136,5513,169,16,138,269,17,2184,4097,4097,2477,1285,33,256,168,4249,513]

theorem envBound48288 : H12AffineFastState.Bounded env48288 := by
  intro p hp
  have h : env48288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48287_48288 : H12AffineEnvironment.transform 13 4249 env48287 = env48288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env48287 == env48288) = true)

theorem identity48288 : scanCanonicalize (H12AffineFastState.compose env48288 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48288 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env48289 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4112,0,262,4096,2341,1024,1,5376,32,16,3,269,17,2049,4097,4097,2340,1285,33,256,33,4112,513]

theorem envBound48289 : H12AffineFastState.Bounded env48289 := by
  intro p hp
  have h : env48289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48288_48289 : H12AffineEnvironment.transform 6 9 env48288 = env48289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48288 == env48289) = true)

theorem identity48289 : scanCanonicalize (H12AffineFastState.compose env48289 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48290 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4112,0,262,4096,2341,52,1,4404,32,16,3,269,17,2049,4097,4097,2340,305,33,256,33,4112,513]

theorem envBound48290 : H12AffineFastState.Bounded env48290 := by
  intro p hp
  have h : env48290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48289_48290 : H12AffineEnvironment.transform 9 52 env48289 = env48290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48289 == env48290) = true)

theorem identity48290 : scanCanonicalize (H12AffineFastState.compose env48290 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2853) := by decide +kernel

theorem selectedBound48290 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48291 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2853,268,2869,0,262,2853,2341,52,1,2577,32,16,3,269,17,2049,2852,2852,2340,305,33,256,33,2869,513]

theorem envBound48291 : H12AffineFastState.Bounded env48291 := by
  intro p hp
  have h : env48291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48290_48291 : H12AffineEnvironment.transform 11 2853 env48290 = env48291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2853 env48290 == env48291) = true)

theorem identity48291 : scanCanonicalize (H12AffineFastState.compose env48291 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48291 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env48292 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2560,41,2576,0,35,2560,2048,52,1,2577,32,16,3,40,17,2049,2561,2561,2049,20,33,37,33,2576,513]

theorem envBound48292 : H12AffineFastState.Bounded env48292 := by
  intro p hp
  have h : env48292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48291_48292 : H12AffineEnvironment.transform 7 37 env48291 = env48292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48291 == env48292) = true)

theorem identity48292 : scanCanonicalize (H12AffineFastState.compose env48292 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound48292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48293 : List Nat := [2,4,8,16,32,17,9,37,512,52,544,32,41,48,0,35,32,544,52,1,49,32,16,3,40,17,545,33,33,545,20,33,37,33,48,513]

theorem envBound48293 : H12AffineFastState.Bounded env48293 := by
  intro p hp
  have h : env48293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48292_48293 : H12AffineEnvironment.transform 10 544 env48292 = env48293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env48292 == env48293) = true)

theorem identity48293 : scanCanonicalize (H12AffineFastState.compose env48293 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound48293 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48294 : List Nat := [2,4,8,16,32,17,9,37,32,52,0,32,41,48,0,35,32,0,52,1,49,32,16,3,40,17,1,33,33,1,20,33,37,33,48,33]

theorem envBound48294 : H12AffineFastState.Bounded env48294 := by
  intro p hp
  have h : env48294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48293_48294 : H12AffineEnvironment.transform 8 32 env48293 = env48294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env48293 == env48294) = true)

theorem identity48294 : scanCanonicalize (H12AffineFastState.compose env48294 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48294 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48295 : List Nat := [2,4,8,16,17,17,9,20,17,5,0,17,24,1,0,18,17,0,5,1,0,17,16,3,25,17,1,16,16,1,20,16,20,16,1,16]

theorem envBound48295 : H12AffineFastState.Bounded env48295 := by
  intro p hp
  have h : env48295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48294_48295 : H12AffineEnvironment.transform 4 17 env48294 = env48295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48294 == env48295) = true)

def env48296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,138,8328,64,4450483,2196487,2233817,190521,246803,6382922,256,2327726,2319626,189381]

theorem envBound48296 : H12AffineFastState.Bounded env48296 := by
  intro p hp
  have h : env48296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48267_48296 : H12AffineEnvironment.transform 17 157873 env48267 = env48296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env48267 == env48296) = true)

theorem identity48296 : scanCanonicalize (H12AffineFastState.compose env48296 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48296 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157873,1024,8540,2097152,4194304,147593,138,8328,64,4409838,2172250,2233817,149860,222542,6382922,256,2303475,2319626,148120]

theorem envBound48297 : H12AffineFastState.Bounded env48297 := by
  intro p hp
  have h : env48297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48296_48297 : H12AffineEnvironment.transform 14 8541 env48296 = env48297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48296 == env48297) = true)

theorem identity48297 : scanCanonicalize (H12AffineFastState.compose env48297 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48297 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env48298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157752,1024,8540,2097152,4194304,147456,3,8193,64,4409703,2172250,2233680,149860,222542,6382922,256,2303354,2319626,147985]

theorem envBound48298 : H12AffineFastState.Bounded env48298 := by
  intro p hp
  have h : env48298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48297_48298 : H12AffineEnvironment.transform 6 9 env48297 = env48298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48297 == env48298) = true)

theorem identity48298 : scanCanonicalize (H12AffineFastState.compose env48298 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound48298 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,3,8193,64,4262263,2172250,2118976,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound48299 : H12AffineFastState.Bounded env48299 := by
  intro p hp
  have h : env48299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48298_48299 : H12AffineEnvironment.transform 16 16400 env48298 = env48299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48298 == env48299) = true)

theorem identity48299 : scanCanonicalize (H12AffineFastState.compose env48299 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound48299 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91467,4194304,16,3,8193,64,4262263,16401,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound48300 : H12AffineFastState.Bounded env48300 := by
  intro p hp
  have h : env48300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48299_48300 : H12AffineEnvironment.transform 20 91467 env48299 = env48300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env48299 == env48300) = true)

theorem identity48300 : scanCanonicalize (H12AffineFastState.compose env48300 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound48300 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,16400,10280,1024,8540,25629,4194304,16,3,8193,64,4196385,16401,12637,2420,9224,4194305,256,33,16465,513]

theorem envBound48301 : H12AffineFastState.Bounded env48301 := by
  intro p hp
  have h : env48301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48300_48301 : H12AffineEnvironment.transform 15 342 env48300 = env48301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env48300 == env48301) = true)

theorem identity48301 : scanCanonicalize (H12AffineFastState.compose env48301 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48301 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16400,2420,1024,0,17729,4194304,16,3,349,64,4196385,16401,4097,2420,1364,4194305,256,33,16465,513]

theorem envBound48302 : H12AffineFastState.Bounded env48302 := by
  intro p hp
  have h : env48302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48301_48302 : H12AffineEnvironment.transform 12 348 env48301 = env48302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48301 == env48302) = true)

theorem identity48302 : scanCanonicalize (H12AffineFastState.compose env48302 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48303 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1024,0,17680,4194304,16,3,268,17,4196385,16401,4097,2341,1285,4194305,256,33,16384,513]

theorem envBound48303 : H12AffineFastState.Bounded env48303 := by
  intro p hp
  have h : env48303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48302_48303 : H12AffineEnvironment.transform 5 17 env48302 = env48303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48302 == env48303) = true)

theorem identity48303 : scanCanonicalize (H12AffineFastState.compose env48303 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound48303 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48304 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1024,0,17680,21509,16,3,268,17,23588,16401,4097,2341,1285,21508,256,33,16384,513]

theorem envBound48304 : H12AffineFastState.Bounded env48304 := by
  intro p hp
  have h : env48304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48303_48304 : H12AffineEnvironment.transform 21 21509 env48303 = env48304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env48303 == env48304) = true)

theorem identity48304 : scanCanonicalize (H12AffineFastState.compose env48304 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound48304 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48305 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5156,1,263,5172,2341,1024,0,4404,33,16,3,268,17,2048,5173,4097,2341,1285,32,256,33,5156,513]

theorem envBound48305 : H12AffineFastState.Bounded env48305 := by
  intro p hp
  have h : env48305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48304_48305 : H12AffineEnvironment.transform 13 5156 env48304 = env48305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env48304 == env48305) = true)

def env48306 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2836,1,263,2820,2341,1024,0,3588,33,16,3,268,17,2048,2821,3889,2341,1285,32,256,33,2836,513]

theorem envBound48306 : H12AffineFastState.Bounded env48306 := by
  intro p hp
  have h : env48306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48305_48306 : H12AffineEnvironment.transform 11 3888 env48305 = env48306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env48305 == env48306) = true)

def env48307 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1044,1,263,1028,1573,1024,0,260,33,16,3,268,17,1792,1029,49,1573,1285,32,256,33,1044,513]

theorem envBound48307 : H12AffineFastState.Bounded env48307 := by
  intro p hp
  have h : env48307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48306_48307 : H12AffineEnvironment.transform 10 1792 env48306 = env48307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env48306 == env48307) = true)

theorem identity48307 : scanCanonicalize (H12AffineFastState.compose env48307 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48308 : List Nat := [2,4,8,16,32,17,9,256,512,272,528,48,269,260,1,263,276,821,272,0,260,33,16,3,268,17,528,277,49,821,21,32,256,33,260,513]

theorem envBound48308 : H12AffineFastState.Bounded env48308 := by
  intro p hp
  have h : env48308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48307_48308 : H12AffineEnvironment.transform 9 272 env48307 = env48308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48307 == env48308) = true)

def env48309 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,32,1,35,48,529,52,0,32,33,16,3,40,17,528,49,49,529,21,32,36,33,32,513]

theorem envBound48309 : H12AffineFastState.Bounded env48309 := by
  intro p hp
  have h : env48309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48308_48309 : H12AffineEnvironment.transform 7 36 env48308 = env48309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48308 == env48309) = true)

def env48310 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,48,40,33,1,34,49,528,53,0,33,33,16,3,41,17,528,48,49,528,21,32,37,33,33,513]

theorem envBound48310 : H12AffineFastState.Bounded env48310 := by
  intro p hp
  have h : env48310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48308_48310 : H12AffineEnvironment.transform 7 37 env48308 = env48310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48308 == env48310) = true)

theorem identity48310 : scanCanonicalize (H12AffineFastState.compose env48310 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48311 : List Nat := [2,4,8,16,32,17,9,37,42,53,58,48,40,33,1,34,49,58,53,0,33,33,16,3,41,17,58,48,49,58,21,32,37,33,33,43]

theorem envBound48311 : H12AffineFastState.Bounded env48311 := by
  intro p hp
  have h : env48311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48310_48311 : H12AffineEnvironment.transform 8 42 env48310 = env48311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48310 == env48311) = true)

def leafEnv48311 : List Nat := [2,4,8,16,32,17,9,37,42,53,58,48,40,33,1,34,49,58,53,0,33,33,16,3,21,41,1,17,58,48,49,58,21,32,37,33,4,35,33,43,1,33,0]

def active48311 : List Nat := [0,1,2,3,4]

def tree48311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48311 : H12WitnessSearch.Good tree48311 := H12GlobalWitnessIndex.good

theorem leafIdentity48311 : H12AffineFastState.composeSystem env48311 rootObs = leafEnv48311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48311 rootObs == leafEnv48311) = true)

theorem terminalChecked48311 : H12PackedTerminal.terminalCheckFast leafEnv48311 active48311 tree48311 = true := by decide +kernel

def env48312 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1045,1,263,1029,1572,1024,0,261,33,16,3,268,17,1793,1028,48,1572,1285,32,256,33,1045,513]

theorem envBound48312 : H12AffineFastState.Bounded env48312 := by
  intro p hp
  have h : env48312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48306_48312 : H12AffineEnvironment.transform 10 1793 env48306 = env48312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env48306 == env48312) = true)

def env48313 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2837,1,263,2821,2341,1024,0,3589,33,16,3,268,17,2048,2820,3888,2341,1285,32,256,33,2837,513]

theorem envBound48313 : H12AffineFastState.Bounded env48313 := by
  intro p hp
  have h : env48313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48305_48313 : H12AffineEnvironment.transform 11 3889 env48305 = env48313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env48305 == env48313) = true)

def env48314 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1045,1,263,1029,1573,1024,0,261,33,16,3,268,17,1792,1028,48,1573,1285,32,256,33,1045,513]

theorem envBound48314 : H12AffineFastState.Bounded env48314 := by
  intro p hp
  have h : env48314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48313_48314 : H12AffineEnvironment.transform 10 1792 env48313 = env48314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env48313 == env48314) = true)

theorem identity48314 : scanCanonicalize (H12AffineFastState.compose env48314 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48315 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,49,40,1045,1,34,1029,1573,1024,0,32,33,16,3,41,17,1573,1028,48,1573,1056,32,37,33,1045,513]

theorem envBound48315 : H12AffineFastState.Bounded env48315 := by
  intro p hp
  have h : env48315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48314_48315 : H12AffineEnvironment.transform 7 37 env48314 = env48315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48314 == env48315) = true)

def env48316 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,49,40,33,1,34,49,529,52,0,32,33,16,3,41,17,529,48,48,529,20,32,37,33,33,513]

theorem envBound48316 : H12AffineFastState.Bounded env48316 := by
  intro p hp
  have h : env48316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48315_48316 : H12AffineEnvironment.transform 9 52 env48315 = env48316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48315 == env48316) = true)

def env48317 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,49,40,32,1,34,48,528,53,0,32,33,16,3,41,17,528,49,48,528,21,32,37,33,32,513]

theorem envBound48317 : H12AffineFastState.Bounded env48317 := by
  intro p hp
  have h : env48317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48315_48317 : H12AffineEnvironment.transform 9 53 env48315 = env48317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48315 == env48317) = true)

theorem identity48317 : scanCanonicalize (H12AffineFastState.compose env48317 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48318 : List Nat := [2,4,8,16,32,17,9,37,43,53,59,49,40,32,1,34,48,59,53,0,32,33,16,3,41,17,59,49,48,59,21,32,37,33,32,42]

theorem envBound48318 : H12AffineFastState.Bounded env48318 := by
  intro p hp
  have h : env48318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48317_48318 : H12AffineEnvironment.transform 8 43 env48317 = env48318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48317 == env48318) = true)

def leafEnv48318 : List Nat := [2,4,8,16,32,17,9,37,43,53,59,49,40,32,1,34,48,59,53,0,32,33,16,3,21,41,1,17,59,49,48,59,21,32,37,33,4,35,32,42,1,32,0]

def active48318 : List Nat := [0,1,2,3,4]

def tree48318 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48318 : H12WitnessSearch.Good tree48318 := H12GlobalWitnessIndex.good

theorem leafIdentity48318 : H12AffineFastState.composeSystem env48318 rootObs = leafEnv48318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48318 rootObs == leafEnv48318) = true)

theorem terminalChecked48318 : H12PackedTerminal.terminalCheckFast leafEnv48318 active48318 tree48318 = true := by decide +kernel

def env48319 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1044,1,263,1028,1572,1024,0,260,33,16,3,268,17,1793,1029,49,1572,1285,32,256,33,1044,513]

theorem envBound48319 : H12AffineFastState.Bounded env48319 := by
  intro p hp
  have h : env48319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48313_48319 : H12AffineEnvironment.transform 10 1793 env48313 = env48319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env48313 == env48319) = true)

theorem identity48319 : scanCanonicalize (H12AffineFastState.compose env48319 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48320 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,48,269,32,1,263,48,528,52,0,260,33,16,3,268,17,821,49,49,528,305,32,256,33,32,513]

theorem envBound48320 : H12AffineFastState.Bounded env48320 := by
  intro p hp
  have h : env48320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48319_48320 : H12AffineEnvironment.transform 9 52 env48319 = env48320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48319 == env48320) = true)

def env48321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound48321 : H12AffineFastState.Bounded env48321 := by
  intro p hp
  have h : env48321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48171_48321 : H12AffineEnvironment.transform 18 1025 env48171 = env48321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env48171 == env48321) = true)

theorem identity48321 : scanCanonicalize (H12AffineFastState.compose env48321 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 253962) := by decide +kernel

theorem selectedBound48321 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,253962,16777216,8328,64,21241866,18973836,2340186,335882,16933914,23160256,257,19014822,19055875,16991181]

theorem envBound48322 : H12AffineFastState.Bounded env48322 := by
  intro p hp
  have h : env48322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48321_48322 : H12AffineEnvironment.transform 22 253962 env48321 = env48322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 253962 env48321 == env48322) = true)

def env48323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,16777216,8328,64,16959642,18973836,2340186,335882,16933914,19369296,257,19014822,19055875,16991181]

theorem envBound48323 : H12AffineFastState.Bounded env48323 := by
  intro p hp
  have h : env48323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48322_48323 : H12AffineEnvironment.transform 21 452752 env48322 = env48323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env48322 == env48323) = true)

def env48324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,242968,8328,64,97666,2240916,2340186,335882,119042,2373704,257,2199998,2191387,63189]

theorem envBound48324 : H12AffineFastState.Bounded env48324 := by
  intro p hp
  have h : env48324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48323_48324 : H12AffineEnvironment.transform 23 242968 env48323 = env48324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env48323 == env48324) = true)

def env48325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253962,242968,8328,64,97666,139732,238874,335882,119042,272392,257,98814,90203,63189]

theorem envBound48325 : H12AffineFastState.Bounded env48325 := by
  intro p hp
  have h : env48325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48324_48325 : H12AffineEnvironment.transform 20 4160 env48324 = env48325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48324 == env48325) = true)

def env48326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,180272,253962,242968,8328,64,97666,139732,238874,67754,119042,168,257,98814,90203,63189]

theorem envBound48326 : H12AffineFastState.Bounded env48326 := by
  intro p hp
  have h : env48326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48325_48326 : H12AffineEnvironment.transform 17 10400 env48325 = env48326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48325 == env48326) = true)

def env48327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180272,253962,242968,8192,64,97546,139612,238874,67618,119042,32,257,98678,90203,63069]

theorem envBound48327 : H12AffineFastState.Bounded env48327 := by
  intro p hp
  have h : env48327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48326_48327 : H12AffineEnvironment.transform 6 8 env48326 = env48327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48326 == env48327) = true)

theorem identity48327 : scanCanonicalize (H12AffineFastState.compose env48327 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48327 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,4160,144492,201814,213316,8192,64,97546,139612,217414,67618,75102,32,257,95530,90203,513]

theorem envBound48328 : H12AffineFastState.Bounded env48328 := by
  intro p hp
  have h : env48328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48327_48328 : H12AffineEnvironment.transform 14 29788 env48327 = env48328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48327 == env48328) = true)

theorem identity48328 : scanCanonicalize (H12AffineFastState.compose env48328 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound48328 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env48329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,82247,10280,1025,29789,4160,95531,21777,3,8192,64,97546,90139,4097,67618,75102,32,257,95530,90203,513]

theorem envBound48329 : H12AffineFastState.Bounded env48329 := by
  intro p hp
  have h : env48329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48328_48329 : H12AffineEnvironment.transform 16 82247 env48328 = env48329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env48328 == env48329) = true)

theorem identity48329 : scanCanonicalize (H12AffineFastState.compose env48329 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound48329 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,262,16449,10280,1025,29789,4160,29741,21777,3,8192,64,31756,24861,4097,2340,9304,32,257,29740,24925,513]

theorem envBound48330 : H12AffineFastState.Bounded env48330 := by
  intro p hp
  have h : env48330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48329_48330 : H12AffineEnvironment.transform 15 262 env48329 = env48330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env48329 == env48330) = true)

theorem identity48330 : scanCanonicalize (H12AffineFastState.compose env48330 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48330 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,262,5441,10280,1025,8541,4160,8493,17,3,8192,64,10508,13341,4097,2340,9304,32,257,8492,13405,513]

theorem envBound48331 : H12AffineFastState.Bounded env48331 := by
  intro p hp
  have h : env48331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48330_48331 : H12AffineEnvironment.transform 13 5376 env48330 = env48331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48330 == env48331) = true)

theorem identity48331 : scanCanonicalize (H12AffineFastState.compose env48331 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48331 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,262,5441,2421,1025,0,4160,112,17,3,349,64,2129,5440,4097,2340,1285,32,257,113,5376,513]

theorem envBound48332 : H12AffineFastState.Bounded env48332 := by
  intro p hp
  have h : env48332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48331_48332 : H12AffineEnvironment.transform 12 349 env48331 = env48332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48331 == env48332) = true)

theorem identity48332 : scanCanonicalize (H12AffineFastState.compose env48332 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound48332 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1588,4096,349,5376,1,262,5441,1857,1025,0,4160,112,17,3,349,64,1637,5440,4097,1808,1285,32,257,113,5376,513]

theorem envBound48333 : H12AffineFastState.Bounded env48333 := by
  intro p hp
  have h : env48333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48332_48333 : H12AffineEnvironment.transform 10 1588 env48332 = env48333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env48332 == env48333) = true)

theorem identity48333 : scanCanonicalize (H12AffineFastState.compose env48333 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound48333 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env48334 : List Nat := [2,4,8,16,32,64,8,256,276,1024,1312,4096,349,5376,1,262,5441,1109,1025,0,4160,112,17,3,349,64,1393,5440,4097,1028,1285,32,257,113,5376,277]

theorem envBound48334 : H12AffineFastState.Bounded env48334 := by
  intro p hp
  have h : env48334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48333_48334 : H12AffineEnvironment.transform 8 276 env48333 = env48334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env48333 == env48334) = true)

theorem identity48334 : scanCanonicalize (H12AffineFastState.compose env48334 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound48334 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env48335 : List Nat := [2,4,8,16,32,64,8,256,276,116,340,4096,349,4468,1,262,4405,33,117,0,4160,112,17,3,349,64,261,4404,4097,112,369,32,257,113,4468,277]

theorem envBound48335 : H12AffineFastState.Bounded env48335 := by
  intro p hp
  have h : env48335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48334_48335 : H12AffineEnvironment.transform 9 116 env48334 = env48335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env48334 == env48335) = true)

theorem identity48335 : scanCanonicalize (H12AffineFastState.compose env48335 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound48335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48336 : List Nat := [2,4,8,16,32,64,8,256,276,116,340,260,349,112,1,262,49,33,117,0,324,112,17,3,349,64,261,48,261,112,369,32,257,113,112,277]

theorem envBound48336 : H12AffineFastState.Bounded env48336 := by
  intro p hp
  have h : env48336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48335_48336 : H12AffineEnvironment.transform 11 260 env48335 = env48336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env48335 == env48336) = true)

theorem identity48336 : scanCanonicalize (H12AffineFastState.compose env48336 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound48336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48337 : List Nat := [2,4,8,16,32,64,8,85,65,116,1,81,8,112,1,83,49,33,117,0,17,112,17,3,8,64,80,48,80,112,36,32,84,113,112,64]

theorem envBound48337 : H12AffineFastState.Bounded env48337 := by
  intro p hp
  have h : env48337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48336_48337 : H12AffineEnvironment.transform 7 85 env48336 = env48337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env48336 == env48337) = true)

theorem identity48337 : scanCanonicalize (H12AffineFastState.compose env48337 (packedSelected [3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48337 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env48338 : List Nat := [2,4,8,1,32,64,8,68,65,101,1,64,8,97,1,66,32,33,100,0,0,97,0,3,8,64,65,33,65,97,36,32,69,96,97,64]

theorem envBound48338 : H12AffineFastState.Bounded env48338 := by
  intro p hp
  have h : env48338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48337_48338 : H12AffineEnvironment.transform 3 1 env48337 = env48338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48337 == env48338) = true)

theorem identity48338 : scanCanonicalize (H12AffineFastState.compose env48338 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48338 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48339 : List Nat := [2,4,8,1,0,64,8,68,65,69,1,64,8,65,1,66,0,1,68,0,0,65,0,3,8,64,65,1,65,65,4,0,69,64,65,64]

theorem envBound48339 : H12AffineFastState.Bounded env48339 := by
  intro p hp
  have h : env48339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48338_48339 : H12AffineEnvironment.transform 4 0 env48338 = env48339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48338 == env48339) = true)

theorem identity48339 : scanCanonicalize (H12AffineFastState.compose env48339 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48339 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48340 : List Nat := [2,4,8,1,0,1,8,5,0,4,1,1,8,0,1,3,0,1,5,0,0,0,0,3,8,1,0,1,0,0,4,0,4,1,0,1]

theorem envBound48340 : H12AffineFastState.Bounded env48340 := by
  intro p hp
  have h : env48340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48339_48340 : H12AffineEnvironment.transform 5 1 env48339 = env48340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48339 == env48340) = true)

theorem identity48340 : scanCanonicalize (H12AffineFastState.compose env48340 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48340 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48341 : List Nat := [2,4,3,1,0,1,3,5,0,4,1,1,3,0,1,3,0,1,5,0,0,0,0,3,3,1,0,1,0,0,4,0,4,1,0,1]

theorem envBound48341 : H12AffineFastState.Bounded env48341 := by
  intro p hp
  have h : env48341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48340_48341 : H12AffineEnvironment.transform 2 3 env48340 = env48341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48340 == env48341) = true)

def env48342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180272,253962,242968,8193,64,97547,139613,238874,67619,119042,33,257,98679,90203,63068]

theorem envBound48342 : H12AffineFastState.Bounded env48342 := by
  intro p hp
  have h : env48342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48326_48342 : H12AffineEnvironment.transform 6 9 env48326 = env48342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48326 == env48342) = true)

theorem identity48342 : scanCanonicalize (H12AffineFastState.compose env48342 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48342 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1025,8541,4160,156012,213334,201796,8193,64,97547,139613,197702,67619,94302,33,257,73771,90203,22272]

theorem envBound48343 : H12AffineFastState.Bounded env48343 := by
  intro p hp
  have h : env48343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48342_48343 : H12AffineEnvironment.transform 14 8540 env48342 = env48343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48342 == env48343) = true)

theorem identity48343 : scanCanonicalize (H12AffineFastState.compose env48343 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound48343 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,131072,10281,1025,8541,4160,156012,136448,147474,8193,64,10589,139613,151568,23669,9224,33,257,29821,13325,22272]

theorem envBound48344 : H12AffineFastState.Bounded env48344 := by
  intro p hp
  have h : env48344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48343_48344 : H12AffineEnvironment.transform 15 21590 env48343 = env48344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env48343 == env48344) = true)

theorem identity48344 : scanCanonicalize (H12AffineFastState.compose env48344 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48344 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env48345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8282,131072,10281,1025,8541,4160,136544,136448,144414,8193,64,10589,139613,140316,10361,9224,33,257,113,13325,8972]

theorem envBound48345 : H12AffineFastState.Bounded env48345 := by
  intro p hp
  have h : env48345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48344_48345 : H12AffineEnvironment.transform 13 13324 env48344 = env48345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48344 == env48345) = true)

theorem identity48345 : scanCanonicalize (H12AffineFastState.compose env48345 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 12409) := by decide +kernel

theorem selectedBound48345 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8282,12409,10281,1025,8541,4160,9497,9593,1127,8193,64,10589,4388,5221,10361,9224,33,257,113,13325,8972]

theorem envBound48346 : H12AffineFastState.Bounded env48346 := by
  intro p hp
  have h : env48346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48345_48346 : H12AffineEnvironment.transform 16 12409 env48345 = env48346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12409 env48345 == env48346) = true)

theorem identity48346 : scanCanonicalize (H12AffineFastState.compose env48346 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound48346 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4160,1296,1046,5173,3173,1025,1297,4160,341,309,1127,1101,64,3345,4388,5221,3125,68,33,257,113,4161,1856]

theorem envBound48347 : H12AffineFastState.Bounded env48347 := by
  intro p hp
  have h : env48347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48346_48347 : H12AffineEnvironment.transform 12 1100 env48346 = env48347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env48346 == env48347) = true)

theorem identity48347 : scanCanonicalize (H12AffineFastState.compose env48347 (packedSelected [1,2,3,5,6,8,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound48347 : packedSelected [1,2,3,5,6,8,12,16] rootPS < 2^1333 := by decide +kernel

def env48348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,2420,1296,1046,3329,3173,1025,1297,2420,341,309,1127,1101,64,3345,2064,3409,3125,68,33,257,113,2421,1856]

theorem envBound48348 : H12AffineFastState.Bounded env48348 := by
  intro p hp
  have h : env48348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48347_48348 : H12AffineEnvironment.transform 11 2356 env48347 = env48348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env48347 == env48348) = true)

theorem identity48348 : scanCanonicalize (H12AffineFastState.compose env48348 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48348 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48349 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,121,2420,293,35,2356,2128,52,292,2420,341,309,82,120,64,2340,2064,2404,2048,68,33,257,113,2421,885]

theorem envBound48349 : H12AffineFastState.Bounded env48349 := by
  intro p hp
  have h : env48349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48348_48349 : H12AffineEnvironment.transform 9 53 env48348 = env48349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48348 == env48349) = true)

theorem identity48349 : scanCanonicalize (H12AffineFastState.compose env48349 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48349 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env48350 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,121,2129,0,35,2065,2128,52,1,2129,112,16,82,120,64,2049,2064,2113,2048,68,33,36,113,2128,592]

theorem envBound48350 : H12AffineFastState.Bounded env48350 := by
  intro p hp
  have h : env48350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48349_48350 : H12AffineEnvironment.transform 7 37 env48349 = env48350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48349 == env48350) = true)

def env48351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,180273,253962,242968,8328,64,97666,139732,238874,67755,119042,169,257,98814,90203,63189]

theorem envBound48351 : H12AffineFastState.Bounded env48351 := by
  intro p hp
  have h : env48351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48325_48351 : H12AffineEnvironment.transform 17 10401 env48325 = env48351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48325 == env48351) = true)

def env48352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180273,253962,242968,8192,64,97546,139612,238874,67619,119042,33,257,98678,90203,63069]

theorem envBound48352 : H12AffineFastState.Bounded env48352 := by
  intro p hp
  have h : env48352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48351_48352 : H12AffineEnvironment.transform 6 8 env48351 = env48352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48351 == env48352) = true)

theorem identity48352 : scanCanonicalize (H12AffineFastState.compose env48352 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound48352 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4160,73771,16,21762,8192,64,97546,115014,17664,67619,119042,33,257,98678,90203,63069]

theorem envBound48353 : H12AffineFastState.Bounded env48353 := by
  intro p hp
  have h : env48353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48352_48353 : H12AffineEnvironment.transform 16 122906 env48352 = env48353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env48352 == env48353) = true)

theorem identity48353 : scanCanonicalize (H12AffineFastState.compose env48353 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48353 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,103494,10281,1025,32769,4160,73771,16,8542,8192,64,67926,111898,12636,67619,107870,33,257,98678,70663,33281]

theorem envBound48354 : H12AffineFastState.Bounded env48354 := by
  intro p hp
  have h : env48354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48353_48354 : H12AffineEnvironment.transform 13 13404 env48353 = env48354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48353 == env48354) = true)

theorem identity48354 : scanCanonicalize (H12AffineFastState.compose env48354 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 34098) := by decide +kernel

theorem selectedBound48354 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env48355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,34098,4468,10281,1025,32769,4160,42265,16,8542,8192,64,35940,12328,12636,36113,8300,33,257,1092,37173,33281]

theorem envBound48355 : H12AffineFastState.Bounded env48355 := by
  intro p hp
  have h : env48355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48354_48355 : H12AffineEnvironment.transform 15 34098 env48354 = env48355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34098 env48354 == env48355) = true)

theorem identity48355 : scanCanonicalize (H12AffineFastState.compose env48355 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48355 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env48356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,32768,34098,4468,2341,1025,32769,4160,33813,16,82,268,64,35940,4388,4176,36113,352,33,257,1092,37173,33281]

theorem envBound48356 : H12AffineFastState.Bounded env48356 := by
  intro p hp
  have h : env48356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48355_48356 : H12AffineEnvironment.transform 12 268 env48355 = env48356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48355 == env48356) = true)

theorem identity48356 : scanCanonicalize (H12AffineFastState.compose env48356 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound48356 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env48357 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4405,32768,33111,4468,2341,100,32769,4160,32880,16,82,268,64,34817,4388,4176,35188,352,33,257,33,37173,33281]

theorem envBound48357 : H12AffineFastState.Bounded env48357 := by
  intro p hp
  have h : env48357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48356_48357 : H12AffineEnvironment.transform 9 101 env48356 = env48357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env48356 == env48357) = true)

theorem identity48357 : scanCanonicalize (H12AffineFastState.compose env48357 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound48357 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48358 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4405,1,342,4468,2341,100,0,4160,113,16,82,268,64,2048,4388,4176,2421,352,33,257,33,4404,512]

theorem envBound48358 : H12AffineFastState.Bounded env48358 := by
  intro p hp
  have h : env48358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48357_48358 : H12AffineEnvironment.transform 14 1 env48357 = env48358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env48357 == env48358) = true)

theorem identity48358 : scanCanonicalize (H12AffineFastState.compose env48358 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound48358 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48359 : List Nat := [2,4,8,16,32,64,8,256,512,101,33,4096,268,4405,1,342,4468,260,100,0,4160,113,16,82,268,64,33,4388,4176,340,352,33,257,33,4404,512]

theorem envBound48359 : H12AffineFastState.Bounded env48359 := by
  intro p hp
  have h : env48359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48358_48359 : H12AffineEnvironment.transform 10 33 env48358 = env48359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env48358 == env48359) = true)

theorem identity48359 : scanCanonicalize (H12AffineFastState.compose env48359 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48359 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48360 : List Nat := [2,4,8,16,32,48,8,256,512,21,33,4096,268,4405,1,294,4356,260,20,0,4144,1,16,34,268,48,33,4388,4128,292,272,33,257,33,4404,512]

theorem envBound48360 : H12AffineFastState.Bounded env48360 := by
  intro p hp
  have h : env48360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48359_48360 : H12AffineEnvironment.transform 5 48 env48359 = env48360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48359 == env48360) = true)

theorem identity48360 : scanCanonicalize (H12AffineFastState.compose env48360 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48360 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env48361 : List Nat := [2,4,8,16,32,48,8,5,512,21,33,4096,9,4144,1,35,4097,1,20,0,4144,1,16,34,9,48,33,4129,4128,33,21,33,4,33,4145,512]

theorem envBound48361 : H12AffineFastState.Bounded env48361 := by
  intro p hp
  have h : env48361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48360_48361 : H12AffineEnvironment.transform 7 5 env48360 = env48361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48360 == env48361) = true)

theorem identity48361 : scanCanonicalize (H12AffineFastState.compose env48361 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound48361 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48362 : List Nat := [2,4,8,16,32,48,8,5,512,21,33,513,9,561,1,35,512,1,20,0,561,1,16,34,9,48,33,544,545,33,21,33,4,33,560,512]

theorem envBound48362 : H12AffineFastState.Bounded env48362 := by
  intro p hp
  have h : env48362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48361_48362 : H12AffineEnvironment.transform 11 513 env48361 = env48362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env48361 == env48362) = true)

theorem identity48362 : scanCanonicalize (H12AffineFastState.compose env48362 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48362 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48363 : List Nat := [2,4,8,16,32,48,8,5,49,21,33,48,9,0,1,35,49,1,20,0,0,1,16,34,9,48,33,17,16,33,21,33,4,33,1,49]

theorem envBound48363 : H12AffineFastState.Bounded env48363 := by
  intro p hp
  have h : env48363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48362_48363 : H12AffineEnvironment.transform 8 49 env48362 = env48363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48362 == env48363) = true)

theorem identity48363 : scanCanonicalize (H12AffineFastState.compose env48363 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48364 : List Nat := [2,1,8,16,32,48,8,0,49,16,33,48,9,0,1,35,49,1,17,0,0,1,16,34,9,48,33,17,16,33,16,33,1,33,1,49]

theorem envBound48364 : H12AffineFastState.Bounded env48364 := by
  intro p hp
  have h : env48364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48363_48364 : H12AffineEnvironment.transform 1 1 env48363 = env48364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48363 == env48364) = true)

theorem identity48364 : scanCanonicalize (H12AffineFastState.compose env48364 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48364 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env48365 : List Nat := [2,1,8,16,0,16,8,0,17,16,1,16,9,0,1,3,17,1,17,0,0,1,16,2,9,16,1,17,16,1,16,1,1,1,1,17]

theorem envBound48365 : H12AffineFastState.Bounded env48365 := by
  intro p hp
  have h : env48365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48364_48365 : H12AffineEnvironment.transform 4 0 env48364 = env48365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48364 == env48365) = true)

theorem identity48365 : scanCanonicalize (H12AffineFastState.compose env48365 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48366 : List Nat := [2,1,8,1,0,1,8,0,0,1,1,1,9,0,1,3,0,1,0,0,0,1,1,2,9,1,1,0,1,1,1,1,1,1,1,0]

theorem envBound48366 : H12AffineFastState.Bounded env48366 := by
  intro p hp
  have h : env48366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48365_48366 : H12AffineEnvironment.transform 3 1 env48365 = env48366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48365 == env48366) = true)

def env48367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180273,253962,242968,8193,64,97547,139613,238874,67618,119042,32,257,98679,90203,63068]

theorem envBound48367 : H12AffineFastState.Bounded env48367 := by
  intro p hp
  have h : env48367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48351_48367 : H12AffineEnvironment.transform 6 9 env48351 = env48367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48351 == env48367) = true)

theorem identity48367 : scanCanonicalize (H12AffineFastState.compose env48367 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound48367 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,4160,98679,41292,62558,8193,64,97547,90139,58460,67618,119042,32,257,98679,90203,63068]

theorem envBound48368 : H12AffineFastState.Bounded env48368 := by
  intro p hp
  have h : env48368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48367_48368 : H12AffineEnvironment.transform 16 82246 env48367 = env48368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env48367 == env48368) = true)

theorem identity48368 : scanCanonicalize (H12AffineFastState.compose env48368 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48368 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,2420,1025,32769,4160,98679,32784,54530,349,64,89175,82247,50432,67618,119042,32,257,98679,82183,55040]

theorem envBound48369 : H12AffineFastState.Bounded env48369 := by
  intro p hp
  have h : env48369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48368_48369 : H12AffineEnvironment.transform 12 348 env48368 = env48369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48368 == env48369) = true)

theorem identity48369 : scanCanonicalize (H12AffineFastState.compose env48369 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound48369 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env48370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54279,38209,2420,1025,32769,4160,21872,32784,54530,349,64,34896,38208,50432,56357,1285,32,257,21872,38144,55040]

theorem envBound48370 : H12AffineFastState.Bounded env48370 := by
  intro p hp
  have h : env48370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48369_48370 : H12AffineEnvironment.transform 15 54279 env48369 = env48370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env48369 == env48370) = true)

theorem identity48370 : scanCanonicalize (H12AffineFastState.compose env48370 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound48370 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,263,16449,2420,1025,21761,4160,21872,21776,2,349,64,23888,16448,4096,2341,1285,32,257,21872,16384,512]

theorem envBound48371 : H12AffineFastState.Bounded env48371 := by
  intro p hp
  have h : env48371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48370_48371 : H12AffineEnvironment.transform 14 21760 env48370 = env48371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env48370 == env48371) = true)

theorem identity48371 : scanCanonicalize (H12AffineFastState.compose env48371 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound48371 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,112,263,5425,2420,1025,113,4160,0,96,2,349,64,2080,5424,4096,2341,1285,32,257,0,5488,512]

theorem envBound48372 : H12AffineFastState.Bounded env48372 := by
  intro p hp
  have h : env48372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48371_48372 : H12AffineEnvironment.transform 13 5488 env48371 = env48372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env48371 == env48372) = true)

theorem identity48372 : scanCanonicalize (H12AffineFastState.compose env48372 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48372 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env48373 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5409,33,263,5425,2341,1025,32,4113,0,49,2,268,17,2080,5424,4096,2341,1285,32,257,0,5409,512]

theorem envBound48373 : H12AffineFastState.Bounded env48373 := by
  intro p hp
  have h : env48373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48372_48373 : H12AffineEnvironment.transform 5 17 env48372 = env48373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48372 == env48373) = true)

theorem identity48373 : scanCanonicalize (H12AffineFastState.compose env48373 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound48373 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48374 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2587,269,3898,33,263,3882,2341,1025,32,2570,0,49,2,268,17,2080,3883,2587,2341,1285,32,257,0,3898,512]

theorem envBound48374 : H12AffineFastState.Bounded env48374 := by
  intro p hp
  have h : env48374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48373_48374 : H12AffineEnvironment.transform 11 2587 env48373 = env48374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env48373 == env48374) = true)

theorem identity48374 : scanCanonicalize (H12AffineFastState.compose env48374 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48374 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env48375 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,2587,269,3866,1,263,3850,2309,1025,0,2570,0,17,2,268,17,2048,3851,2587,2309,1285,0,257,0,3866,512]

theorem envBound48375 : H12AffineFastState.Bounded env48375 := by
  intro p hp
  have h : env48375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48374_48375 : H12AffineEnvironment.transform 4 0 env48374 = env48375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48374 == env48375) = true)

theorem identity48375 : scanCanonicalize (H12AffineFastState.compose env48375 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48376 : List Nat := [2,4,8,16,0,17,9,21,512,1024,2048,2587,24,3599,1,18,3615,2064,1025,0,2570,0,17,2,25,17,2048,3614,2587,2064,1040,0,20,0,3599,512]

theorem envBound48376 : H12AffineFastState.Bounded env48376 := by
  intro p hp
  have h : env48376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48375_48376 : H12AffineEnvironment.transform 7 21 env48375 = env48376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48375 == env48376) = true)

theorem identity48376 : scanCanonicalize (H12AffineFastState.compose env48376 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound48376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48377 : List Nat := [2,4,8,16,0,17,9,21,512,1024,11,528,24,1540,1,18,1556,27,1025,0,513,0,17,2,25,17,11,1557,528,27,1040,0,20,0,1540,512]

theorem envBound48377 : H12AffineFastState.Bounded env48377 := by
  intro p hp
  have h : env48377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48376_48377 : H12AffineEnvironment.transform 10 11 env48376 = env48377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env48376 == env48377) = true)

theorem identity48377 : scanCanonicalize (H12AffineFastState.compose env48377 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48377 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48378 : List Nat := [2,4,3,16,0,17,2,21,512,1024,0,528,19,1540,1,18,1556,16,1025,0,513,0,17,2,18,17,0,1557,528,16,1040,0,20,0,1540,512]

theorem envBound48378 : H12AffineFastState.Bounded env48378 := by
  intro p hp
  have h : env48378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48377_48378 : H12AffineEnvironment.transform 2 3 env48377 = env48378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48377 == env48378) = true)

theorem identity48378 : scanCanonicalize (H12AffineFastState.compose env48378 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound48378 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48379 : List Nat := [2,4,3,16,0,17,2,21,512,5,0,528,19,513,1,18,529,16,4,0,513,0,17,2,18,17,0,528,528,16,21,0,20,0,513,512]

theorem envBound48379 : H12AffineFastState.Bounded env48379 := by
  intro p hp
  have h : env48379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48378_48379 : H12AffineEnvironment.transform 9 5 env48378 = env48379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env48378 == env48379) = true)

theorem identity48379 : scanCanonicalize (H12AffineFastState.compose env48379 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound48379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48380 : List Nat := [2,4,3,16,0,17,2,21,23,5,0,7,19,22,1,18,6,16,4,0,22,0,17,2,18,17,0,7,7,16,21,0,20,0,22,23]

theorem envBound48380 : H12AffineFastState.Bounded env48380 := by
  intro p hp
  have h : env48380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48379_48380 : H12AffineEnvironment.transform 8 23 env48379 = env48380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env48379 == env48380) = true)

theorem identity48380 : scanCanonicalize (H12AffineFastState.compose env48380 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48380 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48381 : List Nat := [2,4,3,7,0,6,2,2,0,5,0,7,4,1,1,5,6,7,4,0,1,0,6,2,5,6,0,7,7,7,2,0,3,0,1,0]

theorem envBound48381 : H12AffineFastState.Bounded env48381 := by
  intro p hp
  have h : env48381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48380_48381 : H12AffineEnvironment.transform 3 7 env48380 = env48381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48380 == env48381) = true)

theorem identity48381 : scanCanonicalize (H12AffineFastState.compose env48381 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48382 : List Nat := [2,1,3,2,0,3,2,2,0,0,0,2,1,1,1,0,3,2,1,0,1,0,3,2,0,3,0,2,2,2,2,0,3,0,1,0]

theorem envBound48382 : H12AffineFastState.Bounded env48382 := by
  intro p hp
  have h : env48382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48381_48382 : H12AffineEnvironment.transform 1 1 env48381 = env48382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48381 == env48382) = true)

theorem identity48382 : scanCanonicalize (H12AffineFastState.compose env48382 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

end H12CloudChart1