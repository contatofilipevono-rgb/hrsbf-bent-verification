import H12CloudChart1Data134

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans34257_34258 : H12AffineEnvironment.transform 4 1 env34257 = env34258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34257 == env34258) = true)

theorem identity34258 : scanCanonicalize (H12AffineFastState.compose env34258 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound34258 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34259 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8192,13524,1,2,13509,2185,1024,0,12360,8200,8217,138,8328,65,2048,13389,12416,10369,9345,136,84,8320,13444,512]

theorem envBound34259 : H12AffineFastState.Bounded env34259 := by
  intro p hp
  have h : env34259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34258_34259 : H12AffineEnvironment.transform 7 84 env34258 = env34259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env34258 == env34259) = true)

theorem identity34259 : scanCanonicalize (H12AffineFastState.compose env34259 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound34259 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34260 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,2201,8192,11341,1,2,11356,2185,1024,0,10449,8200,8217,138,8328,65,2048,11476,10265,10369,9345,136,84,8320,11293,512]

theorem envBound34260 : H12AffineFastState.Bounded env34260 := by
  intro p hp
  have h : env34260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34259_34260 : H12AffineEnvironment.transform 11 2201 env34259 = env34260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env34259 == env34260) = true)

theorem identity34260 : scanCanonicalize (H12AffineFastState.compose env34260 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound34260 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env34261 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,2201,9,3140,1,2,3157,2185,1024,0,2264,1,16,138,129,65,2048,3293,2064,2184,1160,136,84,137,3092,512]

theorem envBound34261 : H12AffineFastState.Bounded env34261 := by
  intro p hp
  have h : env34261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34260_34261 : H12AffineEnvironment.transform 12 9 env34260 = env34261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env34260 == env34261) = true)

theorem identity34261 : scanCanonicalize (H12AffineFastState.compose env34261 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound34261 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34262 : List Nat := [2,4,8,16,1,64,128,84,512,1024,642,539,9,1734,1,2,1751,523,1024,0,602,1,16,138,129,65,642,1631,658,522,1160,136,84,137,1686,512]

theorem envBound34262 : H12AffineFastState.Bounded env34262 := by
  intro p hp
  have h : env34262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34261_34262 : H12AffineEnvironment.transform 10 642 env34261 = env34262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env34261 == env34262) = true)

theorem identity34262 : scanCanonicalize (H12AffineFastState.compose env34262 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound34262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34263 : List Nat := [2,4,8,16,1,64,128,84,512,84,642,539,9,658,1,2,643,523,84,0,602,1,16,138,129,65,642,523,658,522,220,136,84,137,706,512]

theorem envBound34263 : H12AffineFastState.Bounded env34263 := by
  intro p hp
  have h : env34263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34262_34263 : H12AffineEnvironment.transform 9 84 env34262 = env34263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env34262 == env34263) = true)

theorem identity34263 : scanCanonicalize (H12AffineFastState.compose env34263 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound34263 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env34264 : List Nat := [2,4,8,16,1,10,128,30,512,30,642,539,9,658,1,2,643,523,30,0,528,1,16,138,129,11,642,523,658,522,150,136,30,137,648,512]

theorem envBound34264 : H12AffineFastState.Bounded env34264 := by
  intro p hp
  have h : env34264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34263_34264 : H12AffineEnvironment.transform 5 10 env34263 = env34264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env34263 == env34264) = true)

theorem identity34264 : scanCanonicalize (H12AffineFastState.compose env34264 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34264 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env34265 : List Nat := [2,4,8,16,1,10,9,30,512,30,523,539,9,539,1,2,522,523,30,0,528,1,16,3,8,11,523,523,539,522,31,1,30,0,513,512]

theorem envBound34265 : H12AffineFastState.Bounded env34265 := by
  intro p hp
  have h : env34265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34264_34265 : H12AffineEnvironment.transform 6 9 env34264 = env34265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34264 == env34265) = true)

theorem identity34265 : scanCanonicalize (H12AffineFastState.compose env34265 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound34265 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env34266 : List Nat := [2,4,8,16,1,10,9,30,9,30,2,18,9,18,1,2,3,2,30,0,25,1,16,3,8,11,2,2,18,3,31,1,30,0,8,9]

theorem envBound34266 : H12AffineFastState.Bounded env34266 := by
  intro p hp
  have h : env34266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34265_34266 : H12AffineEnvironment.transform 8 9 env34265 = env34266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env34265 == env34266) = true)

theorem identity34266 : scanCanonicalize (H12AffineFastState.compose env34266 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34266 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34267 : List Nat := [2,4,8,0,1,10,9,14,9,14,2,2,9,2,1,2,3,2,14,0,9,1,0,3,8,11,2,2,2,3,15,1,14,0,8,9]

theorem envBound34267 : H12AffineFastState.Bounded env34267 := by
  intro p hp
  have h : env34267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34266_34267 : H12AffineEnvironment.transform 3 0 env34266 = env34267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34266 == env34267) = true)

def env34268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115871,120063,120014,98781,8328,65,97667,115150,17664,10400,119042,62589,256,21793,46213,63189]

theorem envBound34268 : H12AffineFastState.Bounded env34268 := by
  intro p hp
  have h : env34268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34253_34268 : H12AffineEnvironment.transform 16 49169 env34253 = env34268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env34253 == env34268) = true)

theorem identity34268 : scanCanonicalize (H12AffineFastState.compose env34268 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34268 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env34269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,65536,49169,122227,1024,32769,115871,120063,120014,98781,389,65,89230,115150,17664,2477,119042,54640,256,21793,38280,55256]

theorem envBound34269 : H12AffineFastState.Bounded env34269 := by
  intro p hp
  have h : env34269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34268_34269 : H12AffineEnvironment.transform 12 269 env34268 = env34269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34268 == env34269) = true)

theorem identity34269 : scanCanonicalize (H12AffineFastState.compose env34269 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound34269 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env34270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,33111,49169,23588,1024,32769,17864,21928,21913,138,389,65,56793,16537,17664,2477,20565,54640,256,21793,38280,55256]

theorem envBound34270 : H12AffineFastState.Bounded env34270 := by
  intro p hp
  have h : env34270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34269_34270 : H12AffineEnvironment.transform 15 33111 env34269 = env34270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env34269 == env34270) = true)

theorem identity34270 : scanCanonicalize (H12AffineFastState.compose env34270 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound34270 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env34271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,217,398,16584,23588,1024,216,17864,21928,21913,138,389,65,23808,16537,17664,2477,20565,21929,256,21793,5457,22273]

theorem envBound34271 : H12AffineFastState.Bounded env34271 := by
  intro p hp
  have h : env34271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34270_34271 : H12AffineEnvironment.transform 14 217 env34270 = env34271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env34270 == env34271) = true)

theorem identity34271 : scanCanonicalize (H12AffineFastState.compose env34271 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34271 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env34272 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,0,343,16401,23588,1024,1,17681,21873,21824,83,348,65,23808,16448,17664,2420,20565,21872,256,21793,5457,22273]

theorem envBound34272 : H12AffineFastState.Bounded env34272 := by
  intro p hp
  have h : env34272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34271_34272 : H12AffineEnvironment.transform 6 89 env34271 = env34272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34271 == env34272) = true)

theorem identity34272 : scanCanonicalize (H12AffineFastState.compose env34272 (packedSelected [0,1,4,6,7,8,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound34272 : packedSelected [0,1,4,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env34273 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5409,0,343,5424,2309,1024,1,4144,80,97,83,348,65,2081,5473,4129,2420,1396,81,256,0,5457,544]

theorem envBound34273 : H12AffineFastState.Bounded env34273 := by
  intro p hp
  have h : env34273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34272_34273 : H12AffineEnvironment.transform 13 5409 env34272 = env34273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env34272 == env34273) = true)

theorem identity34273 : scanCanonicalize (H12AffineFastState.compose env34273 (packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34273 : packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34274 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5409,0,263,5424,2309,1024,1,4144,0,49,3,268,17,2081,5425,4129,2340,1316,1,256,0,5377,544]

theorem envBound34274 : H12AffineFastState.Bounded env34274 := by
  intro p hp
  have h : env34274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34273_34274 : H12AffineEnvironment.transform 5 16 env34273 = env34274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34273 == env34274) = true)

theorem identity34274 : scanCanonicalize (H12AffineFastState.compose env34274 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34274 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env34275 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,9,5157,0,3,5172,2049,1024,1,4144,0,49,3,8,17,2081,5173,4129,2080,1056,1,4,0,5125,544]

theorem envBound34275 : H12AffineFastState.Bounded env34275 := by
  intro p hp
  have h : env34275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34274_34275 : H12AffineEnvironment.transform 7 4 env34274 = env34275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34274 == env34275) = true)

theorem identity34275 : scanCanonicalize (H12AffineFastState.compose env34275 (packedSelected [2,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34275 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env34276 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,0,3,5141,2049,1024,1,4113,0,16,3,8,17,2048,5140,4096,2049,1025,1,4,0,5125,513]

theorem envBound34276 : H12AffineFastState.Bounded env34276 := by
  intro p hp
  have h : env34276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34275_34276 : H12AffineEnvironment.transform 4 1 env34275 = env34276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34275 == env34276) = true)

theorem identity34276 : scanCanonicalize (H12AffineFastState.compose env34276 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34276 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34277 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,4096,9,5124,0,3,5141,522,1024,1,4113,0,16,3,8,17,523,5140,4096,522,1025,1,4,0,5125,513]

theorem envBound34277 : H12AffineFastState.Bounded env34277 := by
  intro p hp
  have h : env34277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34276_34277 : H12AffineEnvironment.transform 10 523 env34276 = env34277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34276 == env34277) = true)

def env34278 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,16,9,1044,0,3,1029,522,1024,1,1,0,16,3,8,17,523,1028,16,522,1025,1,4,0,1045,513]

theorem envBound34278 : H12AffineFastState.Bounded env34278 := by
  intro p hp
  have h : env34278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34277_34278 : H12AffineEnvironment.transform 11 16 env34277 = env34278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34277 == env34278) = true)

theorem identity34278 : scanCanonicalize (H12AffineFastState.compose env34278 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound34278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34279 : List Nat := [2,4,8,5,1,5,9,4,512,1024,523,5,9,1025,0,3,1029,522,1024,1,1,0,5,3,8,4,523,1028,5,522,1025,1,4,0,1024,513]

theorem envBound34279 : H12AffineFastState.Bounded env34279 := by
  intro p hp
  have h : env34279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34278_34279 : H12AffineEnvironment.transform 3 5 env34278 = env34279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34278 == env34279) = true)

def env34280 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,5,9,1,0,3,5,522,0,1,1,0,5,3,8,4,523,4,5,522,1,1,4,0,0,513]

theorem envBound34280 : H12AffineFastState.Bounded env34280 := by
  intro p hp
  have h : env34280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34279_34280 : H12AffineEnvironment.transform 9 0 env34279 = env34280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env34279 == env34280) = true)

theorem identity34280 : scanCanonicalize (H12AffineFastState.compose env34280 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound34280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34281 : List Nat := [2,4,8,5,1,5,9,4,8,0,3,5,9,1,0,3,5,2,0,1,1,0,5,3,8,4,3,4,5,2,1,1,4,0,0,9]

theorem envBound34281 : H12AffineFastState.Bounded env34281 := by
  intro p hp
  have h : env34281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34280_34281 : H12AffineEnvironment.transform 8 8 env34280 = env34281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env34280 == env34281) = true)

def leafEnv34281 : List Nat := [2,4,8,5,1,5,9,4,8,0,3,5,9,1,0,3,5,2,0,1,1,0,5,3,0,8,1,4,3,4,5,2,1,1,4,0,5,2,0,9,1,0,0]

def active34281 : List Nat := [0,1,2]

def tree34281 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34281 : H12WitnessSearch.Good tree34281 := H12GlobalWitnessIndex.good

theorem leafIdentity34281 : H12AffineFastState.composeSystem env34281 rootObs = leafEnv34281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34281 rootObs == leafEnv34281) = true)

theorem terminalChecked34281 : H12PackedTerminal.terminalCheckFast leafEnv34281 active34281 tree34281 = true := by decide +kernel

def env34282 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,5,9,0,0,3,4,522,1,1,1,0,5,3,8,4,523,5,5,522,0,1,4,0,1,513]

theorem envBound34282 : H12AffineFastState.Bounded env34282 := by
  intro p hp
  have h : env34282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34279_34282 : H12AffineEnvironment.transform 9 1 env34279 = env34282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env34279 == env34282) = true)

theorem identity34282 : scanCanonicalize (H12AffineFastState.compose env34282 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34283 : List Nat := [0,4,8,5,1,5,9,4,512,1,521,5,9,0,0,1,4,520,1,1,1,0,5,1,8,4,521,5,5,520,0,1,4,0,1,513]

theorem envBound34283 : H12AffineFastState.Bounded env34283 := by
  intro p hp
  have h : env34283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34282_34283 : H12AffineEnvironment.transform 0 0 env34282 = env34283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34282 == env34283) = true)

def leafEnv34283 : List Nat := [0,4,8,5,1,5,9,4,512,1,521,5,9,0,0,1,4,520,1,1,1,0,5,1,1,8,1,4,521,5,5,520,0,1,4,0,5,0,1,513,1,0,0]

def active34283 : List Nat := [1,2,8]

def tree34283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34283 : H12WitnessSearch.Good tree34283 := H12GlobalWitnessIndex.good

theorem leafIdentity34283 : H12AffineFastState.composeSystem env34283 rootObs = leafEnv34283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34283 rootObs == leafEnv34283) = true)

theorem terminalChecked34283 : H12PackedTerminal.terminalCheckFast leafEnv34283 active34283 tree34283 = true := by decide +kernel

def env34284 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,17,9,1045,0,3,1028,522,1024,1,0,0,16,3,8,17,523,1029,17,522,1025,1,4,0,1044,513]

theorem envBound34284 : H12AffineFastState.Bounded env34284 := by
  intro p hp
  have h : env34284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34277_34284 : H12AffineEnvironment.transform 11 17 env34277 = env34284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34277 == env34284) = true)

theorem identity34284 : scanCanonicalize (H12AffineFastState.compose env34284 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound34284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34285 : List Nat := [2,4,8,16,1,16,9,4,512,0,523,17,9,21,0,3,4,522,0,1,0,0,16,3,8,17,523,5,17,522,1,1,4,0,20,513]

theorem envBound34285 : H12AffineFastState.Bounded env34285 := by
  intro p hp
  have h : env34285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34284_34285 : H12AffineEnvironment.transform 9 0 env34284 = env34285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env34284 == env34285) = true)

def env34286 : List Nat := [2,4,8,4,1,4,9,4,512,0,523,5,9,1,0,3,4,522,0,1,0,0,4,3,8,5,523,5,5,522,1,1,4,0,0,513]

theorem envBound34286 : H12AffineFastState.Bounded env34286 := by
  intro p hp
  have h : env34286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34285_34286 : H12AffineEnvironment.transform 3 4 env34285 = env34286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env34285 == env34286) = true)

theorem identity34286 : scanCanonicalize (H12AffineFastState.compose env34286 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34287 : List Nat := [1,4,8,4,1,4,9,4,512,0,520,5,9,1,0,0,4,521,0,1,0,0,4,0,8,5,520,5,5,521,1,1,4,0,0,513]

theorem envBound34287 : H12AffineFastState.Bounded env34287 := by
  intro p hp
  have h : env34287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34286_34287 : H12AffineEnvironment.transform 0 1 env34286 = env34287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34286 == env34287) = true)

def leafEnv34287 : List Nat := [1,4,8,4,1,4,9,4,512,0,520,5,9,1,0,0,4,521,0,1,0,0,4,0,0,8,1,5,520,5,5,521,1,1,4,0,5,1,0,513,1,1,0]

def active34287 : List Nat := [1,2,8]

def tree34287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34287 : H12WitnessSearch.Good tree34287 := H12GlobalWitnessIndex.good

theorem leafIdentity34287 : H12AffineFastState.composeSystem env34287 rootObs = leafEnv34287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34287 rootObs == leafEnv34287) = true)

theorem terminalChecked34287 : H12PackedTerminal.terminalCheckFast leafEnv34287 active34287 tree34287 = true := by decide +kernel

def env34288 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,4,9,0,0,3,4,522,0,1,0,0,5,3,8,4,523,5,4,522,1,1,4,0,1,513]

theorem envBound34288 : H12AffineFastState.Bounded env34288 := by
  intro p hp
  have h : env34288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34285_34288 : H12AffineEnvironment.transform 3 5 env34285 = env34288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34285 == env34288) = true)

theorem identity34288 : scanCanonicalize (H12AffineFastState.compose env34288 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound34288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34289 : List Nat := [2,4,8,5,1,5,9,4,9,0,2,4,9,0,0,3,4,3,0,1,0,0,5,3,8,4,2,5,4,3,1,1,4,0,1,8]

theorem envBound34289 : H12AffineFastState.Bounded env34289 := by
  intro p hp
  have h : env34289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34288_34289 : H12AffineEnvironment.transform 8 9 env34288 = env34289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env34288 == env34289) = true)

def leafEnv34289 : List Nat := [2,4,8,5,1,5,9,4,9,0,2,4,9,0,0,3,4,3,0,1,0,0,5,3,0,8,1,4,2,5,4,3,1,1,4,0,5,2,1,8,1,1,0]

def active34289 : List Nat := [0,1,2]

def tree34289 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34289 : H12WitnessSearch.Good tree34289 := H12GlobalWitnessIndex.good

theorem leafIdentity34289 : H12AffineFastState.composeSystem env34289 rootObs = leafEnv34289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34289 rootObs == leafEnv34289) = true)

theorem terminalChecked34289 : H12PackedTerminal.terminalCheckFast leafEnv34289 active34289 tree34289 = true := by decide +kernel

def env34290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,8388608,8874364,8328,65,4237692,8393985,8826272,8830977,453997,12645453,256,21792,46212,510650]

theorem envBound34290 : H12AffineFastState.Bounded env34290 := by
  intro p hp
  have h : env34290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34183_34290 : H12AffineEnvironment.transform 20 456945 env34183 = env34290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env34183 == env34290) = true)

def env34291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,98780,8328,65,4237692,458145,17664,10401,453997,4594925,256,21792,46212,510650]

theorem envBound34291 : H12AffineFastState.Bounded env34291 := by
  intro p hp
  have h : env34291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34290_34291 : H12AffineEnvironment.transform 22 452768 env34290 = env34291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env34290 == env34291) = true)

def env34292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,98780,8328,65,295420,458145,17664,10401,453997,144493,256,21792,46212,510650]

theorem envBound34292 : H12AffineFastState.Bounded env34292 := by
  intro p hp
  have h : env34292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34291_34292 : H12AffineEnvironment.transform 21 272512 env34291 = env34292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34291 == env34292) = true)

theorem identity34292 : scanCanonicalize (H12AffineFastState.compose env34292 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound34292 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180272,16,98780,8328,65,158028,5393,17664,10401,1501,144493,256,21792,46212,74250]

theorem envBound34293 : H12AffineFastState.Bounded env34293 := by
  intro p hp
  have h : env34293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34292_34293 : H12AffineEnvironment.transform 17 190640 env34292 = env34293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env34292 == env34293) = true)

theorem identity34293 : scanCanonicalize (H12AffineFastState.compose env34293 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34293 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,180272,16,41431,8328,65,158028,5393,17664,10401,1501,144493,256,21792,46212,513]

theorem envBound34294 : H12AffineFastState.Bounded env34294 := by
  intro p hp
  have h : env34294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34293_34294 : H12AffineEnvironment.transform 15 8203 env34293 = env34294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34293 == env34294) = true)

theorem identity34294 : scanCanonicalize (H12AffineFastState.compose env34294 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound34294 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43168,1024,32769,4161,32800,16,41431,8328,65,10588,5393,17664,10401,1501,29821,256,21792,46212,513]

theorem envBound34295 : H12AffineFastState.Bounded env34295 := by
  intro p hp
  have h : env34295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34294_34295 : H12AffineEnvironment.transform 16 16400 env34294 = env34295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34294 == env34295) = true)

theorem identity34295 : scanCanonicalize (H12AffineFastState.compose env34295 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34295 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13388,43168,1024,32769,4161,32800,16,41431,8328,65,10588,5393,12636,10401,1501,33,256,8572,46212,513]

theorem envBound34296 : H12AffineFastState.Bounded env34296 := by
  intro p hp
  have h : env34296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34295_34296 : H12AffineEnvironment.transform 13 13404 env34295 = env34296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34295 == env34296) = true)

theorem identity34296 : scanCanonicalize (H12AffineFastState.compose env34296 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34296 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8540,8203,13388,2556,1024,8541,4161,8572,16,139,8328,65,10588,5393,12636,10401,1501,33,256,8572,5592,513]

theorem envBound34297 : H12AffineFastState.Bounded env34297 := by
  intro p hp
  have h : env34297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34296_34297 : H12AffineEnvironment.transform 14 8540 env34296 = env34297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34296 == env34297) = true)

theorem identity34297 : scanCanonicalize (H12AffineFastState.compose env34297 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34297 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,0,343,5392,2556,1024,1,4161,32,16,139,468,65,2048,5393,4096,2557,1501,33,256,32,5592,513]

theorem envBound34298 : H12AffineFastState.Bounded env34298 := by
  intro p hp
  have h : env34298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34297_34298 : H12AffineEnvironment.transform 12 348 env34297 = env34298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34297 == env34298) = true)

theorem identity34298 : scanCanonicalize (H12AffineFastState.compose env34298 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3309) := by decide +kernel

theorem selectedBound34298 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3309,348,2541,0,343,2557,2556,1024,1,3244,32,16,139,468,65,2048,2556,3309,2557,1501,33,256,32,2357,513]

theorem envBound34299 : H12AffineFastState.Bounded env34299 := by
  intro p hp
  have h : env34299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34298_34299 : H12AffineEnvironment.transform 11 3309 env34298 = env34299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3309 env34298 == env34299) = true)

theorem identity34299 : scanCanonicalize (H12AffineFastState.compose env34299 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound34299 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env34300 : List Nat := [2,4,8,16,32,64,128,256,512,266,2048,2535,348,2541,0,343,2557,2556,266,1,2470,32,16,139,468,65,2048,2556,2535,2557,215,33,256,32,2357,513]

theorem envBound34300 : H12AffineFastState.Bounded env34300 := by
  intro p hp
  have h : env34300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34299_34300 : H12AffineEnvironment.transform 9 266 env34299 = env34300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env34299 == env34300) = true)

theorem identity34300 : scanCanonicalize (H12AffineFastState.compose env34300 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34300 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34301 : List Nat := [2,4,8,16,32,64,8,256,512,266,2048,2415,348,2405,0,343,2421,2420,266,1,2350,32,16,3,348,65,2048,2420,2415,2421,95,33,256,32,2357,513]

theorem envBound34301 : H12AffineFastState.Bounded env34301 := by
  intro p hp
  have h : env34301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34300_34301 : H12AffineEnvironment.transform 6 8 env34300 = env34301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34300 == env34301) = true)

theorem identity34301 : scanCanonicalize (H12AffineFastState.compose env34301 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34301 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34302 : List Nat := [2,4,8,11,32,64,8,256,512,266,2048,2415,327,2405,0,332,2414,2415,266,1,2350,32,11,3,327,65,2048,2415,2415,2414,68,33,256,32,2350,513]

theorem envBound34302 : H12AffineFastState.Bounded env34302 := by
  intro p hp
  have h : env34302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34301_34302 : H12AffineEnvironment.transform 3 11 env34301 = env34302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34301 == env34302) = true)

theorem identity34302 : scanCanonicalize (H12AffineFastState.compose env34302 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound34302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34303 : List Nat := [2,4,8,11,32,0,8,256,512,266,2048,2351,263,2341,0,268,2350,2351,266,1,2350,32,11,3,263,1,2048,2351,2351,2350,4,33,256,32,2350,513]

theorem envBound34303 : H12AffineFastState.Bounded env34303 := by
  intro p hp
  have h : env34303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34302_34303 : H12AffineEnvironment.transform 5 0 env34302 = env34303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34302 == env34303) = true)

theorem identity34303 : scanCanonicalize (H12AffineFastState.compose env34303 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 295) := by decide +kernel

theorem selectedBound34303 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34304 : List Nat := [2,4,8,11,32,0,8,256,295,266,2048,2351,263,2341,0,268,2350,2351,266,1,2350,32,11,3,263,1,2048,2351,2351,2350,4,33,256,32,2350,294]

theorem envBound34304 : H12AffineFastState.Bounded env34304 := by
  intro p hp
  have h : env34304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34303_34304 : H12AffineEnvironment.transform 8 295 env34303 = env34304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 295 env34303 == env34304) = true)

theorem identity34304 : scanCanonicalize (H12AffineFastState.compose env34304 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34304 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34305 : List Nat := [2,4,3,0,32,0,3,256,295,257,2048,2340,263,2341,0,263,2341,2340,257,1,2341,32,0,3,263,1,2048,2340,2340,2341,4,33,256,32,2341,294]

theorem envBound34305 : H12AffineFastState.Bounded env34305 := by
  intro p hp
  have h : env34305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34304_34305 : H12AffineEnvironment.transform 2 3 env34304 = env34305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34304 == env34305) = true)

theorem identity34305 : scanCanonicalize (H12AffineFastState.compose env34305 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34306 : List Nat := [2,4,3,0,32,0,3,4,35,5,2048,2080,3,2081,0,3,2081,2080,5,1,2081,32,0,3,3,1,2048,2080,2080,2081,4,33,4,32,2081,34]

theorem envBound34306 : H12AffineFastState.Bounded env34306 := by
  intro p hp
  have h : env34306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34305_34306 : H12AffineEnvironment.transform 7 4 env34305 = env34306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34305 == env34306) = true)

theorem identity34306 : scanCanonicalize (H12AffineFastState.compose env34306 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34306 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34307 : List Nat := [2,4,3,0,1,0,3,4,2,5,2048,2049,3,2048,0,3,2048,2049,5,1,2048,1,0,3,3,1,2048,2049,2049,2048,4,0,4,1,2048,3]

theorem envBound34307 : H12AffineFastState.Bounded env34307 := by
  intro p hp
  have h : env34307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34306_34307 : H12AffineEnvironment.transform 4 1 env34306 = env34307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34306 == env34307) = true)

theorem identity34307 : scanCanonicalize (H12AffineFastState.compose env34307 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34308 : List Nat := [2,3,3,0,1,0,3,3,2,2,2048,2049,3,2048,0,3,2048,2049,2,1,2048,1,0,3,3,1,2048,2049,2049,2048,3,0,3,1,2048,3]

theorem envBound34308 : H12AffineFastState.Bounded env34308 := by
  intro p hp
  have h : env34308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34307_34308 : H12AffineEnvironment.transform 1 3 env34307 = env34308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34307 == env34308) = true)

def env34309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,98780,8328,65,295421,458145,17664,10401,453997,144492,256,21792,46212,510650]

theorem envBound34309 : H12AffineFastState.Bounded env34309 := by
  intro p hp
  have h : env34309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34291_34309 : H12AffineEnvironment.transform 21 272513 env34291 = env34309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34291 == env34309) = true)

def env34310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452648,98644,8192,65,295285,458025,17664,10281,453997,144492,256,21792,46092,510514]

theorem envBound34310 : H12AffineFastState.Bounded env34310 := by
  intro p hp
  have h : env34310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34309_34310 : H12AffineEnvironment.transform 6 8 env34309 = env34310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34309 == env34310) = true)

theorem identity34310 : scanCanonicalize (H12AffineFastState.compose env34310 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound34310 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env34311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,100387,1024,32769,225370,106538,221195,98644,8192,65,67926,226570,17664,10281,222542,144492,256,21792,46092,147985]

theorem envBound34311 : H12AffineFastState.Bounded env34311 := by
  intro p hp
  have h : env34311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34310_34311 : H12AffineEnvironment.transform 17 100387 env34310 = env34311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env34310 == env34311) = true)

theorem identity34311 : scanCanonicalize (H12AffineFastState.compose env34311 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound34311 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,100387,1024,32769,102678,106538,98631,98644,8192,65,67926,103494,17664,10281,99330,54560,256,21792,46092,41821]

theorem envBound34312 : H12AffineFastState.Bounded env34312 := by
  intro p hp
  have h : env34312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34311_34312 : H12AffineEnvironment.transform 16 57676 env34311 = env34312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env34311 == env34312) = true)

theorem identity34312 : scanCanonicalize (H12AffineFastState.compose env34312 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34312 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env34313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,76159,1024,8541,77898,65910,73755,73736,8192,65,67926,79130,17664,10281,75102,29820,256,21792,5456,513]

theorem envBound34313 : H12AffineFastState.Bounded env34313 := by
  intro p hp
  have h : env34313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34312_34313 : H12AffineEnvironment.transform 14 8540 env34312 = env34313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34312 == env34313) = true)

theorem identity34313 : scanCanonicalize (H12AffineFastState.compose env34313 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound34313 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28698,16400,22885,1024,8541,16464,29036,20481,20498,8192,65,31052,17664,17664,10281,21828,29820,256,21792,5456,513]

theorem envBound34314 : H12AffineFastState.Bounded env34314 := by
  intro p hp
  have h : env34314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34313_34314 : H12AffineEnvironment.transform 15 28698 env34313 = env34314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env34313 == env34314) = true)

theorem identity34314 : scanCanonicalize (H12AffineFastState.compose env34314 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound34314 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,8540,343,12637,10280,1024,8541,12573,33,8524,8543,8192,65,2049,13389,13389,10281,9225,1329,256,9325,5456,513]

theorem envBound34315 : H12AffineFastState.Bounded env34315 := by
  intro p hp
  have h : env34315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34314_34315 : H12AffineEnvironment.transform 13 12621 env34314 = env34315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env34314 == env34315) = true)

theorem identity34315 : scanCanonicalize (H12AffineFastState.compose env34315 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34315 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env34316 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8312,115,12409,10280,1024,8313,12345,33,8296,8315,8192,65,2049,13389,13389,10281,9225,1045,36,9325,5236,513]

theorem envBound34316 : H12AffineFastState.Bounded env34316 := by
  intro p hp
  have h : env34316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34315_34316 : H12AffineEnvironment.transform 7 36 env34315 = env34316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34315 == env34316) = true)

theorem identity34316 : scanCanonicalize (H12AffineFastState.compose env34316 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound34316 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env34317 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,8192,11293,8312,115,11277,10280,1024,8313,11341,33,8296,8315,8192,65,2049,10297,10297,10281,9225,1045,36,9325,2048,513]

theorem envBound34317 : H12AffineFastState.Bounded env34317 := by
  intro p hp
  have h : env34317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34316_34317 : H12AffineEnvironment.transform 11 3188 env34316 = env34317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env34316 == env34317) = true)

theorem identity34317 : scanCanonicalize (H12AffineFastState.compose env34317 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound34317 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env34318 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,121,3172,1,115,3188,2129,1024,0,3124,33,17,2,121,65,2049,2112,2112,2128,1136,1045,36,1044,2048,513]

theorem envBound34318 : H12AffineFastState.Bounded env34318 := by
  intro p hp
  have h : env34318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34317_34318 : H12AffineEnvironment.transform 12 121 env34317 = env34318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env34317 == env34318) = true)

theorem identity34318 : scanCanonicalize (H12AffineFastState.compose env34318 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34318 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34319 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,2112,121,2128,1,115,2112,2129,52,0,2048,33,17,2,121,65,2049,2112,2112,2128,68,33,36,32,2048,513]

theorem envBound34319 : H12AffineFastState.Bounded env34319 := by
  intro p hp
  have h : env34319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34318_34319 : H12AffineEnvironment.transform 9 52 env34318 = env34319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34318 == env34319) = true)

theorem identity34319 : scanCanonicalize (H12AffineFastState.compose env34319 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34320 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,41,2048,1,35,2064,2049,52,0,2048,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,513]

theorem envBound34320 : H12AffineFastState.Bounded env34320 := by
  intro p hp
  have h : env34320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34319_34320 : H12AffineEnvironment.transform 5 16 env34319 = env34320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34319 == env34320) = true)

def env34321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452649,98645,8193,65,295284,458024,17664,10280,453997,144492,256,21792,46093,510515]

theorem envBound34321 : H12AffineFastState.Bounded env34321 := by
  intro p hp
  have h : env34321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34309_34321 : H12AffineEnvironment.transform 6 9 env34309 = env34321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34309 == env34321) = true)

def env34322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272441,98645,8193,65,295284,277816,17664,10280,273789,62588,256,21792,46093,330275]

theorem envBound34322 : H12AffineFastState.Bounded env34322 := by
  intro p hp
  have h : env34322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34321_34322 : H12AffineEnvironment.transform 16 49168 env34321 = env34322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env34321 == env34322) = true)

theorem identity34322 : scanCanonicalize (H12AffineFastState.compose env34322 (packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34322 : packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env34323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,33,16,98645,8193,65,43357,5393,17664,10280,1364,62588,256,21792,46093,74250]

theorem envBound34323 : H12AffineFastState.Bounded env34323 := by
  intro p hp
  have h : env34323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34322_34323 : H12AffineEnvironment.transform 17 10281 env34322 = env34323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34322 == env34323) = true)

theorem identity34323 : scanCanonicalize (H12AffineFastState.compose env34323 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound34323 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49168,10281,1024,32769,4161,33,16,8543,8193,65,43357,5393,17664,10280,1364,62588,256,21792,46093,33280]

theorem envBound34324 : H12AffineFastState.Bounded env34324 := by
  intro p hp
  have h : env34324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34323_34324 : H12AffineEnvironment.transform 15 40970 env34323 = env34324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env34323 == env34324) = true)

theorem identity34324 : scanCanonicalize (H12AffineFastState.compose env34324 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34324 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env34325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40970,46156,10281,1024,32769,4161,33,16,8543,8193,65,43357,5393,12636,10280,1364,32800,256,8572,46093,33280]

theorem envBound34325 : H12AffineFastState.Bounded env34325 := by
  intro p hp
  have h : env34325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34324_34325 : H12AffineEnvironment.transform 13 13404 env34324 = env34325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34324 == env34325) = true)

theorem identity34325 : scanCanonicalize (H12AffineFastState.compose env34325 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34325 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,342,5392,10281,1024,8541,4161,33,16,8543,8193,65,2049,5393,12636,10280,1364,8572,256,8572,5457,9052]

theorem envBound34326 : H12AffineFastState.Bounded env34326 := by
  intro p hp
  have h : env34326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34325_34326 : H12AffineEnvironment.transform 14 8540 env34325 = env34326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34325 == env34326) = true)

theorem identity34326 : scanCanonicalize (H12AffineFastState.compose env34326 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound34326 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1296,342,5392,3173,1024,1297,4161,33,16,1299,1101,65,2049,5393,5392,3172,1364,1328,256,1328,5457,1808]

theorem envBound34327 : H12AffineFastState.Bounded env34327 := by
  intro p hp
  have h : env34327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34326_34327 : H12AffineEnvironment.transform 12 1100 env34326 = env34327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env34326 == env34327) = true)

theorem identity34327 : scanCanonicalize (H12AffineFastState.compose env34327 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound34327 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env34328 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,8,4112,340,342,4436,2081,68,341,4161,33,16,343,9,65,2049,4437,4436,2080,272,372,256,372,4373,852]

theorem envBound34328 : H12AffineFastState.Bounded env34328 := by
  intro p hp
  have h : env34328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34327_34328 : H12AffineEnvironment.transform 9 68 env34327 = env34328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env34327 == env34328) = true)

theorem identity34328 : scanCanonicalize (H12AffineFastState.compose env34328 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound34328 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env34329 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,4096,8,4112,0,2,4096,2081,68,1,4161,33,16,3,9,65,2049,4097,4096,2080,68,32,84,32,4161,512]

theorem envBound34329 : H12AffineFastState.Bounded env34329 := by
  intro p hp
  have h : env34329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34328_34329 : H12AffineEnvironment.transform 7 84 env34328 = env34329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env34328 == env34329) = true)

theorem identity34329 : scanCanonicalize (H12AffineFastState.compose env34329 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34330 : List Nat := [2,4,8,16,32,16,9,4,512,20,2048,4096,8,4112,0,2,4096,2081,20,1,4113,33,16,3,9,17,2049,4097,4096,2080,20,32,4,32,4113,512]

theorem envBound34330 : H12AffineFastState.Bounded env34330 := by
  intro p hp
  have h : env34330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34329_34330 : H12AffineEnvironment.transform 5 16 env34329 = env34330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34329 == env34330) = true)

theorem identity34330 : scanCanonicalize (H12AffineFastState.compose env34330 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound34330 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34331 : List Nat := [2,4,8,16,32,16,9,4,512,20,554,4096,8,4112,0,2,4096,523,20,1,4113,33,16,3,9,17,555,4097,4096,522,20,32,4,32,4113,512]

theorem envBound34331 : H12AffineFastState.Bounded env34331 := by
  intro p hp
  have h : env34331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34330_34331 : H12AffineEnvironment.transform 10 554 env34330 = env34331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env34330 == env34331) = true)

def env34332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272440,98645,8193,65,295284,277817,17664,10280,273788,62589,256,21792,46093,330274]

theorem envBound34332 : H12AffineFastState.Bounded env34332 := by
  intro p hp
  have h : env34332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34321_34332 : H12AffineEnvironment.transform 16 49169 env34321 = env34332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env34321 == env34332) = true)

theorem identity34332 : scanCanonicalize (H12AffineFastState.compose env34332 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34332 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,33,17,98645,8193,65,43357,5392,17664,10280,1365,62589,256,21792,46093,74251]

theorem envBound34333 : H12AffineFastState.Bounded env34333 := by
  intro p hp
  have h : env34333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34332_34333 : H12AffineEnvironment.transform 17 10281 env34332 = env34333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34332 == env34333) = true)

theorem identity34333 : scanCanonicalize (H12AffineFastState.compose env34333 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound34333 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10281,1024,32769,4160,33,17,8543,8193,65,43357,5392,17664,10280,1365,62589,256,21792,46093,33281]

theorem envBound34334 : H12AffineFastState.Bounded env34334 := by
  intro p hp
  have h : env34334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34333_34334 : H12AffineEnvironment.transform 15 40970 env34333 = env34334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env34333 == env34334) = true)

theorem identity34334 : scanCanonicalize (H12AffineFastState.compose env34334 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34334 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env34335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,46156,10281,1024,32769,4160,33,17,8543,8193,65,43357,5392,12637,10280,1365,32800,256,8573,46093,33281]

theorem envBound34335 : H12AffineFastState.Bounded env34335 := by
  intro p hp
  have h : env34335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34334_34335 : H12AffineEnvironment.transform 13 13405 env34334 = env34335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34334 == env34335) = true)

theorem identity34335 : scanCanonicalize (H12AffineFastState.compose env34335 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34335 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33110,38160,2421,1024,32769,4160,33,17,3,349,65,34817,5392,4097,2420,1365,32800,256,33,38225,33281]

theorem envBound34336 : H12AffineFastState.Bounded env34336 := by
  intro p hp
  have h : env34336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34335_34336 : H12AffineEnvironment.transform 12 348 env34335 = env34336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34335 == env34336) = true)

theorem identity34336 : scanCanonicalize (H12AffineFastState.compose env34336 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34336 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2421,1024,1,4160,33,17,3,349,65,2049,5392,4097,2420,1365,32,256,33,5457,513]

theorem envBound34337 : H12AffineFastState.Bounded env34337 := by
  intro p hp
  have h : env34337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34336_34337 : H12AffineEnvironment.transform 14 0 env34336 = env34337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34336 == env34337) = true)

theorem identity34337 : scanCanonicalize (H12AffineFastState.compose env34337 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound34337 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1087,4096,348,5377,0,342,5392,1354,1024,1,4160,33,17,3,349,65,1086,5392,4097,1355,1365,32,256,33,5457,513]

theorem envBound34338 : H12AffineFastState.Bounded env34338 := by
  intro p hp
  have h : env34338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34337_34338 : H12AffineEnvironment.transform 10 1087 env34337 = env34338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env34337 == env34338) = true)

theorem identity34338 : scanCanonicalize (H12AffineFastState.compose env34338 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound34338 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1087,80,348,1361,0,342,1344,1354,1024,1,16,33,17,3,349,65,1086,1344,81,1355,1365,32,256,33,1281,513]

theorem envBound34339 : H12AffineFastState.Bounded env34339 := by
  intro p hp
  have h : env34339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34338_34339 : H12AffineEnvironment.transform 11 80 env34338 = env34339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env34338 == env34339) = true)

theorem identity34339 : scanCanonicalize (H12AffineFastState.compose env34339 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34339 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env34340 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,0,268,1281,0,262,1296,1306,1024,1,16,33,17,3,269,17,1086,1296,1,1307,1285,32,256,33,1281,513]

theorem envBound34340 : H12AffineFastState.Bounded env34340 := by
  intro p hp
  have h : env34340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34339_34340 : H12AffineEnvironment.transform 5 16 env34339 = env34340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34339 == env34340) = true)

theorem identity34340 : scanCanonicalize (H12AffineFastState.compose env34340 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34340 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34341 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1087,0,40,1061,0,34,1076,1086,1024,1,16,33,17,3,41,17,1086,1076,1,1087,1057,32,36,33,1061,513]

theorem envBound34341 : H12AffineFastState.Bounded env34341 := by
  intro p hp
  have h : env34341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34340_34341 : H12AffineEnvironment.transform 7 36 env34340 = env34341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34340 == env34341) = true)

theorem identity34341 : scanCanonicalize (H12AffineFastState.compose env34341 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound34341 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34342 : List Nat := [2,4,8,16,27,16,9,31,512,1024,1028,0,19,1054,0,25,1039,1029,1024,1,16,26,17,3,18,17,1029,1039,1,1028,1050,27,31,26,1054,513]

theorem envBound34342 : H12AffineFastState.Bounded env34342 := by
  intro p hp
  have h : env34342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34341_34342 : H12AffineEnvironment.transform 4 27 env34341 = env34342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env34341 == env34342) = true)

def env34343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,98781,8328,65,4237692,458144,17665,10400,453997,4594924,256,21792,46212,510650]

theorem envBound34343 : H12AffineFastState.Bounded env34343 := by
  intro p hp
  have h : env34343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34290_34343 : H12AffineEnvironment.transform 22 452769 env34290 = env34343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env34290 == env34343) = true)

def env34344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,98781,8328,65,295420,458144,17665,10400,453997,144492,256,21792,46212,510650]

theorem envBound34344 : H12AffineFastState.Bounded env34344 := by
  intro p hp
  have h : env34344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34343_34344 : H12AffineEnvironment.transform 21 272512 env34343 = env34344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34343 == env34344) = true)

theorem identity34344 : scanCanonicalize (H12AffineFastState.compose env34344 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound34344 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58517,144612,62661,98781,8328,65,171416,57796,17665,10400,61705,144492,256,21792,46212,120542]

theorem envBound34345 : H12AffineFastState.Bounded env34345 := by
  intro p hp
  have h : env34345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34344_34345 : H12AffineEnvironment.transform 17 138340 env34344 = env34345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env34344 == env34345) = true)

def env34346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58397,144492,62541,98645,8192,65,171280,57676,17665,10280,61705,144492,256,21792,46092,120406]

theorem envBound34346 : H12AffineFastState.Bounded env34346 := by
  intro p hp
  have h : env34346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34345_34346 : H12AffineEnvironment.transform 6 8 env34345 = env34346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34345 == env34346) = true)

theorem identity34346 : scanCanonicalize (H12AffineFastState.compose env34346 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound34346 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env34347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,78959,75787,1024,32769,58397,65539,62541,98645,8192,65,108927,57676,17665,10280,61705,65539,256,21792,46092,120406]

theorem envBound34347 : H12AffineFastState.Bounded env34347 := by
  intro p hp
  have h : env34347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34346_34347 : H12AffineEnvironment.transform 16 78959 env34346 = env34347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env34346 == env34347) = true)

theorem identity34347 : scanCanonicalize (H12AffineFastState.compose env34347 (packedSelected [3,4,7,8,9,11,12,15,16,20,24,26,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34347 : packedSelected [3,4,7,8,9,11,12,15,16,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env34348 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,78959,75787,1024,32769,58397,65539,62541,98337,8192,65,108555,57400,17525,10280,61565,65539,116,21588,46092,120406]

theorem envBound34348 : H12AffineFastState.Bounded env34348 := by
  intro p hp
  have h : env34348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34347_34348 : H12AffineEnvironment.transform 7 116 env34347 = env34348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34347 == env34348) = true)

theorem identity34348 : scanCanonicalize (H12AffineFastState.compose env34348 (packedSelected [0,1,2,5,6,8,11,14,16,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound34348 : packedSelected [0,1,2,5,6,8,11,14,16,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34349 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,32768,65536,78959,75787,1024,32769,45161,65539,41017,98337,8192,65,108555,46156,4097,10280,41993,65539,116,32,46092,98850]

theorem envBound34349 : H12AffineFastState.Bounded env34349 := by
  intro p hp
  have h : env34349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34348_34349 : H12AffineEnvironment.transform 13 5236 env34348 = env34349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env34348 == env34349) = true)

theorem identity34349 : scanCanonicalize (H12AffineFastState.compose env34349 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34349 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34350 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,1,65536,78959,75787,1024,0,12392,65539,8248,65568,8192,65,75786,13389,4097,10280,9224,65539,116,32,13325,66083]

theorem envBound34350 : H12AffineFastState.Bounded env34350 := by
  intro p hp
  have h : env34350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34349_34350 : H12AffineEnvironment.transform 14 1 env34349 = env34350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34349 == env34350) = true)

theorem identity34350 : scanCanonicalize (H12AffineFastState.compose env34350 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound34350 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34351 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,8192,2129,1,65536,75850,75787,1024,0,11341,65539,8248,65568,8192,65,75786,10344,3108,10280,9224,65539,116,32,10280,66083]

theorem envBound34351 : H12AffineFastState.Bounded env34351 := by
  intro p hp
  have h : env34351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34350_34351 : H12AffineEnvironment.transform 11 3109 env34350 = env34351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env34350 == env34351) = true)

theorem identity34351 : scanCanonicalize (H12AffineFastState.compose env34351 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34351 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34352 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,1061,8192,81,1,65536,73802,73739,1024,0,9293,65539,8248,65568,8192,65,73738,8296,1060,8232,9224,65539,116,32,8232,66083]

theorem envBound34352 : H12AffineFastState.Bounded env34352 := by
  intro p hp
  have h : env34352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34351_34352 : H12AffineEnvironment.transform 10 0 env34351 = env34352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34351 == env34352) = true)

theorem identity34352 : scanCanonicalize (H12AffineFastState.compose env34352 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34352 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34353 : List Nat := [2,4,8,16,32,64,8,116,512,1024,0,1061,40,81,1,65536,65634,65571,1024,0,1125,65539,16,65568,40,65,65570,64,1060,0,1056,65539,116,32,0,66083]

theorem envBound34353 : H12AffineFastState.Bounded env34353 := by
  intro p hp
  have h : env34353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34352_34353 : H12AffineEnvironment.transform 12 40 env34352 = env34353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34352 == env34353) = true)

def env34354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144493,62540,98644,8193,65,171281,57677,17665,10281,61705,144492,256,21792,46093,120407]

theorem envBound34354 : H12AffineFastState.Bounded env34354 := by
  intro p hp
  have h : env34354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34345_34354 : H12AffineEnvironment.transform 6 9 env34345 = env34354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34345 == env34354) = true)

theorem identity34354 : scanCanonicalize (H12AffineFastState.compose env34354 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34354 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env34355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,17729,144493,21777,73737,8193,65,146508,16400,17665,10281,20564,144492,256,21792,5456,96010]

theorem envBound34355 : H12AffineFastState.Bounded env34355 := by
  intro p hp
  have h : env34355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34354_34355 : H12AffineEnvironment.transform 14 8541 env34354 = env34355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34354 == env34355) = true)

theorem identity34355 : scanCanonicalize (H12AffineFastState.compose env34355 (packedSelected [1,3,16,17,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound34355 : packedSelected [1,3,16,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env34356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16448,23588,1024,8540,17729,29741,21777,73737,8193,65,31756,16400,17665,10281,20564,29740,256,21792,5456,96010]

theorem envBound34356 : H12AffineFastState.Bounded env34356 := by
  intro p hp
  have h : env34356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34355_34356 : H12AffineEnvironment.transform 16 16448 env34355 = env34356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env34355 == env34356) = true)

theorem identity34356 : scanCanonicalize (H12AffineFastState.compose env34356 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34356 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16448,23588,1024,8540,17729,29741,21777,8463,8193,65,31756,16400,17665,10281,20564,29740,256,21792,5456,30220]

theorem envBound34357 : H12AffineFastState.Bounded env34357 := by
  intro p hp
  have h : env34357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34356_34357 : H12AffineEnvironment.transform 15 262 env34356 = env34357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34356 == env34357) = true)

theorem identity34357 : scanCanonicalize (H12AffineFastState.compose env34357 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34357 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,81,262,16448,23588,1024,80,17729,21793,21777,3,269,65,23808,16400,17665,2341,20564,21792,256,21792,5456,22272]

theorem envBound34358 : H12AffineFastState.Bounded env34358 := by
  intro p hp
  have h : env34358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34357_34358 : H12AffineEnvironment.transform 12 268 env34357 = env34358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34357 == env34358) = true)

theorem identity34358 : scanCanonicalize (H12AffineFastState.compose env34358 (packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2608) := by decide +kernel

theorem selectedBound34358 : packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,2608,81,262,2672,5652,1024,80,3953,7953,7969,3,269,65,5936,2592,3889,2341,6756,7952,256,7952,5456,7472]

theorem envBound34359 : H12AffineFastState.Bounded env34359 := by
  intro p hp
  have h : env34359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34358_34359 : H12AffineEnvironment.transform 13 2608 env34358 = env34359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2608 env34358 == env34359) = true)

theorem identity34359 : scanCanonicalize (H12AffineFastState.compose env34359 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3937) := by decide +kernel

theorem selectedBound34359 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env34360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3937,268,2608,81,262,2672,2421,1024,80,3953,112,64,3,269,65,2129,2592,3889,2341,1285,113,256,113,2609,593]

theorem envBound34360 : H12AffineFastState.Bounded env34360 := by
  intro p hp
  have h : env34360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34359_34360 : H12AffineEnvironment.transform 11 3937 env34359 = env34360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3937 env34359 == env34360) = true)

theorem identity34360 : scanCanonicalize (H12AffineFastState.compose env34360 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound34360 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34361 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3637,88,2608,81,82,2672,2081,1024,80,3621,112,64,3,89,65,2129,2592,3685,2161,1105,113,84,113,2609,593]

theorem envBound34361 : H12AffineFastState.Bounded env34361 := by
  intro p hp
  have h : env34361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34360_34361 : H12AffineEnvironment.transform 7 84 env34360 = env34361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env34360 == env34361) = true)

theorem identity34361 : scanCanonicalize (H12AffineFastState.compose env34361 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34361 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34362 : List Nat := [2,4,8,16,32,64,9,84,512,1024,48,1541,88,512,81,82,576,17,1024,80,1557,112,64,3,89,65,97,528,1621,65,1105,113,84,113,513,593]

theorem envBound34362 : H12AffineFastState.Bounded env34362 := by
  intro p hp
  have h : env34362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34361_34362 : H12AffineEnvironment.transform 10 48 env34361 = env34362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34361 == env34362) = true)

theorem identity34362 : scanCanonicalize (H12AffineFastState.compose env34362 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound34362 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34363 : List Nat := [2,4,8,16,32,64,9,84,512,564,48,49,88,512,81,82,576,17,564,80,33,112,64,3,89,65,97,528,97,65,613,113,84,113,513,593]

theorem envBound34363 : H12AffineFastState.Bounded env34363 := by
  intro p hp
  have h : env34363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34362_34363 : H12AffineEnvironment.transform 9 564 env34362 = env34363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env34362 == env34363) = true)

theorem identity34363 : scanCanonicalize (H12AffineFastState.compose env34363 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound34363 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34364 : List Nat := [2,4,8,16,32,64,9,84,80,100,48,49,88,80,81,82,16,17,100,80,33,112,64,3,89,65,97,64,97,65,53,113,84,113,81,1]

theorem envBound34364 : H12AffineFastState.Bounded env34364 := by
  intro p hp
  have h : env34364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34363_34364 : H12AffineEnvironment.transform 8 80 env34363 = env34364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env34363 == env34364) = true)

theorem identity34364 : scanCanonicalize (H12AffineFastState.compose env34364 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound34364 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env34365 : List Nat := [2,4,8,16,32,1,9,21,17,37,48,49,25,17,16,19,16,17,37,17,33,49,1,3,24,0,32,1,32,0,53,48,21,48,16,1]

theorem envBound34365 : H12AffineFastState.Bounded env34365 := by
  intro p hp
  have h : env34365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34364_34365 : H12AffineEnvironment.transform 5 1 env34364 = env34365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34364 == env34365) = true)

def env34366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,98781,8328,65,295421,458144,17665,10400,453997,144493,256,21792,46212,510650]

theorem envBound34366 : H12AffineFastState.Bounded env34366 := by
  intro p hp
  have h : env34366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34343_34366 : H12AffineEnvironment.transform 21 272513 env34343 = env34366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34343 == env34366) = true)

theorem identity34366 : scanCanonicalize (H12AffineFastState.compose env34366 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34366 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396324,272513,400500,95496,8328,65,292136,395637,17665,10400,399800,144493,256,21792,16465,474735]

theorem envBound34367 : H12AffineFastState.Bounded env34367 := by
  intro p hp
  have h : env34367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34366_34367 : H12AffineEnvironment.transform 14 29909 env34366 = env34367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34366 == env34367) = true)

def env34368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140420,33,144596,95496,8328,65,23944,139733,17665,10400,143640,144493,256,21792,16465,202447]

theorem envBound34368 : H12AffineFastState.Bounded env34368 := by
  intro p hp
  have h : env34368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34367_34368 : H12AffineEnvironment.transform 17 10400 env34367 = env34368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34367 == env34368) = true)

theorem identity34368 : scanCanonicalize (H12AffineFastState.compose env34368 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound34368 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env34369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10400,1024,29908,83103,33,87247,95496,8328,65,23944,82382,17665,10400,86275,87158,256,21792,16465,30420]

theorem envBound34369 : H12AffineFastState.Bounded env34369 := by
  intro p hp
  have h : env34369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34368_34369 : H12AffineEnvironment.transform 16 90139 env34368 = env34369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env34368 == env34369) = true)

theorem identity34369 : scanCanonicalize (H12AffineFastState.compose env34369 (packedSelected [1,5,8,11,16,17,18,19,20,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34369 : packedSelected [1,5,8,11,16,17,18,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env34370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10281,1024,29789,82966,33,87110,95496,8193,65,23809,82247,17665,10281,86275,87158,256,21792,16465,30301]

theorem envBound34370 : H12AffineFastState.Bounded env34370 := by
  intro p hp
  have h : env34370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34369_34370 : H12AffineEnvironment.transform 6 9 env34369 = env34370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34369 == env34370) = true)

theorem identity34370 : scanCanonicalize (H12AffineFastState.compose env34370 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34370 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16401,10281,1024,29789,25628,33,29772,21762,8193,65,23809,24909,17665,10281,28937,29820,256,21792,16465,30301]

theorem envBound34371 : H12AffineFastState.Bounded env34371 := by
  intro p hp
  have h : env34371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34370_34371 : H12AffineEnvironment.transform 15 8202 env34370 = env34371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34370 == env34371) = true)

theorem identity34371 : scanCanonicalize (H12AffineFastState.compose env34371 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34371 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env34372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8461,8202,5440,10281,1024,8460,12621,33,8477,83,8193,65,2128,13340,4176,10281,9304,8493,256,113,5376,8972]

theorem envBound34372 : H12AffineFastState.Bounded env34372 := by
  intro p hp
  have h : env34372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34371_34372 : H12AffineEnvironment.transform 13 5457 env34371 = env34372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34371 == env34372) = true)

theorem identity34372 : scanCanonicalize (H12AffineFastState.compose env34372 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34372 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env34373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,343,5440,2420,1024,81,4112,33,64,83,348,65,2128,5441,4176,2420,1285,112,256,113,5376,593]

theorem envBound34373 : H12AffineFastState.Bounded env34373 := by
  intro p hp
  have h : env34373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34372_34373 : H12AffineEnvironment.transform 12 349 env34372 = env34373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34372 == env34373) = true)

theorem identity34373 : scanCanonicalize (H12AffineFastState.compose env34373 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34373 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34374 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5392,2340,1024,1,4112,33,16,3,268,17,2048,5393,4096,2340,1285,32,256,33,5376,513]

theorem envBound34374 : H12AffineFastState.Bounded env34374 := by
  intro p hp
  have h : env34374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34373_34374 : H12AffineEnvironment.transform 5 16 env34373 = env34374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34373 == env34374) = true)

theorem identity34374 : scanCanonicalize (H12AffineFastState.compose env34374 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34375 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,35,5172,2048,1024,1,4112,33,16,3,40,17,2048,5173,4096,2048,1057,32,36,33,5156,513]

theorem envBound34375 : H12AffineFastState.Bounded env34375 := by
  intro p hp
  have h : env34375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34374_34375 : H12AffineEnvironment.transform 7 36 env34374 = env34375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34374 == env34375) = true)

theorem identity34375 : scanCanonicalize (H12AffineFastState.compose env34375 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34375 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34376 : List Nat := [2,4,8,16,32,16,9,36,512,1024,523,4096,41,5157,0,35,5172,523,1024,1,4112,33,16,3,40,17,523,5173,4096,523,1057,32,36,33,5156,513]

theorem envBound34376 : H12AffineFastState.Bounded env34376 := by
  intro p hp
  have h : env34376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34375_34376 : H12AffineEnvironment.transform 10 523 env34375 = env34376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34375 == env34376) = true)

theorem identity34376 : scanCanonicalize (H12AffineFastState.compose env34376 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34376 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34377 : List Nat := [2,4,8,16,1,16,9,5,512,1024,523,4096,8,5124,0,2,5141,523,1024,1,4112,0,16,3,9,17,523,5140,4096,523,1024,1,5,0,5125,513]

theorem envBound34377 : H12AffineFastState.Bounded env34377 := by
  intro p hp
  have h : env34377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34376_34377 : H12AffineEnvironment.transform 4 1 env34376 = env34377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34376 == env34377) = true)

def env34378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140421,32,144597,95496,8328,65,23945,139732,17665,10400,143641,144493,256,21792,16465,202446]

theorem envBound34378 : H12AffineFastState.Bounded env34378 := by
  intro p hp
  have h : env34378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34367_34378 : H12AffineEnvironment.transform 17 10401 env34367 = env34378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34367 == env34378) = true)

theorem identity34378 : scanCanonicalize (H12AffineFastState.compose env34378 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound34378 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env34379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79250,10401,1024,29908,69911,32,65863,95496,8328,65,23945,70726,17665,10400,66699,66047,256,21792,16465,9052]

theorem envBound34379 : H12AffineFastState.Bounded env34379 := by
  intro p hp
  have h : env34379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34378_34379 : H12AffineEnvironment.transform 16 79250 env34378 = env34379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env34378 == env34379) = true)

theorem identity34379 : scanCanonicalize (H12AffineFastState.compose env34379 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound34379 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,19,20,23,28] rootPS < 2^1333 := by decide +kernel

def env34380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,372,65536,79250,10401,1024,373,69911,32,65863,65705,8328,65,10280,70726,12448,10400,66699,66047,256,8321,13808,9052]

theorem envBound34380 : H12AffineFastState.Bounded env34380 := by
  intro p hp
  have h : env34380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34379_34380 : H12AffineEnvironment.transform 13 13729 env34379 = env34380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env34379 == env34380) = true)

theorem identity34380 : scanCanonicalize (H12AffineFastState.compose env34380 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34380 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env34381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5372,372,65536,70863,2556,1024,373,69911,32,65863,65705,469,65,2421,70726,4605,2557,66699,66047,256,476,5293,513]

theorem envBound34381 : H12AffineFastState.Bounded env34381 := by
  intro p hp
  have h : env34381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34380_34381 : H12AffineEnvironment.transform 12 349 env34380 = env34381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34380 == env34381) = true)

theorem identity34381 : scanCanonicalize (H12AffineFastState.compose env34381 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound34381 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34382 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,4540,372,65536,70031,2556,320,373,69911,32,65863,65705,469,65,2421,69894,4605,2557,65995,66047,256,476,4589,513]

theorem envBound34382 : H12AffineFastState.Bounded env34382 := by
  intro p hp
  have h : env34382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34381_34382 : H12AffineEnvironment.transform 9 320 env34381 = env34382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34381 == env34382) = true)

theorem identity34382 : scanCanonicalize (H12AffineFastState.compose env34382 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 6558) := by decide +kernel

theorem selectedBound34382 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env34383 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,4540,372,6558,2065,2556,320,373,2185,32,6361,6455,469,65,2421,2200,4605,2557,6229,6241,256,476,4589,513]

theorem envBound34383 : H12AffineFastState.Bounded env34383 := by
  intro p hp
  have h : env34383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34382_34383 : H12AffineEnvironment.transform 15 6558 env34382 = env34383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6558 env34382 == env34383) = true)

theorem identity34383 : scanCanonicalize (H12AffineFastState.compose env34383 (packedSelected [0,1,2,3,5,6,7,8,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound34383 : packedSelected [0,1,2,3,5,6,7,8,11,16] rootPS < 2^1333 := by decide +kernel

def env34384 : List Nat := [2,4,8,16,32,64,128,256,512,320,137,4096,349,4540,372,4375,152,373,320,373,0,32,4176,4542,469,65,508,17,4605,372,4316,4328,256,476,4589,513]

theorem envBound34384 : H12AffineFastState.Bounded env34384 := by
  intro p hp
  have h : env34384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34383_34384 : H12AffineEnvironment.transform 10 137 env34383 = env34384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env34383 == env34384) = true)

theorem identity34384 : scanCanonicalize (H12AffineFastState.compose env34384 (packedSelected [1,2,3,4,5,6,8,9,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34384 : packedSelected [1,2,3,4,5,6,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34385 : List Nat := [2,4,8,16,32,64,128,116,512,52,137,4096,41,4296,0,4195,152,1,52,1,0,32,4176,4298,161,65,136,17,4233,0,4316,4328,116,168,4249,513]

theorem envBound34385 : H12AffineFastState.Bounded env34385 := by
  intro p hp
  have h : env34385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34384_34385 : H12AffineEnvironment.transform 7 116 env34384 = env34385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34384 == env34385) = true)

theorem identity34385 : scanCanonicalize (H12AffineFastState.compose env34385 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound34385 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34386 : List Nat := [2,4,8,16,32,64,73,116,512,52,64,4096,41,4097,0,4195,81,1,52,1,0,32,4176,4099,104,65,65,17,4160,0,4117,4129,116,97,4176,513]

theorem envBound34386 : H12AffineFastState.Bounded env34386 := by
  intro p hp
  have h : env34386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34385_34386 : H12AffineEnvironment.transform 6 73 env34385 = env34386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env34385 == env34386) = true)

theorem identity34386 : scanCanonicalize (H12AffineFastState.compose env34386 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34386 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34387 : List Nat := [2,4,8,16,32,64,73,116,17,52,64,4096,41,4097,0,4195,81,1,52,1,0,32,4176,4099,104,65,65,17,4160,0,4117,4129,116,97,4176,16]

theorem envBound34387 : H12AffineFastState.Bounded env34387 := by
  intro p hp
  have h : env34387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34386_34387 : H12AffineEnvironment.transform 8 17 env34386 = env34387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34386 == env34387) = true)

theorem identity34387 : scanCanonicalize (H12AffineFastState.compose env34387 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound34387 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34388 : List Nat := [2,4,8,16,32,64,73,116,17,52,64,80,41,81,0,51,81,1,52,1,0,32,0,83,104,65,65,17,16,0,69,113,116,97,0,16]

theorem envBound34388 : H12AffineFastState.Bounded env34388 := by
  intro p hp
  have h : env34388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34387_34388 : H12AffineEnvironment.transform 11 80 env34387 = env34388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env34387 == env34388) = true)

def env34389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound34389 : H12AffineFastState.Bounded env34389 := by
  intro p hp
  have h : env34389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34181_34389 : H12AffineEnvironment.transform 18 1025 env34181 = env34389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34181 == env34389) = true)

theorem identity34389 : scanCanonicalize (H12AffineFastState.compose env34389 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound34389 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575677,18973837,10507601,8538620,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound34390 : H12AffineFastState.Bounded env34390 := by
  intro p hp
  have h : env34390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34389_34390 : H12AffineEnvironment.transform 17 35324 env34389 = env34390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env34389 == env34390) = true)

def env34391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575541,18973701,10507601,8538484,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound34391 : H12AffineFastState.Bounded env34391 := by
  intro p hp
  have h : env34391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34390_34391 : H12AffineEnvironment.transform 6 8 env34390 = env34391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34390 == env34391) = true)

def env34392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,16777216,8192,65,21039477,18973701,2233681,2420,17024017,23160136,257,19104804,19096841,16966479]

theorem envBound34392 : H12AffineFastState.Bounded env34392 := by
  intro p hp
  have h : env34392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34391_34392 : H12AffineEnvironment.transform 22 147456 env34391 = env34392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env34391 == env34392) = true)

theorem identity34392 : scanCanonicalize (H12AffineFastState.compose env34392 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound34392 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,188750,8192,65,4450363,2319691,2233681,2420,75103,6521862,257,2188650,2196551,513]

theorem envBound34393 : H12AffineFastState.Bounded env34393 := by
  intro p hp
  have h : env34393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34392_34393 : H12AffineEnvironment.transform 23 188750 env34392 = env34393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env34392 == env34393) = true)

def env34394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302891,2172251,2118977,2420,75103,6407190,257,2188650,2196551,513]

theorem envBound34394 : H12AffineFastState.Bounded env34394 := by
  intro p hp
  have h : env34394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34393_34394 : H12AffineEnvironment.transform 16 16400 env34393 = env34394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34393 == env34394) = true)

theorem identity34394 : scanCanonicalize (H12AffineFastState.compose env34394 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34394 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2098513,2118977,2420,1365,6349852,257,2114912,2139213,513]

theorem envBound34395 : H12AffineFastState.Bounded env34395 := by
  intro p hp
  have h : env34395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34394_34395 : H12AffineEnvironment.transform 15 8202 env34394 = env34395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34394 == env34395) = true)

theorem identity34395 : scanCanonicalize (H12AffineFastState.compose env34395 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound34395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,2097152,32,16,41310,8192,65,34817,2098513,2118977,2420,1365,2155580,257,2114912,2139213,513]

theorem envBound34396 : H12AffineFastState.Bounded env34396 := by
  intro p hp
  have h : env34396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34395_34396 : H12AffineEnvironment.transform 21 32 env34395 = env34396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env34395 == env34396) = true)

theorem identity34396 : scanCanonicalize (H12AffineFastState.compose env34396 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34396 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1025,8540,2097152,32,16,3,8192,65,10588,2098513,2118977,2420,1365,2114913,257,2114912,2098448,513]

theorem envBound34397 : H12AffineFastState.Bounded env34397 := by
  intro p hp
  have h : env34397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34396_34397 : H12AffineEnvironment.transform 14 8541 env34396 = env34397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34396 == env34397) = true)

theorem identity34397 : scanCanonicalize (H12AffineFastState.compose env34397 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound34397 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1025,8540,25676,32,16,3,8192,65,10588,24861,12557,2420,1365,8493,257,8492,24924,513]

theorem envBound34398 : H12AffineFastState.Bounded env34398 := by
  intro p hp
  have h : env34398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34397_34398 : H12AffineEnvironment.transform 20 25676 env34397 = env34398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env34397 == env34398) = true)

theorem identity34398 : scanCanonicalize (H12AffineFastState.compose env34398 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound34398 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5392,10281,1025,8540,12620,32,16,3,8192,65,10588,13341,12557,2420,1365,8493,257,8492,13404,513]

theorem envBound34399 : H12AffineFastState.Bounded env34399 := by
  intro p hp
  have h : env34399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34398_34399 : H12AffineEnvironment.transform 13 5376 env34398 = env34399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34398 == env34399) = true)

theorem identity34399 : scanCanonicalize (H12AffineFastState.compose env34399 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34399 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,262,5392,2341,1025,80,4160,32,16,3,268,65,2128,5393,4097,2420,1365,33,257,32,5456,513]

theorem envBound34400 : H12AffineFastState.Bounded env34400 := by
  intro p hp
  have h : env34400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34399_34400 : H12AffineEnvironment.transform 12 268 env34399 = env34400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34399 == env34400) = true)

theorem identity34400 : scanCanonicalize (H12AffineFastState.compose env34400 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34400 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34401 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,268,4453,81,262,4469,2341,100,80,4160,32,16,3,268,65,2128,4468,4097,2420,304,33,257,32,4405,513]

theorem envBound34401 : H12AffineFastState.Bounded env34401 := by
  intro p hp
  have h : env34401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34400_34401 : H12AffineEnvironment.transform 9 101 env34400 = env34401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34400 == env34401) = true)

theorem identity34401 : scanCanonicalize (H12AffineFastState.compose env34401 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound34401 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34402 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,268,2421,81,262,2405,2341,100,80,2128,32,16,3,268,65,2128,2404,2065,2420,304,33,257,32,2341,513]

theorem envBound34402 : H12AffineFastState.Bounded env34402 := by
  intro p hp
  have h : env34402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34401_34402 : H12AffineEnvironment.transform 11 2064 env34401 = env34402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env34401 == env34402) = true)

theorem identity34402 : scanCanonicalize (H12AffineFastState.compose env34402 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34402 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34403 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,2341,1,262,2357,2341,52,0,2048,32,16,3,268,17,2048,2356,2065,2340,304,33,257,32,2341,513]

theorem envBound34403 : H12AffineFastState.Bounded env34403 := by
  intro p hp
  have h : env34403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34402_34403 : H12AffineEnvironment.transform 5 16 env34402 = env34403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34402 == env34403) = true)

theorem identity34403 : scanCanonicalize (H12AffineFastState.compose env34403 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34404 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,16,268,293,1,262,309,293,52,0,0,32,16,3,268,17,0,308,17,292,304,33,257,32,293,513]

theorem envBound34404 : H12AffineFastState.Bounded env34404 := by
  intro p hp
  have h : env34404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34403_34404 : H12AffineEnvironment.transform 10 0 env34403 = env34404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34403 == env34404) = true)

def env34405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41311,8192,65,4302890,2172250,2118976,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound34405 : H12AffineFastState.Bounded env34405 := by
  intro p hp
  have h : env34405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34393_34405 : H12AffineEnvironment.transform 16 16401 env34393 = env34405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34393 == env34405) = true)

theorem identity34405 : scanCanonicalize (H12AffineFastState.compose env34405 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound34405 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env34406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115735,4194304,17,41311,8192,65,4302890,57677,102743,2420,75103,4194304,257,41341,16464,513]

theorem envBound34406 : H12AffineFastState.Bounded env34406 := by
  intro p hp
  have h : env34406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34405_34406 : H12AffineEnvironment.transform 20 115735 env34405 = env34406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env34405 == env34406) = true)

def env34407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91199,4194304,17,375,8192,65,4261890,16741,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound34407 : H12AffineFastState.Bounded env34407 := by
  intro p hp
  have h : env34407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34406_34407 : H12AffineEnvironment.transform 14 8232 env34406 = env34407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env34406 == env34407) = true)

theorem identity34407 : scanCanonicalize (H12AffineFastState.compose env34407 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound34407 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env34408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91199,8572,17,375,8192,65,76158,16741,78207,2420,75103,8572,257,341,16464,513]

theorem envBound34408 : H12AffineFastState.Bounded env34408 := by
  intro p hp
  have h : env34408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34407_34408 : H12AffineEnvironment.transform 21 8572 env34407 = env34408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env34407 == env34408) = true)

theorem identity34408 : scanCanonicalize (H12AffineFastState.compose env34408 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound34408 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env34409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,342,16401,10588,1025,8233,25961,8572,17,375,8192,65,10280,16741,12329,2420,9225,8572,257,341,16464,513]

theorem envBound34409 : H12AffineFastState.Bounded env34409 := by
  intro p hp
  have h : env34409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34408_34409 : H12AffineEnvironment.transform 15 342 env34408 = env34409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env34408 == env34409) = true)

theorem identity34409 : scanCanonicalize (H12AffineFastState.compose env34409 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34409 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,0,342,16401,2420,1025,1,17729,340,17,375,40,65,2048,16741,4097,2420,1057,340,257,341,16464,513]

theorem envBound34410 : H12AffineFastState.Bounded env34410 := by
  intro p hp
  have h : env34410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34409_34410 : H12AffineEnvironment.transform 12 40 env34409 = env34410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34409 == env34410) = true)

theorem identity34410 : scanCanonicalize (H12AffineFastState.compose env34410 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34410 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34411 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,16384,0,262,16401,2340,1025,1,17681,260,17,295,40,17,2048,16693,4097,2340,1057,260,257,261,16384,513]

theorem envBound34411 : H12AffineFastState.Bounded env34411 := by
  intro p hp
  have h : env34411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34410_34411 : H12AffineEnvironment.transform 5 16 env34410 = env34411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34410 == env34411) = true)

theorem identity34411 : scanCanonicalize (H12AffineFastState.compose env34411 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound34411 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env34412 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5157,0,262,5172,2340,1025,1,4404,260,17,295,40,17,2048,5392,4097,2340,1057,260,257,261,5157,513]

theorem envBound34412 : H12AffineFastState.Bounded env34412 := by
  intro p hp
  have h : env34412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34411_34412 : H12AffineEnvironment.transform 13 5157 env34411 = env34412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env34411 == env34412) = true)

theorem identity34412 : scanCanonicalize (H12AffineFastState.compose env34412 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34412 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env34413 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,0,35,5172,2049,1025,1,4113,33,17,2,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound34413 : H12AffineFastState.Bounded env34413 := by
  intro p hp
  have h : env34413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34412_34413 : H12AffineEnvironment.transform 7 37 env34412 = env34413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34412 == env34413) = true)

def env34414 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,0,35,1028,2049,1025,1,33,33,17,2,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound34414 : H12AffineFastState.Bounded env34414 := by
  intro p hp
  have h : env34414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34413_34414 : H12AffineEnvironment.transform 11 48 env34413 = env34414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34413 == env34414) = true)

theorem identity34414 : scanCanonicalize (H12AffineFastState.compose env34414 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound34414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34415 : List Nat := [2,4,8,16,32,16,8,37,49,1024,2048,48,40,1045,0,35,1028,2049,1025,1,33,33,17,2,40,17,2048,1029,49,2049,1057,33,36,32,1045,48]

theorem envBound34415 : H12AffineFastState.Bounded env34415 := by
  intro p hp
  have h : env34415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34414_34415 : H12AffineEnvironment.transform 8 49 env34414 = env34415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34414 == env34415) = true)

def env34416 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,48,40,33,0,35,48,2049,53,1,33,33,17,2,40,17,2048,49,49,2049,21,33,36,32,33,48]

theorem envBound34416 : H12AffineFastState.Bounded env34416 := by
  intro p hp
  have h : env34416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34415_34416 : H12AffineEnvironment.transform 9 52 env34415 = env34416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34415 == env34416) = true)

def env34417 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,48,40,32,0,35,49,2049,52,1,33,33,17,2,40,17,2048,48,49,2049,20,33,36,32,32,48]

theorem envBound34417 : H12AffineFastState.Bounded env34417 := by
  intro p hp
  have h : env34417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34415_34417 : H12AffineEnvironment.transform 9 53 env34415 = env34417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34415 == env34417) = true)

theorem identity34417 : scanCanonicalize (H12AffineFastState.compose env34417 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34417 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34418 : List Nat := [2,4,8,10,32,10,8,37,43,47,2048,42,40,32,0,35,43,2049,46,1,33,33,11,2,40,11,2048,42,43,2049,14,33,36,32,32,42]

theorem envBound34418 : H12AffineFastState.Bounded env34418 := by
  intro p hp
  have h : env34418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34417_34418 : H12AffineEnvironment.transform 3 10 env34417 = env34418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34417 == env34418) = true)

def leafEnv34418 : List Nat := [2,4,8,10,32,10,8,37,43,47,2048,42,40,32,0,35,43,2049,46,1,33,33,11,2,15,40,1,11,2048,42,43,2049,14,33,36,32,5,35,32,42,1,33,0]

def active34418 : List Nat := [0,1,2,4,10]

def tree34418 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34418 : H12WitnessSearch.Good tree34418 := H12GlobalWitnessIndex.good

theorem leafIdentity34418 : H12AffineFastState.composeSystem env34418 rootObs = leafEnv34418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34418 rootObs == leafEnv34418) = true)

theorem terminalChecked34418 : H12PackedTerminal.terminalCheckFast leafEnv34418 active34418 tree34418 = true := by decide +kernel

def env34419 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,0,35,1029,2049,1025,1,32,33,17,2,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound34419 : H12AffineFastState.Bounded env34419 := by
  intro p hp
  have h : env34419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34413_34419 : H12AffineEnvironment.transform 11 49 env34413 = env34419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34413 == env34419) = true)

theorem identity34419 : scanCanonicalize (H12AffineFastState.compose env34419 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound34419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34420 : List Nat := [2,4,8,16,32,16,8,37,512,517,2048,49,40,529,0,35,512,2049,516,1,32,33,17,2,40,17,2048,513,48,2049,548,33,36,32,529,513]

theorem envBound34420 : H12AffineFastState.Bounded env34420 := by
  intro p hp
  have h : env34420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34419_34420 : H12AffineEnvironment.transform 9 517 env34419 = env34420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env34419 == env34420) = true)

def env34421 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,49,40,33,0,35,48,2049,52,1,32,33,17,2,40,17,2048,49,48,2049,20,33,36,32,33,49]

theorem envBound34421 : H12AffineFastState.Bounded env34421 := by
  intro p hp
  have h : env34421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34420_34421 : H12AffineEnvironment.transform 8 48 env34420 = env34421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34420 == env34421) = true)

theorem identity34421 : scanCanonicalize (H12AffineFastState.compose env34421 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34421 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34422 : List Nat := [2,4,8,10,32,10,8,37,42,47,2048,43,40,33,0,35,42,2049,46,1,32,33,11,2,40,11,2048,43,42,2049,14,33,36,32,33,43]

theorem envBound34422 : H12AffineFastState.Bounded env34422 := by
  intro p hp
  have h : env34422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34421_34422 : H12AffineEnvironment.transform 3 10 env34421 = env34422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34421 == env34422) = true)

def leafEnv34422 : List Nat := [2,4,8,10,32,10,8,37,42,47,2048,43,40,33,0,35,42,2049,46,1,32,33,11,2,15,40,1,11,2048,43,42,2049,14,33,36,32,5,35,33,43,1,32,0]

def active34422 : List Nat := [0,1,2,4,10]

def tree34422 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34422 : H12WitnessSearch.Good tree34422 := H12GlobalWitnessIndex.good

theorem leafIdentity34422 : H12AffineFastState.composeSystem env34422 rootObs = leafEnv34422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34422 rootObs == leafEnv34422) = true)

theorem terminalChecked34422 : H12PackedTerminal.terminalCheckFast leafEnv34422 active34422 tree34422 = true := by decide +kernel

def env34423 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,49,40,32,0,35,49,2049,53,1,32,33,17,2,40,17,2048,48,48,2049,21,33,36,32,32,48]

theorem envBound34423 : H12AffineFastState.Bounded env34423 := by
  intro p hp
  have h : env34423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34420_34423 : H12AffineEnvironment.transform 8 49 env34420 = env34423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34420 == env34423) = true)

def env34424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91198,4194304,17,374,8192,65,4261891,16740,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound34424 : H12AffineFastState.Bounded env34424 := by
  intro p hp
  have h : env34424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34406_34424 : H12AffineEnvironment.transform 14 8233 env34406 = env34424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env34406 == env34424) = true)

theorem identity34424 : scanCanonicalize (H12AffineFastState.compose env34424 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound34424 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env34425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91198,8200,17,374,8192,65,75787,16740,78206,2420,75103,8200,257,340,16464,513]

theorem envBound34425 : H12AffineFastState.Bounded env34425 := by
  intro p hp
  have h : env34425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34424_34425 : H12AffineEnvironment.transform 21 8200 env34424 = env34425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env34424 == env34425) = true)

theorem identity34425 : scanCanonicalize (H12AffineFastState.compose env34425 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34425 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env34426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16401,10589,1025,8232,25628,8200,17,374,8192,65,10281,16740,12636,2420,9597,8200,257,340,16464,513]

theorem envBound34426 : H12AffineFastState.Bounded env34426 := by
  intro p hp
  have h : env34426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34425_34426 : H12AffineEnvironment.transform 15 34 env34425 = env34426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34425 == env34426) = true)

theorem identity34426 : scanCanonicalize (H12AffineFastState.compose env34426 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34426 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,0,34,16401,2420,1025,1,17461,33,17,374,41,65,2048,16740,4469,2420,1364,33,257,340,16464,513]

theorem envBound34427 : H12AffineFastState.Bounded env34427 := by
  intro p hp
  have h : env34427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34426_34427 : H12AffineEnvironment.transform 12 41 env34426 = env34427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34426 == env34427) = true)

theorem identity34427 : scanCanonicalize (H12AffineFastState.compose env34427 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34427 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,0,34,5392,2420,1025,1,4404,33,17,374,41,65,2048,5221,4469,2420,1364,33,257,340,5457,513]

theorem envBound34428 : H12AffineFastState.Bounded env34428 := by
  intro p hp
  have h : env34428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34427_34428 : H12AffineEnvironment.transform 13 5377 env34427 = env34428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34427 == env34428) = true)

theorem identity34428 : scanCanonicalize (H12AffineFastState.compose env34428 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34428 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34429 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5157,0,34,5172,2128,1025,1,4112,33,17,82,41,65,2048,5221,4177,2128,1136,33,37,112,5237,513]

theorem envBound34429 : H12AffineFastState.Bounded env34429 := by
  intro p hp
  have h : env34429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34428_34429 : H12AffineEnvironment.transform 7 36 env34428 = env34429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34428 == env34429) = true)

theorem identity34429 : scanCanonicalize (H12AffineFastState.compose env34429 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34429 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34430 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,0,34,5172,2048,1025,1,4112,33,17,2,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound34430 : H12AffineFastState.Bounded env34430 := by
  intro p hp
  have h : env34430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34429_34430 : H12AffineEnvironment.transform 5 16 env34429 = env34430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34429 == env34430) = true)

def env34431 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,0,34,1028,2048,1025,1,32,33,17,2,41,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound34431 : H12AffineFastState.Bounded env34431 := by
  intro p hp
  have h : env34431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34430_34431 : H12AffineEnvironment.transform 11 48 env34430 = env34431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34430 == env34431) = true)

theorem identity34431 : scanCanonicalize (H12AffineFastState.compose env34431 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound34431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34432 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1045,48,41,1045,0,34,1028,1045,1025,1,32,33,17,2,41,17,1045,1029,49,1045,1056,33,37,32,1045,513]

theorem envBound34432 : H12AffineFastState.Bounded env34432 := by
  intro p hp
  have h : env34432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34431_34432 : H12AffineEnvironment.transform 10 1045 env34431 = env34432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env34431 == env34432) = true)

def env34433 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,48,41,33,0,34,48,33,53,1,32,33,17,2,41,17,33,49,49,33,20,33,37,32,33,513]

theorem envBound34433 : H12AffineFastState.Bounded env34433 := by
  intro p hp
  have h : env34433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34432_34433 : H12AffineEnvironment.transform 9 52 env34432 = env34433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34432 == env34433) = true)

def env34434 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,41,32,0,34,49,32,52,1,32,33,17,2,41,17,32,48,49,32,21,33,37,32,32,513]

theorem envBound34434 : H12AffineFastState.Bounded env34434 := by
  intro p hp
  have h : env34434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34432_34434 : H12AffineEnvironment.transform 9 53 env34432 = env34434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34432 == env34434) = true)

theorem identity34434 : scanCanonicalize (H12AffineFastState.compose env34434 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34435 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,48,41,32,0,34,49,32,52,1,32,33,17,2,41,17,32,48,49,32,21,33,37,32,32,43]

theorem envBound34435 : H12AffineFastState.Bounded env34435 := by
  intro p hp
  have h : env34435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34434_34435 : H12AffineEnvironment.transform 8 42 env34434 = env34435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34434 == env34435) = true)

def leafEnv34435 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,48,41,32,0,34,49,32,52,1,32,33,17,2,20,41,1,17,32,48,49,32,21,33,37,32,5,34,32,43,1,32,0]

def active34435 : List Nat := [0,1,2,3,4]

def tree34435 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34435 : H12WitnessSearch.Good tree34435 := H12GlobalWitnessIndex.good

theorem leafIdentity34435 : H12AffineFastState.composeSystem env34435 rootObs = leafEnv34435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34435 rootObs == leafEnv34435) = true)

theorem terminalChecked34435 : H12PackedTerminal.terminalCheckFast leafEnv34435 active34435 tree34435 = true := by decide +kernel

def env34436 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,0,34,1029,2048,1025,1,33,33,17,2,41,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound34436 : H12AffineFastState.Bounded env34436 := by
  intro p hp
  have h : env34436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34430_34436 : H12AffineEnvironment.transform 11 49 env34430 = env34436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34430 == env34436) = true)

theorem identity34436 : scanCanonicalize (H12AffineFastState.compose env34436 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34437 : List Nat := [2,4,8,16,32,16,8,36,512,1024,33,49,41,1044,0,34,1029,33,1025,1,33,33,17,2,41,17,33,1028,48,33,1056,33,37,32,1044,513]

theorem envBound34437 : H12AffineFastState.Bounded env34437 := by
  intro p hp
  have h : env34437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34436_34437 : H12AffineEnvironment.transform 10 33 env34436 = env34437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34436 == env34437) = true)

def env34438 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,49,41,32,0,34,49,33,53,1,33,33,17,2,41,17,33,48,48,33,20,33,37,32,32,513]

theorem envBound34438 : H12AffineFastState.Bounded env34438 := by
  intro p hp
  have h : env34438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34437_34438 : H12AffineEnvironment.transform 9 52 env34437 = env34438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34437 == env34438) = true)

def env34439 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,49,41,33,0,34,48,33,52,1,33,33,17,2,41,17,33,49,48,33,21,33,37,32,33,513]

theorem envBound34439 : H12AffineFastState.Bounded env34439 := by
  intro p hp
  have h : env34439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34437_34439 : H12AffineEnvironment.transform 9 53 env34437 = env34439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34437 == env34439) = true)

theorem identity34439 : scanCanonicalize (H12AffineFastState.compose env34439 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34440 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,49,41,33,0,34,48,33,52,1,33,33,17,2,41,17,33,49,48,33,21,33,37,32,33,42]

theorem envBound34440 : H12AffineFastState.Bounded env34440 := by
  intro p hp
  have h : env34440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34439_34440 : H12AffineEnvironment.transform 8 43 env34439 = env34440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34439 == env34440) = true)

def leafEnv34440 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,49,41,33,0,34,48,33,52,1,33,33,17,2,20,41,1,17,33,49,48,33,21,33,37,32,5,34,33,42,1,33,0]

def active34440 : List Nat := [0,1,2,3,4]

def tree34440 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34440 : H12WitnessSearch.Good tree34440 := H12GlobalWitnessIndex.good

theorem leafIdentity34440 : H12AffineFastState.composeSystem env34440 rootObs = leafEnv34440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34440 rootObs == leafEnv34440) = true)

theorem terminalChecked34440 : H12PackedTerminal.terminalCheckFast leafEnv34440 active34440 tree34440 = true := by decide +kernel

def env34441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,16777216,8192,65,21039476,18973701,2233680,2421,17024016,23160136,257,19104805,19096840,16966478]

theorem envBound34441 : H12AffineFastState.Bounded env34441 := by
  intro p hp
  have h : env34441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34391_34441 : H12AffineEnvironment.transform 22 147457 env34391 = env34441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env34391 == env34441) = true)

def env34442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,16777216,8192,65,21039476,18973701,2118976,2421,16876544,23160136,257,18990133,18949400,16819038]

theorem envBound34442 : H12AffineFastState.Bounded env34442 := by
  intro p hp
  have h : env34442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34442 : H12AffineEnvironment.transform 16 16400 env34441 = env34442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34441 == env34442) = true)

def env34443 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,16777216,8192,65,21039104,18973701,2118708,2049,16876544,23159868,117,18990133,18949228,16818730]

theorem envBound34443 : H12AffineFastState.Bounded env34443 := by
  intro p hp
  have h : env34443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34442_34443 : H12AffineEnvironment.transform 7 116 env34442 = env34443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34442 == env34443) = true)

theorem identity34443 : scanCanonicalize (H12AffineFastState.compose env34443 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound34443 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env34444 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,65,21039104,16834619,77834,2049,16876544,20971522,117,16818187,16793682,16818730]

theorem envBound34444 : H12AffineFastState.Bounded env34444 := by
  intro p hp
  have h : env34444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34443_34444 : H12AffineEnvironment.transform 20 91198 env34443 = env34444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env34443 == env34444) = true)

def env34445 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,17,21039104,16834619,77834,2049,16876544,20971522,37,16818187,16793602,16818730]

theorem envBound34445 : H12AffineFastState.Bounded env34445 := by
  intro p hp
  have h : env34445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34444_34445 : H12AffineEnvironment.transform 5 16 env34444 = env34445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34444 == env34445) = true)

theorem identity34445 : scanCanonicalize (H12AffineFastState.compose env34445 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292608) := by decide +kernel

theorem selectedBound34445 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34446 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,4292608,8192,17,34816,4284475,77834,2049,4195328,98306,37,4268043,4308994,4268586]

theorem envBound34446 : H12AffineFastState.Bounded env34446 := by
  intro p hp
  have h : env34446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34445_34446 : H12AffineEnvironment.transform 23 4292608 env34445 = env34446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292608 env34445 == env34446) = true)

theorem identity34446 : scanCanonicalize (H12AffineFastState.compose env34446 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound34446 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34447 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1025,8232,91198,4194304,17,4268073,8192,17,10281,4284475,77834,2049,4195328,73771,37,4268043,4284459,4268586]

theorem envBound34447 : H12AffineFastState.Bounded env34447 := by
  intro p hp
  have h : env34447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34446_34447 : H12AffineEnvironment.transform 14 8233 env34446 = env34447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env34446 == env34447) = true)

theorem identity34447 : scanCanonicalize (H12AffineFastState.compose env34447 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(21+1) ^^^ 87047) := by decide +kernel

theorem selectedBound34447 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env34448 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1025,8232,91198,87047,17,29742,8192,17,10281,13372,77834,2049,86023,73771,37,29708,13356,30253]

theorem envBound34448 : H12AffineFastState.Bounded env34448 := by
  intro p hp
  have h : env34448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34447_34448 : H12AffineEnvironment.transform 21 87047 env34447 = env34448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87047 env34447 == env34448) = true)

theorem identity34448 : scanCanonicalize (H12AffineFastState.compose env34448 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound34448 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34449 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5125,8233,65536,5141,10281,1025,8232,77883,65538,17,8235,8192,17,10281,13372,77834,2049,66562,73771,37,8201,13356,8744]

theorem envBound34449 : H12AffineFastState.Bounded env34449 := by
  intro p hp
  have h : env34449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34448_34449 : H12AffineEnvironment.transform 13 5125 env34448 = env34449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env34448 == env34449) = true)

theorem identity34449 : scanCanonicalize (H12AffineFastState.compose env34449 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34449 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34450 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5125,8233,8203,5141,10281,1025,8232,4144,8201,17,8235,8192,17,10281,13372,4097,2049,9225,32,37,8201,13356,8744]

theorem envBound34450 : H12AffineFastState.Bounded env34450 := by
  intro p hp
  have h : env34450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34449_34450 : H12AffineEnvironment.transform 15 8203 env34449 = env34450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34449 == env34450) = true)

theorem identity34450 : scanCanonicalize (H12AffineFastState.compose env34450 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound34450 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env34451 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,5125,1077,1047,5141,3125,1025,1076,4144,1045,17,1079,1052,17,3125,4128,4097,2049,21,32,37,1045,4144,1588]

theorem envBound34451 : H12AffineFastState.Bounded env34451 := by
  intro p hp
  have h : env34451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34450_34451 : H12AffineEnvironment.transform 12 1052 env34450 = env34451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env34450 == env34451) = true)

theorem identity34451 : scanCanonicalize (H12AffineFastState.compose env34451 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound34451 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env34452 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,4096,1052,5125,1077,1047,5141,1,1025,1076,4144,1045,17,1079,1052,17,1,4128,4097,1077,21,32,37,1045,4144,1588]

theorem envBound34452 : H12AffineFastState.Bounded env34452 := by
  intro p hp
  have h : env34452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34451_34452 : H12AffineEnvironment.transform 10 1076 env34451 = env34452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env34451 == env34452) = true)

theorem identity34452 : scanCanonicalize (H12AffineFastState.compose env34452 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound34452 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env34453 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,1052,1076,1077,1047,1060,1,1025,1076,1,1045,17,1079,1052,17,1,17,48,1077,21,32,37,1045,1,1588]

theorem envBound34453 : H12AffineFastState.Bounded env34453 := by
  intro p hp
  have h : env34453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34452_34453 : H12AffineEnvironment.transform 11 49 env34452 = env34453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34452 == env34453) = true)

def env34454 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,16,21039104,16834619,77834,2049,16876544,20971522,36,16818187,16793603,16818730]

theorem envBound34454 : H12AffineFastState.Bounded env34454 := by
  intro p hp
  have h : env34454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34444_34454 : H12AffineEnvironment.transform 5 17 env34444 = env34454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34444 == env34454) = true)

theorem identity34454 : scanCanonicalize (H12AffineFastState.compose env34454 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235274) := by decide +kernel

theorem selectedBound34454 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34455 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,4235274,8192,16,108554,4210737,77834,2049,4269066,40968,36,4194305,4251657,4194848]

theorem envBound34455 : H12AffineFastState.Bounded env34455 := by
  intro p hp
  have h : env34455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34454_34455 : H12AffineEnvironment.transform 23 4235274 env34454 = env34455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235274 env34454 == env34455) = true)

theorem identity34455 : scanCanonicalize (H12AffineFastState.compose env34455 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound34455 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env34456 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,8201,17,32771,8192,16,108554,24632,77834,2049,66563,40968,36,8200,49152,8745]

theorem envBound34456 : H12AffineFastState.Bounded env34456 := by
  intro p hp
  have h : env34456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34455_34456 : H12AffineEnvironment.transform 21 8201 env34455 = env34456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env34455 == env34456) = true)

theorem identity34456 : scanCanonicalize (H12AffineFastState.compose env34456 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34456 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env34457 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,34,16400,34816,1025,32769,25628,8201,17,32771,8192,16,43048,24632,12328,2049,1057,40968,36,8200,49152,8745]

theorem envBound34457 : H12AffineFastState.Bounded env34457 := by
  intro p hp
  have h : env34457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34456_34457 : H12AffineEnvironment.transform 15 34 env34456 = env34457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34456 == env34457) = true)

theorem identity34457 : scanCanonicalize (H12AffineFastState.compose env34457 (packedSelected [0,2,3,5,6,7,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34457 : packedSelected [0,2,3,5,6,7,14,19] rootPS < 2^1333 := by decide +kernel

def env34458 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,1,34,16400,2049,1025,0,25628,8201,17,2,8192,16,10281,24632,12328,2049,1057,8201,36,8200,16385,8745]

theorem envBound34458 : H12AffineFastState.Bounded env34458 := by
  intro p hp
  have h : env34458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34457_34458 : H12AffineEnvironment.transform 14 1 env34457 = env34458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34457 == env34458) = true)

theorem identity34458 : scanCanonicalize (H12AffineFastState.compose env34458 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound34458 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34459 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5124,1,34,5140,2049,1025,0,12312,8201,17,2,8192,16,10281,13372,12328,2049,1057,8201,36,8200,5125,8745]

theorem envBound34459 : H12AffineFastState.Bounded env34459 := by
  intro p hp
  have h : env34459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34458_34459 : H12AffineEnvironment.transform 13 5124 env34458 = env34459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env34458 == env34459) = true)

theorem identity34459 : scanCanonicalize (H12AffineFastState.compose env34459 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34459 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34460 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5124,1,34,5140,2049,1025,0,4145,32,17,2,41,16,2048,5141,4097,2049,1057,32,36,33,5125,512]

theorem envBound34460 : H12AffineFastState.Bounded env34460 := by
  intro p hp
  have h : env34460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34459_34460 : H12AffineEnvironment.transform 12 41 env34459 = env34460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34459 == env34460) = true)

theorem identity34460 : scanCanonicalize (H12AffineFastState.compose env34460 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound34460 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34461 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3076,41,2048,1,34,2064,2049,1025,0,3125,32,17,2,41,16,2048,2065,3077,2049,1057,32,36,33,2049,512]

theorem envBound34461 : H12AffineFastState.Bounded env34461 := by
  intro p hp
  have h : env34461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34460_34461 : H12AffineEnvironment.transform 11 3076 env34460 = env34461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env34460 == env34461) = true)

theorem identity34461 : scanCanonicalize (H12AffineFastState.compose env34461 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34461 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34462 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3076,8,2048,1,3,2064,2049,1025,0,3092,1,17,2,8,16,2048,2065,3077,2049,1024,1,5,0,2049,512]

theorem envBound34462 : H12AffineFastState.Bounded env34462 := by
  intro p hp
  have h : env34462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34461_34462 : H12AffineEnvironment.transform 4 1 env34461 = env34462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34461 == env34462) = true)

theorem identity34462 : scanCanonicalize (H12AffineFastState.compose env34462 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34462 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34463 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2048,1,3,2064,2049,21,0,2048,1,17,2,8,16,2048,2065,2065,2049,20,1,5,0,2049,512]

theorem envBound34463 : H12AffineFastState.Bounded env34463 := by
  intro p hp
  have h : env34463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34462_34463 : H12AffineEnvironment.transform 9 20 env34462 = env34463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34462 == env34463) = true)

theorem identity34463 : scanCanonicalize (H12AffineFastState.compose env34463 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34464 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,2064,8,2048,1,3,2064,2049,21,0,2048,1,17,2,8,16,2048,2065,2065,2049,20,1,5,0,2049,0]

theorem envBound34464 : H12AffineFastState.Bounded env34464 := by
  intro p hp
  have h : env34464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34463_34464 : H12AffineEnvironment.transform 8 0 env34463 = env34464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34463 == env34464) = true)

theorem identity34464 : scanCanonicalize (H12AffineFastState.compose env34464 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound34464 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34465 : List Nat := [2,4,8,5,1,4,8,4,0,1,2048,2053,8,2048,1,3,2053,2049,0,0,2048,1,4,2,8,5,2048,2052,2052,2049,1,1,5,0,2049,0]

theorem envBound34465 : H12AffineFastState.Bounded env34465 := by
  intro p hp
  have h : env34465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34464_34465 : H12AffineEnvironment.transform 3 5 env34464 = env34465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34464 == env34465) = true)

def leafEnv34465 : List Nat := [2,4,8,5,1,4,8,4,0,1,2048,2053,8,2048,1,3,2053,2049,0,0,2048,1,4,2,0,8,1,5,2048,2052,2052,2049,1,1,5,0,5,3,2049,0,1,2049,0]

def active34465 : List Nat := [0,1,2,10]

def tree34465 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34465 : H12WitnessSearch.Good tree34465 := H12GlobalWitnessIndex.good

theorem leafIdentity34465 : H12AffineFastState.composeSystem env34465 rootObs = leafEnv34465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34465 rootObs == leafEnv34465) = true)

theorem terminalChecked34465 : H12PackedTerminal.terminalCheckFast leafEnv34465 active34465 tree34465 = true := by decide +kernel

def env34466 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,16777216,8192,65,21039105,18973701,2118709,2048,16876544,23159869,116,18990133,18949229,16818731]

theorem envBound34466 : H12AffineFastState.Bounded env34466 := by
  intro p hp
  have h : env34466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34442_34466 : H12AffineEnvironment.transform 7 117 env34442 = env34466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34442 == env34466) = true)

theorem identity34466 : scanCanonicalize (H12AffineFastState.compose env34466 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound34466 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env34467 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212885,8192,65,6343700,16400,2118709,2048,2113557,4235304,116,32,57464,2188862]

theorem envBound34467 : H12AffineFastState.Bounded env34467 := by
  intro p hp
  have h : env34467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34466_34467 : H12AffineEnvironment.transform 23 2212885 env34466 = env34467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env34466 == env34467) = true)

def env34468 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212885,8192,17,6343700,16400,2118709,2048,2113557,4235304,36,32,57384,2188862]

theorem envBound34468 : H12AffineFastState.Bounded env34468 := by
  intro p hp
  have h : env34468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34467_34468 : H12AffineEnvironment.transform 5 16 env34467 = env34468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34467 == env34468) = true)

theorem identity34468 : scanCanonicalize (H12AffineFastState.compose env34468 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound34468 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env34469 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,73770,17,2212885,8192,17,2223166,16400,2118709,2048,2113557,98306,36,32,57384,2188862]

theorem envBound34469 : H12AffineFastState.Bounded env34469 := by
  intro p hp
  have h : env34469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34468_34469 : H12AffineEnvironment.transform 21 73770 env34468 = env34469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env34468 == env34469) = true)

theorem identity34469 : scanCanonicalize (H12AffineFastState.compose env34469 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound34469 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34470 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1025,8233,2097152,73770,17,2188349,8192,17,2182166,16400,2118709,2048,2113557,73770,36,32,16384,2188862]

theorem envBound34470 : H12AffineFastState.Bounded env34470 := by
  intro p hp
  have h : env34470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34469_34470 : H12AffineEnvironment.transform 14 8232 env34469 = env34470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env34469 == env34470) = true)

theorem identity34470 : scanCanonicalize (H12AffineFastState.compose env34470 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34470 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env34471 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,34,16400,10281,1025,8233,2097152,8200,17,2122783,8192,17,2116660,16400,2118709,2048,2113557,8200,36,32,16384,2123292]

theorem envBound34471 : H12AffineFastState.Bounded env34471 := by
  intro p hp
  have h : env34471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34470_34471 : H12AffineEnvironment.transform 15 34 env34470 = env34471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34470 == env34471) = true)

theorem identity34471 : scanCanonicalize (H12AffineFastState.compose env34471 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound34471 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34472 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,34,16400,10281,1025,8233,17460,8200,17,8235,8192,17,2048,16400,4097,2048,1057,8200,36,32,16384,8744]

theorem envBound34472 : H12AffineFastState.Bounded env34472 := by
  intro p hp
  have h : env34472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34471_34472 : H12AffineEnvironment.transform 20 17460 env34471 = env34472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env34471 == env34472) = true)

theorem identity34472 : scanCanonicalize (H12AffineFastState.compose env34472 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound34472 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env34473 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1029,8192,16384,8232,34,16400,10281,1025,8233,17460,8200,17,8235,8192,17,2048,16400,1028,2048,1057,8200,36,32,16384,8744]

theorem envBound34473 : H12AffineFastState.Bounded env34473 := by
  intro p hp
  have h : env34473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34472_34473 : H12AffineEnvironment.transform 11 1029 env34472 = env34473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env34472 == env34473) = true)

theorem identity34473 : scanCanonicalize (H12AffineFastState.compose env34473 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 32) := by decide +kernel

theorem selectedBound34473 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34474 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1029,8192,32,8232,34,48,10281,1025,8233,1044,8200,17,8235,8192,17,2048,48,1028,2048,1057,8200,36,32,32,8744]

theorem envBound34474 : H12AffineFastState.Bounded env34474 := by
  intro p hp
  have h : env34474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34473_34474 : H12AffineEnvironment.transform 13 32 env34473 = env34474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 32 env34473 == env34474) = true)

theorem identity34474 : scanCanonicalize (H12AffineFastState.compose env34474 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34474 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34475 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,1029,8192,32,8232,34,48,8200,1025,8233,1044,8200,17,8235,8192,17,33,48,1028,33,1057,8200,36,32,32,8744]

theorem envBound34475 : H12AffineFastState.Bounded env34475 := by
  intro p hp
  have h : env34475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34474_34475 : H12AffineEnvironment.transform 10 33 env34474 = env34475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34474 == env34475) = true)

def env34476 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212885,8192,16,6343700,16400,2118709,2048,2113557,4235304,37,32,57385,2188862]

theorem envBound34476 : H12AffineFastState.Bounded env34476 := by
  intro p hp
  have h : env34476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34467_34476 : H12AffineEnvironment.transform 5 17 env34467 = env34476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34467 == env34476) = true)

theorem identity34476 : scanCanonicalize (H12AffineFastState.compose env34476 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34476 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env34477 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,1,65536,16400,2048,1025,0,2097152,4194304,17,2180116,8192,16,6310933,16400,2118709,2048,2113557,4202537,37,32,24616,2188862]

theorem envBound34477 : H12AffineFastState.Bounded env34477 := by
  intro p hp
  have h : env34477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34476_34477 : H12AffineEnvironment.transform 14 1 env34476 = env34477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34476 == env34477) = true)

theorem identity34477 : scanCanonicalize (H12AffineFastState.compose env34477 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122813) := by decide +kernel

theorem selectedBound34477 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env34478 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,1,65536,16400,2048,1025,0,2097152,2122813,17,2180116,8192,16,10280,16400,2118709,2048,2113557,2114580,37,32,24616,2188862]

theorem envBound34478 : H12AffineFastState.Bounded env34478 := by
  intro p hp
  have h : env34478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34477_34478 : H12AffineEnvironment.transform 21 2122813 env34477 = env34478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122813 env34477 == env34478) = true)

theorem identity34478 : scanCanonicalize (H12AffineFastState.compose env34478 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 29711) := by decide +kernel

theorem selectedBound34478 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env34479 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,1,29711,16400,2048,1025,0,2097152,2122813,17,2109467,8192,16,10280,16400,2118709,2048,2113557,2114580,37,32,24616,2101809]

theorem envBound34479 : H12AffineFastState.Bounded env34479 := by
  intro p hp
  have h : env34479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34478_34479 : H12AffineEnvironment.transform 15 29711 env34478 = env34479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29711 env34478 == env34479) = true)

theorem identity34479 : scanCanonicalize (H12AffineFastState.compose env34479 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12312) := by decide +kernel

theorem selectedBound34479 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env34480 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,1,29711,16400,2048,1025,0,12312,21541,17,3,8192,16,10280,16400,25645,2048,28685,29708,37,32,24616,8745]

theorem envBound34480 : H12AffineFastState.Bounded env34480 := by
  intro p hp
  have h : env34480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34479_34480 : H12AffineEnvironment.transform 20 12312 env34479 = env34480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12312 env34479 == env34480) = true)

theorem identity34480 : scanCanonicalize (H12AffineFastState.compose env34480 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound34480 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34481 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,2081,1,15406,2097,2048,1025,0,12312,7172,17,3,8192,16,10280,2097,11276,2048,14380,15405,37,32,10249,8745]

theorem envBound34481 : H12AffineFastState.Bounded env34481 := by
  intro p hp
  have h : env34481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34480_34481 : H12AffineEnvironment.transform 13 2081 env34480 = env34481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env34480 == env34481) = true)

theorem identity34481 : scanCanonicalize (H12AffineFastState.compose env34481 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound34481 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env34482 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,5133,2081,1,2083,2097,2048,1025,0,1045,7172,17,3,5133,16,7205,2097,6145,2048,3105,2080,37,32,7172,5668]

theorem envBound34482 : H12AffineFastState.Bounded env34482 := by
  intro p hp
  have h : env34482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34481_34482 : H12AffineEnvironment.transform 12 5133 env34481 = env34482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env34481 == env34482) = true)

theorem identity34482 : scanCanonicalize (H12AffineFastState.compose env34482 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound34482 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env34483 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,4096,5133,1045,1,1047,1029,1076,1025,0,1045,4144,17,3,5133,16,4113,1029,5173,1076,21,1044,37,32,4144,5668]

theorem envBound34483 : H12AffineFastState.Bounded env34483 := by
  intro p hp
  have h : env34483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34482_34483 : H12AffineEnvironment.transform 10 1076 env34482 = env34483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env34482 == env34483) = true)

theorem identity34483 : scanCanonicalize (H12AffineFastState.compose env34483 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34483 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34484 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,4096,4152,32,1,34,48,1,52,0,32,4144,17,3,4152,16,4113,48,4096,1,21,33,37,32,4144,4625]

theorem envBound34484 : H12AffineFastState.Bounded env34484 := by
  intro p hp
  have h : env34484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34483_34484 : H12AffineEnvironment.transform 9 53 env34483 = env34484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34483 == env34484) = true)

def env34485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973701,2118977,2421,16876545,23160136,257,18990132,18949401,16819039]

theorem envBound34485 : H12AffineFastState.Bounded env34485 := by
  intro p hp
  have h : env34485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34485 : H12AffineEnvironment.transform 16 16401 env34441 = env34485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34441 == env34485) = true)

theorem identity34485 : scanCanonicalize (H12AffineFastState.compose env34485 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34485 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env34486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,2097152,4194304,16,16777216,8192,65,21039476,18949464,2118977,2421,16852316,23160136,257,18965865,18949401,16777730]

theorem envBound34486 : H12AffineFastState.Bounded env34486 := by
  intro p hp
  have h : env34486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34485_34486 : H12AffineEnvironment.transform 14 8541 env34485 = env34486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34485 == env34486) = true)

theorem identity34486 : scanCanonicalize (H12AffineFastState.compose env34486 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 65876) := by decide +kernel

theorem selectedBound34486 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env34487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,2097152,4194304,16,65876,8192,65,4196384,2106380,2118977,2421,9224,6317084,257,2122813,2106445,66390]

theorem envBound34487 : H12AffineFastState.Bounded env34487 := by
  intro p hp
  have h : env34487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34486_34487 : H12AffineEnvironment.transform 23 65876 env34486 = env34487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65876 env34486 == env34487) = true)

theorem identity34487 : scanCanonicalize (H12AffineFastState.compose env34487 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound34487 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,16,18,19,20,28] rootPS < 2^1333 := by decide +kernel

def env34488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17680,4194304,16,65876,8192,65,4196384,24860,4177,2421,9224,4202764,257,8493,24925,66390]

theorem envBound34488 : H12AffineFastState.Bounded env34488 := by
  intro p hp
  have h : env34488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34487_34488 : H12AffineEnvironment.transform 20 17680 env34487 = env34488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env34487 == env34488) = true)

theorem identity34488 : scanCanonicalize (H12AffineFastState.compose env34488 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound34488 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env34489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17680,8572,16,65876,8192,65,10588,24860,4177,2421,9224,112,257,8493,24925,66390]

theorem envBound34489 : H12AffineFastState.Bounded env34489 := by
  intro p hp
  have h : env34489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34488_34489 : H12AffineEnvironment.transform 21 8572 env34488 = env34489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env34488 == env34489) = true)

theorem identity34489 : scanCanonicalize (H12AffineFastState.compose env34489 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound34489 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env34490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,65536,16401,2421,1025,0,17680,32,16,65876,348,65,2048,16448,4177,2421,1364,112,257,113,16385,66390]

theorem envBound34490 : H12AffineFastState.Bounded env34490 := by
  intro p hp
  have h : env34490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34489_34490 : H12AffineEnvironment.transform 12 348 env34489 = env34490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env34489 == env34490) = true)

theorem identity34490 : scanCanonicalize (H12AffineFastState.compose env34490 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound34490 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2144,348,16384,1,65536,16401,2421,1025,0,17680,32,16,65876,348,65,2048,16448,2097,2421,1364,112,257,113,16385,66390]

theorem envBound34491 : H12AffineFastState.Bounded env34491 := by
  intro p hp
  have h : env34491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34490_34491 : H12AffineEnvironment.transform 11 2144 env34490 = env34491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env34490 == env34491) = true)

theorem identity34491 : scanCanonicalize (H12AffineFastState.compose env34491 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound34491 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34492 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,2064,300,16384,1,65536,16401,2309,1025,0,17680,32,16,65828,300,49,2048,16432,2097,2309,1316,0,257,1,16385,66342]

theorem envBound34492 : H12AffineFastState.Bounded env34492 := by
  intro p hp
  have h : env34492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34491_34492 : H12AffineEnvironment.transform 5 48 env34491 = env34492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env34491 == env34492) = true)

theorem identity34492 : scanCanonicalize (H12AffineFastState.compose env34492 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34492 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34493 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,2064,268,16384,1,65536,16401,2309,1025,0,17680,0,16,65796,268,17,2048,16400,2065,2309,1284,0,257,1,16385,66310]

theorem envBound34493 : H12AffineFastState.Bounded env34493 := by
  intro p hp
  have h : env34493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34492_34493 : H12AffineEnvironment.transform 4 0 env34492 = env34493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34492 == env34493) = true)

theorem identity34493 : scanCanonicalize (H12AffineFastState.compose env34493 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(13+1) ^^^ 1044) := by decide +kernel

theorem selectedBound34493 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env34494 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,2064,268,1044,1,65536,1029,2309,1025,0,260,0,16,65796,268,17,2048,1028,2065,2309,1284,0,257,1,1045,66310]

theorem envBound34494 : H12AffineFastState.Bounded env34494 := by
  intro p hp
  have h : env34494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34493_34494 : H12AffineEnvironment.transform 13 1044 env34493 = env34494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1044 env34493 == env34494) = true)

theorem identity34494 : scanCanonicalize (H12AffineFastState.compose env34494 (packedSelected [0,2,3,4,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34494 : packedSelected [0,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env34495 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2064,268,0,1,65536,17,2309,21,0,260,0,16,65796,268,17,2048,16,2065,2309,272,0,257,1,1,66310]

theorem envBound34495 : H12AffineFastState.Bounded env34495 := by
  intro p hp
  have h : env34495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34494_34495 : H12AffineEnvironment.transform 9 20 env34494 = env34495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34494 == env34495) = true)

theorem identity34495 : scanCanonicalize (H12AffineFastState.compose env34495 (packedSelected [1,2,8] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34495 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env34496 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,2064,268,0,1,262,17,2309,21,0,260,0,16,2,268,17,2048,16,2065,2309,272,0,257,1,1,512]

theorem envBound34496 : H12AffineFastState.Bounded env34496 := by
  intro p hp
  have h : env34496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34495_34496 : H12AffineEnvironment.transform 15 262 env34495 = env34496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34495 == env34496) = true)

theorem identity34496 : scanCanonicalize (H12AffineFastState.compose env34496 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34496 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34497 : List Nat := [2,4,8,16,0,16,8,256,512,20,0,16,268,0,1,262,17,261,21,0,260,0,16,2,268,17,0,16,17,261,272,0,257,1,1,512]

theorem envBound34497 : H12AffineFastState.Bounded env34497 := by
  intro p hp
  have h : env34497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34496_34497 : H12AffineEnvironment.transform 10 0 env34496 = env34497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34496 == env34497) = true)

theorem identity34497 : scanCanonicalize (H12AffineFastState.compose env34497 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound34497 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34498 : List Nat := [2,4,8,4,0,4,8,256,512,0,0,4,268,0,1,262,5,261,1,0,260,0,4,2,268,5,0,4,5,261,260,0,257,1,1,512]

theorem envBound34498 : H12AffineFastState.Bounded env34498 := by
  intro p hp
  have h : env34498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34497_34498 : H12AffineEnvironment.transform 3 4 env34497 = env34498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env34497 == env34498) = true)

def env34499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575540,18973700,10507601,8538485,25265169,23160137,257,27378725,27337993,25207630]

theorem envBound34499 : H12AffineFastState.Bounded env34499 := by
  intro p hp
  have h : env34499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34390_34499 : H12AffineEnvironment.transform 6 9 env34390 = env34499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34390 == env34499) = true)

theorem identity34499 : scanCanonicalize (H12AffineFastState.compose env34499 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8634709) := by decide +kernel

theorem selectedBound34499 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,8388608,8634709,8193,65,4229153,10634577,10507601,8538485,148804,14853148,257,2229616,2286684,221723]

theorem envBound34500 : H12AffineFastState.Bounded env34500 := by
  intro p hp
  have h : env34500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34499_34500 : H12AffineEnvironment.transform 23 8634709 env34499 = env34500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8634709 env34499 == env34500) = true)

def env34501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147456,98645,8193,65,4229153,2098513,2233681,2421,148804,6349852,257,2229616,2286684,221723]

theorem envBound34501 : H12AffineFastState.Bounded env34501 := by
  intro p hp
  have h : env34501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34500_34501 : H12AffineEnvironment.transform 22 147456 env34500 = env34501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env34500 == env34501) = true)

theorem identity34501 : scanCanonicalize (H12AffineFastState.compose env34501 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound34501 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env34502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,73754,98645,8193,65,4229153,2098513,2192715,2421,75102,6349852,257,2188650,2196550,513]

theorem envBound34502 : H12AffineFastState.Bounded env34502 := by
  intro p hp
  have h : env34502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34501_34502 : H12AffineEnvironment.transform 16 90138 env34501 = env34502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env34501 == env34502) = true)

theorem identity34502 : scanCanonicalize (H12AffineFastState.compose env34502 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound34502 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env34503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,98679,73754,98645,8193,65,67926,2098513,2192715,2421,75102,2188651,257,2188650,2196550,513]

theorem envBound34503 : H12AffineFastState.Bounded env34503 := by
  intro p hp
  have h : env34503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34502_34503 : H12AffineEnvironment.transform 21 98679 env34502 = env34503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env34502 == env34503) = true)

theorem identity34503 : scanCanonicalize (H12AffineFastState.compose env34503 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(20+1) ^^^ 111882) := by decide +kernel

theorem selectedBound34503 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env34504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,111882,98679,73754,98645,8193,65,67926,110683,49217,2421,75102,53345,257,53344,12620,513]

theorem envBound34504 : H12AffineFastState.Bounded env34504 := by
  intro p hp
  have h : env34504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34503_34504 : H12AffineEnvironment.transform 20 111882 env34503 = env34504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111882 env34503 == env34504) = true)

theorem identity34504 : scanCanonicalize (H12AffineFastState.compose env34504 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34504 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env34505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1025,8540,70743,73770,73754,73736,8193,65,67926,69894,24860,2421,75102,28988,257,28989,12620,513]

theorem envBound34505 : H12AffineFastState.Bounded env34505 := by
  intro p hp
  have h : env34505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34504_34505 : H12AffineEnvironment.transform 14 8541 env34504 = env34505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34504 == env34505) = true)

theorem identity34505 : scanCanonicalize (H12AffineFastState.compose env34505 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound34505 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10280,1025,8540,25677,20528,20480,20498,8193,65,31052,24860,24860,2421,21828,28988,257,28989,12620,513]

theorem envBound34506 : H12AffineFastState.Bounded env34506 := by
  intro p hp
  have h : env34506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34505_34506 : H12AffineEnvironment.transform 15 28698 env34505 = env34506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env34505 == env34506) = true)

theorem identity34506 : scanCanonicalize (H12AffineFastState.compose env34506 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound34506 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2049,8541,14363,4096,10280,1025,8540,11340,6193,6145,6163,8193,65,12621,10525,10525,2421,7493,14653,257,14652,12620,513]

theorem envBound34507 : H12AffineFastState.Bounded env34507 := by
  intro p hp
  have h : env34507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34506_34507 : H12AffineEnvironment.transform 13 2049 env34506 = env34507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env34506 == env34507) = true)

theorem identity34507 : scanCanonicalize (H12AffineFastState.compose env34507 (packedSelected [3,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound34507 : packedSelected [3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env34508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,2049,1077,7539,4096,3392,1025,1076,2340,6193,6145,6163,1385,65,5157,3189,3189,2421,7493,7253,257,7252,5156,513]

theorem envBound34508 : H12AffineFastState.Bounded env34508 := by
  intro p hp
  have h : env34508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1