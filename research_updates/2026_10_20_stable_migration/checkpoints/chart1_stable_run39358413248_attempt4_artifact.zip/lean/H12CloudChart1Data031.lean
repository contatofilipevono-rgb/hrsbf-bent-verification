import H12CloudChart1Data030

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity7677 : scanCanonicalize (H12AffineFastState.compose env7677 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7678 : List Nat := [2,4,8,16,26,16,19,4,512,1024,522,1550,9,1567,0,24,1551,529,1025,0,1567,26,16,24,19,17,523,1551,1551,529,1025,1,5,1,1566,513]

theorem envBound7678 : H12AffineFastState.Bounded env7678 := by
  intro p hp
  have h : env7678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7677_7678 : H12AffineEnvironment.transform 4 26 env7677 = env7678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7677 == env7678) = true)

theorem identity7678 : scanCanonicalize (H12AffineFastState.compose env7678 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound7678 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7679 : List Nat := [2,4,8,16,26,16,19,4,15,1024,5,1025,9,1040,0,24,1024,30,1025,0,1040,26,16,24,19,17,4,1024,1024,30,1025,1,5,1,1041,14]

theorem envBound7679 : H12AffineFastState.Bounded env7679 := by
  intro p hp
  have h : env7679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7678_7679 : H12AffineEnvironment.transform 8 15 env7678 = env7679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env7678 == env7679) = true)

theorem identity7679 : scanCanonicalize (H12AffineFastState.compose env7679 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound7679 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7680 : List Nat := [2,4,8,16,26,16,19,4,15,10,5,11,9,26,0,24,10,30,11,0,26,26,16,24,19,17,4,10,10,30,11,1,5,1,27,14]

theorem envBound7680 : H12AffineFastState.Bounded env7680 := by
  intro p hp
  have h : env7680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7679_7680 : H12AffineEnvironment.transform 9 10 env7679 = env7680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env7679 == env7680) = true)

theorem identity7680 : scanCanonicalize (H12AffineFastState.compose env7680 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound7680 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7681 : List Nat := [2,4,8,10,0,10,9,4,15,10,5,11,9,0,0,2,10,4,11,0,0,0,10,2,9,11,4,10,10,4,11,1,5,1,1,14]

theorem envBound7681 : H12AffineFastState.Bounded env7681 := by
  intro p hp
  have h : env7681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7680_7681 : H12AffineEnvironment.transform 3 10 env7680 = env7681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env7680 == env7681) = true)

theorem identity7681 : scanCanonicalize (H12AffineFastState.compose env7681 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound7681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7682 : List Nat := [2,0,8,10,0,10,9,0,11,10,1,11,9,0,0,2,10,0,11,0,0,0,10,2,9,11,0,10,10,0,11,1,1,1,1,10]

theorem envBound7682 : H12AffineFastState.Bounded env7682 := by
  intro p hp
  have h : env7682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7681_7682 : H12AffineEnvironment.transform 1 0 env7681 = env7682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7681 == env7682) = true)

def env7683 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74077,8224,67108864,67450747,67184475,67184143,67116549,67633429,67114864,525568,67114533,69206081,74282]

theorem envBound7683 : H12AffineFastState.Bounded env7683 := by
  intro p hp
  have h : env7683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7665_7683 : H12AffineEnvironment.transform 21 33 env7665 = env7683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7665 == env7683) = true)

theorem identity7683 : scanCanonicalize (H12AffineFastState.compose env7683 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound7683 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7684 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74077,8224,2712942,2904597,2638389,2638689,2718571,2188411,2716190,525568,2716491,615727,74282]

theorem envBound7684 : H12AffineFastState.Bounded env7684 := by
  intro p hp
  have h : env7684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7683_7684 : H12AffineEnvironment.transform 25 2712942 env7683 = env7684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env7683 == env7684) = true)

theorem identity7684 : scanCanonicalize (H12AffineFastState.compose env7684 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879967) := by decide +kernel

theorem selectedBound7684 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7685 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,879967,33,525637,74077,8224,264241,81738,339818,339518,267828,788772,270145,525568,269844,615727,74282]

theorem envBound7685 : H12AffineFastState.Bounded env7685 := by
  intro p hp
  have h : env7685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7684_7685 : H12AffineEnvironment.transform 20 879967 env7684 = env7685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879967 env7684 == env7685) = true)

def env7686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,74229,8329,67108864,71645170,67184474,67184295,71310989,67633597,67114969,525568,71308973,73400521,74283]

theorem envBound7686 : H12AffineFastState.Bounded env7686 := by
  intro p hp
  have h : env7686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7636_7686 : H12AffineEnvironment.transform 23 74229 env7636 = env7686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74229 env7636 == env7686) = true)

def env7687 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,4194304,525636,74077,8225,67108864,71645018,67184474,67184143,71310885,67633429,67114865,525568,71308805,73400417,74283]

theorem envBound7687 : H12AffineFastState.Bounded env7687 := by
  intro p hp
  have h : env7687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7686_7687 : H12AffineEnvironment.transform 6 40 env7686 = env7687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7686 == env7687) = true)

def env7688 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,32,525636,74077,8225,67108864,67450746,67184474,67184143,67116549,67633429,67114865,525568,67114533,69206081,74283]

theorem envBound7688 : H12AffineFastState.Bounded env7688 := by
  intro p hp
  have h : env7688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7687_7688 : H12AffineEnvironment.transform 21 32 env7687 = env7688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7687 == env7688) = true)

theorem identity7688 : scanCanonicalize (H12AffineFastState.compose env7688 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619038) := by decide +kernel

theorem selectedBound7688 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7689 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,619038,32,525636,74077,8225,67108864,67450746,67184474,67184143,67116549,67633429,67114865,525568,67114533,67727967,74283]

theorem envBound7689 : H12AffineFastState.Bounded env7689 := by
  intro p hp
  have h : env7689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7688_7689 : H12AffineEnvironment.transform 20 619038 env7688 = env7689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619038 env7688 == env7689) = true)

theorem identity7689 : scanCanonicalize (H12AffineFastState.compose env7689 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound7689 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7690 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,7700,524288,8540,619038,32,525636,74077,8225,67108864,67185006,67184474,67184143,67116549,67633429,67114865,525568,67114533,67727967,74283]

theorem envBound7690 : H12AffineFastState.Bounded env7690 := by
  intro p hp
  have h : env7690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7689_7690 : H12AffineEnvironment.transform 17 7700 env7689 = env7690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env7689 == env7690) = true)

theorem identity7690 : scanCanonicalize (H12AffineFastState.compose env7690 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7690 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7691 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,524288,8201,619038,32,525329,73736,8225,67108864,67184699,67184143,67184143,67116549,67633216,67114532,525397,67114533,67727967,74283]

theorem envBound7691 : H12AffineFastState.Bounded env7691 := by
  intro p hp
  have h : env7691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7690_7691 : H12AffineEnvironment.transform 7 85 env7690 = env7691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7690 == env7691) = true)

theorem identity7691 : scanCanonicalize (H12AffineFastState.compose env7691 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 4708) := by decide +kernel

theorem selectedBound7691 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7692 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,4708,8201,90234,32,5749,73736,8225,67108864,67184699,67184143,67184143,67116549,67113508,67114532,5681,67114533,67199035,74283]

theorem envBound7692 : H12AffineFastState.Bounded env7692 := by
  intro p hp
  have h : env7692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7691_7692 : H12AffineEnvironment.transform 18 4708 env7691 = env7692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4708 env7691 == env7692) = true)

theorem identity7692 : scanCanonicalize (H12AffineFastState.compose env7692 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7692 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7693 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,8235,4097,7700,4708,8201,16465,32,5749,35,8225,67108864,67110928,67110436,67110436,67116549,67113508,67114532,5681,67114533,67125264,512]

theorem envBound7693 : H12AffineFastState.Bounded env7693 := by
  intro p hp
  have h : env7693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7692_7693 : H12AffineEnvironment.transform 15 8235 env7692 = env7693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7692 == env7693) = true)

theorem identity7693 : scanCanonicalize (H12AffineFastState.compose env7693 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(25+1) ^^^ 31257) := by decide +kernel

theorem selectedBound7693 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7694 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,8235,4097,7700,4708,8201,16465,32,5749,35,8225,31257,29193,31805,31805,25628,26685,27709,5681,27708,14857,512]

theorem envBound7694 : H12AffineFastState.Bounded env7694 := by
  intro p hp
  have h : env7694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7693_7694 : H12AffineEnvironment.transform 25 31257 env7693 = env7694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 31257 env7693 == env7694) = true)

theorem identity7694 : scanCanonicalize (H12AffineFastState.compose env7694 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 11341) := by decide +kernel

theorem selectedBound7694 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7695 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11341,8201,8235,4097,7700,4708,8201,11292,32,5749,35,8225,5716,7748,4208,4208,2129,1136,112,5681,113,14857,512]

theorem envBound7695 : H12AffineFastState.Bounded env7695 := by
  intro p hp
  have h : env7695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7694_7695 : H12AffineEnvironment.transform 13 11341 env7694 = env7695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11341 env7694 == env7695) = true)

theorem identity7695 : scanCanonicalize (H12AffineFastState.compose env7695 (packedSelected [0,6] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound7695 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env7696 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,552,3685,545,515,4097,7700,4708,545,3636,32,5749,35,521,5716,7748,4208,4208,2129,1136,112,5681,113,6177,512]

theorem envBound7696 : H12AffineFastState.Bounded env7696 := by
  intro p hp
  have h : env7696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7695_7696 : H12AffineEnvironment.transform 12 552 env7695 = env7696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env7695 == env7696) = true)

theorem identity7696 : scanCanonicalize (H12AffineFastState.compose env7696 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound7696 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env7697 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1588,552,3685,545,515,1589,2080,1104,545,3636,32,65,35,521,96,2160,1604,1604,2129,1136,112,5,113,3605,512]

theorem envBound7697 : H12AffineFastState.Bounded env7697 := by
  intro p hp
  have h : env7697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7696_7697 : H12AffineEnvironment.transform 11 1588 env7696 = env7697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env7696 == env7697) = true)

theorem identity7697 : scanCanonicalize (H12AffineFastState.compose env7697 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound7697 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env7698 : List Nat := [2,4,8,16,32,64,40,85,107,1024,2048,1119,67,3086,74,104,1118,2080,1104,74,3167,32,65,35,98,96,2160,1071,1071,2129,1136,112,5,113,3198,107]

theorem envBound7698 : H12AffineFastState.Bounded env7698 := by
  intro p hp
  have h : env7698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7697_7698 : H12AffineEnvironment.transform 8 107 env7697 = env7698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env7697 == env7698) = true)

theorem identity7698 : scanCanonicalize (H12AffineFastState.compose env7698 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound7698 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7699 : List Nat := [2,4,8,16,32,48,40,37,27,1024,2048,1071,51,3086,58,24,1070,2080,1056,58,3119,32,49,35,18,16,2048,1071,1071,2081,1024,0,5,1,3086,27]

theorem envBound7699 : H12AffineFastState.Bounded env7699 := by
  intro p hp
  have h : env7699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7698_7699 : H12AffineEnvironment.transform 5 48 env7698 = env7699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7698 == env7699) = true)

theorem identity7699 : scanCanonicalize (H12AffineFastState.compose env7699 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound7699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7700 : List Nat := [2,4,8,16,32,48,40,37,27,1024,16,1071,51,1054,58,24,1070,48,1056,58,1087,32,49,35,18,16,16,1071,1071,49,1024,0,5,1,1054,27]

theorem envBound7700 : H12AffineFastState.Bounded env7700 := by
  intro p hp
  have h : env7700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7699_7700 : H12AffineEnvironment.transform 10 16 env7699 = env7700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env7699 == env7700) = true)

theorem identity7700 : scanCanonicalize (H12AffineFastState.compose env7700 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound7700 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7701 : List Nat := [2,4,8,16,27,11,19,30,27,1024,16,1044,8,1054,1,24,1045,11,1051,1,1028,27,10,24,18,16,16,1044,1044,10,1024,0,5,1,1054,27]

theorem envBound7701 : H12AffineFastState.Bounded env7701 := by
  intro p hp
  have h : env7701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7700_7701 : H12AffineEnvironment.transform 4 27 env7700 = env7701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env7700 == env7701) = true)

def leafEnv7701 : List Nat := [2,4,8,16,27,11,19,30,27,1024,16,1044,8,1054,1,24,1045,11,1051,1,1028,27,10,24,1051,18,1,16,16,1044,1044,10,1024,0,5,1,31,3,1054,27,1,1029,0]

def active7701 : List Nat := [0,1,2,3,9]

def tree7701 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7701 : H12WitnessSearch.Good tree7701 := H12GlobalWitnessIndex.good

theorem leafIdentity7701 : H12AffineFastState.composeSystem env7701 rootObs = leafEnv7701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7701 rootObs == leafEnv7701) = true)

theorem terminalChecked7701 : H12PackedTerminal.terminalCheckFast leafEnv7701 active7701 tree7701 = true := by decide +kernel

def env7702 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,33,525636,74077,8225,67108864,67450747,67184474,67184143,67116548,67633429,67114865,525568,67114532,69206080,74283]

theorem envBound7702 : H12AffineFastState.Bounded env7702 := by
  intro p hp
  have h : env7702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7687_7702 : H12AffineEnvironment.transform 21 33 env7687 = env7702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7687 == env7702) = true)

theorem identity7702 : scanCanonicalize (H12AffineFastState.compose env7702 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound7702 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7703 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,33,525636,74077,8225,2712942,2904597,2638388,2638689,2718570,2188411,2716191,525568,2716490,615726,74283]

theorem envBound7703 : H12AffineFastState.Bounded env7703 := by
  intro p hp
  have h : env7703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7702_7703 : H12AffineEnvironment.transform 25 2712942 env7702 = env7703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env7702 == env7703) = true)

theorem identity7703 : scanCanonicalize (H12AffineFastState.compose env7703 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879966) := by decide +kernel

theorem selectedBound7703 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7704 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,879966,33,525636,74077,8225,264240,81739,339818,339519,267828,788773,270145,525568,269844,615726,74283]

theorem envBound7704 : H12AffineFastState.Bounded env7704 := by
  intro p hp
  have h : env7704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7703_7704 : H12AffineEnvironment.transform 20 879966 env7703 = env7704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879966 env7703 == env7704) = true)

theorem identity7704 : scanCanonicalize (H12AffineFastState.compose env7704 (packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78618) := by decide +kernel

theorem selectedBound7704 : packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7705 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,78618,8540,286276,33,79454,74077,8225,264240,81739,339818,339519,267828,342591,270145,79386,269844,22068,74283]

theorem envBound7705 : H12AffineFastState.Bounded env7705 := by
  intro p hp
  have h : env7705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7704_7705 : H12AffineEnvironment.transform 18 78618 env7704 = env7705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78618 env7704 == env7705) = true)

theorem identity7705 : scanCanonicalize (H12AffineFastState.compose env7705 (packedSelected [1,3,12,13,14,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound7705 : packedSelected [1,3,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env7706 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,8574,4436,262144,4708,8540,286276,33,5920,35,8225,264240,7733,265748,266049,267828,269121,270145,5988,269844,22068,853]

theorem envBound7706 : H12AffineFastState.Bounded env7706 := by
  intro p hp
  have h : env7706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7705_7706 : H12AffineEnvironment.transform 15 8574 env7705 = env7706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env7705 == env7706) = true)

theorem identity7706 : scanCanonicalize (H12AffineFastState.compose env7706 (packedSelected [0,2,3,4,5,6,11,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7706 : packedSelected [0,2,3,4,5,6,11,12,13] rootPS < 2^1333 := by decide +kernel

def env7707 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,8574,4436,2080,4708,8540,22116,33,5920,35,8225,16,7733,1588,1889,7700,4961,5985,5988,5684,22068,853]

theorem envBound7707 : H12AffineFastState.Bounded env7707 := by
  intro p hp
  have h : env7707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7706_7707 : H12AffineEnvironment.transform 17 2080 env7706 = env7707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7706 == env7707) = true)

theorem identity7707 : scanCanonicalize (H12AffineFastState.compose env7707 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7707 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7708 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,8235,4097,2080,4708,8201,22116,33,5749,35,8225,16,7733,1588,1588,7700,4660,5684,5681,5684,22068,512]

theorem envBound7708 : H12AffineFastState.Bounded env7708 := by
  intro p hp
  have h : env7708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7707_7708 : H12AffineEnvironment.transform 7 85 env7707 = env7708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7707 == env7708) = true)

theorem identity7708 : scanCanonicalize (H12AffineFastState.compose env7708 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 11293) := by decide +kernel

theorem selectedBound7708 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7709 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11293,8201,8235,4097,2080,4708,8201,14969,33,5749,35,8225,16,7733,1588,1588,7700,4660,5684,5681,5684,14889,512]

theorem envBound7709 : H12AffineFastState.Bounded env7709 := by
  intro p hp
  have h : env7709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7708_7709 : H12AffineEnvironment.transform 13 11293 env7708 = env7709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11293 env7708 == env7709) = true)

theorem identity7709 : scanCanonicalize (H12AffineFastState.compose env7709 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2067) := by decide +kernel

theorem selectedBound7709 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env7710 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,2067,1038,2074,2104,4097,2080,4708,2074,4714,33,5749,35,2098,16,7733,1588,1588,7700,4660,5684,5681,5684,4666,512]

theorem envBound7710 : H12AffineFastState.Bounded env7710 := by
  intro p hp
  have h : env7710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7709_7710 : H12AffineEnvironment.transform 12 2067 env7709 = env7710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2067 env7709 == env7710) = true)

theorem identity7710 : scanCanonicalize (H12AffineFastState.compose env7710 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound7710 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7711 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1588,2067,1038,2074,2104,1589,2080,1104,2074,1118,33,65,35,2098,16,2049,1588,1588,2080,1024,0,5,0,1038,512]

theorem envBound7711 : H12AffineFastState.Bounded env7711 := by
  intro p hp
  have h : env7711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7710_7711 : H12AffineEnvironment.transform 11 1588 env7710 = env7711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env7710 == env7711) = true)

theorem identity7711 : scanCanonicalize (H12AffineFastState.compose env7711 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound7711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7712 : List Nat := [2,4,8,16,32,64,40,85,123,1024,2048,1103,2067,1038,2074,2104,1102,2080,1104,2074,1118,33,65,35,2098,16,2049,1103,1103,2080,1024,0,5,0,1038,123]

theorem envBound7712 : H12AffineFastState.Bounded env7712 := by
  intro p hp
  have h : env7712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7711_7712 : H12AffineEnvironment.transform 8 123 env7711 = env7712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env7711 == env7712) = true)

def env7713 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,4194304,525637,74076,8224,67108864,71645019,67184474,67184142,71310884,67633428,67114864,525568,71308804,73400416,74283]

theorem envBound7713 : H12AffineFastState.Bounded env7713 := by
  intro p hp
  have h : env7713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7686_7713 : H12AffineEnvironment.transform 6 41 env7686 = env7713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7686 == env7713) = true)

def env7714 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,32,525637,74076,8224,67108864,67450747,67184474,67184142,67116548,67633428,67114864,525568,67114532,69206080,74283]

theorem envBound7714 : H12AffineFastState.Bounded env7714 := by
  intro p hp
  have h : env7714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7713_7714 : H12AffineEnvironment.transform 21 32 env7713 = env7714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7713 == env7714) = true)

theorem identity7714 : scanCanonicalize (H12AffineFastState.compose env7714 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712942) := by decide +kernel

theorem selectedBound7714 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7715 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,32,525637,74076,8224,2712942,2904597,2638388,2638688,2718570,2188410,2716190,525568,2716490,615726,74283]

theorem envBound7715 : H12AffineFastState.Bounded env7715 := by
  intro p hp
  have h : env7715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7714_7715 : H12AffineEnvironment.transform 25 2712942 env7714 = env7715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712942 env7714 == env7715) = true)

theorem identity7715 : scanCanonicalize (H12AffineFastState.compose env7715 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286481) := by decide +kernel

theorem selectedBound7715 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7716 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,286481,32,525637,74076,8224,866943,527620,793893,793713,861307,342891,863503,525568,863323,615726,74283]

theorem envBound7716 : H12AffineFastState.Bounded env7716 := by
  intro p hp
  have h : env7716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7715_7716 : H12AffineEnvironment.transform 20 286481 env7715 = env7716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286481 env7715 == env7716) = true)

theorem identity7716 : scanCanonicalize (H12AffineFastState.compose env7716 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound7716 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7717 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,78414,8541,286481,32,79627,74076,8224,264241,81738,339819,339519,267829,342891,270145,79694,269845,22368,74283]

theorem envBound7717 : H12AffineFastState.Bounded env7717 := by
  intro p hp
  have h : env7717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7716_7717 : H12AffineEnvironment.transform 18 78414 env7716 = env7717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env7716 == env7717) = true)

theorem identity7717 : scanCanonicalize (H12AffineFastState.compose env7717 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7717 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7718 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,78414,8201,286277,32,79455,73736,8224,264241,81438,339519,339519,267829,342591,269845,79386,269845,22068,74283]

theorem envBound7718 : H12AffineFastState.Bounded env7718 := by
  intro p hp
  have h : env7718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7717_7718 : H12AffineEnvironment.transform 7 84 env7717 = env7718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7717 == env7718) = true)

theorem identity7718 : scanCanonicalize (H12AffineFastState.compose env7718 (packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 7700) := by decide +kernel

theorem selectedBound7718 : packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7719 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,7700,78414,8201,16465,32,79455,73736,8224,5669,81438,77867,77867,2081,74795,1,79386,1,22068,74283]

theorem envBound7719 : H12AffineFastState.Bounded env7719 := by
  intro p hp
  have h : env7719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7718_7719 : H12AffineEnvironment.transform 17 7700 env7718 = env7719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7700 env7718 == env7719) = true)

theorem identity7719 : scanCanonicalize (H12AffineFastState.compose env7719 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7719 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7720 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,8235,4097,7700,4709,8201,16465,32,5748,35,8224,5669,7733,4096,4096,2081,1024,1,5681,1,22068,512]

theorem envBound7720 : H12AffineFastState.Bounded env7720 := by
  intro p hp
  have h : env7720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7719_7720 : H12AffineEnvironment.transform 15 8235 env7719 = env7720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7719 == env7720) = true)

theorem identity7720 : scanCanonicalize (H12AffineFastState.compose env7720 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound7720 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7721 : List Nat := [2,4,8,16,32,42,41,62,512,1024,2048,4096,8192,16384,8201,8235,4097,7700,4623,8201,16443,32,5662,35,8224,5669,7733,4096,4096,2081,1024,1,5681,1,22068,512]

theorem envBound7721 : H12AffineFastState.Bounded env7721 := by
  intro p hp
  have h : env7721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7720_7721 : H12AffineEnvironment.transform 5 42 env7720 = env7721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env7720 == env7721) = true)

def env7722 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74076,8224,67108864,67450746,67184474,67184142,67116549,67633428,67114864,525568,67114533,69206081,74283]

theorem envBound7722 : H12AffineFastState.Bounded env7722 := by
  intro p hp
  have h : env7722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7713_7722 : H12AffineEnvironment.transform 21 33 env7713 = env7722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7713 == env7722) = true)

theorem identity7722 : scanCanonicalize (H12AffineFastState.compose env7722 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619039) := by decide +kernel

theorem selectedBound7722 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7723 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,619039,33,525637,74076,8224,67108864,67450746,67184474,67184142,67116549,67633428,67114864,525568,67114533,67727966,74283]

theorem envBound7723 : H12AffineFastState.Bounded env7723 := by
  intro p hp
  have h : env7723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7722_7723 : H12AffineEnvironment.transform 20 619039 env7722 = env7723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619039 env7722 == env7723) = true)

theorem identity7723 : scanCanonicalize (H12AffineFastState.compose env7723 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339034) := by decide +kernel

theorem selectedBound7723 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7724 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,339034,8541,286277,33,338207,74076,8224,67108864,67450746,67184474,67184142,67116549,67448142,67114864,338266,67114533,67395076,74283]

theorem envBound7724 : H12AffineFastState.Bounded env7724 := by
  intro p hp
  have h : env7724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7723_7724 : H12AffineEnvironment.transform 18 339034 env7723 = env7724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339034 env7723 == env7724) = true)

def env7725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,67108864,134217728,138678441,138678612,151259274,84484168,155451870,525568,151257258,73400521,16778206]

theorem envBound7725 : H12AffineFastState.Bounded env7725 := by
  intro p hp
  have h : env7725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7634_7725 : H12AffineEnvironment.transform 27 138678441 env7634 = env7725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env7634 == env7725) = true)

theorem identity7725 : scanCanonicalize (H12AffineFastState.compose env7725 (packedSelected [9,14,22] rootPS)) = affineNative (2^(26+1) ^^^ 88348667) := by decide +kernel

theorem selectedBound7725 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env7726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,67108864,88348667,83887954,83887791,71311217,84484168,67114533,525568,71309137,73400521,16778206]

theorem envBound7726 : H12AffineFastState.Bounded env7726 := by
  intro p hp
  have h : env7726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7725_7726 : H12AffineEnvironment.transform 26 88348667 env7725 = env7726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 88348667 env7725 == env7726) = true)

def env7727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,74228,8329,67108864,71644687,67184294,67184475,71311217,67633596,67114533,525568,71309137,73400521,74282]

theorem envBound7727 : H12AffineFastState.Bounded env7727 := by
  intro p hp
  have h : env7727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7726_7727 : H12AffineEnvironment.transform 23 74228 env7726 = env7727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74228 env7726 == env7727) = true)

def env7728 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,4194304,525636,74076,8225,67108864,71644687,67184142,67184475,71311217,67633428,67114533,525568,71309137,73400417,74282]

theorem envBound7728 : H12AffineFastState.Bounded env7728 := by
  intro p hp
  have h : env7728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7727_7728 : H12AffineEnvironment.transform 6 40 env7727 = env7728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7727 == env7728) = true)

def env7729 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,32,525636,74076,8225,67108864,67450415,67184142,67184475,67116881,67633428,67114533,525568,67114865,69206081,74282]

theorem envBound7729 : H12AffineFastState.Bounded env7729 := by
  intro p hp
  have h : env7729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7728_7729 : H12AffineEnvironment.transform 21 32 env7728 = env7729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7728 == env7729) = true)

theorem identity7729 : scanCanonicalize (H12AffineFastState.compose env7729 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound7729 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7730 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,32,525636,74076,8225,2712943,2904896,2638689,2638388,2718270,2188411,2716490,525568,2716190,615726,74282]

theorem envBound7730 : H12AffineFastState.Bounded env7730 := by
  intro p hp
  have h : env7730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7729_7730 : H12AffineEnvironment.transform 25 2712943 env7729 = env7730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env7729 == env7730) = true)

theorem identity7730 : scanCanonicalize (H12AffineFastState.compose env7730 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286277) := by decide +kernel

theorem selectedBound7730 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7731 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,286277,32,525636,74076,8225,867114,527621,793892,793713,861307,342590,863503,525568,863323,615726,74282]

theorem envBound7731 : H12AffineFastState.Bounded env7731 := by
  intro p hp
  have h : env7731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7730_7731 : H12AffineEnvironment.transform 20 286277 env7730 = env7731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286277 env7730 == env7731) = true)

theorem identity7731 : scanCanonicalize (H12AffineFastState.compose env7731 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78618) := by decide +kernel

theorem selectedBound7731 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7732 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,78618,8540,286277,32,79454,74076,8225,264240,81439,339518,339819,268129,342590,269845,79386,270145,22068,74282]

theorem envBound7732 : H12AffineFastState.Bounded env7732 := by
  intro p hp
  have h : env7732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7731_7732 : H12AffineEnvironment.transform 18 78618 env7731 = env7732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78618 env7731 == env7732) = true)

theorem identity7732 : scanCanonicalize (H12AffineFastState.compose env7732 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7732 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7733 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,78414,8200,286277,32,79454,73736,8225,264240,81439,339518,339519,267829,342590,269845,79386,269845,22068,74282]

theorem envBound7733 : H12AffineFastState.Bounded env7733 := by
  intro p hp
  have h : env7733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7732_7733 : H12AffineEnvironment.transform 7 84 env7732 = env7733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7732 == env7733) = true)

theorem identity7733 : scanCanonicalize (H12AffineFastState.compose env7733 (packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 81471) := by decide +kernel

theorem selectedBound7733 : packedSelected [1,2,4,6,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7734 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,4096,81471,78414,8200,90234,32,79454,73736,8225,79375,81439,4097,4096,75786,1025,73770,79386,73770,22068,74282]

theorem envBound7734 : H12AffineFastState.Bounded env7734 := by
  intro p hp
  have h : env7734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7733_7734 : H12AffineEnvironment.transform 17 81471 env7733 = env7734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81471 env7733 == env7734) = true)

theorem identity7734 : scanCanonicalize (H12AffineFastState.compose env7734 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7734 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env7735 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,8235,4096,7700,4709,8200,16465,32,5749,35,8225,5668,7732,4097,4096,2081,1025,1,5681,1,22068,513]

theorem envBound7735 : H12AffineFastState.Bounded env7735 := by
  intro p hp
  have h : env7735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7734_7735 : H12AffineEnvironment.transform 15 8235 env7734 = env7735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7734 == env7735) = true)

theorem identity7735 : scanCanonicalize (H12AffineFastState.compose env7735 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1653) := by decide +kernel

theorem selectedBound7735 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7736 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,1653,8200,8235,4096,7700,4709,8200,1572,32,5749,35,8225,5668,7732,4097,4096,2081,1025,1,5681,1,4161,513]

theorem envBound7736 : H12AffineFastState.Bounded env7736 := by
  intro p hp
  have h : env7736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7735_7736 : H12AffineEnvironment.transform 13 1653 env7735 = env7736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1653 env7735 == env7736) = true)

theorem identity7736 : scanCanonicalize (H12AffineFastState.compose env7736 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound7736 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7737 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1582,8192,1653,8200,8235,1582,2106,1099,8200,1572,32,91,35,8225,10,2074,1583,1582,2081,1025,1,31,1,1647,513]

theorem envBound7737 : H12AffineFastState.Bounded env7737 := by
  intro p hp
  have h : env7737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7736_7737 : H12AffineEnvironment.transform 11 1582 env7736 = env7737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env7736 == env7737) = true)

theorem identity7737 : scanCanonicalize (H12AffineFastState.compose env7737 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound7737 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7738 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1582,9,1653,1,34,1582,2106,1099,1,1572,32,91,35,40,10,2074,1583,1582,2081,1025,1,31,1,1647,513]

theorem envBound7738 : H12AffineFastState.Bounded env7738 := by
  intro p hp
  have h : env7738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7737_7738 : H12AffineEnvironment.transform 12 9 env7737 = env7738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env7737 == env7738) = true)

theorem identity7738 : scanCanonicalize (H12AffineFastState.compose env7738 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound7738 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env7739 : List Nat := [2,4,8,16,32,64,40,84,512,1024,528,1582,9,1653,1,34,1582,554,1099,1,1572,32,91,35,40,10,522,1583,1582,561,1025,1,31,1,1647,513]

theorem envBound7739 : H12AffineFastState.Bounded env7739 := by
  intro p hp
  have h : env7739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7738_7739 : H12AffineEnvironment.transform 10 528 env7738 = env7739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env7738 == env7739) = true)

theorem identity7739 : scanCanonicalize (H12AffineFastState.compose env7739 (packedSelected [13] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound7739 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7740 : List Nat := [2,4,8,10,32,64,40,78,512,1024,522,1582,9,1647,1,34,1582,554,1099,1,1572,32,65,35,40,10,522,1583,1582,555,1025,1,5,1,1647,513]

theorem envBound7740 : H12AffineFastState.Bounded env7740 := by
  intro p hp
  have h : env7740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7739_7740 : H12AffineEnvironment.transform 3 10 env7739 = env7740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env7739 == env7740) = true)

theorem identity7740 : scanCanonicalize (H12AffineFastState.compose env7740 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound7740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7741 : List Nat := [2,4,8,10,32,11,40,5,512,1024,522,1582,9,1572,1,34,1582,554,1024,1,1572,32,10,35,40,10,522,1583,1582,555,1025,1,5,1,1572,513]

theorem envBound7741 : H12AffineFastState.Bounded env7741 := by
  intro p hp
  have h : env7741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7740_7741 : H12AffineEnvironment.transform 5 11 env7740 = env7741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env7740 == env7741) = true)

theorem identity7741 : scanCanonicalize (H12AffineFastState.compose env7741 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound7741 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7742 : List Nat := [2,4,8,10,32,11,40,5,47,1024,37,1025,9,1035,1,34,1025,5,1024,1,1035,32,10,35,40,10,37,1024,1025,4,1025,1,5,1,1035,46]

theorem envBound7742 : H12AffineFastState.Bounded env7742 := by
  intro p hp
  have h : env7742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7741_7742 : H12AffineEnvironment.transform 8 47 env7741 = env7742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env7741 == env7742) = true)

theorem identity7742 : scanCanonicalize (H12AffineFastState.compose env7742 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound7742 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7743 : List Nat := [2,4,8,10,32,11,40,5,47,11,37,10,9,0,1,34,10,5,11,1,0,32,10,35,40,10,37,11,10,4,10,1,5,1,0,46]

theorem envBound7743 : H12AffineFastState.Bounded env7743 := by
  intro p hp
  have h : env7743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7742_7743 : H12AffineEnvironment.transform 9 11 env7742 = env7743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env7742 == env7743) = true)

theorem identity7743 : scanCanonicalize (H12AffineFastState.compose env7743 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound7743 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7744 : List Nat := [2,4,8,10,0,11,8,5,15,11,5,10,9,0,1,2,10,5,11,1,0,0,10,3,8,10,5,11,10,4,10,1,5,1,0,14]

theorem envBound7744 : H12AffineFastState.Bounded env7744 := by
  intro p hp
  have h : env7744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7743_7744 : H12AffineEnvironment.transform 4 0 env7743 = env7744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env7743 == env7744) = true)

theorem identity7744 : scanCanonicalize (H12AffineFastState.compose env7744 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound7744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7745 : List Nat := [2,1,8,10,0,11,8,0,10,11,0,10,9,0,1,2,10,0,11,1,0,0,10,3,8,10,0,11,10,1,10,1,0,1,0,11]

theorem envBound7745 : H12AffineFastState.Bounded env7745 := by
  intro p hp
  have h : env7745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7744_7745 : H12AffineEnvironment.transform 1 1 env7744 = env7745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env7744 == env7745) = true)

def env7746 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,33,525636,74076,8225,67108864,67450414,67184142,67184475,67116880,67633428,67114533,525568,67114864,69206080,74282]

theorem envBound7746 : H12AffineFastState.Bounded env7746 := by
  intro p hp
  have h : env7746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7728_7746 : H12AffineEnvironment.transform 21 33 env7728 = env7746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7728 == env7746) = true)

theorem identity7746 : scanCanonicalize (H12AffineFastState.compose env7746 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619338) := by decide +kernel

theorem selectedBound7746 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7747 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,619338,33,525636,74076,8225,67108864,67450414,67184142,67184475,67116880,67633428,67114533,525568,67114864,67728138,74282]

theorem envBound7747 : H12AffineFastState.Bounded env7747 := by
  intro p hp
  have h : env7747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7746_7747 : H12AffineEnvironment.transform 20 619338 env7746 = env7747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619338 env7746 == env7747) = true)

theorem identity7747 : scanCanonicalize (H12AffineFastState.compose env7747 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339035) := by decide +kernel

theorem selectedBound7747 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7748 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,339035,8540,286481,33,338207,74076,8225,67108864,67450414,67184142,67184475,67116880,67448143,67114533,338267,67114864,67395409,74282]

theorem envBound7748 : H12AffineFastState.Bounded env7748 := by
  intro p hp
  have h : env7748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7747_7748 : H12AffineEnvironment.transform 18 339035 env7747 = env7748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339035 env7747 == env7748) = true)

def env7749 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,4194304,525637,74077,8224,67108864,71644687,67184143,67184475,71311217,67633429,67114533,525568,71309137,73400416,74282]

theorem envBound7749 : H12AffineFastState.Bounded env7749 := by
  intro p hp
  have h : env7749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7727_7749 : H12AffineEnvironment.transform 6 41 env7727 = env7749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7727 == env7749) = true)

def env7750 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,32,525637,74077,8224,67108864,67450415,67184143,67184475,67116881,67633429,67114533,525568,67114865,69206080,74282]

theorem envBound7750 : H12AffineFastState.Bounded env7750 := by
  intro p hp
  have h : env7750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7749_7750 : H12AffineEnvironment.transform 21 32 env7749 = env7750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7749 == env7750) = true)

theorem identity7750 : scanCanonicalize (H12AffineFastState.compose env7750 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619338) := by decide +kernel

theorem selectedBound7750 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7751 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,619338,32,525637,74077,8224,67108864,67450415,67184143,67184475,67116881,67633429,67114533,525568,67114865,67728138,74282]

theorem envBound7751 : H12AffineFastState.Bounded env7751 := by
  intro p hp
  have h : env7751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7750_7751 : H12AffineEnvironment.transform 20 619338 env7750 = env7751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619338 env7750 == env7751) = true)

theorem identity7751 : scanCanonicalize (H12AffineFastState.compose env7751 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound7751 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7752 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,8000,524288,8541,619338,32,525637,74077,8224,67108864,67185007,67184143,67184475,67116881,67633429,67114533,525568,67114865,67728138,74282]

theorem envBound7752 : H12AffineFastState.Bounded env7752 := by
  intro p hp
  have h : env7752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7751_7752 : H12AffineEnvironment.transform 17 8000 env7751 = env7752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env7751 == env7752) = true)

theorem identity7752 : scanCanonicalize (H12AffineFastState.compose env7752 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7752 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7753 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,4096,7701,524288,8200,619039,32,525328,73736,8224,67108864,67184698,67184143,67184142,67116548,67633216,67114533,525397,67114532,67727967,74282]

theorem envBound7753 : H12AffineFastState.Bounded env7753 := by
  intro p hp
  have h : env7753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7752_7753 : H12AffineEnvironment.transform 7 85 env7752 = env7753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7752 == env7753) = true)

theorem identity7753 : scanCanonicalize (H12AffineFastState.compose env7753 (packedSelected [13,17] rootPS)) = affineNative (2^(18+1) ^^^ 4709) := by decide +kernel

theorem selectedBound7753 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7754 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,4096,7701,4709,8200,90234,32,5749,73736,8224,67108864,67184698,67184143,67184142,67116548,67113509,67114533,5680,67114532,67199034,74282]

theorem envBound7754 : H12AffineFastState.Bounded env7754 := by
  intro p hp
  have h : env7754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7753_7754 : H12AffineEnvironment.transform 18 4709 env7753 = env7754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4709 env7753 == env7754) = true)

theorem identity7754 : scanCanonicalize (H12AffineFastState.compose env7754 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7754 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7755 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,8234,4096,7701,4709,8200,16464,32,5749,34,8224,67108864,67110928,67110437,67110436,67116548,67113509,67114533,5680,67114532,67125264,512]

theorem envBound7755 : H12AffineFastState.Bounded env7755 := by
  intro p hp
  have h : env7755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7754_7755 : H12AffineEnvironment.transform 15 8234 env7754 = env7755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7754 == env7755) = true)

theorem identity7755 : scanCanonicalize (H12AffineFastState.compose env7755 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(25+1) ^^^ 27693) := by decide +kernel

theorem selectedBound7755 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7756 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,8234,4096,7701,4709,8200,16464,32,5749,34,8224,27693,25661,27144,27145,29225,32264,31240,5680,31241,11325,512]

theorem envBound7756 : H12AffineFastState.Bounded env7756 := by
  intro p hp
  have h : env7756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7755_7756 : H12AffineEnvironment.transform 25 27693 env7755 = env7756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 27693 env7755 == env7756) = true)

theorem identity7756 : scanCanonicalize (H12AffineFastState.compose env7756 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 14968) := by decide +kernel

theorem selectedBound7756 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7757 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,14968,8200,8234,4096,7701,4709,8200,14888,32,5749,34,8224,5717,7749,4208,4209,2129,1136,112,5680,113,11325,512]

theorem envBound7757 : H12AffineFastState.Bounded env7757 := by
  intro p hp
  have h : env7757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7756_7757 : H12AffineEnvironment.transform 13 14968 env7756 = env7757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14968 env7756 == env7757) = true)

theorem identity7757 : scanCanonicalize (H12AffineFastState.compose env7757 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1605) := by decide +kernel

theorem selectedBound7757 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env7758 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,1605,8192,11325,8200,8234,1605,2128,1056,8200,11373,32,48,34,8224,16,2048,1589,1588,2129,1136,112,117,113,11325,512]

theorem envBound7758 : H12AffineFastState.Bounded env7758 := by
  intro p hp
  have h : env7758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7757_7758 : H12AffineEnvironment.transform 11 1605 env7757 = env7758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1605 env7757 == env7758) = true)

theorem identity7758 : scanCanonicalize (H12AffineFastState.compose env7758 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound7758 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env7759 : List Nat := [2,4,8,16,27,64,18,85,512,1024,2048,1605,8192,11270,8200,8209,1605,2128,1051,8200,11350,27,11,25,8219,16,2048,1550,1551,2129,1099,75,78,74,11270,512]

theorem envBound7759 : H12AffineFastState.Bounded env7759 := by
  intro p hp
  have h : env7759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7758_7759 : H12AffineEnvironment.transform 4 27 env7758 = env7759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env7758 == env7759) = true)

theorem identity7759 : scanCanonicalize (H12AffineFastState.compose env7759 (packedSelected [1,2,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound7759 : packedSelected [1,2,4,10] rootPS < 2^1333 := by decide +kernel

def env7760 : List Nat := [2,4,8,16,27,11,18,30,512,1024,2048,1550,8192,11270,8200,8209,1550,2075,1051,8200,11293,27,11,25,8219,16,2048,1550,1551,2074,1024,0,5,1,11270,512]

theorem envBound7760 : H12AffineFastState.Bounded env7760 := by
  intro p hp
  have h : env7760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7759_7760 : H12AffineEnvironment.transform 5 11 env7759 = env7760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env7759 == env7760) = true)

theorem identity7760 : scanCanonicalize (H12AffineFastState.compose env7760 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound7760 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7761 : List Nat := [2,4,8,16,27,11,18,30,512,20,2048,538,8192,10258,8200,8209,538,2075,15,8200,10249,27,11,25,8219,16,2048,538,539,2074,20,0,5,1,10258,512]

theorem envBound7761 : H12AffineFastState.Bounded env7761 := by
  intro p hp
  have h : env7761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7760_7761 : H12AffineEnvironment.transform 9 20 env7760 = env7761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env7760 == env7761) = true)

theorem identity7761 : scanCanonicalize (H12AffineFastState.compose env7761 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound7761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7762 : List Nat := [2,4,8,16,27,11,18,30,512,20,2048,538,520,2586,512,537,538,2075,15,512,2561,27,11,25,531,16,2048,538,539,2074,20,0,5,1,2586,512]

theorem envBound7762 : H12AffineFastState.Bounded env7762 := by
  intro p hp
  have h : env7762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7761_7762 : H12AffineEnvironment.transform 12 520 env7761 = env7762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env7761 == env7762) = true)

theorem identity7762 : scanCanonicalize (H12AffineFastState.compose env7762 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound7762 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7763 : List Nat := [2,4,8,16,27,11,18,30,27,20,2048,1,19,2049,27,2,1,2075,15,27,2074,27,11,25,8,16,2048,1,0,2074,20,0,5,1,2049,27]

theorem envBound7763 : H12AffineFastState.Bounded env7763 := by
  intro p hp
  have h : env7763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7762_7763 : H12AffineEnvironment.transform 8 27 env7762 = env7763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env7762 == env7763) = true)

def env7764 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74077,8224,67108864,67450414,67184143,67184475,67116880,67633429,67114533,525568,67114864,69206081,74282]

theorem envBound7764 : H12AffineFastState.Bounded env7764 := by
  intro p hp
  have h : env7764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7749_7764 : H12AffineEnvironment.transform 21 33 env7749 = env7764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7749 == env7764) = true)

theorem identity7764 : scanCanonicalize (H12AffineFastState.compose env7764 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound7764 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7765 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74077,8224,2712943,2904897,2638688,2638388,2718271,2188410,2716490,525568,2716191,615726,74282]

theorem envBound7765 : H12AffineFastState.Bounded env7765 := by
  intro p hp
  have h : env7765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7764_7765 : H12AffineEnvironment.transform 25 2712943 env7764 = env7765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env7764 == env7765) = true)

theorem identity7765 : scanCanonicalize (H12AffineFastState.compose env7765 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879966) := by decide +kernel

theorem selectedBound7765 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7766 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,879966,33,525637,74077,8224,264241,81439,339518,339818,268129,788772,269844,525568,270145,615726,74282]

theorem envBound7766 : H12AffineFastState.Bounded env7766 := by
  intro p hp
  have h : env7766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7765_7766 : H12AffineEnvironment.transform 20 879966 env7765 = env7766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879966 env7765 == env7766) = true)

theorem identity7766 : scanCanonicalize (H12AffineFastState.compose env7766 (packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78415) := by decide +kernel

theorem selectedBound7766 : packedSelected [0,4,5,8,9,10,13,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7767 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,78415,8541,286481,33,79626,74077,8224,264241,81439,339518,339818,268129,342891,269844,79695,270145,22369,74282]

theorem envBound7767 : H12AffineFastState.Bounded env7767 := by
  intro p hp
  have h : env7767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7766_7767 : H12AffineEnvironment.transform 18 78415 env7766 = env7767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78415 env7766 == env7767) = true)

theorem identity7767 : scanCanonicalize (H12AffineFastState.compose env7767 (packedSelected [2,3,4,6,7,8,12,13,18] rootPS)) = affineNative (2^(17+1) ^^^ 8001) := by decide +kernel

theorem selectedBound7767 : packedSelected [2,3,4,6,7,8,12,13,18] rootPS < 2^1333 := by decide +kernel

def env7768 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,8001,78415,8541,16464,33,79626,74077,8224,6000,81439,78207,77867,2080,74794,341,79695,0,22369,74282]

theorem envBound7768 : H12AffineFastState.Bounded env7768 := by
  intro p hp
  have h : env7768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7767_7768 : H12AffineEnvironment.transform 17 8001 env7767 = env7768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8001 env7767 == env7768) = true)

theorem identity7768 : scanCanonicalize (H12AffineFastState.compose env7768 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7768 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7769 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,7701,78415,8201,16464,33,79454,73737,8224,5668,81439,77867,77867,2080,74794,1,79387,0,22069,74282]

theorem envBound7769 : H12AffineFastState.Bounded env7769 := by
  intro p hp
  have h : env7769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7768_7769 : H12AffineEnvironment.transform 7 84 env7768 = env7769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7768 == env7769) = true)

theorem identity7769 : scanCanonicalize (H12AffineFastState.compose env7769 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 26159) := by decide +kernel

theorem selectedBound7769 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7770 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,26159,4097,7701,21600,8201,16464,33,20593,17958,8224,5668,22576,22020,22020,2080,16901,1,20532,0,22069,17413]

theorem envBound7770 : H12AffineFastState.Bounded env7770 := by
  intro p hp
  have h : env7770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7769_7770 : H12AffineEnvironment.transform 15 26159 env7769 = env7770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26159 env7769 == env7770) = true)

theorem identity7770 : scanCanonicalize (H12AffineFastState.compose env7770 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound7770 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7771 : List Nat := [2,4,8,16,32,64,41,84,512,1024,561,4096,8192,16384,8201,26159,4097,5156,21600,8201,16464,33,20593,17958,8224,5668,20993,22020,22020,529,16901,1,20532,0,22069,17413]

theorem envBound7771 : H12AffineFastState.Bounded env7771 := by
  intro p hp
  have h : env7771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7770_7771 : H12AffineEnvironment.transform 10 561 env7770 = env7771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env7770 == env7771) = true)

theorem identity7771 : scanCanonicalize (H12AffineFastState.compose env7771 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1662) := by decide +kernel

theorem selectedBound7771 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env7772 : List Nat := [2,4,8,16,32,64,41,84,512,1024,561,1662,8192,16384,8201,26159,1663,602,16926,8201,16464,33,17935,17958,8224,90,17535,16506,16506,529,16901,1,17994,0,16459,17413]

theorem envBound7772 : H12AffineFastState.Bounded env7772 := by
  intro p hp
  have h : env7772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7771_7772 : H12AffineEnvironment.transform 11 1662 env7771 = env7772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1662 env7771 == env7772) = true)

theorem identity7772 : scanCanonicalize (H12AffineFastState.compose env7772 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1652) := by decide +kernel

theorem selectedBound7772 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env7773 : List Nat := [2,4,8,16,32,64,41,84,512,1024,561,1662,8192,1652,8201,8283,1663,602,1130,8201,1572,33,123,82,8224,90,523,1550,1550,529,1137,1,62,0,1599,625]

theorem envBound7773 : H12AffineFastState.Bounded env7773 := by
  intro p hp
  have h : env7773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7772_7773 : H12AffineEnvironment.transform 13 1652 env7772 = env7773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1652 env7772 == env7773) = true)

def env7774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,74229,8329,67108864,71644686,67184295,67184474,71311217,67633597,67114533,525568,71309137,73400521,74283]

theorem envBound7774 : H12AffineFastState.Bounded env7774 := by
  intro p hp
  have h : env7774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7726_7774 : H12AffineEnvironment.transform 23 74229 env7726 = env7774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 74229 env7726 == env7774) = true)

def env7775 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,4194304,525636,74077,8225,67108864,71644686,67184143,67184474,71311217,67633429,67114533,525568,71309137,73400417,74283]

theorem envBound7775 : H12AffineFastState.Bounded env7775 := by
  intro p hp
  have h : env7775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7774_7775 : H12AffineEnvironment.transform 6 40 env7774 = env7775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7774 == env7775) = true)

def env7776 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,32,525636,74077,8225,67108864,67450414,67184143,67184474,67116881,67633429,67114533,525568,67114865,69206081,74283]

theorem envBound7776 : H12AffineFastState.Bounded env7776 := by
  intro p hp
  have h : env7776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7775_7776 : H12AffineEnvironment.transform 21 32 env7775 = env7776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7775 == env7776) = true)

theorem identity7776 : scanCanonicalize (H12AffineFastState.compose env7776 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619339) := by decide +kernel

theorem selectedBound7776 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7777 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,619339,32,525636,74077,8225,67108864,67450414,67184143,67184474,67116881,67633429,67114533,525568,67114865,67728138,74283]

theorem envBound7777 : H12AffineFastState.Bounded env7777 := by
  intro p hp
  have h : env7777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7776_7777 : H12AffineEnvironment.transform 20 619339 env7776 = env7777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619339 env7776 == env7777) = true)

theorem identity7777 : scanCanonicalize (H12AffineFastState.compose env7777 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound7777 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7778 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,8000,524288,8540,619339,32,525636,74077,8225,67108864,67185006,67184143,67184474,67116881,67633429,67114533,525568,67114865,67728138,74283]

theorem envBound7778 : H12AffineFastState.Bounded env7778 := by
  intro p hp
  have h : env7778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7777_7778 : H12AffineEnvironment.transform 17 8000 env7777 = env7778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env7777 == env7778) = true)

theorem identity7778 : scanCanonicalize (H12AffineFastState.compose env7778 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(18+1) ^^^ 78618) := by decide +kernel

theorem selectedBound7778 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7779 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,8000,78618,8540,16465,32,79454,74077,8225,67108864,67185006,67184143,67184474,67116881,67187215,67114533,79386,67114865,67125264,74283]

theorem envBound7779 : H12AffineFastState.Bounded env7779 := by
  intro p hp
  have h : env7779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7778_7779 : H12AffineEnvironment.transform 18 78618 env7778 = env7779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78618 env7778 == env7779) = true)

theorem identity7779 : scanCanonicalize (H12AffineFastState.compose env7779 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7779 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env7780 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,4096,7700,78414,8200,16465,32,79454,73737,8225,67108864,67184698,67184143,67184142,67116549,67187215,67114533,79386,67114533,67125264,74283]

theorem envBound7780 : H12AffineFastState.Bounded env7780 := by
  intro p hp
  have h : env7780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7779_7780 : H12AffineEnvironment.transform 7 84 env7779 = env7780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7779 == env7780) = true)

def env7781 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,33,525636,74077,8225,67108864,67450415,67184143,67184474,67116880,67633429,67114533,525568,67114864,69206080,74283]

theorem envBound7781 : H12AffineFastState.Bounded env7781 := by
  intro p hp
  have h : env7781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7775_7781 : H12AffineEnvironment.transform 21 33 env7775 = env7781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7775 == env7781) = true)

theorem identity7781 : scanCanonicalize (H12AffineFastState.compose env7781 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound7781 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7782 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,2097152,33,525636,74077,8225,2712943,2904896,2638688,2638389,2718271,2188410,2716490,525568,2716191,615727,74283]

theorem envBound7782 : H12AffineFastState.Bounded env7782 := by
  intro p hp
  have h : env7782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7781_7782 : H12AffineEnvironment.transform 25 2712943 env7781 = env7782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env7781 == env7782) = true)

theorem identity7782 : scanCanonicalize (H12AffineFastState.compose env7782 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 879967) := by decide +kernel

theorem selectedBound7782 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7783 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,4436,262144,524288,8540,879967,33,525636,74077,8225,264240,81439,339519,339818,268128,788773,269845,525568,270144,615727,74283]

theorem envBound7783 : H12AffineFastState.Bounded env7783 := by
  intro p hp
  have h : env7783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7782_7783 : H12AffineEnvironment.transform 20 879967 env7782 = env7783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879967 env7782 == env7783) = true)

def env7784 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,4194304,525637,74076,8224,67108864,71644686,67184142,67184474,71311217,67633428,67114533,525568,71309137,73400416,74283]

theorem envBound7784 : H12AffineFastState.Bounded env7784 := by
  intro p hp
  have h : env7784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7774_7784 : H12AffineEnvironment.transform 6 41 env7774 = env7784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7774 == env7784) = true)

def env7785 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,32,525637,74076,8224,67108864,67450414,67184142,67184474,67116881,67633428,67114533,525568,67114865,69206080,74283]

theorem envBound7785 : H12AffineFastState.Bounded env7785 := by
  intro p hp
  have h : env7785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7784_7785 : H12AffineEnvironment.transform 21 32 env7784 = env7785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7784 == env7785) = true)

theorem identity7785 : scanCanonicalize (H12AffineFastState.compose env7785 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(25+1) ^^^ 2712943) := by decide +kernel

theorem selectedBound7785 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7786 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,32,525637,74076,8224,2712943,2904897,2638689,2638389,2718270,2188411,2716490,525568,2716190,615727,74283]

theorem envBound7786 : H12AffineFastState.Bounded env7786 := by
  intro p hp
  have h : env7786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7785_7786 : H12AffineEnvironment.transform 25 2712943 env7785 = env7786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2712943 env7785 == env7786) = true)

theorem identity7786 : scanCanonicalize (H12AffineFastState.compose env7786 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 286277) := by decide +kernel

theorem selectedBound7786 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7787 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,286277,32,525637,74076,8224,867114,527620,793892,793712,861307,342590,863503,525568,863323,615727,74283]

theorem envBound7787 : H12AffineFastState.Bounded env7787 := by
  intro p hp
  have h : env7787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7786_7787 : H12AffineEnvironment.transform 20 286277 env7786 = env7787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286277 env7786 == env7787) = true)

theorem identity7787 : scanCanonicalize (H12AffineFastState.compose env7787 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7787 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7788 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,524288,8200,286277,32,525328,73737,8224,866943,527441,793713,793712,861307,342590,863322,525397,863323,615546,74283]

theorem envBound7788 : H12AffineFastState.Bounded env7788 := by
  intro p hp
  have h : env7788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7787_7788 : H12AffineEnvironment.transform 7 85 env7787 = env7788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7787 == env7788) = true)

theorem identity7788 : scanCanonicalize (H12AffineFastState.compose env7788 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(18+1) ^^^ 4708) := by decide +kernel

theorem selectedBound7788 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7789 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,4096,262144,4708,8200,286277,32,5748,73737,8224,337947,7733,265749,265748,341535,342590,343614,5681,343615,95774,74283]

theorem envBound7789 : H12AffineFastState.Bounded env7789 := by
  intro p hp
  have h : env7789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7788_7789 : H12AffineEnvironment.transform 18 4708 env7788 = env7789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4708 env7788 == env7789) = true)

theorem identity7789 : scanCanonicalize (H12AffineFastState.compose env7789 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7789 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7790 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,8235,4096,262144,4708,8200,286277,32,5748,34,8224,264240,7733,265749,265748,267828,268821,269845,5681,269844,22069,512]

theorem envBound7790 : H12AffineFastState.Bounded env7790 := by
  intro p hp
  have h : env7790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7789_7790 : H12AffineEnvironment.transform 15 8235 env7789 = env7790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7789 == env7790) = true)

theorem identity7790 : scanCanonicalize (H12AffineFastState.compose env7790 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 29273) := by decide +kernel

theorem selectedBound7790 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7791 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,8235,4096,29273,4708,8200,11292,32,5748,34,8224,31337,7733,31820,31821,25709,26700,27724,5681,27725,22069,512]

theorem envBound7791 : H12AffineFastState.Bounded env7791 := by
  intro p hp
  have h : env7791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7790_7791 : H12AffineEnvironment.transform 17 29273 env7790 = env7791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 29273 env7790 == env7791) = true)

theorem identity7791 : scanCanonicalize (H12AffineFastState.compose env7791 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7791 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7792 : List Nat := [2,4,8,16,32,49,41,36,512,1024,2048,4096,8192,16384,8200,8235,4096,29224,4629,8200,11292,32,5637,34,8224,31256,7733,31805,31804,25628,26685,27709,5681,27708,22069,512]

theorem envBound7792 : H12AffineFastState.Bounded env7792 := by
  intro p hp
  have h : env7792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7791_7792 : H12AffineEnvironment.transform 5 49 env7791 = env7792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7791 == env7792) = true)

theorem identity7792 : scanCanonicalize (H12AffineFastState.compose env7792 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound7792 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env7793 : List Nat := [2,4,8,16,32,49,41,36,512,1024,2048,1588,8192,16384,8200,8235,1588,25628,1057,8200,11292,32,49,34,8224,27692,2049,27145,27144,25628,26685,27709,5,27708,16385,512]

theorem envBound7793 : H12AffineFastState.Bounded env7793 := by
  intro p hp
  have h : env7793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7792_7793 : H12AffineEnvironment.transform 11 1588 env7792 = env7793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env7792 == env7793) = true)

theorem identity7793 : scanCanonicalize (H12AffineFastState.compose env7793 (packedSelected [2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound7793 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env7794 : List Nat := [2,4,8,16,27,10,18,31,512,1024,2048,1551,8192,16384,8200,8208,1551,25628,1050,8200,11292,27,10,25,8219,27671,2049,27145,27144,25628,26630,27654,5,27655,16385,512]

theorem envBound7794 : H12AffineFastState.Bounded env7794 := by
  intro p hp
  have h : env7794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7793_7794 : H12AffineEnvironment.transform 4 27 env7793 = env7794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env7793 == env7794) = true)

theorem identity7794 : scanCanonicalize (H12AffineFastState.compose env7794 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 11270) := by decide +kernel

theorem selectedBound7794 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env7795 : List Nat := [2,4,8,16,27,10,18,31,512,1024,2048,1551,8192,11270,8200,8208,1551,2074,1050,8200,11292,27,10,25,8219,17,2049,1551,1550,2074,1024,0,5,1,11271,512]

theorem envBound7795 : H12AffineFastState.Bounded env7795 := by
  intro p hp
  have h : env7795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7794_7795 : H12AffineEnvironment.transform 13 11270 env7794 = env7795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11270 env7794 == env7795) = true)

theorem identity7795 : scanCanonicalize (H12AffineFastState.compose env7795 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2072) := by decide +kernel

theorem selectedBound7795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7796 : List Nat := [2,4,8,16,27,10,18,31,512,1024,2048,1551,2072,1054,2064,2056,1551,2074,1050,2064,1028,27,10,25,2051,17,2049,1551,1550,2074,1024,0,5,1,1055,512]

theorem envBound7796 : H12AffineFastState.Bounded env7796 := by
  intro p hp
  have h : env7796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7795_7796 : H12AffineEnvironment.transform 12 2072 env7795 = env7796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2072 env7795 == env7796) = true)

theorem identity7796 : scanCanonicalize (H12AffineFastState.compose env7796 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound7796 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7797 : List Nat := [2,4,8,16,27,10,18,31,27,1024,2048,1044,2072,1054,2064,2056,1044,2074,1050,2064,1028,27,10,25,2051,17,2049,1044,1045,2074,1024,0,5,1,1055,27]

theorem envBound7797 : H12AffineFastState.Bounded env7797 := by
  intro p hp
  have h : env7797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7796_7797 : H12AffineEnvironment.transform 8 27 env7796 = env7797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env7796 == env7797) = true)

def env7798 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,2097152,33,525637,74076,8224,67108864,67450415,67184142,67184474,67116880,67633428,67114533,525568,67114864,69206081,74283]

theorem envBound7798 : H12AffineFastState.Bounded env7798 := by
  intro p hp
  have h : env7798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7784_7798 : H12AffineEnvironment.transform 21 33 env7784 = env7798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7784 == env7798) = true)

theorem identity7798 : scanCanonicalize (H12AffineFastState.compose env7798 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 619339) := by decide +kernel

theorem selectedBound7798 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env7799 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,524288,8541,619339,33,525637,74076,8224,67108864,67450415,67184142,67184474,67116880,67633428,67114533,525568,67114864,67728138,74283]

theorem envBound7799 : H12AffineFastState.Bounded env7799 := by
  intro p hp
  have h : env7799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7798_7799 : H12AffineEnvironment.transform 20 619339 env7798 = env7799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619339 env7798 == env7799) = true)

theorem identity7799 : scanCanonicalize (H12AffineFastState.compose env7799 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(18+1) ^^^ 339034) := by decide +kernel

theorem selectedBound7799 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7800 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,262144,339034,8541,286481,33,338207,74076,8224,67108864,67450415,67184142,67184474,67116880,67448142,67114533,338266,67114864,67395408,74283]

theorem envBound7800 : H12AffineFastState.Bounded env7800 := by
  intro p hp
  have h : env7800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7799_7800 : H12AffineEnvironment.transform 18 339034 env7799 = env7800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339034 env7799 == env7800) = true)

theorem identity7800 : scanCanonicalize (H12AffineFastState.compose env7800 (packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 7701) := by decide +kernel

theorem selectedBound7800 : packedSelected [0,1,3,4,9,13,17,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7801 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,4437,7701,78415,8541,16644,33,79626,74076,8224,67108864,67184698,67184142,67184474,67116880,67187547,67114533,79695,67114864,67125573,74283]

theorem envBound7801 : H12AffineFastState.Bounded env7801 := by
  intro p hp
  have h : env7801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7800_7801 : H12AffineEnvironment.transform 17 7701 env7800 = env7801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7701 env7800 == env7801) = true)

theorem identity7801 : scanCanonicalize (H12AffineFastState.compose env7801 (packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7801 : packedSelected [2,3,5,6,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7802 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,7701,78415,8201,16464,33,79454,73736,8224,67108864,67184698,67184142,67184142,67116548,67187215,67114533,79387,67114532,67125265,74283]

theorem envBound7802 : H12AffineFastState.Bounded env7802 := by
  intro p hp
  have h : env7802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7801_7802 : H12AffineEnvironment.transform 7 84 env7801 = env7802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7801 == env7802) = true)

theorem identity7802 : scanCanonicalize (H12AffineFastState.compose env7802 (packedSelected [2,3,4,6,7,8,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound7802 : packedSelected [2,3,4,6,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env7803 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,8282,4097,7701,4629,8201,16464,33,5636,82,8224,67108864,67111008,67110484,67110484,67116548,67113557,67114533,5697,67114532,67125265,625]

theorem envBound7803 : H12AffineFastState.Bounded env7803 := by
  intro p hp
  have h : env7803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7802_7803 : H12AffineEnvironment.transform 15 8282 env7802 = env7803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env7802 == env7803) = true)

theorem identity7803 : scanCanonicalize (H12AffineFastState.compose env7803 (packedSelected [13,17] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound7803 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7804 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,16384,8201,8234,4097,7701,4629,8201,16416,33,5636,34,8224,67108864,67110928,67110436,67110436,67116548,67113509,67114533,5681,67114532,67125265,513]

theorem envBound7804 : H12AffineFastState.Bounded env7804 := by
  intro p hp
  have h : env7804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7803_7804 : H12AffineEnvironment.transform 5 48 env7803 = env7804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7803 == env7804) = true)

theorem identity7804 : scanCanonicalize (H12AffineFastState.compose env7804 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 14856) := by decide +kernel

theorem selectedBound7804 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7805 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,14856,8201,8234,4097,7701,4629,8201,14888,33,5636,34,8224,67108864,67110928,67110436,67110436,67116548,67113509,67114533,5681,67114532,67123737,513]

theorem envBound7805 : H12AffineFastState.Bounded env7805 := by
  intro p hp
  have h : env7805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7804_7805 : H12AffineEnvironment.transform 13 14856 env7804 = env7805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14856 env7804 == env7805) = true)

theorem identity7805 : scanCanonicalize (H12AffineFastState.compose env7805 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(25+1) ^^^ 5669) := by decide +kernel

theorem selectedBound7805 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7806 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,8192,14856,8201,8234,4097,7701,4629,8201,14888,33,5636,34,8224,5669,7733,4097,4097,2081,1024,0,5681,1,11324,513]

theorem envBound7806 : H12AffineFastState.Bounded env7806 := by
  intro p hp
  have h : env7806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7805_7806 : H12AffineEnvironment.transform 25 5669 env7805 = env7806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5669 env7805 == env7806) = true)

theorem identity7806 : scanCanonicalize (H12AffineFastState.compose env7806 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 7191) := by decide +kernel

theorem selectedBound7806 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7807 : List Nat := [2,4,8,16,32,48,41,36,512,1024,2048,4096,7191,1567,7198,7229,4097,7701,4629,7198,1599,33,5636,34,7223,5669,7733,4097,4097,2081,1024,0,5681,1,4139,513]

theorem envBound7807 : H12AffineFastState.Bounded env7807 := by
  intro p hp
  have h : env7807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7806_7807 : H12AffineEnvironment.transform 12 7191 env7806 = env7807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7191 env7806 == env7807) = true)

theorem identity7807 : scanCanonicalize (H12AffineFastState.compose env7807 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound7807 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env7808 : List Nat := [2,4,8,11,32,43,41,36,512,1024,2048,4096,7180,1540,7173,7206,4097,7694,4622,7173,1572,33,5636,34,7212,5669,7726,4097,4097,2081,1024,0,5674,1,4139,513]

theorem envBound7808 : H12AffineFastState.Bounded env7808 := by
  intro p hp
  have h : env7808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7807_7808 : H12AffineEnvironment.transform 3 11 env7807 = env7808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env7807 == env7808) = true)

theorem identity7808 : scanCanonicalize (H12AffineFastState.compose env7808 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound7808 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7809 : List Nat := [2,4,8,11,32,43,41,36,512,1024,2048,1550,2562,1540,2571,2600,1551,2048,1024,2571,1572,33,10,34,2594,43,2080,1551,1551,2081,1024,0,36,1,1573,513]

theorem envBound7809 : H12AffineFastState.Bounded env7809 := by
  intro p hp
  have h : env7809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7808_7809 : H12AffineEnvironment.transform 11 1550 env7808 = env7809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env7808 == env7809) = true)

theorem identity7809 : scanCanonicalize (H12AffineFastState.compose env7809 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound7809 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7810 : List Nat := [2,4,8,11,0,11,9,4,512,1024,2048,1550,2562,1540,2571,2568,1551,2048,1024,2571,1540,1,10,2,2562,11,2048,1551,1551,2049,1024,0,4,1,1541,513]

theorem envBound7810 : H12AffineFastState.Bounded env7810 := by
  intro p hp
  have h : env7810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7809_7810 : H12AffineEnvironment.transform 4 0 env7809 = env7810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env7809 == env7810) = true)

theorem identity7810 : scanCanonicalize (H12AffineFastState.compose env7810 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 513) := by decide +kernel

theorem selectedBound7810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7811 : List Nat := [2,4,8,11,0,11,9,4,512,513,2048,15,2562,5,2571,2568,14,2048,513,2571,5,1,10,2,2562,11,2048,14,14,2049,513,0,4,1,4,513]

theorem envBound7811 : H12AffineFastState.Bounded env7811 := by
  intro p hp
  have h : env7811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7810_7811 : H12AffineEnvironment.transform 9 513 env7810 = env7811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 513 env7810 == env7811) = true)

theorem identity7811 : scanCanonicalize (H12AffineFastState.compose env7811 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound7811 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7812 : List Nat := [2,4,8,11,0,11,9,4,512,513,523,15,9,5,0,3,14,523,513,0,5,1,10,2,9,11,523,14,14,522,513,0,4,1,4,513]

theorem envBound7812 : H12AffineFastState.Bounded env7812 := by
  intro p hp
  have h : env7812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7811_7812 : H12AffineEnvironment.transform 10 523 env7811 = env7812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env7811 == env7812) = true)

def env7813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,134217728,268435456,268435965,151259274,84484169,155451871,525568,151257258,73400520,16778207]

theorem envBound7813 : H12AffineFastState.Bounded env7813 := by
  intro p hp
  have h : env7813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7633_7813 : H12AffineEnvironment.transform 14 8693 env7633 = env7813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env7633 == env7813) = true)

def env7814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,134217728,138678440,138678613,151259274,84484169,155451871,525568,151257258,73400520,16778207]

theorem envBound7814 : H12AffineFastState.Bounded env7814 := by
  intro p hp
  have h : env7814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7813_7814 : H12AffineEnvironment.transform 27 138678440 env7813 = env7814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env7813 == env7814) = true)

theorem identity7814 : scanCanonicalize (H12AffineFastState.compose env7814 (packedSelected [9,14,22] rootPS)) = affineNative (2^(26+1) ^^^ 71571416) := by decide +kernel

theorem selectedBound7814 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env7815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,71571416,67110768,67110541,88088402,84484169,83891719,525568,88086386,73400520,16778207]

theorem envBound7815 : H12AffineFastState.Bounded env7815 := by
  intro p hp
  have h : env7815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7814_7815 : H12AffineEnvironment.transform 26 71571416 env7814 = env7815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 71571416 env7814 == env7815) = true)

def env7816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,17375308,21837716,17377084,17376961,4800286,5,603723,525568,4798270,23666820,16778207]

theorem envBound7816 : H12AffineFastState.Bounded env7816 := by
  intro p hp
  have h : env7816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7815_7816 : H12AffineEnvironment.transform 25 17375308 env7815 = env7816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17375308 env7815 == env7816) = true)

def env7817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,4194304,5748,16777216,8329,16856020,21308428,16856228,16856409,4271238,5,75219,5784,4269222,23147292,16778207]

theorem envBound7817 : H12AffineFastState.Bounded env7817 := by
  intro p hp
  have h : env7817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7816_7817 : H12AffineEnvironment.transform 18 5016 env7816 = env7817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env7816 == env7817) = true)

def env7818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,32,5748,16777216,8329,16856020,17114156,16856228,16856409,76966,5,75219,5784,74886,18953020,16778207]

theorem envBound7818 : H12AffineFastState.Bounded env7818 := by
  intro p hp
  have h : env7818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7817_7818 : H12AffineEnvironment.transform 21 32 env7817 = env7818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7817 == env7818) = true)

theorem identity7818 : scanCanonicalize (H12AffineFastState.compose env7818 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360251) := by decide +kernel

theorem selectedBound7818 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,360251,32,5748,16777216,8329,16856020,17114156,16856228,16856409,76966,5,75219,5784,74886,17058823,16778207]

theorem envBound7819 : H12AffineFastState.Bounded env7819 := by
  intro p hp
  have h : env7819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7818_7819 : H12AffineEnvironment.transform 20 360251 env7818 = env7819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360251 env7818 == env7819) = true)

def env7820 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4812,8353,360047,32,5748,16777216,8329,16855680,17114156,16856228,16856077,76966,5,74887,5784,74886,17058823,16777867]

theorem envBound7820 : H12AffineFastState.Bounded env7820 := by
  intro p hp
  have h : env7820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7819_7820 : H12AffineEnvironment.transform 7 84 env7819 = env7820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7819 == env7820) = true)

theorem identity7820 : scanCanonicalize (H12AffineFastState.compose env7820 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7820 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7821 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,262144,4812,8353,286276,32,5748,16777216,8329,16781995,17040391,16782479,16782374,3213,5,1196,5784,1197,17058823,16777867]

theorem envBound7821 : H12AffineFastState.Bounded env7821 := by
  intro p hp
  have h : env7821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7820_7821 : H12AffineEnvironment.transform 15 8235 env7820 = env7821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7820 == env7821) = true)

theorem identity7821 : scanCanonicalize (H12AffineFastState.compose env7821 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound7821 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7822 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,262144,4812,8353,286276,32,5748,34,8329,4745,263205,5293,5124,3213,5,1196,5784,1197,281637,681]

theorem envBound7822 : H12AffineFastState.Bounded env7822 := by
  intro p hp
  have h : env7822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7821_7822 : H12AffineEnvironment.transform 23 34 env7821 = env7822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env7821 == env7822) = true)

theorem identity7822 : scanCanonicalize (H12AffineFastState.compose env7822 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6753) := by decide +kernel

theorem selectedBound7822 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7823 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,6753,4812,8353,17445,32,5748,34,8329,4745,7748,5293,5124,3213,5,1196,5784,1197,22084,681]

theorem envBound7823 : H12AffineFastState.Bounded env7823 := by
  intro p hp
  have h : env7823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7822_7823 : H12AffineEnvironment.transform 17 6753 env7822 = env7823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6753 env7822 == env7823) = true)

theorem identity7823 : scanCanonicalize (H12AffineFastState.compose env7823 (packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound7823 : packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env7824 : List Nat := [2,4,8,16,32,64,128,84,512,221,2048,4096,8192,16384,8353,8235,4264,6753,4812,8353,16632,32,4777,34,8329,4745,6809,4208,4313,2128,5,113,4677,112,21145,681]

theorem envBound7824 : H12AffineFastState.Bounded env7824 := by
  intro p hp
  have h : env7824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7823_7824 : H12AffineEnvironment.transform 9 221 env7823 = env7824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env7823 == env7824) = true)

theorem identity7824 : scanCanonicalize (H12AffineFastState.compose env7824 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7824 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7825 : List Nat := [2,4,8,16,32,49,128,37,512,172,2048,4096,8192,16384,8353,8235,4264,6672,4797,8353,16521,32,4777,34,8329,4745,6809,4097,4264,2081,5,0,4660,1,21145,681]

theorem envBound7825 : H12AffineFastState.Bounded env7825 := by
  intro p hp
  have h : env7825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7824_7825 : H12AffineEnvironment.transform 5 49 env7824 = env7825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7824 == env7825) = true)

theorem identity7825 : scanCanonicalize (H12AffineFastState.compose env7825 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7825 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env7826 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,4096,8192,16384,8347,8209,4242,6672,4743,8347,16521,26,4755,24,8329,4745,6809,4097,4242,2075,5,0,4622,1,21145,659]

theorem envBound7826 : H12AffineFastState.Bounded env7826 := by
  intro p hp
  have h : env7826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7825_7826 : H12AffineEnvironment.transform 4 26 env7825 = env7826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7825 == env7826) = true)

theorem identity7826 : scanCanonicalize (H12AffineFastState.compose env7826 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound7826 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env7827 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,4096,8192,512,8347,8209,4242,6672,4743,8347,649,26,4755,24,8329,4745,6809,4097,4242,2075,5,0,4622,1,4249,659]

theorem envBound7827 : H12AffineFastState.Bounded env7827 := by
  intro p hp
  have h : env7827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7826_7827 : H12AffineEnvironment.transform 13 512 env7826 = env7827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env7826 == env7827) = true)

theorem identity7827 : scanCanonicalize (H12AffineFastState.compose env7827 (packedSelected [2,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound7827 : packedSelected [2,11,14,23] rootPS < 2^1333 := by decide +kernel

def env7828 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,664,8192,512,8347,8209,522,2184,31,8347,649,26,11,24,8329,17,2049,665,522,2075,5,0,150,1,513,659]

theorem envBound7828 : H12AffineFastState.Bounded env7828 := by
  intro p hp
  have h : env7828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7827_7828 : H12AffineEnvironment.transform 11 664 env7827 = env7828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env7827 == env7828) = true)

theorem identity7828 : scanCanonicalize (H12AffineFastState.compose env7828 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound7828 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env7829 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,664,154,512,1,139,522,2184,31,1,649,26,11,24,19,17,2049,665,522,2075,5,0,150,1,513,659]

theorem envBound7829 : H12AffineFastState.Bounded env7829 := by
  intro p hp
  have h : env7829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7828_7829 : H12AffineEnvironment.transform 12 154 env7828 = env7829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env7828 == env7829) = true)

theorem identity7829 : scanCanonicalize (H12AffineFastState.compose env7829 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound7829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7830 : List Nat := [2,4,8,16,26,11,128,31,512,150,665,664,154,512,1,139,522,529,31,1,649,26,11,24,19,17,664,665,522,642,5,0,150,1,513,659]

theorem envBound7830 : H12AffineFastState.Bounded env7830 := by
  intro p hp
  have h : env7830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7829_7830 : H12AffineEnvironment.transform 10 665 env7829 = env7830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env7829 == env7830) = true)

theorem identity7830 : scanCanonicalize (H12AffineFastState.compose env7830 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7830 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env7831 : List Nat := [2,4,8,16,26,11,19,31,512,5,522,523,9,512,1,24,522,529,31,1,538,26,11,24,19,17,523,522,522,529,5,0,5,1,513,512]

theorem envBound7831 : H12AffineFastState.Bounded env7831 := by
  intro p hp
  have h : env7831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7830_7831 : H12AffineEnvironment.transform 6 19 env7830 = env7831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7830 == env7831) = true)

theorem identity7831 : scanCanonicalize (H12AffineFastState.compose env7831 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7832 : List Nat := [2,4,8,16,26,11,19,31,26,5,16,17,9,26,1,24,16,11,31,1,0,26,11,24,19,17,17,16,16,11,5,0,5,1,27,26]

theorem envBound7832 : H12AffineFastState.Bounded env7832 := by
  intro p hp
  have h : env7832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7831_7832 : H12AffineEnvironment.transform 8 26 env7831 = env7832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7831 == env7832) = true)

def leafEnv7832 : List Nat := [2,4,8,16,26,11,19,31,26,5,16,17,9,26,1,24,16,11,31,1,0,26,11,24,31,19,1,17,17,16,16,11,5,0,5,1,30,3,27,26,1,0,0]

def active7832 : List Nat := [0,1,2,3]

def tree7832 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7832 : H12WitnessSearch.Good tree7832 := H12GlobalWitnessIndex.good

theorem leafIdentity7832 : H12AffineFastState.composeSystem env7832 rootObs = leafEnv7832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7832 rootObs == leafEnv7832) = true)

theorem terminalChecked7832 : H12PackedTerminal.terminalCheckFast leafEnv7832 active7832 tree7832 = true := by decide +kernel

def env7833 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4813,8352,360046,32,5748,16777216,8329,16855681,17114156,16856228,16856076,76966,5,74886,5784,74886,17058823,16777866]

theorem envBound7833 : H12AffineFastState.Bounded env7833 := by
  intro p hp
  have h : env7833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7819_7833 : H12AffineEnvironment.transform 7 85 env7819 = env7833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7819 == env7833) = true)

theorem identity7833 : scanCanonicalize (H12AffineFastState.compose env7833 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7833 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7834 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,32,5748,16777216,8225,16855593,17114156,16856076,16856076,76814,5,74798,5680,74798,17058823,16777762]

theorem envBound7834 : H12AffineFastState.Bounded env7834 := by
  intro p hp
  have h : env7834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7833_7834 : H12AffineEnvironment.transform 6 40 env7833 = env7834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7833 == env7834) = true)

theorem identity7834 : scanCanonicalize (H12AffineFastState.compose env7834 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(23+1) ^^^ 73736) := by decide +kernel

theorem selectedBound7834 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7835 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,32,5748,73736,8225,4641,263204,5124,5124,76814,5,74798,5680,74798,355343,74282]

theorem envBound7835 : H12AffineFastState.Bounded env7835 := by
  intro p hp
  have h : env7835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7834_7835 : H12AffineEnvironment.transform 23 73736 env7834 = env7835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73736 env7834 == env7835) = true)

theorem identity7835 : scanCanonicalize (H12AffineFastState.compose env7835 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7835 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7836 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8234,4097,262144,4709,8200,286276,32,5748,34,8225,4641,263204,5124,5124,3108,5,1028,5680,1028,281637,512]

theorem envBound7836 : H12AffineFastState.Bounded env7836 := by
  intro p hp
  have h : env7836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7835_7836 : H12AffineEnvironment.transform 15 8234 env7835 = env7836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7835 == env7836) = true)

theorem identity7836 : scanCanonicalize (H12AffineFastState.compose env7836 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 7781) := by decide +kernel

theorem selectedBound7836 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7837 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,7781,8200,8234,4097,262144,4709,8200,262177,32,5748,34,8225,4641,263204,5124,5124,3108,5,1028,5680,1028,266816,512]

theorem envBound7837 : H12AffineFastState.Bounded env7837 := by
  intro p hp
  have h : env7837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7836_7837 : H12AffineEnvironment.transform 13 7781 env7836 = env7837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7781 env7836 == env7837) = true)

theorem identity7837 : scanCanonicalize (H12AffineFastState.compose env7837 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7837 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7838 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,6753,8200,8234,4097,262144,4709,8200,262177,32,4720,34,8225,4641,262176,4096,4096,2080,5,0,4660,0,266816,512]

theorem envBound7838 : H12AffineFastState.Bounded env7838 := by
  intro p hp
  have h : env7838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7837_7838 : H12AffineEnvironment.transform 9 4 env7837 = env7838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7837 == env7838) = true)

theorem identity7838 : scanCanonicalize (H12AffineFastState.compose env7838 (packedSelected [0,4] rootPS)) = affineNative (2^(17+1) ^^^ 6779) := by decide +kernel

theorem selectedBound7838 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7839 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,6753,8200,8234,4097,6779,4709,8200,6746,32,4720,34,8225,4641,6747,4096,4096,2080,5,0,4660,0,2107,512]

theorem envBound7839 : H12AffineFastState.Bounded env7839 := by
  intro p hp
  have h : env7839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7838_7839 : H12AffineEnvironment.transform 17 6779 env7838 = env7839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6779 env7838 == env7839) = true)

theorem identity7839 : scanCanonicalize (H12AffineFastState.compose env7839 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound7839 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env7840 : List Nat := [2,4,8,16,32,43,40,62,512,4,2048,4096,8192,6666,8200,8234,4097,6672,4622,8200,6705,32,4635,34,8225,4641,6704,4096,4096,2080,5,0,4660,0,2107,512]

theorem envBound7840 : H12AffineFastState.Bounded env7840 := by
  intro p hp
  have h : env7840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7839_7840 : H12AffineEnvironment.transform 5 43 env7839 = env7840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env7839 == env7840) = true)

def env7841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,33,5748,16777216,8329,16856020,17114157,16856228,16856409,76967,5,75219,5784,74887,18953021,16778207]

theorem envBound7841 : H12AffineFastState.Bounded env7841 := by
  intro p hp
  have h : env7841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7817_7841 : H12AffineEnvironment.transform 21 33 env7817 = env7841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7817 == env7841) = true)

theorem identity7841 : scanCanonicalize (H12AffineFastState.compose env7841 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360046) := by decide +kernel

theorem selectedBound7841 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,360046,33,5748,16777216,8329,16856020,17114157,16856228,16856409,76967,5,75219,5784,74887,17059155,16778207]

theorem envBound7842 : H12AffineFastState.Bounded env7842 := by
  intro p hp
  have h : env7842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7841_7842 : H12AffineEnvironment.transform 20 360046 env7841 = env7842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360046 env7841 == env7842) = true)

def env7843 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4812,8353,360046,33,5748,16777216,8329,16855680,17114157,16856228,16856077,76967,5,74887,5784,74887,17058823,16777867]

theorem envBound7843 : H12AffineFastState.Bounded env7843 := by
  intro p hp
  have h : env7843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7842_7843 : H12AffineEnvironment.transform 7 84 env7842 = env7843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7842 == env7843) = true)

theorem identity7843 : scanCanonicalize (H12AffineFastState.compose env7843 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7843 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7844 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,33,5748,16777216,8224,16855593,17114157,16856077,16856077,76814,5,74798,5681,74798,17058823,16777762]

theorem envBound7844 : H12AffineFastState.Bounded env7844 := by
  intro p hp
  have h : env7844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7843_7844 : H12AffineEnvironment.transform 6 41 env7843 = env7844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7843 == env7844) = true)

theorem identity7844 : scanCanonicalize (H12AffineFastState.compose env7844 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(23+1) ^^^ 73737) := by decide +kernel

theorem selectedBound7844 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7845 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,33,5748,73737,8224,4640,263204,5124,5124,76814,5,74798,5681,74798,355342,74283]

theorem envBound7845 : H12AffineFastState.Bounded env7845 := by
  intro p hp
  have h : env7845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7844_7845 : H12AffineEnvironment.transform 23 73737 env7844 = env7845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73737 env7844 == env7845) = true)

theorem identity7845 : scanCanonicalize (H12AffineFastState.compose env7845 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7845 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7846 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,262144,4709,8200,286277,33,5748,34,8224,4640,263204,5124,5124,3109,5,1029,5681,1029,281637,512]

theorem envBound7846 : H12AffineFastState.Bounded env7846 := by
  intro p hp
  have h : env7846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7845_7846 : H12AffineEnvironment.transform 15 8235 env7845 = env7846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7845 == env7846) = true)

theorem identity7846 : scanCanonicalize (H12AffineFastState.compose env7846 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 24649) := by decide +kernel

theorem selectedBound7846 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7847 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,24649,4709,8200,15884,33,5748,34,8224,4640,25709,5124,5124,3109,5,1029,5681,1029,11372,512]

theorem envBound7847 : H12AffineFastState.Bounded env7847 := by
  intro p hp
  have h : env7847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7846_7847 : H12AffineEnvironment.transform 17 24649 env7846 = env7847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24649 env7846 == env7847) = true)

theorem identity7847 : scanCanonicalize (H12AffineFastState.compose env7847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 14937) := by decide +kernel

theorem selectedBound7847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7848 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,14937,8200,8235,4097,6672,4709,8200,15884,33,5748,34,8224,4640,7732,5124,5124,3109,5,1029,5681,1029,11372,512]

theorem envBound7848 : H12AffineFastState.Bounded env7848 := by
  intro p hp
  have h : env7848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7847_7848 : H12AffineEnvironment.transform 13 14937 env7847 = env7848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14937 env7847 == env7848) = true)

theorem identity7848 : scanCanonicalize (H12AffineFastState.compose env7848 (packedSelected [3,5,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound7848 : packedSelected [3,5,11,13] rootPS < 2^1333 := by decide +kernel

def env7849 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1588,8192,11373,8200,8235,1589,3108,1105,8200,10296,33,64,34,8224,1044,2048,560,560,3109,5,1029,5,1029,11372,512]

theorem envBound7849 : H12AffineFastState.Bounded env7849 := by
  intro p hp
  have h : env7849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7848_7849 : H12AffineEnvironment.transform 11 1588 env7848 = env7849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env7848 == env7849) = true)

theorem identity7849 : scanCanonicalize (H12AffineFastState.compose env7849 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 3165) := by decide +kernel

theorem selectedBound7849 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env7850 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1588,3165,48,3157,3190,1589,3108,1105,3157,1125,33,64,34,3197,1044,2048,560,560,3109,5,1029,5,1029,49,512]

theorem envBound7850 : H12AffineFastState.Bounded env7850 := by
  intro p hp
  have h : env7850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7849_7850 : H12AffineEnvironment.transform 12 3165 env7849 = env7850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3165 env7849 == env7850) = true)

theorem identity7850 : scanCanonicalize (H12AffineFastState.compose env7850 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound7850 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env7851 : List Nat := [2,4,8,16,32,64,41,84,512,127,2048,587,2082,48,2090,2057,586,2139,46,2090,26,33,64,34,2050,107,2048,560,560,2138,5,122,5,122,49,512]

theorem envBound7851 : H12AffineFastState.Bounded env7851 := by
  intro p hp
  have h : env7851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7850_7851 : H12AffineEnvironment.transform 9 127 env7850 = env7851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env7850 == env7851) = true)

theorem identity7851 : scanCanonicalize (H12AffineFastState.compose env7851 (packedSelected [0,14] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound7851 : packedSelected [0,14] rootPS < 2^1333 := by decide +kernel

def env7852 : List Nat := [2,4,8,16,32,58,41,46,512,5,2048,561,2082,48,2090,2057,560,2081,46,2090,26,33,58,34,2050,17,2048,560,560,2080,5,0,5,0,49,512]

theorem envBound7852 : H12AffineFastState.Bounded env7852 := by
  intro p hp
  have h : env7852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7851_7852 : H12AffineEnvironment.transform 5 58 env7851 = env7852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env7851 == env7852) = true)

def env7853 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4813,8352,360046,33,5748,16777216,8329,16855681,17114157,16856228,16856076,76967,5,74886,5784,74887,17058822,16777866]

theorem envBound7853 : H12AffineFastState.Bounded env7853 := by
  intro p hp
  have h : env7853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7842_7853 : H12AffineEnvironment.transform 7 85 env7842 = env7853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7842 == env7853) = true)

theorem identity7853 : scanCanonicalize (H12AffineFastState.compose env7853 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7853 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7854 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,262144,4813,8352,286276,33,5748,16777216,8329,16781995,17040391,16782478,16782374,3213,5,1196,5784,1197,17058822,16777866]

theorem envBound7854 : H12AffineFastState.Bounded env7854 := by
  intro p hp
  have h : env7854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7853_7854 : H12AffineEnvironment.transform 15 8234 env7853 = env7854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7853 == env7854) = true)

theorem identity7854 : scanCanonicalize (H12AffineFastState.compose env7854 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound7854 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7855 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,262144,4813,8352,286276,33,5748,34,8329,4745,263205,5292,5124,3213,5,1196,5784,1197,281636,680]

theorem envBound7855 : H12AffineFastState.Bounded env7855 := by
  intro p hp
  have h : env7855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7854_7855 : H12AffineEnvironment.transform 23 34 env7854 = env7855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env7854 == env7855) = true)

theorem identity7855 : scanCanonicalize (H12AffineFastState.compose env7855 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 7780) := by decide +kernel

theorem selectedBound7855 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7856 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,7780,4813,8352,16416,33,5748,34,8329,4745,6721,5292,5124,3213,5,1196,5784,1197,21056,680]

theorem envBound7856 : H12AffineFastState.Bounded env7856 := by
  intro p hp
  have h : env7856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7855_7856 : H12AffineEnvironment.transform 17 7780 env7855 = env7856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7780 env7855 == env7856) = true)

theorem identity7856 : scanCanonicalize (H12AffineFastState.compose env7856 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7856 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env7857 : List Nat := [2,4,8,16,32,64,128,85,512,4,2048,4096,8192,16384,8352,8234,4265,6752,4813,8352,16416,33,4720,34,8329,4745,6721,4264,4096,2185,5,168,4764,169,21056,680]

theorem envBound7857 : H12AffineFastState.Bounded env7857 := by
  intro p hp
  have h : env7857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7856_7857 : H12AffineEnvironment.transform 9 4 env7856 = env7857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7856 == env7857) = true)

theorem identity7857 : scanCanonicalize (H12AffineFastState.compose env7857 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2275) := by decide +kernel

theorem selectedBound7857 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env7858 : List Nat := [2,4,8,16,32,64,128,85,512,4,2048,4096,8192,2275,8352,8234,4265,6752,4813,8352,2243,33,4720,34,8329,4745,6721,4264,4096,2185,5,168,4764,169,6819,680]

theorem envBound7858 : H12AffineFastState.Bounded env7858 := by
  intro p hp
  have h : env7858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7857_7858 : H12AffineEnvironment.transform 13 2275 env7857 = env7858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2275 env7857 == env7858) = true)

theorem identity7858 : scanCanonicalize (H12AffineFastState.compose env7858 (packedSelected [3,5,6,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound7858 : packedSelected [3,5,6,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env7859 : List Nat := [2,4,8,16,32,64,128,85,512,4,2048,577,8192,2275,8352,8234,744,2081,140,8352,2243,33,49,34,8329,200,2048,745,577,2185,5,168,221,169,2274,680]

theorem envBound7859 : H12AffineFastState.Bounded env7859 := by
  intro p hp
  have h : env7859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7858_7859 : H12AffineEnvironment.transform 11 577 env7858 = env7859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env7858 == env7859) = true)

theorem identity7859 : scanCanonicalize (H12AffineFastState.compose env7859 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7859 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env7860 : List Nat := [2,4,8,16,32,64,41,85,512,4,2048,577,8192,2122,8201,8234,577,2081,37,8201,2154,33,49,34,8224,97,2048,576,577,2080,5,1,116,0,2123,513]

theorem envBound7860 : H12AffineFastState.Bounded env7860 := by
  intro p hp
  have h : env7860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7859_7860 : H12AffineEnvironment.transform 6 41 env7859 = env7860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7859 == env7860) = true)

theorem identity7860 : scanCanonicalize (H12AffineFastState.compose env7860 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 547) := by decide +kernel

theorem selectedBound7860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7861 : List Nat := [2,4,8,16,32,64,41,85,512,4,2048,577,547,2122,554,521,577,2081,37,554,2154,33,49,34,515,97,2048,576,577,2080,5,1,116,0,2123,513]

theorem envBound7861 : H12AffineFastState.Bounded env7861 := by
  intro p hp
  have h : env7861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7860_7861 : H12AffineEnvironment.transform 12 547 env7860 = env7861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 547 env7860 == env7861) = true)

theorem identity7861 : scanCanonicalize (H12AffineFastState.compose env7861 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound7861 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7862 : List Nat := [2,4,8,16,32,64,41,85,32,4,2048,97,3,2122,10,41,97,2081,37,10,2154,33,49,34,35,97,2048,96,97,2080,5,1,116,0,2123,33]

theorem envBound7862 : H12AffineFastState.Bounded env7862 := by
  intro p hp
  have h : env7862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7861_7862 : H12AffineEnvironment.transform 8 32 env7861 = env7862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env7861 == env7862) = true)

theorem identity7862 : scanCanonicalize (H12AffineFastState.compose env7862 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7862 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7863 : List Nat := [2,4,8,16,32,59,41,46,32,4,2048,26,3,2097,10,41,26,2081,37,10,2065,33,49,34,35,26,2048,27,26,2080,5,1,15,0,2096,33]

theorem envBound7863 : H12AffineFastState.Bounded env7863 := by
  intro p hp
  have h : env7863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7862_7863 : H12AffineEnvironment.transform 5 59 env7862 = env7863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7862 == env7863) = true)

theorem identity7863 : scanCanonicalize (H12AffineFastState.compose env7863 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound7863 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7864 : List Nat := [2,4,8,16,32,59,41,46,32,4,15,26,3,62,10,41,26,46,37,10,30,33,49,34,35,26,15,27,26,47,5,1,15,0,63,33]

theorem envBound7864 : H12AffineFastState.Bounded env7864 := by
  intro p hp
  have h : env7864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7863_7864 : H12AffineEnvironment.transform 10 15 env7863 = env7864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env7863 == env7864) = true)

theorem identity7864 : scanCanonicalize (H12AffineFastState.compose env7864 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7864 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7865 : List Nat := [2,4,2,16,32,49,35,36,32,4,5,16,3,52,0,35,16,36,37,0,20,33,49,34,35,16,5,17,16,37,5,1,5,0,53,33]

theorem envBound7865 : H12AffineFastState.Bounded env7865 := by
  intro p hp
  have h : env7865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7864_7865 : H12AffineEnvironment.transform 2 2 env7864 = env7865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7864 == env7865) = true)

def env7866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,4194304,5749,16777216,8329,16856021,21308429,16856229,16856408,4271239,5,75218,5785,4269223,23147293,16778207]

theorem envBound7866 : H12AffineFastState.Bounded env7866 := by
  intro p hp
  have h : env7866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7816_7866 : H12AffineEnvironment.transform 18 5017 env7816 = env7866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env7816 == env7866) = true)

def env7867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,32,5749,16777216,8329,16856021,17114157,16856229,16856408,76967,5,75218,5785,74887,18953021,16778207]

theorem envBound7867 : H12AffineFastState.Bounded env7867 := by
  intro p hp
  have h : env7867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7866_7867 : H12AffineEnvironment.transform 21 32 env7866 = env7867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7866 == env7867) = true)

theorem identity7867 : scanCanonicalize (H12AffineFastState.compose env7867 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383462) := by decide +kernel

theorem selectedBound7867 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,32,5749,2383462,8329,2452915,2193995,2452163,2452286,76967,5,75218,5785,74887,355675,2383289]

theorem envBound7868 : H12AffineFastState.Bounded env7868 := by
  intro p hp
  have h : env7868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7867_7868 : H12AffineEnvironment.transform 23 2383462 env7867 = env7868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383462 env7867 == env7868) = true)

def env7869 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4813,8353,2097152,32,5749,2383462,8329,2452711,2193995,2452163,2452074,76967,5,74886,5785,74887,355343,2383085]

theorem envBound7869 : H12AffineFastState.Bounded env7869 := by
  intro p hp
  have h : env7869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7868_7869 : H12AffineEnvironment.transform 7 84 env7868 = env7869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7868 == env7869) = true)

theorem identity7869 : scanCanonicalize (H12AffineFastState.compose env7869 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7869 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7870 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,262144,4813,8353,2097152,32,5749,2383462,8329,2378957,2120289,2378473,2378304,3213,5,1196,5785,1197,281637,2383085]

theorem envBound7870 : H12AffineFastState.Bounded env7870 := by
  intro p hp
  have h : env7870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7869_7870 : H12AffineEnvironment.transform 15 8234 env7869 = env7870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7869 == env7870) = true)

theorem identity7870 : scanCanonicalize (H12AffineFastState.compose env7870 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound7870 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7871 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,262144,4813,8353,286276,32,5749,34,8329,4745,263205,5293,5124,3213,5,1196,5785,1197,281637,681]

theorem envBound7871 : H12AffineFastState.Bounded env7871 := by
  intro p hp
  have h : env7871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7870_7871 : H12AffineEnvironment.transform 20 286276 env7870 = env7871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env7870 == env7871) = true)

theorem identity7871 : scanCanonicalize (H12AffineFastState.compose env7871 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6857) := by decide +kernel

theorem selectedBound7871 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7872 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,6857,4813,8353,17549,32,5749,34,8329,4745,7916,5293,5124,3213,5,1196,5785,1197,22252,681]

theorem envBound7872 : H12AffineFastState.Bounded env7872 := by
  intro p hp
  have h : env7872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7871_7872 : H12AffineEnvironment.transform 17 6857 env7871 = env7872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6857 env7871 == env7872) = true)

theorem identity7872 : scanCanonicalize (H12AffineFastState.compose env7872 (packedSelected [0,2,3,5,6,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound7872 : packedSelected [0,2,3,5,6,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env7873 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,665,8192,16384,8353,8234,561,2128,84,8353,17549,32,1260,34,8329,16,3189,1588,1693,3213,5,1196,1024,1197,17525,681]

theorem envBound7873 : H12AffineFastState.Bounded env7873 := by
  intro p hp
  have h : env7873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7872_7873 : H12AffineEnvironment.transform 11 665 env7872 = env7873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env7872 == env7873) = true)

theorem identity7873 : scanCanonicalize (H12AffineFastState.compose env7873 (packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7873 : packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS < 2^1333 := by decide +kernel

def env7874 : List Nat := [2,4,8,16,32,49,128,37,512,1024,2048,665,8192,16384,8353,8234,561,2081,37,8353,17549,32,1181,34,8329,16,3076,1588,1693,3213,5,1196,1024,1197,17412,681]

theorem envBound7874 : H12AffineFastState.Bounded env7874 := by
  intro p hp
  have h : env7874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7873_7874 : H12AffineEnvironment.transform 5 49 env7873 = env7874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7873 == env7874) = true)

theorem identity7874 : scanCanonicalize (H12AffineFastState.compose env7874 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7874 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env7875 : List Nat := [2,4,8,16,32,49,128,37,512,4,2048,665,8192,16384,8353,8234,561,2081,37,8353,16521,32,153,34,8329,16,2048,560,665,2185,5,168,4,169,16384,681]

theorem envBound7875 : H12AffineFastState.Bounded env7875 := by
  intro p hp
  have h : env7875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7874_7875 : H12AffineEnvironment.transform 9 4 env7874 = env7875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7874 == env7875) = true)

theorem identity7875 : scanCanonicalize (H12AffineFastState.compose env7875 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2731) := by decide +kernel

theorem selectedBound7875 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env7876 : List Nat := [2,4,8,16,32,49,128,37,512,4,2048,665,2731,16384,2570,2689,561,2081,37,2570,16521,32,153,34,2594,16,2048,560,665,2185,5,168,4,169,16384,681]

theorem envBound7876 : H12AffineFastState.Bounded env7876 := by
  intro p hp
  have h : env7876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7875_7876 : H12AffineEnvironment.transform 12 2731 env7875 = env7876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2731 env7875 == env7876) = true)

theorem identity7876 : scanCanonicalize (H12AffineFastState.compose env7876 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound7876 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env7877 : List Nat := [2,4,8,16,32,49,128,37,512,4,523,665,160,16384,1,138,561,554,37,1,16521,32,153,34,41,16,523,560,665,642,5,168,4,169,16384,681]

theorem envBound7877 : H12AffineFastState.Bounded env7877 := by
  intro p hp
  have h : env7877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7876_7877 : H12AffineEnvironment.transform 10 523 env7876 = env7877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env7876 == env7877) = true)

theorem identity7877 : scanCanonicalize (H12AffineFastState.compose env7877 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7877 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env7878 : List Nat := [2,4,8,16,26,11,128,31,512,4,523,665,154,16384,1,138,523,528,31,1,16521,26,153,24,19,16,523,522,665,642,5,146,4,147,16384,659]

theorem envBound7878 : H12AffineFastState.Bounded env7878 := by
  intro p hp
  have h : env7878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7877_7878 : H12AffineEnvironment.transform 4 26 env7877 = env7878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7877 == env7878) = true)

theorem identity7878 : scanCanonicalize (H12AffineFastState.compose env7878 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7878 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env7879 : List Nat := [2,4,8,16,26,11,19,31,512,4,523,522,9,16384,1,25,523,528,31,1,16410,26,10,24,19,16,523,522,522,529,5,1,4,0,16384,512]

theorem envBound7879 : H12AffineFastState.Bounded env7879 := by
  intro p hp
  have h : env7879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7878_7879 : H12AffineEnvironment.transform 6 19 env7878 = env7879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7878 == env7879) = true)

theorem identity7879 : scanCanonicalize (H12AffineFastState.compose env7879 (packedSelected [0,1] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound7879 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7880 : List Nat := [2,4,8,16,26,11,19,31,512,4,523,522,9,512,1,25,523,528,31,1,538,26,10,24,19,16,523,522,522,529,5,1,4,0,512,512]

theorem envBound7880 : H12AffineFastState.Bounded env7880 := by
  intro p hp
  have h : env7880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7879_7880 : H12AffineEnvironment.transform 13 512 env7879 = env7880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env7879 == env7880) = true)

theorem identity7880 : scanCanonicalize (H12AffineFastState.compose env7880 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7881 : List Nat := [2,4,8,16,26,11,19,31,26,4,17,16,9,26,1,25,17,10,31,1,0,26,10,24,19,16,17,16,16,11,5,1,4,0,26,26]

theorem envBound7881 : H12AffineFastState.Bounded env7881 := by
  intro p hp
  have h : env7881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7880_7881 : H12AffineEnvironment.transform 8 26 env7880 = env7881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7880 == env7881) = true)

def leafEnv7881 : List Nat := [2,4,8,16,26,11,19,31,26,4,17,16,9,26,1,25,17,10,31,1,0,26,10,24,30,19,1,16,17,16,16,11,5,1,4,0,31,2,26,26,1,1,0]

def active7881 : List Nat := [0,1,2,3]

def tree7881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7881 : H12WitnessSearch.Good tree7881 := H12GlobalWitnessIndex.good

theorem leafIdentity7881 : H12AffineFastState.composeSystem env7881 rootObs = leafEnv7881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7881 rootObs == leafEnv7881) = true)

theorem terminalChecked7881 : H12PackedTerminal.terminalCheckFast leafEnv7881 active7881 tree7881 = true := by decide +kernel

def env7882 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4812,8352,2097152,32,5749,2383462,8329,2452710,2193995,2452163,2452075,76967,5,74887,5785,74887,355342,2383084]

theorem envBound7882 : H12AffineFastState.Bounded env7882 := by
  intro p hp
  have h : env7882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7868_7882 : H12AffineEnvironment.transform 7 85 env7868 = env7882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7868 == env7882) = true)

theorem identity7882 : scanCanonicalize (H12AffineFastState.compose env7882 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7882 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7883 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,2097152,32,5749,2383462,8225,2452558,2193995,2452075,2452075,76815,5,74799,5681,74799,355342,2382916]

theorem envBound7883 : H12AffineFastState.Bounded env7883 := by
  intro p hp
  have h : env7883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7882_7883 : H12AffineEnvironment.transform 6 40 env7882 = env7883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7882 == env7883) = true)

theorem identity7883 : scanCanonicalize (H12AffineFastState.compose env7883 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360047) := by decide +kernel

theorem selectedBound7883 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7884 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,360047,32,5749,73737,8225,4641,263204,5124,5124,76815,5,74799,5681,74799,355342,74283]

theorem envBound7884 : H12AffineFastState.Bounded env7884 := by
  intro p hp
  have h : env7884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7883_7884 : H12AffineEnvironment.transform 20 360047 env7883 = env7884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360047 env7883 == env7884) = true)

theorem identity7884 : scanCanonicalize (H12AffineFastState.compose env7884 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7884 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7885 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8235,4097,262144,4708,8200,286276,32,5749,34,8225,4641,263204,5124,5124,3108,5,1028,5681,1028,281637,512]

theorem envBound7885 : H12AffineFastState.Bounded env7885 := by
  intro p hp
  have h : env7885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7884_7885 : H12AffineEnvironment.transform 15 8235 env7884 = env7885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7884 == env7885) = true)

theorem identity7885 : scanCanonicalize (H12AffineFastState.compose env7885 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7885 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7886 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,2081,8200,8235,4097,262144,4708,8200,267877,32,5749,34,8225,4641,263204,5124,5124,3108,5,1028,5681,1028,263172,512]

theorem envBound7886 : H12AffineFastState.Bounded env7886 := by
  intro p hp
  have h : env7886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7885_7886 : H12AffineEnvironment.transform 13 2081 env7885 = env7886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env7885 == env7886) = true)

theorem identity7886 : scanCanonicalize (H12AffineFastState.compose env7886 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7886 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7887 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,2081,8200,8235,4097,262144,4708,8200,266848,32,4720,34,8225,4641,262177,4097,4097,2081,5,1,4660,1,262145,512]

theorem envBound7887 : H12AffineFastState.Bounded env7887 := by
  intro p hp
  have h : env7887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7886_7887 : H12AffineEnvironment.transform 9 5 env7886 = env7887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7886 == env7887) = true)

theorem identity7887 : scanCanonicalize (H12AffineFastState.compose env7887 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 2107) := by decide +kernel

theorem selectedBound7887 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7888 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,2081,8200,8235,4097,2107,4708,8200,6747,32,4720,34,8225,4641,2074,4097,4097,2081,5,1,4660,1,2106,512]

theorem envBound7888 : H12AffineFastState.Bounded env7888 := by
  intro p hp
  have h : env7888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7887_7888 : H12AffineEnvironment.transform 17 2107 env7887 = env7888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2107 env7887 == env7888) = true)

def env7889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,33,5749,16777216,8329,16856021,17114156,16856229,16856408,76966,5,75218,5785,74886,18953020,16778207]

theorem envBound7889 : H12AffineFastState.Bounded env7889 := by
  intro p hp
  have h : env7889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7866_7889 : H12AffineEnvironment.transform 21 33 env7866 = env7889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7866 == env7889) = true)

theorem identity7889 : scanCanonicalize (H12AffineFastState.compose env7889 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383667) := by decide +kernel

theorem selectedBound7889 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,33,5749,2383667,8329,2452710,2194207,2452374,2452075,76966,5,75218,5785,74886,355343,2383084]

theorem envBound7890 : H12AffineFastState.Bounded env7890 := by
  intro p hp
  have h : env7890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7889_7890 : H12AffineEnvironment.transform 23 2383667 env7889 = env7890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383667 env7889 == env7890) = true)

def env7891 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4813,8353,2097152,33,5749,2383463,8329,2452710,2193995,2452162,2452075,76966,5,74886,5785,74886,355343,2383084]

theorem envBound7891 : H12AffineFastState.Bounded env7891 := by
  intro p hp
  have h : env7891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7890_7891 : H12AffineEnvironment.transform 7 84 env7890 = env7891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7890 == env7891) = true)

theorem identity7891 : scanCanonicalize (H12AffineFastState.compose env7891 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7891 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7892 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,2097152,33,5749,2383463,8224,2452559,2193995,2452075,2452075,76815,5,74799,5680,74799,355343,2382917]

theorem envBound7892 : H12AffineFastState.Bounded env7892 := by
  intro p hp
  have h : env7892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7891_7892 : H12AffineEnvironment.transform 6 41 env7891 = env7892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7891 == env7892) = true)

theorem identity7892 : scanCanonicalize (H12AffineFastState.compose env7892 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360047) := by decide +kernel

theorem selectedBound7892 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7893 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,360047,33,5749,73736,8224,4640,263204,5124,5124,76815,5,74799,5680,74799,355343,74282]

theorem envBound7893 : H12AffineFastState.Bounded env7893 := by
  intro p hp
  have h : env7893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7892_7893 : H12AffineEnvironment.transform 20 360047 env7892 = env7893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360047 env7892 == env7893) = true)

theorem identity7893 : scanCanonicalize (H12AffineFastState.compose env7893 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7893 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7894 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8234,4097,262144,4708,8200,286277,33,5749,34,8224,4640,263204,5124,5124,3109,5,1029,5680,1029,281637,512]

theorem envBound7894 : H12AffineFastState.Bounded env7894 := by
  intro p hp
  have h : env7894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7893_7894 : H12AffineEnvironment.transform 15 8234 env7893 = env7894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7893 == env7894) = true)

theorem identity7894 : scanCanonicalize (H12AffineFastState.compose env7894 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 30220) := by decide +kernel

theorem selectedBound7894 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7895 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8234,4097,30220,4708,8200,10313,33,5749,34,8224,4640,29224,5124,5124,3109,5,1029,5680,1029,14889,512]

theorem envBound7895 : H12AffineFastState.Bounded env7895 := by
  intro p hp
  have h : env7895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7894_7895 : H12AffineEnvironment.transform 17 30220 env7894 = env7895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30220 env7894 == env7895) = true)

theorem identity7895 : scanCanonicalize (H12AffineFastState.compose env7895 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 10265) := by decide +kernel

theorem selectedBound7895 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7896 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,10265,8200,8234,4097,7701,4708,8200,10313,33,5749,34,8224,4640,6705,5124,5124,3109,5,1029,5680,1029,14889,512]

theorem envBound7896 : H12AffineFastState.Bounded env7896 := by
  intro p hp
  have h : env7896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7895_7896 : H12AffineEnvironment.transform 13 10265 env7895 = env7896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10265 env7895 == env7896) = true)

theorem identity7896 : scanCanonicalize (H12AffineFastState.compose env7896 (packedSelected [0,1,5,7,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound7896 : packedSelected [0,1,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env7897 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,560,8192,10265,8200,8234,561,3109,84,8200,10313,33,1093,34,8224,16,2049,1588,1588,3109,5,1029,1024,1029,10265,512]

theorem envBound7897 : H12AffineFastState.Bounded env7897 := by
  intro p hp
  have h : env7897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7896_7897 : H12AffineEnvironment.transform 11 560 env7896 = env7897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env7896 == env7897) = true)

theorem identity7897 : scanCanonicalize (H12AffineFastState.compose env7897 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound7897 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env7898 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,560,2168,97,2160,2130,561,3109,84,2160,49,33,1093,34,2136,16,2049,1588,1588,3109,5,1029,1024,1029,97,512]

theorem envBound7898 : H12AffineFastState.Bounded env7898 := by
  intro p hp
  have h : env7898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7897_7898 : H12AffineEnvironment.transform 12 2168 env7897 = env7898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env7897 == env7898) = true)

theorem identity7898 : scanCanonicalize (H12AffineFastState.compose env7898 (packedSelected [1,3,14] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7898 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env7899 : List Nat := [2,4,8,16,32,64,41,84,512,4,2048,560,2168,97,2160,2130,561,2081,84,2160,49,33,65,34,2136,16,2049,560,560,2081,5,1,4,1,97,512]

theorem envBound7899 : H12AffineFastState.Bounded env7899 := by
  intro p hp
  have h : env7899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7898_7899 : H12AffineEnvironment.transform 9 4 env7898 = env7899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7898 == env7899) = true)

theorem identity7899 : scanCanonicalize (H12AffineFastState.compose env7899 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound7899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7900 : List Nat := [2,4,8,16,32,26,41,14,512,4,2048,560,2082,59,2090,2056,561,2081,14,2090,49,33,27,34,2050,16,2049,560,560,2081,5,1,4,1,59,512]

theorem envBound7900 : H12AffineFastState.Bounded env7900 := by
  intro p hp
  have h : env7900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7899_7900 : H12AffineEnvironment.transform 5 26 env7899 = env7900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env7899 == env7900) = true)

theorem identity7900 : scanCanonicalize (H12AffineFastState.compose env7900 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound7900 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7901 : List Nat := [2,4,8,16,32,26,41,14,16,4,2048,32,2082,59,2090,2056,33,2081,14,2090,49,33,27,34,2050,16,2049,32,32,2081,5,1,4,1,59,16]

theorem envBound7901 : H12AffineFastState.Bounded env7901 := by
  intro p hp
  have h : env7901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7900_7901 : H12AffineEnvironment.transform 8 16 env7900 = env7901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env7900 == env7901) = true)

def env7902 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4812,8352,2097152,33,5749,2383462,8329,2452710,2193994,2452163,2452075,76966,5,74887,5785,74886,355343,2383084]

theorem envBound7902 : H12AffineFastState.Bounded env7902 := by
  intro p hp
  have h : env7902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7890_7902 : H12AffineEnvironment.transform 7 85 env7890 = env7902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7890 == env7902) = true)

theorem identity7902 : scanCanonicalize (H12AffineFastState.compose env7902 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7902 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7903 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,262144,4812,8352,2097152,33,5749,2383462,8329,2378957,2120289,2378472,2378304,3213,5,1196,5785,1197,281636,2383084]

theorem envBound7903 : H12AffineFastState.Bounded env7903 := by
  intro p hp
  have h : env7903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7902_7903 : H12AffineEnvironment.transform 15 8235 env7902 = env7903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7902 == env7903) = true)

theorem identity7903 : scanCanonicalize (H12AffineFastState.compose env7903 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound7903 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7904 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,262144,4812,8352,286276,33,5749,34,8329,4745,263205,5292,5124,3213,5,1196,5785,1197,281636,680]

theorem envBound7904 : H12AffineFastState.Bounded env7904 := by
  intro p hp
  have h : env7904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7903_7904 : H12AffineEnvironment.transform 20 286276 env7903 = env7904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env7903 == env7904) = true)

theorem identity7904 : scanCanonicalize (H12AffineFastState.compose env7904 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 7885) := by decide +kernel

theorem selectedBound7904 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7905 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,7885,4812,8352,16521,33,5749,34,8329,4745,6888,5292,5124,3213,5,1196,5785,1197,21225,680]

theorem envBound7905 : H12AffineFastState.Bounded env7905 := by
  intro p hp
  have h : env7905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7904_7905 : H12AffineEnvironment.transform 17 7885 env7904 = env7905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7885 env7904 == env7905) = true)

theorem identity7905 : scanCanonicalize (H12AffineFastState.compose env7905 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound7905 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env7906 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,8192,16384,8352,8235,4265,6753,4812,8352,16521,33,4825,34,8329,4745,6888,4096,4264,2081,5,0,4661,1,21225,680]

theorem envBound7906 : H12AffineFastState.Bounded env7906 := by
  intro p hp
  have h : env7906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7905_7906 : H12AffineEnvironment.transform 9 172 env7905 = env7906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env7905 == env7906) = true)

theorem identity7906 : scanCanonicalize (H12AffineFastState.compose env7906 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound7906 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env7907 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,171,16384,11,128,4265,6753,4812,11,16521,33,4825,34,34,4745,6888,4096,4264,2081,5,0,4661,1,21225,680]

theorem envBound7907 : H12AffineFastState.Bounded env7907 := by
  intro p hp
  have h : env7907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7906_7907 : H12AffineEnvironment.transform 12 171 env7906 = env7907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env7906 == env7907) = true)

theorem identity7907 : scanCanonicalize (H12AffineFastState.compose env7907 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound7907 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env7908 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,171,513,11,128,4265,6753,4812,11,648,33,4825,34,34,4745,6888,4096,4264,2081,5,0,4661,1,4328,680]

theorem envBound7908 : H12AffineFastState.Bounded env7908 := by
  intro p hp
  have h : env7908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7907_7908 : H12AffineEnvironment.transform 13 513 env7907 = env7908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env7907 == env7908) = true)

theorem identity7908 : scanCanonicalize (H12AffineFastState.compose env7908 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound7908 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7909 : List Nat := [2,4,8,16,32,64,88,85,512,116,2048,4096,115,513,11,88,4209,6753,4628,11,592,33,4609,34,34,4689,6704,4096,4208,2081,5,0,4661,1,4144,624]

theorem envBound7909 : H12AffineFastState.Bounded env7909 := by
  intro p hp
  have h : env7909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7908_7909 : H12AffineEnvironment.transform 6 88 env7908 = env7909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env7908 == env7909) = true)

theorem identity7909 : scanCanonicalize (H12AffineFastState.compose env7909 (packedSelected [11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7909 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env7910 : List Nat := [2,4,8,16,32,49,41,36,512,5,2048,4096,2,513,11,41,4096,6672,4628,11,545,33,4609,34,34,4640,6704,4096,4097,2081,5,0,4661,1,4144,513]

theorem envBound7910 : H12AffineFastState.Bounded env7910 := by
  intro p hp
  have h : env7910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7909_7910 : H12AffineEnvironment.transform 5 49 env7909 = env7910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7909 == env7910) = true)

theorem identity7910 : scanCanonicalize (H12AffineFastState.compose env7910 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 571) := by decide +kernel

theorem selectedBound7910 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7911 : List Nat := [2,4,8,16,32,49,41,36,512,5,571,4096,2,513,11,41,4096,4139,4628,11,545,33,4609,34,34,4640,4107,4096,4097,538,5,0,4661,1,4144,513]

theorem envBound7911 : H12AffineFastState.Bounded env7911 := by
  intro p hp
  have h : env7911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7910_7911 : H12AffineEnvironment.transform 10 571 env7910 = env7911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 571 env7910 == env7911) = true)

theorem identity7911 : scanCanonicalize (H12AffineFastState.compose env7911 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound7911 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env7912 : List Nat := [2,4,8,16,32,49,41,36,512,5,571,539,2,513,11,41,539,560,15,11,545,33,26,34,34,59,528,539,538,538,5,0,46,1,555,513]

theorem envBound7912 : H12AffineFastState.Bounded env7912 := by
  intro p hp
  have h : env7912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7911_7912 : H12AffineEnvironment.transform 11 539 env7911 = env7912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env7911 == env7912) = true)

theorem identity7912 : scanCanonicalize (H12AffineFastState.compose env7912 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound7912 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7913 : List Nat := [2,4,8,16,11,26,2,15,512,5,528,539,2,513,11,2,539,539,15,11,522,10,26,9,9,16,528,539,538,538,5,0,5,1,512,513]

theorem envBound7913 : H12AffineFastState.Bounded env7913 := by
  intro p hp
  have h : env7913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7912_7913 : H12AffineEnvironment.transform 4 11 env7912 = env7913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env7912 == env7913) = true)

theorem identity7913 : scanCanonicalize (H12AffineFastState.compose env7913 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound7913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7914 : List Nat := [2,4,8,16,11,26,2,15,0,5,16,27,2,1,11,2,27,27,15,11,10,10,26,9,9,16,16,27,26,26,5,0,5,1,0,1]

theorem envBound7914 : H12AffineFastState.Bounded env7914 := by
  intro p hp
  have h : env7914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7913_7914 : H12AffineEnvironment.transform 8 0 env7913 = env7914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env7913 == env7914) = true)

theorem identity7914 : scanCanonicalize (H12AffineFastState.compose env7914 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound7914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7915 : List Nat := [2,4,8,15,11,5,2,15,0,5,15,4,2,1,11,2,4,4,15,11,10,10,5,9,9,15,15,4,5,5,5,0,5,1,0,1]

theorem envBound7915 : H12AffineFastState.Bounded env7915 := by
  intro p hp
  have h : env7915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7914_7915 : H12AffineEnvironment.transform 3 15 env7914 = env7915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env7914 == env7915) = true)

theorem identity7915 : scanCanonicalize (H12AffineFastState.compose env7915 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound7915 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7916 : List Nat := [2,0,8,11,11,1,2,11,0,1,11,0,2,1,11,2,0,0,11,11,10,10,1,9,9,11,11,0,1,1,1,0,1,1,0,1]

theorem envBound7916 : H12AffineFastState.Bounded env7916 := by
  intro p hp
  have h : env7916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7915_7916 : H12AffineEnvironment.transform 1 0 env7915 = env7916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7915 == env7916) = true)

theorem identity7916 : scanCanonicalize (H12AffineFastState.compose env7916 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7916 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env7917 : List Nat := [2,0,2,1,1,1,2,1,0,1,1,0,2,1,1,2,0,0,1,1,0,0,1,3,3,1,1,0,1,1,1,0,1,1,0,1]

theorem envBound7917 : H12AffineFastState.Bounded env7917 := by
  intro p hp
  have h : env7917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7916_7917 : H12AffineEnvironment.transform 2 2 env7916 = env7917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7916 == env7917) = true)

def env7918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,17375309,21837717,17377085,17376960,4800287,4,603722,525568,4798271,23666821,16778207]

theorem envBound7918 : H12AffineFastState.Bounded env7918 := by
  intro p hp
  have h : env7918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7815_7918 : H12AffineEnvironment.transform 25 17375309 env7815 = env7918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17375309 env7815 == env7918) = true)

def env7919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,4194304,5748,16777216,8329,16856021,21308429,16856229,16856408,4271239,4,75218,5784,4269223,23147293,16778207]

theorem envBound7919 : H12AffineFastState.Bounded env7919 := by
  intro p hp
  have h : env7919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7918_7919 : H12AffineEnvironment.transform 18 5016 env7918 = env7919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env7918 == env7919) = true)

def env7920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,32,5748,16777216,8329,16856021,17114157,16856229,16856408,76967,4,75218,5784,74887,18953021,16778207]

theorem envBound7920 : H12AffineFastState.Bounded env7920 := by
  intro p hp
  have h : env7920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7919_7920 : H12AffineEnvironment.transform 21 32 env7919 = env7920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7919 == env7920) = true)

theorem identity7920 : scanCanonicalize (H12AffineFastState.compose env7920 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360251) := by decide +kernel

theorem selectedBound7920 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,360251,32,5748,16777216,8329,16856021,17114157,16856229,16856408,76967,4,75218,5784,74887,17058822,16778207]

theorem envBound7921 : H12AffineFastState.Bounded env7921 := by
  intro p hp
  have h : env7921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7920_7921 : H12AffineEnvironment.transform 20 360251 env7920 = env7921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360251 env7920 == env7921) = true)

def env7922 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4812,8353,360047,32,5748,16777216,8329,16855681,17114157,16856229,16856076,76967,4,74886,5784,74887,17058822,16777867]

theorem envBound7922 : H12AffineFastState.Bounded env7922 := by
  intro p hp
  have h : env7922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7921_7922 : H12AffineEnvironment.transform 7 84 env7921 = env7922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7921 == env7922) = true)

theorem identity7922 : scanCanonicalize (H12AffineFastState.compose env7922 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7922 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7923 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,262144,4812,8353,286276,32,5748,16777216,8329,16781994,17040390,16782478,16782375,3212,4,1197,5784,1196,17058822,16777867]

theorem envBound7923 : H12AffineFastState.Bounded env7923 := by
  intro p hp
  have h : env7923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7922_7923 : H12AffineEnvironment.transform 15 8235 env7922 = env7923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7922 == env7923) = true)

theorem identity7923 : scanCanonicalize (H12AffineFastState.compose env7923 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound7923 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7924 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,262144,4812,8353,286276,32,5748,34,8329,4744,263204,5292,5125,3212,4,1197,5784,1196,281636,681]

theorem envBound7924 : H12AffineFastState.Bounded env7924 := by
  intro p hp
  have h : env7924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7923_7924 : H12AffineEnvironment.transform 23 34 env7923 = env7924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env7923 == env7924) = true)

theorem identity7924 : scanCanonicalize (H12AffineFastState.compose env7924 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6752) := by decide +kernel

theorem selectedBound7924 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7925 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8235,4264,6752,4812,8353,17444,32,5748,34,8329,4744,7748,5292,5125,3212,4,1197,5784,1196,22084,681]

theorem envBound7925 : H12AffineFastState.Bounded env7925 := by
  intro p hp
  have h : env7925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7924_7925 : H12AffineEnvironment.transform 17 6752 env7924 = env7925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6752 env7924 == env7925) = true)

theorem identity7925 : scanCanonicalize (H12AffineFastState.compose env7925 (packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound7925 : packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env7926 : List Nat := [2,4,8,16,32,64,128,84,512,220,2048,4096,8192,16384,8353,8235,4264,6752,4812,8353,16632,32,4776,34,8329,4744,6808,4208,4313,2128,4,113,4676,112,21144,681]

theorem envBound7926 : H12AffineFastState.Bounded env7926 := by
  intro p hp
  have h : env7926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7925_7926 : H12AffineEnvironment.transform 9 220 env7925 = env7926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env7925 == env7926) = true)

theorem identity7926 : scanCanonicalize (H12AffineFastState.compose env7926 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7926 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7927 : List Nat := [2,4,8,16,32,49,128,37,512,173,2048,4096,8192,16384,8353,8235,4264,6673,4797,8353,16521,32,4776,34,8329,4744,6808,4097,4264,2081,4,0,4661,1,21144,681]

theorem envBound7927 : H12AffineFastState.Bounded env7927 := by
  intro p hp
  have h : env7927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7926_7927 : H12AffineEnvironment.transform 5 49 env7926 = env7927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7926 == env7927) = true)

theorem identity7927 : scanCanonicalize (H12AffineFastState.compose env7927 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7927 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env7928 : List Nat := [2,4,8,16,26,11,128,31,512,151,2048,4096,8192,16384,8347,8209,4242,6673,4743,8347,16521,26,4754,24,8329,4744,6808,4097,4242,2075,4,0,4623,1,21144,659]

theorem envBound7928 : H12AffineFastState.Bounded env7928 := by
  intro p hp
  have h : env7928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7927_7928 : H12AffineEnvironment.transform 4 26 env7927 = env7928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7927 == env7928) = true)

theorem identity7928 : scanCanonicalize (H12AffineFastState.compose env7928 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound7928 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env7929 : List Nat := [2,4,8,16,26,11,128,31,512,151,2048,4096,8192,513,8347,8209,4242,6673,4743,8347,648,26,4754,24,8329,4744,6808,4097,4242,2075,4,0,4623,1,4249,659]

theorem envBound7929 : H12AffineFastState.Bounded env7929 := by
  intro p hp
  have h : env7929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7928_7929 : H12AffineEnvironment.transform 13 513 env7928 = env7929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env7928 == env7929) = true)

theorem identity7929 : scanCanonicalize (H12AffineFastState.compose env7929 (packedSelected [2,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound7929 : packedSelected [2,11,14,23] rootPS < 2^1333 := by decide +kernel

def env7930 : List Nat := [2,4,8,16,26,11,128,31,512,151,2048,665,8192,513,8347,8209,523,2184,30,8347,648,26,11,24,8329,17,2049,664,523,2075,4,0,150,1,512,659]

theorem envBound7930 : H12AffineFastState.Bounded env7930 := by
  intro p hp
  have h : env7930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7929_7930 : H12AffineEnvironment.transform 11 665 env7929 = env7930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env7929 == env7930) = true)

theorem identity7930 : scanCanonicalize (H12AffineFastState.compose env7930 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound7930 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env7931 : List Nat := [2,4,8,16,26,11,128,31,512,151,2048,665,154,513,1,139,523,2184,30,1,648,26,11,24,19,17,2049,664,523,2075,4,0,150,1,512,659]

theorem envBound7931 : H12AffineFastState.Bounded env7931 := by
  intro p hp
  have h : env7931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7930_7931 : H12AffineEnvironment.transform 12 154 env7930 = env7931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env7930 == env7931) = true)

end H12CloudChart1