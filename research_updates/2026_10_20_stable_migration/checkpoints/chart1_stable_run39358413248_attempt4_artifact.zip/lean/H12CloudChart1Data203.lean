import H12CloudChart1Data202

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound51416 : packedSelected [0,1,4,7,11,19,22,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,29963,13461,23589,1025,32769,45461,29861,41364,62598,8328,16,64524,46228,17664,2340,41993,8492,257,21793,46212,63109]

theorem envBound51417 : H12AffineFastState.Bounded env51417 := by
  intro p hp
  have h : env51417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51416_51417 : H12AffineEnvironment.transform 15 29963 env51416 = env51417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env51416 == env51417) = true)

theorem identity51417 : scanCanonicalize (H12AffineFastState.compose env51417 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51417 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env51418 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,263,13461,10281,1025,32769,45461,169,41364,32906,8328,16,34816,46228,12556,2340,41993,8492,257,8493,46212,33417]

theorem envBound51418 : H12AffineFastState.Bounded env51418 := by
  intro p hp
  have h : env51418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51417_51418 : H12AffineEnvironment.transform 13 13324 env51417 = env51418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51417 == env51418) = true)

theorem identity51418 : scanCanonicalize (H12AffineFastState.compose env51418 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound51418 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51419 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8580,263,13461,10281,1025,8581,4113,169,16,8462,8328,16,10628,5392,12556,2340,1421,8492,257,8493,5376,8973]

theorem envBound51419 : H12AffineFastState.Bounded env51419 := by
  intro p hp
  have h : env51419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51418_51419 : H12AffineEnvironment.transform 14 8580 env51418 = env51419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env51418 == env51419) = true)

theorem identity51419 : scanCanonicalize (H12AffineFastState.compose env51419 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1425) := by decide +kernel

theorem selectedBound51419 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51420 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1425,4509,1045,263,4356,3512,1025,1044,4113,169,16,1183,1305,16,3093,5392,5277,2340,1421,1213,257,1212,5376,1692]

theorem envBound51420 : H12AffineFastState.Bounded env51420 := by
  intro p hp
  have h : env51420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51419_51420 : H12AffineEnvironment.transform 12 1425 env51419 = env51420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1425 env51419 == env51420) = true)

theorem identity51420 : scanCanonicalize (H12AffineFastState.compose env51420 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 441) := by decide +kernel

theorem selectedBound51420 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51421 : List Nat := [2,4,8,16,32,16,128,256,512,441,2048,4096,40,4509,428,263,4356,2049,440,429,4113,169,16,294,160,16,2476,4265,4388,2340,52,260,257,261,4281,805]

theorem envBound51421 : H12AffineFastState.Bounded env51421 := by
  intro p hp
  have h : env51421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51420_51421 : H12AffineEnvironment.transform 9 441 env51420 = env51421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 441 env51420 == env51421) = true)

theorem identity51421 : scanCanonicalize (H12AffineFastState.compose env51421 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound51421 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env51422 : List Nat := [2,4,8,16,32,16,128,173,512,20,2048,4096,40,4144,1,170,4265,2049,21,0,4113,169,16,139,160,16,2049,4265,4233,2185,52,169,172,168,4281,648]

theorem envBound51422 : H12AffineFastState.Bounded env51422 := by
  intro p hp
  have h : env51422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51421_51422 : H12AffineEnvironment.transform 7 173 env51421 = env51422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51421 == env51422) = true)

theorem identity51422 : scanCanonicalize (H12AffineFastState.compose env51422 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound51422 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51423 : List Nat := [2,4,8,16,32,16,128,173,512,20,2048,2200,40,2216,1,170,2097,2049,21,0,2185,169,16,139,160,16,2049,2097,2065,2185,52,169,172,168,2081,648]

theorem envBound51423 : H12AffineFastState.Bounded env51423 := by
  intro p hp
  have h : env51423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51422_51423 : H12AffineEnvironment.transform 11 2200 env51422 = env51423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env51422 == env51423) = true)

theorem identity51423 : scanCanonicalize (H12AffineFastState.compose env51423 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound51423 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51424 : List Nat := [2,4,8,16,32,16,128,173,512,20,136,16,40,32,1,170,185,137,21,0,1,169,16,139,160,16,137,185,153,1,52,169,172,168,169,648]

theorem envBound51424 : H12AffineFastState.Bounded env51424 := by
  intro p hp
  have h : env51424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51423_51424 : H12AffineEnvironment.transform 10 136 env51423 = env51424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env51423 == env51424) = true)

theorem identity51424 : scanCanonicalize (H12AffineFastState.compose env51424 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound51424 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51425 : List Nat := [2,4,8,16,32,16,56,21,512,20,48,16,40,32,1,18,1,49,21,0,1,17,16,51,24,16,49,1,33,1,52,17,20,16,17,560]

theorem envBound51425 : H12AffineFastState.Bounded env51425 := by
  intro p hp
  have h : env51425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51424_51425 : H12AffineEnvironment.transform 6 56 env51424 = env51425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env51424 == env51425) = true)

theorem identity51425 : scanCanonicalize (H12AffineFastState.compose env51425 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51425 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env51426 : List Nat := [2,4,8,0,32,0,40,5,512,4,32,0,40,32,1,2,1,33,5,0,1,1,0,35,8,0,33,1,33,1,36,1,4,0,1,544]

theorem envBound51426 : H12AffineFastState.Bounded env51426 := by
  intro p hp
  have h : env51426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51425_51426 : H12AffineEnvironment.transform 3 0 env51425 = env51426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51425 == env51426) = true)

theorem identity51426 : scanCanonicalize (H12AffineFastState.compose env51426 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51427 : List Nat := [2,4,8,0,1,0,9,5,512,4,1,0,9,1,1,2,1,0,5,0,1,1,0,2,8,0,0,1,0,1,5,1,4,0,1,513]

theorem envBound51427 : H12AffineFastState.Bounded env51427 := by
  intro p hp
  have h : env51427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51426_51427 : H12AffineEnvironment.transform 4 1 env51426 = env51427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51426 == env51427) = true)

theorem identity51427 : scanCanonicalize (H12AffineFastState.compose env51427 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51428 : List Nat := [2,4,8,0,1,0,9,5,1,4,1,0,9,1,1,2,1,0,5,0,1,1,0,2,8,0,0,1,0,1,5,1,4,0,1,0]

theorem envBound51428 : H12AffineFastState.Bounded env51428 := by
  intro p hp
  have h : env51428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51427_51428 : H12AffineEnvironment.transform 8 1 env51427 = env51428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51427 == env51428) = true)

def env51429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115870,272512,119966,98700,8328,17,64525,115102,17664,283905,119042,329730,257,21793,46212,63108]

theorem envBound51429 : H12AffineFastState.Bounded env51429 := by
  intro p hp
  have h : env51429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51414_51429 : H12AffineEnvironment.transform 5 17 env51414 = env51429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51414 == env51429) = true)

theorem identity51429 : scanCanonicalize (H12AffineFastState.compose env51429 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound51429 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51430 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,23724,1025,32769,115870,29740,119966,98700,8328,17,64525,115102,17664,2477,119042,87214,257,21793,46212,63108]

theorem envBound51430 : H12AffineFastState.Bounded env51430 := by
  intro p hp
  have h : env51430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51429_51430 : H12AffineEnvironment.transform 17 23724 env51429 = env51430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env51429 == env51430) = true)

theorem identity51430 : scanCanonicalize (H12AffineFastState.compose env51430 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound51430 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21761,65536,82335,23724,1025,21760,70047,29740,65951,87181,8328,17,10508,70815,17664,2477,66563,87214,257,21793,24965,9093]

theorem envBound51431 : H12AffineFastState.Bounded env51431 := by
  intro p hp
  have h : env51431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51430_51431 : H12AffineEnvironment.transform 14 21761 env51430 = env51431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env51430 == env51431) = true)

theorem identity51431 : scanCanonicalize (H12AffineFastState.compose env51431 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51431 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env51432 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,8460,65536,79250,10401,1025,8461,70047,33,65951,73856,8328,17,10508,70815,12557,2477,66563,73891,257,8492,5512,9093]

theorem envBound51432 : H12AffineFastState.Bounded env51432 := by
  intro p hp
  have h : env51432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51431_51432 : H12AffineEnvironment.transform 13 13325 env51431 = env51432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51431 == env51432) = true)

theorem identity51432 : scanCanonicalize (H12AffineFastState.compose env51432 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51433 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8460,65536,79131,10280,1025,8461,69910,33,65814,73737,8193,17,10508,70678,12557,2340,66563,73770,257,8492,5377,8972]

theorem envBound51433 : H12AffineFastState.Bounded env51433 := by
  intro p hp
  have h : env51433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51432_51433 : H12AffineEnvironment.transform 6 9 env51432 = env51433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51432 == env51433) = true)

theorem identity51433 : scanCanonicalize (H12AffineFastState.compose env51433 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51433 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51434 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,65536,70679,2340,1025,1,69910,33,65814,65797,269,17,2048,70678,4097,2340,66563,65830,257,32,5377,512]

theorem envBound51434 : H12AffineFastState.Bounded env51434 := by
  intro p hp
  have h : env51434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51433_51434 : H12AffineEnvironment.transform 12 268 env51433 = env51434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51433 == env51434) = true)

theorem identity51434 : scanCanonicalize (H12AffineFastState.compose env51434 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound51434 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51435 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,294,5425,2340,1025,1,4144,33,48,35,269,17,2048,5424,4097,2340,1317,0,257,32,5377,512]

theorem envBound51435 : H12AffineFastState.Bounded env51435 := by
  intro p hp
  have h : env51435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51434_51435 : H12AffineEnvironment.transform 15 294 env51434 = env51435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env51434 == env51435) = true)

theorem identity51435 : scanCanonicalize (H12AffineFastState.compose env51435 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51435 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env51436 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,0,294,4128,2340,272,1,4144,33,48,35,269,17,2048,4129,4097,2340,52,0,257,32,4112,512]

theorem envBound51436 : H12AffineFastState.Bounded env51436 := by
  intro p hp
  have h : env51436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51435_51436 : H12AffineEnvironment.transform 9 273 env51435 = env51436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51435 == env51436) = true)

theorem identity51436 : scanCanonicalize (H12AffineFastState.compose env51436 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51436 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51437 : List Nat := [2,4,8,16,32,17,9,5,512,20,2048,4096,9,4112,0,35,4128,2081,21,1,4144,33,48,35,8,17,2048,4129,4097,2081,52,0,4,32,4112,512]

theorem envBound51437 : H12AffineFastState.Bounded env51437 := by
  intro p hp
  have h : env51437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51436_51437 : H12AffineEnvironment.transform 7 5 env51436 = env51437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51436 == env51437) = true)

theorem identity51437 : scanCanonicalize (H12AffineFastState.compose env51437 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 542) := by decide +kernel

theorem selectedBound51437 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51438 : List Nat := [2,4,8,16,32,17,9,5,512,20,2048,542,9,526,0,35,574,2081,21,1,558,33,48,35,8,17,2048,575,543,2081,52,0,4,32,526,512]

theorem envBound51438 : H12AffineFastState.Bounded env51438 := by
  intro p hp
  have h : env51438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51437_51438 : H12AffineEnvironment.transform 11 542 env51437 = env51438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 542 env51437 == env51438) = true)

theorem identity51438 : scanCanonicalize (H12AffineFastState.compose env51438 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound51438 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env51439 : List Nat := [2,4,8,16,32,17,9,5,512,20,32,542,9,526,0,35,574,1,21,1,558,33,48,35,8,17,32,575,543,1,52,0,4,32,526,512]

theorem envBound51439 : H12AffineFastState.Bounded env51439 := by
  intro p hp
  have h : env51439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51438_51439 : H12AffineEnvironment.transform 10 32 env51438 = env51439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env51438 == env51439) = true)

theorem identity51439 : scanCanonicalize (H12AffineFastState.compose env51439 (packedSelected [1,11] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound51439 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env51440 : List Nat := [2,4,8,16,32,17,9,5,46,20,32,48,9,32,0,35,16,1,21,1,0,33,48,35,8,17,32,17,49,1,52,0,4,32,32,46]

theorem envBound51440 : H12AffineFastState.Bounded env51440 := by
  intro p hp
  have h : env51440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51439_51440 : H12AffineEnvironment.transform 8 46 env51439 = env51440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env51439 == env51440) = true)

theorem identity51440 : scanCanonicalize (H12AffineFastState.compose env51440 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51441 : List Nat := [2,4,8,16,1,17,9,5,15,20,1,17,9,1,0,2,16,1,21,1,0,0,17,2,8,17,1,17,16,1,21,0,4,1,1,15]

theorem envBound51441 : H12AffineFastState.Bounded env51441 := by
  intro p hp
  have h : env51441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51440_51441 : H12AffineEnvironment.transform 4 1 env51440 = env51441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51440 == env51441) = true)

theorem identity51441 : scanCanonicalize (H12AffineFastState.compose env51441 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound51441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51442 : List Nat := [2,4,8,15,1,14,9,5,15,11,1,14,9,1,0,2,15,1,10,1,0,0,14,2,8,14,1,14,15,1,10,0,4,1,1,15]

theorem envBound51442 : H12AffineFastState.Bounded env51442 := by
  intro p hp
  have h : env51442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51441_51442 : H12AffineEnvironment.transform 3 15 env51441 = env51442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env51441 == env51442) = true)

theorem identity51442 : scanCanonicalize (H12AffineFastState.compose env51442 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51442 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51443 : List Nat := [2,4,7,0,1,1,6,5,0,4,1,1,6,1,0,2,0,1,5,1,0,0,1,2,7,1,1,1,0,1,5,0,4,1,1,0]

theorem envBound51443 : H12AffineFastState.Bounded env51443 := by
  intro p hp
  have h : env51443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51442_51443 : H12AffineEnvironment.transform 2 7 env51442 = env51443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51442 == env51443) = true)

def env51444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177219,2098513,17664,2462111,2102684,2411677,257,21793,46212,2175563]

theorem envBound51444 : H12AffineFastState.Bounded env51444 := by
  intro p hp
  have h : env51444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51412_51444 : H12AffineEnvironment.transform 21 272513 env51412 = env51444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51412 == env51444) = true)

theorem identity51444 : scanCanonicalize (H12AffineFastState.compose env51444 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound51444 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38160,262144,1025,32769,2097152,272513,2101329,21763,8328,64,2157597,2098513,17664,2377025,2102684,2411677,257,21793,46212,2156181]

theorem envBound51445 : H12AffineFastState.Bounded env51445 := by
  intro p hp
  have h : env51445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51444_51445 : H12AffineEnvironment.transform 15 54494 env51444 = env51445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env51444 == env51445) = true)

def env51446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,2097152,272393,2101329,21763,8192,64,2157597,2098513,17664,2377025,2102548,2411541,257,21793,46092,2156061]

theorem envBound51446 : H12AffineFastState.Bounded env51446 := by
  intro p hp
  have h : env51446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51445_51446 : H12AffineEnvironment.transform 6 8 env51445 = env51446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51445 == env51446) = true)

theorem identity51446 : scanCanonicalize (H12AffineFastState.compose env51446 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 314688) := by decide +kernel

theorem selectedBound51446 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env51447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,314688,272393,318737,21763,8192,64,270685,313361,17664,34817,317524,341,257,21793,46092,273245]

theorem envBound51447 : H12AffineFastState.Bounded env51447 := by
  intro p hp
  have h : env51447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51446_51447 : H12AffineEnvironment.transform 20 314688 env51446 = env51447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314688 env51446 == env51447) = true)

def env51448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,2097152,272392,2101329,21763,8193,64,2157597,2098513,17664,2377025,2102549,2411540,257,21793,46093,2156060]

theorem envBound51448 : H12AffineFastState.Bounded env51448 := by
  intro p hp
  have h : env51448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51445_51448 : H12AffineEnvironment.transform 6 9 env51445 = env51448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51445 == env51448) = true)

theorem identity51448 : scanCanonicalize (H12AffineFastState.compose env51448 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound51448 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env51449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,25628,272392,29773,21763,8193,64,34817,24909,17664,270685,28937,305160,257,21793,46093,33280]

theorem envBound51449 : H12AffineFastState.Bounded env51449 := by
  intro p hp
  have h : env51449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51448_51449 : H12AffineEnvironment.transform 20 25628 env51448 = env51449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env51448 == env51449) = true)

theorem identity51449 : scanCanonicalize (H12AffineFastState.compose env51449 (packedSelected [1,3,5,8,19,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound51449 : packedSelected [1,3,5,8,19,31] rootPS < 2^1333 := by decide +kernel

def env51450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,35189,1025,32769,25628,41341,29773,21763,8193,64,34817,24909,17664,43048,28937,8573,257,21793,46093,33280]

theorem envBound51450 : H12AffineFastState.Bounded env51450 := by
  intro p hp
  have h : env51450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51449_51450 : H12AffineEnvironment.transform 17 35189 env51449 = env51450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env51449 == env51450) = true)

theorem identity51450 : scanCanonicalize (H12AffineFastState.compose env51450 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound51450 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env51451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21511,5440,2341,1025,81,25628,8493,29773,21763,8193,64,2129,24909,17664,10360,28937,8573,257,21793,13405,592]

theorem envBound51451 : H12AffineFastState.Bounded env51451 := by
  intro p hp
  have h : env51451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51450_51451 : H12AffineEnvironment.transform 14 80 env51450 = env51451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env51450 == env51451) = true)

theorem identity51451 : scanCanonicalize (H12AffineFastState.compose env51451 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51451 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env51452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,262,5440,2341,1025,81,12573,8493,8524,2,8193,64,2129,13388,4097,10360,9224,8573,257,32,13405,592]

theorem envBound51452 : H12AffineFastState.Bounded env51452 := by
  intro p hp
  have h : env51452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51451_51452 : H12AffineEnvironment.transform 13 5377 env51451 = env51452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51451 == env51452) = true)

theorem identity51452 : scanCanonicalize (H12AffineFastState.compose env51452 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51452 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51453 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,262,5393,2341,1025,0,12573,8493,8477,2,8193,17,2048,13341,4097,10281,9224,8492,257,32,13324,513]

theorem envBound51453 : H12AffineFastState.Bounded env51453 := by
  intro p hp
  have h : env51453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51452_51453 : H12AffineEnvironment.transform 5 17 env51452 = env51453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51452 == env51453) = true)

theorem identity51453 : scanCanonicalize (H12AffineFastState.compose env51453 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51453 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51454 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1025,0,4113,33,17,2,269,17,2048,5393,4097,2341,1284,32,257,32,5376,513]

theorem envBound51454 : H12AffineFastState.Bounded env51454 := by
  intro p hp
  have h : env51454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51453_51454 : H12AffineEnvironment.transform 12 268 env51453 = env51454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51453 == env51454) = true)

theorem identity51454 : scanCanonicalize (H12AffineFastState.compose env51454 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51455 : List Nat := [2,4,8,16,32,17,9,256,512,20,2048,4096,268,4373,1,262,4357,2341,21,0,4113,33,17,2,269,17,2048,4357,4097,2341,272,32,257,32,4372,513]

theorem envBound51455 : H12AffineFastState.Bounded env51455 := by
  intro p hp
  have h : env51455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51454_51455 : H12AffineEnvironment.transform 9 20 env51454 = env51455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51454 == env51455) = true)

theorem identity51455 : scanCanonicalize (H12AffineFastState.compose env51455 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound51455 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51456 : List Nat := [2,4,8,16,32,17,9,256,512,20,523,4096,268,4373,1,262,4357,814,21,0,4113,33,17,2,269,17,523,4357,4097,814,272,32,257,32,4372,513]

theorem envBound51456 : H12AffineFastState.Bounded env51456 := by
  intro p hp
  have h : env51456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51455_51456 : H12AffineEnvironment.transform 10 523 env51455 = env51456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env51455 == env51456) = true)

theorem identity51456 : scanCanonicalize (H12AffineFastState.compose env51456 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51456 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51457 : List Nat := [2,4,8,16,32,17,9,256,1,20,10,4096,268,4373,1,262,4357,303,21,0,4113,33,17,2,269,17,10,4357,4097,303,272,32,257,32,4372,0]

theorem envBound51457 : H12AffineFastState.Bounded env51457 := by
  intro p hp
  have h : env51457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51456_51457 : H12AffineEnvironment.transform 8 1 env51456 = env51457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51456 == env51457) = true)

theorem identity51457 : scanCanonicalize (H12AffineFastState.compose env51457 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound51457 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51458 : List Nat := [2,4,8,16,32,17,9,256,1,20,10,261,268,16,1,262,0,303,21,0,276,33,17,2,269,17,10,0,260,303,272,32,257,32,17,0]

theorem envBound51458 : H12AffineFastState.Bounded env51458 := by
  intro p hp
  have h : env51458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51457_51458 : H12AffineEnvironment.transform 11 261 env51457 = env51458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env51457 == env51458) = true)

theorem identity51458 : scanCanonicalize (H12AffineFastState.compose env51458 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51458 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51459 : List Nat := [2,4,8,16,0,17,9,256,1,20,10,261,268,16,1,262,0,271,21,0,276,1,17,2,269,17,10,0,260,271,272,0,257,0,17,0]

theorem envBound51459 : H12AffineFastState.Bounded env51459 := by
  intro p hp
  have h : env51459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51458_51459 : H12AffineEnvironment.transform 4 0 env51458 = env51459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51458 == env51459) = true)

theorem identity51459 : scanCanonicalize (H12AffineFastState.compose env51459 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51459 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51460 : List Nat := [2,4,4,16,0,17,5,256,1,20,6,261,256,16,1,262,0,259,21,0,276,1,17,2,257,17,6,0,260,259,272,0,257,0,17,0]

theorem envBound51460 : H12AffineFastState.Bounded env51460 := by
  intro p hp
  have h : env51460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51459_51460 : H12AffineEnvironment.transform 2 4 env51459 = env51460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51459 == env51460) = true)

def env51461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623299,8393985,10507601,8749518,2102685,12645452,257,21792,46213,2175562]

theorem envBound51461 : H12AffineFastState.Bounded env51461 := by
  intro p hp
  have h : env51461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51370_51461 : H12AffineEnvironment.transform 23 10588557 env51370 = env51461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env51370 == env51461) = true)

def env51462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623299,2098513,17665,2462110,2102685,6349852,257,21792,46213,2175562]

theorem envBound51462 : H12AffineFastState.Bounded env51462 := by
  intro p hp
  have h : env51462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51461_51462 : H12AffineEnvironment.transform 22 2101328 env51461 = env51462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env51461 == env51462) = true)

def env51463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177219,2098513,17665,2462110,2102685,2411676,257,21792,46213,2175562]

theorem envBound51463 : H12AffineFastState.Bounded env51463 := by
  intro p hp
  have h : env51463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51462_51463 : H12AffineEnvironment.transform 21 272512 env51462 = env51463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51462 == env51463) = true)

theorem identity51463 : scanCanonicalize (H12AffineFastState.compose env51463 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound51463 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82382,262144,1025,29908,2097152,272512,2101328,95496,8328,64,2177219,2098513,17665,2450763,2102685,2373705,257,21792,16464,2175562]

theorem envBound51464 : H12AffineFastState.Bounded env51464 := by
  intro p hp
  have h : env51464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51463_51464 : H12AffineEnvironment.transform 14 29909 env51463 = env51464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env51463 == env51464) = true)

def env51465 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82334,262144,1025,29828,2097152,272512,2101248,95496,8328,16,2177171,2098433,17665,2450715,2102685,2373657,257,21792,16384,2175514]

theorem envBound51465 : H12AffineFastState.Bounded env51465 := by
  intro p hp
  have h : env51465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51464_51465 : H12AffineEnvironment.transform 5 16 env51464 = env51465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51464 == env51465) = true)

theorem identity51465 : scanCanonicalize (H12AffineFastState.compose env51465 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51465 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51466 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,65536,79250,262144,1025,136,2097152,272512,2101248,65796,8328,16,2177171,2098433,12557,2429207,2102685,2373657,257,8492,13324,2175514]

theorem envBound51466 : H12AffineFastState.Bounded env51466 := by
  intro p hp
  have h : env51466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51465_51466 : H12AffineEnvironment.transform 13 13324 env51465 = env51466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51465 == env51466) = true)

theorem identity51466 : scanCanonicalize (H12AffineFastState.compose env51466 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(20+1) ^^^ 268597) := by decide +kernel

theorem selectedBound51466 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env51467 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,65536,79250,262144,1025,136,268597,272512,264501,65796,8328,16,336294,269364,12557,67618,265384,8492,257,8492,13324,338735]

theorem envBound51467 : H12AffineFastState.Bounded env51467 := by
  intro p hp
  have h : env51467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51466_51467 : H12AffineEnvironment.transform 20 268597 env51466 = env51467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268597 env51466 == env51467) = true)

theorem identity51467 : scanCanonicalize (H12AffineFastState.compose env51467 (packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound51467 : packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env51468 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,8322,5392,262144,1025,136,268597,272512,264501,8582,8328,16,262436,269364,12557,10400,265384,8492,257,8492,13324,265133]

theorem envBound51468 : H12AffineFastState.Bounded env51468 := by
  intro p hp
  have h : env51468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51467_51468 : H12AffineEnvironment.transform 15 8322 env51467 = env51468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env51467 == env51468) = true)

theorem identity51468 : scanCanonicalize (H12AffineFastState.compose env51468 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound51468 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env51469 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,8322,5392,10281,1025,136,12572,169,8476,8582,8328,16,10509,13341,12557,10400,9345,8492,257,8492,13324,9092]

theorem envBound51469 : H12AffineFastState.Bounded env51469 := by
  intro p hp
  have h : env51469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51468_51469 : H12AffineEnvironment.transform 17 10281 env51468 = env51469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51468 == env51469) = true)

theorem identity51469 : scanCanonicalize (H12AffineFastState.compose env51469 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound51469 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51470 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,8192,12692,137,8322,4232,10281,409,136,12572,169,8476,8582,8328,16,10509,12677,12557,10400,8473,8492,257,8492,12692,9092]

theorem envBound51470 : H12AffineFastState.Bounded env51470 := by
  intro p hp
  have h : env51470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51469_51470 : H12AffineEnvironment.transform 9 408 env51469 = env51470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env51469 == env51470) = true)

theorem identity51470 : scanCanonicalize (H12AffineFastState.compose env51470 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound51470 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51471 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2493,8192,10281,137,8322,2357,10281,409,136,10401,169,8476,8582,8328,16,10509,10296,10416,10400,8473,8492,257,8492,10281,9092]

theorem envBound51471 : H12AffineFastState.Bounded env51471 := by
  intro p hp
  have h : env51471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51470_51471 : H12AffineEnvironment.transform 11 2493 env51470 = env51471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env51470 == env51471) = true)

theorem identity51471 : scanCanonicalize (H12AffineFastState.compose env51471 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound51471 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51472 : List Nat := [2,4,8,16,32,16,128,173,512,53,2048,2064,8192,10281,137,8322,2200,10281,52,136,10401,169,8369,8235,8328,16,10400,10296,10416,10400,8372,8321,172,8321,10281,8745]

theorem envBound51472 : H12AffineFastState.Bounded env51472 := by
  intro p hp
  have h : env51472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51471_51472 : H12AffineEnvironment.transform 7 173 env51471 = env51472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51471 == env51472) = true)

theorem identity51472 : scanCanonicalize (H12AffineFastState.compose env51472 (packedSelected [0,2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound51472 : packedSelected [0,2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env51473 : List Nat := [2,4,8,16,32,16,128,173,512,53,560,544,8192,8729,137,8322,680,8729,52,136,8849,169,8369,8235,8328,16,8848,8712,8832,8848,8372,8321,172,8321,8729,8745]

theorem envBound51473 : H12AffineFastState.Bounded env51473 := by
  intro p hp
  have h : env51473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51472_51473 : H12AffineEnvironment.transform 10 560 env51472 = env51473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env51472 == env51473) = true)

theorem identity51473 : scanCanonicalize (H12AffineFastState.compose env51473 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound51473 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env51474 : List Nat := [2,4,8,16,32,16,41,4,512,53,560,544,8192,8729,32,8235,513,8729,52,33,8760,0,8216,8235,8225,16,8761,8712,8745,8761,8221,8232,5,8232,8729,8745]

theorem envBound51474 : H12AffineFastState.Bounded env51474 := by
  intro p hp
  have h : env51474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51473_51474 : H12AffineEnvironment.transform 6 41 env51473 = env51474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env51473 == env51474) = true)

def env51475 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,262144,1025,29829,2097152,272512,2101249,95496,8328,17,2177170,2098432,17665,2450714,2102685,2373656,257,21792,16385,2175515]

theorem envBound51475 : H12AffineFastState.Bounded env51475 := by
  intro p hp
  have h : env51475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51464_51475 : H12AffineEnvironment.transform 5 17 env51464 = env51475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51464 == env51475) = true)

theorem identity51475 : scanCanonicalize (H12AffineFastState.compose env51475 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 70046) := by decide +kernel

theorem selectedBound51475 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51476 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,262144,1025,29829,70046,272512,65951,95496,8328,17,10508,70814,17665,291972,66563,338310,257,21792,16385,9093]

theorem envBound51476 : H12AffineFastState.Bounded env51476 := by
  intro p hp
  have h : env51476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51475_51476 : H12AffineEnvironment.transform 20 70046 env51475 = env51476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70046 env51475 == env51476) = true)

theorem identity51476 : scanCanonicalize (H12AffineFastState.compose env51476 (packedSelected [0,9,15,22,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound51476 : packedSelected [0,9,15,22,27,38] rootPS < 2^1333 := by decide +kernel

def env51477 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,76079,1025,29829,70046,65967,65951,95496,8328,17,10508,70814,17665,89515,66563,169,257,21792,16385,9093]

theorem envBound51477 : H12AffineFastState.Bounded env51477 := by
  intro p hp
  have h : env51477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51476_51477 : H12AffineEnvironment.transform 17 76079 env51476 = env51477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env51476 == env51477) = true)

theorem identity51477 : scanCanonicalize (H12AffineFastState.compose env51477 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound51477 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env51478 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,30082,13341,23725,1025,29829,25628,29741,29725,138,8328,17,10508,24860,17665,10281,29057,169,257,21792,16385,9093]

theorem envBound51478 : H12AffineFastState.Bounded env51478 := by
  intro p hp
  have h : env51478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51477_51478 : H12AffineEnvironment.transform 15 30082 env51477 = env51478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env51477 == env51478) = true)

theorem identity51478 : scanCanonicalize (H12AffineFastState.compose env51478 (packedSelected [10,12,14,15,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51478 : packedSelected [10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51479 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,16384,29077,28819,12556,22972,272,29076,24845,28988,28940,138,8328,17,10508,24860,16400,10281,29057,169,257,20529,16385,9093]

theorem envBound51479 : H12AffineFastState.Bounded env51479 := by
  intro p hp
  have h : env51479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51478_51479 : H12AffineEnvironment.transform 9 273 env51478 = env51479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51478 == env51479) = true)

theorem identity51479 : scanCanonicalize (H12AffineFastState.compose env51479 (packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound51479 : packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env51480 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,389,16384,20496,20758,4233,22972,272,20497,16520,20665,20617,138,269,17,2185,16537,16400,2476,20484,169,257,20529,16385,512]

theorem envBound51480 : H12AffineFastState.Bounded env51480 := by
  intro p hp
  have h : env51480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51479_51480 : H12AffineEnvironment.transform 12 389 env51479 = env51480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env51479 == env51480) = true)

theorem identity51480 : scanCanonicalize (H12AffineFastState.compose env51480 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound51480 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env51481 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,389,4541,429,171,4233,2049,272,428,4405,260,308,138,269,17,2185,4388,4525,2476,441,169,257,396,4540,512]

theorem envBound51481 : H12AffineFastState.Bounded env51481 := by
  intro p hp
  have h : env51481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51480_51481 : H12AffineEnvironment.transform 13 4541 env51480 = env51481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env51480 == env51481) = true)

theorem identity51481 : scanCanonicalize (H12AffineFastState.compose env51481 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51481 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51482 : List Nat := [2,4,8,16,32,17,128,5,512,20,2048,4096,128,4280,168,171,4233,2049,21,169,4144,1,49,138,8,17,2185,4129,4264,2217,188,169,4,137,4281,512]

theorem envBound51482 : H12AffineFastState.Bounded env51482 := by
  intro p hp
  have h : env51482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51481_51482 : H12AffineEnvironment.transform 7 5 env51481 = env51482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51481 == env51482) = true)

theorem identity51482 : scanCanonicalize (H12AffineFastState.compose env51482 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound51482 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51483 : List Nat := [2,4,8,16,32,17,40,5,512,20,2048,4096,40,4112,0,3,4129,2049,21,1,4144,1,49,34,8,17,2081,4129,4096,2049,20,1,4,33,4113,512]

theorem envBound51483 : H12AffineFastState.Bounded env51483 := by
  intro p hp
  have h : env51483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51482_51483 : H12AffineEnvironment.transform 6 40 env51482 = env51483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env51482 == env51483) = true)

theorem identity51483 : scanCanonicalize (H12AffineFastState.compose env51483 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2623) := by decide +kernel

theorem selectedBound51483 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51484 : List Nat := [2,4,8,16,32,17,40,5,512,20,2048,2623,40,2607,0,3,2590,2049,21,1,2575,1,49,34,8,17,2081,2590,2623,2049,20,1,4,33,2606,512]

theorem envBound51484 : H12AffineFastState.Bounded env51484 := by
  intro p hp
  have h : env51484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51483_51484 : H12AffineEnvironment.transform 11 2623 env51483 = env51484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2623 env51483 == env51484) = true)

theorem identity51484 : scanCanonicalize (H12AffineFastState.compose env51484 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound51484 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env51485 : List Nat := [2,4,8,16,32,17,40,5,46,20,2048,2065,40,2049,0,3,2096,2049,21,1,2081,1,49,34,8,17,2081,2096,2065,2049,20,1,4,33,2048,46]

theorem envBound51485 : H12AffineFastState.Bounded env51485 := by
  intro p hp
  have h : env51485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51484_51485 : H12AffineEnvironment.transform 8 46 env51484 = env51485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env51484 == env51485) = true)

theorem identity51485 : scanCanonicalize (H12AffineFastState.compose env51485 (packedSelected [0,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51485 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env51486 : List Nat := [2,4,8,16,1,17,9,5,15,20,2048,2065,9,2049,0,3,2065,2049,21,1,2048,1,16,3,8,17,2048,2065,2065,2049,20,1,4,0,2048,15]

theorem envBound51486 : H12AffineFastState.Bounded env51486 := by
  intro p hp
  have h : env51486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51485_51486 : H12AffineEnvironment.transform 4 1 env51485 = env51486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51485 == env51486) = true)

def env51487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177218,2098513,17665,2462110,2102685,2411677,257,21792,46213,2175562]

theorem envBound51487 : H12AffineFastState.Bounded env51487 := by
  intro p hp
  have h : env51487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51462_51487 : H12AffineEnvironment.transform 21 272513 env51462 = env51487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51462 == env51487) = true)

theorem identity51487 : scanCanonicalize (H12AffineFastState.compose env51487 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound51487 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,58516,272513,62660,98781,8328,64,121942,57797,17665,357642,61705,272393,257,21792,46213,120542]

theorem envBound51488 : H12AffineFastState.Bounded env51488 := by
  intro p hp
  have h : env51488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51487_51488 : H12AffineEnvironment.transform 20 58516 env51487 = env51488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env51487 == env51488) = true)

def env51489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,10280,1025,32769,58516,169,62660,98781,8328,64,121942,57797,17665,89378,61705,33,257,21792,46213,120542]

theorem envBound51489 : H12AffineFastState.Bounded env51489 := by
  intro p hp
  have h : env51489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51488_51489 : H12AffineEnvironment.transform 17 10280 env51488 = env51489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51488 == env51489) = true)

theorem identity51489 : scanCanonicalize (H12AffineFastState.compose env51489 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound51489 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,82382,10280,1025,8660,17729,169,21777,73736,8328,64,97667,16400,17665,89378,20700,33,257,21792,5456,96011]

theorem envBound51490 : H12AffineFastState.Bounded env51490 := by
  intro p hp
  have h : env51490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51489_51490 : H12AffineEnvironment.transform 14 8661 env51489 = env51490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env51489 == env51490) = true)

theorem identity51490 : scanCanonicalize (H12AffineFastState.compose env51490 (packedSelected [16,19,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound51490 : packedSelected [16,19,20,26] rootPS < 2^1333 := by decide +kernel

def env51491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,24909,10280,1025,8660,17729,169,21777,139,8328,64,23808,16400,17665,32161,20700,33,257,21792,5456,22408]

theorem envBound51491 : H12AffineFastState.Bounded env51491 := by
  intro p hp
  have h : env51491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51490_51491 : H12AffineEnvironment.transform 15 8323 env51490 = env51491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env51490 == env51491) = true)

theorem identity51491 : scanCanonicalize (H12AffineFastState.compose env51491 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound51491 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env51492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8323,13508,10280,1025,8660,4296,169,152,139,8328,64,2185,5529,4232,10280,1365,33,257,169,5456,513]

theorem envBound51492 : H12AffineFastState.Bounded env51492 := by
  intro p hp
  have h : env51492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51491_51492 : H12AffineEnvironment.transform 13 5513 env51491 = env51492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env51491 == env51492) = true)

theorem identity51492 : scanCanonicalize (H12AffineFastState.compose env51492 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51492 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13389,10280,1025,8541,4161,32,17,2,8193,64,2048,5392,4097,10280,1365,33,257,32,5456,513]

theorem envBound51493 : H12AffineFastState.Bounded env51493 := by
  intro p hp
  have h : env51493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51492_51493 : H12AffineEnvironment.transform 6 9 env51492 = env51493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51492 == env51493) = true)

theorem identity51493 : scanCanonicalize (H12AffineFastState.compose env51493 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51493 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51494 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,262,5441,2340,1025,81,4161,32,17,2,269,64,2048,5392,4097,2340,1365,33,257,32,5456,513]

theorem envBound51494 : H12AffineFastState.Bounded env51494 := by
  intro p hp
  have h : env51494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51493_51494 : H12AffineEnvironment.transform 12 268 env51493 = env51494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51493 == env51494) = true)

theorem identity51494 : scanCanonicalize (H12AffineFastState.compose env51494 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound51494 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51495 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,805,268,1573,80,262,1636,2340,1025,81,868,32,17,2,269,64,2048,1589,804,2340,1365,33,257,32,1653,513]

theorem envBound51495 : H12AffineFastState.Bounded env51495 := by
  intro p hp
  have h : env51495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51494_51495 : H12AffineEnvironment.transform 11 805 env51494 = env51495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env51494 == env51495) = true)

theorem identity51495 : scanCanonicalize (H12AffineFastState.compose env51495 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51495 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51496 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,773,268,1541,80,262,1604,2308,1025,81,836,0,17,2,269,64,2048,1557,772,2308,1365,1,257,0,1621,513]

theorem envBound51496 : H12AffineFastState.Bounded env51496 := by
  intro p hp
  have h : env51496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51495_51496 : H12AffineEnvironment.transform 4 0 env51495 = env51496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51495 == env51496) = true)

theorem identity51496 : scanCanonicalize (H12AffineFastState.compose env51496 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound51496 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51497 : List Nat := [2,4,8,16,0,64,9,256,341,1024,2048,80,268,1360,80,262,1297,2308,1025,81,17,0,17,2,269,64,2048,1344,81,2308,1365,1,257,0,1280,340]

theorem envBound51497 : H12AffineFastState.Bounded env51497 := by
  intro p hp
  have h : env51497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51496_51497 : H12AffineEnvironment.transform 8 341 env51496 = env51497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env51496 == env51497) = true)

theorem identity51497 : scanCanonicalize (H12AffineFastState.compose env51497 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51497 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51498 : List Nat := [2,4,8,16,0,64,9,256,341,20,2048,80,268,324,80,262,261,2308,21,81,17,0,17,2,269,64,2048,340,81,2308,321,1,257,0,276,340]

theorem envBound51498 : H12AffineFastState.Bounded env51498 := by
  intro p hp
  have h : env51498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51497_51498 : H12AffineEnvironment.transform 9 20 env51497 = env51498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51497 == env51498) = true)

def env51499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,10281,1025,32769,58516,168,62660,98781,8328,64,121942,57797,17665,89379,61705,32,257,21792,46213,120542]

theorem envBound51499 : H12AffineFastState.Bounded env51499 := by
  intro p hp
  have h : env51499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51488_51499 : H12AffineEnvironment.transform 17 10281 env51488 = env51499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51488 == env51499) = true)

theorem identity51499 : scanCanonicalize (H12AffineFastState.compose env51499 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound51499 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51500 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,32768,65536,82382,10281,236,32769,57465,168,61481,98781,8328,64,121019,57797,16876,88526,61705,32,257,20941,45160,119347]

theorem envBound51500 : H12AffineFastState.Bounded env51500 := by
  intro p hp
  have h : env51500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51499_51500 : H12AffineEnvironment.transform 9 237 env51499 = env51500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env51499 == env51500) = true)

theorem identity51500 : scanCanonicalize (H12AffineFastState.compose env51500 (packedSelected [1,3,5,15,26,28,38] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound51500 : packedSelected [1,3,5,15,26,28,38] rootPS < 2^1333 := by decide +kernel

def env51501 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,4296,32768,65536,69894,10281,236,32769,45233,168,41185,98781,8328,64,100467,45325,4388,67846,41409,32,257,261,45160,99067]

theorem envBound51501 : H12AffineFastState.Bounded env51501 := by
  intro p hp
  have h : env51501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51500_51501 : H12AffineEnvironment.transform 13 4296 env51500 = env51501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env51500 == env51501) = true)

theorem identity51501 : scanCanonicalize (H12AffineFastState.compose env51501 (packedSelected [2,4,6,10,11,12,15,16,19,22,23,26,31] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound51501 : packedSelected [2,4,6,10,11,12,15,16,19,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env51502 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,32768,65536,69894,2185,236,32769,36881,168,32833,98781,40,64,100467,37293,4388,67846,33121,32,257,261,37064,99067]

theorem envBound51502 : H12AffineFastState.Bounded env51502 := by
  intro p hp
  have h : env51502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51501_51502 : H12AffineEnvironment.transform 12 160 env51501 = env51502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env51501 == env51502) = true)

theorem identity51502 : scanCanonicalize (H12AffineFastState.compose env51502 (packedSelected [0,1,2,3,5,6,7,8,10,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51502 : packedSelected [0,1,2,3,5,6,7,8,10,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51503 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,32768,343,4177,2185,236,32769,36881,168,32833,32906,40,64,35108,37293,4388,2129,33121,32,257,261,37064,33708]

theorem envBound51503 : H12AffineFastState.Bounded env51503 := by
  intro p hp
  have h : env51503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51502_51503 : H12AffineEnvironment.transform 15 343 env51502 = env51503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51502 == env51503) = true)

theorem identity51503 : scanCanonicalize (H12AffineFastState.compose env51503 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound51503 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env51504 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,160,4296,429,343,4177,2185,236,428,4540,168,492,295,40,64,2185,4096,4388,2129,204,32,257,261,4453,513]

theorem envBound51504 : H12AffineFastState.Bounded env51504 := by
  intro p hp
  have h : env51504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51503_51504 : H12AffineEnvironment.transform 14 429 env51503 = env51504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env51503 == env51504) = true)

theorem identity51504 : scanCanonicalize (H12AffineFastState.compose env51504 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51504 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51505 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,4096,160,4296,137,115,4177,2185,236,136,4248,168,200,3,40,64,2185,4096,4096,2129,204,32,37,33,4161,513]

theorem envBound51505 : H12AffineFastState.Bounded env51505 := by
  intro p hp
  have h : env51505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51504_51505 : H12AffineEnvironment.transform 7 36 env51504 = env51505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51504 == env51505) = true)

theorem identity51505 : scanCanonicalize (H12AffineFastState.compose env51505 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound51505 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51506 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,121,4113,80,115,4177,2128,53,81,4161,113,17,3,40,64,2128,4096,4096,2129,21,32,37,33,4161,513]

theorem envBound51506 : H12AffineFastState.Bounded env51506 := by
  intro p hp
  have h : env51506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51505_51506 : H12AffineEnvironment.transform 6 89 env51505 = env51506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env51505 == env51506) = true)

theorem identity51506 : scanCanonicalize (H12AffineFastState.compose env51506 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound51506 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51507 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,592,121,577,80,115,513,2128,53,81,529,113,17,3,40,64,2128,592,592,2129,21,32,37,33,529,513]

theorem envBound51507 : H12AffineFastState.Bounded env51507 := by
  intro p hp
  have h : env51507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51506_51507 : H12AffineEnvironment.transform 11 592 env51506 = env51507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env51506 == env51507) = true)

theorem identity51507 : scanCanonicalize (H12AffineFastState.compose env51507 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51507 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51508 : List Nat := [2,4,8,16,32,49,40,36,512,52,2048,545,8,560,33,2,513,2081,53,32,529,0,17,3,40,49,2081,545,545,2080,21,32,37,33,529,513]

theorem envBound51508 : H12AffineFastState.Bounded env51508 := by
  intro p hp
  have h : env51508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51507_51508 : H12AffineEnvironment.transform 5 49 env51507 = env51508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51507 == env51508) = true)

theorem identity51508 : scanCanonicalize (H12AffineFastState.compose env51508 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound51508 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51509 : List Nat := [2,4,8,16,32,49,40,36,512,52,16,545,8,560,33,2,513,49,53,32,529,0,17,3,40,49,49,545,545,48,21,32,37,33,529,513]

theorem envBound51509 : H12AffineFastState.Bounded env51509 := by
  intro p hp
  have h : env51509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51508_51509 : H12AffineEnvironment.transform 10 16 env51508 = env51509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env51508 == env51509) = true)

theorem identity51509 : scanCanonicalize (H12AffineFastState.compose env51509 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51509 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51510 : List Nat := [2,4,8,16,32,49,40,36,0,52,16,33,8,48,33,2,1,49,53,32,17,0,17,3,40,49,49,33,33,48,21,32,37,33,17,1]

theorem envBound51510 : H12AffineFastState.Bounded env51510 := by
  intro p hp
  have h : env51510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51509_51510 : H12AffineEnvironment.transform 8 0 env51509 = env51510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51509 == env51510) = true)

def env51511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623299,2098512,17664,2462111,2102685,6349853,257,21792,46213,2175562]

theorem envBound51511 : H12AffineFastState.Bounded env51511 := by
  intro p hp
  have h : env51511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51461_51511 : H12AffineEnvironment.transform 22 2101329 env51461 = env51511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env51461 == env51511) = true)

def env51512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177219,2098512,17664,2462111,2102685,2411677,257,21792,46213,2175562]

theorem envBound51512 : H12AffineFastState.Bounded env51512 := by
  intro p hp
  have h : env51512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51511_51512 : H12AffineEnvironment.transform 21 272512 env51511 = env51512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51511 == env51512) = true)

def env51513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272392,2101329,98644,8192,64,2177099,2098512,17664,2461975,2102549,2411541,257,21792,46093,2175562]

theorem envBound51513 : H12AffineFastState.Bounded env51513 := by
  intro p hp
  have h : env51513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51512_51513 : H12AffineEnvironment.transform 6 8 env51512 = env51513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51512 == env51513) = true)

theorem identity51513 : scanCanonicalize (H12AffineFastState.compose env51513 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound51513 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,12572,272392,8525,98644,8192,64,67927,13388,17664,368651,9225,326921,257,21792,46093,66390]

theorem envBound51514 : H12AffineFastState.Bounded env51514 := by
  intro p hp
  have h : env51514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51513_51514 : H12AffineEnvironment.transform 20 12572 env51513 = env51514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env51513 == env51514) = true)

theorem identity51514 : scanCanonicalize (H12AffineFastState.compose env51514 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound51514 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57677,262144,1025,32769,12572,272392,8525,8543,8192,64,43356,13388,17664,262144,9225,326921,257,21792,46093,41821]

theorem envBound51515 : H12AffineFastState.Bounded env51515 := by
  intro p hp
  have h : env51515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51514_51515 : H12AffineEnvironment.transform 15 40971 env51514 = env51515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env51514 == env51515) = true)

theorem identity51515 : scanCanonicalize (H12AffineFastState.compose env51515 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound51515 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env51516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57677,43049,1025,32769,12572,32801,8525,8543,8192,64,43356,13388,17664,43049,9225,21792,257,21792,46093,41821]

theorem envBound51516 : H12AffineFastState.Bounded env51516 := by
  intro p hp
  have h : env51516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51515_51516 : H12AffineEnvironment.transform 17 43049 env51515 = env51516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env51515 == env51516) = true)

theorem identity51516 : scanCanonicalize (H12AffineFastState.compose env51516 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51516 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env51517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33110,49168,35188,1025,32769,4161,32801,16,2,349,64,34817,5393,17664,35188,1364,21792,257,21792,38224,33280]

theorem envBound51517 : H12AffineFastState.Bounded env51517 := by
  intro p hp
  have h : env51517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51516_51517 : H12AffineEnvironment.transform 12 349 env51516 = env51517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51516 == env51517) = true)

theorem identity51517 : scanCanonicalize (H12AffineFastState.compose env51517 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound51517 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21540,21874,5172,23888,1025,21541,4161,21509,16,2,349,64,23589,5393,17664,23888,1364,21792,257,21792,16756,22052]

theorem envBound51518 : H12AffineFastState.Bounded env51518 := by
  intro p hp
  have h : env51518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51517_51518 : H12AffineEnvironment.transform 14 21540 env51517 = env51518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env51517 == env51518) = true)

theorem identity51518 : scanCanonicalize (H12AffineFastState.compose env51518 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound51518 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env51519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,349,16384,16676,16498,308,18512,1025,16677,1345,16645,16,2,349,64,18725,17,17664,18512,1364,16416,257,16416,16756,17188]

theorem envBound51519 : H12AffineFastState.Bounded env51519 := by
  intro p hp
  have h : env51519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51518_51519 : H12AffineEnvironment.transform 11 1280 env51518 = env51519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env51518 == env51519) = true)

theorem identity51519 : scanCanonicalize (H12AffineFastState.compose env51519 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound51519 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env51520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,349,292,0,342,308,2420,1025,1,1345,33,16,2,349,64,2049,17,1060,2420,1364,260,257,260,80,512]

theorem envBound51520 : H12AffineFastState.Bounded env51520 := by
  intro p hp
  have h : env51520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51519_51520 : H12AffineEnvironment.transform 13 292 env51519 = env51520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env51519 == env51520) = true)

theorem identity51520 : scanCanonicalize (H12AffineFastState.compose env51520 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 884) := by decide +kernel

theorem selectedBound51520 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,884,1280,349,292,0,342,308,512,1025,1,1345,33,16,2,349,64,885,17,1060,512,1364,260,257,260,80,512]

theorem envBound51521 : H12AffineFastState.Bounded env51521 := by
  intro p hp
  have h : env51521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51520_51521 : H12AffineEnvironment.transform 10 884 env51520 = env51521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 884 env51520 == env51521) = true)

theorem identity51521 : scanCanonicalize (H12AffineFastState.compose env51521 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51521 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51522 : List Nat := [2,4,8,16,32,49,8,256,512,1024,773,1280,300,292,0,295,308,512,1025,1,1328,33,16,2,300,49,772,17,1060,512,1317,260,257,260,33,512]

theorem envBound51522 : H12AffineFastState.Bounded env51522 := by
  intro p hp
  have h : env51522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51521_51522 : H12AffineEnvironment.transform 5 49 env51521 = env51522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51521 == env51522) = true)

theorem identity51522 : scanCanonicalize (H12AffineFastState.compose env51522 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound51522 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51523 : List Nat := [2,4,8,16,32,49,8,256,512,564,773,820,300,292,0,295,308,512,565,1,772,33,16,2,300,49,772,17,528,512,785,260,257,260,33,512]

theorem envBound51523 : H12AffineFastState.Bounded env51523 := by
  intro p hp
  have h : env51523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51522_51523 : H12AffineEnvironment.transform 9 564 env51522 = env51523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env51522 == env51523) = true)

theorem identity51523 : scanCanonicalize (H12AffineFastState.compose env51523 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51523 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51524 : List Nat := [2,4,8,11,32,42,8,256,512,559,773,815,300,292,0,295,303,512,558,1,772,33,11,2,300,42,772,10,523,512,778,260,257,260,33,512]

theorem envBound51524 : H12AffineFastState.Bounded env51524 := by
  intro p hp
  have h : env51524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51523_51524 : H12AffineEnvironment.transform 3 11 env51523 = env51524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51523 == env51524) = true)

theorem identity51524 : scanCanonicalize (H12AffineFastState.compose env51524 (packedSelected [2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51524 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env51525 : List Nat := [2,4,8,11,32,42,8,256,0,47,261,303,300,292,0,295,303,0,46,1,260,33,11,2,300,42,260,10,11,0,266,260,257,260,33,0]

theorem envBound51525 : H12AffineFastState.Bounded env51525 := by
  intro p hp
  have h : env51525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51524_51525 : H12AffineEnvironment.transform 8 0 env51524 = env51525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51524 == env51525) = true)

theorem identity51525 : scanCanonicalize (H12AffineFastState.compose env51525 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51525 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51526 : List Nat := [2,4,8,11,11,1,8,256,0,4,261,260,263,271,0,268,260,0,5,1,260,10,11,2,263,1,260,10,11,0,266,260,257,260,10,0]

theorem envBound51526 : H12AffineFastState.Bounded env51526 := by
  intro p hp
  have h : env51526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51525_51526 : H12AffineEnvironment.transform 4 11 env51525 = env51526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51525 == env51526) = true)

theorem identity51526 : scanCanonicalize (H12AffineFastState.compose env51526 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51526 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51527 : List Nat := [2,4,1,2,2,1,1,256,0,4,261,260,263,262,0,261,260,0,5,1,260,3,2,2,263,1,260,3,2,0,259,260,257,260,3,0]

theorem envBound51527 : H12AffineFastState.Bounded env51527 := by
  intro p hp
  have h : env51527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51526_51527 : H12AffineEnvironment.transform 2 1 env51526 = env51527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51526 == env51527) = true)

theorem identity51527 : scanCanonicalize (H12AffineFastState.compose env51527 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound51527 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51528 : List Nat := [2,4,1,2,2,1,1,2,0,4,7,6,5,4,0,7,6,0,5,1,6,3,2,2,5,1,6,3,2,0,1,6,3,6,3,0]

theorem envBound51528 : H12AffineFastState.Bounded env51528 := by
  intro p hp
  have h : env51528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51527_51528 : H12AffineEnvironment.transform 7 2 env51527 = env51528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env51527 == env51528) = true)

theorem identity51528 : scanCanonicalize (H12AffineFastState.compose env51528 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51528 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env51529 : List Nat := [0,4,1,0,0,1,1,0,0,4,5,4,5,4,0,5,4,0,5,1,4,1,0,0,5,1,4,1,0,0,1,4,1,4,1,0]

theorem envBound51529 : H12AffineFastState.Bounded env51529 := by
  intro p hp
  have h : env51529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51528_51529 : H12AffineEnvironment.transform 0 0 env51528 = env51529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51528 == env51529) = true)

def env51530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272393,2101329,98645,8193,64,2177098,2098512,17664,2461974,2102548,2411540,257,21792,46092,2175562]

theorem envBound51530 : H12AffineFastState.Bounded env51530 := by
  intro p hp
  have h : env51530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51512_51530 : H12AffineEnvironment.transform 6 9 env51512 = env51530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51512 == env51530) = true)

def env51531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,272393,17,98645,8193,64,75786,5392,17664,360790,1364,318548,257,21792,46092,74250]

theorem envBound51531 : H12AffineFastState.Bounded env51531 := by
  intro p hp
  have h : env51531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51530_51531 : H12AffineEnvironment.transform 20 4160 env51530 = env51531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51530 == env51531) = true)

theorem identity51531 : scanCanonicalize (H12AffineFastState.compose env51531 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4160,33,17,98645,8193,64,75786,5392,17664,108926,1364,62588,257,21792,46092,74250]

theorem envBound51532 : H12AffineFastState.Bounded env51532 := by
  intro p hp
  have h : env51532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51531_51532 : H12AffineEnvironment.transform 17 10280 env51531 = env51532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51531 == env51532) = true)

theorem identity51532 : scanCanonicalize (H12AffineFastState.compose env51532 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51532 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1025,32769,4160,33,17,98645,349,64,67926,5392,17664,100386,1364,54560,257,21792,38224,66390]

theorem envBound51533 : H12AffineFastState.Bounded env51533 := by
  intro p hp
  have h : env51533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51532_51533 : H12AffineEnvironment.transform 12 348 env51532 = env51533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51532 == env51533) = true)

theorem identity51533 : scanCanonicalize (H12AffineFastState.compose env51533 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51533 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,16400,2420,1025,32769,4160,33,17,32770,349,64,2049,5392,17664,35189,1364,54560,257,21792,38224,513]

theorem envBound51534 : H12AffineFastState.Bounded env51534 := by
  intro p hp
  have h : env51534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51533_51534 : H12AffineEnvironment.transform 15 343 env51533 = env51534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51533 == env51534) = true)

theorem identity51534 : scanCanonicalize (H12AffineFastState.compose env51534 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound51534 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,343,16400,2420,1025,21761,4160,33,17,21762,349,64,2049,5392,17664,23669,1364,32,257,21792,16464,513]

theorem envBound51535 : H12AffineFastState.Bounded env51535 := by
  intro p hp
  have h : env51535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51534_51535 : H12AffineEnvironment.transform 14 21760 env51534 = env51535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env51534 == env51535) = true)

theorem identity51535 : scanCanonicalize (H12AffineFastState.compose env51535 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51535 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51536 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,263,16400,2340,1025,21761,4112,33,17,21762,269,16,2049,5392,17664,23589,1284,32,257,21792,16384,513]

theorem envBound51536 : H12AffineFastState.Bounded env51536 := by
  intro p hp
  have h : env51536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51535_51536 : H12AffineEnvironment.transform 5 16 env51535 = env51536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51535 == env51536) = true)

theorem identity51536 : scanCanonicalize (H12AffineFastState.compose env51536 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound51536 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51537 : List Nat := [2,4,8,16,32,16,9,256,308,1024,2048,4096,268,16384,21760,263,16400,2340,1025,21761,4112,33,17,21762,269,16,2049,5392,17664,23589,1284,32,257,21792,16384,309]

theorem envBound51537 : H12AffineFastState.Bounded env51537 := by
  intro p hp
  have h : env51537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51536_51537 : H12AffineEnvironment.transform 8 308 env51536 = env51537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env51536 == env51537) = true)

theorem identity51537 : scanCanonicalize (H12AffineFastState.compose env51537 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound51537 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env51538 : List Nat := [2,4,8,16,32,16,9,256,308,1024,2048,4096,268,2308,7172,263,2324,2340,1025,7173,4112,33,17,7174,269,16,2049,5392,3076,5409,1284,32,257,7204,2308,309]

theorem envBound51538 : H12AffineFastState.Bounded env51538 := by
  intro p hp
  have h : env51538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51537_51538 : H12AffineEnvironment.transform 13 2308 env51537 = env51538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env51537 == env51538) = true)

theorem identity51538 : scanCanonicalize (H12AffineFastState.compose env51538 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound51538 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env51539 : List Nat := [2,4,8,16,32,16,9,256,308,1024,1029,4096,268,1281,4097,263,1297,1313,1025,4096,4112,33,17,4099,269,16,1028,5392,1,5409,1284,32,257,4129,1281,309]

theorem envBound51539 : H12AffineFastState.Bounded env51539 := by
  intro p hp
  have h : env51539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51538_51539 : H12AffineEnvironment.transform 10 1029 env51538 = env51539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env51538 == env51539) = true)

theorem identity51539 : scanCanonicalize (H12AffineFastState.compose env51539 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound51539 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env51540 : List Nat := [2,4,8,16,32,16,9,256,308,1024,1029,0,268,1281,1,263,1297,1313,1025,0,16,33,17,3,269,16,1028,1296,1,1313,1284,32,257,33,1281,309]

theorem envBound51540 : H12AffineFastState.Bounded env51540 := by
  intro p hp
  have h : env51540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51539_51540 : H12AffineEnvironment.transform 11 0 env51539 = env51540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env51539 == env51540) = true)

theorem identity51540 : scanCanonicalize (H12AffineFastState.compose env51540 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51541 : List Nat := [2,4,8,16,32,16,9,21,33,1024,1029,0,25,1044,1,18,1028,1076,1025,0,16,33,17,3,24,16,1028,1029,1,1076,1041,32,20,33,1044,32]

theorem envBound51541 : H12AffineFastState.Bounded env51541 := by
  intro p hp
  have h : env51541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51540_51541 : H12AffineEnvironment.transform 7 21 env51540 = env51541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51540 == env51541) = true)

theorem identity51541 : scanCanonicalize (H12AffineFastState.compose env51541 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51541 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51542 : List Nat := [2,4,8,16,32,16,9,21,33,21,16,0,25,1,1,18,17,33,20,0,16,33,17,3,24,16,17,16,1,33,4,32,20,33,1,32]

theorem envBound51542 : H12AffineFastState.Bounded env51542 := by
  intro p hp
  have h : env51542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51541_51542 : H12AffineEnvironment.transform 9 21 env51541 = env51542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51541 == env51542) = true)

theorem identity51542 : scanCanonicalize (H12AffineFastState.compose env51542 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51543 : List Nat := [2,4,8,0,32,0,9,5,33,5,0,0,9,1,1,2,1,33,4,0,0,33,1,3,8,0,1,0,1,33,4,32,4,33,1,32]

theorem envBound51543 : H12AffineFastState.Bounded env51543 := by
  intro p hp
  have h : env51543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51542_51543 : H12AffineEnvironment.transform 3 0 env51542 = env51543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51542 == env51543) = true)

theorem identity51543 : scanCanonicalize (H12AffineFastState.compose env51543 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51544 : List Nat := [2,4,8,0,10,0,9,5,11,5,0,0,9,1,1,2,1,11,4,0,0,11,1,3,8,0,1,0,1,11,4,10,4,11,1,10]

theorem envBound51544 : H12AffineFastState.Bounded env51544 := by
  intro p hp
  have h : env51544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51543_51544 : H12AffineEnvironment.transform 4 10 env51543 = env51544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51543 == env51544) = true)

theorem identity51544 : scanCanonicalize (H12AffineFastState.compose env51544 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51544 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51545 : List Nat := [2,4,3,0,1,0,2,5,0,5,0,0,2,1,1,2,1,0,4,0,0,0,1,3,3,0,1,0,1,0,4,1,4,0,1,1]

theorem envBound51545 : H12AffineFastState.Bounded env51545 := by
  intro p hp
  have h : env51545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51544_51545 : H12AffineEnvironment.transform 2 3 env51544 = env51545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51544 == env51545) = true)

def env51546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272393,16,98645,8193,64,75787,5393,17664,360791,1365,318549,257,21792,46092,74251]

theorem envBound51546 : H12AffineFastState.Bounded env51546 := by
  intro p hp
  have h : env51546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51530_51546 : H12AffineEnvironment.transform 20 4161 env51530 = env51546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51530 == env51546) = true)

theorem identity51546 : scanCanonicalize (H12AffineFastState.compose env51546 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound51546 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,56357,1025,32769,4161,62508,16,98645,8193,64,75787,5393,17664,89458,1365,112,257,21792,46092,74251]

theorem envBound51547 : H12AffineFastState.Bounded env51547 := by
  intro p hp
  have h : env51547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51546_51547 : H12AffineEnvironment.transform 17 56357 env51546 = env51547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env51546 == env51547) = true)

theorem identity51547 : scanCanonicalize (H12AffineFastState.compose env51547 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound51547 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env51548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62810,46109,56357,1025,32769,4161,62508,16,29711,8193,64,56657,5393,17664,43048,1365,112,257,21792,46092,55121]

theorem envBound51548 : H12AffineFastState.Bounded env51548 := by
  intro p hp
  have h : env51548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51547_51548 : H12AffineEnvironment.transform 15 62810 env51547 = env51548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env51547 == env51548) = true)

theorem identity51548 : scanCanonicalize (H12AffineFastState.compose env51548 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound51548 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env51549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,8202,24909,2421,1025,21841,4161,8572,16,29711,8193,64,2049,5393,17664,32120,1365,112,257,21792,24924,513]

theorem envBound51549 : H12AffineFastState.Bounded env51549 := by
  intro p hp
  have h : env51549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51548_51549 : H12AffineEnvironment.transform 14 21840 env51548 = env51549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env51548 == env51549) = true)

theorem identity51549 : scanCanonicalize (H12AffineFastState.compose env51549 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51549 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,342,16401,2421,1025,21841,4161,32,16,21843,349,64,2049,5393,17664,23588,1365,112,257,21792,16384,513]

theorem envBound51550 : H12AffineFastState.Bounded env51550 := by
  intro p hp
  have h : env51550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51549_51550 : H12AffineEnvironment.transform 12 348 env51549 = env51550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51549 == env51550) = true)

theorem identity51550 : scanCanonicalize (H12AffineFastState.compose env51550 (packedSelected [3,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound51550 : packedSelected [3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env51551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,348,16384,19556,342,16401,2421,1025,19557,2421,32,16,19559,349,64,2049,3109,17664,17680,1365,112,257,19476,16384,513]

theorem envBound51551 : H12AffineFastState.Bounded env51551 := by
  intro p hp
  have h : env51551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51550_51551 : H12AffineEnvironment.transform 11 2356 env51550 = env51551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env51550 == env51551) = true)

theorem identity51551 : scanCanonicalize (H12AffineFastState.compose env51551 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51551 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env51552 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,16384,18513,342,16401,2421,52,18512,2421,32,16,18514,349,64,2049,2064,16693,16677,352,112,257,18465,16384,513]

theorem envBound51552 : H12AffineFastState.Bounded env51552 := by
  intro p hp
  have h : env51552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51551_51552 : H12AffineEnvironment.transform 9 53 env51551 = env51552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51551 == env51552) = true)

theorem identity51552 : scanCanonicalize (H12AffineFastState.compose env51552 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound51552 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51553 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,2341,372,342,2356,2421,52,373,2421,32,16,375,349,64,2049,2064,2064,2048,352,112,257,260,2341,513]

theorem envBound51553 : H12AffineFastState.Bounded env51553 := by
  intro p hp
  have h : env51553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51552_51553 : H12AffineEnvironment.transform 13 2341 env51552 = env51553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env51552 == env51553) = true)

theorem identity51553 : scanCanonicalize (H12AffineFastState.compose env51553 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound51553 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51554 : List Nat := [2,4,8,16,32,64,9,256,512,53,292,16,348,1,372,342,16,81,52,373,81,32,16,375,349,64,293,308,308,292,352,112,257,260,1,513]

theorem envBound51554 : H12AffineFastState.Bounded env51554 := by
  intro p hp
  have h : env51554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51553_51554 : H12AffineEnvironment.transform 10 292 env51553 = env51554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env51553 == env51554) = true)

theorem identity51554 : scanCanonicalize (H12AffineFastState.compose env51554 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51554 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51555 : List Nat := [2,4,8,16,32,64,9,37,512,53,1,16,121,1,81,115,16,81,52,80,81,32,16,82,120,64,0,17,17,1,69,112,36,33,1,513]

theorem envBound51555 : H12AffineFastState.Bounded env51555 := by
  intro p hp
  have h : env51555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51554_51555 : H12AffineEnvironment.transform 7 37 env51554 = env51555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51554 == env51555) = true)

theorem identity51555 : scanCanonicalize (H12AffineFastState.compose env51555 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51555 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51556 : List Nat := [2,4,8,16,32,64,9,37,11,53,1,16,121,1,81,115,16,81,52,80,81,32,16,82,120,64,0,17,17,1,69,112,36,33,1,10]

theorem envBound51556 : H12AffineFastState.Bounded env51556 := by
  intro p hp
  have h : env51556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51555_51556 : H12AffineEnvironment.transform 8 11 env51555 = env51556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51555 == env51556) = true)

def env51557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177218,2098512,17664,2462111,2102685,2411676,257,21792,46213,2175562]

theorem envBound51557 : H12AffineFastState.Bounded env51557 := by
  intro p hp
  have h : env51557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51511_51557 : H12AffineEnvironment.transform 21 272513 env51511 = env51557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51511 == env51557) = true)

theorem identity51557 : scanCanonicalize (H12AffineFastState.compose env51557 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound51557 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4160,272513,17,98780,8328,64,75906,5392,17664,360927,1501,318684,257,21792,46213,74250]

theorem envBound51558 : H12AffineFastState.Bounded env51558 := by
  intro p hp
  have h : env51558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51557_51558 : H12AffineEnvironment.transform 20 4160 env51557 = env51558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51557 == env51558) = true)

theorem identity51558 : scanCanonicalize (H12AffineFastState.compose env51558 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51558 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,4160,272513,17,41431,8328,64,2185,5392,17664,303572,1501,318684,257,21792,46213,513]

theorem envBound51559 : H12AffineFastState.Bounded env51559 := by
  intro p hp
  have h : env51559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51558_51559 : H12AffineEnvironment.transform 15 8203 env51558 = env51559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51558 == env51559) = true)

theorem identity51559 : scanCanonicalize (H12AffineFastState.compose env51559 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51559 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env51560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,262144,1025,8540,4160,272513,17,138,8328,64,2185,5392,17664,262281,1501,294273,257,21792,5592,513]

theorem envBound51560 : H12AffineFastState.Bounded env51560 := by
  intro p hp
  have h : env51560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51559_51560 : H12AffineEnvironment.transform 14 8541 env51559 = env51560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51559 == env51560) = true)

theorem identity51560 : scanCanonicalize (H12AffineFastState.compose env51560 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51560 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,10280,1025,8540,4160,169,17,138,8328,64,2185,5392,17664,10401,1501,21929,257,21792,5592,513]

theorem envBound51561 : H12AffineFastState.Bounded env51561 := by
  intro p hp
  have h : env51561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51560_51561 : H12AffineEnvironment.transform 17 10280 env51560 = env51561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51560 == env51561) = true)

theorem identity51561 : scanCanonicalize (H12AffineFastState.compose env51561 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound51561 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,13389,10280,1025,8540,4160,169,17,138,8328,64,2185,5392,4232,10401,1501,33,257,168,5592,513]

theorem envBound51562 : H12AffineFastState.Bounded env51562 := by
  intro p hp
  have h : env51562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51561_51562 : H12AffineEnvironment.transform 13 5512 env51561 = env51562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env51561 == env51562) = true)

theorem identity51562 : scanCanonicalize (H12AffineFastState.compose env51562 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound51562 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env51563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5512,509,171,5357,2184,1025,508,4160,169,17,138,40,64,2185,5392,4232,2049,1501,33,257,168,5592,513]

theorem envBound51563 : H12AffineFastState.Bounded env51563 := by
  intro p hp
  have h : env51563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51562_51563 : H12AffineEnvironment.transform 12 160 env51562 = env51563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env51562 == env51563) = true)

theorem identity51563 : scanCanonicalize (H12AffineFastState.compose env51563 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51563 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,372,34,5220,2049,1025,373,4160,32,17,3,40,64,2048,5392,4097,2049,1364,33,257,33,5457,513]

theorem envBound51564 : H12AffineFastState.Bounded env51564 := by
  intro p hp
  have h : env51564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51563_51564 : H12AffineEnvironment.transform 6 9 env51563 = env51564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51563 == env51564) = true)

theorem identity51564 : scanCanonicalize (H12AffineFastState.compose env51564 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51565 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,0,34,5220,2049,1025,1,4160,32,17,3,40,64,2048,5220,4097,2049,1056,33,117,33,5157,513]

theorem envBound51565 : H12AffineFastState.Bounded env51565 := by
  intro p hp
  have h : env51565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51564_51565 : H12AffineEnvironment.transform 7 116 env51564 = env51565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51564 == env51565) = true)

theorem identity51565 : scanCanonicalize (H12AffineFastState.compose env51565 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound51565 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51566 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1134,4096,41,5237,0,34,5220,1135,1025,1,4160,32,17,3,40,64,1134,5220,4097,1135,1056,33,117,33,5157,513]

theorem envBound51566 : H12AffineFastState.Bounded env51566 := by
  intro p hp
  have h : env51566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51565_51566 : H12AffineEnvironment.transform 10 1134 env51565 = env51566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env51565 == env51566) = true)

theorem identity51566 : scanCanonicalize (H12AffineFastState.compose env51566 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound51566 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51567 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1134,0,41,1141,0,34,1124,1135,1025,1,64,32,17,3,40,64,1134,1124,1,1135,1056,33,117,33,1061,513]

theorem envBound51567 : H12AffineFastState.Bounded env51567 := by
  intro p hp
  have h : env51567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51566_51567 : H12AffineEnvironment.transform 11 0 env51566 = env51567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env51566 == env51567) = true)

theorem identity51567 : scanCanonicalize (H12AffineFastState.compose env51567 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound51567 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51568 : List Nat := [2,4,8,16,32,64,9,116,512,62,80,0,41,75,0,34,90,81,63,1,64,32,17,3,40,64,80,90,1,81,30,33,117,33,27,513]

theorem envBound51568 : H12AffineFastState.Bounded env51568 := by
  intro p hp
  have h : env51568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51567_51568 : H12AffineEnvironment.transform 9 62 env51567 = env51568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env51567 == env51568) = true)

theorem identity51568 : scanCanonicalize (H12AffineFastState.compose env51568 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound51568 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51569 : List Nat := [2,4,8,16,32,58,9,14,512,62,42,0,41,49,0,34,32,43,63,1,58,32,17,3,40,58,42,32,1,43,30,33,15,33,27,513]

theorem envBound51569 : H12AffineFastState.Bounded env51569 := by
  intro p hp
  have h : env51569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51568_51569 : H12AffineEnvironment.transform 5 58 env51568 = env51569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env51568 == env51569) = true)

theorem identity51569 : scanCanonicalize (H12AffineFastState.compose env51569 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51569 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env51570 : List Nat := [2,4,8,16,10,16,9,14,512,20,0,0,3,27,0,8,10,1,21,1,16,10,17,3,2,16,0,10,1,1,30,11,15,11,27,513]

theorem envBound51570 : H12AffineFastState.Bounded env51570 := by
  intro p hp
  have h : env51570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51569_51570 : H12AffineEnvironment.transform 4 10 env51569 = env51570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51569 == env51570) = true)

theorem identity51570 : scanCanonicalize (H12AffineFastState.compose env51570 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51570 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51571 : List Nat := [2,4,8,1,10,1,9,14,512,5,0,0,3,10,0,8,10,1,4,1,1,10,0,3,2,1,0,10,1,1,15,11,15,11,10,513]

theorem envBound51571 : H12AffineFastState.Bounded env51571 := by
  intro p hp
  have h : env51571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51570_51571 : H12AffineEnvironment.transform 3 1 env51570 = env51571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51570 == env51571) = true)

theorem identity51571 : scanCanonicalize (H12AffineFastState.compose env51571 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound51571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51572 : List Nat := [2,4,6,1,4,1,7,0,512,5,0,0,3,4,0,6,4,1,4,1,1,4,0,3,2,1,0,4,1,1,1,5,1,5,4,513]

theorem envBound51572 : H12AffineFastState.Bounded env51572 := by
  intro p hp
  have h : env51572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51571_51572 : H12AffineEnvironment.transform 2 6 env51571 = env51572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env51571 == env51572) = true)

theorem identity51572 : scanCanonicalize (H12AffineFastState.compose env51572 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51572 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51573 : List Nat := [2,0,2,1,0,1,3,0,512,1,0,0,3,0,0,2,0,1,0,1,1,0,0,3,2,1,0,0,1,1,1,1,1,1,0,513]

theorem envBound51573 : H12AffineFastState.Bounded env51573 := by
  intro p hp
  have h : env51573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51572_51573 : H12AffineEnvironment.transform 1 0 env51572 = env51573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51572 == env51573) = true)

theorem identity51573 : scanCanonicalize (H12AffineFastState.compose env51573 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound51573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51574 : List Nat := [2,0,2,1,0,1,3,0,2,1,0,0,3,0,0,2,0,1,0,1,1,0,0,3,2,1,0,0,1,1,1,1,1,1,0,3]

theorem envBound51574 : H12AffineFastState.Bounded env51574 := by
  intro p hp
  have h : env51574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51573_51574 : H12AffineEnvironment.transform 8 2 env51573 = env51574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env51573 == env51574) = true)

def env51575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound51575 : H12AffineFastState.Bounded env51575 := by
  intro p hp
  have h : env51575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50851_51575 : H12AffineEnvironment.transform 25 65 env50851 = env51575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env50851 == env51575) = true)

def env51576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound51576 : H12AffineFastState.Bounded env51576 := by
  intro p hp
  have h : env51576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51575_51576 : H12AffineEnvironment.transform 26 30393344 env51575 = env51576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env51575 == env51576) = true)

def env51577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound51577 : H12AffineFastState.Bounded env51577 := by
  intro p hp
  have h : env51577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51576_51577 : H12AffineEnvironment.transform 18 1024 env51576 = env51577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env51576 == env51577) = true)

theorem identity51577 : scanCanonicalize (H12AffineFastState.compose env51577 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493615) := by decide +kernel

theorem selectedBound51577 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493615,8328,65,14797999,493602,10507600,8830976,10979518,4680047,256,8898562,8858023,10923881]

theorem envBound51578 : H12AffineFastState.Bounded env51578 := by
  intro p hp
  have h : env51578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51577_51578 : H12AffineEnvironment.transform 23 2493615 env51577 = env51578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493615 env51577 == env51578) = true)

def env51579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797999,115150,10507600,8423916,10600786,4268163,256,8487406,8478795,10544773]

theorem envBound51579 : H12AffineFastState.Bounded env51579 := by
  intro p hp
  have h : env51579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51578_51579 : H12AffineEnvironment.transform 17 149996 env51578 = env51579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env51578 == env51579) = true)

def env51580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,8388608,21763,8328,65,12705007,115150,8406288,8423916,8507666,4268163,256,8487406,8478795,8451781]

theorem envBound51580 : H12AffineFastState.Bounded env51580 := by
  intro p hp
  have h : env51580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51579_51580 : H12AffineEnvironment.transform 20 4160 env51579 = env51580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51579 == env51580) = true)

def env51581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,16,21763,8328,65,4316415,115150,17664,35324,119042,4268163,256,98814,90203,63189]

theorem envBound51581 : H12AffineFastState.Bounded env51581 := by
  intro p hp
  have h : env51581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51580_51581 : H12AffineEnvironment.transform 22 16 env51580 = env51581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51580 == env51581) = true)

theorem identity51581 : scanCanonicalize (H12AffineFastState.compose env51581 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound51581 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149996,1024,32769,4160,4194304,16,21763,8328,65,4196384,5393,17664,35324,1501,4256860,256,21793,46212,63189]

theorem envBound51582 : H12AffineFastState.Bounded env51582 := by
  intro p hp
  have h : env51582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51581_51582 : H12AffineEnvironment.transform 15 54495 env51581 = env51582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env51581 == env51582) = true)

def env51583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149860,1024,32769,4160,4194304,16,21763,8192,65,4196384,5393,17664,35188,1365,4256860,256,21793,46092,63069]

theorem envBound51583 : H12AffineFastState.Bounded env51583 := by
  intro p hp
  have h : env51583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51582_51583 : H12AffineEnvironment.transform 6 8 env51582 = env51583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51582 == env51583) = true)

theorem identity51583 : scanCanonicalize (H12AffineFastState.compose env51583 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound51583 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,35189,1024,32769,4160,4194304,16,21763,8192,65,4196384,5393,17664,35188,1365,4256860,256,21793,46092,63069]

theorem envBound51584 : H12AffineFastState.Bounded env51584 := by
  intro p hp
  have h : env51584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51583_51584 : H12AffineEnvironment.transform 16 49169 env51583 = env51584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env51583 == env51584) = true)

theorem identity51584 : scanCanonicalize (H12AffineFastState.compose env51584 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51584 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env51585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,54359,49169,35189,1024,32769,4160,4194304,16,21763,268,65,4196384,5393,17664,35188,1365,4248912,256,21793,38144,55121]

theorem envBound51585 : H12AffineFastState.Bounded env51585 := by
  intro p hp
  have h : env51585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51584_51585 : H12AffineEnvironment.transform 12 268 env51584 = env51585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51584 == env51585) = true)

theorem identity51585 : scanCanonicalize (H12AffineFastState.compose env51585 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound51585 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,54359,49169,35189,1024,32769,4160,33,16,21763,268,65,2049,5393,17664,35188,1365,54641,256,21793,38144,55121]

theorem envBound51586 : H12AffineFastState.Bounded env51586 := by
  intro p hp
  have h : env51586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51585_51586 : H12AffineEnvironment.transform 21 33 env51585 = env51586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51585 == env51586) = true)

theorem identity51586 : scanCanonicalize (H12AffineFastState.compose env51586 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound51586 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env51587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,32883,37941,35189,1024,32769,4160,33,16,295,268,65,2049,5393,4388,35188,1365,33109,256,261,38144,33653]

theorem envBound51587 : H12AffineFastState.Bounded env51587 := by
  intro p hp
  have h : env51587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51586_51587 : H12AffineEnvironment.transform 13 5156 env51586 = env51587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env51586 == env51587) = true)

theorem identity51587 : scanCanonicalize (H12AffineFastState.compose env51587 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51587 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51588 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5156,32768,32883,37941,34817,1024,32769,4160,33,16,83,120,65,2049,5221,4176,34816,1057,32801,116,113,38004,33281]

theorem envBound51588 : H12AffineFastState.Bounded env51588 := by
  intro p hp
  have h : env51588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51587_51588 : H12AffineEnvironment.transform 7 116 env51587 = env51588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51587 == env51588) = true)

theorem identity51588 : scanCanonicalize (H12AffineFastState.compose env51588 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51588 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env51589 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5156,1,114,5172,2048,1024,0,4160,33,16,83,120,65,2049,5221,4176,2049,1057,32,116,113,5237,512]

theorem envBound51589 : H12AffineFastState.Bounded env51589 := by
  intro p hp
  have h : env51589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51588_51589 : H12AffineEnvironment.transform 14 1 env51588 = env51589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51588 == env51589) = true)

theorem identity51589 : scanCanonicalize (H12AffineFastState.compose env51589 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound51589 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51590 : List Nat := [2,4,8,16,32,64,8,116,512,1024,555,4096,120,5156,1,114,5172,555,1024,0,4160,33,16,83,120,65,554,5221,4176,554,1057,32,116,113,5237,512]

theorem envBound51590 : H12AffineFastState.Bounded env51590 := by
  intro p hp
  have h : env51590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51589_51590 : H12AffineEnvironment.transform 10 555 env51589 = env51590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env51589 == env51590) = true)

theorem identity51590 : scanCanonicalize (H12AffineFastState.compose env51590 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51590 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51591 : List Nat := [2,4,8,16,32,49,8,5,512,1024,555,4096,9,5156,1,3,5172,555,1024,0,4145,33,16,34,9,48,554,5140,4129,554,1057,32,5,0,5124,512]

theorem envBound51591 : H12AffineFastState.Bounded env51591 := by
  intro p hp
  have h : env51591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51590_51591 : H12AffineEnvironment.transform 5 49 env51590 = env51591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51590 == env51591) = true)

theorem identity51591 : scanCanonicalize (H12AffineFastState.compose env51591 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51592 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,4096,9,5125,1,3,5141,522,1024,0,4112,0,16,3,9,17,523,5140,4096,523,1024,1,5,0,5124,512]

theorem envBound51592 : H12AffineFastState.Bounded env51592 := by
  intro p hp
  have h : env51592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51591_51592 : H12AffineEnvironment.transform 4 1 env51591 = env51592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51591 == env51592) = true)

theorem identity51592 : scanCanonicalize (H12AffineFastState.compose env51592 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51592 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51593 : List Nat := [2,4,8,16,1,16,8,5,0,1024,10,4096,9,5125,1,3,5141,10,1024,0,4112,0,16,3,9,17,11,5140,4096,11,1024,1,5,0,5124,0]

theorem envBound51593 : H12AffineFastState.Bounded env51593 := by
  intro p hp
  have h : env51593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51592_51593 : H12AffineEnvironment.transform 8 0 env51592 = env51593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51592 == env51593) = true)

theorem identity51593 : scanCanonicalize (H12AffineFastState.compose env51593 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound51593 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51594 : List Nat := [2,4,8,16,1,16,8,5,0,1024,10,1044,9,17,1,3,1,10,1024,0,1028,0,16,3,9,17,11,0,1044,11,1024,1,5,0,16,0]

theorem envBound51594 : H12AffineFastState.Bounded env51594 := by
  intro p hp
  have h : env51594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51593_51594 : H12AffineEnvironment.transform 11 1044 env51593 = env51594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env51593 == env51594) = true)

def env51595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149861,1024,32769,4160,4194304,16,21763,8193,65,4196384,5393,17664,35189,1364,4256860,256,21793,46093,63068]

theorem envBound51595 : H12AffineFastState.Bounded env51595 := by
  intro p hp
  have h : env51595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51582_51595 : H12AffineEnvironment.transform 6 9 env51582 = env51595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51582 == env51595) = true)

theorem identity51595 : scanCanonicalize (H12AffineFastState.compose env51595 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound51595 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,10280,1024,32769,4160,4194304,16,21763,8193,65,4196384,5393,17664,35189,1364,4256860,256,21793,46093,63068]

theorem envBound51596 : H12AffineFastState.Bounded env51596 := by
  intro p hp
  have h : env51596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51595_51596 : H12AffineEnvironment.transform 16 24909 env51595 = env51596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env51595 == env51596) = true)

theorem identity51596 : scanCanonicalize (H12AffineFastState.compose env51596 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound51596 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1024,29788,4160,4194304,16,21763,8193,65,4196384,5393,17664,32040,1364,4194305,256,21793,16464,513]

theorem envBound51597 : H12AffineFastState.Bounded env51597 := by
  intro p hp
  have h : env51597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51596_51597 : H12AffineEnvironment.transform 14 29789 env51596 = env51597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env51596 == env51597) = true)

theorem identity51597 : scanCanonicalize (H12AffineFastState.compose env51597 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound51597 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1024,29788,4160,33,16,21763,8193,65,2049,5393,17664,32040,1364,32,256,21793,16464,513]

theorem envBound51598 : H12AffineFastState.Bounded env51598 := by
  intro p hp
  have h : env51598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51597_51598 : H12AffineEnvironment.transform 21 33 env51597 = env51598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51597 == env51598) = true)

theorem identity51598 : scanCanonicalize (H12AffineFastState.compose env51598 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51598 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,262,16448,2341,1024,21841,4160,33,16,21763,268,65,2049,5393,17664,23589,1364,32,256,21793,16464,513]

theorem envBound51599 : H12AffineFastState.Bounded env51599 := by
  intro p hp
  have h : env51599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51598_51599 : H12AffineEnvironment.transform 12 269 env51598 = env51599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51598 == env51599) = true)

theorem identity51599 : scanCanonicalize (H12AffineFastState.compose env51599 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51599 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,262,5441,2341,1024,80,4160,33,16,2,268,65,2049,5393,4097,2340,1364,32,256,32,5457,513]

theorem envBound51600 : H12AffineFastState.Bounded env51600 := by
  intro p hp
  have h : env51600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51599_51600 : H12AffineEnvironment.transform 13 5377 env51599 = env51600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51599 == env51600) = true)

theorem identity51600 : scanCanonicalize (H12AffineFastState.compose env51600 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound51600 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2561,269,3840,81,262,3904,2341,1024,80,2625,33,16,2,268,65,2049,3856,2560,2340,1364,32,256,32,3920,513]

theorem envBound51601 : H12AffineFastState.Bounded env51601 := by
  intro p hp
  have h : env51601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51600_51601 : H12AffineEnvironment.transform 11 2561 env51600 = env51601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env51600 == env51601) = true)

theorem identity51601 : scanCanonicalize (H12AffineFastState.compose env51601 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51601 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51602 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2561,269,3840,0,262,3857,2341,1024,1,2576,33,16,2,268,16,2049,3856,2560,2340,1285,32,256,32,3841,513]

theorem envBound51602 : H12AffineFastState.Bounded env51602 := by
  intro p hp
  have h : env51602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51601_51602 : H12AffineEnvironment.transform 5 17 env51601 = env51602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51601 == env51602) = true)

theorem identity51602 : scanCanonicalize (H12AffineFastState.compose env51602 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound51602 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51603 : List Nat := [2,4,8,16,32,17,9,256,512,1024,560,49,269,1328,0,262,1313,789,1024,1,32,33,16,2,268,16,561,1312,48,788,1285,32,256,32,1329,513]

theorem envBound51603 : H12AffineFastState.Bounded env51603 := by
  intro p hp
  have h : env51603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51602_51603 : H12AffineEnvironment.transform 10 560 env51602 = env51603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env51602 == env51603) = true)

def env51604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,4194304,17,21763,8328,65,4316414,115150,17665,35325,119043,4268163,256,98815,90202,63188]

theorem envBound51604 : H12AffineFastState.Bounded env51604 := by
  intro p hp
  have h : env51604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51580_51604 : H12AffineEnvironment.transform 22 17 env51580 = env51604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51580 == env51604) = true)

theorem identity51604 : scanCanonicalize (H12AffineFastState.compose env51604 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

theorem selectedBound51604 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,213350,17,21763,8328,65,171416,115150,17665,35325,119043,156133,256,98815,90202,63188]

theorem envBound51605 : H12AffineFastState.Bounded env51605 := by
  intro p hp
  have h : env51605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51604_51605 : H12AffineEnvironment.transform 21 213350 env51604 = env51605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env51604 == env51605) = true)

def env51606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,213350,17,21763,8192,65,171280,115014,17665,35189,119043,156013,256,98679,90202,63068]

theorem envBound51606 : H12AffineFastState.Bounded env51606 := by
  intro p hp
  have h : env51606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51605_51606 : H12AffineEnvironment.transform 6 8 env51605 = env51606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51605 == env51606) = true)

theorem identity51606 : scanCanonicalize (H12AffineFastState.compose env51606 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51606 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4160,213350,17,21763,8192,65,146508,90138,17665,10281,94303,156013,256,73771,90202,22272]

theorem envBound51607 : H12AffineFastState.Bounded env51607 := by
  intro p hp
  have h : env51607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51606_51607 : H12AffineEnvironment.transform 14 8540 env51606 = env51607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51606 == env51607) = true)

theorem identity51607 : scanCanonicalize (H12AffineFastState.compose env51607 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51607 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,76159,1024,8541,4160,8573,17,21763,8192,65,89175,90138,17665,10281,94303,65910,256,73771,90202,22272]

theorem envBound51608 : H12AffineFastState.Bounded env51608 := by
  intro p hp
  have h : env51608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51607_51608 : H12AffineEnvironment.transform 16 90139 env51607 = env51608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51607 == env51608) = true)

theorem identity51608 : scanCanonicalize (H12AffineFastState.compose env51608 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound51608 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24909,10281,1024,8541,4160,8573,17,21763,8192,65,23809,24908,17665,10281,28937,32,256,8573,24844,22272]

theorem envBound51609 : H12AffineFastState.Bounded env51609 := by
  intro p hp
  have h : env51609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51608_51609 : H12AffineEnvironment.transform 15 342 env51608 = env51609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env51608 == env51609) = true)

theorem identity51609 : scanCanonicalize (H12AffineFastState.compose env51609 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound51609 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,342,17665,3173,1024,1297,4160,1329,17,21763,1100,65,23809,17664,17665,3173,21829,32,256,1329,17728,22272]

theorem envBound51610 : H12AffineFastState.Bounded env51610 := by
  intro p hp
  have h : env51610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51609_51610 : H12AffineEnvironment.transform 12 1100 env51609 = env51610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env51609 == env51610) = true)

theorem identity51610 : scanCanonicalize (H12AffineFastState.compose env51610 (packedSelected [1,8,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51610 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env51611 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,16384,0,342,16401,2421,272,1,4160,33,17,20499,348,65,22545,16400,16401,2421,20565,32,256,33,16464,21008]

theorem envBound51611 : H12AffineFastState.Bounded env51611 := by
  intro p hp
  have h : env51611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51610_51611 : H12AffineEnvironment.transform 9 272 env51610 = env51611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51610 == env51611) = true)

theorem identity51611 : scanCanonicalize (H12AffineFastState.compose env51611 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound51611 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51612 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4405,0,342,4388,2421,272,1,4160,33,17,294,348,65,2340,4389,4388,2421,352,32,256,33,4453,805]

theorem envBound51612 : H12AffineFastState.Bounded env51612 := by
  intro p hp
  have h : env51612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51611_51612 : H12AffineEnvironment.transform 13 4405 env51611 = env51612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env51611 == env51612) = true)

theorem identity51612 : scanCanonicalize (H12AffineFastState.compose env51612 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound51612 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env51613 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,348,2048,0,342,2065,2421,272,1,2421,33,17,294,348,65,2340,2064,2065,2421,352,32,256,33,2128,805]

theorem envBound51613 : H12AffineFastState.Bounded env51613 := by
  intro p hp
  have h : env51613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51612_51613 : H12AffineEnvironment.transform 11 2357 env51612 = env51613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env51612 == env51613) = true)

theorem identity51613 : scanCanonicalize (H12AffineFastState.compose env51613 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51613 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env51614 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2113,40,2048,0,34,2065,2049,100,1,2049,33,17,82,40,65,2128,2064,2065,2049,20,32,116,33,2128,593]

theorem envBound51614 : H12AffineFastState.Bounded env51614 := by
  intro p hp
  have h : env51614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51613_51614 : H12AffineEnvironment.transform 7 116 env51613 = env51614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51613 == env51614) = true)

theorem identity51614 : scanCanonicalize (H12AffineFastState.compose env51614 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound51614 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51615 : List Nat := [2,4,8,16,32,64,8,116,512,100,112,49,40,112,0,34,97,113,100,1,113,33,17,82,40,65,32,96,97,113,20,32,116,33,32,593]

theorem envBound51615 : H12AffineFastState.Bounded env51615 := by
  intro p hp
  have h : env51615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51614_51615 : H12AffineEnvironment.transform 10 112 env51614 = env51615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env51614 == env51615) = true)

theorem identity51615 : scanCanonicalize (H12AffineFastState.compose env51615 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51615 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51616 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,49,40,33,0,34,48,32,53,1,32,33,17,3,40,16,32,49,48,32,20,32,37,33,32,512]

theorem envBound51616 : H12AffineFastState.Bounded env51616 := by
  intro p hp
  have h : env51616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51615_51616 : H12AffineEnvironment.transform 5 17 env51615 = env51616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51615 == env51616) = true)

theorem identity51616 : scanCanonicalize (H12AffineFastState.compose env51616 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound51616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51617 : List Nat := [2,4,8,16,5,17,8,0,512,16,4,20,13,4,0,7,21,5,16,1,5,4,17,3,13,16,5,20,21,5,20,5,0,4,5,512]

theorem envBound51617 : H12AffineFastState.Bounded env51617 := by
  intro p hp
  have h : env51617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51616_51617 : H12AffineEnvironment.transform 4 5 env51616 = env51617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env51616 == env51617) = true)

theorem identity51617 : scanCanonicalize (H12AffineFastState.compose env51617 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51618 : List Nat := [2,0,8,16,1,17,8,0,512,16,0,16,9,0,0,3,17,1,16,1,1,0,17,3,9,16,1,16,17,1,16,1,0,0,1,512]

theorem envBound51618 : H12AffineFastState.Bounded env51618 := by
  intro p hp
  have h : env51618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51617_51618 : H12AffineEnvironment.transform 1 0 env51617 = env51618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51617 == env51618) = true)

def env51619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,213350,17,21763,8193,65,171281,115015,17665,35188,119043,156012,256,98678,90202,63069]

theorem envBound51619 : H12AffineFastState.Bounded env51619 := by
  intro p hp
  have h : env51619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51605_51619 : H12AffineEnvironment.transform 6 9 env51605 = env51619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51605 == env51619) = true)

def env51620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,2421,1024,32769,4160,65910,17,21763,8193,65,56577,115015,17665,35188,119043,8572,256,98678,90202,63069]

theorem envBound51620 : H12AffineFastState.Bounded env51620 := by
  intro p hp
  have h : env51620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51619_51620 : H12AffineEnvironment.transform 16 16400 env51619 = env51620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51619 == env51620) = true)

theorem identity51620 : scanCanonicalize (H12AffineFastState.compose env51620 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51620 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env51621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16400,2421,1024,29789,4160,65910,17,21763,8193,65,10589,79131,17665,32040,75103,8572,256,95530,90202,513]

theorem envBound51621 : H12AffineFastState.Bounded env51621 := by
  intro p hp
  have h : env51621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51620_51621 : H12AffineEnvironment.transform 14 29788 env51620 = env51621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51620 == env51621) = true)

theorem identity51621 : scanCanonicalize (H12AffineFastState.compose env51621 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51621 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16400,2421,1024,29789,4160,8572,17,21763,8193,65,10589,5393,17665,32040,1365,8572,256,21792,16464,513]

theorem envBound51622 : H12AffineFastState.Bounded env51622 := by
  intro p hp
  have h : env51622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51621_51622 : H12AffineEnvironment.transform 15 8202 env51621 = env51622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51621 == env51622) = true)

theorem identity51622 : scanCanonicalize (H12AffineFastState.compose env51622 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51622 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16400,2421,1024,21760,4160,33,17,21763,348,65,2048,5393,17665,23669,1365,33,256,21792,16464,513]

theorem envBound51623 : H12AffineFastState.Bounded env51623 := by
  intro p hp
  have h : env51623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51622_51623 : H12AffineEnvironment.transform 12 349 env51622 = env51623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51622 == env51623) = true)

theorem identity51623 : scanCanonicalize (H12AffineFastState.compose env51623 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51623 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4160,33,17,3,348,65,2048,5393,4097,2421,1365,33,256,32,5456,513]

theorem envBound51624 : H12AffineFastState.Bounded env51624 := by
  intro p hp
  have h : env51624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51623_51624 : H12AffineEnvironment.transform 13 5376 env51623 = env51624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51623 == env51624) = true)

theorem identity51624 : scanCanonicalize (H12AffineFastState.compose env51624 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51625 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,1,34,5221,2048,1024,0,4160,33,17,3,41,65,2048,5220,4097,2048,1056,33,117,32,5157,513]

theorem envBound51625 : H12AffineFastState.Bounded env51625 := by
  intro p hp
  have h : env51625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51624_51625 : H12AffineEnvironment.transform 7 117 env51624 = env51625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51624 == env51625) = true)

theorem identity51625 : scanCanonicalize (H12AffineFastState.compose env51625 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51625 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51626 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5173,2048,1024,0,4112,33,17,3,41,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound51626 : H12AffineFastState.Bounded env51626 := by
  intro p hp
  have h : env51626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51625_51626 : H12AffineEnvironment.transform 5 16 env51625 = env51626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51625 == env51626) = true)

def env51627 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,1,34,1029,2048,1024,0,32,33,17,3,41,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound51627 : H12AffineFastState.Bounded env51627 := by
  intro p hp
  have h : env51627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51626_51627 : H12AffineEnvironment.transform 11 48 env51626 = env51627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51626 == env51627) = true)

theorem identity51627 : scanCanonicalize (H12AffineFastState.compose env51627 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound51627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51628 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,48,40,1045,1,34,1029,560,1024,0,32,33,17,3,41,17,560,1028,49,560,1056,33,37,32,1045,513]

theorem envBound51628 : H12AffineFastState.Bounded env51628 := by
  intro p hp
  have h : env51628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51627_51628 : H12AffineEnvironment.transform 10 560 env51627 = env51628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env51627 == env51628) = true)

def env51629 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,40,33,1,34,49,560,52,0,32,33,17,3,41,17,560,48,49,560,20,33,37,32,33,513]

theorem envBound51629 : H12AffineFastState.Bounded env51629 := by
  intro p hp
  have h : env51629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51628_51629 : H12AffineEnvironment.transform 9 52 env51628 = env51629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51628 == env51629) = true)

theorem identity51629 : scanCanonicalize (H12AffineFastState.compose env51629 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51630 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,48,40,33,1,34,49,33,52,0,32,33,17,3,41,17,33,48,49,33,20,33,37,32,33,16]

theorem envBound51630 : H12AffineFastState.Bounded env51630 := by
  intro p hp
  have h : env51630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51629_51630 : H12AffineEnvironment.transform 8 17 env51629 = env51630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51629 == env51630) = true)

def leafEnv51630 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,48,40,33,1,34,49,33,52,0,32,33,17,3,20,41,1,17,33,48,49,33,20,33,37,32,4,35,33,16,1,32,0]

def active51630 : List Nat := [0,1,2,3,4]

def tree51630 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51630 : H12WitnessSearch.Good tree51630 := H12GlobalWitnessIndex.good

theorem leafIdentity51630 : H12AffineFastState.composeSystem env51630 rootObs = leafEnv51630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51630 rootObs == leafEnv51630) = true)

theorem terminalChecked51630 : H12PackedTerminal.terminalCheckFast leafEnv51630 active51630 tree51630 = true := by decide +kernel

def env51631 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,40,32,1,34,48,560,53,0,32,33,17,3,41,17,560,49,49,560,21,33,37,32,32,513]

theorem envBound51631 : H12AffineFastState.Bounded env51631 := by
  intro p hp
  have h : env51631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51628_51631 : H12AffineEnvironment.transform 9 53 env51628 = env51631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51628 == env51631) = true)

theorem identity51631 : scanCanonicalize (H12AffineFastState.compose env51631 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound51631 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51632 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,10,18,26,1,24,10,522,15,0,26,27,17,3,19,17,522,11,11,522,21,27,31,26,26,513]

theorem envBound51632 : H12AffineFastState.Bounded env51632 := by
  intro p hp
  have h : env51632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51631_51632 : H12AffineEnvironment.transform 4 26 env51631 = env51632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env51631 == env51632) = true)

def leafEnv51632 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,10,18,26,1,24,10,522,15,0,26,27,17,3,21,19,1,17,522,11,11,522,21,27,31,26,4,25,26,513,1,26,0]

def active51632 : List Nat := [0,1,2,3,8]

def tree51632 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51632 : H12WitnessSearch.Good tree51632 := H12GlobalWitnessIndex.good

theorem leafIdentity51632 : H12AffineFastState.composeSystem env51632 rootObs = leafEnv51632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51632 rootObs == leafEnv51632) = true)

theorem terminalChecked51632 : H12PackedTerminal.terminalCheckFast leafEnv51632 active51632 tree51632 = true := by decide +kernel

def env51633 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,1,34,1028,2048,1024,0,33,33,17,3,41,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound51633 : H12AffineFastState.Bounded env51633 := by
  intro p hp
  have h : env51633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51626_51633 : H12AffineEnvironment.transform 11 49 env51626 = env51633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51626 == env51633) = true)

theorem identity51633 : scanCanonicalize (H12AffineFastState.compose env51633 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound51633 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51634 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,49,40,1044,1,34,1028,1540,1024,0,33,33,17,3,41,17,1540,1029,48,1540,1056,33,37,32,1044,513]

theorem envBound51634 : H12AffineFastState.Bounded env51634 := by
  intro p hp
  have h : env51634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51633_51634 : H12AffineEnvironment.transform 10 1540 env51633 = env51634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env51633 == env51634) = true)

def env51635 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,40,32,1,34,48,560,52,0,33,33,17,3,41,17,560,49,48,560,20,33,37,32,32,513]

theorem envBound51635 : H12AffineFastState.Bounded env51635 := by
  intro p hp
  have h : env51635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51634_51635 : H12AffineEnvironment.transform 9 52 env51634 = env51635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51634 == env51635) = true)

theorem identity51635 : scanCanonicalize (H12AffineFastState.compose env51635 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51636 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,49,40,32,1,34,48,32,52,0,33,33,17,3,41,17,32,49,48,32,20,33,37,32,32,17]

theorem envBound51636 : H12AffineFastState.Bounded env51636 := by
  intro p hp
  have h : env51636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51635_51636 : H12AffineEnvironment.transform 8 16 env51635 = env51636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51635 == env51636) = true)

def leafEnv51636 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,49,40,32,1,34,48,32,52,0,33,33,17,3,20,41,1,17,32,49,48,32,20,33,37,32,4,35,32,17,1,33,0]

def active51636 : List Nat := [0,1,2,3,4]

def tree51636 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51636 : H12WitnessSearch.Good tree51636 := H12GlobalWitnessIndex.good

theorem leafIdentity51636 : H12AffineFastState.composeSystem env51636 rootObs = leafEnv51636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51636 rootObs == leafEnv51636) = true)

theorem terminalChecked51636 : H12PackedTerminal.terminalCheckFast leafEnv51636 active51636 tree51636 = true := by decide +kernel

def env51637 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,40,33,1,34,49,561,53,0,33,33,17,3,41,17,561,48,48,561,21,33,37,32,33,513]

theorem envBound51637 : H12AffineFastState.Bounded env51637 := by
  intro p hp
  have h : env51637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51634_51637 : H12AffineEnvironment.transform 9 53 env51634 = env51637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51634 == env51637) = true)

theorem identity51637 : scanCanonicalize (H12AffineFastState.compose env51637 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound51637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51638 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,10,19,26,1,25,10,522,14,0,26,26,17,3,18,17,522,11,11,522,21,26,30,27,26,513]

theorem envBound51638 : H12AffineFastState.Bounded env51638 := by
  intro p hp
  have h : env51638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51637_51638 : H12AffineEnvironment.transform 4 27 env51637 = env51638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env51637 == env51638) = true)

def leafEnv51638 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,10,19,26,1,25,10,522,14,0,26,26,17,3,21,18,1,17,522,11,11,522,21,26,30,27,4,24,26,513,1,26,0]

def active51638 : List Nat := [0,1,2,3,8]

def tree51638 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51638 : H12WitnessSearch.Good tree51638 := H12GlobalWitnessIndex.good

theorem leafIdentity51638 : H12AffineFastState.composeSystem env51638 rootObs = leafEnv51638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51638 rootObs == leafEnv51638) = true)

theorem terminalChecked51638 : H12PackedTerminal.terminalCheckFast leafEnv51638 active51638 tree51638 = true := by decide +kernel

def env51639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,2420,1024,32769,4160,65911,17,21763,8193,65,56576,115015,17665,35188,119043,8573,256,98678,90202,63069]

theorem envBound51639 : H12AffineFastState.Bounded env51639 := by
  intro p hp
  have h : env51639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51619_51639 : H12AffineEnvironment.transform 16 16401 env51619 = env51639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51619 == env51639) = true)

theorem identity51639 : scanCanonicalize (H12AffineFastState.compose env51639 (packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,19,22,23,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51639 : packedSelected [0,3,5,7,9,10,11,12,14,15,16,18,19,22,23,26,32] rootPS < 2^1333 := by decide +kernel

def env51640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,16401,2420,1024,32769,4160,65911,17,21763,348,65,56576,115015,17665,35188,119043,32,256,98678,82183,55040]

theorem envBound51640 : H12AffineFastState.Bounded env51640 := by
  intro p hp
  have h : env51640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51639_51640 : H12AffineEnvironment.transform 12 349 env51639 = env51640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51639 == env51640) = true)

theorem identity51640 : scanCanonicalize (H12AffineFastState.compose env51640 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51640 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env51641 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,32768,65536,16401,2420,272,32769,4160,65911,17,20499,348,65,55312,115015,16401,35188,119043,32,256,98678,82183,53776]

theorem envBound51641 : H12AffineFastState.Bounded env51641 := by
  intro p hp
  have h : env51641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51640_51641 : H12AffineEnvironment.transform 9 272 env51640 = env51641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51640 == env51641) = true)

theorem identity51641 : scanCanonicalize (H12AffineFastState.compose env51641 (packedSelected [11,18] rootPS)) = affineNative (2^(15+1) ^^^ 20579) := by decide +kernel

theorem selectedBound51641 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env51642 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,32768,20579,16401,2420,272,32769,4160,20756,17,20499,348,65,55312,37156,16401,35188,33120,32,256,53525,4452,53776]

theorem envBound51642 : H12AffineFastState.Bounded env51642 := by
  intro p hp
  have h : env51642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51641_51642 : H12AffineEnvironment.transform 15 20579 env51641 = env51642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20579 env51641 == env51642) = true)

theorem identity51642 : scanCanonicalize (H12AffineFastState.compose env51642 (packedSelected [0,4,6,7,9,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 20788) := by decide +kernel

theorem selectedBound51642 : packedSelected [0,4,6,7,9,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env51643 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,16384,20788,20579,16401,2420,272,20789,4160,20756,17,20499,348,65,2340,16400,16401,22592,20564,32,256,33,4452,804]

theorem envBound51643 : H12AffineFastState.Bounded env51643 := by
  intro p hp
  have h : env51643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51642_51643 : H12AffineEnvironment.transform 14 20788 env51642 = env51643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20788 env51642 == env51643) = true)

theorem identity51643 : scanCanonicalize (H12AffineFastState.compose env51643 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51643 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51644 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,121,16384,20496,20579,16401,2128,52,20497,4160,20528,17,20499,120,65,2048,16400,16401,22592,20564,32,36,33,4160,512]

theorem envBound51644 : H12AffineFastState.Bounded env51644 := by
  intro p hp
  have h : env51644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51643_51644 : H12AffineEnvironment.transform 7 36 env51643 = env51644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51643 == env51644) = true)

theorem identity51644 : scanCanonicalize (H12AffineFastState.compose env51644 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51644 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51645 : List Nat := [2,4,8,16,1,64,9,5,512,21,2048,4096,88,16384,20496,20546,16401,2128,21,20497,4160,20497,17,20499,89,65,2048,16400,16401,22592,20564,1,5,0,4160,512]

theorem envBound51645 : H12AffineFastState.Bounded env51645 := by
  intro p hp
  have h : env51645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51644_51645 : H12AffineEnvironment.transform 4 1 env51644 = env51645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51644 == env51645) = true)

theorem identity51645 : scanCanonicalize (H12AffineFastState.compose env51645 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound51645 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51646 : List Nat := [2,4,8,16,1,64,9,5,512,21,2048,4096,88,4112,0,82,4097,2128,21,1,4160,1,17,3,89,65,2048,4096,4097,2128,68,1,5,0,4160,512]

theorem envBound51646 : H12AffineFastState.Bounded env51646 := by
  intro p hp
  have h : env51646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51645_51646 : H12AffineEnvironment.transform 13 4112 env51645 = env51646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env51645 == env51646) = true)

theorem identity51646 : scanCanonicalize (H12AffineFastState.compose env51646 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51646 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51647 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4112,0,3,4097,2049,21,1,4113,1,17,3,8,16,2048,4096,4097,2049,21,1,5,0,4113,512]

theorem envBound51647 : H12AffineFastState.Bounded env51647 := by
  intro p hp
  have h : env51647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51646_51647 : H12AffineEnvironment.transform 5 17 env51646 = env51647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51646 == env51647) = true)

theorem identity51647 : scanCanonicalize (H12AffineFastState.compose env51647 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 20) := by decide +kernel

theorem selectedBound51647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51648 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,20,9,4,0,3,21,2049,21,1,5,1,17,3,8,16,2048,20,21,2049,21,1,5,0,5,512]

theorem envBound51648 : H12AffineFastState.Bounded env51648 := by
  intro p hp
  have h : env51648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51647_51648 : H12AffineEnvironment.transform 11 20 env51647 = env51648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 20 env51647 == env51648) = true)

theorem identity51648 : scanCanonicalize (H12AffineFastState.compose env51648 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound51648 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51649 : List Nat := [2,4,8,16,1,17,9,5,512,21,4,20,9,4,0,3,21,5,21,1,5,1,17,3,8,16,4,20,21,5,21,1,5,0,5,512]

theorem envBound51649 : H12AffineFastState.Bounded env51649 := by
  intro p hp
  have h : env51649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51648_51649 : H12AffineEnvironment.transform 10 4 env51648 = env51649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env51648 == env51649) = true)

def env51650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,8388608,21762,8328,65,12705006,115150,8406289,8423916,8507667,4268163,256,8487406,8478795,8451780]

theorem envBound51650 : H12AffineFastState.Bounded env51650 := by
  intro p hp
  have h : env51650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51579_51650 : H12AffineEnvironment.transform 20 4161 env51579 = env51650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51579 == env51650) = true)

def env51651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,16,21762,8328,65,4316414,115150,17665,35324,119043,4268163,256,98814,90203,63188]

theorem envBound51651 : H12AffineFastState.Bounded env51651 := by
  intro p hp
  have h : env51651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51650_51651 : H12AffineEnvironment.transform 22 16 env51650 = env51651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51650 == env51651) = true)

theorem identity51651 : scanCanonicalize (H12AffineFastState.compose env51651 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51651 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4161,4194304,16,21762,8328,65,4259061,57797,17665,35324,61704,4194440,256,41461,16464,63188]

theorem envBound51652 : H12AffineFastState.Bounded env51652 := by
  intro p hp
  have h : env51652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51651_51652 : H12AffineEnvironment.transform 15 8203 env51651 = env51652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51651 == env51652) = true)

def env51653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,4194304,16,21762,8192,65,4258941,57677,17665,35188,61704,4194304,256,41341,16464,63068]

theorem envBound51653 : H12AffineFastState.Bounded env51653 := by
  intro p hp
  have h : env51653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51652_51653 : H12AffineEnvironment.transform 6 8 env51652 = env51653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51652 == env51653) = true)

theorem identity51653 : scanCanonicalize (H12AffineFastState.compose env51653 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound51653 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,35189,1024,32769,4161,4194304,16,21762,8192,65,4258941,57677,17665,35188,61704,4194304,256,41341,16464,63068]

theorem envBound51654 : H12AffineFastState.Bounded env51654 := by
  intro p hp
  have h : env51654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51653_51654 : H12AffineEnvironment.transform 16 49169 env51653 = env51654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env51653 == env51654) = true)

theorem identity51654 : scanCanonicalize (H12AffineFastState.compose env51654 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound51654 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,35189,1024,32769,4161,41341,16,21762,8192,65,23808,57677,17665,35188,61704,41341,256,41341,16464,63068]

theorem envBound51655 : H12AffineFastState.Bounded env51655 := by
  intro p hp
  have h : env51655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51654_51655 : H12AffineEnvironment.transform 21 41341 env51654 = env51655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env51654 == env51655) = true)

theorem identity51655 : scanCanonicalize (H12AffineFastState.compose env51655 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound51655 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,340,8203,16709,2081,1024,341,4161,8233,16,21762,8192,65,23808,24601,17665,2080,28764,8233,256,8233,16464,30472]

theorem envBound51656 : H12AffineFastState.Bounded env51656 := by
  intro p hp
  have h : env51656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51655_51656 : H12AffineEnvironment.transform 14 340 env51655 = env51656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env51655 == env51656) = true)

theorem identity51656 : scanCanonicalize (H12AffineFastState.compose env51656 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51656 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env51657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,340,8203,5188,2081,1024,341,4161,8233,16,3,8192,65,2049,13592,4096,2080,9565,8233,256,8233,5457,8713]

theorem envBound51657 : H12AffineFastState.Bounded env51657 := by
  intro p hp
  have h : env51657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51656_51657 : H12AffineEnvironment.transform 13 5377 env51656 = env51657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51656 == env51657) = true)

theorem identity51657 : scanCanonicalize (H12AffineFastState.compose env51657 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51657 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,340,35,5188,2081,1024,341,4161,1,16,3,40,65,2049,5424,4096,2080,1397,1,256,1,5457,545]

theorem envBound51658 : H12AffineFastState.Bounded env51658 := by
  intro p hp
  have h : env51658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51657_51658 : H12AffineEnvironment.transform 12 40 env51657 = env51658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51657 == env51658) = true)

theorem identity51658 : scanCanonicalize (H12AffineFastState.compose env51658 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound51658 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env51659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,4096,40,5377,340,35,5188,1044,1024,341,4161,1,16,3,40,65,1076,5424,4096,1045,1397,1,256,1,5457,545]

theorem envBound51659 : H12AffineFastState.Bounded env51659 := by
  intro p hp
  have h : env51659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51658_51659 : H12AffineEnvironment.transform 10 1077 env51658 = env51659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env51658 == env51659) = true)

theorem identity51659 : scanCanonicalize (H12AffineFastState.compose env51659 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound51659 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env51660 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1077,4096,40,5205,0,35,5188,1044,1024,1,4161,1,16,3,40,65,1076,5220,4096,1045,1057,1,84,1,5125,545]

theorem envBound51660 : H12AffineFastState.Bounded env51660 := by
  intro p hp
  have h : env51660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51659_51660 : H12AffineEnvironment.transform 7 84 env51659 = env51660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env51659 == env51660) = true)

theorem identity51660 : scanCanonicalize (H12AffineFastState.compose env51660 (packedSelected [0,2,3,5,7,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51660 : packedSelected [0,2,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env51661 : List Nat := [2,4,8,0,32,64,8,68,512,1024,1061,4096,40,5189,0,35,5188,1028,1024,1,4161,1,0,3,40,65,1060,5220,4096,1029,1057,1,68,1,5125,545]

theorem envBound51661 : H12AffineFastState.Bounded env51661 := by
  intro p hp
  have h : env51661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51660_51661 : H12AffineEnvironment.transform 3 0 env51660 = env51661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51660 == env51661) = true)

theorem identity51661 : scanCanonicalize (H12AffineFastState.compose env51661 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound51661 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env51662 : List Nat := [2,4,8,0,32,64,8,68,512,1024,1061,32,40,1125,0,35,1124,1028,1024,1,97,1,0,3,40,65,1060,1092,32,1029,1057,1,68,1,1061,545]

theorem envBound51662 : H12AffineFastState.Bounded env51662 := by
  intro p hp
  have h : env51662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51661_51662 : H12AffineEnvironment.transform 11 32 env51661 = env51662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env51661 == env51662) = true)

theorem identity51662 : scanCanonicalize (H12AffineFastState.compose env51662 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound51662 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51663 : List Nat := [2,4,8,0,32,64,8,68,65,1024,1061,32,40,1125,0,35,1124,1028,1024,1,97,1,0,3,40,65,1060,1092,32,1029,1057,1,68,1,1061,96]

theorem envBound51663 : H12AffineFastState.Bounded env51663 := by
  intro p hp
  have h : env51663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51662_51663 : H12AffineEnvironment.transform 8 65 env51662 = env51663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env51662 == env51663) = true)

theorem identity51663 : scanCanonicalize (H12AffineFastState.compose env51663 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51663 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env51664 : List Nat := [2,4,8,0,0,64,8,68,65,1024,1029,0,8,1093,0,3,1092,1028,1024,1,65,1,0,3,8,65,1028,1092,0,1029,1025,1,68,1,1029,64]

theorem envBound51664 : H12AffineFastState.Bounded env51664 := by
  intro p hp
  have h : env51664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51663_51664 : H12AffineEnvironment.transform 4 0 env51663 = env51664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51663 == env51664) = true)

theorem identity51664 : scanCanonicalize (H12AffineFastState.compose env51664 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound51664 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51665 : List Nat := [2,4,8,0,0,64,8,68,65,4,1,0,8,65,0,3,64,0,4,1,65,1,0,3,8,65,0,64,0,1,5,1,68,1,1,64]

theorem envBound51665 : H12AffineFastState.Bounded env51665 := by
  intro p hp
  have h : env51665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51664_51665 : H12AffineEnvironment.transform 9 4 env51664 = env51665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env51664 == env51665) = true)

theorem identity51665 : scanCanonicalize (H12AffineFastState.compose env51665 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound51665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51666 : List Nat := [2,4,8,0,0,1,8,5,0,4,1,0,8,0,0,3,1,0,4,1,0,1,0,3,8,0,0,1,0,1,5,1,5,1,1,1]

theorem envBound51666 : H12AffineFastState.Bounded env51666 := by
  intro p hp
  have h : env51666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51665_51666 : H12AffineEnvironment.transform 5 1 env51665 = env51666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51665 == env51666) = true)

theorem identity51666 : scanCanonicalize (H12AffineFastState.compose env51666 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51667 : List Nat := [2,4,3,0,0,1,3,5,0,4,1,0,3,0,0,3,1,0,4,1,0,1,0,3,3,0,0,1,0,1,5,1,5,1,1,1]

theorem envBound51667 : H12AffineFastState.Bounded env51667 := by
  intro p hp
  have h : env51667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51666_51667 : H12AffineEnvironment.transform 2 3 env51666 = env51667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51666 == env51667) = true)

def env51668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4161,4194304,16,21762,8193,65,4258940,57676,17665,35189,61704,4194305,256,41340,16464,63069]

theorem envBound51668 : H12AffineFastState.Bounded env51668 := by
  intro p hp
  have h : env51668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51652_51668 : H12AffineEnvironment.transform 6 9 env51652 = env51668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51652 == env51668) = true)

theorem identity51668 : scanCanonicalize (H12AffineFastState.compose env51668 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

end H12CloudChart1