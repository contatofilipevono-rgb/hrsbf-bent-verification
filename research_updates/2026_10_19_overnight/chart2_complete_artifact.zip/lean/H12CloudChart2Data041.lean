import H12CloudChart2Data040

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env9990 : List Nat := [2,4,8,16,32,18,9,39,42,4,35,48,11,50,33,0,48,33,5,33,48,35,16,3,10,18,32,51,51,34,38,3,38,0,48,42]

theorem envBound9990 : H12AffineFastState.Bounded env9990 := by
  intro p hp
  have h : env9990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9989_9990 : H12AffineEnvironment.transform 7 39 env9989 = env9990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 39 env9989 == env9990) = true)

def env9991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,16777216,33554432,67108864,21352529,67130624,1296,1073741824,16876544,4294967296,257,4417151346,1345,33563272]

theorem envBound9991 : H12AffineFastState.Bounded env9991 := by
  intro p hp
  have h : env9991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9956_9991 : H12AffineEnvironment.transform 20 4097 env9956 = env9991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9956 == env9991) = true)

theorem identity9991 : scanCanonicalize (H12AffineFastState.compose env9991 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 16880645) := by decide +kernel

theorem selectedBound9991 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,16777216,33554432,16880645,21352529,16892165,1296,1073741824,16876544,4294967296,257,4333368695,1345,33563272]

theorem envBound9992 : H12AffineFastState.Bounded env9992 := by
  intro p hp
  have h : env9992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9991_9992 : H12AffineEnvironment.transform 25 16880645 env9991 = env9992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16880645 env9991 == env9992) = true)

def env9993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32768,4097,4194304,17665,16777216,33554432,16880645,21352529,16892165,1296,1073741824,16876544,4294967296,257,4332843383,1345,33563272]

theorem envBound9993 : H12AffineFastState.Bounded env9993 := by
  intro p hp
  have h : env9993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9992_9993 : H12AffineEnvironment.transform 18 1024 env9992 = env9993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9992 == env9993) = true)

theorem identity9993 : scanCanonicalize (H12AffineFastState.compose env9993 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 20994526) := by decide +kernel

theorem selectedBound9993 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32768,4097,4194304,17665,16777216,33554432,16880645,21352529,16892165,1296,20994526,16876544,4294967296,257,4332843383,1345,33563272]

theorem envBound9994 : H12AffineFastState.Bounded env9994 := by
  intro p hp
  have h : env9994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9993_9994 : H12AffineEnvironment.transform 29 20994526 env9993 = env9994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 20994526 env9993 == env9994) = true)

theorem identity9994 : scanCanonicalize (H12AffineFastState.compose env9994 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound9994 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env9995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32768,4097,4194304,17665,16777216,28889,16880645,21352529,16892165,1296,20994526,16876544,4294967296,257,4299260334,1345,21073]

theorem envBound9995 : H12AffineFastState.Bounded env9995 := by
  intro p hp
  have h : env9995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9994_9995 : H12AffineEnvironment.transform 24 28889 env9994 = env9995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env9994 == env9995) = true)

theorem identity9995 : scanCanonicalize (H12AffineFastState.compose env9995 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9995 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env9996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32768,4097,4194304,17665,98565,28889,5376,4477268,16384,1296,4315355,1285,4294967296,257,4299260334,1345,21073]

theorem envBound9996 : H12AffineFastState.Bounded env9996 := by
  intro p hp
  have h : env9996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9995_9996 : H12AffineEnvironment.transform 23 98565 env9995 = env9996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9995 == env9996) = true)

theorem identity9996 : scanCanonicalize (H12AffineFastState.compose env9996 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound9996 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env9997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,76199,1024,32768,4097,4194304,17665,98565,28889,5376,4290803,16384,1296,4315355,1285,4294967296,257,4299260334,1345,21073]

theorem envBound9997 : H12AffineFastState.Bounded env9997 := by
  intro p hp
  have h : env9997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9996_9997 : H12AffineEnvironment.transform 17 76199 env9996 = env9997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env9996 == env9997) = true)

theorem identity9997 : scanCanonicalize (H12AffineFastState.compose env9997 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 53726) := by decide +kernel

theorem selectedBound9997 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env9998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53726,1345,63609,1024,32768,4097,4194304,17665,20699,28889,5376,4237613,16384,1296,4196613,1285,4294967296,257,4299182192,1345,21073]

theorem envBound9998 : H12AffineFastState.Bounded env9998 := by
  intro p hp
  have h : env9998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9997_9998 : H12AffineEnvironment.transform 15 53726 env9997 = env9998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53726 env9997 == env9998) = true)

def env9999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,1345,43049,1024,32768,4097,4194304,5457,139,8329,5376,4237613,4176,1296,4196613,1285,4294967296,257,4299161632,1345,513]

theorem envBound9999 : H12AffineFastState.Bounded env9999 := by
  intro p hp
  have h : env9999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9998_9999 : H12AffineEnvironment.transform 13 4176 env9998 = env9999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9998 == env9999) = true)

theorem identity9999 : scanCanonicalize (H12AffineFastState.compose env9999 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9999 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10000 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,33166,1345,43049,1024,32768,4097,4194304,5457,139,8329,5376,4237613,4176,1296,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound10000 : H12AffineFastState.Bounded env10000 := by
  intro p hp
  have h : env10000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9999_10000 : H12AffineEnvironment.transform 8 137 env9999 = env10000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9999 == env10000) = true)

theorem identity10000 : scanCanonicalize (H12AffineFastState.compose env10000 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 7649) := by decide +kernel

theorem selectedBound10000 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10001 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,7649,4176,32768,33166,1345,38344,1024,32768,4097,4194304,5457,139,7528,5376,4232396,4176,1296,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound10001 : H12AffineFastState.Bounded env10001 := by
  intro p hp
  have h : env10001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10000_10001 : H12AffineEnvironment.transform 12 7649 env10000 = env10001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7649 env10000 == env10001) = true)

theorem identity10001 : scanCanonicalize (H12AffineFastState.compose env10001 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2556) := by decide +kernel

theorem selectedBound10001 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10002 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,7649,4176,2556,2162,1345,7220,1024,2556,4097,4194304,5457,139,7528,5376,4201776,4176,1296,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound10002 : H12AffineFastState.Bounded env10002 := by
  intro p hp
  have h : env10002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10001_10002 : H12AffineEnvironment.transform 14 2556 env10001 = env10002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2556 env10001 == env10002) = true)

theorem identity10002 : scanCanonicalize (H12AffineFastState.compose env10002 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 5254) := by decide +kernel

theorem selectedBound10002 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10003 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,7649,4176,2556,2162,1345,7220,1024,2556,4097,5254,5457,139,7528,5376,2486,4176,1296,7555,1285,4294967296,257,4294972582,1345,136]

theorem envBound10003 : H12AffineFastState.Bounded env10003 := by
  intro p hp
  have h : env10003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10002_10003 : H12AffineEnvironment.transform 21 5254 env10002 = env10003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5254 env10002 == env10003) = true)

def env10004 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2289,1344,2556,2162,1345,2340,1024,2556,1297,406,65,139,2168,16,2486,1344,1296,2195,1285,4294967296,257,4294967734,1345,136]

theorem envBound10004 : H12AffineFastState.Bounded env10004 := by
  intro p hp
  have h : env10004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10003_10004 : H12AffineEnvironment.transform 11 1296 env10003 = env10004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10003 == env10004) = true)

theorem identity10004 : scanCanonicalize (H12AffineFastState.compose env10004 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound10004 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10005 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1261,2289,1213,2049,2162,1212,2265,1024,2049,1260,107,65,139,2168,16,2123,1213,1261,2195,1272,4294967296,252,4294967371,1212,136]

theorem envBound10005 : H12AffineFastState.Bounded env10005 := by
  intro p hp
  have h : env10005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10004_10005 : H12AffineEnvironment.transform 7 253 env10004 = env10005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env10004 == env10005) = true)

theorem identity10005 : scanCanonicalize (H12AffineFastState.compose env10005 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 162) := by decide +kernel

theorem selectedBound10005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10006 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1261,2289,1213,2049,2162,1212,2265,1024,2049,1260,107,65,139,2168,16,2123,1213,1261,2195,1272,162,252,233,1212,136]

theorem envBound10006 : H12AffineFastState.Bounded env10006 := by
  intro p hp
  have h : env10006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10005_10006 : H12AffineEnvironment.transform 31 162 env10005 = env10006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 162 env10005 == env10006) = true)

theorem identity10006 : scanCanonicalize (H12AffineFastState.compose env10006 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound10006 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10007 : List Nat := [2,4,8,16,32,64,89,36,80,1024,2048,1076,2088,1124,2049,2162,1125,2048,1024,2049,1077,107,65,82,2168,16,2123,1124,1076,2122,1057,123,37,48,1125,81]

theorem envBound10007 : H12AffineFastState.Bounded env10007 := by
  intro p hp
  have h : env10007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10006_10007 : H12AffineEnvironment.transform 6 89 env10006 = env10007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env10006 == env10007) = true)

theorem identity10007 : scanCanonicalize (H12AffineFastState.compose env10007 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound10007 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10008 : List Nat := [2,4,8,16,32,11,18,36,27,1024,2048,1076,2088,1071,2049,2105,1070,2048,1024,2049,1077,32,10,25,2099,16,2048,1071,1076,2049,1057,48,37,48,1070,26]

theorem envBound10008 : H12AffineFastState.Bounded env10008 := by
  intro p hp
  have h : env10008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10007_10008 : H12AffineEnvironment.transform 5 11 env10007 = env10008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env10007 == env10008) = true)

def leafEnv10008 : List Nat := [2,4,8,16,32,11,18,36,27,1024,2048,1076,2088,1071,2049,2105,1070,2048,1024,2049,1077,32,10,25,1057,2099,1,16,2048,1071,1076,2049,1057,48,37,48,5,2083,1070,26,0,1077,1]

def active10008 : List Nat := [0,1,2,3,4,9,10]

def tree10008 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10008 : H12WitnessSearch.Good tree10008 := H12GlobalWitnessIndex.good

theorem leafIdentity10008 : H12AffineFastState.composeSystem env10008 rootObs = leafEnv10008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10008 rootObs == leafEnv10008) = true)

theorem terminalChecked10008 : H12PackedTerminal.terminalCheckFast leafEnv10008 active10008 tree10008 = true := by decide +kernel

def env10009 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2288,1345,2556,2162,1345,2341,1024,2556,1296,407,64,139,2169,17,2486,1345,1296,2194,1285,4294967296,257,4294967735,1345,136]

theorem envBound10009 : H12AffineFastState.Bounded env10009 := by
  intro p hp
  have h : env10009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10003_10009 : H12AffineEnvironment.transform 11 1297 env10003 = env10009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10003 == env10009) = true)

theorem identity10009 : scanCanonicalize (H12AffineFastState.compose env10009 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound10009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10010 : List Nat := [2,4,8,16,32,64,128,110,137,1024,2048,1151,2288,1071,2194,2162,1071,2123,1024,2194,1150,249,64,139,2169,17,2264,1071,1150,2194,1131,4294967296,111,4294967513,1071,136]

theorem envBound10010 : H12AffineFastState.Bounded env10010 := by
  intro p hp
  have h : env10010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10009_10010 : H12AffineEnvironment.transform 7 110 env10009 = env10010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env10009 == env10010) = true)

theorem identity10010 : scanCanonicalize (H12AffineFastState.compose env10010 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 43) := by decide +kernel

theorem selectedBound10010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10011 : List Nat := [2,4,8,16,32,64,128,110,137,1024,2048,1151,2288,1071,2194,2162,1071,2123,1024,2194,1150,249,64,139,2169,17,2264,1071,1150,2194,1131,43,111,242,1071,136]

theorem envBound10011 : H12AffineFastState.Bounded env10011 := by
  intro p hp
  have h : env10011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10010_10011 : H12AffineEnvironment.transform 31 43 env10010 = env10011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 43 env10010 == env10011) = true)

theorem identity10011 : scanCanonicalize (H12AffineFastState.compose env10011 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound10011 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10012 : List Nat := [2,4,8,16,32,10,128,36,137,1024,2048,1077,2234,1071,2194,2104,1071,2049,1024,2194,1076,179,10,139,2099,17,2194,1071,1076,2194,1057,43,37,184,1071,136]

theorem envBound10012 : H12AffineFastState.Bounded env10012 := by
  intro p hp
  have h : env10012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10011_10012 : H12AffineEnvironment.transform 5 10 env10011 = env10012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env10011 == env10012) = true)

theorem identity10012 : scanCanonicalize (H12AffineFastState.compose env10012 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10012 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10013 : List Nat := [2,4,8,16,32,10,19,36,26,1024,2048,1077,2089,1071,2049,2104,1071,2049,1024,2049,1076,32,10,24,2099,17,2049,1071,1076,2049,1057,43,37,43,1071,27]

theorem envBound10013 : H12AffineFastState.Bounded env10013 := by
  intro p hp
  have h : env10013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10012_10013 : H12AffineEnvironment.transform 6 19 env10012 = env10013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10012 == env10013) = true)

def leafEnv10013 : List Nat := [2,4,8,16,32,10,19,36,26,1024,2048,1077,2089,1071,2049,2104,1071,2049,1024,2049,1076,32,10,24,1057,2099,1,17,2049,1071,1076,2049,1057,43,37,43,5,2083,1071,27,0,1077,1]

def active10013 : List Nat := [0,1,2,3,4,9,10]

def tree10013 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10013 : H12WitnessSearch.Good tree10013 := H12GlobalWitnessIndex.good

theorem leafIdentity10013 : H12AffineFastState.composeSystem env10013 rootObs = leafEnv10013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10013 rootObs == leafEnv10013) = true)

theorem terminalChecked10013 : H12PackedTerminal.terminalCheckFast leafEnv10013 active10013 tree10013 = true := by decide +kernel

def env10014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,33167,1345,43048,1024,32768,4097,4194304,5456,138,8328,5376,4237613,4177,1296,4196613,1285,4294967296,257,4299161633,1345,512]

theorem envBound10014 : H12AffineFastState.Bounded env10014 := by
  intro p hp
  have h : env10014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9998_10014 : H12AffineEnvironment.transform 13 4177 env9998 = env10014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9998 == env10014) = true)

theorem identity10014 : scanCanonicalize (H12AffineFastState.compose env10014 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10014 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,261,138,1345,10541,1024,261,4097,4194304,5456,138,8328,5376,4204584,4177,1296,4196613,1285,4294967296,257,4299161633,1345,512]

theorem envBound10015 : H12AffineFastState.Bounded env10015 := by
  intro p hp
  have h : env10015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10014_10015 : H12AffineEnvironment.transform 14 261 env10014 = env10015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10014 == env10015) = true)

theorem identity10015 : scanCanonicalize (H12AffineFastState.compose env10015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 13133) := by decide +kernel

theorem selectedBound10015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,261,138,1345,10541,1024,261,4097,13133,5456,138,8328,5376,7013,4177,1296,14920,1285,4294967296,257,4294980460,1345,512]

theorem envBound10016 : H12AffineFastState.Bounded env10016 := by
  intro p hp
  have h : env10016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10015_10016 : H12AffineEnvironment.transform 21 13133 env10015 = env10016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 13133 env10015 == env10016) = true)

theorem identity10016 : scanCanonicalize (H12AffineFastState.compose env10016 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound10016 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env10017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,8192,4177,261,138,1345,8843,1024,261,4097,13133,5456,138,8328,5376,4291,4177,1296,12782,1285,4294967296,257,4294980460,1345,512]

theorem envBound10017 : H12AffineFastState.Bounded env10017 := by
  intro p hp
  have h : env10017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10016_10017 : H12AffineEnvironment.transform 10 934 env10016 = env10017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env10016 == env10017) = true)

theorem identity10017 : scanCanonicalize (H12AffineFastState.compose env10017 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound10017 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env10018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,1289,4177,261,138,1345,1922,1024,261,4097,5700,5456,138,1409,5376,4291,4177,1296,5351,1285,4294967296,257,4294973029,1345,512]

theorem envBound10018 : H12AffineFastState.Bounded env10018 := by
  intro p hp
  have h : env10018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10017_10018 : H12AffineEnvironment.transform 12 1289 env10017 = env10018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env10017 == env10018) = true)

theorem identity10018 : scanCanonicalize (H12AffineFastState.compose env10018 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1993) := by decide +kernel

theorem selectedBound10018 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env10019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,1993,1289,1944,261,138,1345,1922,1024,261,1992,397,665,138,1409,713,1802,1944,1296,814,1285,4294967296,257,4294967724,1345,512]

theorem envBound10019 : H12AffineFastState.Bounded env10019 := by
  intro p hp
  have h : env10019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10018_10019 : H12AffineEnvironment.transform 11 1993 env10018 = env10019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1993 env10018 == env10019) = true)

theorem identity10019 : scanCanonicalize (H12AffineFastState.compose env10019 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound10019 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10020 : List Nat := [2,4,8,16,32,64,3,256,512,1024,805,1866,1289,1819,261,9,1345,1793,1024,261,1867,270,538,9,1282,586,1802,1819,1296,814,1285,4294967296,257,4294967599,1345,512]

theorem envBound10020 : H12AffineFastState.Bounded env10020 := by
  intro p hp
  have h : env10020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10019_10020 : H12AffineEnvironment.transform 6 3 env10019 = env10020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env10019 == env10020) = true)

theorem identity10020 : scanCanonicalize (H12AffineFastState.compose env10020 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound10020 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10021 : List Nat := [2,4,8,16,32,64,3,256,512,1024,805,1866,1289,1819,261,9,1345,1793,1024,261,1867,270,538,9,1282,586,1802,1819,1296,814,1285,805,257,522,1345,512]

theorem envBound10021 : H12AffineFastState.Bounded env10021 := by
  intro p hp
  have h : env10021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10020_10021 : H12AffineEnvironment.transform 31 805 env10020 = env10021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env10020 == env10021) = true)

theorem identity10021 : scanCanonicalize (H12AffineFastState.compose env10021 (packedSelected [1,12,21] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound10021 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env10022 : List Nat := [2,4,8,16,32,64,3,256,512,257,805,587,8,538,261,9,64,512,257,261,586,270,538,9,3,586,523,538,17,814,4,805,257,522,64,512]

theorem envBound10022 : H12AffineFastState.Bounded env10022 := by
  intro p hp
  have h : env10022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10021_10022 : H12AffineEnvironment.transform 9 257 env10021 = env10022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env10021 == env10022) = true)

def env10023 : List Nat := [2,4,8,16,32,64,3,256,32,257,261,107,8,58,261,9,64,32,257,261,106,270,58,9,3,106,43,58,17,270,4,261,257,42,64,32]

theorem envBound10023 : H12AffineFastState.Bounded env10023 := by
  intro p hp
  have h : env10023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10022_10023 : H12AffineEnvironment.transform 8 32 env10022 = env10023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env10022 == env10023) = true)

theorem identity10023 : scanCanonicalize (H12AffineFastState.compose env10023 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10024 : List Nat := [2,4,0,16,32,64,3,256,32,257,261,99,0,50,261,1,64,32,257,261,98,262,50,1,3,98,35,50,17,262,4,261,257,34,64,32]

theorem envBound10024 : H12AffineFastState.Bounded env10024 := by
  intro p hp
  have h : env10024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10023_10024 : H12AffineEnvironment.transform 2 0 env10023 = env10024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10023 == env10024) = true)

def env10025 : List Nat := [2,4,0,16,32,64,3,36,32,37,33,99,0,50,33,1,64,32,37,33,98,34,50,1,3,98,35,50,17,34,4,33,37,34,64,32]

theorem envBound10025 : H12AffineFastState.Bounded env10025 := by
  intro p hp
  have h : env10025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10024_10025 : H12AffineEnvironment.transform 7 36 env10024 = env10025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10024 == env10025) = true)

theorem identity10025 : scanCanonicalize (H12AffineFastState.compose env10025 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10026 : List Nat := [2,4,0,16,32,48,3,36,32,37,33,19,0,50,33,1,48,32,37,33,18,34,50,1,3,18,35,50,17,34,4,33,37,34,48,32]

theorem envBound10026 : H12AffineFastState.Bounded env10026 := by
  intro p hp
  have h : env10026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10025_10026 : H12AffineEnvironment.transform 5 48 env10025 = env10026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10025 == env10026) = true)

def env10027 : List Nat := [2,4,0,16,32,64,3,37,32,36,32,99,0,50,32,1,64,32,36,32,98,35,50,1,3,98,35,50,17,35,4,32,36,34,64,32]

theorem envBound10027 : H12AffineFastState.Bounded env10027 := by
  intro p hp
  have h : env10027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10024_10027 : H12AffineEnvironment.transform 7 37 env10024 = env10027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10024 == env10027) = true)

theorem identity10027 : scanCanonicalize (H12AffineFastState.compose env10027 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10028 : List Nat := [0,4,0,16,32,64,1,37,32,36,32,97,0,48,32,1,64,32,36,32,96,33,48,1,1,96,33,48,17,33,4,32,36,32,64,32]

theorem envBound10028 : H12AffineFastState.Bounded env10028 := by
  intro p hp
  have h : env10028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10027_10028 : H12AffineEnvironment.transform 0 0 env10027 = env10028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10027 == env10028) = true)

theorem identity10028 : scanCanonicalize (H12AffineFastState.compose env10028 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound10028 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10029 : List Nat := [0,4,0,16,32,49,1,37,32,36,32,16,0,48,32,1,49,32,36,32,17,33,48,1,1,17,33,48,17,33,4,32,36,32,49,32]

theorem envBound10029 : H12AffineFastState.Bounded env10029 := by
  intro p hp
  have h : env10029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10028_10029 : H12AffineEnvironment.transform 5 49 env10028 = env10029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env10028 == env10029) = true)

def env10030 : List Nat := [2,4,8,16,32,64,3,256,33,257,260,106,8,59,261,9,64,33,257,261,107,270,59,9,3,107,42,59,17,271,4,260,257,43,64,33]

theorem envBound10030 : H12AffineFastState.Bounded env10030 := by
  intro p hp
  have h : env10030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10022_10030 : H12AffineEnvironment.transform 8 33 env10022 = env10030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10022 == env10030) = true)

theorem identity10030 : scanCanonicalize (H12AffineFastState.compose env10030 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound10030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10031 : List Nat := [1,4,8,16,32,64,0,256,33,257,260,105,8,56,261,9,64,33,257,261,104,269,56,9,0,104,41,56,17,268,4,260,257,40,64,33]

theorem envBound10031 : H12AffineFastState.Bounded env10031 := by
  intro p hp
  have h : env10031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10030_10031 : H12AffineEnvironment.transform 0 1 env10030 = env10031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env10030 == env10031) = true)

theorem identity10031 : scanCanonicalize (H12AffineFastState.compose env10031 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 44) := by decide +kernel

theorem selectedBound10031 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10032 : List Nat := [1,4,8,16,32,64,0,44,33,45,40,105,8,56,41,9,64,33,45,41,104,33,56,9,0,104,41,56,17,32,4,40,45,40,64,33]

theorem envBound10032 : H12AffineFastState.Bounded env10032 := by
  intro p hp
  have h : env10032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10031_10032 : H12AffineEnvironment.transform 7 44 env10031 = env10032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 44 env10031 == env10032) = true)

theorem identity10032 : scanCanonicalize (H12AffineFastState.compose env10032 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 56) := by decide +kernel

theorem selectedBound10032 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10033 : List Nat := [1,4,8,16,32,56,0,44,33,45,40,17,8,56,41,9,56,33,45,41,16,33,56,9,0,16,41,56,17,32,4,40,45,40,56,33]

theorem envBound10033 : H12AffineFastState.Bounded env10033 := by
  intro p hp
  have h : env10033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10032_10033 : H12AffineEnvironment.transform 5 56 env10032 = env10033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 56 env10032 == env10033) = true)

theorem identity10033 : scanCanonicalize (H12AffineFastState.compose env10033 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10034 : List Nat := [1,4,0,16,32,48,0,36,33,37,32,17,0,48,33,1,48,33,37,33,16,33,48,1,0,16,33,48,17,32,4,32,37,32,48,33]

theorem envBound10034 : H12AffineFastState.Bounded env10034 := by
  intro p hp
  have h : env10034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10033_10034 : H12AffineEnvironment.transform 2 0 env10033 = env10034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10033 == env10034) = true)

theorem identity10034 : scanCanonicalize (H12AffineFastState.compose env10034 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10035 : List Nat := [1,4,0,16,0,16,0,4,1,5,0,17,0,16,1,1,16,1,5,1,16,1,16,1,0,16,1,16,17,0,4,0,5,0,16,1]

theorem envBound10035 : H12AffineFastState.Bounded env10035 := by
  intro p hp
  have h : env10035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10034_10035 : H12AffineEnvironment.transform 4 0 env10034 = env10035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10034 == env10035) = true)

def leafEnv10035 : List Nat := [1,4,0,16,0,16,0,4,1,5,0,17,0,16,1,1,16,1,5,1,16,1,16,1,4,0,1,16,1,16,17,0,4,0,5,0,5,1,16,1,0,16,1]

def active10035 : List Nat := [1,3]

def tree10035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10035 : H12WitnessSearch.Good tree10035 := H12GlobalWitnessIndex.good

theorem leafIdentity10035 : H12AffineFastState.composeSystem env10035 rootObs = leafEnv10035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10035 rootObs == leafEnv10035) = true)

theorem terminalChecked10035 : H12PackedTerminal.terminalCheckFast leafEnv10035 active10035 tree10035 = true := by decide +kernel

def env10036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17665,16777216,33554432,16880645,21352529,16892165,1296,1073741824,16876544,4294967296,257,4332843382,1345,33563272]

theorem envBound10036 : H12AffineFastState.Bounded env10036 := by
  intro p hp
  have h : env10036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9992_10036 : H12AffineEnvironment.transform 18 1025 env9992 = env10036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9992 == env10036) = true)

theorem identity10036 : scanCanonicalize (H12AffineFastState.compose env10036 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 20973967) := by decide +kernel

theorem selectedBound10036 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17665,16777216,33554432,16880645,21352529,16892165,1296,20973967,16876544,4294967296,257,4332843382,1345,33563272]

theorem envBound10037 : H12AffineFastState.Bounded env10037 := by
  intro p hp
  have h : env10037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10036_10037 : H12AffineEnvironment.transform 29 20973967 env10036 = env10037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 20973967 env10036 == env10037) = true)

theorem identity10037 : scanCanonicalize (H12AffineFastState.compose env10037 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound10037 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env10038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17665,98565,33554432,5376,4477268,16384,1296,4294794,1285,4294967296,257,4332843382,1345,33563272]

theorem envBound10038 : H12AffineFastState.Bounded env10038 := by
  intro p hp
  have h : env10038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10037_10038 : H12AffineEnvironment.transform 23 98565 env10037 = env10038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env10037 == env10038) = true)

theorem identity10038 : scanCanonicalize (H12AffineFastState.compose env10038 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 330031) := by decide +kernel

theorem selectedBound10038 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env10039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17665,98565,330031,5376,4477268,16384,1296,4294794,1285,4294967296,257,4299487321,1345,338855]

theorem envBound10039 : H12AffineFastState.Bounded env10039 := by
  intro p hp
  have h : env10039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10038_10039 : H12AffineEnvironment.transform 24 330031 env10038 = env10039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 330031 env10038 == env10039) = true)

theorem identity10039 : scanCanonicalize (H12AffineFastState.compose env10039 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(17+1) ^^^ 63609) := by decide +kernel

theorem selectedBound10039 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env10040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,63609,1025,32768,4097,4194304,17665,98565,127318,5376,4237613,16384,1296,4294794,1285,4294967296,257,4299161632,1345,119774]

theorem envBound10040 : H12AffineFastState.Bounded env10040 := by
  intro p hp
  have h : env10040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10039_10040 : H12AffineEnvironment.transform 17 63609 env10039 = env10040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63609 env10039 == env10040) = true)

def env10041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,43049,1025,32768,4097,4194304,5457,98565,106758,5376,4237613,4176,1296,4294794,1285,4294967296,257,4299161632,1345,99214]

theorem envBound10041 : H12AffineFastState.Bounded env10041 := by
  intro p hp
  have h : env10041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10040_10041 : H12AffineEnvironment.transform 13 4176 env10040 = env10041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10040 == env10041) = true)

theorem identity10041 : scanCanonicalize (H12AffineFastState.compose env10041 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound10041 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33542,1345,43049,1025,32768,4097,4194304,5457,515,8704,5376,4237613,4176,1296,4197260,1285,4294967296,257,4299161632,1345,136]

theorem envBound10042 : H12AffineFastState.Bounded env10042 := by
  intro p hp
  have h : env10042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10041_10042 : H12AffineEnvironment.transform 15 33542 env10041 = env10042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env10041 == env10042) = true)

theorem identity10042 : scanCanonicalize (H12AffineFastState.compose env10042 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 2297) := by decide +kernel

theorem selectedBound10042 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2297,3071,1345,8400,1025,2297,4097,4194304,5457,515,8704,5376,4202964,4176,1296,4197260,1285,4294967296,257,4299161632,1345,136]

theorem envBound10043 : H12AffineFastState.Bounded env10043 := by
  intro p hp
  have h : env10043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10042_10043 : H12AffineEnvironment.transform 14 2297 env10042 = env10043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2297 env10042 == env10043) = true)

theorem identity10043 : scanCanonicalize (H12AffineFastState.compose env10043 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10043 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10044 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,2297,2422,1345,8400,1025,2297,4097,4194304,5457,138,8329,5376,4202964,4176,1296,4196613,1285,4294967296,257,4299161632,1345,136]

theorem envBound10044 : H12AffineFastState.Bounded env10044 := by
  intro p hp
  have h : env10044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10043_10044 : H12AffineEnvironment.transform 8 137 env10043 = env10044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10043 == env10044) = true)

theorem identity10044 : scanCanonicalize (H12AffineFastState.compose env10044 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound10044 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10045 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,2297,2422,1345,8400,1025,2297,4097,476,5457,138,8329,5376,8200,4176,1296,2265,1285,4294967296,257,4294967804,1345,136]

theorem envBound10045 : H12AffineFastState.Bounded env10045 := by
  intro p hp
  have h : env10045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10044_10045 : H12AffineEnvironment.transform 21 476 env10044 = env10045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env10044 == env10045) = true)

theorem identity10045 : scanCanonicalize (H12AffineFastState.compose env10045 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 7396) := by decide +kernel

theorem selectedBound10045 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10046 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,7396,4176,2297,2422,1345,7220,1025,2297,4097,476,5457,138,7277,5376,7404,4176,1296,2265,1285,4294967296,257,4294967804,1345,136]

theorem envBound10046 : H12AffineFastState.Bounded env10046 := by
  intro p hp
  have h : env10046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10045_10046 : H12AffineEnvironment.transform 12 7396 env10045 = env10046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7396 env10045 == env10046) = true)

theorem identity10046 : scanCanonicalize (H12AffineFastState.compose env10046 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound10046 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10047 : List Nat := [2,4,8,16,32,64,128,256,137,1024,248,4096,5148,4176,1,398,1345,5324,1025,1,4097,476,5457,138,5269,5376,5140,4176,1296,33,1285,4294967296,257,4294967804,1345,136]

theorem envBound10047 : H12AffineFastState.Bounded env10047 := by
  intro p hp
  have h : env10047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10046_10047 : H12AffineEnvironment.transform 10 248 env10046 = env10047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env10046 == env10047) = true)

def env10048 : List Nat := [2,4,8,16,32,64,128,256,137,1024,248,1296,268,1344,1,398,1345,476,1025,1,1297,476,65,138,389,16,260,1344,1296,33,1285,4294967296,257,4294967804,1345,136]

theorem envBound10048 : H12AffineFastState.Bounded env10048 := by
  intro p hp
  have h : env10048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10047_10048 : H12AffineEnvironment.transform 11 1296 env10047 = env10048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10047 == env10048) = true)

theorem identity10048 : scanCanonicalize (H12AffineFastState.compose env10048 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10049 : List Nat := [2,4,8,16,32,64,120,256,113,1024,0,1296,268,1344,1,374,1345,292,1025,1,1297,292,65,114,381,16,260,1344,1296,33,1285,4294967296,257,4294967556,1345,112]

theorem envBound10049 : H12AffineFastState.Bounded env10049 := by
  intro p hp
  have h : env10049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10048_10049 : H12AffineEnvironment.transform 6 120 env10048 = env10049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10048 == env10049) = true)

theorem identity10049 : scanCanonicalize (H12AffineFastState.compose env10049 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 351) := by decide +kernel

theorem selectedBound10049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10050 : List Nat := [2,4,8,16,32,64,120,256,113,1024,0,1296,268,1344,1,374,1345,292,1025,1,1297,292,65,114,381,16,260,1344,1296,33,1285,351,257,91,1345,112]

theorem envBound10050 : H12AffineFastState.Bounded env10050 := by
  intro p hp
  have h : env10050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10049_10050 : H12AffineEnvironment.transform 31 351 env10049 = env10050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 351 env10049 == env10050) = true)

theorem identity10050 : scanCanonicalize (H12AffineFastState.compose env10050 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10050 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10051 : List Nat := [2,4,8,16,0,64,88,256,81,1024,0,1296,268,1344,1,342,1345,260,1025,1,1297,260,65,82,349,16,260,1344,1296,1,1285,351,257,91,1345,80]

theorem envBound10051 : H12AffineFastState.Bounded env10051 := by
  intro p hp
  have h : env10051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10050_10051 : H12AffineEnvironment.transform 4 0 env10050 = env10051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10050 == env10051) = true)

theorem identity10051 : scanCanonicalize (H12AffineFastState.compose env10051 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10051 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10052 : List Nat := [2,4,8,16,0,64,88,4,81,1024,0,1044,8,1092,1,82,1093,0,1025,1,1045,0,65,82,89,16,0,1092,1044,1,1025,91,5,91,1093,80]

theorem envBound10052 : H12AffineFastState.Bounded env10052 := by
  intro p hp
  have h : env10052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10051_10052 : H12AffineEnvironment.transform 7 4 env10051 = env10052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10051 == env10052) = true)

theorem identity10052 : scanCanonicalize (H12AffineFastState.compose env10052 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound10052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10053 : List Nat := [2,4,8,16,0,10,18,4,27,1024,0,1044,8,1038,1,24,1039,0,1025,1,1045,0,11,24,19,16,0,1038,1044,1,1025,17,5,17,1039,26]

theorem envBound10053 : H12AffineFastState.Bounded env10053 := by
  intro p hp
  have h : env10053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10052_10053 : H12AffineEnvironment.transform 5 10 env10052 = env10053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env10052 == env10053) = true)

def leafEnv10053 : List Nat := [2,4,8,16,0,10,18,4,27,1024,0,1044,8,1038,1,24,1039,0,1025,1,1045,0,11,24,1024,19,1,16,0,1038,1044,1,1025,17,5,17,5,3,1039,26,0,1045,1]

def active10053 : List Nat := [0,1,2,3,9]

def tree10053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10053 : H12WitnessSearch.Good tree10053 := H12GlobalWitnessIndex.good

theorem leafIdentity10053 : H12AffineFastState.composeSystem env10053 rootObs = leafEnv10053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10053 rootObs == leafEnv10053) = true)

theorem terminalChecked10053 : H12PackedTerminal.terminalCheckFast leafEnv10053 active10053 tree10053 = true := by decide +kernel

def env10054 : List Nat := [2,4,8,16,32,64,128,256,137,1024,248,1297,269,1345,1,398,1345,477,1025,1,1296,476,64,138,388,17,261,1345,1296,33,1285,4294967296,257,4294967804,1345,136]

theorem envBound10054 : H12AffineFastState.Bounded env10054 := by
  intro p hp
  have h : env10054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10047_10054 : H12AffineEnvironment.transform 11 1297 env10047 = env10054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10047 == env10054) = true)

theorem identity10054 : scanCanonicalize (H12AffineFastState.compose env10054 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10055 : List Nat := [2,4,8,16,32,64,128,36,137,1024,248,1077,41,1125,1,170,1125,249,1025,1,1076,248,64,138,160,17,33,1125,1076,33,1057,4294967296,37,4294967512,1125,136]

theorem envBound10055 : H12AffineFastState.Bounded env10055 := by
  intro p hp
  have h : env10055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10054_10055 : H12AffineEnvironment.transform 7 36 env10054 = env10055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10054 == env10055) = true)

theorem identity10055 : scanCanonicalize (H12AffineFastState.compose env10055 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10055 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10056 : List Nat := [2,4,8,16,32,64,120,36,113,1024,0,1077,41,1125,1,82,1125,1,1025,1,1076,0,64,114,88,17,33,1125,1076,33,1057,4294967296,37,4294967328,1125,112]

theorem envBound10056 : H12AffineFastState.Bounded env10056 := by
  intro p hp
  have h : env10056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10055_10056 : H12AffineEnvironment.transform 6 120 env10055 = env10056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10055 == env10056) = true)

theorem identity10056 : scanCanonicalize (H12AffineFastState.compose env10056 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound10056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10057 : List Nat := [2,4,8,16,32,64,120,36,113,1024,0,1077,41,1125,1,82,1125,1,1025,1,1076,0,64,114,88,17,33,1125,1076,33,1057,10,37,42,1125,112]

theorem envBound10057 : H12AffineFastState.Bounded env10057 := by
  intro p hp
  have h : env10057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10056_10057 : H12AffineEnvironment.transform 31 10 env10056 = env10057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env10056 == env10057) = true)

theorem identity10057 : scanCanonicalize (H12AffineFastState.compose env10057 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10057 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10058 : List Nat := [2,4,8,16,0,64,88,4,81,1024,0,1045,9,1093,1,82,1093,1,1025,1,1044,0,64,82,88,17,1,1093,1044,1,1025,10,5,10,1093,80]

theorem envBound10058 : H12AffineFastState.Bounded env10058 := by
  intro p hp
  have h : env10058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10057_10058 : H12AffineEnvironment.transform 4 0 env10057 = env10058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10057 == env10058) = true)

theorem identity10058 : scanCanonicalize (H12AffineFastState.compose env10058 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound10058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10059 : List Nat := [2,4,8,16,0,10,18,4,27,1024,0,1045,9,1039,1,24,1039,1,1025,1,1044,0,10,24,18,17,1,1039,1044,1,1025,10,5,10,1039,26]

theorem envBound10059 : H12AffineFastState.Bounded env10059 := by
  intro p hp
  have h : env10059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10058_10059 : H12AffineEnvironment.transform 5 10 env10058 = env10059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env10058 == env10059) = true)

def leafEnv10059 : List Nat := [2,4,8,16,0,10,18,4,27,1024,0,1045,9,1039,1,24,1039,1,1025,1,1044,0,10,24,1024,18,1,17,1,1039,1044,1,1025,10,5,10,5,3,1039,26,0,1045,1]

def active10059 : List Nat := [0,1,2,3,9]

def tree10059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10059 : H12WitnessSearch.Good tree10059 := H12GlobalWitnessIndex.good

theorem leafIdentity10059 : H12AffineFastState.composeSystem env10059 rootObs = leafEnv10059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10059 rootObs == leafEnv10059) = true)

theorem terminalChecked10059 : H12PackedTerminal.terminalCheckFast leafEnv10059 active10059 tree10059 = true := by decide +kernel

def env10060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,43048,1025,32768,4097,4194304,5456,98565,106759,5376,4237613,4177,1296,4294794,1285,4294967296,257,4299161632,1345,99215]

theorem envBound10060 : H12AffineFastState.Bounded env10060 := by
  intro p hp
  have h : env10060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10040_10060 : H12AffineEnvironment.transform 13 4177 env10040 = env10060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env10040 == env10060) = true)

theorem identity10060 : scanCanonicalize (H12AffineFastState.compose env10060 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound10060 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,33167,1345,43048,1025,32768,4097,4194304,5456,138,8328,5376,4237613,4177,1296,4196613,1285,4294967296,257,4299161632,1345,512]

theorem envBound10061 : H12AffineFastState.Bounded env10061 := by
  intro p hp
  have h : env10061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10060_10061 : H12AffineEnvironment.transform 15 33167 env10060 = env10061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env10060 == env10061) = true)

theorem identity10061 : scanCanonicalize (H12AffineFastState.compose env10061 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10061 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,261,138,1345,10541,1025,261,4097,4194304,5456,138,8328,5376,4204584,4177,1296,4196613,1285,4294967296,257,4299161632,1345,512]

theorem envBound10062 : H12AffineFastState.Bounded env10062 := by
  intro p hp
  have h : env10062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10061_10062 : H12AffineEnvironment.transform 14 261 env10061 = env10062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10061 == env10062) = true)

theorem identity10062 : scanCanonicalize (H12AffineFastState.compose env10062 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound10062 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,65,8192,16,261,138,1345,10541,1025,261,64,4194304,1297,138,8328,1345,4204584,16,1296,4196613,1285,4294967296,257,4299161632,1345,512]

theorem envBound10063 : H12AffineFastState.Bounded env10063 := by
  intro p hp
  have h : env10063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10062_10063 : H12AffineEnvironment.transform 11 65 env10062 = env10063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env10062 == env10063) = true)

theorem identity10063 : scanCanonicalize (H12AffineFastState.compose env10063 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound10063 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env10064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,65,8192,16,261,138,1345,8842,1025,261,64,4194304,1297,138,8328,1345,4203407,16,1296,4194978,1285,4294967296,257,4299161632,1345,512]

theorem envBound10064 : H12AffineFastState.Bounded env10064 := by
  intro p hp
  have h : env10064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10063_10064 : H12AffineEnvironment.transform 10 935 env10063 = env10064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env10063 == env10064) = true)

theorem identity10064 : scanCanonicalize (H12AffineFastState.compose env10064 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound10064 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env10065 : List Nat := [2,4,8,16,32,64,128,256,512,256,935,65,8192,16,261,138,65,8842,257,261,64,4194304,17,138,8328,65,4203407,16,16,4194978,5,4294967296,257,4299161632,65,512]

theorem envBound10065 : H12AffineFastState.Bounded env10065 := by
  intro p hp
  have h : env10065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10064_10065 : H12AffineEnvironment.transform 9 256 env10064 = env10065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env10064 == env10065) = true)

theorem identity10065 : scanCanonicalize (H12AffineFastState.compose env10065 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 775) := by decide +kernel

theorem selectedBound10065 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10066 : List Nat := [2,4,8,16,32,64,128,256,512,256,935,65,775,16,261,138,65,397,257,261,64,4194304,17,138,911,65,4194440,16,16,4194978,5,4294967296,257,4299161632,65,512]

theorem envBound10066 : H12AffineFastState.Bounded env10066 := by
  intro p hp
  have h : env10066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10065_10066 : H12AffineEnvironment.transform 12 775 env10065 = env10066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 775 env10065 == env10066) = true)

theorem identity10066 : scanCanonicalize (H12AffineFastState.compose env10066 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound10066 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env10067 : List Nat := [2,4,8,16,32,64,128,256,512,256,935,65,775,16,261,138,65,397,257,261,64,397,17,138,911,65,261,16,16,815,5,4294967296,257,4294967725,65,512]

theorem envBound10067 : H12AffineFastState.Bounded env10067 := by
  intro p hp
  have h : env10067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10066_10067 : H12AffineEnvironment.transform 21 397 env10066 = env10067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env10066 == env10067) = true)

theorem identity10067 : scanCanonicalize (H12AffineFastState.compose env10067 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound10067 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10068 : List Nat := [2,4,8,16,32,64,128,256,512,256,935,65,775,16,261,138,65,397,257,261,64,397,17,138,911,65,261,16,16,815,5,429,257,0,65,512]

theorem envBound10068 : H12AffineFastState.Bounded env10068 := by
  intro p hp
  have h : env10068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10067_10068 : H12AffineEnvironment.transform 31 429 env10067 = env10068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env10067 == env10068) = true)

theorem identity10068 : scanCanonicalize (H12AffineFastState.compose env10068 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound10068 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env10069 : List Nat := [2,4,8,16,32,64,128,256,271,256,168,65,8,16,261,138,65,397,257,261,64,397,17,138,128,65,261,16,16,32,5,429,257,0,65,271]

theorem envBound10069 : H12AffineFastState.Bounded env10069 := by
  intro p hp
  have h : env10069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10068_10069 : H12AffineEnvironment.transform 8 271 env10068 = env10069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env10068 == env10069) = true)

theorem identity10069 : scanCanonicalize (H12AffineFastState.compose env10069 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 87) := by decide +kernel

theorem selectedBound10069 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10070 : List Nat := [2,4,8,16,32,64,128,87,88,87,168,65,8,16,82,138,65,218,86,82,64,218,17,138,128,65,82,16,16,32,5,250,86,0,65,88]

theorem envBound10070 : H12AffineFastState.Bounded env10070 := by
  intro p hp
  have h : env10070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10069_10070 : H12AffineEnvironment.transform 7 87 env10069 = env10070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 87 env10069 == env10070) = true)

def env10071 : List Nat := [2,4,8,16,32,64,8,87,88,87,32,65,8,16,82,2,65,82,86,82,64,82,17,2,8,65,82,16,16,32,5,114,86,0,65,88]

theorem envBound10071 : H12AffineFastState.Bounded env10071 := by
  intro p hp
  have h : env10071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10070_10071 : H12AffineEnvironment.transform 6 8 env10070 = env10071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10070 == env10071) = true)

theorem identity10071 : scanCanonicalize (H12AffineFastState.compose env10071 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10072 : List Nat := [2,4,8,16,32,17,8,6,9,6,32,16,8,16,3,2,16,3,7,3,17,3,17,2,8,16,3,16,16,32,5,35,7,0,16,9]

theorem envBound10072 : H12AffineFastState.Bounded env10072 := by
  intro p hp
  have h : env10072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10071_10072 : H12AffineEnvironment.transform 5 17 env10071 = env10072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10071 == env10072) = true)

theorem identity10072 : scanCanonicalize (H12AffineFastState.compose env10072 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound10072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10073 : List Nat := [2,4,8,16,3,17,8,6,9,6,3,16,8,16,3,2,16,3,7,3,17,3,17,2,8,16,3,16,16,3,5,0,7,0,16,9]

theorem envBound10073 : H12AffineFastState.Bounded env10073 := by
  intro p hp
  have h : env10073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10072_10073 : H12AffineEnvironment.transform 4 3 env10072 = env10073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env10072 == env10073) = true)

theorem identity10073 : scanCanonicalize (H12AffineFastState.compose env10073 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10074 : List Nat := [2,4,2,16,3,17,2,6,3,6,3,16,2,16,3,2,16,3,7,3,17,3,17,2,2,16,3,16,16,3,5,0,7,0,16,3]

theorem envBound10074 : H12AffineFastState.Bounded env10074 := by
  intro p hp
  have h : env10074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10073_10074 : H12AffineEnvironment.transform 2 2 env10073 = env10074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10073 == env10074) = true)

def leafEnv10074 : List Nat := [2,4,2,16,3,17,2,6,3,6,3,16,2,16,3,2,16,3,7,3,17,3,17,2,4,2,1,16,3,16,16,3,5,0,7,0,5,2,16,3,0,17,1]

def active10074 : List Nat := [0,1,3]

def tree10074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10074 : H12WitnessSearch.Good tree10074 := H12GlobalWitnessIndex.good

theorem leafIdentity10074 : H12AffineFastState.composeSystem env10074 rootObs = leafEnv10074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10074 rootObs == leafEnv10074) = true)

theorem terminalChecked10074 : H12PackedTerminal.terminalCheckFast leafEnv10074 active10074 tree10074 = true := by decide +kernel

def env10075 : List Nat := [2,4,8,16,32,64,9,87,88,87,33,65,8,16,82,3,65,83,86,82,64,83,17,3,9,65,82,16,16,32,5,115,86,0,65,88]

theorem envBound10075 : H12AffineFastState.Bounded env10075 := by
  intro p hp
  have h : env10075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10070_10075 : H12AffineEnvironment.transform 6 9 env10070 = env10075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10070 == env10075) = true)

theorem identity10075 : scanCanonicalize (H12AffineFastState.compose env10075 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound10075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10076 : List Nat := [2,4,8,16,3,64,9,87,88,87,2,65,8,16,82,3,65,83,86,82,64,83,17,3,9,65,82,16,16,3,5,80,86,0,65,88]

theorem envBound10076 : H12AffineFastState.Bounded env10076 := by
  intro p hp
  have h : env10076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10075_10076 : H12AffineEnvironment.transform 4 3 env10075 = env10076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env10075 == env10076) = true)

def env10077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,23445585,67130624,1297,1073741824,16876545,4294967296,256,4417151346,1345,33563272]

theorem envBound10077 : H12AffineFastState.Bounded env10077 := by
  intro p hp
  have h : env10077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9955_10077 : H12AffineEnvironment.transform 26 23445585 env9955 = env10077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env9955 == env10077) = true)

def env10078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352529,67130624,1297,1073741824,16876545,4294967296,256,4417151346,1345,33563272]

theorem envBound10078 : H12AffineFastState.Bounded env10078 := by
  intro p hp
  have h : env10078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10077_10078 : H12AffineEnvironment.transform 20 4096 env10077 = env10078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env10077 == env10078) = true)

def env10079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,16777216,33554432,67108864,21352528,67130624,1297,1073741824,16876545,4294967296,256,4417151346,1345,33563272]

theorem envBound10079 : H12AffineFastState.Bounded env10079 := by
  intro p hp
  have h : env10079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10077_10079 : H12AffineEnvironment.transform 20 4097 env10077 = env10079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env10077 == env10079) = true)

theorem identity10079 : scanCanonicalize (H12AffineFastState.compose env10079 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10079 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,16777216,33554432,5377,21352528,16385,1297,1073741824,16876545,4294967296,256,4350047347,1345,33563272]

theorem envBound10080 : H12AffineFastState.Bounded env10080 := by
  intro p hp
  have h : env10080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10079_10080 : H12AffineEnvironment.transform 25 5377 env10079 = env10080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env10079 == env10080) = true)

theorem identity10080 : scanCanonicalize (H12AffineFastState.compose env10080 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10080 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,16777216,8329,5377,21352528,16385,1297,1073741824,16876545,4294967296,256,4316484858,1345,513]

theorem envBound10081 : H12AffineFastState.Bounded env10081 := by
  intro p hp
  have h : env10081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10080_10081 : H12AffineEnvironment.transform 24 8329 env10080 = env10081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10080 == env10081) = true)

theorem identity10081 : scanCanonicalize (H12AffineFastState.compose env10081 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 644437) := by decide +kernel

theorem selectedBound10081 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,644437,8329,5377,4982021,16385,1297,1073741824,545108,4294967296,256,4299260335,1345,513]

theorem envBound10082 : H12AffineFastState.Bounded env10082 := by
  intro p hp
  have h : env10082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10081_10082 : H12AffineEnvironment.transform 23 644437 env10081 = env10082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644437 env10081 == env10082) = true)

theorem identity10082 : scanCanonicalize (H12AffineFastState.compose env10082 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4840666) := by decide +kernel

theorem selectedBound10082 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17665,644437,8329,5377,4982021,16385,1297,4840666,545108,4294967296,256,4299260335,1345,513]

theorem envBound10083 : H12AffineFastState.Bounded env10083 := by
  intro p hp
  have h : env10083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10082_10083 : H12AffineEnvironment.transform 29 4840666 env10082 = env10083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4840666 env10082 == env10083) = true)

theorem identity10083 : scanCanonicalize (H12AffineFastState.compose env10083 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound10083 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,524288,32768,4097,4194304,5457,623877,8329,5377,4982021,4177,1297,4820106,524548,4294967296,256,4299260335,1345,513]

theorem envBound10084 : H12AffineFastState.Bounded env10084 := by
  intro p hp
  have h : env10084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10083_10084 : H12AffineEnvironment.transform 13 4176 env10083 = env10084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10083 == env10084) = true)

theorem identity10084 : scanCanonicalize (H12AffineFastState.compose env10084 (packedSelected [6,25] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound10084 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1025,32768,4097,4194304,5457,98564,8329,5377,4456708,4177,1297,4294795,1285,4294967296,256,4299260335,1345,513]

theorem envBound10085 : H12AffineFastState.Bounded env10085 := by
  intro p hp
  have h : env10085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10084_10085 : H12AffineEnvironment.transform 18 1025 env10084 = env10085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10084 == env10085) = true)

theorem identity10085 : scanCanonicalize (H12AffineFastState.compose env10085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 99327) := by decide +kernel

theorem selectedBound10085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1025,32768,4097,4194304,5457,98564,8329,5377,4456708,4177,1297,4294795,1285,99327,256,4194896,1345,513]

theorem envBound10086 : H12AffineFastState.Bounded env10086 := by
  intro p hp
  have h : env10086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10085_10086 : H12AffineEnvironment.transform 31 99327 env10085 = env10086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 99327 env10085 == env10086) = true)

theorem identity10086 : scanCanonicalize (H12AffineFastState.compose env10086 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10086 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env10087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1992,32768,65536,1345,262144,1025,32768,1945,4194304,713,98564,8329,665,4456708,1993,1297,4294795,1285,99327,256,4194896,1345,513]

theorem envBound10087 : H12AffineFastState.Bounded env10087 := by
  intro p hp
  have h : env10087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10086_10087 : H12AffineEnvironment.transform 11 1944 env10086 = env10087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env10086 == env10087) = true)

theorem identity10087 : scanCanonicalize (H12AffineFastState.compose env10087 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10087 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env10088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1992,8461,65536,1345,262144,1025,8461,1945,4194304,713,73737,8329,665,4456708,1993,1297,4270470,1285,74482,256,4194896,1345,513]

theorem envBound10088 : H12AffineFastState.Bounded env10088 := by
  intro p hp
  have h : env10088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10087_10088 : H12AffineEnvironment.transform 14 8461 env10087 = env10088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10087 == env10088) = true)

theorem identity10088 : scanCanonicalize (H12AffineFastState.compose env10088 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 337801) := by decide +kernel

theorem selectedBound10088 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1992,8461,65536,1345,262144,1025,8461,1945,337801,713,73737,8329,665,75405,1993,1297,265743,1285,74482,256,337369,1345,513]

theorem envBound10089 : H12AffineFastState.Bounded env10089 := by
  intro p hp
  have h : env10089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10088_10089 : H12AffineEnvironment.transform 21 337801 env10088 = env10089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 337801 env10088 == env10089) = true)

def env10090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878608,4294967296,537002321,4417151346,34359738368,33563272]

theorem envBound10090 : H12AffineFastState.Bounded env10090 := by
  intro p hp
  have h : env10090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9447_10090 : H12AffineEnvironment.transform 27 67130625 env9447 = env10090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 67130625 env9447 == env10090) = true)

def env10091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878608,4294967296,537002321,4417151346,694534144,33563272]

theorem envBound10091 : H12AffineFastState.Bounded env10091 := by
  intro p hp
  have h : env10091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10090_10091 : H12AffineEnvironment.transform 34 694534144 env10090 = env10091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534144 env10090 == env10091) = true)

def env10092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,157794304,1073741824,140788816,4294967296,157663569,4417151346,131072,33563272]

theorem envBound10092 : H12AffineFastState.Bounded env10092 := by
  intro p hp
  have h : env10092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10091_10092 : H12AffineEnvironment.transform 28 157794304 env10091 = env10092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env10091 == env10092) = true)

def env10093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,23445584,67130625,131152,1073741824,16876544,4294967296,257,4417151346,131072,33563272]

theorem envBound10093 : H12AffineFastState.Bounded env10093 := by
  intro p hp
  have h : env10093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10092_10093 : H12AffineEnvironment.transform 26 23445584 env10092 = env10093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env10092 == env10093) = true)

def env10094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352528,67130625,131152,1073741824,16876544,4294967296,257,4417151346,131072,33563272]

theorem envBound10094 : H12AffineFastState.Bounded env10094 := by
  intro p hp
  have h : env10094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10093_10094 : H12AffineEnvironment.transform 20 4096 env10093 = env10094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env10093 == env10094) = true)

theorem identity10094 : scanCanonicalize (H12AffineFastState.compose env10094 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 17011013) := by decide +kernel

theorem selectedBound10094 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,17011013,21352528,17024068,131152,1073741824,16876544,4294967296,257,4333498423,131072,33563272]

theorem envBound10095 : H12AffineFastState.Bounded env10095 := by
  intro p hp
  have h : env10095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10094_10095 : H12AffineEnvironment.transform 25 17011013 env10094 = env10095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17011013 env10094 == env10095) = true)

def env10096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4096,4194304,17665,16777216,33554432,17011013,21352528,17024068,131152,1073741824,16876544,4294967296,257,4332975159,131072,33563272]

theorem envBound10096 : H12AffineFastState.Bounded env10096 := by
  intro p hp
  have h : env10096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10095_10096 : H12AffineEnvironment.transform 18 1024 env10095 = env10096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10095 == env10096) = true)

theorem identity10096 : scanCanonicalize (H12AffineFastState.compose env10096 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 21126302) := by decide +kernel

theorem selectedBound10096 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4096,4194304,17665,16777216,33554432,17011013,21352528,17024068,131152,21126302,16876544,4294967296,257,4332975159,131072,33563272]

theorem envBound10097 : H12AffineFastState.Bounded env10097 := by
  intro p hp
  have h : env10097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10096_10097 : H12AffineEnvironment.transform 29 21126302 env10096 = env10097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21126302 env10096 == env10097) = true)

def env10098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17011013,21332048,17011780,131152,21105822,16876544,4294967296,257,4332954679,131072,33563272]

theorem envBound10098 : H12AffineFastState.Bounded env10098 := by
  intro p hp
  have h : env10098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10097_10098 : H12AffineEnvironment.transform 13 4096 env10097 = env10098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env10097 == env10098) = true)

def env10099 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17010965,21331968,17011732,131072,21105822,16876544,4294967296,257,4332954679,131072,33563272]

theorem envBound10099 : H12AffineFastState.Bounded env10099 := by
  intro p hp
  have h : env10099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10098_10099 : H12AffineEnvironment.transform 5 16 env10098 = env10099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10098 == env10099) = true)

theorem identity10099 : scanCanonicalize (H12AffineFastState.compose env10099 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 17015964) := by decide +kernel

theorem selectedBound10099 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10100 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,17015964,17010965,21331968,17011732,131072,21105822,16876544,4294967296,257,4315938987,131072,17008148]

theorem envBound10100 : H12AffineFastState.Bounded env10100 := by
  intro p hp
  have h : env10100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10099_10100 : H12AffineEnvironment.transform 24 17015964 env10099 = env10100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17015964 env10099 == env10100) = true)

def env10101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17010964,21331969,17011733,131073,21105822,16876544,4294967296,257,4332954679,131072,33563272]

theorem envBound10101 : H12AffineFastState.Bounded env10101 := by
  intro p hp
  have h : env10101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10098_10101 : H12AffineEnvironment.transform 5 17 env10098 = env10101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10098 == env10101) = true)

theorem identity10101 : scanCanonicalize (H12AffineFastState.compose env10101 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 230421) := by decide +kernel

theorem selectedBound10101 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,230421,33554432,5377,4588564,4096,131073,4294795,131093,4294967296,257,4332954679,131072,33563272]

theorem envBound10102 : H12AffineFastState.Bounded env10102 := by
  intro p hp
  have h : env10102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10101_10102 : H12AffineEnvironment.transform 23 230421 env10101 = env10102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230421 env10101 == env10102) = true)

theorem identity10102 : scanCanonicalize (H12AffineFastState.compose env10102 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10102 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,230421,8329,5377,4588564,4096,131073,4294795,131093,4294967296,257,4299392190,131072,513]

theorem envBound10103 : H12AffineFastState.Bounded env10103 := by
  intro p hp
  have h : env10103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10102_10103 : H12AffineEnvironment.transform 24 8329 env10102 = env10103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10102 == env10103) = true)

theorem identity10103 : scanCanonicalize (H12AffineFastState.compose env10103 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound10103 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13341,65536,131072,262144,1024,13341,4096,4194304,5377,208904,8329,5377,4588564,4096,131073,4275350,131093,4294967296,257,4299370659,131072,513]

theorem envBound10104 : H12AffineFastState.Bounded env10104 := by
  intro p hp
  have h : env10104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10103_10104 : H12AffineEnvironment.transform 14 13341 env10103 = env10104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env10103 == env10104) = true)

theorem identity10104 : scanCanonicalize (H12AffineFastState.compose env10104 (packedSelected [0,5,7,8,13,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10104 : packedSelected [0,5,7,8,13,17,20] rootPS < 2^1333 := by decide +kernel

def env10105 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13341,65536,1297,262144,1024,13341,4096,4194304,5377,79129,8329,5377,4456709,4096,1296,4275350,1284,4294967296,257,4299240882,1297,513]

theorem envBound10105 : H12AffineFastState.Bounded env10105 := by
  intro p hp
  have h : env10105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10104_10105 : H12AffineEnvironment.transform 16 1297 env10104 = env10105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env10104 == env10105) = true)

theorem identity10105 : scanCanonicalize (H12AffineFastState.compose env10105 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10105 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10106 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4096,13341,65536,1297,262144,1024,13341,4096,4194304,5377,79129,8329,5377,4456709,4096,1296,4275350,1284,4294967296,257,4299240882,1297,137]

theorem envBound10106 : H12AffineFastState.Bounded env10106 := by
  intro p hp
  have h : env10106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10105_10106 : H12AffineEnvironment.transform 8 136 env10105 = env10106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10105 == env10106) = true)

theorem identity10106 : scanCanonicalize (H12AffineFastState.compose env10106 (packedSelected [1,6,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 81063) := by decide +kernel

theorem selectedBound10106 : packedSelected [1,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10107 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4096,13341,65536,1297,81063,1024,13341,4096,4194304,5377,79129,8329,5377,4275618,4096,1296,4275350,1284,4294967296,257,4299240882,1297,137]

theorem envBound10107 : H12AffineFastState.Bounded env10107 := by
  intro p hp
  have h : env10107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10106_10107 : H12AffineEnvironment.transform 17 81063 env10106 = env10107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81063 env10106 == env10107) = true)

theorem identity10107 : scanCanonicalize (H12AffineFastState.compose env10107 (packedSelected [6,8,13] rootPS)) = affineNative (2^(21+1) ^^^ 74135) := by decide +kernel

theorem selectedBound10107 : packedSelected [6,8,13] rootPS < 2^1333 := by decide +kernel

def env10108 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4096,13341,65536,1297,81063,1024,13341,4096,74135,5377,79129,8329,5377,7221,4096,1296,7425,1284,4294967296,257,4294972453,1297,137]

theorem envBound10108 : H12AffineFastState.Bounded env10108 := by
  intro p hp
  have h : env10108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10107_10108 : H12AffineEnvironment.transform 21 74135 env10107 = env10108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74135 env10107 == env10108) = true)

theorem identity10108 : scanCanonicalize (H12AffineFastState.compose env10108 (packedSelected [3,5,6,15] rootPS)) = affineNative (2^(15+1) ^^^ 13714) := by decide +kernel

theorem selectedBound10108 : packedSelected [3,5,6,15] rootPS < 2^1333 := by decide +kernel

def env10109 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4096,13341,13714,1297,2357,1024,13341,4096,5125,5377,139,8329,5377,7221,4096,1296,7425,1284,4294967296,257,4294972453,1297,137]

theorem envBound10109 : H12AffineFastState.Bounded env10109 := by
  intro p hp
  have h : env10109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10108_10109 : H12AffineEnvironment.transform 15 13714 env10108 = env10109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13714 env10108 == env10109) = true)

theorem identity10109 : scanCanonicalize (H12AffineFastState.compose env10109 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2104) := by decide +kernel

theorem selectedBound10109 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10110 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,2104,4096,7205,7594,1297,2357,1024,7205,4096,5125,5377,139,2225,5377,7221,4096,1296,7425,1284,4294967296,257,4294972453,1297,137]

theorem envBound10110 : H12AffineFastState.Bounded env10110 := by
  intro p hp
  have h : env10110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10109_10110 : H12AffineEnvironment.transform 12 2104 env10109 = env10110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2104 env10109 == env10110) = true)

theorem identity10110 : scanCanonicalize (H12AffineFastState.compose env10110 (packedSelected [8] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound10110 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10111 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1281,2104,1281,2340,2219,1297,2357,1024,2340,1281,260,0,139,2225,0,2356,1281,1296,2048,1284,4294967296,257,4294967588,1297,137]

theorem envBound10111 : H12AffineFastState.Bounded env10111 := by
  intro p hp
  have h : env10111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10110_10111 : H12AffineEnvironment.transform 11 1281 env10110 = env10111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env10110 == env10111) = true)

theorem identity10111 : scanCanonicalize (H12AffineFastState.compose env10111 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10111 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10112 : List Nat := [2,4,8,16,32,17,128,37,136,1024,2048,1060,2104,1060,2049,2219,1076,2064,1024,2049,1060,33,0,139,2225,0,2065,1060,1077,2048,1057,4294967296,36,4294967297,1076,137]

theorem envBound10112 : H12AffineFastState.Bounded env10112 := by
  intro p hp
  have h : env10112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10111_10112 : H12AffineEnvironment.transform 7 37 env10111 = env10112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10111 == env10112) = true)

def env10113 : List Nat := [2,4,8,0,32,1,128,37,136,1024,2048,1060,2088,1060,2049,2219,1060,2048,1024,2049,1060,33,0,139,2209,0,2049,1060,1061,2048,1057,4294967296,36,4294967297,1060,137]

theorem envBound10113 : H12AffineFastState.Bounded env10113 := by
  intro p hp
  have h : env10113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10112_10113 : H12AffineEnvironment.transform 3 0 env10112 = env10113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10112 == env10113) = true)

theorem identity10113 : scanCanonicalize (H12AffineFastState.compose env10113 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 163) := by decide +kernel

theorem selectedBound10113 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10114 : List Nat := [2,4,8,0,32,1,128,37,136,1024,2048,1060,2088,1060,2049,2219,1060,2048,1024,2049,1060,33,0,139,2209,0,2049,1060,1061,2048,1057,163,36,162,1060,137]

theorem envBound10114 : H12AffineFastState.Bounded env10114 := by
  intro p hp
  have h : env10114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10113_10114 : H12AffineEnvironment.transform 31 163 env10113 = env10114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 163 env10113 == env10114) = true)

def leafEnv10114 : List Nat := [2,4,8,0,32,1,128,37,136,1024,2048,1060,2088,1060,2049,2219,1060,2048,1024,2049,1060,33,0,139,1057,2209,1,0,2049,1060,1061,2048,1057,163,36,162,5,2083,1060,137,0,1061,1]

def active10114 : List Nat := [0,1,2,4,6,9,10]

def tree10114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10114 : H12WitnessSearch.Good tree10114 := H12GlobalWitnessIndex.good

theorem leafIdentity10114 : H12AffineFastState.composeSystem env10114 rootObs = leafEnv10114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10114 rootObs == leafEnv10114) = true)

theorem terminalChecked10114 : H12PackedTerminal.terminalCheckFast leafEnv10114 active10114 tree10114 = true := by decide +kernel

def env10115 : List Nat := [2,4,8,1,32,0,128,37,136,1024,2048,1060,2089,1060,2049,2219,1061,2049,1024,2049,1060,33,0,139,2208,0,2048,1060,1060,2048,1057,4294967296,36,4294967297,1061,137]

theorem envBound10115 : H12AffineFastState.Bounded env10115 := by
  intro p hp
  have h : env10115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10112_10115 : H12AffineEnvironment.transform 3 1 env10112 = env10115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10112 == env10115) = true)

theorem identity10115 : scanCanonicalize (H12AffineFastState.compose env10115 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 43) := by decide +kernel

theorem selectedBound10115 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10116 : List Nat := [2,4,8,1,32,0,128,37,136,1024,2048,1060,2089,1060,2049,2219,1061,2049,1024,2049,1060,33,0,139,2208,0,2048,1060,1060,2048,1057,43,36,42,1061,137]

theorem envBound10116 : H12AffineFastState.Bounded env10116 := by
  intro p hp
  have h : env10116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10115_10116 : H12AffineEnvironment.transform 31 43 env10115 = env10116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 43 env10115 == env10116) = true)

def leafEnv10116 : List Nat := [2,4,8,1,32,0,128,37,136,1024,2048,1060,2089,1060,2049,2219,1061,2049,1024,2049,1060,33,0,139,1057,2208,1,0,2048,1060,1060,2048,1057,43,36,42,5,2083,1061,137,0,1060,1]

def active10116 : List Nat := [0,1,2,4,6,9,10]

def tree10116 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10116 : H12WitnessSearch.Good tree10116 := H12GlobalWitnessIndex.good

theorem leafIdentity10116 : H12AffineFastState.composeSystem env10116 rootObs = leafEnv10116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10116 rootObs == leafEnv10116) = true)

theorem terminalChecked10116 : H12PackedTerminal.terminalCheckFast leafEnv10116 active10116 tree10116 = true := by decide +kernel

def env10117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17011013,21332049,17011781,131152,21105823,16876544,4294967296,257,4332954678,131072,33563272]

theorem envBound10117 : H12AffineFastState.Bounded env10117 := by
  intro p hp
  have h : env10117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10097_10117 : H12AffineEnvironment.transform 13 4097 env10097 = env10117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10097 == env10117) = true)

def env10118 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17010965,21331969,17011733,131072,21105823,16876544,4294967296,257,4332954678,131072,33563272]

theorem envBound10118 : H12AffineFastState.Bounded env10118 := by
  intro p hp
  have h : env10118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10117_10118 : H12AffineEnvironment.transform 5 16 env10117 = env10118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10117 == env10118) = true)

theorem identity10118 : scanCanonicalize (H12AffineFastState.compose env10118 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 230420) := by decide +kernel

theorem selectedBound10118 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,230420,33554432,5377,4588565,4097,131072,4294795,131092,4294967296,257,4332954678,131072,33563272]

theorem envBound10119 : H12AffineFastState.Bounded env10119 := by
  intro p hp
  have h : env10119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10118_10119 : H12AffineEnvironment.transform 23 230420 env10118 = env10119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230420 env10118 == env10119) = true)

theorem identity10119 : scanCanonicalize (H12AffineFastState.compose env10119 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10119 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,230420,8329,5377,4588565,4097,131072,4294795,131092,4294967296,257,4299392191,131072,513]

theorem envBound10120 : H12AffineFastState.Bounded env10120 := by
  intro p hp
  have h : env10120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10119_10120 : H12AffineEnvironment.transform 24 8329 env10119 = env10120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10119 == env10120) = true)

theorem identity10120 : scanCanonicalize (H12AffineFastState.compose env10120 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound10120 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,13341,65536,131072,262144,1024,13341,4096,4194304,5376,208905,8329,5377,4588565,4097,131072,4275350,131092,4294967296,257,4299370658,131072,513]

theorem envBound10121 : H12AffineFastState.Bounded env10121 := by
  intro p hp
  have h : env10121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10120_10121 : H12AffineEnvironment.transform 14 13341 env10120 = env10121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env10120 == env10121) = true)

theorem identity10121 : scanCanonicalize (H12AffineFastState.compose env10121 (packedSelected [0,5,7,8,13,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10121 : packedSelected [0,5,7,8,13,17,20] rootPS < 2^1333 := by decide +kernel

def env10122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,13341,65536,1296,262144,1024,13341,4096,4194304,5376,79129,8329,5377,4456709,4097,1296,4275350,1284,4294967296,257,4299240882,1296,513]

theorem envBound10122 : H12AffineFastState.Bounded env10122 := by
  intro p hp
  have h : env10122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10121_10122 : H12AffineEnvironment.transform 16 1296 env10121 = env10122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env10121 == env10122) = true)

theorem identity10122 : scanCanonicalize (H12AffineFastState.compose env10122 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10122 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10123 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,13341,65536,1296,262144,1024,13341,4096,4194304,5376,79129,8329,5377,4456709,4097,1296,4275350,1284,4294967296,257,4299240882,1296,137]

theorem envBound10123 : H12AffineFastState.Bounded env10123 := by
  intro p hp
  have h : env10123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10122_10123 : H12AffineEnvironment.transform 8 136 env10122 = env10123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10122 == env10123) = true)

theorem identity10123 : scanCanonicalize (H12AffineFastState.compose env10123 (packedSelected [1,6,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 76214) := by decide +kernel

theorem selectedBound10123 : packedSelected [1,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10124 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,13341,65536,1296,76214,1024,13341,4096,4194304,5376,79129,8329,5377,4270259,4097,1296,4275350,1284,4294967296,257,4299240882,1296,137]

theorem envBound10124 : H12AffineFastState.Bounded env10124 := by
  intro p hp
  have h : env10124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10123_10124 : H12AffineEnvironment.transform 17 76214 env10123 = env10124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76214 env10123 == env10124) = true)

theorem identity10124 : scanCanonicalize (H12AffineFastState.compose env10124 (packedSelected [6,8,13] rootPS)) = affineNative (2^(21+1) ^^^ 78982) := by decide +kernel

theorem selectedBound10124 : packedSelected [6,8,13] rootPS < 2^1333 := by decide +kernel

def env10125 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,13341,65536,1296,76214,1024,13341,4096,78982,5376,79129,8329,5377,7221,4097,1296,2064,1284,4294967296,257,4294967604,1296,137]

theorem envBound10125 : H12AffineFastState.Bounded env10125 := by
  intro p hp
  have h : env10125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10124_10125 : H12AffineEnvironment.transform 21 78982 env10124 = env10125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 78982 env10124 == env10125) = true)

theorem identity10125 : scanCanonicalize (H12AffineFastState.compose env10125 (packedSelected [3,5,6,15] rootPS)) = affineNative (2^(15+1) ^^^ 13714) := by decide +kernel

theorem selectedBound10125 : packedSelected [3,5,6,15] rootPS < 2^1333 := by decide +kernel

def env10126 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,13341,13714,1296,7204,1024,13341,4096,276,5376,139,8329,5377,7221,4097,1296,2064,1284,4294967296,257,4294967604,1296,137]

theorem envBound10126 : H12AffineFastState.Bounded env10126 := by
  intro p hp
  have h : env10126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10125_10126 : H12AffineEnvironment.transform 15 13714 env10125 = env10126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13714 env10125 == env10126) = true)

theorem identity10126 : scanCanonicalize (H12AffineFastState.compose env10126 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 7481) := by decide +kernel

theorem selectedBound10126 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10127 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,7481,4097,2340,2219,1296,7204,1024,2340,4096,276,5376,139,7600,5377,7221,4097,1296,2064,1284,4294967296,257,4294967604,1296,137]

theorem envBound10127 : H12AffineFastState.Bounded env10127 := by
  intro p hp
  have h : env10127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10126_10127 : H12AffineEnvironment.transform 12 7481 env10126 = env10127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7481 env10126 == env10127) = true)

theorem identity10127 : scanCanonicalize (H12AffineFastState.compose env10127 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10127 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10128 : List Nat := [2,4,8,0,32,0,128,256,136,1024,2048,4096,7465,4097,2340,2219,1280,7204,1024,2340,4096,260,5376,139,7584,5377,7205,4097,1280,2048,1284,4294967296,257,4294967588,1280,137]

theorem envBound10128 : H12AffineFastState.Bounded env10128 := by
  intro p hp
  have h : env10128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10127_10128 : H12AffineEnvironment.transform 3 0 env10127 = env10128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10127 == env10128) = true)

theorem identity10128 : scanCanonicalize (H12AffineFastState.compose env10128 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10128 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10129 : List Nat := [2,4,8,0,32,0,128,37,136,1024,2048,4096,7180,4097,2049,2219,1061,7204,1024,2049,4096,33,5157,139,7301,5156,7205,4097,1061,2048,1057,4294967296,36,4294967297,1061,137]

theorem envBound10129 : H12AffineFastState.Bounded env10129 := by
  intro p hp
  have h : env10129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10128_10129 : H12AffineEnvironment.transform 7 37 env10128 = env10129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10128 == env10129) = true)

def env10130 : List Nat := [2,4,8,0,32,0,8,37,0,1024,2048,4096,7180,4097,2049,2083,1061,7204,1024,2049,4096,33,5157,3,7181,5156,7205,4097,1061,2048,1057,4294967296,36,4294967297,1061,1]

theorem envBound10130 : H12AffineFastState.Bounded env10130 := by
  intro p hp
  have h : env10130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10129_10130 : H12AffineEnvironment.transform 6 8 env10129 = env10130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10129 == env10130) = true)

theorem identity10130 : scanCanonicalize (H12AffineFastState.compose env10130 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 43) := by decide +kernel

theorem selectedBound10130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10131 : List Nat := [2,4,8,0,32,0,8,37,0,1024,2048,4096,7180,4097,2049,2083,1061,7204,1024,2049,4096,33,5157,3,7181,5156,7205,4097,1061,2048,1057,43,36,42,1061,1]

theorem envBound10131 : H12AffineFastState.Bounded env10131 := by
  intro p hp
  have h : env10131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10130_10131 : H12AffineEnvironment.transform 31 43 env10130 = env10131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 43 env10130 == env10131) = true)

def leafEnv10131 : List Nat := [2,4,8,0,32,0,8,37,0,1024,2048,4096,7180,4097,2049,2083,1061,7204,1024,2049,4096,33,5157,3,1057,7181,1,5156,7205,4097,1061,2048,1057,43,36,42,5,2083,1061,1,0,1061,1]

def active10131 : List Nat := [0,1,2,4,9,10,11]

def tree10131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10131 : H12WitnessSearch.Good tree10131 := H12GlobalWitnessIndex.good

theorem leafIdentity10131 : H12AffineFastState.composeSystem env10131 rootObs = leafEnv10131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10131 rootObs == leafEnv10131) = true)

theorem terminalChecked10131 : H12PackedTerminal.terminalCheckFast leafEnv10131 active10131 tree10131 = true := by decide +kernel

def env10132 : List Nat := [2,4,8,0,32,0,9,37,1,1024,2048,4096,7180,4097,2049,2082,1061,7204,1024,2049,4096,33,5157,2,7180,5156,7205,4097,1061,2048,1057,4294967296,36,4294967297,1061,0]

theorem envBound10132 : H12AffineFastState.Bounded env10132 := by
  intro p hp
  have h : env10132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10129_10132 : H12AffineEnvironment.transform 6 9 env10129 = env10132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10129 == env10132) = true)

theorem identity10132 : scanCanonicalize (H12AffineFastState.compose env10132 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 5134) := by decide +kernel

theorem selectedBound10132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10133 : List Nat := [2,4,8,0,32,0,9,37,1,1024,2048,4096,7180,4097,2049,2082,1061,7204,1024,2049,4096,33,5157,2,7180,5156,7205,4097,1061,2048,1057,5134,36,5135,1061,0]

theorem envBound10133 : H12AffineFastState.Bounded env10133 := by
  intro p hp
  have h : env10133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10132_10133 : H12AffineEnvironment.transform 31 5134 env10132 = env10133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5134 env10132 == env10133) = true)

def leafEnv10133 : List Nat := [2,4,8,0,32,0,9,37,1,1024,2048,4096,7180,4097,2049,2082,1061,7204,1024,2049,4096,33,5157,2,1057,7180,1,5156,7205,4097,1061,2048,1057,5134,36,5135,5,2083,1061,0,0,1061,1]

def active10133 : List Nat := [0,1,2,4,9,10,11]

def tree10133 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10133 : H12WitnessSearch.Good tree10133 := H12GlobalWitnessIndex.good

theorem leafIdentity10133 : H12AffineFastState.composeSystem env10133 rootObs = leafEnv10133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10133 rootObs == leafEnv10133) = true)

theorem terminalChecked10133 : H12PackedTerminal.terminalCheckFast leafEnv10133 active10133 tree10133 = true := by decide +kernel

def env10134 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17010964,21331968,17011732,131073,21105823,16876544,4294967296,257,4332954678,131072,33563272]

theorem envBound10134 : H12AffineFastState.Bounded env10134 := by
  intro p hp
  have h : env10134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10117_10134 : H12AffineEnvironment.transform 5 17 env10117 = env10134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10117 == env10134) = true)

theorem identity10134 : scanCanonicalize (H12AffineFastState.compose env10134 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 17015965) := by decide +kernel

theorem selectedBound10134 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,17015965,17010964,21331968,17011732,131073,21105823,16876544,4294967296,257,4315938987,131072,17008149]

theorem envBound10135 : H12AffineFastState.Bounded env10135 := by
  intro p hp
  have h : env10135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10134_10135 : H12AffineEnvironment.transform 24 17015965 env10134 = env10135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17015965 env10134 == env10135) = true)

def env10136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17011013,21352528,17024068,131152,1073741824,16876544,4294967296,257,4332975158,131072,33563272]

theorem envBound10136 : H12AffineFastState.Bounded env10136 := by
  intro p hp
  have h : env10136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10095_10136 : H12AffineEnvironment.transform 18 1025 env10095 = env10136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10095 == env10136) = true)

theorem identity10136 : scanCanonicalize (H12AffineFastState.compose env10136 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 21105870) := by decide +kernel

theorem selectedBound10136 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17011013,21352528,17024068,131152,21105870,16876544,4294967296,257,4332975158,131072,33563272]

theorem envBound10137 : H12AffineFastState.Bounded env10137 := by
  intro p hp
  have h : env10137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10136_10137 : H12AffineEnvironment.transform 29 21105870 env10136 = env10137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21105870 env10136 == env10137) = true)

def env10138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352448,17024020,131072,21105822,16876544,4294967296,257,4332975158,131072,33563272]

theorem envBound10138 : H12AffineFastState.Bounded env10138 := by
  intro p hp
  have h : env10138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10137_10138 : H12AffineEnvironment.transform 5 16 env10137 = env10138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10137 == env10138) = true)

def env10139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352448,17024020,131072,21105822,16876544,4294967296,257,4332967606,131072,33554440]

theorem envBound10139 : H12AffineFastState.Bounded env10139 := by
  intro p hp
  have h : env10139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10138_10139 : H12AffineEnvironment.transform 12 640 env10138 = env10139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env10138 == env10139) = true)

def env10140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352448,16897044,4096,20978846,16876544,4294967296,257,4332832438,4096,33554440]

theorem envBound10140 : H12AffineFastState.Bounded env10140 := by
  intro p hp
  have h : env10140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10139_10140 : H12AffineEnvironment.transform 16 4096 env10139 = env10140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10139 == env10140) = true)

theorem identity10140 : scanCanonicalize (H12AffineFastState.compose env10140 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 20608) := by decide +kernel

theorem selectedBound10140 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10141 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,20608,16875797,21352448,16897044,4096,20978846,16876544,4294967296,257,4299265590,4096,20616]

theorem envBound10141 : H12AffineFastState.Bounded env10141 := by
  intro p hp
  have h : env10141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10140_10141 : H12AffineEnvironment.transform 24 20608 env10140 = env10141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 20608 env10140 == env10141) = true)

def env10142 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,16777216,128,16875797,21331968,16876564,4096,20978846,16876544,4294967296,257,4299265590,4096,136]

theorem envBound10142 : H12AffineFastState.Bounded env10142 := by
  intro p hp
  have h : env10142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10141_10142 : H12AffineEnvironment.transform 13 4096 env10141 = env10142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env10141 == env10142) = true)

def env10143 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,4293120,128,4195093,262656,4195860,4096,106142,4195840,4294967296,257,4299265590,4096,136]

theorem envBound10143 : H12AffineFastState.Bounded env10143 := by
  intro p hp
  have h : env10143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10142_10143 : H12AffineEnvironment.transform 23 4293120 env10142 = env10143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293120 env10142 == env10143) = true)

def env10144 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,640,1296,32768,65536,1296,262144,1025,32768,1296,4194304,17,4293120,128,4195093,262656,4195860,1296,101262,4195840,4294967296,257,4299260710,1296,136]

theorem envBound10144 : H12AffineFastState.Bounded env10144 := by
  intro p hp
  have h : env10144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10143_10144 : H12AffineEnvironment.transform 11 1296 env10143 = env10144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10143 == env10144) = true)

theorem identity10144 : scanCanonicalize (H12AffineFastState.compose env10144 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 98306) := by decide +kernel

theorem selectedBound10144 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10145 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,640,1296,32768,65536,1296,262144,1025,32768,1296,98306,17,514,128,99095,262656,99862,1296,101262,99842,4294967296,257,4294968100,1296,136]

theorem envBound10145 : H12AffineFastState.Bounded env10145 := by
  intro p hp
  have h : env10145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10144_10145 : H12AffineEnvironment.transform 21 98306 env10144 = env10145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98306 env10144 == env10145) = true)

theorem identity10145 : scanCanonicalize (H12AffineFastState.compose env10145 (packedSelected [4,6,9,16,25] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound10145 : packedSelected [4,6,9,16,25] rootPS < 2^1333 := by decide +kernel

def env10146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,640,1296,32768,33542,1296,262144,1025,32768,1296,772,17,514,128,17,262656,1296,1296,2184,1284,4294967296,257,4294968100,1296,136]

theorem envBound10146 : H12AffineFastState.Bounded env10146 := by
  intro p hp
  have h : env10146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10145_10146 : H12AffineEnvironment.transform 15 33542 env10145 = env10146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env10145 == env10146) = true)

theorem identity10146 : scanCanonicalize (H12AffineFastState.compose env10146 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10146 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10147 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1296,520,1296,32768,33542,1296,262144,1025,32768,1296,772,17,514,8,17,262656,1296,1296,2048,1284,4294967296,257,4294968100,1296,0]

theorem envBound10147 : H12AffineFastState.Bounded env10147 := by
  intro p hp
  have h : env10147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10146_10147 : H12AffineEnvironment.transform 6 8 env10146 = env10147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10146 == env10147) = true)

theorem identity10147 : scanCanonicalize (H12AffineFastState.compose env10147 (packedSelected [10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 34848) := by decide +kernel

theorem selectedBound10147 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env10148 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1296,520,1296,32768,33542,1296,34848,1025,32768,1296,772,17,514,8,17,35360,1296,1296,2048,1284,4294967296,257,4294968100,1296,0]

theorem envBound10148 : H12AffineFastState.Bounded env10148 := by
  intro p hp
  have h : env10148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10147_10148 : H12AffineEnvironment.transform 17 34848 env10147 = env10148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34848 env10147 == env10148) = true)

theorem identity10148 : scanCanonicalize (H12AffineFastState.compose env10148 (packedSelected [12,15] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10148 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env10149 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1296,8,1296,32768,33030,1296,34848,1025,32768,1296,260,17,2,8,17,34848,1296,1296,2048,1284,4294967296,257,4294967588,1296,0]

theorem envBound10149 : H12AffineFastState.Bounded env10149 := by
  intro p hp
  have h : env10149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10148_10149 : H12AffineEnvironment.transform 8 0 env10148 = env10149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10148 == env10149) = true)

theorem identity10149 : scanCanonicalize (H12AffineFastState.compose env10149 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 35078) := by decide +kernel

theorem selectedBound10149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10150 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1296,8,1296,32768,33030,1296,34848,1025,32768,1296,260,17,2,8,17,34848,1296,1296,2048,1284,35078,257,34850,1296,0]

theorem envBound10150 : H12AffineFastState.Bounded env10150 := by
  intro p hp
  have h : env10150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10149_10150 : H12AffineEnvironment.transform 31 35078 env10149 = env10150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 35078 env10149 == env10150) = true)

theorem identity10150 : scanCanonicalize (H12AffineFastState.compose env10150 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2050) := by decide +kernel

theorem selectedBound10150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10151 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1296,8,1296,2050,2308,1296,34,1025,2050,1296,260,17,2,8,17,34,1296,1296,2048,1284,260,257,32,1296,0]

theorem envBound10151 : H12AffineFastState.Bounded env10151 := by
  intro p hp
  have h : env10151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10150_10151 : H12AffineEnvironment.transform 14 2050 env10150 = env10151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2050 env10150 == env10151) = true)

theorem identity10151 : scanCanonicalize (H12AffineFastState.compose env10151 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 295) := by decide +kernel

theorem selectedBound10151 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10152 : List Nat := [2,4,8,16,32,16,8,256,0,1024,295,1296,8,1296,293,35,1296,34,1025,293,1296,260,17,2,8,17,34,1296,1296,295,1284,260,257,32,1296,0]

theorem envBound10152 : H12AffineFastState.Bounded env10152 := by
  intro p hp
  have h : env10152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10151_10152 : H12AffineEnvironment.transform 10 295 env10151 = env10152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 295 env10151 == env10152) = true)

theorem identity10152 : scanCanonicalize (H12AffineFastState.compose env10152 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10152 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10153 : List Nat := [2,4,8,16,1,16,8,256,0,1024,262,1296,8,1296,260,2,1296,3,1025,260,1296,260,17,2,8,17,3,1296,1296,262,1284,260,257,1,1296,0]

theorem envBound10153 : H12AffineFastState.Bounded env10153 := by
  intro p hp
  have h : env10153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10152_10153 : H12AffineEnvironment.transform 4 1 env10152 = env10153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10152 == env10153) = true)

theorem identity10153 : scanCanonicalize (H12AffineFastState.compose env10153 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound10153 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10154 : List Nat := [2,4,8,16,1,16,8,256,0,256,262,16,8,16,260,2,16,3,257,260,16,260,17,2,8,17,3,16,16,262,4,260,257,1,16,0]

theorem envBound10154 : H12AffineFastState.Bounded env10154 := by
  intro p hp
  have h : env10154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10153_10154 : H12AffineEnvironment.transform 9 256 env10153 = env10154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env10153 == env10154) = true)

theorem identity10154 : scanCanonicalize (H12AffineFastState.compose env10154 (packedSelected [4,11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound10154 : packedSelected [4,11] rootPS < 2^1333 := by decide +kernel

def env10155 : List Nat := [2,4,1,16,1,16,1,256,0,256,262,16,1,16,260,2,16,3,257,260,16,260,17,2,1,17,3,16,16,262,4,260,257,1,16,0]

theorem envBound10155 : H12AffineFastState.Bounded env10155 := by
  intro p hp
  have h : env10155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10154_10155 : H12AffineEnvironment.transform 2 1 env10154 = env10155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env10154 == env10155) = true)

theorem identity10155 : scanCanonicalize (H12AffineFastState.compose env10155 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10155 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10156 : List Nat := [2,4,1,16,1,16,1,5,0,5,3,16,1,16,1,2,16,3,4,1,16,1,17,2,1,17,3,16,16,3,4,1,4,1,16,0]

theorem envBound10156 : H12AffineFastState.Bounded env10156 := by
  intro p hp
  have h : env10156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10155_10156 : H12AffineEnvironment.transform 7 5 env10155 = env10156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10155 == env10156) = true)

theorem identity10156 : scanCanonicalize (H12AffineFastState.compose env10156 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10156 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10157 : List Nat := [0,4,1,16,1,16,1,5,0,5,1,16,1,16,1,0,16,1,4,1,16,1,17,0,1,17,1,16,16,1,4,1,4,1,16,0]

theorem envBound10157 : H12AffineFastState.Bounded env10157 := by
  intro p hp
  have h : env10157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10156_10157 : H12AffineEnvironment.transform 0 0 env10156 = env10157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10156 == env10157) = true)

def env10158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,640,1297,32768,65536,1297,262144,1025,32768,1297,4194304,16,4293120,128,4195093,262656,4195860,1297,101263,4195840,4294967296,257,4299260711,1297,136]

theorem envBound10158 : H12AffineFastState.Bounded env10158 := by
  intro p hp
  have h : env10158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10143_10158 : H12AffineEnvironment.transform 11 1297 env10143 = env10158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10143 == env10158) = true)

theorem identity10158 : scanCanonicalize (H12AffineFastState.compose env10158 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 264360) := by decide +kernel

theorem selectedBound10158 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,640,1297,32768,65536,1297,262144,1025,32768,1297,264360,16,363176,128,265149,262656,265916,1297,101263,265896,4294967296,257,4295330703,1297,136]

theorem envBound10159 : H12AffineFastState.Bounded env10159 := by
  intro p hp
  have h : env10159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10158_10159 : H12AffineEnvironment.transform 21 264360 env10158 = env10159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264360 env10158 == env10159) = true)

theorem identity10159 : scanCanonicalize (H12AffineFastState.compose env10159 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 2989) := by decide +kernel

theorem selectedBound10159 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env10160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,640,1297,32768,65536,1297,2989,1025,32768,1297,773,16,98565,128,16,2477,1297,1297,101263,1285,4294967296,257,4295065634,1297,136]

theorem envBound10160 : H12AffineFastState.Bounded env10160 := by
  intro p hp
  have h : env10160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10159_10160 : H12AffineEnvironment.transform 17 2989 env10159 = env10160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2989 env10159 == env10160) = true)

theorem identity10160 : scanCanonicalize (H12AffineFastState.compose env10160 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 33288) := by decide +kernel

theorem selectedBound10160 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10161 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,640,1297,32768,33288,1297,2989,1025,32768,1297,773,16,781,128,16,2477,1297,1297,2439,1285,4294967296,257,4294967850,1297,136]

theorem envBound10161 : H12AffineFastState.Bounded env10161 := by
  intro p hp
  have h : env10161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10160_10161 : H12AffineEnvironment.transform 15 33288 env10160 = env10161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33288 env10160 == env10161) = true)

theorem identity10161 : scanCanonicalize (H12AffineFastState.compose env10161 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10161 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10162 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,640,1297,261,781,1297,2989,1025,261,1297,773,16,781,128,16,2477,1297,1297,2439,1285,4294967296,257,4294967850,1297,136]

theorem envBound10162 : H12AffineFastState.Bounded env10162 := by
  intro p hp
  have h : env10162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10161_10162 : H12AffineEnvironment.transform 14 261 env10161 = env10162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10161 == env10162) = true)

theorem identity10162 : scanCanonicalize (H12AffineFastState.compose env10162 (packedSelected [3,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound10162 : packedSelected [3,10,12] rootPS < 2^1333 := by decide +kernel

def env10163 : List Nat := [2,4,8,16,32,16,128,15,512,1024,2048,1054,640,1054,10,514,1054,2722,1025,10,1054,522,16,514,128,16,2210,1054,1054,2184,1034,4294967296,14,4294967850,1054,136]

theorem envBound10163 : H12AffineFastState.Bounded env10163 := by
  intro p hp
  have h : env10163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10162_10163 : H12AffineEnvironment.transform 7 15 env10162 = env10163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env10162 == env10163) = true)

theorem identity10163 : scanCanonicalize (H12AffineFastState.compose env10163 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10163 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10164 : List Nat := [2,4,8,16,32,16,34,15,512,1024,2048,1054,546,1054,10,514,1054,2560,1025,10,1054,522,16,514,34,16,2048,1054,1054,2090,1034,4294967296,14,4294967850,1054,42]

theorem envBound10164 : H12AffineFastState.Bounded env10164 := by
  intro p hp
  have h : env10164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10163_10164 : H12AffineEnvironment.transform 6 34 env10163 = env10164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10163 == env10164) = true)

theorem identity10164 : scanCanonicalize (H12AffineFastState.compose env10164 (packedSelected [0,6,7] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound10164 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env10165 : List Nat := [2,4,8,16,32,16,34,15,512,1024,2048,1054,546,1054,10,514,1054,2560,1025,10,1054,522,16,514,34,16,2048,1054,1054,2090,1034,513,14,43,1054,42]

theorem envBound10165 : H12AffineFastState.Bounded env10165 := by
  intro p hp
  have h : env10165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10164_10165 : H12AffineEnvironment.transform 31 513 env10164 = env10165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env10164 == env10165) = true)

theorem identity10165 : scanCanonicalize (H12AffineFastState.compose env10165 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10165 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10166 : List Nat := [2,4,8,16,0,16,2,15,512,1024,2048,1054,514,1054,10,514,1054,2560,1025,10,1054,522,16,514,2,16,2048,1054,1054,2058,1034,513,14,11,1054,10]

theorem envBound10166 : H12AffineFastState.Bounded env10166 := by
  intro p hp
  have h : env10166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10165_10166 : H12AffineEnvironment.transform 4 0 env10165 = env10166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10165 == env10166) = true)

theorem identity10166 : scanCanonicalize (H12AffineFastState.compose env10166 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound10166 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env10167 : List Nat := [2,4,8,16,0,16,2,15,512,1024,512,1054,514,1054,10,514,1054,0,1025,10,1054,522,16,514,2,16,512,1054,1054,522,1034,513,14,11,1054,10]

theorem envBound10167 : H12AffineFastState.Bounded env10167 := by
  intro p hp
  have h : env10167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10166_10167 : H12AffineEnvironment.transform 10 512 env10166 = env10167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env10166 == env10167) = true)

theorem identity10167 : scanCanonicalize (H12AffineFastState.compose env10167 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10168 : List Nat := [2,4,2,16,0,16,2,5,512,1024,512,1044,514,1044,0,514,1044,0,1025,0,1044,512,16,514,2,16,512,1044,1044,512,1024,513,4,1,1044,0]

theorem envBound10168 : H12AffineFastState.Bounded env10168 := by
  intro p hp
  have h : env10168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10167_10168 : H12AffineEnvironment.transform 2 2 env10167 = env10168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10167 == env10168) = true)

theorem identity10168 : scanCanonicalize (H12AffineFastState.compose env10168 (packedSelected [1,13] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10168 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env10169 : List Nat := [2,4,2,16,0,16,2,5,0,1024,0,1044,2,1044,0,2,1044,0,1025,0,1044,0,16,2,2,16,0,1044,1044,0,1024,1,4,1,1044,0]

theorem envBound10169 : H12AffineFastState.Bounded env10169 := by
  intro p hp
  have h : env10169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10168_10169 : H12AffineEnvironment.transform 8 0 env10168 = env10169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10168 == env10169) = true)

theorem identity10169 : scanCanonicalize (H12AffineFastState.compose env10169 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound10169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10170 : List Nat := [2,4,2,3,0,3,2,5,0,1024,0,1031,2,1031,0,2,1031,0,1025,0,1031,0,3,2,2,3,0,1031,1031,0,1024,1,4,1,1031,0]

theorem envBound10170 : H12AffineFastState.Bounded env10170 := by
  intro p hp
  have h : env10170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10169_10170 : H12AffineEnvironment.transform 3 3 env10169 = env10170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env10169 == env10170) = true)

theorem identity10170 : scanCanonicalize (H12AffineFastState.compose env10170 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound10170 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10171 : List Nat := [2,4,2,3,0,3,2,5,0,4,0,3,2,3,0,2,3,0,5,0,3,0,3,2,2,3,0,3,3,0,4,1,4,1,3,0]

theorem envBound10171 : H12AffineFastState.Bounded env10171 := by
  intro p hp
  have h : env10171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10170_10171 : H12AffineEnvironment.transform 9 4 env10170 = env10171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env10170 == env10171) = true)

def leafEnv10171 : List Nat := [2,4,2,3,0,3,2,5,0,4,0,3,2,3,0,2,3,0,5,0,3,0,3,2,5,2,1,3,0,3,3,0,4,1,4,1,5,2,3,0,0,3,1]

def active10171 : List Nat := [0,1]

def tree10171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10171 : H12WitnessSearch.Good tree10171 := H12GlobalWitnessIndex.good

theorem leafIdentity10171 : H12AffineFastState.composeSystem env10171 rootObs = leafEnv10171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10171 rootObs == leafEnv10171) = true)

theorem terminalChecked10171 : H12PackedTerminal.terminalCheckFast leafEnv10171 active10171 tree10171 = true := by decide +kernel

def env10172 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,4293121,128,4195092,262657,4195861,4096,106143,4195841,4294967296,257,4299265590,4096,136]

theorem envBound10172 : H12AffineFastState.Bounded env10172 := by
  intro p hp
  have h : env10172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10142_10172 : H12AffineEnvironment.transform 23 4293121 env10142 = env10172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293121 env10142 == env10172) = true)

theorem identity10172 : scanCanonicalize (H12AffineFastState.compose env10172 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10172 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env10173 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,4292744,128,4194717,262280,4195484,4096,105494,4195464,4294967296,257,4299265215,4096,136]

theorem envBound10173 : H12AffineFastState.Bounded env10173 := by
  intro p hp
  have h : env10173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10172_10173 : H12AffineEnvironment.transform 8 137 env10172 = env10173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10172 == env10173) = true)

theorem identity10173 : scanCanonicalize (H12AffineFastState.compose env10173 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 5276) := by decide +kernel

theorem selectedBound10173 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10174 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,65536,4096,262144,1025,32768,4096,5276,5377,103444,128,5377,262280,4096,4096,105494,4116,4294967296,257,4295065635,4096,136]

theorem envBound10174 : H12AffineFastState.Bounded env10174 := by
  intro p hp
  have h : env10174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10173_10174 : H12AffineEnvironment.transform 21 5276 env10173 = env10174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5276 env10173 == env10174) = true)

theorem identity10174 : scanCanonicalize (H12AffineFastState.compose env10174 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 295075) := by decide +kernel

theorem selectedBound10174 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10175 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,65536,4096,262144,1025,32768,4096,5276,5377,103444,128,5377,262280,4096,4096,105494,4116,295075,257,327808,4096,136]

theorem envBound10175 : H12AffineFastState.Bounded env10175 := by
  intro p hp
  have h : env10175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10174_10175 : H12AffineEnvironment.transform 31 295075 env10174 = env10175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 295075 env10174 == env10175) = true)

def env10176 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,16777216,129,16875797,21331969,16876565,4096,20978846,16876544,4294967296,257,4299265590,4096,137]

theorem envBound10176 : H12AffineFastState.Bounded env10176 := by
  intro p hp
  have h : env10176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10141_10176 : H12AffineEnvironment.transform 13 4097 env10141 = env10176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10141 == env10176) = true)

theorem identity10176 : scanCanonicalize (H12AffineFastState.compose env10176 (packedSelected [3,5,8,17,21,28] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound10176 : packedSelected [3,5,8,17,21,28] rootPS < 2^1333 := by decide +kernel

def env10177 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,138,129,98719,4554891,99487,4096,4201492,99466,4294967296,257,4299265590,4096,137]

theorem envBound10177 : H12AffineFastState.Bounded env10177 := by
  intro p hp
  have h : env10177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10176_10177 : H12AffineEnvironment.transform 23 138 env10176 = env10177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env10176 == env10177) = true)

theorem identity10177 : scanCanonicalize (H12AffineFastState.compose env10177 (packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10177 : packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS < 2^1333 := by decide +kernel

def env10178 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,138,129,98719,4554891,99487,4096,4201492,99466,4294967296,257,4299265214,4096,137]

theorem envBound10178 : H12AffineFastState.Bounded env10178 := by
  intro p hp
  have h : env10178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10177_10178 : H12AffineEnvironment.transform 8 136 env10177 = env10178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10177 == env10178) = true)

theorem identity10178 : scanCanonicalize (H12AffineFastState.compose env10178 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound10178 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env10179 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4097,32768,38046,4096,262144,1025,32768,4096,4194304,5376,138,129,5377,4461589,4097,4096,4201492,4116,4294967296,257,4299161632,4096,137]

theorem envBound10179 : H12AffineFastState.Bounded env10179 := by
  intro p hp
  have h : env10179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10178_10179 : H12AffineEnvironment.transform 15 38046 env10178 = env10179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env10178 == env10179) = true)

theorem identity10179 : scanCanonicalize (H12AffineFastState.compose env10179 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10179 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10180 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1297,32768,33166,1296,262144,1025,32768,1296,4194304,16,138,129,17,4456709,1297,1296,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound10180 : H12AffineFastState.Bounded env10180 := by
  intro p hp
  have h : env10180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10179_10180 : H12AffineEnvironment.transform 11 1296 env10179 = env10180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10179 == env10180) = true)

theorem identity10180 : scanCanonicalize (H12AffineFastState.compose env10180 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 295308) := by decide +kernel

theorem selectedBound10180 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10181 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1297,32768,33166,1296,262144,1025,32768,1296,295308,16,138,129,17,32905,1297,1296,297096,1284,4294967296,257,4295262636,1296,137]

theorem envBound10181 : H12AffineFastState.Bounded env10181 := by
  intro p hp
  have h : env10181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10180_10181 : H12AffineEnvironment.transform 21 295308 env10180 = env10181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295308 env10180 == env10181) = true)

theorem identity10181 : scanCanonicalize (H12AffineFastState.compose env10181 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2216) := by decide +kernel

theorem selectedBound10181 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10182 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1297,2216,2342,1296,262144,1025,2216,1296,264484,16,138,129,17,2081,1297,1296,262176,1284,4294967296,257,4295231748,1296,137]

theorem envBound10182 : H12AffineFastState.Bounded env10182 := by
  intro p hp
  have h : env10182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10181_10182 : H12AffineEnvironment.transform 14 2216 env10181 = env10182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2216 env10181 == env10182) = true)

theorem identity10182 : scanCanonicalize (H12AffineFastState.compose env10182 (packedSelected [8] rootPS)) = affineNative (2^(17+1) ^^^ 137) := by decide +kernel

theorem selectedBound10182 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10183 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1297,2216,2342,1296,137,1025,2216,1296,2477,16,138,129,17,2081,1297,1296,169,1284,4294967296,257,4294969741,1296,137]

theorem envBound10183 : H12AffineFastState.Bounded env10183 := by
  intro p hp
  have h : env10183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10182_10183 : H12AffineEnvironment.transform 17 137 env10182 = env10183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env10182 == env10183) = true)

theorem identity10183 : scanCanonicalize (H12AffineFastState.compose env10183 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound10183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10184 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1297,2216,2342,1296,137,1025,2216,1296,2477,16,138,129,17,2081,1297,1296,169,1284,137,257,2308,1296,137]

theorem envBound10184 : H12AffineFastState.Bounded env10184 := by
  intro p hp
  have h : env10184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10183_10184 : H12AffineEnvironment.transform 31 137 env10183 = env10184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env10183 == env10184) = true)

theorem identity10184 : scanCanonicalize (H12AffineFastState.compose env10184 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound10184 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env10185 : List Nat := [2,4,8,16,32,16,128,256,136,1024,58,1296,8,1297,146,284,1296,137,1025,146,1296,407,16,138,129,17,27,1297,1296,169,1284,137,257,318,1296,137]

theorem envBound10185 : H12AffineFastState.Bounded env10185 := by
  intro p hp
  have h : env10185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10184_10185 : H12AffineEnvironment.transform 10 58 env10184 = env10185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env10184 == env10185) = true)

theorem identity10185 : scanCanonicalize (H12AffineFastState.compose env10185 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10185 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10186 : List Nat := [2,4,8,11,32,11,128,256,136,1024,33,1291,8,1290,137,263,1291,137,1025,137,1291,396,11,138,129,10,0,1290,1291,169,1284,137,257,293,1291,137]

theorem envBound10186 : H12AffineFastState.Bounded env10186 := by
  intro p hp
  have h : env10186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10185_10186 : H12AffineEnvironment.transform 3 11 env10185 = env10186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10185 == env10186) = true)

theorem identity10186 : scanCanonicalize (H12AffineFastState.compose env10186 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10186 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10187 : List Nat := [2,4,8,11,10,11,128,256,136,1024,11,1291,8,1290,137,263,1291,137,1025,137,1291,396,11,138,129,10,0,1290,1291,131,1284,137,257,271,1291,137]

theorem envBound10187 : H12AffineFastState.Bounded env10187 := by
  intro p hp
  have h : env10187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10186_10187 : H12AffineEnvironment.transform 4 10 env10186 = env10187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10186 == env10187) = true)

theorem identity10187 : scanCanonicalize (H12AffineFastState.compose env10187 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound10187 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10188 : List Nat := [2,4,8,11,10,11,3,256,11,1024,11,1291,8,1290,10,263,1291,10,1025,10,1291,271,11,9,2,10,0,1290,1291,0,1284,10,257,271,1291,10]

theorem envBound10188 : H12AffineFastState.Bounded env10188 := by
  intro p hp
  have h : env10188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10187_10188 : H12AffineEnvironment.transform 6 3 env10187 = env10188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env10187 == env10188) = true)

theorem identity10188 : scanCanonicalize (H12AffineFastState.compose env10188 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10188 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10189 : List Nat := [2,4,3,0,1,0,3,256,0,1024,0,1280,3,1281,1,263,1280,1,1025,1,1280,260,0,2,2,1,0,1281,1280,0,1284,1,257,260,1280,1]

theorem envBound10189 : H12AffineFastState.Bounded env10189 := by
  intro p hp
  have h : env10189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10188_10189 : H12AffineEnvironment.transform 2 3 env10188 = env10189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10188 == env10189) = true)

theorem identity10189 : scanCanonicalize (H12AffineFastState.compose env10189 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10189 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10190 : List Nat := [2,4,3,0,1,0,3,4,0,1024,0,1028,3,1029,1,3,1028,1,1025,1,1028,0,0,2,2,1,0,1029,1028,0,1024,1,5,0,1028,1]

theorem envBound10190 : H12AffineFastState.Bounded env10190 := by
  intro p hp
  have h : env10190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10189_10190 : H12AffineEnvironment.transform 7 4 env10189 = env10190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10189 == env10190) = true)

def leafEnv10190 : List Nat := [2,4,3,0,1,0,3,4,0,1024,0,1028,3,1029,1,3,1028,1,1025,1,1028,0,0,2,1025,2,1,1,0,1029,1028,0,1024,1,5,0,5,2,1028,1,0,1028,1]

def active10190 : List Nat := [0,1,9]

def tree10190 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10190 : H12WitnessSearch.Good tree10190 := H12GlobalWitnessIndex.good

theorem leafIdentity10190 : H12AffineFastState.composeSystem env10190 rootObs = leafEnv10190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10190 rootObs == leafEnv10190) = true)

theorem terminalChecked10190 : H12PackedTerminal.terminalCheckFast leafEnv10190 active10190 tree10190 = true := by decide +kernel

def env10191 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352448,16897045,4097,20978847,16876544,4294967296,257,4332832439,4097,33554440]

theorem envBound10191 : H12AffineFastState.Bounded env10191 := by
  intro p hp
  have h : env10191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10139_10191 : H12AffineEnvironment.transform 16 4097 env10139 = env10191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10139 == env10191) = true)

theorem identity10191 : scanCanonicalize (H12AffineFastState.compose env10191 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 17809) := by decide +kernel

theorem selectedBound10191 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10192 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17809,16875796,21352448,16897045,4097,20978847,16876544,4294967296,257,4299260710,4097,17817]

theorem envBound10192 : H12AffineFastState.Bounded env10192 := by
  intro p hp
  have h : env10192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10191_10192 : H12AffineEnvironment.transform 24 17809 env10191 = env10192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17809 env10191 == env10192) = true)

def env10193 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17809,16875796,21352448,16897045,4097,20978847,16876544,4294967296,257,4299260334,4097,17817]

theorem envBound10193 : H12AffineFastState.Bounded env10193 := by
  intro p hp
  have h : env10193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10192_10193 : H12AffineEnvironment.transform 8 136 env10192 = env10193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10192 == env10193) = true)

theorem identity10193 : scanCanonicalize (H12AffineFastState.compose env10193 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 119045) := by decide +kernel

theorem selectedBound10193 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10194 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,119045,17809,20497,4456709,1296,4097,4312474,21765,4294967296,257,4299260334,4097,17817]

theorem envBound10194 : H12AffineFastState.Bounded env10194 := by
  intro p hp
  have h : env10194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10193_10194 : H12AffineEnvironment.transform 23 119045 env10193 = env10194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119045 env10193 == env10194) = true)

theorem identity10194 : scanCanonicalize (H12AffineFastState.compose env10194 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10194 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env10195 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,103445,129,5377,4456709,1296,4097,4294794,4117,4294967296,257,4299260334,4097,137]

theorem envBound10195 : H12AffineFastState.Bounded env10195 := by
  intro p hp
  have h : env10195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10194_10195 : H12AffineEnvironment.transform 13 1296 env10194 = env10195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env10194 == env10195) = true)

theorem identity10195 : scanCanonicalize (H12AffineFastState.compose env10195 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound10195 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10196 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,65536,4097,262144,1025,260,4096,4194304,17,70929,129,5377,4456709,1296,4097,4262286,4117,4294967296,257,4299227306,4097,137]

theorem envBound10196 : H12AffineFastState.Bounded env10196 := by
  intro p hp
  have h : env10196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10195_10196 : H12AffineEnvironment.transform 14 260 env10195 = env10196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env10195 == env10196) = true)

theorem identity10196 : scanCanonicalize (H12AffineFastState.compose env10196 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4461882) := by decide +kernel

theorem selectedBound10196 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10197 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,65536,4097,262144,1025,260,4096,4194304,17,70929,129,5377,4456709,1296,4097,4262286,4117,4461882,257,333200,4097,137]

theorem envBound10197 : H12AffineFastState.Bounded env10197 := by
  intro p hp
  have h : env10197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10196_10197 : H12AffineEnvironment.transform 31 4461882 env10196 = env10197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4461882 env10196 == env10197) = true)

def env10198 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1296,260,65536,1297,262144,1025,260,1296,4194304,17,65537,129,17,4456709,1296,1297,4262286,1285,4456490,257,327808,1297,137]

theorem envBound10198 : H12AffineFastState.Bounded env10198 := by
  intro p hp
  have h : env10198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10197_10198 : H12AffineEnvironment.transform 11 1296 env10197 = env10198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10197 == env10198) = true)

theorem identity10198 : scanCanonicalize (H12AffineFastState.compose env10198 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 67745) := by decide +kernel

theorem selectedBound10198 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10199 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1296,260,65536,1297,67745,1025,260,1296,4194304,17,65537,129,17,4262308,1296,1297,4262286,1285,4262027,257,2081,1297,137]

theorem envBound10199 : H12AffineFastState.Bounded env10199 := by
  intro p hp
  have h : env10199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10198_10199 : H12AffineEnvironment.transform 17 67745 env10198 = env10199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67745 env10198 == env10199) = true)

theorem identity10199 : scanCanonicalize (H12AffineFastState.compose env10199 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound10199 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10200 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8,1296,260,138,1297,2091,1025,260,1296,4194304,17,139,129,17,4196654,1296,1297,4196612,1285,4196353,257,2081,1297,137]

theorem envBound10200 : H12AffineFastState.Bounded env10200 := by
  intro p hp
  have h : env10200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10199_10200 : H12AffineEnvironment.transform 15 138 env10199 = env10200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env10199 == env10200) = true)

theorem identity10200 : scanCanonicalize (H12AffineFastState.compose env10200 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10201 : List Nat := [2,4,8,16,32,16,128,36,136,1024,2048,1076,8,1076,32,138,1077,2091,1025,32,1076,4194304,17,139,129,17,4196362,1076,1077,4196384,1057,4196353,37,2081,1077,137]

theorem envBound10201 : H12AffineFastState.Bounded env10201 := by
  intro p hp
  have h : env10201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10200_10201 : H12AffineEnvironment.transform 7 36 env10200 = env10201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10200 == env10201) = true)

theorem identity10201 : scanCanonicalize (H12AffineFastState.compose env10201 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound10201 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10202 : List Nat := [2,4,8,16,32,16,128,36,136,1024,2048,1076,8,1076,32,138,1077,2091,1025,32,1076,32,17,139,129,17,2090,1076,1077,2048,1057,2081,37,2081,1077,137]

theorem envBound10202 : H12AffineFastState.Bounded env10202 := by
  intro p hp
  have h : env10202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10201_10202 : H12AffineEnvironment.transform 21 32 env10201 = env10202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env10201 == env10202) = true)

theorem identity10202 : scanCanonicalize (H12AffineFastState.compose env10202 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10203 : List Nat := [2,4,8,16,32,16,19,36,27,1024,2048,1076,8,1076,32,25,1077,2091,1025,32,1076,32,17,24,18,17,2090,1076,1077,2048,1057,2081,37,2081,1077,26]

theorem envBound10203 : H12AffineFastState.Bounded env10203 := by
  intro p hp
  have h : env10203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10202_10203 : H12AffineEnvironment.transform 6 19 env10202 = env10203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10202 == env10203) = true)

def env10204 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1296,260,65536,1296,262144,1025,260,1297,4194304,17,65536,129,16,4456709,1296,1296,4262286,1284,4456491,257,327809,1296,137]

theorem envBound10204 : H12AffineFastState.Bounded env10204 := by
  intro p hp
  have h : env10204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10197_10204 : H12AffineEnvironment.transform 11 1297 env10197 = env10204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10197 == env10204) = true)

theorem identity10204 : scanCanonicalize (H12AffineFastState.compose env10204 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 65674) := by decide +kernel

theorem selectedBound10204 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10205 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1296,260,65536,1296,262144,1025,260,1297,65674,17,65536,129,16,328079,1296,1296,2308,1284,327841,257,327809,1296,137]

theorem envBound10205 : H12AffineFastState.Bounded env10205 := by
  intro p hp
  have h : env10205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10204_10205 : H12AffineEnvironment.transform 21 65674 env10204 = env10205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65674 env10204 == env10205) = true)

theorem identity10205 : scanCanonicalize (H12AffineFastState.compose env10205 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10205 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10206 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1296,260,262,1296,262144,1025,260,1297,396,17,262,129,16,262281,1296,1296,2308,1284,262567,257,262535,1296,137]

theorem envBound10206 : H12AffineFastState.Bounded env10206 := by
  intro p hp
  have h : env10206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10205_10206 : H12AffineEnvironment.transform 15 262 env10205 = env10206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10205 == env10206) = true)

theorem identity10206 : scanCanonicalize (H12AffineFastState.compose env10206 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound10206 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10207 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1296,260,262,1296,2217,1025,260,1297,396,17,262,129,16,2080,1296,1296,2308,1284,2318,257,2350,1296,137]

theorem envBound10207 : H12AffineFastState.Bounded env10207 := by
  intro p hp
  have h : env10207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10206_10207 : H12AffineEnvironment.transform 17 2217 env10206 = env10207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env10206 == env10207) = true)

theorem identity10207 : scanCanonicalize (H12AffineFastState.compose env10207 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10207 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10208 : List Nat := [2,4,8,16,32,16,34,256,42,1024,2048,1297,8,1296,260,262,1296,2059,1025,260,1297,302,17,262,35,16,2080,1296,1296,2308,1284,2318,257,2350,1296,43]

theorem envBound10208 : H12AffineFastState.Bounded env10208 := by
  intro p hp
  have h : env10208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10207_10208 : H12AffineEnvironment.transform 6 34 env10207 = env10208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10207 == env10208) = true)

theorem identity10208 : scanCanonicalize (H12AffineFastState.compose env10208 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound10208 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10209 : List Nat := [2,4,8,16,32,16,34,256,42,1024,303,1297,8,1296,260,262,1296,292,1025,260,1297,302,17,262,35,16,271,1296,1296,43,1284,33,257,1,1296,43]

theorem envBound10209 : H12AffineFastState.Bounded env10209 := by
  intro p hp
  have h : env10209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10208_10209 : H12AffineEnvironment.transform 10 303 env10208 = env10209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env10208 == env10209) = true)

theorem identity10209 : scanCanonicalize (H12AffineFastState.compose env10209 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10210 : List Nat := [2,4,8,16,32,16,34,4,42,1024,43,1045,8,1044,0,2,1044,32,1025,0,1045,42,17,2,35,16,11,1044,1044,43,1024,33,5,1,1044,43]

theorem envBound10210 : H12AffineFastState.Bounded env10210 := by
  intro p hp
  have h : env10210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10209_10210 : H12AffineEnvironment.transform 7 4 env10209 = env10210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10209 == env10210) = true)

theorem identity10210 : scanCanonicalize (H12AffineFastState.compose env10210 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10210 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10211 : List Nat := [2,4,3,16,32,16,34,4,33,1024,32,1045,3,1044,0,2,1044,32,1025,0,1045,33,17,2,35,16,0,1044,1044,32,1024,33,5,1,1044,32]

theorem envBound10211 : H12AffineFastState.Bounded env10211 := by
  intro p hp
  have h : env10211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10210_10211 : H12AffineEnvironment.transform 2 3 env10210 = env10211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10210 == env10211) = true)

theorem identity10211 : scanCanonicalize (H12AffineFastState.compose env10211 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10212 : List Nat := [2,4,3,16,17,16,19,4,16,1024,17,1045,3,1044,0,2,1044,17,1025,0,1045,16,17,2,18,16,0,1044,1044,17,1024,16,5,1,1044,17]

theorem envBound10212 : H12AffineFastState.Bounded env10212 := by
  intro p hp
  have h : env10212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10211_10212 : H12AffineEnvironment.transform 4 17 env10211 = env10212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10211 == env10212) = true)

theorem identity10212 : scanCanonicalize (H12AffineFastState.compose env10212 (packedSelected [1,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10212 : packedSelected [1,15] rootPS < 2^1333 := by decide +kernel

def env10213 : List Nat := [2,4,3,0,1,0,3,4,0,1024,1,1029,3,1028,0,2,1028,1,1025,0,1029,0,1,2,2,0,0,1028,1028,1,1024,0,5,1,1028,1]

theorem envBound10213 : H12AffineFastState.Bounded env10213 := by
  intro p hp
  have h : env10213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10212_10213 : H12AffineEnvironment.transform 3 0 env10212 = env10213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10212 == env10213) = true)

def leafEnv10213 : List Nat := [2,4,3,0,1,0,3,4,0,1024,1,1029,3,1028,0,2,1028,1,1025,0,1029,0,1,2,1025,2,1,0,0,1028,1028,1,1024,0,5,1,5,3,1028,1,0,1028,1]

def active10213 : List Nat := [0,1,9]

def tree10213 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10213 : H12WitnessSearch.Good tree10213 := H12GlobalWitnessIndex.good

theorem leafIdentity10213 : H12AffineFastState.composeSystem env10213 rootObs = leafEnv10213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10213 rootObs == leafEnv10213) = true)

theorem terminalChecked10213 : H12PackedTerminal.terminalCheckFast leafEnv10213 active10213 tree10213 = true := by decide +kernel

def env10214 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17809,16875796,21352448,16897045,4097,20978847,16876544,4294967296,257,4299260335,4097,17817]

theorem envBound10214 : H12AffineFastState.Bounded env10214 := by
  intro p hp
  have h : env10214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10192_10214 : H12AffineEnvironment.transform 8 137 env10192 = env10214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10192 == env10214) = true)

theorem identity10214 : scanCanonicalize (H12AffineFastState.compose env10214 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound10214 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10215 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,65536,4097,262144,1025,32768,4096,4194304,5377,16777216,5521,16875796,21331968,16876565,4097,20978847,16876544,4294967296,257,4299260335,4097,5529]

theorem envBound10215 : H12AffineFastState.Bounded env10215 := by
  intro p hp
  have h : env10215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10214_10215 : H12AffineEnvironment.transform 13 4096 env10214 = env10215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env10214 == env10215) = true)

theorem identity10215 : scanCanonicalize (H12AffineFastState.compose env10215 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(23+1) ^^^ 103445) := by decide +kernel

theorem selectedBound10215 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10216 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,65536,4097,262144,1025,32768,4096,4194304,5377,103445,5521,5377,4461589,4096,4097,4294794,4117,4294967296,257,4299260335,4097,5529]

theorem envBound10216 : H12AffineFastState.Bounded env10216 := by
  intro p hp
  have h : env10216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10215_10216 : H12AffineEnvironment.transform 23 103445 env10215 = env10216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103445 env10215 == env10216) = true)

theorem identity10216 : scanCanonicalize (H12AffineFastState.compose env10216 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound10216 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10217 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4096,32768,33167,4097,262144,1025,32768,4096,4194304,5377,5530,5521,5377,4461589,4096,4097,4196613,4117,4294967296,257,4299161632,4097,5529]

theorem envBound10217 : H12AffineFastState.Bounded env10217 := by
  intro p hp
  have h : env10217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10216_10217 : H12AffineEnvironment.transform 15 33167 env10216 = env10217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env10216 == env10217) = true)

theorem identity10217 : scanCanonicalize (H12AffineFastState.compose env10217 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10217 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10218 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1297,32768,33167,1296,262144,1025,32768,1297,4194304,16,139,128,16,4456708,1297,1296,4196613,1284,4294967296,257,4299161632,1296,136]

theorem envBound10218 : H12AffineFastState.Bounded env10218 := by
  intro p hp
  have h : env10218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10217_10218 : H12AffineEnvironment.transform 11 1297 env10217 = env10218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10217 == env10218) = true)

theorem identity10218 : scanCanonicalize (H12AffineFastState.compose env10218 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound10218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10219 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1297,32768,33167,1296,262144,1025,32768,1297,260,16,139,128,16,262144,1297,1296,2049,1284,4294967296,257,4294967588,1296,136]

theorem envBound10219 : H12AffineFastState.Bounded env10219 := by
  intro p hp
  have h : env10219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10218_10219 : H12AffineEnvironment.transform 21 260 env10218 = env10219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env10218 == env10219) = true)

theorem identity10219 : scanCanonicalize (H12AffineFastState.compose env10219 (packedSelected [5] rootPS)) = affineNative (2^(17+1) ^^^ 34848) := by decide +kernel

theorem selectedBound10219 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10220 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1297,32768,33167,1296,34848,1025,32768,1297,260,16,139,128,16,34848,1297,1296,2049,1284,4294967296,257,4294967588,1296,136]

theorem envBound10220 : H12AffineFastState.Bounded env10220 := by
  intro p hp
  have h : env10220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10219_10220 : H12AffineEnvironment.transform 17 34848 env10219 = env10220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34848 env10219 == env10220) = true)

theorem identity10220 : scanCanonicalize (H12AffineFastState.compose env10220 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 3360) := by decide +kernel

theorem selectedBound10220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10221 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1297,32768,33167,1296,34848,1025,32768,1297,260,16,139,128,16,34848,1297,1296,2049,1284,3360,257,3076,1296,136]

theorem envBound10221 : H12AffineFastState.Bounded env10221 := by
  intro p hp
  have h : env10221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10220_10221 : H12AffineEnvironment.transform 31 3360 env10220 = env10221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3360 env10220 == env10221) = true)

theorem identity10221 : scanCanonicalize (H12AffineFastState.compose env10221 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound10221 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env10222 : List Nat := [2,4,8,16,32,16,128,256,137,1024,260,1297,9,1297,32768,33167,1296,33060,1025,32768,1297,260,16,139,128,16,33060,1297,1296,261,1284,1060,257,1280,1296,136]

theorem envBound10222 : H12AffineFastState.Bounded env10222 := by
  intro p hp
  have h : env10222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10221_10222 : H12AffineEnvironment.transform 10 260 env10221 = env10222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env10221 == env10222) = true)

theorem identity10222 : scanCanonicalize (H12AffineFastState.compose env10222 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound10222 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10223 : List Nat := [2,4,8,16,32,16,128,256,137,1024,260,1297,9,1297,292,171,1296,0,1025,292,1297,260,16,139,128,16,0,1297,1296,261,1284,1060,257,1280,1296,136]

theorem envBound10223 : H12AffineFastState.Bounded env10223 := by
  intro p hp
  have h : env10223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10222_10223 : H12AffineEnvironment.transform 14 292 env10222 = env10223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env10222 == env10223) = true)

def env10224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352448,17024020,131072,21105822,16876544,4294967296,257,4332967607,131072,33554441]

theorem envBound10224 : H12AffineFastState.Bounded env10224 := by
  intro p hp
  have h : env10224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10138_10224 : H12AffineEnvironment.transform 12 641 env10138 = env10224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env10138 == env10224) = true)

def env10225 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352448,16897044,4096,20978846,16876544,4294967296,257,4332832439,4096,33554441]

theorem envBound10225 : H12AffineFastState.Bounded env10225 := by
  intro p hp
  have h : env10225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10224_10225 : H12AffineEnvironment.transform 16 4096 env10224 = env10225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10224 == env10225) = true)

theorem identity10225 : scanCanonicalize (H12AffineFastState.compose env10225 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 4745) := by decide +kernel

theorem selectedBound10225 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10226 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4745,32768,65536,4096,262144,1025,32768,4096,4194304,6024,16777216,33554432,16875797,21332617,16877213,4096,20978846,16876544,4294967296,257,4332819518,4096,33554441]

theorem envBound10226 : H12AffineFastState.Bounded env10226 := by
  intro p hp
  have h : env10226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10225_10226 : H12AffineEnvironment.transform 13 4745 env10225 = env10226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4745 env10225 == env10226) = true)

def env10227 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,16777216,33554432,16875797,21331969,16876565,4096,20978846,16876544,4294967296,257,4332819518,4096,33554441]

theorem envBound10227 : H12AffineFastState.Bounded env10227 := by
  intro p hp
  have h : env10227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10226_10227 : H12AffineEnvironment.transform 8 136 env10226 = env10227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10226 == env10227) = true)

theorem identity10227 : scanCanonicalize (H12AffineFastState.compose env10227 (packedSelected [3,5,8,17,21,28] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound10227 : packedSelected [3,5,8,17,21,28] rootPS < 2^1333 := by decide +kernel

def env10228 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,138,33554432,98719,4554891,99487,4096,4201492,99466,4294967296,257,4332819518,4096,33554441]

theorem envBound10228 : H12AffineFastState.Bounded env10228 := by
  intro p hp
  have h : env10228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10227_10228 : H12AffineEnvironment.transform 23 138 env10227 = env10228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env10227 == env10228) = true)

theorem identity10228 : scanCanonicalize (H12AffineFastState.compose env10228 (packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS)) = affineNative (2^(24+1) ^^^ 128) := by decide +kernel

theorem selectedBound10228 : packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS < 2^1333 := by decide +kernel

def env10229 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,138,128,98719,4554891,99487,4096,4201492,99466,4294967296,257,4299265214,4096,137]

theorem envBound10229 : H12AffineFastState.Bounded env10229 := by
  intro p hp
  have h : env10229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10228_10229 : H12AffineEnvironment.transform 24 128 env10228 = env10229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env10228 == env10229) = true)

theorem identity10229 : scanCanonicalize (H12AffineFastState.compose env10229 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound10229 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env10230 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4097,32768,38046,4096,262144,1025,32768,4096,4194304,5376,138,128,5377,4461589,4097,4096,4201492,4116,4294967296,257,4299161632,4096,137]

theorem envBound10230 : H12AffineFastState.Bounded env10230 := by
  intro p hp
  have h : env10230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10229_10230 : H12AffineEnvironment.transform 15 38046 env10229 = env10230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env10229 == env10230) = true)

theorem identity10230 : scanCanonicalize (H12AffineFastState.compose env10230 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10230 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10231 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1297,32768,33166,1296,262144,1025,32768,1296,4194304,16,138,128,17,4456709,1297,1296,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound10231 : H12AffineFastState.Bounded env10231 := by
  intro p hp
  have h : env10231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10230_10231 : H12AffineEnvironment.transform 11 1296 env10230 = env10231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10230 == env10231) = true)

theorem identity10231 : scanCanonicalize (H12AffineFastState.compose env10231 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 295308) := by decide +kernel

theorem selectedBound10231 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10232 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1297,32768,33166,1296,262144,1025,32768,1296,295308,16,138,128,17,32905,1297,1296,297096,1284,4294967296,257,4295262636,1296,137]

theorem envBound10232 : H12AffineFastState.Bounded env10232 := by
  intro p hp
  have h : env10232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10231_10232 : H12AffineEnvironment.transform 21 295308 env10231 = env10232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295308 env10231 == env10232) = true)

theorem identity10232 : scanCanonicalize (H12AffineFastState.compose env10232 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2216) := by decide +kernel

theorem selectedBound10232 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10233 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1297,2216,2342,1296,262144,1025,2216,1296,264484,16,138,128,17,2081,1297,1296,262176,1284,4294967296,257,4295231748,1296,137]

theorem envBound10233 : H12AffineFastState.Bounded env10233 := by
  intro p hp
  have h : env10233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10232_10233 : H12AffineEnvironment.transform 14 2216 env10232 = env10233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2216 env10232 == env10233) = true)

theorem identity10233 : scanCanonicalize (H12AffineFastState.compose env10233 (packedSelected [8] rootPS)) = affineNative (2^(17+1) ^^^ 136) := by decide +kernel

theorem selectedBound10233 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10234 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1297,2216,2342,1296,136,1025,2216,1296,2476,16,138,128,17,2081,1297,1296,168,1284,4294967296,257,4294969740,1296,137]

theorem envBound10234 : H12AffineFastState.Bounded env10234 := by
  intro p hp
  have h : env10234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10233_10234 : H12AffineEnvironment.transform 17 136 env10233 = env10234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 136 env10233 == env10234) = true)

theorem identity10234 : scanCanonicalize (H12AffineFastState.compose env10234 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound10234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10235 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1297,2216,2342,1296,136,1025,2216,1296,2476,16,138,128,17,2081,1297,1296,168,1284,136,257,2308,1296,137]

theorem envBound10235 : H12AffineFastState.Bounded env10235 := by
  intro p hp
  have h : env10235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10234_10235 : H12AffineEnvironment.transform 31 136 env10234 = env10235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env10234 == env10235) = true)

theorem identity10235 : scanCanonicalize (H12AffineFastState.compose env10235 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound10235 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2