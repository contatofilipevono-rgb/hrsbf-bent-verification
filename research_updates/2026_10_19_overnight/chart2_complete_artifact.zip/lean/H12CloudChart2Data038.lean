import H12CloudChart2Data037

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound9265 : H12AffineFastState.Bounded env9265 := by
  intro p hp
  have h : env9265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9264_9265 : H12AffineEnvironment.transform 26 23577872 env9264 = env9265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23577872 env9264 == env9265) = true)

def env9266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,23445584,67130625,1297,1073741824,16876544,4294967296,257,4417151347,1344,33563272]

theorem envBound9266 : H12AffineFastState.Bounded env9266 := by
  intro p hp
  have h : env9266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9265_9266 : H12AffineEnvironment.transform 16 1344 env9265 = env9266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9265 == env9266) = true)

def env9267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,16777216,33554432,67108864,21352528,67130625,1297,1073741824,16876544,4294967296,257,4417151347,1344,33563272]

theorem envBound9267 : H12AffineFastState.Bounded env9267 := by
  intro p hp
  have h : env9267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9266_9267 : H12AffineEnvironment.transform 20 4096 env9266 = env9267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9266 == env9267) = true)

theorem identity9267 : scanCanonicalize (H12AffineFastState.compose env9267 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9267 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,33554432,67108864,4477269,67130625,1297,1073741824,1285,4294967296,257,4400472182,1344,33563272]

theorem envBound9268 : H12AffineFastState.Bounded env9268 := by
  intro p hp
  have h : env9268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9267_9268 : H12AffineEnvironment.transform 23 98565 env9267 = env9268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9267 == env9268) = true)

def env9269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,33554432,5376,4477269,16385,1297,1073741824,1285,4294967296,257,4333368694,1344,33563272]

theorem envBound9269 : H12AffineFastState.Bounded env9269 := by
  intro p hp
  have h : env9269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9268_9269 : H12AffineEnvironment.transform 25 5376 env9268 = env9269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9268 == env9269) = true)

theorem identity9269 : scanCanonicalize (H12AffineFastState.compose env9269 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 554201) := by decide +kernel

theorem selectedBound9269 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,554201,5376,4477269,16385,1297,1073741824,1285,4294967296,257,4299260335,1344,546385]

theorem envBound9270 : H12AffineFastState.Bounded env9270 := by
  intro p hp
  have h : env9270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9269_9270 : H12AffineEnvironment.transform 24 554201 env9269 = env9270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 554201 env9269 == env9270) = true)

theorem identity9270 : scanCanonicalize (H12AffineFastState.compose env9270 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 5043580) := by decide +kernel

theorem selectedBound9270 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,554201,5376,4477269,16385,1297,5043580,1285,4294967296,257,4299260335,1344,546385]

theorem envBound9271 : H12AffineFastState.Bounded env9271 := by
  intro p hp
  have h : env9271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9270_9271 : H12AffineEnvironment.transform 29 5043580 env9270 = env9271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5043580 env9270 == env9271) = true)

theorem identity9271 : scanCanonicalize (H12AffineFastState.compose env9271 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(17+1) ^^^ 63608) := by decide +kernel

theorem selectedBound9271 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env9272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,63608,524288,32768,4096,4194304,17664,98565,554201,5376,4237613,16385,1297,4721924,1285,4294967296,257,4299260335,1344,546385]

theorem envBound9272 : H12AffineFastState.Bounded env9272 := by
  intro p hp
  have h : env9272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9271_9272 : H12AffineEnvironment.transform 17 63608 env9271 = env9272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63608 env9271 == env9272) = true)

theorem identity9272 : scanCanonicalize (H12AffineFastState.compose env9272 (packedSelected [0,4,7,10,12,13,15,17,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 53727) := by decide +kernel

theorem selectedBound9272 : packedSelected [0,4,7,10,12,13,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env9273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53727,1344,63608,524288,32768,4096,4194304,17664,20698,554201,5376,4237613,16385,1297,4721924,1285,4294967296,257,4299182192,1344,546385]

theorem envBound9273 : H12AffineFastState.Bounded env9273 := by
  intro p hp
  have h : env9273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9272_9273 : H12AffineEnvironment.transform 15 53727 env9272 = env9273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53727 env9272 == env9273) = true)

theorem identity9273 : scanCanonicalize (H12AffineFastState.compose env9273 (packedSelected [11,16,18] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound9273 : packedSelected [11,16,18] rootPS < 2^1333 := by decide +kernel

def env9274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53727,1344,63608,21585,32768,4096,4194304,17664,20698,8328,5376,4237613,16385,1297,4217173,1285,4294967296,257,4299182192,1344,512]

theorem envBound9274 : H12AffineFastState.Bounded env9274 := by
  intro p hp
  have h : env9274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9273_9274 : H12AffineEnvironment.transform 18 21585 env9273 = env9274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env9273 == env9274) = true)

theorem identity9274 : scanCanonicalize (H12AffineFastState.compose env9274 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 20740) := by decide +kernel

theorem selectedBound9274 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20740,219,1344,10620,21585,20740,4096,4194304,17664,20698,8328,5376,4225065,16385,1297,4217173,1285,4294967296,257,4299182192,1344,512]

theorem envBound9275 : H12AffineFastState.Bounded env9275 := by
  intro p hp
  have h : env9275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9274_9275 : H12AffineEnvironment.transform 14 20740 env9274 = env9275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20740 env9274 == env9275) = true)

theorem identity9275 : scanCanonicalize (H12AffineFastState.compose env9275 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(21+1) ^^^ 20282) := by decide +kernel

theorem selectedBound9275 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env9276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20740,219,1344,10620,21585,20740,4096,20282,17664,20698,8328,5376,14099,16385,1297,5743,1285,4294967296,257,4294975306,1344,512]

theorem envBound9276 : H12AffineFastState.Bounded env9276 := by
  intro p hp
  have h : env9276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9275_9276 : H12AffineEnvironment.transform 21 20282 env9275 = env9276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20282 env9275 == env9276) = true)

theorem identity9276 : scanCanonicalize (H12AffineFastState.compose env9276 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 9545) := by decide +kernel

theorem selectedBound9276 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env9277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9545,13389,219,1344,10620,12568,13389,4096,10867,8265,13715,8328,5376,14099,9544,1297,5743,1285,4294967296,257,4294975306,1344,512]

theorem envBound9277 : H12AffineFastState.Bounded env9277 := by
  intro p hp
  have h : env9277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9276_9277 : H12AffineEnvironment.transform 13 9545 env9276 = env9277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9545 env9276 == env9277) = true)

theorem identity9277 : scanCanonicalize (H12AffineFastState.compose env9277 (packedSelected [3,8,10] rootPS)) = affineNative (2^(31+1) ^^^ 6991) := by decide +kernel

theorem selectedBound9277 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env9278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9545,13389,219,1344,10620,12568,13389,4096,10867,8265,13715,8328,5376,14099,9544,1297,5743,1285,6991,257,1029,1344,512]

theorem envBound9278 : H12AffineFastState.Bounded env9278 := by
  intro p hp
  have h : env9278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9277_9278 : H12AffineEnvironment.transform 31 6991 env9277 = env9278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 6991 env9277 == env9278) = true)

theorem identity9278 : scanCanonicalize (H12AffineFastState.compose env9278 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 3070) := by decide +kernel

theorem selectedBound9278 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env9279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3070,3767,8115,219,1344,642,6886,8115,4096,397,2999,7789,2934,5376,7405,3766,1297,5743,1285,6991,257,1029,1344,512]

theorem envBound9279 : H12AffineFastState.Bounded env9279 := by
  intro p hp
  have h : env9279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9278_9279 : H12AffineEnvironment.transform 12 3070 env9278 = env9279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3070 env9278 == env9279) = true)

theorem identity9279 : scanCanonicalize (H12AffineFastState.compose env9279 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 3815) := by decide +kernel

theorem selectedBound9279 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env9280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3815,3070,3767,340,219,1344,642,1025,340,3815,397,2999,138,2934,3047,522,3766,1297,2184,1285,1448,257,1029,1344,512]

theorem envBound9280 : H12AffineFastState.Bounded env9280 := by
  intro p hp
  have h : env9280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9279_9280 : H12AffineEnvironment.transform 11 3815 env9279 = env9280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3815 env9279 == env9280) = true)

theorem identity9280 : scanCanonicalize (H12AffineFastState.compose env9280 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1954) := by decide +kernel

theorem selectedBound9280 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1954,325,1116,277,340,219,1344,642,1025,340,325,397,1045,138,1236,1093,522,276,1297,1834,1285,1448,257,1029,1344,512]

theorem envBound9281 : H12AffineFastState.Bounded env9281 := by
  intro p hp
  have h : env9281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9280_9281 : H12AffineEnvironment.transform 10 1954 env9280 = env9281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1954 env9280 == env9281) = true)

theorem identity9281 : scanCanonicalize (H12AffineFastState.compose env9281 (packedSelected [1,5,12] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9281 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env9282 : List Nat := [2,4,8,16,32,64,128,256,512,5,935,325,89,277,340,219,325,642,4,340,325,397,16,138,209,64,522,276,276,815,256,429,257,0,325,512]

theorem envBound9282 : H12AffineFastState.Bounded env9282 := by
  intro p hp
  have h : env9282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9281_9282 : H12AffineEnvironment.transform 9 5 env9281 = env9282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9281 == env9282) = true)

theorem identity9282 : scanCanonicalize (H12AffineFastState.compose env9282 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound9282 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9283 : List Nat := [2,4,8,16,32,64,128,256,350,5,249,325,89,277,340,219,325,476,4,340,325,397,16,138,209,64,340,276,276,113,256,429,257,0,325,350]

theorem envBound9283 : H12AffineFastState.Bounded env9283 := by
  intro p hp
  have h : env9283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9282_9283 : H12AffineEnvironment.transform 8 350 env9282 = env9283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env9282 == env9283) = true)

theorem identity9283 : scanCanonicalize (H12AffineFastState.compose env9283 (packedSelected [2,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound9283 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9284 : List Nat := [1,4,8,16,32,64,128,256,349,5,249,325,89,277,340,216,325,476,4,340,325,397,16,137,209,64,340,276,276,113,256,429,257,0,325,349]

theorem envBound9284 : H12AffineFastState.Bounded env9284 := by
  intro p hp
  have h : env9284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9283_9284 : H12AffineEnvironment.transform 0 1 env9283 = env9284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env9283 == env9284) = true)

def env9285 : List Nat := [1,4,8,16,32,64,8,256,349,5,113,325,89,277,340,80,325,340,4,340,325,261,16,1,89,64,340,276,276,113,256,293,257,0,325,349]

theorem envBound9285 : H12AffineFastState.Bounded env9285 := by
  intro p hp
  have h : env9285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9284_9285 : H12AffineEnvironment.transform 6 8 env9284 = env9285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9284 == env9285) = true)

theorem identity9285 : scanCanonicalize (H12AffineFastState.compose env9285 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9285 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9286 : List Nat := [1,4,8,16,32,16,8,256,269,5,33,277,9,277,260,0,277,260,4,260,277,261,16,1,9,16,260,276,276,33,256,293,257,0,277,269]

theorem envBound9286 : H12AffineFastState.Bounded env9286 := by
  intro p hp
  have h : env9286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9285_9286 : H12AffineEnvironment.transform 5 16 env9285 = env9286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9285 == env9286) = true)

theorem identity9286 : scanCanonicalize (H12AffineFastState.compose env9286 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9287 : List Nat := [1,4,8,16,32,16,8,37,40,5,33,48,9,48,33,0,48,33,4,33,48,32,16,1,9,16,33,49,49,33,37,0,36,0,48,40]

theorem envBound9287 : H12AffineFastState.Bounded env9287 := by
  intro p hp
  have h : env9287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9286_9287 : H12AffineEnvironment.transform 7 37 env9286 = env9287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9286 == env9287) = true)

theorem identity9287 : scanCanonicalize (H12AffineFastState.compose env9287 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound9287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9288 : List Nat := [1,4,0,16,32,16,0,37,32,5,33,48,1,48,33,0,48,33,4,33,48,32,16,1,1,16,33,49,49,33,37,0,36,0,48,32]

theorem envBound9288 : H12AffineFastState.Bounded env9288 := by
  intro p hp
  have h : env9288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9287_9288 : H12AffineEnvironment.transform 2 0 env9287 = env9288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env9287 == env9288) = true)

def leafEnv9288 : List Nat := [1,4,0,16,32,16,0,37,32,5,33,48,1,48,33,0,48,33,4,33,48,32,16,1,36,1,1,16,33,49,49,33,37,0,36,0,5,0,48,32,0,48,1]

def active9288 : List Nat := [1,3,4]

def tree9288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9288 : H12WitnessSearch.Good tree9288 := H12GlobalWitnessIndex.good

theorem leafIdentity9288 : H12AffineFastState.composeSystem env9288 rootObs = leafEnv9288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9288 rootObs == leafEnv9288) = true)

theorem terminalChecked9288 : H12PackedTerminal.terminalCheckFast leafEnv9288 active9288 tree9288 = true := by decide +kernel

def env9289 : List Nat := [1,4,8,16,32,64,9,256,349,5,112,325,89,277,340,81,325,341,4,340,325,260,16,0,88,64,340,276,276,113,256,292,257,0,325,349]

theorem envBound9289 : H12AffineFastState.Bounded env9289 := by
  intro p hp
  have h : env9289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9284_9289 : H12AffineEnvironment.transform 6 9 env9284 = env9289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9284 == env9289) = true)

theorem identity9289 : scanCanonicalize (H12AffineFastState.compose env9289 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound9289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9290 : List Nat := [1,4,8,16,32,64,9,117,40,5,112,48,89,96,33,81,48,32,4,33,48,113,16,0,88,64,33,97,97,113,117,81,116,0,48,40]

theorem envBound9290 : H12AffineFastState.Bounded env9290 := by
  intro p hp
  have h : env9290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9289_9290 : H12AffineEnvironment.transform 7 117 env9289 = env9290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env9289 == env9290) = true)

def env9291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,33554432,5377,4477269,16384,1297,1073741824,1285,4294967296,257,4333368695,1344,33563272]

theorem envBound9291 : H12AffineFastState.Bounded env9291 := by
  intro p hp
  have h : env9291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9268_9291 : H12AffineEnvironment.transform 25 5377 env9268 = env9291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9268 == env9291) = true)

theorem identity9291 : scanCanonicalize (H12AffineFastState.compose env9291 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9291 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,8328,5377,4477269,16384,1297,1073741824,1285,4294967296,257,4299806207,1344,512]

theorem envBound9292 : H12AffineFastState.Bounded env9292 := by
  intro p hp
  have h : env9292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9291_9292 : H12AffineEnvironment.transform 24 8328 env9291 = env9292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9291 == env9292) = true)

theorem identity9292 : scanCanonicalize (H12AffineFastState.compose env9292 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(29+1) ^^^ 4267214) := by decide +kernel

theorem selectedBound9292 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,8328,5377,4477269,16384,1297,4267214,1285,4294967296,257,4299806207,1344,512]

theorem envBound9293 : H12AffineFastState.Bounded env9293 := by
  intro p hp
  have h : env9293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9292_9293 : H12AffineEnvironment.transform 29 4267214 env9292 = env9293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4267214 env9292 == env9293) = true)

theorem identity9293 : scanCanonicalize (H12AffineFastState.compose env9293 (packedSelected [4,16,22] rootPS)) = affineNative (2^(21+1) ^^^ 25749) := by decide +kernel

theorem selectedBound9293 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env9294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,25749,17664,98565,8328,5377,275904,16384,1297,96347,1285,4294967296,257,4295602538,1344,512]

theorem envBound9294 : H12AffineFastState.Bounded env9294 := by
  intro p hp
  have h : env9294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9293_9294 : H12AffineEnvironment.transform 21 25749 env9293 = env9294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 25749 env9293 == env9294) = true)

theorem identity9294 : scanCanonicalize (H12AffineFastState.compose env9294 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(31+1) ^^^ 74767) := by decide +kernel

theorem selectedBound9294 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env9295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,25749,17664,98565,8328,5377,275904,16384,1297,96347,1285,74767,257,562533,1344,512]

theorem envBound9295 : H12AffineFastState.Bounded env9295 := by
  intro p hp
  have h : env9295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9294_9295 : H12AffineEnvironment.transform 31 74767 env9294 = env9295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74767 env9294 == env9295) = true)

theorem identity9295 : scanCanonicalize (H12AffineFastState.compose env9295 (packedSelected [4,6,9,16,25] rootPS)) = affineNative (2^(18+1) ^^^ 12617) := by decide +kernel

theorem selectedBound9295 : packedSelected [4,6,9,16,25] rootPS < 2^1333 := by decide +kernel

def env9296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,12617,32768,4096,25749,17664,98565,8328,5377,275904,16384,1297,96347,1285,74767,257,42028,1344,512]

theorem envBound9296 : H12AffineFastState.Bounded env9296 := by
  intro p hp
  have h : env9296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9295_9296 : H12AffineEnvironment.transform 18 12617 env9295 = env9296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 12617 env9295 == env9296) = true)

theorem identity9296 : scanCanonicalize (H12AffineFastState.compose env9296 (packedSelected [0,27] rootPS)) = affineNative (2^(14+1) ^^^ 17428) := by decide +kernel

theorem selectedBound9296 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env9297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17428,65536,1344,262144,12617,17428,4096,25749,17664,83217,8328,5377,275904,16384,1297,96347,1285,74767,257,24632,1344,512]

theorem envBound9297 : H12AffineFastState.Bounded env9297 := by
  intro p hp
  have h : env9297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9296_9297 : H12AffineEnvironment.transform 14 17428 env9296 = env9297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17428 env9296 == env9297) = true)

theorem identity9297 : scanCanonicalize (H12AffineFastState.compose env9297 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 23775) := by decide +kernel

theorem selectedBound9297 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17428,23775,1344,262144,12617,17428,4096,25749,17664,6606,8328,5377,275904,16384,1297,9348,1285,30928,257,24632,1344,512]

theorem envBound9298 : H12AffineFastState.Bounded env9298 := by
  intro p hp
  have h : env9298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9297_9298 : H12AffineEnvironment.transform 15 23775 env9297 = env9298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 23775 env9297 == env9298) = true)

theorem identity9298 : scanCanonicalize (H12AffineFastState.compose env9298 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound9298 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,5188,3215,1344,262144,12617,5188,4096,13509,5456,6606,8328,5377,275904,4176,1297,9348,1285,10368,257,12392,1344,512]

theorem envBound9299 : H12AffineFastState.Bounded env9299 := by
  intro p hp
  have h : env9299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9298_9299 : H12AffineEnvironment.transform 13 4176 env9298 = env9299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9298 == env9299) = true)

theorem identity9299 : scanCanonicalize (H12AffineFastState.compose env9299 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound9299 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,4176,5188,3215,1344,262144,4448,5188,4096,5356,5456,6606,161,5377,267753,4176,1297,1197,1285,2217,257,4161,1344,512]

theorem envBound9300 : H12AffineFastState.Bounded env9300 := by
  intro p hp
  have h : env9300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9299_9300 : H12AffineEnvironment.transform 12 41 env9299 = env9300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env9299 == env9300) = true)

def env9301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17664,16777216,33554432,67108864,21352529,67130625,1297,1073741824,16876544,4294967296,257,4417151347,1344,33563272]

theorem envBound9301 : H12AffineFastState.Bounded env9301 := by
  intro p hp
  have h : env9301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9266_9301 : H12AffineEnvironment.transform 20 4097 env9266 = env9301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9266 == env9301) = true)

theorem identity9301 : scanCanonicalize (H12AffineFastState.compose env9301 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 16880644) := by decide +kernel

theorem selectedBound9301 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,4194304,17664,16777216,33554432,16880644,21352529,16892165,1297,1073741824,16876544,4294967296,257,4333368695,1344,33563272]

theorem envBound9302 : H12AffineFastState.Bounded env9302 := by
  intro p hp
  have h : env9302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9301_9302 : H12AffineEnvironment.transform 25 16880644 env9301 = env9302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16880644 env9301 == env9302) = true)

def env9303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,16777216,33554432,16880644,21352529,16892165,1297,1073741824,16876544,4294967296,257,4332843383,1344,33563272]

theorem envBound9303 : H12AffineFastState.Bounded env9303 := by
  intro p hp
  have h : env9303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9302_9303 : H12AffineEnvironment.transform 18 1024 env9302 = env9303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9302 == env9303) = true)

theorem identity9303 : scanCanonicalize (H12AffineFastState.compose env9303 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 20994526) := by decide +kernel

theorem selectedBound9303 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,16777216,33554432,16880644,21352529,16892165,1297,20994526,16876544,4294967296,257,4332843383,1344,33563272]

theorem envBound9304 : H12AffineFastState.Bounded env9304 := by
  intro p hp
  have h : env9304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9303_9304 : H12AffineEnvironment.transform 29 20994526 env9303 = env9304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 20994526 env9303 == env9304) = true)

theorem identity9304 : scanCanonicalize (H12AffineFastState.compose env9304 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound9304 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env9305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,16777216,28889,16880644,21352529,16892165,1297,20994526,16876544,4294967296,257,4299260334,1344,21073]

theorem envBound9305 : H12AffineFastState.Bounded env9305 := by
  intro p hp
  have h : env9305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9304_9305 : H12AffineEnvironment.transform 24 28889 env9304 = env9305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env9304 == env9305) = true)

theorem identity9305 : scanCanonicalize (H12AffineFastState.compose env9305 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9305 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env9306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,98565,28889,5377,4477268,16384,1297,4315355,1285,4294967296,257,4299260334,1344,21073]

theorem envBound9306 : H12AffineFastState.Bounded env9306 := by
  intro p hp
  have h : env9306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9305_9306 : H12AffineEnvironment.transform 23 98565 env9305 = env9306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9305 == env9306) = true)

theorem identity9306 : scanCanonicalize (H12AffineFastState.compose env9306 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 63609) := by decide +kernel

theorem selectedBound9306 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env9307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,63609,1024,32768,4097,4194304,17664,98565,28889,5377,4237613,16384,1297,4315355,1285,4294967296,257,4299260334,1344,21073]

theorem envBound9307 : H12AffineFastState.Bounded env9307 := by
  intro p hp
  have h : env9307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9306_9307 : H12AffineEnvironment.transform 17 63609 env9306 = env9307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63609 env9306 == env9307) = true)

theorem identity9307 : scanCanonicalize (H12AffineFastState.compose env9307 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53726) := by decide +kernel

theorem selectedBound9307 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env9308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,53726,1344,63609,1024,32768,4097,4194304,17664,20699,28889,5377,4237613,16384,1297,4196613,1285,4294967296,257,4299182192,1344,21073]

theorem envBound9308 : H12AffineFastState.Bounded env9308 := by
  intro p hp
  have h : env9308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9307_9308 : H12AffineEnvironment.transform 15 53726 env9307 = env9308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53726 env9307 == env9308) = true)

def env9309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33166,1344,43049,1024,32768,4097,4194304,5456,139,8329,5377,4237613,4176,1297,4196613,1285,4294967296,257,4299161632,1344,513]

theorem envBound9309 : H12AffineFastState.Bounded env9309 := by
  intro p hp
  have h : env9309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9308_9309 : H12AffineEnvironment.transform 13 4176 env9308 = env9309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9308 == env9309) = true)

theorem identity9309 : scanCanonicalize (H12AffineFastState.compose env9309 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9309 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9310 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4176,32768,33166,1344,43049,1024,32768,4097,4194304,5456,139,8329,5377,4237613,4176,1297,4196613,1285,4294967296,257,4299161632,1344,137]

theorem envBound9310 : H12AffineFastState.Bounded env9310 := by
  intro p hp
  have h : env9310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9309_9310 : H12AffineEnvironment.transform 8 136 env9309 = env9310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9309 == env9310) = true)

theorem identity9310 : scanCanonicalize (H12AffineFastState.compose env9310 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound9310 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9311 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4176,2340,2218,1344,8461,1024,2340,4097,4194304,5456,139,8329,5377,4202505,4176,1297,4196613,1285,4294967296,257,4299161632,1344,137]

theorem envBound9311 : H12AffineFastState.Bounded env9311 := by
  intro p hp
  have h : env9311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9310_9311 : H12AffineEnvironment.transform 14 2340 env9310 = env9311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env9310 == env9311) = true)

theorem identity9311 : scanCanonicalize (H12AffineFastState.compose env9311 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound9311 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9312 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4176,2340,2218,1344,8461,1024,2340,4097,260,5456,139,8329,5377,8461,4176,1297,2049,1285,4294967296,257,4294967588,1344,137]

theorem envBound9312 : H12AffineFastState.Bounded env9312 := by
  intro p hp
  have h : env9312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9311_9312 : H12AffineEnvironment.transform 21 260 env9311 = env9312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env9311 == env9312) = true)

theorem identity9312 : scanCanonicalize (H12AffineFastState.compose env9312 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9313 : List Nat := [2,4,8,16,32,64,128,36,136,1024,2048,4096,8192,4176,2048,2218,1124,8233,1024,2048,4097,32,5236,139,8329,5157,8233,4176,1077,2049,1057,4294967296,37,4294967296,1124,137]

theorem envBound9313 : H12AffineFastState.Bounded env9313 := by
  intro p hp
  have h : env9313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9312_9313 : H12AffineEnvironment.transform 7 36 env9312 = env9313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9312 == env9313) = true)

theorem identity9313 : scanCanonicalize (H12AffineFastState.compose env9313 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound9313 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9314 : List Nat := [2,4,8,16,32,64,128,36,136,1024,2048,4096,7196,4176,2048,2218,1124,7221,1024,2048,4097,32,5236,139,7317,5157,7221,4176,1077,2049,1057,4294967296,37,4294967296,1124,137]

theorem envBound9314 : H12AffineFastState.Bounded env9314 := by
  intro p hp
  have h : env9314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9313_9314 : H12AffineEnvironment.transform 12 7196 env9313 = env9314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env9313 == env9314) = true)

def env9315 : List Nat := [2,4,8,16,32,64,8,36,0,1024,2048,4096,7196,4176,2048,2082,1124,7221,1024,2048,4097,32,5236,3,7197,5157,7221,4176,1077,2049,1057,4294967296,37,4294967296,1124,1]

theorem envBound9315 : H12AffineFastState.Bounded env9315 := by
  intro p hp
  have h : env9315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9314_9315 : H12AffineEnvironment.transform 6 8 env9314 = env9315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9314 == env9315) = true)

theorem identity9315 : scanCanonicalize (H12AffineFastState.compose env9315 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 5151) := by decide +kernel

theorem selectedBound9315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9316 : List Nat := [2,4,8,16,32,64,8,36,0,1024,2048,4096,7196,4176,2048,2082,1124,7221,1024,2048,4097,32,5236,3,7197,5157,7221,4176,1077,2049,1057,5151,37,5151,1124,1]

theorem envBound9316 : H12AffineFastState.Bounded env9316 := by
  intro p hp
  have h : env9316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9315_9316 : H12AffineEnvironment.transform 31 5151 env9315 = env9316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5151 env9315 == env9316) = true)

def env9317 : List Nat := [2,4,8,16,32,16,8,36,0,1024,2048,4096,7196,4096,2048,2082,1076,7221,1024,2048,4097,32,5156,3,7197,5157,7221,4096,1077,2049,1057,5151,37,5151,1076,1]

theorem envBound9317 : H12AffineFastState.Bounded env9317 := by
  intro p hp
  have h : env9317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9316_9317 : H12AffineEnvironment.transform 5 16 env9316 = env9317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9316 == env9317) = true)

theorem identity9317 : scanCanonicalize (H12AffineFastState.compose env9317 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9318 : List Nat := [2,4,8,11,32,11,8,36,0,1024,2048,4096,7175,4096,2048,2082,1071,7214,1024,2048,4097,32,5156,3,7174,5157,7214,4096,1070,2049,1057,5124,37,5124,1071,1]

theorem envBound9318 : H12AffineFastState.Bounded env9318 := by
  intro p hp
  have h : env9318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9317_9318 : H12AffineEnvironment.transform 3 11 env9317 = env9318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9317 == env9318) = true)

def leafEnv9318 : List Nat := [2,4,8,11,32,11,8,36,0,1024,2048,4096,7175,4096,2048,2082,1071,7214,1024,2048,4097,32,5156,3,1057,7174,1,5157,7214,4096,1070,2049,1057,5124,37,5124,5,2082,1071,1,0,1071,1]

def active9318 : List Nat := [0,1,2,4,9,10,11]

def tree9318 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9318 : H12WitnessSearch.Good tree9318 := H12GlobalWitnessIndex.good

theorem leafIdentity9318 : H12AffineFastState.composeSystem env9318 rootObs = leafEnv9318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9318 rootObs == leafEnv9318) = true)

theorem terminalChecked9318 : H12PackedTerminal.terminalCheckFast leafEnv9318 active9318 tree9318 = true := by decide +kernel

def env9319 : List Nat := [2,4,8,16,32,17,8,36,0,1024,2048,4096,7196,4097,2048,2082,1077,7221,1024,2048,4097,32,5157,3,7197,5157,7221,4097,1077,2049,1057,5151,37,5151,1077,1]

theorem envBound9319 : H12AffineFastState.Bounded env9319 := by
  intro p hp
  have h : env9319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9316_9319 : H12AffineEnvironment.transform 5 17 env9316 = env9319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9316 == env9319) = true)

theorem identity9319 : scanCanonicalize (H12AffineFastState.compose env9319 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1070) := by decide +kernel

theorem selectedBound9319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9320 : List Nat := [2,4,8,16,32,17,8,36,0,1024,2048,1070,2098,1071,2048,2082,1077,2075,1024,2048,1071,32,11,3,2099,11,2075,1071,1077,2049,1057,49,37,49,1077,1]

theorem envBound9320 : H12AffineFastState.Bounded env9320 := by
  intro p hp
  have h : env9320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9319_9320 : H12AffineEnvironment.transform 11 1070 env9319 = env9320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1070 env9319 == env9320) = true)

def leafEnv9320 : List Nat := [2,4,8,16,32,17,8,36,0,1024,2048,1070,2098,1071,2048,2082,1077,2075,1024,2048,1071,32,11,3,1057,2099,1,11,2075,1071,1077,2049,1057,49,37,49,5,2082,1077,1,0,1076,1]

def active9320 : List Nat := [0,1,2,3,4,9,10]

def tree9320 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9320 : H12WitnessSearch.Good tree9320 := H12GlobalWitnessIndex.good

theorem leafIdentity9320 : H12AffineFastState.composeSystem env9320 rootObs = leafEnv9320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9320 rootObs == leafEnv9320) = true)

theorem terminalChecked9320 : H12PackedTerminal.terminalCheckFast leafEnv9320 active9320 tree9320 = true := by decide +kernel

def env9321 : List Nat := [2,4,8,16,32,64,9,36,1,1024,2048,4096,7196,4176,2048,2083,1124,7221,1024,2048,4097,32,5236,2,7196,5157,7221,4176,1077,2049,1057,4294967296,37,4294967296,1124,0]

theorem envBound9321 : H12AffineFastState.Bounded env9321 := by
  intro p hp
  have h : env9321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9314_9321 : H12AffineEnvironment.transform 6 9 env9314 = env9321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9314 == env9321) = true)

theorem identity9321 : scanCanonicalize (H12AffineFastState.compose env9321 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 43) := by decide +kernel

theorem selectedBound9321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9322 : List Nat := [2,4,8,16,32,64,9,36,1,1024,2048,4096,7196,4176,2048,2083,1124,7221,1024,2048,4097,32,5236,2,7196,5157,7221,4176,1077,2049,1057,43,37,43,1124,0]

theorem envBound9322 : H12AffineFastState.Bounded env9322 := by
  intro p hp
  have h : env9322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9321_9322 : H12AffineEnvironment.transform 31 43 env9321 = env9322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 43 env9321 == env9322) = true)

def env9323 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,4096,7196,4096,2048,2083,1076,7221,1024,2048,4097,32,5156,2,7196,5157,7221,4096,1077,2049,1057,43,37,43,1076,0]

theorem envBound9323 : H12AffineFastState.Bounded env9323 := by
  intro p hp
  have h : env9323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9322_9323 : H12AffineEnvironment.transform 5 16 env9322 = env9323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9322 == env9323) = true)

theorem identity9323 : scanCanonicalize (H12AffineFastState.compose env9323 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound9323 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9324 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1071,2099,1071,2048,2083,1076,2074,1024,2048,1070,32,11,2,2099,10,2074,1071,1077,2049,1057,43,37,43,1076,0]

theorem envBound9324 : H12AffineFastState.Bounded env9324 := by
  intro p hp
  have h : env9324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9323_9324 : H12AffineEnvironment.transform 11 1071 env9323 = env9324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env9323 == env9324) = true)

def leafEnv9324 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1071,2099,1071,2048,2083,1076,2074,1024,2048,1070,32,11,2,1057,2099,1,10,2074,1071,1077,2049,1057,43,37,43,5,2082,1076,0,0,1076,1]

def active9324 : List Nat := [0,1,2,3,4,9,10]

def tree9324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9324 : H12WitnessSearch.Good tree9324 := H12GlobalWitnessIndex.good

theorem leafIdentity9324 : H12AffineFastState.composeSystem env9324 rootObs = leafEnv9324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9324 rootObs == leafEnv9324) = true)

theorem terminalChecked9324 : H12PackedTerminal.terminalCheckFast leafEnv9324 active9324 tree9324 = true := by decide +kernel

def env9325 : List Nat := [2,4,8,16,32,17,9,36,1,1024,2048,4096,7196,4097,2048,2083,1077,7221,1024,2048,4097,32,5157,2,7196,5157,7221,4097,1077,2049,1057,43,37,43,1077,0]

theorem envBound9325 : H12AffineFastState.Bounded env9325 := by
  intro p hp
  have h : env9325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9322_9325 : H12AffineEnvironment.transform 5 17 env9322 = env9325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9322 == env9325) = true)

theorem identity9325 : scanCanonicalize (H12AffineFastState.compose env9325 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9326 : List Nat := [2,4,8,10,32,11,9,36,1,1024,2048,4096,7174,4097,2048,2083,1071,7215,1024,2048,4097,32,5157,2,7174,5157,7215,4097,1071,2049,1057,43,37,43,1071,0]

theorem envBound9326 : H12AffineFastState.Bounded env9326 := by
  intro p hp
  have h : env9326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9325_9326 : H12AffineEnvironment.transform 3 10 env9325 = env9326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9325 == env9326) = true)

def leafEnv9326 : List Nat := [2,4,8,10,32,11,9,36,1,1024,2048,4096,7174,4097,2048,2083,1071,7215,1024,2048,4097,32,5157,2,1057,7174,1,5157,7215,4097,1071,2049,1057,43,37,43,5,2082,1071,0,0,1070,1]

def active9326 : List Nat := [0,1,2,4,9,10,11]

def tree9326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9326 : H12WitnessSearch.Good tree9326 := H12GlobalWitnessIndex.good

theorem leafIdentity9326 : H12AffineFastState.composeSystem env9326 rootObs = leafEnv9326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9326 rootObs == leafEnv9326) = true)

theorem terminalChecked9326 : H12PackedTerminal.terminalCheckFast leafEnv9326 active9326 tree9326 = true := by decide +kernel

def env9327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,33167,1344,43048,1024,32768,4097,4194304,5457,138,8328,5377,4237613,4177,1297,4196613,1285,4294967296,257,4299161633,1344,512]

theorem envBound9327 : H12AffineFastState.Bounded env9327 := by
  intro p hp
  have h : env9327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9308_9327 : H12AffineEnvironment.transform 13 4177 env9308 = env9327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9308 == env9327) = true)

theorem identity9327 : scanCanonicalize (H12AffineFastState.compose env9327 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound9327 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,261,138,1344,10541,1024,261,4097,4194304,5457,138,8328,5377,4204584,4177,1297,4196613,1285,4294967296,257,4299161633,1344,512]

theorem envBound9328 : H12AffineFastState.Bounded env9328 := by
  intro p hp
  have h : env9328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9327_9328 : H12AffineEnvironment.transform 14 261 env9327 = env9328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env9327 == env9328) = true)

theorem identity9328 : scanCanonicalize (H12AffineFastState.compose env9328 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 13132) := by decide +kernel

theorem selectedBound9328 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,261,138,1344,10541,1024,261,4097,13132,5457,138,8328,5377,7012,4177,1297,14921,1285,4294967296,257,4294980461,1344,512]

theorem envBound9329 : H12AffineFastState.Bounded env9329 := by
  intro p hp
  have h : env9329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9328_9329 : H12AffineEnvironment.transform 21 13132 env9328 = env9329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 13132 env9328 == env9329) = true)

theorem identity9329 : scanCanonicalize (H12AffineFastState.compose env9329 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound9329 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env9330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,8192,4177,261,138,1344,8842,1024,261,4097,13132,5457,138,8328,5377,4291,4177,1297,12782,1285,4294967296,257,4294980461,1344,512]

theorem envBound9330 : H12AffineFastState.Bounded env9330 := by
  intro p hp
  have h : env9330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9329_9330 : H12AffineEnvironment.transform 10 935 env9329 = env9330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env9329 == env9330) = true)

theorem identity9330 : scanCanonicalize (H12AffineFastState.compose env9330 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound9330 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env9331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,1289,4177,261,138,1344,1923,1024,261,4097,5701,5457,138,1409,5377,4291,4177,1297,5351,1285,4294967296,257,4294973028,1344,512]

theorem envBound9331 : H12AffineFastState.Bounded env9331 := by
  intro p hp
  have h : env9331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9330_9331 : H12AffineEnvironment.transform 12 1289 env9330 = env9331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env9330 == env9331) = true)

theorem identity9331 : scanCanonicalize (H12AffineFastState.compose env9331 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1992) := by decide +kernel

theorem selectedBound9331 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,1992,1289,1945,261,138,1344,1923,1024,261,1993,397,665,138,1409,713,1803,1945,1297,815,1285,4294967296,257,4294967724,1344,512]

theorem envBound9332 : H12AffineFastState.Bounded env9332 := by
  intro p hp
  have h : env9332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9331_9332 : H12AffineEnvironment.transform 11 1992 env9331 = env9332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1992 env9331 == env9332) = true)

theorem identity9332 : scanCanonicalize (H12AffineFastState.compose env9332 (packedSelected [1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound9332 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9333 : List Nat := [2,4,8,16,32,64,128,256,512,267,935,707,2,658,261,138,75,648,267,261,706,397,665,138,138,713,512,658,26,815,14,4294967296,257,4294967724,75,512]

theorem envBound9333 : H12AffineFastState.Bounded env9333 := by
  intro p hp
  have h : env9333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9332_9333 : H12AffineEnvironment.transform 9 267 env9332 = env9333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env9332 == env9333) = true)

theorem identity9333 : scanCanonicalize (H12AffineFastState.compose env9333 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound9333 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9334 : List Nat := [2,4,8,16,32,64,128,256,512,267,935,707,2,658,261,138,75,648,267,261,706,397,665,138,138,713,512,658,26,815,14,805,257,649,75,512]

theorem envBound9334 : H12AffineFastState.Bounded env9334 := by
  intro p hp
  have h : env9334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9333_9334 : H12AffineEnvironment.transform 31 805 env9333 = env9334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env9333 == env9334) = true)

theorem identity9334 : scanCanonicalize (H12AffineFastState.compose env9334 (packedSelected [1,12,21] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9334 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env9335 : List Nat := [2,4,2,16,32,64,128,256,512,257,935,707,2,658,261,128,65,642,257,261,706,391,659,128,128,707,512,658,16,805,4,805,257,643,65,512]

theorem envBound9335 : H12AffineFastState.Bounded env9335 := by
  intro p hp
  have h : env9335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9334_9335 : H12AffineEnvironment.transform 2 2 env9334 = env9335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9334 == env9335) = true)

def env9336 : List Nat := [2,4,2,16,32,64,128,256,32,257,391,227,2,178,261,128,65,162,257,261,226,391,179,128,128,227,32,178,16,261,4,261,257,163,65,32]

theorem envBound9336 : H12AffineFastState.Bounded env9336 := by
  intro p hp
  have h : env9336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9335_9336 : H12AffineEnvironment.transform 8 32 env9335 = env9336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9335 == env9336) = true)

theorem identity9336 : scanCanonicalize (H12AffineFastState.compose env9336 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 80) := by decide +kernel

theorem selectedBound9336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9337 : List Nat := [2,4,2,16,32,64,80,256,32,257,343,51,2,98,261,80,65,114,257,261,50,343,99,80,80,51,32,98,16,261,4,261,257,115,65,32]

theorem envBound9337 : H12AffineFastState.Bounded env9337 := by
  intro p hp
  have h : env9337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9336_9337 : H12AffineEnvironment.transform 6 80 env9336 = env9337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 80 env9336 == env9337) = true)

def env9338 : List Nat := [2,4,2,16,32,64,80,84,32,85,3,51,2,98,81,80,65,114,85,81,50,3,99,80,80,51,32,98,16,81,4,81,85,115,65,32]

theorem envBound9338 : H12AffineFastState.Bounded env9338 := by
  intro p hp
  have h : env9338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9337_9338 : H12AffineEnvironment.transform 7 84 env9337 = env9338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9337 == env9338) = true)

def env9339 : List Nat := [2,4,2,16,32,64,80,85,32,84,2,51,2,98,80,80,65,114,84,80,50,2,99,80,80,51,32,98,16,80,4,80,84,115,65,32]

theorem envBound9339 : H12AffineFastState.Bounded env9339 := by
  intro p hp
  have h : env9339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9337_9339 : H12AffineEnvironment.transform 7 85 env9337 = env9339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9337 == env9339) = true)

theorem identity9339 : scanCanonicalize (H12AffineFastState.compose env9339 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound9339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9340 : List Nat := [2,4,2,16,2,64,80,85,2,84,2,17,2,64,80,80,65,80,84,80,16,2,65,80,80,17,2,64,16,80,4,80,84,81,65,2]

theorem envBound9340 : H12AffineFastState.Bounded env9340 := by
  intro p hp
  have h : env9340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9339_9340 : H12AffineEnvironment.transform 4 2 env9339 = env9340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env9339 == env9340) = true)

theorem identity9340 : scanCanonicalize (H12AffineFastState.compose env9340 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound9340 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9341 : List Nat := [2,4,2,16,2,18,2,7,2,6,2,17,2,18,2,2,19,2,6,2,16,2,19,2,2,17,2,18,16,2,4,2,6,3,19,2]

theorem envBound9341 : H12AffineFastState.Bounded env9341 := by
  intro p hp
  have h : env9341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9340_9341 : H12AffineEnvironment.transform 5 18 env9340 = env9341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env9340 == env9341) = true)

def env9342 : List Nat := [2,4,2,16,32,64,128,256,33,257,390,226,2,179,261,128,65,163,257,261,227,391,178,128,128,226,33,179,16,260,4,260,257,162,65,33]

theorem envBound9342 : H12AffineFastState.Bounded env9342 := by
  intro p hp
  have h : env9342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9335_9342 : H12AffineEnvironment.transform 8 33 env9335 = env9342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env9335 == env9342) = true)

theorem identity9342 : scanCanonicalize (H12AffineFastState.compose env9342 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound9342 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9343 : List Nat := [2,4,2,16,32,18,128,256,33,257,390,176,2,179,261,128,19,163,257,261,177,391,178,128,128,176,33,179,16,260,4,260,257,162,19,33]

theorem envBound9343 : H12AffineFastState.Bounded env9343 := by
  intro p hp
  have h : env9343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9342_9343 : H12AffineEnvironment.transform 5 18 env9342 = env9343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env9342 == env9343) = true)

theorem identity9343 : scanCanonicalize (H12AffineFastState.compose env9343 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound9343 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9344 : List Nat := [2,4,2,16,32,18,128,166,33,167,32,176,2,179,163,128,19,163,167,163,177,33,178,128,128,176,33,179,16,162,4,162,167,162,19,33]

theorem envBound9344 : H12AffineFastState.Bounded env9344 := by
  intro p hp
  have h : env9344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9343_9344 : H12AffineEnvironment.transform 7 166 env9343 = env9344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env9343 == env9344) = true)

theorem identity9344 : scanCanonicalize (H12AffineFastState.compose env9344 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 32) := by decide +kernel

theorem selectedBound9344 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9345 : List Nat := [2,4,2,16,32,18,32,6,33,7,32,16,2,19,3,32,19,3,7,3,17,33,18,32,32,16,33,19,16,2,4,2,7,2,19,33]

theorem envBound9345 : H12AffineFastState.Bounded env9345 := by
  intro p hp
  have h : env9345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9344_9345 : H12AffineEnvironment.transform 6 32 env9344 = env9345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 32 env9344 == env9345) = true)

theorem identity9345 : scanCanonicalize (H12AffineFastState.compose env9345 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound9345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9346 : List Nat := [0,4,0,16,32,16,32,4,33,5,32,16,0,17,1,32,17,1,5,1,17,33,16,32,32,16,33,17,16,0,4,0,5,0,17,33]

theorem envBound9346 : H12AffineFastState.Bounded env9346 := by
  intro p hp
  have h : env9346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9345_9346 : H12AffineEnvironment.transform 0 0 env9345 = env9346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env9345 == env9346) = true)

theorem identity9346 : scanCanonicalize (H12AffineFastState.compose env9346 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9346 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9347 : List Nat := [0,4,0,16,0,16,0,4,1,5,0,16,0,17,1,0,17,1,5,1,17,1,16,0,0,16,1,17,16,0,4,0,5,0,17,1]

theorem envBound9347 : H12AffineFastState.Bounded env9347 := by
  intro p hp
  have h : env9347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9346_9347 : H12AffineEnvironment.transform 4 0 env9346 = env9347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9346 == env9347) = true)

def leafEnv9347 : List Nat := [0,4,0,16,0,16,0,4,1,5,0,16,0,17,1,0,17,1,5,1,17,1,16,0,4,0,1,16,1,17,16,0,4,0,5,0,5,0,17,1,0,17,1]

def active9347 : List Nat := [1,3]

def tree9347 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9347 : H12WitnessSearch.Good tree9347 := H12GlobalWitnessIndex.good

theorem leafIdentity9347 : H12AffineFastState.composeSystem env9347 rootObs = leafEnv9347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9347 rootObs == leafEnv9347) = true)

theorem terminalChecked9347 : H12PackedTerminal.terminalCheckFast leafEnv9347 active9347 tree9347 = true := by decide +kernel

def env9348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,16777216,33554432,16880644,21352529,16892165,1297,1073741824,16876544,4294967296,257,4332843382,1344,33563272]

theorem envBound9348 : H12AffineFastState.Bounded env9348 := by
  intro p hp
  have h : env9348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9302_9348 : H12AffineEnvironment.transform 18 1025 env9302 = env9348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9302 == env9348) = true)

theorem identity9348 : scanCanonicalize (H12AffineFastState.compose env9348 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 20973967) := by decide +kernel

theorem selectedBound9348 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,16777216,33554432,16880644,21352529,16892165,1297,20973967,16876544,4294967296,257,4332843382,1344,33563272]

theorem envBound9349 : H12AffineFastState.Bounded env9349 := by
  intro p hp
  have h : env9349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9348_9349 : H12AffineEnvironment.transform 29 20973967 env9348 = env9349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 20973967 env9348 == env9349) = true)

theorem identity9349 : scanCanonicalize (H12AffineFastState.compose env9349 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9349 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env9350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,98565,33554432,5377,4477268,16384,1297,4294794,1285,4294967296,257,4332843382,1344,33563272]

theorem envBound9350 : H12AffineFastState.Bounded env9350 := by
  intro p hp
  have h : env9350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9349_9350 : H12AffineEnvironment.transform 23 98565 env9349 = env9350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9349 == env9350) = true)

theorem identity9350 : scanCanonicalize (H12AffineFastState.compose env9350 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 63609) := by decide +kernel

theorem selectedBound9350 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,63609,1025,32768,4097,4194304,17664,98565,33554432,5377,4237613,16384,1297,4294794,1285,4294967296,257,4332843382,1344,33563272]

theorem envBound9351 : H12AffineFastState.Bounded env9351 := by
  intro p hp
  have h : env9351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9350_9351 : H12AffineEnvironment.transform 17 63609 env9350 = env9351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63609 env9350 == env9351) = true)

theorem identity9351 : scanCanonicalize (H12AffineFastState.compose env9351 (packedSelected [6,11,16,18,20,23,25,32] rootPS)) = affineNative (2^(24+1) ^^^ 127318) := by decide +kernel

theorem selectedBound9351 : packedSelected [6,11,16,18,20,23,25,32] rootPS < 2^1333 := by decide +kernel

def env9352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,63609,1025,32768,4097,4194304,17664,98565,127318,5377,4237613,16384,1297,4294794,1285,4294967296,257,4299161632,1344,119774]

theorem envBound9352 : H12AffineFastState.Bounded env9352 := by
  intro p hp
  have h : env9352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9351_9352 : H12AffineEnvironment.transform 24 127318 env9351 = env9352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 127318 env9351 == env9352) = true)

def env9353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1025,32768,4097,4194304,5456,98565,106758,5377,4237613,4176,1297,4294794,1285,4294967296,257,4299161632,1344,99214]

theorem envBound9353 : H12AffineFastState.Bounded env9353 := by
  intro p hp
  have h : env9353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9352_9353 : H12AffineEnvironment.transform 13 4176 env9352 = env9353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env9352 == env9353) = true)

theorem identity9353 : scanCanonicalize (H12AffineFastState.compose env9353 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9353 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9354 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4176,32768,65536,1344,43049,1025,32768,4097,4194304,5456,98565,106758,5377,4237613,4176,1297,4294794,1285,4294967296,257,4299161632,1344,98566]

theorem envBound9354 : H12AffineFastState.Bounded env9354 := by
  intro p hp
  have h : env9354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9353_9354 : H12AffineEnvironment.transform 8 136 env9353 = env9354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9353 == env9354) = true)

theorem identity9354 : scanCanonicalize (H12AffineFastState.compose env9354 (packedSelected [5,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 48562) := by decide +kernel

theorem selectedBound9354 : packedSelected [5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env9355 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4176,32768,48562,1344,43049,1025,32768,4097,4194304,5456,15543,7348,5377,4237613,4176,1297,4207928,1285,4294967296,257,4299161632,1344,15540]

theorem envBound9355 : H12AffineFastState.Bounded env9355 := by
  intro p hp
  have h : env9355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9354_9355 : H12AffineEnvironment.transform 15 48562 env9354 = env9355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 48562 env9354 == env9355) = true)

theorem identity9355 : scanCanonicalize (H12AffineFastState.compose env9355 (packedSelected [1,3,5,10,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 7229) := by decide +kernel

theorem selectedBound9355 : packedSelected [1,3,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env9356 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,7229,4176,32768,33167,1344,37908,1025,32768,4097,4194304,5456,138,7348,5377,4232464,4176,1297,4196613,1285,4294967296,257,4299161632,1344,137]

theorem envBound9356 : H12AffineFastState.Bounded env9356 := by
  intro p hp
  have h : env9356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9355_9356 : H12AffineEnvironment.transform 12 7229 env9355 = env9356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7229 env9355 == env9356) = true)

theorem identity9356 : scanCanonicalize (H12AffineFastState.compose env9356 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9356 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9357 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,7229,4176,32768,33167,1344,37908,1025,32768,4097,476,5456,138,7348,5377,38092,4176,1297,2265,1285,4294967296,257,4294967804,1344,137]

theorem envBound9357 : H12AffineFastState.Bounded env9357 := by
  intro p hp
  have h : env9357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9356_9357 : H12AffineEnvironment.transform 21 476 env9356 = env9357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9356 == env9357) = true)

theorem identity9357 : scanCanonicalize (H12AffineFastState.compose env9357 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound9357 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9358 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,7229,4176,2081,2478,1344,7221,1025,2081,4097,476,5456,138,7348,5377,7405,4176,1297,2265,1285,4294967296,257,4294967804,1344,137]

theorem envBound9358 : H12AffineFastState.Bounded env9358 := by
  intro p hp
  have h : env9358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9357_9358 : H12AffineEnvironment.transform 14 2081 env9357 = env9358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env9357 == env9358) = true)

theorem identity9358 : scanCanonicalize (H12AffineFastState.compose env9358 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound9358 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env9359 : List Nat := [2,4,8,16,32,64,128,256,136,1024,33,4096,5148,4176,0,399,1344,5140,1025,0,4097,476,5456,138,5269,5377,5324,4176,1297,248,1285,4294967296,257,4294967804,1344,137]

theorem envBound9359 : H12AffineFastState.Bounded env9359 := by
  intro p hp
  have h : env9359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9358_9359 : H12AffineEnvironment.transform 10 33 env9358 = env9359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env9358 == env9359) = true)

def env9360 : List Nat := [2,4,8,16,32,64,128,256,136,1024,33,1296,268,1344,0,399,1344,260,1025,0,1297,476,64,138,389,17,476,1344,1297,248,1285,4294967296,257,4294967804,1344,137]

theorem envBound9360 : H12AffineFastState.Bounded env9360 := by
  intro p hp
  have h : env9360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9359_9360 : H12AffineEnvironment.transform 11 1296 env9359 = env9360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9359 == env9360) = true)

theorem identity9360 : scanCanonicalize (H12AffineFastState.compose env9360 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9361 : List Nat := [2,4,8,16,32,64,88,256,80,1024,33,1296,268,1344,0,343,1344,260,1025,0,1297,260,64,82,349,17,260,1344,1297,32,1285,4294967296,257,4294967588,1344,81]

theorem envBound9361 : H12AffineFastState.Bounded env9361 := by
  intro p hp
  have h : env9361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9360_9361 : H12AffineEnvironment.transform 6 88 env9360 = env9361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9360 == env9361) = true)

theorem identity9361 : scanCanonicalize (H12AffineFastState.compose env9361 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 270) := by decide +kernel

theorem selectedBound9361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9362 : List Nat := [2,4,8,16,32,64,88,256,80,1024,33,1296,268,1344,0,343,1344,260,1025,0,1297,260,64,82,349,17,260,1344,1297,32,1285,270,257,42,1344,81]

theorem envBound9362 : H12AffineFastState.Bounded env9362 := by
  intro p hp
  have h : env9362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9361_9362 : H12AffineEnvironment.transform 31 270 env9361 = env9362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 270 env9361 == env9362) = true)

theorem identity9362 : scanCanonicalize (H12AffineFastState.compose env9362 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9362 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9363 : List Nat := [2,4,8,16,1,64,88,256,80,1024,0,1296,268,1344,0,343,1344,260,1025,0,1297,260,64,82,349,17,260,1344,1297,1,1285,270,257,11,1344,81]

theorem envBound9363 : H12AffineFastState.Bounded env9363 := by
  intro p hp
  have h : env9363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9362_9363 : H12AffineEnvironment.transform 4 1 env9362 = env9363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9362 == env9363) = true)

theorem identity9363 : scanCanonicalize (H12AffineFastState.compose env9363 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9363 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9364 : List Nat := [2,4,8,16,1,64,88,5,80,1024,0,1045,9,1093,0,82,1093,1,1025,0,1044,1,64,82,88,17,1,1093,1044,1,1024,11,4,11,1093,81]

theorem envBound9364 : H12AffineFastState.Bounded env9364 := by
  intro p hp
  have h : env9364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9363_9364 : H12AffineEnvironment.transform 7 5 env9363 = env9364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9363 == env9364) = true)

theorem identity9364 : scanCanonicalize (H12AffineFastState.compose env9364 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9365 : List Nat := [2,4,8,16,1,10,18,5,26,1024,0,1045,9,1039,0,24,1039,1,1025,0,1044,1,10,24,18,17,1,1039,1044,1,1024,11,4,11,1039,27]

theorem envBound9365 : H12AffineFastState.Bounded env9365 := by
  intro p hp
  have h : env9365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9364_9365 : H12AffineEnvironment.transform 5 10 env9364 = env9365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9364 == env9365) = true)

def leafEnv9365 : List Nat := [2,4,8,16,1,10,18,5,26,1024,0,1045,9,1039,0,24,1039,1,1025,0,1044,1,10,24,1025,18,1,17,1,1039,1044,1,1024,11,4,11,5,3,1039,27,0,1045,1]

def active9365 : List Nat := [0,1,2,3,9]

def tree9365 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9365 : H12WitnessSearch.Good tree9365 := H12GlobalWitnessIndex.good

theorem leafIdentity9365 : H12AffineFastState.composeSystem env9365 rootObs = leafEnv9365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9365 rootObs == leafEnv9365) = true)

theorem terminalChecked9365 : H12PackedTerminal.terminalCheckFast leafEnv9365 active9365 tree9365 = true := by decide +kernel

def env9366 : List Nat := [2,4,8,16,32,64,128,256,136,1024,33,1297,269,1345,0,399,1344,261,1025,0,1296,476,65,138,388,16,477,1345,1297,248,1285,4294967296,257,4294967804,1344,137]

theorem envBound9366 : H12AffineFastState.Bounded env9366 := by
  intro p hp
  have h : env9366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9359_9366 : H12AffineEnvironment.transform 11 1297 env9359 = env9366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9359 == env9366) = true)

theorem identity9366 : scanCanonicalize (H12AffineFastState.compose env9366 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound9366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9367 : List Nat := [2,4,8,16,32,64,128,221,136,1024,33,1228,208,1180,0,82,1181,216,1025,0,1229,1,65,138,89,16,0,1180,1228,248,1240,4294967296,220,4294967329,1181,137]

theorem envBound9367 : H12AffineFastState.Bounded env9367 := by
  intro p hp
  have h : env9367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9366_9367 : H12AffineEnvironment.transform 7 221 env9366 = env9367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env9366 == env9367) = true)

theorem identity9367 : scanCanonicalize (H12AffineFastState.compose env9367 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9367 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9368 : List Nat := [2,4,8,16,32,64,121,36,113,1024,33,1077,41,1125,0,82,1124,33,1025,0,1076,1,65,115,89,16,0,1125,1077,1,1057,4294967296,37,4294967329,1124,112]

theorem envBound9368 : H12AffineFastState.Bounded env9368 := by
  intro p hp
  have h : env9368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9367_9368 : H12AffineEnvironment.transform 6 121 env9367 = env9368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9367 == env9368) = true)

theorem identity9368 : scanCanonicalize (H12AffineFastState.compose env9368 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 123) := by decide +kernel

theorem selectedBound9368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9369 : List Nat := [2,4,8,16,32,64,121,36,113,1024,33,1077,41,1125,0,82,1124,33,1025,0,1076,1,65,115,89,16,0,1125,1077,1,1057,123,37,90,1124,112]

theorem envBound9369 : H12AffineFastState.Bounded env9369 := by
  intro p hp
  have h : env9369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9368_9369 : H12AffineEnvironment.transform 31 123 env9368 = env9369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 123 env9368 == env9369) = true)

theorem identity9369 : scanCanonicalize (H12AffineFastState.compose env9369 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9369 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9370 : List Nat := [2,4,8,16,1,64,88,5,80,1024,0,1044,8,1092,0,82,1093,0,1025,0,1045,1,65,82,89,16,0,1092,1044,1,1024,90,4,90,1093,81]

theorem envBound9370 : H12AffineFastState.Bounded env9370 := by
  intro p hp
  have h : env9370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9369_9370 : H12AffineEnvironment.transform 4 1 env9369 = env9370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9369 == env9370) = true)

theorem identity9370 : scanCanonicalize (H12AffineFastState.compose env9370 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9371 : List Nat := [2,4,8,16,1,10,18,5,26,1024,0,1044,8,1038,0,24,1039,0,1025,0,1045,1,11,24,19,16,0,1038,1044,1,1024,16,4,16,1039,27]

theorem envBound9371 : H12AffineFastState.Bounded env9371 := by
  intro p hp
  have h : env9371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9370_9371 : H12AffineEnvironment.transform 5 10 env9370 = env9371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9370 == env9371) = true)

def leafEnv9371 : List Nat := [2,4,8,16,1,10,18,5,26,1024,0,1044,8,1038,0,24,1039,0,1025,0,1045,1,11,24,1025,19,1,16,0,1038,1044,1,1024,16,4,16,5,3,1039,27,0,1045,1]

def active9371 : List Nat := [0,1,2,3,9]

def tree9371 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9371 : H12WitnessSearch.Good tree9371 := H12GlobalWitnessIndex.good

theorem leafIdentity9371 : H12AffineFastState.composeSystem env9371 rootObs = leafEnv9371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9371 rootObs == leafEnv9371) = true)

theorem terminalChecked9371 : H12PackedTerminal.terminalCheckFast leafEnv9371 active9371 tree9371 = true := by decide +kernel

def env9372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,43048,1025,32768,4097,4194304,5457,98565,106759,5377,4237613,4177,1297,4294794,1285,4294967296,257,4299161632,1344,99215]

theorem envBound9372 : H12AffineFastState.Bounded env9372 := by
  intro p hp
  have h : env9372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9352_9372 : H12AffineEnvironment.transform 13 4177 env9352 = env9372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9352 == env9372) = true)

def env9373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,43048,1025,32768,1345,4194304,17,98565,106759,65,4237613,1297,1297,4294794,1285,4294967296,257,4299161632,1344,99215]

theorem envBound9373 : H12AffineFastState.Bounded env9373 := by
  intro p hp
  have h : env9373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9372_9373 : H12AffineEnvironment.transform 11 1344 env9372 = env9373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env9372 == env9373) = true)

theorem identity9373 : scanCanonicalize (H12AffineFastState.compose env9373 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound9373 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,2218,1344,43048,1025,32768,1345,4194304,17,35247,43437,65,4237613,1297,1297,4227104,1285,4294967296,257,4299161632,1344,35621]

theorem envBound9374 : H12AffineFastState.Bounded env9374 := by
  intro p hp
  have h : env9374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9373_9374 : H12AffineEnvironment.transform 15 2218 env9373 = env9374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env9373 == env9374) = true)

theorem identity9374 : scanCanonicalize (H12AffineFastState.compose env9374 (packedSelected [3,13] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound9374 : packedSelected [3,13] rootPS < 2^1333 := by decide +kernel

def env9375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,2341,2218,1344,8461,1025,2341,1345,4194304,17,138,8328,65,4202504,1297,1297,4196613,1285,4294967296,257,4299161632,1344,512]

theorem envBound9375 : H12AffineFastState.Bounded env9375 := by
  intro p hp
  have h : env9375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9374_9375 : H12AffineEnvironment.transform 14 2341 env9374 = env9375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env9374 == env9375) = true)

theorem identity9375 : scanCanonicalize (H12AffineFastState.compose env9375 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound9375 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,1344,8192,1297,642,781,1344,8461,1025,642,1345,4194304,17,138,8328,65,4202504,1297,1297,4194978,1285,4294967296,257,4299161632,1344,512]

theorem envBound9376 : H12AffineFastState.Bounded env9376 := by
  intro p hp
  have h : env9376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9375_9376 : H12AffineEnvironment.transform 10 935 env9375 = env9376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env9375 == env9376) = true)

theorem identity9376 : scanCanonicalize (H12AffineFastState.compose env9376 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound9376 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9377 : List Nat := [2,4,8,16,32,64,128,256,391,1024,32,1344,8192,1297,261,138,1344,8461,1025,261,1345,4194304,17,138,8328,65,4202504,1297,1297,4194597,1285,4294967296,257,4299161632,1344,391]

theorem envBound9377 : H12AffineFastState.Bounded env9377 := by
  intro p hp
  have h : env9377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9376_9377 : H12AffineEnvironment.transform 8 391 env9376 = env9377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env9376 == env9377) = true)

theorem identity9377 : scanCanonicalize (H12AffineFastState.compose env9377 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound9377 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9378 : List Nat := [2,4,8,16,32,64,128,256,391,257,32,65,8192,16,261,138,65,8461,256,261,64,4194304,17,138,8328,65,4202504,16,16,4194597,4,4294967296,257,4299161632,65,391]

theorem envBound9378 : H12AffineFastState.Bounded env9378 := by
  intro p hp
  have h : env9378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9377_9378 : H12AffineEnvironment.transform 9 257 env9377 = env9378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env9377 == env9378) = true)

theorem identity9378 : scanCanonicalize (H12AffineFastState.compose env9378 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound9378 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env9379 : List Nat := [2,4,8,16,32,64,128,256,391,257,32,65,8192,16,261,138,65,8461,256,261,64,397,17,138,8328,65,8581,16,16,168,4,4294967296,257,4294967725,65,391]

theorem envBound9379 : H12AffineFastState.Bounded env9379 := by
  intro p hp
  have h : env9379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9378_9379 : H12AffineEnvironment.transform 21 397 env9378 = env9379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env9378 == env9379) = true)

theorem identity9379 : scanCanonicalize (H12AffineFastState.compose env9379 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound9379 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env9380 : List Nat := [2,4,8,16,32,64,128,256,391,257,32,65,8192,16,261,138,65,8461,256,261,64,397,17,138,8328,65,8581,16,16,168,4,429,257,0,65,391]

theorem envBound9380 : H12AffineFastState.Bounded env9380 := by
  intro p hp
  have h : env9380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9379_9380 : H12AffineEnvironment.transform 31 429 env9379 = env9380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env9379 == env9380) = true)

theorem identity9380 : scanCanonicalize (H12AffineFastState.compose env9380 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound9380 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9381 : List Nat := [2,4,8,16,32,64,128,6,129,7,32,65,8192,16,3,138,65,8203,6,3,64,139,17,138,8328,65,8323,16,16,168,4,171,7,0,65,129]

theorem envBound9381 : H12AffineFastState.Bounded env9381 := by
  intro p hp
  have h : env9381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9380_9381 : H12AffineEnvironment.transform 7 6 env9380 = env9381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env9380 == env9381) = true)

theorem identity9381 : scanCanonicalize (H12AffineFastState.compose env9381 (packedSelected [2,22] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9381 : packedSelected [2,22] rootPS < 2^1333 := by decide +kernel

def env9382 : List Nat := [2,4,8,16,32,64,128,6,129,7,32,65,8,16,3,138,65,3,6,3,64,139,17,138,128,65,139,16,16,168,4,171,7,0,65,129]

theorem envBound9382 : H12AffineFastState.Bounded env9382 := by
  intro p hp
  have h : env9382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9381_9382 : H12AffineEnvironment.transform 12 8 env9381 = env9382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9381 == env9382) = true)

def env9383 : List Nat := [2,4,8,16,32,64,8,6,9,7,32,65,8,16,3,2,65,3,6,3,64,3,17,2,8,65,3,16,16,32,4,35,7,0,65,9]

theorem envBound9383 : H12AffineFastState.Bounded env9383 := by
  intro p hp
  have h : env9383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9382_9383 : H12AffineEnvironment.transform 6 8 env9382 = env9383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9382 == env9383) = true)

theorem identity9383 : scanCanonicalize (H12AffineFastState.compose env9383 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9384 : List Nat := [2,4,8,16,32,17,8,6,9,7,32,16,8,16,3,2,16,3,6,3,17,3,17,2,8,16,3,16,16,32,4,35,7,0,16,9]

theorem envBound9384 : H12AffineFastState.Bounded env9384 := by
  intro p hp
  have h : env9384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9383_9384 : H12AffineEnvironment.transform 5 17 env9383 = env9384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9383 == env9384) = true)

theorem identity9384 : scanCanonicalize (H12AffineFastState.compose env9384 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound9384 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9385 : List Nat := [2,4,8,16,3,17,8,6,9,7,3,16,8,16,3,2,16,3,6,3,17,3,17,2,8,16,3,16,16,3,4,0,7,0,16,9]

theorem envBound9385 : H12AffineFastState.Bounded env9385 := by
  intro p hp
  have h : env9385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9384_9385 : H12AffineEnvironment.transform 4 3 env9384 = env9385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env9384 == env9385) = true)

theorem identity9385 : scanCanonicalize (H12AffineFastState.compose env9385 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9385 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9386 : List Nat := [2,4,2,16,3,17,2,6,3,7,3,16,2,16,3,2,16,3,6,3,17,3,17,2,2,16,3,16,16,3,4,0,7,0,16,3]

theorem envBound9386 : H12AffineFastState.Bounded env9386 := by
  intro p hp
  have h : env9386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9385_9386 : H12AffineEnvironment.transform 2 2 env9385 = env9386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9385 == env9386) = true)

def leafEnv9386 : List Nat := [2,4,2,16,3,17,2,6,3,7,3,16,2,16,3,2,16,3,6,3,17,3,17,2,5,2,1,16,3,16,16,3,4,0,7,0,5,2,16,3,0,17,1]

def active9386 : List Nat := [0,1,3]

def tree9386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9386 : H12WitnessSearch.Good tree9386 := H12GlobalWitnessIndex.good

theorem leafIdentity9386 : H12AffineFastState.composeSystem env9386 rootObs = leafEnv9386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9386 rootObs == leafEnv9386) = true)

theorem terminalChecked9386 : H12PackedTerminal.terminalCheckFast leafEnv9386 active9386 tree9386 = true := by decide +kernel

def env9387 : List Nat := [2,4,8,16,32,64,9,6,8,7,32,65,8,16,3,3,65,3,6,3,64,2,17,3,9,65,2,16,16,33,4,34,7,0,65,8]

theorem envBound9387 : H12AffineFastState.Bounded env9387 := by
  intro p hp
  have h : env9387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9382_9387 : H12AffineEnvironment.transform 6 9 env9382 = env9387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9382 == env9387) = true)

theorem identity9387 : scanCanonicalize (H12AffineFastState.compose env9387 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 50) := by decide +kernel

theorem selectedBound9387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9388 : List Nat := [2,4,8,16,32,50,9,6,8,7,32,51,8,16,3,3,51,3,6,3,50,2,17,3,9,51,2,16,16,33,4,34,7,0,51,8]

theorem envBound9388 : H12AffineFastState.Bounded env9388 := by
  intro p hp
  have h : env9388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9387_9388 : H12AffineEnvironment.transform 5 50 env9387 = env9388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 50 env9387 == env9388) = true)

def env9389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,43048,1025,32768,1344,4194304,16,98565,106759,64,4237613,1296,1297,4294794,1285,4294967296,257,4299161632,1344,99215]

theorem envBound9389 : H12AffineFastState.Bounded env9389 := by
  intro p hp
  have h : env9389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9372_9389 : H12AffineEnvironment.transform 11 1345 env9372 = env9389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env9372 == env9389) = true)

theorem identity9389 : scanCanonicalize (H12AffineFastState.compose env9389 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 2989) := by decide +kernel

theorem selectedBound9389 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2989,65536,1344,9093,1025,2989,1344,4194304,16,68264,76458,64,4203136,1296,1297,4260647,1285,4294967296,257,4299161632,1344,67618]

theorem envBound9390 : H12AffineFastState.Bounded env9390 := by
  intro p hp
  have h : env9390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9389_9390 : H12AffineEnvironment.transform 14 2989 env9389 = env9390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2989 env9389 == env9390) = true)

theorem identity9390 : scanCanonicalize (H12AffineFastState.compose env9390 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound9390 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env9391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2989,2595,1344,9093,1025,2989,1344,4194304,16,139,8329,64,4203136,1296,1297,4196612,1285,4294967296,257,4299161632,1344,513]

theorem envBound9391 : H12AffineFastState.Bounded env9391 := by
  intro p hp
  have h : env9391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9390_9391 : H12AffineEnvironment.transform 15 2595 env9390 = env9391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env9390 == env9391) = true)

theorem identity9391 : scanCanonicalize (H12AffineFastState.compose env9391 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9391 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9392 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2340,2218,1344,8460,1025,2340,1344,4194304,16,139,8329,64,4202505,1296,1297,4196612,1285,4294967296,257,4299161632,1344,136]

theorem envBound9392 : H12AffineFastState.Bounded env9392 := by
  intro p hp
  have h : env9392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9391_9392 : H12AffineEnvironment.transform 8 137 env9391 = env9392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9391 == env9392) = true)

theorem identity9392 : scanCanonicalize (H12AffineFastState.compose env9392 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound9392 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9393 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2340,2218,1344,8460,1025,2340,1344,260,16,139,8329,64,8461,1296,1297,2048,1285,4294967296,257,4294967588,1344,136]

theorem envBound9393 : H12AffineFastState.Bounded env9393 := by
  intro p hp
  have h : env9393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9392_9393 : H12AffineEnvironment.transform 21 260 env9392 = env9393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env9392 == env9393) = true)

theorem identity9393 : scanCanonicalize (H12AffineFastState.compose env9393 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound9393 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9394 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2396,1296,2340,2218,1344,2128,1025,2340,1344,260,16,139,2517,64,2129,1296,1297,2048,1285,4294967296,257,4294967588,1344,136]

theorem envBound9394 : H12AffineFastState.Bounded env9394 := by
  intro p hp
  have h : env9394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9393_9394 : H12AffineEnvironment.transform 12 2396 env9393 = env9394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env9393 == env9394) = true)

theorem identity9394 : scanCanonicalize (H12AffineFastState.compose env9394 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9394 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9395 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2317,1296,2340,2218,1297,2049,1025,2340,1297,260,16,139,2436,17,2048,1296,1297,2048,1285,4294967296,257,4294967588,1297,136]

theorem envBound9395 : H12AffineFastState.Bounded env9395 := by
  intro p hp
  have h : env9395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9394_9395 : H12AffineEnvironment.transform 5 17 env9394 = env9395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9394 == env9395) = true)

theorem identity9395 : scanCanonicalize (H12AffineFastState.compose env9395 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound9395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9396 : List Nat := [2,4,8,16,32,17,57,256,48,1024,2048,1296,2317,1296,2340,2067,1297,2049,1025,2340,1297,260,16,50,2365,17,2048,1296,1297,2048,1285,4294967296,257,4294967588,1297,49]

theorem envBound9396 : H12AffineFastState.Bounded env9396 := by
  intro p hp
  have h : env9396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9395_9396 : H12AffineEnvironment.transform 6 57 env9395 = env9396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9395 == env9396) = true)

def env9397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,23445585,67130625,1297,1073741824,16876545,4294967296,256,4417151347,1345,33563272]

theorem envBound9397 : H12AffineFastState.Bounded env9397 := by
  intro p hp
  have h : env9397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9265_9397 : H12AffineEnvironment.transform 16 1345 env9265 = env9397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env9265 == env9397) = true)

def env9398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17664,16777216,33554432,67108864,21352529,67130625,1297,1073741824,16876545,4294967296,256,4417151347,1345,33563272]

theorem envBound9398 : H12AffineFastState.Bounded env9398 := by
  intro p hp
  have h : env9398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9397_9398 : H12AffineEnvironment.transform 20 4096 env9397 = env9398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9397 == env9398) = true)

def env9399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17664,16777216,33554432,67108864,21352528,67130625,1297,1073741824,16876545,4294967296,256,4417151347,1345,33563272]

theorem envBound9399 : H12AffineFastState.Bounded env9399 := by
  intro p hp
  have h : env9399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9397_9399 : H12AffineEnvironment.transform 20 4097 env9397 = env9399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9397 == env9399) = true)

theorem identity9399 : scanCanonicalize (H12AffineFastState.compose env9399 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 5376) := by decide +kernel

theorem selectedBound9399 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17664,16777216,33554432,5376,21352528,16385,1297,1073741824,16876545,4294967296,256,4350047347,1345,33563272]

theorem envBound9400 : H12AffineFastState.Bounded env9400 := by
  intro p hp
  have h : env9400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9399_9400 : H12AffineEnvironment.transform 25 5376 env9399 = env9400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9399 == env9400) = true)

theorem identity9400 : scanCanonicalize (H12AffineFastState.compose env9400 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9400 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env9401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17664,16777216,8329,5376,21352528,16385,1297,1073741824,16876545,4294967296,256,4316484858,1345,513]

theorem envBound9401 : H12AffineFastState.Bounded env9401 := by
  intro p hp
  have h : env9401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9400_9401 : H12AffineEnvironment.transform 24 8329 env9400 = env9401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9400 == env9401) = true)

theorem identity9401 : scanCanonicalize (H12AffineFastState.compose env9401 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9401 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,4194304,17664,98565,8329,5376,4477269,16385,1297,1073741824,1284,4294967296,256,4299806207,1345,513]

theorem envBound9402 : H12AffineFastState.Bounded env9402 := by
  intro p hp
  have h : env9402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9401_9402 : H12AffineEnvironment.transform 23 98565 env9401 = env9402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9401 == env9402) = true)

theorem identity9402 : scanCanonicalize (H12AffineFastState.compose env9402 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound9402 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,262144,524288,32768,4097,4194304,6105,98565,8329,5376,4457356,4824,1297,1073741824,1284,4294967296,256,4299786022,1345,513]

theorem envBound9403 : H12AffineFastState.Bounded env9403 := by
  intro p hp
  have h : env9403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9402_9403 : H12AffineEnvironment.transform 13 4825 env9402 = env9403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env9402 == env9403) = true)

theorem identity9403 : scanCanonicalize (H12AffineFastState.compose env9403 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound9403 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,43681,524288,32768,4097,4194304,6105,98565,8329,5376,4237613,4824,1297,1073741824,1284,4294967296,256,4299786022,1345,513]

theorem envBound9404 : H12AffineFastState.Bounded env9404 := by
  intro p hp
  have h : env9404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9403_9404 : H12AffineEnvironment.transform 17 43681 env9403 = env9404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env9403 == env9404) = true)

theorem identity9404 : scanCanonicalize (H12AffineFastState.compose env9404 (packedSelected [0,4,7,9,18,23] rootPS)) = affineNative (2^(29+1) ^^^ 4197261) := by decide +kernel

theorem selectedBound9404 : packedSelected [0,4,7,9,18,23] rootPS < 2^1333 := by decide +kernel

def env9405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,43681,524288,32768,4097,4194304,6105,98565,8329,5376,4237613,4824,1297,4197261,1284,4294967296,256,4299786022,1345,513]

theorem envBound9405 : H12AffineFastState.Bounded env9405 := by
  intro p hp
  have h : env9405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9404_9405 : H12AffineEnvironment.transform 29 4197261 env9404 = env9405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197261 env9404 == env9405) = true)

def env9406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,43681,524288,32768,4097,10248,6105,98565,8329,5376,33061,4824,1297,9093,1284,4294967296,256,4295601966,1345,513]

theorem envBound9406 : H12AffineFastState.Bounded env9406 := by
  intro p hp
  have h : env9406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9405_9406 : H12AffineEnvironment.transform 21 10248 env9405 = env9406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env9405 == env9406) = true)

theorem identity9406 : scanCanonicalize (H12AffineFastState.compose env9406 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound9406 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2317,4825,32768,65536,1345,33708,524288,32768,4097,261,6105,98565,2436,5376,33061,4824,1297,2696,1284,4294967296,256,4295591459,1345,513]

theorem envBound9407 : H12AffineFastState.Bounded env9407 := by
  intro p hp
  have h : env9407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9406_9407 : H12AffineEnvironment.transform 12 2317 env9406 = env9407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env9406 == env9407) = true)

def env9408 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,2317,4177,32768,65536,1345,33060,524288,32768,4097,261,5457,98565,2436,5376,33061,4176,1297,2048,1284,4294967296,256,4295591083,1345,137]

theorem envBound9408 : H12AffineFastState.Bounded env9408 := by
  intro p hp
  have h : env9408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9407_9408 : H12AffineEnvironment.transform 8 136 env9407 = env9408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9407 == env9408) = true)

theorem identity9408 : scanCanonicalize (H12AffineFastState.compose env9408 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 99726) := by decide +kernel

theorem selectedBound9408 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9409 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,2317,4177,32768,65536,1345,33060,99726,32768,4097,261,5457,98565,2436,5376,33061,4176,1297,2048,1284,4294967296,256,4294967589,1345,137]

theorem envBound9409 : H12AffineFastState.Bounded env9409 := by
  intro p hp
  have h : env9409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9408_9409 : H12AffineEnvironment.transform 18 99726 env9408 = env9409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99726 env9408 == env9409) = true)

theorem identity9409 : scanCanonicalize (H12AffineFastState.compose env9409 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 7220) := by decide +kernel

theorem selectedBound9409 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9410 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,2317,4177,7220,65536,1345,7440,72122,7220,4097,261,5457,73009,2436,5376,7441,4176,1297,2048,1284,4294967296,256,4294967589,1345,137]

theorem envBound9410 : H12AffineFastState.Bounded env9410 := by
  intro p hp
  have h : env9410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9409_9410 : H12AffineEnvironment.transform 14 7220 env9409 = env9410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7220 env9409 == env9410) = true)

def env9411 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,2317,4176,32768,65536,1345,33061,524288,32768,4097,261,5456,98565,2436,5376,33061,4177,1297,2049,1284,4294967296,256,4295591082,1345,136]

theorem envBound9411 : H12AffineFastState.Bounded env9411 := by
  intro p hp
  have h : env9411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9407_9411 : H12AffineEnvironment.transform 8 137 env9407 = env9411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9407 == env9411) = true)

theorem identity9411 : scanCanonicalize (H12AffineFastState.compose env9411 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound9411 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9412 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,2317,4176,32768,33167,1345,33061,524288,32768,4097,261,5456,138,2436,5376,33061,4177,1297,2049,1284,4294967296,256,4295492901,1345,136]

theorem envBound9412 : H12AffineFastState.Bounded env9412 := by
  intro p hp
  have h : env9412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9411_9412 : H12AffineEnvironment.transform 15 33167 env9411 = env9412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env9411 == env9412) = true)

theorem identity9412 : scanCanonicalize (H12AffineFastState.compose env9412 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound9412 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9413 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1044,2317,1092,32768,33167,1345,33061,524288,32768,1045,261,324,138,2436,276,33061,1093,1297,2049,1284,4294967296,256,4295492901,1345,136]

theorem envBound9413 : H12AffineFastState.Bounded env9413 := by
  intro p hp
  have h : env9413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9412_9413 : H12AffineEnvironment.transform 11 1044 env9412 = env9413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env9412 == env9413) = true)

theorem identity9413 : scanCanonicalize (H12AffineFastState.compose env9413 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9413 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9414 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1044,2056,1092,32768,32906,1092,32800,524288,32768,1045,0,65,138,2177,17,32800,1093,1044,2049,1025,4294967296,5,4295492640,1092,136]

theorem envBound9414 : H12AffineFastState.Bounded env9414 := by
  intro p hp
  have h : env9414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9413_9414 : H12AffineEnvironment.transform 7 5 env9413 = env9414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9413 == env9414) = true)

theorem identity9414 : scanCanonicalize (H12AffineFastState.compose env9414 (packedSelected [3,10] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound9414 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env9415 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1044,2056,1092,2081,2219,1092,2049,524288,2081,1045,0,65,138,2177,17,2049,1093,1044,2049,1025,4294967296,5,4295492640,1092,136]

theorem envBound9415 : H12AffineFastState.Bounded env9415 := by
  intro p hp
  have h : env9415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9414_9415 : H12AffineEnvironment.transform 14 2081 env9414 = env9415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env9414 == env9415) = true)

def env9416 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2056,1092,2049,2187,1092,2049,524288,2049,1045,0,65,138,2177,17,2049,1093,1044,2049,1025,4294967296,5,4295492608,1092,136]

theorem envBound9416 : H12AffineFastState.Bounded env9416 := by
  intro p hp
  have h : env9416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9415_9416 : H12AffineEnvironment.transform 4 0 env9415 = env9416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9415 == env9416) = true)

theorem identity9416 : scanCanonicalize (H12AffineFastState.compose env9416 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3167) := by decide +kernel

theorem selectedBound9416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9417 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2056,1092,2049,2187,1092,2049,524288,2049,1045,0,65,138,2177,17,2049,1093,1044,2049,1025,3167,5,526431,1092,136]

theorem envBound9417 : H12AffineFastState.Bounded env9417 := by
  intro p hp
  have h : env9417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9416_9417 : H12AffineEnvironment.transform 31 3167 env9416 = env9417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3167 env9416 == env9417) = true)

theorem identity9417 : scanCanonicalize (H12AffineFastState.compose env9417 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1159) := by decide +kernel

theorem selectedBound9417 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9418 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1159,1044,1167,1092,1158,1036,1092,1158,524288,1158,1045,0,65,138,1030,17,1158,1093,1044,1158,1025,216,5,525528,1092,136]

theorem envBound9418 : H12AffineFastState.Bounded env9418 := by
  intro p hp
  have h : env9418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9417_9418 : H12AffineEnvironment.transform 10 1159 env9417 = env9418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1159 env9417 == env9418) = true)

theorem identity9418 : scanCanonicalize (H12AffineFastState.compose env9418 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9418 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9419 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1039,1044,1031,1092,1038,1036,1092,1038,524288,1038,1045,0,65,2,1030,17,1038,1093,1044,1038,1025,80,5,525392,1092,0]

theorem envBound9419 : H12AffineFastState.Bounded env9419 := by
  intro p hp
  have h : env9419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9418_9419 : H12AffineEnvironment.transform 6 8 env9418 = env9419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9418 == env9419) = true)

def leafEnv9419 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1039,1044,1031,1092,1038,1036,1092,1038,524288,1038,1045,0,65,2,524288,1030,1,17,1038,1093,1044,1038,1025,80,5,525392,5,1037,1092,0,0,1044,1]

def active9419 : List Nat := [0,1,2,3,5,9,18]

def tree9419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9419 : H12WitnessSearch.Good tree9419 := H12GlobalWitnessIndex.good

theorem leafIdentity9419 : H12AffineFastState.composeSystem env9419 rootObs = leafEnv9419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9419 rootObs == leafEnv9419) = true)

theorem terminalChecked9419 : H12PackedTerminal.terminalCheckFast leafEnv9419 active9419 tree9419 = true := by decide +kernel

def env9420 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2056,1092,2048,2186,1092,2049,524288,2048,1045,0,65,138,2177,17,2049,1093,1044,2049,1025,4294967296,5,4295492609,1092,136]

theorem envBound9420 : H12AffineFastState.Bounded env9420 := by
  intro p hp
  have h : env9420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9415_9420 : H12AffineEnvironment.transform 4 1 env9415 = env9420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9415 == env9420) = true)

theorem identity9420 : scanCanonicalize (H12AffineFastState.compose env9420 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3286) := by decide +kernel

theorem selectedBound9420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9421 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2056,1092,2048,2186,1092,2049,524288,2048,1045,0,65,138,2177,17,2049,1093,1044,2049,1025,3286,5,526551,1092,136]

theorem envBound9421 : H12AffineFastState.Bounded env9421 := by
  intro p hp
  have h : env9421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9420_9421 : H12AffineEnvironment.transform 31 3286 env9420 = env9421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3286 env9420 == env9421) = true)

theorem identity9421 : scanCanonicalize (H12AffineFastState.compose env9421 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound9421 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9422 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1039,1044,1031,1092,1039,1157,1092,1038,524288,1039,1045,0,65,138,1166,17,1038,1093,1044,1038,1025,217,5,525528,1092,136]

theorem envBound9422 : H12AffineFastState.Bounded env9422 := by
  intro p hp
  have h : env9422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9421_9422 : H12AffineEnvironment.transform 10 1039 env9421 = env9422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env9421 == env9422) = true)

theorem identity9422 : scanCanonicalize (H12AffineFastState.compose env9422 (packedSelected [1] rootPS)) = affineNative (2^(18+1) ^^^ 1104) := by decide +kernel

theorem selectedBound9422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9423 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1039,1044,1031,1092,1039,1157,1092,1038,1104,1039,1045,0,65,138,1166,17,1038,1093,1044,1038,1025,217,5,136,1092,136]

theorem envBound9423 : H12AffineFastState.Bounded env9423 := by
  intro p hp
  have h : env9423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9422_9423 : H12AffineEnvironment.transform 18 1104 env9422 = env9423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env9422 == env9423) = true)

theorem identity9423 : scanCanonicalize (H12AffineFastState.compose env9423 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9423 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env9424 : List Nat := [2,4,8,16,1,17,128,5,137,1024,1039,1044,1031,1045,1039,1157,1045,1038,1025,1039,1045,0,16,138,1166,17,1038,1044,1044,1038,1025,136,5,136,1045,136]

theorem envBound9424 : H12AffineFastState.Bounded env9424 := by
  intro p hp
  have h : env9424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9423_9424 : H12AffineEnvironment.transform 5 17 env9423 = env9424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9423 == env9424) = true)

def leafEnv9424 : List Nat := [2,4,8,16,1,17,128,5,137,1024,1039,1044,1031,1045,1039,1157,1045,1038,1025,1039,1045,0,16,138,1025,1166,1,17,1038,1044,1044,1038,1025,136,5,136,5,1036,1045,136,0,1044,1]

def active9424 : List Nat := [0,1,2,3,6,9]

def tree9424 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9424 : H12WitnessSearch.Good tree9424 := H12GlobalWitnessIndex.good

theorem leafIdentity9424 : H12AffineFastState.composeSystem env9424 rootObs = leafEnv9424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9424 rootObs == leafEnv9424) = true)

theorem terminalChecked9424 : H12PackedTerminal.terminalCheckFast leafEnv9424 active9424 tree9424 = true := by decide +kernel

def env9425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,43681,524288,32768,4097,10249,6105,98565,8329,5376,33060,4824,1297,9092,1284,4294967296,256,4295601967,1345,513]

theorem envBound9425 : H12AffineFastState.Bounded env9425 := by
  intro p hp
  have h : env9425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9405_9425 : H12AffineEnvironment.transform 21 10249 env9405 = env9425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env9405 == env9425) = true)

theorem identity9425 : scanCanonicalize (H12AffineFastState.compose env9425 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound9425 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,8232,65536,1345,2697,524288,8232,4097,10249,6105,74029,8329,5376,8460,4824,1297,9092,1284,4294967296,256,4295560967,1345,513]

theorem envBound9426 : H12AffineFastState.Bounded env9426 := by
  intro p hp
  have h : env9426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9425_9426 : H12AffineEnvironment.transform 14 8232 env9425 = env9426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env9425 == env9426) = true)

def env9427 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4177,8232,65536,1345,2049,524288,8232,4097,10249,5457,74029,8329,5376,8460,4176,1297,8460,1284,4294967296,256,4295560591,1345,137]

theorem envBound9427 : H12AffineFastState.Bounded env9427 := by
  intro p hp
  have h : env9427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9426_9427 : H12AffineEnvironment.transform 8 136 env9426 = env9427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9426 == env9427) = true)

theorem identity9427 : scanCanonicalize (H12AffineFastState.compose env9427 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 75174) := by decide +kernel

theorem selectedBound9427 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9428 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4177,8232,65536,1345,2049,75174,8232,4097,10249,5457,74029,8329,5376,8460,4176,1297,8460,1284,4294967296,256,4294977577,1345,137]

theorem envBound9428 : H12AffineFastState.Bounded env9428 := by
  intro p hp
  have h : env9428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9427_9428 : H12AffineEnvironment.transform 18 75174 env9427 = env9428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75174 env9427 == env9428) = true)

theorem identity9428 : scanCanonicalize (H12AffineFastState.compose env9428 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound9428 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9429 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,7196,4177,7220,65536,1345,2049,72122,7220,4097,5141,5457,73009,7317,5376,7440,4176,1297,7440,1284,4294967296,256,4294972469,1345,137]

theorem envBound9429 : H12AffineFastState.Bounded env9429 := by
  intro p hp
  have h : env9429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9428_9429 : H12AffineEnvironment.transform 12 7196 env9428 = env9429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env9428 == env9429) = true)

def env9430 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,8232,65536,1345,2048,524288,8232,4097,10249,5456,74029,8329,5376,8460,4177,1297,8461,1284,4294967296,256,4295560590,1345,136]

theorem envBound9430 : H12AffineFastState.Bounded env9430 := by
  intro p hp
  have h : env9430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9426_9430 : H12AffineEnvironment.transform 8 137 env9426 = env9430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9426 == env9430) = true)

theorem identity9430 : scanCanonicalize (H12AffineFastState.compose env9430 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound9430 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9431 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,8232,8615,1345,2048,524288,8232,4097,10249,5456,138,8329,5376,8460,4177,1297,8461,1284,4294967296,256,4295502889,1345,136]

theorem envBound9431 : H12AffineFastState.Bounded env9431 := by
  intro p hp
  have h : env9431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9430_9431 : H12AffineEnvironment.transform 15 8615 env9430 = env9431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env9430 == env9431) = true)

theorem identity9431 : scanCanonicalize (H12AffineFastState.compose env9431 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound9431 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9432 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1045,8192,1093,8232,8615,1345,2048,524288,8232,1044,10249,325,138,8329,277,8460,1092,1297,8461,1284,4294967296,256,4295502889,1345,136]

theorem envBound9432 : H12AffineFastState.Bounded env9432 := by
  intro p hp
  have h : env9432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9431_9432 : H12AffineEnvironment.transform 11 1045 env9431 = env9432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env9431 == env9432) = true)

theorem identity9432 : scanCanonicalize (H12AffineFastState.compose env9432 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9432 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env9433 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,8192,1093,8232,8354,1092,2048,524288,8232,1044,10249,64,138,8329,16,8201,1092,1044,8200,1025,4294967296,5,4295502889,1092,136]

theorem envBound9433 : H12AffineFastState.Bounded env9433 := by
  intro p hp
  have h : env9433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9432_9433 : H12AffineEnvironment.transform 7 5 env9432 = env9433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9432 == env9433) = true)

theorem identity9433 : scanCanonicalize (H12AffineFastState.compose env9433 (packedSelected [1,3,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound9433 : packedSelected [1,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9434 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,2057,1093,2081,2219,1092,2048,524288,2081,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,4294967296,5,4295492640,1092,136]

theorem envBound9434 : H12AffineFastState.Bounded env9434 := by
  intro p hp
  have h : env9434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9433_9434 : H12AffineEnvironment.transform 12 2057 env9433 = env9434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env9433 == env9434) = true)

def env9435 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2057,1093,2049,2187,1092,2048,524288,2049,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,4294967296,5,4295492608,1092,136]

theorem envBound9435 : H12AffineFastState.Bounded env9435 := by
  intro p hp
  have h : env9435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9434_9435 : H12AffineEnvironment.transform 4 0 env9434 = env9435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9434 == env9435) = true)

theorem identity9435 : scanCanonicalize (H12AffineFastState.compose env9435 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3287) := by decide +kernel

theorem selectedBound9435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9436 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2057,1093,2049,2187,1092,2048,524288,2049,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,3287,5,526551,1092,136]

theorem envBound9436 : H12AffineFastState.Bounded env9436 := by
  intro p hp
  have h : env9436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9435_9436 : H12AffineEnvironment.transform 31 3287 env9435 = env9436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3287 env9435 == env9436) = true)

theorem identity9436 : scanCanonicalize (H12AffineFastState.compose env9436 (packedSelected [1,2,5] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9436 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env9437 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2057,1093,2049,2187,1092,2048,1025,2049,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,3287,5,3286,1092,136]

theorem envBound9437 : H12AffineFastState.Bounded env9437 := by
  intro p hp
  have h : env9437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9436_9437 : H12AffineEnvironment.transform 18 1025 env9436 = env9437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9436 == env9437) = true)

theorem identity9437 : scanCanonicalize (H12AffineFastState.compose env9437 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1238) := by decide +kernel

theorem selectedBound9437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9438 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1238,1045,1247,1093,1239,1117,1092,1238,1025,1239,1044,0,64,138,1110,16,1238,1092,1044,1239,1025,1,5,0,1092,136]

theorem envBound9438 : H12AffineFastState.Bounded env9438 := by
  intro p hp
  have h : env9438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9437_9438 : H12AffineEnvironment.transform 10 1238 env9437 = env9438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1238 env9437 == env9438) = true)

theorem identity9438 : scanCanonicalize (H12AffineFastState.compose env9438 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9439 : List Nat := [2,4,8,16,0,64,88,5,81,1024,1038,1045,1031,1093,1039,1117,1092,1038,1025,1039,1044,0,64,82,1110,16,1038,1092,1044,1039,1025,1,5,0,1092,80]

theorem envBound9439 : H12AffineFastState.Bounded env9439 := by
  intro p hp
  have h : env9439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9438_9439 : H12AffineEnvironment.transform 6 88 env9438 = env9439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9438 == env9439) = true)

def leafEnv9439 : List Nat := [2,4,8,16,0,64,88,5,81,1024,1038,1045,1031,1093,1039,1117,1092,1038,1025,1039,1044,0,64,82,1025,1110,1,16,1038,1092,1044,1039,1025,1,5,0,5,1036,1092,80,0,1044,1]

def active9439 : List Nat := [0,1,2,3,5,9]

def tree9439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9439 : H12WitnessSearch.Good tree9439 := H12GlobalWitnessIndex.good

theorem leafIdentity9439 : H12AffineFastState.composeSystem env9439 rootObs = leafEnv9439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9439 rootObs == leafEnv9439) = true)

theorem terminalChecked9439 : H12PackedTerminal.terminalCheckFast leafEnv9439 active9439 tree9439 = true := by decide +kernel

def env9440 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2057,1093,2048,2186,1092,2048,524288,2048,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,4294967296,5,4295492609,1092,136]

theorem envBound9440 : H12AffineFastState.Bounded env9440 := by
  intro p hp
  have h : env9440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9434_9440 : H12AffineEnvironment.transform 4 1 env9434 = env9440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9434 == env9440) = true)

theorem identity9440 : scanCanonicalize (H12AffineFastState.compose env9440 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3166) := by decide +kernel

theorem selectedBound9440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9441 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2057,1093,2048,2186,1092,2048,524288,2048,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,3166,5,526431,1092,136]

theorem envBound9441 : H12AffineFastState.Bounded env9441 := by
  intro p hp
  have h : env9441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9440_9441 : H12AffineEnvironment.transform 31 3166 env9440 = env9441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3166 env9440 == env9441) = true)

def env9442 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2057,1093,2048,2186,1092,2048,1024,2048,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,3166,5,3167,1092,136]

theorem envBound9442 : H12AffineFastState.Bounded env9442 := by
  intro p hp
  have h : env9442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9441_9442 : H12AffineEnvironment.transform 18 1024 env9441 = env9442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9441 == env9442) = true)

theorem identity9442 : scanCanonicalize (H12AffineFastState.compose env9442 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9443 : List Nat := [2,4,8,16,1,64,8,5,1,1024,2048,1045,2057,1093,2048,2050,1092,2048,1024,2048,1044,0,64,2,2056,16,2048,1092,1044,2049,1025,3166,5,3167,1092,0]

theorem envBound9443 : H12AffineFastState.Bounded env9443 := by
  intro p hp
  have h : env9443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9442_9443 : H12AffineEnvironment.transform 6 8 env9442 = env9443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9442 == env9443) = true)

theorem identity9443 : scanCanonicalize (H12AffineFastState.compose env9443 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound9443 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9444 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1038,1045,1031,1093,1038,1036,1092,1038,1024,1038,1044,0,64,2,1030,16,1038,1092,1044,1039,1025,80,5,81,1092,0]

theorem envBound9444 : H12AffineFastState.Bounded env9444 := by
  intro p hp
  have h : env9444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9443_9444 : H12AffineEnvironment.transform 10 1038 env9443 = env9444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env9443 == env9444) = true)

def leafEnv9444 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1038,1045,1031,1093,1038,1036,1092,1038,1024,1038,1044,0,64,2,1024,1030,1,16,1038,1092,1044,1039,1025,80,5,81,5,1037,1092,0,0,1044,1]

def active9444 : List Nat := [0,1,2,3,5,9]

def tree9444 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9444 : H12WitnessSearch.Good tree9444 := H12GlobalWitnessIndex.good

theorem leafIdentity9444 : H12AffineFastState.composeSystem env9444 rootObs = leafEnv9444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9444 rootObs == leafEnv9444) = true)

theorem terminalChecked9444 : H12PackedTerminal.terminalCheckFast leafEnv9444 active9444 tree9444 = true := by decide +kernel

def env9445 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2057,1093,2048,2186,1092,2048,1025,2048,1044,0,64,138,2176,16,2048,1092,1044,2049,1025,3166,5,3166,1092,136]

theorem envBound9445 : H12AffineFastState.Bounded env9445 := by
  intro p hp
  have h : env9445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9441_9445 : H12AffineEnvironment.transform 18 1025 env9441 = env9445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9441 == env9445) = true)

theorem identity9445 : scanCanonicalize (H12AffineFastState.compose env9445 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1158) := by decide +kernel

theorem selectedBound9445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9446 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1158,1045,1167,1093,1158,1036,1092,1158,1025,1158,1044,0,64,138,1030,16,1158,1092,1044,1159,1025,216,5,216,1092,136]

theorem envBound9446 : H12AffineFastState.Bounded env9446 := by
  intro p hp
  have h : env9446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9445_9446 : H12AffineEnvironment.transform 10 1158 env9445 = env9446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1158 env9445 == env9446) = true)

def leafEnv9446 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1158,1045,1167,1093,1158,1036,1092,1158,1025,1158,1044,0,64,138,1025,1030,1,16,1158,1092,1044,1159,1025,216,5,216,5,1157,1092,136,0,1044,1]

def active9446 : List Nat := [0,1,2,3,5,6,9]

def tree9446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9446 : H12WitnessSearch.Good tree9446 := H12GlobalWitnessIndex.good

theorem leafIdentity9446 : H12AffineFastState.composeSystem env9446 rootObs = leafEnv9446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9446 rootObs == leafEnv9446) = true)

theorem terminalChecked9446 : H12PackedTerminal.terminalCheckFast leafEnv9446 active9446 tree9446 = true := by decide +kernel

def env9447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,889442641,4294967296,872567888,4417151346,34359738368,33563272]

theorem envBound9447 : H12AffineFastState.Bounded env9447 := by
  intro p hp
  have h : env9447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6393_9447 : H12AffineEnvironment.transform 22 17665 env6393 = env9447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env6393 == env9447) = true)

def env9448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,536870912,1073741824,553878609,4294967296,537002320,4417151346,34359738368,33563272]

theorem envBound9448 : H12AffineFastState.Bounded env9448 := by
  intro p hp
  have h : env9448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9447_9448 : H12AffineEnvironment.transform 27 67130624 env9447 = env9448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 67130624 env9447 == env9448) = true)

def env9449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,536870912,1073741824,553878609,4294967296,537002320,4417151346,694534144,33563272]

theorem envBound9449 : H12AffineFastState.Bounded env9449 := by
  intro p hp
  have h : env9449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9448_9449 : H12AffineEnvironment.transform 34 694534144 env9448 = env9449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534144 env9448 == env9449) = true)

def env9450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,157794304,1073741824,140788817,4294967296,157663568,4417151346,131072,33563272]

theorem envBound9450 : H12AffineFastState.Bounded env9450 := by
  intro p hp
  have h : env9450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9449_9450 : H12AffineEnvironment.transform 28 157794304 env9449 = env9450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env9449 == env9450) = true)

theorem identity9450 : scanCanonicalize (H12AffineFastState.compose env9450 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 135233) := by decide +kernel

theorem selectedBound9450 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,135233,134217728,148801,157794304,1073741824,140788817,4294967296,157663568,4350177587,131072,33563272]

theorem envBound9451 : H12AffineFastState.Bounded env9451 := by
  intro p hp
  have h : env9451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9450_9451 : H12AffineEnvironment.transform 25 135233 env9450 = env9451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 135233 env9450 == env9451) = true)

def env9452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,135233,23445584,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound9452 : H12AffineFastState.Bounded env9452 := by
  intro p hp
  have h : env9452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9451_9452 : H12AffineEnvironment.transform 26 23445584 env9451 = env9452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env9451 == env9452) = true)

def env9453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,135233,21352528,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound9453 : H12AffineFastState.Bounded env9453 := by
  intro p hp
  have h : env9453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9452_9453 : H12AffineEnvironment.transform 20 4096 env9452 = env9453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9452 == env9453) = true)

theorem identity9453 : scanCanonicalize (H12AffineFastState.compose env9453 (packedSelected [35] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9453 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17665,16777216,33554432,5377,21352528,16385,1296,1073741824,16876545,4294967296,256,4350047347,1344,33563272]

theorem envBound9454 : H12AffineFastState.Bounded env9454 := by
  intro p hp
  have h : env9454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9453_9454 : H12AffineEnvironment.transform 16 1344 env9453 = env9454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9453 == env9454) = true)

theorem identity9454 : scanCanonicalize (H12AffineFastState.compose env9454 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9454 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env9455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17665,16777216,8329,5377,21352528,16385,1296,1073741824,16876545,4294967296,256,4316484858,1344,513]

theorem envBound9455 : H12AffineFastState.Bounded env9455 := by
  intro p hp
  have h : env9455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9454_9455 : H12AffineEnvironment.transform 24 8329 env9454 = env9455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9454 == env9455) = true)

theorem identity9455 : scanCanonicalize (H12AffineFastState.compose env9455 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9455 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17665,98565,8329,5377,4477269,16385,1296,1073741824,1284,4294967296,256,4299806207,1344,513]

theorem envBound9456 : H12AffineFastState.Bounded env9456 := by
  intro p hp
  have h : env9456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9455_9456 : H12AffineEnvironment.transform 23 98565 env9455 = env9456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9455 == env9456) = true)

theorem identity9456 : scanCanonicalize (H12AffineFastState.compose env9456 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound9456 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1344,262144,524288,32768,4096,4194304,6104,98565,8329,5377,4457356,4824,1296,1073741824,1284,4294967296,256,4299786022,1344,513]

theorem envBound9457 : H12AffineFastState.Bounded env9457 := by
  intro p hp
  have h : env9457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9456_9457 : H12AffineEnvironment.transform 13 4825 env9456 = env9457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env9456 == env9457) = true)

theorem identity9457 : scanCanonicalize (H12AffineFastState.compose env9457 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 4197261) := by decide +kernel

theorem selectedBound9457 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1344,262144,524288,32768,4096,4194304,6104,98565,8329,5377,4457356,4824,1296,4197261,1284,4294967296,256,4299786022,1344,513]

theorem envBound9458 : H12AffineFastState.Bounded env9458 := by
  intro p hp
  have h : env9458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9457_9458 : H12AffineEnvironment.transform 29 4197261 env9457 = env9458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197261 env9457 == env9458) = true)

theorem identity9458 : scanCanonicalize (H12AffineFastState.compose env9458 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound9458 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env9459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1344,43681,524288,32768,4096,4194304,6104,98565,8329,5377,4237613,4824,1296,4197261,1284,4294967296,256,4299786022,1344,513]

theorem envBound9459 : H12AffineFastState.Bounded env9459 := by
  intro p hp
  have h : env9459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9458_9459 : H12AffineEnvironment.transform 17 43681 env9458 = env9459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env9458 == env9459) = true)

def env9460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1344,43681,524288,32768,4096,10248,6104,98565,8329,5377,33061,4824,1296,9093,1284,4294967296,256,4295601966,1344,513]

theorem envBound9460 : H12AffineFastState.Bounded env9460 := by
  intro p hp
  have h : env9460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9459_9460 : H12AffineEnvironment.transform 21 10248 env9459 = env9460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env9459 == env9460) = true)

theorem identity9460 : scanCanonicalize (H12AffineFastState.compose env9460 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound9460 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7828,4825,32768,65536,1344,37941,524288,32768,4096,5788,6104,98565,7709,5377,33061,4824,1296,7441,1284,4294967296,256,4295594426,1344,513]

theorem envBound9461 : H12AffineFastState.Bounded env9461 := by
  intro p hp
  have h : env9461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9460_9461 : H12AffineEnvironment.transform 12 7828 env9460 = env9461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env9460 == env9461) = true)

def env9462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2948,1993,32768,65536,1344,33061,524288,32768,1296,908,712,98565,2829,17,33061,1992,1296,2049,1284,4294967296,256,4295591082,1344,513]

theorem envBound9462 : H12AffineFastState.Bounded env9462 := by
  intro p hp
  have h : env9462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9461_9462 : H12AffineEnvironment.transform 11 1296 env9461 = env9462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9461 == env9462) = true)

theorem identity9462 : scanCanonicalize (H12AffineFastState.compose env9462 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9462 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9463 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,2316,1345,32768,65536,1344,33061,524288,32768,1296,260,64,98565,2437,17,33061,1344,1296,2049,1284,4294967296,256,4295591082,1344,137]

theorem envBound9463 : H12AffineFastState.Bounded env9463 := by
  intro p hp
  have h : env9463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9462_9463 : H12AffineEnvironment.transform 8 136 env9462 = env9463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9462 == env9463) = true)

theorem identity9463 : scanCanonicalize (H12AffineFastState.compose env9463 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 99726) := by decide +kernel

theorem selectedBound9463 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9464 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,2316,1345,32768,65536,1344,33061,99726,32768,1296,260,64,98565,2437,17,33061,1344,1296,2049,1284,4294967296,256,4294967588,1344,137]

theorem envBound9464 : H12AffineFastState.Bounded env9464 := by
  intro p hp
  have h : env9464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9463_9464 : H12AffineEnvironment.transform 18 99726 env9463 = env9464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99726 env9463 == env9464) = true)

def env9465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2949,1992,32768,65536,1344,33060,524288,32768,1297,909,713,98565,2828,16,33061,1993,1296,2048,1284,4294967296,256,4295591083,1344,513]

theorem envBound9465 : H12AffineFastState.Bounded env9465 := by
  intro p hp
  have h : env9465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9461_9465 : H12AffineEnvironment.transform 11 1297 env9461 = env9465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9461 == env9465) = true)

theorem identity9465 : scanCanonicalize (H12AffineFastState.compose env9465 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 2988) := by decide +kernel

theorem selectedBound9465 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2949,1992,2988,65536,1344,2696,524288,2988,1297,909,713,68265,2828,16,2697,1993,1296,2048,1284,4294967296,256,4295560967,1344,513]

theorem envBound9466 : H12AffineFastState.Bounded env9466 := by
  intro p hp
  have h : env9466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9465_9466 : H12AffineEnvironment.transform 14 2988 env9465 = env9466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2988 env9465 == env9466) = true)

theorem identity9466 : scanCanonicalize (H12AffineFastState.compose env9466 (packedSelected [0,2,3,4,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound9466 : packedSelected [0,2,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2949,1992,2988,2218,1344,2696,524288,2988,1297,909,713,515,2828,16,2697,1993,1296,2048,1284,4294967296,256,4295493549,1344,513]

theorem envBound9467 : H12AffineFastState.Bounded env9467 := by
  intro p hp
  have h : env9467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9466_9467 : H12AffineEnvironment.transform 15 2218 env9466 = env9467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env9466 == env9467) = true)

theorem identity9467 : scanCanonicalize (H12AffineFastState.compose env9467 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9467 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9468 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2316,1345,2341,2218,1344,2049,524288,2341,1297,260,64,138,2437,16,2048,1344,1296,2048,1284,4294967296,256,4295492900,1344,136]

theorem envBound9468 : H12AffineFastState.Bounded env9468 := by
  intro p hp
  have h : env9468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9467_9468 : H12AffineEnvironment.transform 8 137 env9467 = env9468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9467 == env9468) = true)

theorem identity9468 : scanCanonicalize (H12AffineFastState.compose env9468 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9468 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9469 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1044,2057,1092,2080,2218,1093,2049,524288,2080,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,4294967296,5,4295492641,1093,136]

theorem envBound9469 : H12AffineFastState.Bounded env9469 := by
  intro p hp
  have h : env9469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9468_9469 : H12AffineEnvironment.transform 7 5 env9468 = env9469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9468 == env9469) = true)

def env9470 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1092,2048,2186,1093,2049,524288,2048,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,4294967296,5,4295492609,1093,136]

theorem envBound9470 : H12AffineFastState.Bounded env9470 := by
  intro p hp
  have h : env9470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9469_9470 : H12AffineEnvironment.transform 4 0 env9469 = env9470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9469 == env9470) = true)

theorem identity9470 : scanCanonicalize (H12AffineFastState.compose env9470 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3167) := by decide +kernel

theorem selectedBound9470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9471 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1092,2048,2186,1093,2049,524288,2048,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,3167,5,526430,1093,136]

theorem envBound9471 : H12AffineFastState.Bounded env9471 := by
  intro p hp
  have h : env9471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9470_9471 : H12AffineEnvironment.transform 31 3167 env9470 = env9471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3167 env9470 == env9471) = true)

def env9472 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1092,2048,2186,1093,2049,1024,2048,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,3167,5,3166,1093,136]

theorem envBound9472 : H12AffineFastState.Bounded env9472 := by
  intro p hp
  have h : env9472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9471_9472 : H12AffineEnvironment.transform 18 1024 env9471 = env9472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9471 == env9472) = true)

theorem identity9472 : scanCanonicalize (H12AffineFastState.compose env9472 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9473 : List Nat := [2,4,8,16,0,64,8,5,1,1024,2048,1044,2057,1092,2048,2050,1093,2049,1024,2048,1044,1,64,2,2056,16,2048,1093,1045,2048,1025,3167,5,3166,1093,0]

theorem envBound9473 : H12AffineFastState.Bounded env9473 := by
  intro p hp
  have h : env9473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9472_9473 : H12AffineEnvironment.transform 6 8 env9472 = env9473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9472 == env9473) = true)

theorem identity9473 : scanCanonicalize (H12AffineFastState.compose env9473 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound9473 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9474 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1038,1044,1031,1092,1038,1036,1093,1039,1024,1038,1044,1,64,2,1030,16,1038,1093,1045,1038,1025,81,5,80,1093,0]

theorem envBound9474 : H12AffineFastState.Bounded env9474 := by
  intro p hp
  have h : env9474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9473_9474 : H12AffineEnvironment.transform 10 1038 env9473 = env9474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env9473 == env9474) = true)

def leafEnv9474 : List Nat := [2,4,8,16,0,64,8,5,1,1024,1038,1044,1031,1092,1038,1036,1093,1039,1024,1038,1044,1,64,2,1024,1030,1,16,1038,1093,1045,1038,1025,81,5,80,5,1037,1093,0,0,1044,1]

def active9474 : List Nat := [0,1,2,3,5,9]

def tree9474 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9474 : H12WitnessSearch.Good tree9474 := H12GlobalWitnessIndex.good

theorem leafIdentity9474 : H12AffineFastState.composeSystem env9474 rootObs = leafEnv9474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9474 rootObs == leafEnv9474) = true)

theorem terminalChecked9474 : H12PackedTerminal.terminalCheckFast leafEnv9474 active9474 tree9474 = true := by decide +kernel

def env9475 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1092,2048,2186,1093,2049,1025,2048,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,3167,5,3167,1093,136]

theorem envBound9475 : H12AffineFastState.Bounded env9475 := by
  intro p hp
  have h : env9475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9471_9475 : H12AffineEnvironment.transform 18 1025 env9471 = env9475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9471 == env9475) = true)

theorem identity9475 : scanCanonicalize (H12AffineFastState.compose env9475 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1158) := by decide +kernel

theorem selectedBound9475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9476 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1158,1044,1167,1092,1158,1036,1093,1159,1025,1158,1044,1,64,138,1030,16,1158,1093,1045,1158,1025,217,5,217,1093,136]

theorem envBound9476 : H12AffineFastState.Bounded env9476 := by
  intro p hp
  have h : env9476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9475_9476 : H12AffineEnvironment.transform 10 1158 env9475 = env9476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1158 env9475 == env9476) = true)

def leafEnv9476 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1158,1044,1167,1092,1158,1036,1093,1159,1025,1158,1044,1,64,138,1025,1030,1,16,1158,1093,1045,1158,1025,217,5,217,5,1157,1093,136,0,1044,1]

def active9476 : List Nat := [0,1,2,3,5,6,9]

def tree9476 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9476 : H12WitnessSearch.Good tree9476 := H12GlobalWitnessIndex.good

theorem leafIdentity9476 : H12AffineFastState.composeSystem env9476 rootObs = leafEnv9476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9476 rootObs == leafEnv9476) = true)

theorem terminalChecked9476 : H12PackedTerminal.terminalCheckFast leafEnv9476 active9476 tree9476 = true := by decide +kernel

def env9477 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2057,1092,2049,2187,1093,2049,524288,2049,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,4294967296,5,4295492608,1093,136]

theorem envBound9477 : H12AffineFastState.Bounded env9477 := by
  intro p hp
  have h : env9477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9469_9477 : H12AffineEnvironment.transform 4 1 env9469 = env9477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9469 == env9477) = true)

theorem identity9477 : scanCanonicalize (H12AffineFastState.compose env9477 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3287) := by decide +kernel

theorem selectedBound9477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9478 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2057,1092,2049,2187,1093,2049,524288,2049,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,3287,5,526551,1093,136]

theorem envBound9478 : H12AffineFastState.Bounded env9478 := by
  intro p hp
  have h : env9478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9477_9478 : H12AffineEnvironment.transform 31 3287 env9477 = env9478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3287 env9477 == env9478) = true)

theorem identity9478 : scanCanonicalize (H12AffineFastState.compose env9478 (packedSelected [2,3] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9478 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9479 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1044,2057,1092,2049,2187,1093,2049,1025,2049,1044,1,64,138,2176,16,2048,1093,1045,2048,1025,3287,5,3286,1093,136]

theorem envBound9479 : H12AffineFastState.Bounded env9479 := by
  intro p hp
  have h : env9479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9478_9479 : H12AffineEnvironment.transform 18 1025 env9478 = env9479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9478 == env9479) = true)

theorem identity9479 : scanCanonicalize (H12AffineFastState.compose env9479 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1238) := by decide +kernel

theorem selectedBound9479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9480 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1238,1044,1247,1092,1239,1117,1093,1239,1025,1239,1044,1,64,138,1110,16,1238,1093,1045,1238,1025,1,5,0,1093,136]

theorem envBound9480 : H12AffineFastState.Bounded env9480 := by
  intro p hp
  have h : env9480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9479_9480 : H12AffineEnvironment.transform 10 1238 env9479 = env9480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1238 env9479 == env9480) = true)

theorem identity9480 : scanCanonicalize (H12AffineFastState.compose env9480 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound9480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9481 : List Nat := [2,4,8,16,1,64,89,5,80,1024,1039,1044,1030,1092,1038,1117,1093,1038,1025,1038,1044,1,64,83,1110,16,1039,1093,1045,1039,1025,1,5,0,1093,81]

theorem envBound9481 : H12AffineFastState.Bounded env9481 := by
  intro p hp
  have h : env9481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9480_9481 : H12AffineEnvironment.transform 6 89 env9480 = env9481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env9480 == env9481) = true)

def leafEnv9481 : List Nat := [2,4,8,16,1,64,89,5,80,1024,1039,1044,1030,1092,1038,1117,1093,1038,1025,1038,1044,1,64,83,1025,1110,1,16,1039,1093,1045,1039,1025,1,5,0,5,1037,1093,81,0,1044,1]

def active9481 : List Nat := [0,1,2,3,5,9]

def tree9481 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9481 : H12WitnessSearch.Good tree9481 := H12GlobalWitnessIndex.good

theorem leafIdentity9481 : H12AffineFastState.composeSystem env9481 rootObs = leafEnv9481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9481 rootObs == leafEnv9481) = true)

theorem terminalChecked9481 : H12PackedTerminal.terminalCheckFast leafEnv9481 active9481 tree9481 = true := by decide +kernel

def env9482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1344,43681,524288,32768,4096,10249,6104,98565,8329,5377,33060,4824,1296,9092,1284,4294967296,256,4295601967,1344,513]

theorem envBound9482 : H12AffineFastState.Bounded env9482 := by
  intro p hp
  have h : env9482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9459_9482 : H12AffineEnvironment.transform 21 10249 env9459 = env9482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env9459 == env9482) = true)

theorem identity9482 : scanCanonicalize (H12AffineFastState.compose env9482 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 14257) := by decide +kernel

theorem selectedBound9482 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,14257,65536,1344,7440,524288,14257,4096,10249,6104,79540,8329,5377,13973,4824,1296,9092,1284,4294967296,256,4295563422,1344,513]

theorem envBound9483 : H12AffineFastState.Bounded env9483 := by
  intro p hp
  have h : env9483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9482_9483 : H12AffineEnvironment.transform 14 14257 env9482 = env9483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14257 env9482 == env9483) = true)

def env9484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1993,8865,65536,1344,2048,524288,8865,1296,10249,712,74660,8329,17,9093,1992,1296,9092,1284,4294967296,256,4295560590,1344,513]

theorem envBound9484 : H12AffineFastState.Bounded env9484 := by
  intro p hp
  have h : env9484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9483_9484 : H12AffineEnvironment.transform 11 1296 env9483 = env9484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9483 == env9484) = true)

theorem identity9484 : scanCanonicalize (H12AffineFastState.compose env9484 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9484 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9485 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,8232,65536,1344,2048,524288,8232,1296,10249,65,74029,8329,17,8460,1345,1296,8461,1284,4294967296,256,4295560590,1344,136]

theorem envBound9485 : H12AffineFastState.Bounded env9485 := by
  intro p hp
  have h : env9485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9484_9485 : H12AffineEnvironment.transform 8 137 env9484 = env9485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9484 == env9485) = true)

theorem identity9485 : scanCanonicalize (H12AffineFastState.compose env9485 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound9485 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9486 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,8232,8615,1344,2048,524288,8232,1296,10249,65,138,8329,17,8460,1345,1296,8461,1284,4294967296,256,4295502889,1344,136]

theorem envBound9486 : H12AffineFastState.Bounded env9486 := by
  intro p hp
  have h : env9486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9485_9486 : H12AffineEnvironment.transform 15 8615 env9485 = env9486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env9485 == env9486) = true)

theorem identity9486 : scanCanonicalize (H12AffineFastState.compose env9486 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9486 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9487 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,8192,1093,8232,8354,1093,2048,524288,8232,1045,10249,65,138,8329,17,8201,1092,1045,8200,1025,4294967296,5,4295502889,1093,136]

theorem envBound9487 : H12AffineFastState.Bounded env9487 := by
  intro p hp
  have h : env9487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9486_9487 : H12AffineEnvironment.transform 7 5 env9486 = env9487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9486 == env9487) = true)

theorem identity9487 : scanCanonicalize (H12AffineFastState.compose env9487 (packedSelected [1,3,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound9487 : packedSelected [1,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9488 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,1045,2056,1093,2080,2218,1093,2048,524288,2080,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,4294967296,5,4295492641,1093,136]

theorem envBound9488 : H12AffineFastState.Bounded env9488 := by
  intro p hp
  have h : env9488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9487_9488 : H12AffineEnvironment.transform 12 2056 env9487 = env9488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env9487 == env9488) = true)

def env9489 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1093,2048,2186,1093,2048,524288,2048,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,4294967296,5,4295492609,1093,136]

theorem envBound9489 : H12AffineFastState.Bounded env9489 := by
  intro p hp
  have h : env9489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9488_9489 : H12AffineEnvironment.transform 4 0 env9488 = env9489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9488 == env9489) = true)

theorem identity9489 : scanCanonicalize (H12AffineFastState.compose env9489 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3286) := by decide +kernel

theorem selectedBound9489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9490 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1093,2048,2186,1093,2048,524288,2048,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,3286,5,526551,1093,136]

theorem envBound9490 : H12AffineFastState.Bounded env9490 := by
  intro p hp
  have h : env9490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9489_9490 : H12AffineEnvironment.transform 31 3286 env9489 = env9490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3286 env9489 == env9490) = true)

theorem identity9490 : scanCanonicalize (H12AffineFastState.compose env9490 (packedSelected [2,3] rootPS)) = affineNative (2^(18+1) ^^^ 2063) := by decide +kernel

theorem selectedBound9490 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env9491 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1045,2056,1093,2048,2186,1093,2048,2063,2048,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,3286,5,216,1093,136]

theorem envBound9491 : H12AffineFastState.Bounded env9491 := by
  intro p hp
  have h : env9491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9490_9491 : H12AffineEnvironment.transform 18 2063 env9490 = env9491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2063 env9490 == env9491) = true)

theorem identity9491 : scanCanonicalize (H12AffineFastState.compose env9491 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9492 : List Nat := [2,4,8,16,0,16,128,5,137,1024,2048,1045,2056,1045,2048,2186,1045,2048,2063,2048,1045,1,17,138,2177,17,2049,1044,1045,2048,1025,3206,5,136,1045,136]

theorem envBound9492 : H12AffineFastState.Bounded env9492 := by
  intro p hp
  have h : env9492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9491_9492 : H12AffineEnvironment.transform 5 16 env9491 = env9492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9491 == env9492) = true)

theorem identity9492 : scanCanonicalize (H12AffineFastState.compose env9492 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound9492 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env9493 : List Nat := [2,4,8,16,0,16,128,5,137,1024,1038,1045,1030,1045,1038,1156,1045,1038,1025,1038,1045,1,17,138,1167,17,1039,1044,1045,1038,1025,136,5,136,1045,136]

theorem envBound9493 : H12AffineFastState.Bounded env9493 := by
  intro p hp
  have h : env9493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9492_9493 : H12AffineEnvironment.transform 10 1038 env9492 = env9493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env9492 == env9493) = true)

def leafEnv9493 : List Nat := [2,4,8,16,0,16,128,5,137,1024,1038,1045,1030,1045,1038,1156,1045,1038,1025,1038,1045,1,17,138,1025,1167,1,17,1039,1044,1045,1038,1025,136,5,136,5,1037,1045,136,0,1044,1]

def active9493 : List Nat := [0,1,2,3,6,9]

def tree9493 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9493 : H12WitnessSearch.Good tree9493 := H12GlobalWitnessIndex.good

theorem leafIdentity9493 : H12AffineFastState.composeSystem env9493 rootObs = leafEnv9493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9493 rootObs == leafEnv9493) = true)

theorem terminalChecked9493 : H12PackedTerminal.terminalCheckFast leafEnv9493 active9493 tree9493 = true := by decide +kernel

def env9494 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1093,2049,2187,1093,2048,524288,2049,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,4294967296,5,4295492608,1093,136]

theorem envBound9494 : H12AffineFastState.Bounded env9494 := by
  intro p hp
  have h : env9494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9488_9494 : H12AffineEnvironment.transform 4 1 env9488 = env9494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9488 == env9494) = true)

theorem identity9494 : scanCanonicalize (H12AffineFastState.compose env9494 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 3166) := by decide +kernel

theorem selectedBound9494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9495 : List Nat := [2,4,8,16,1,64,128,5,137,1024,2048,1045,2056,1093,2049,2187,1093,2048,524288,2049,1045,1,65,138,2177,17,2049,1092,1045,2048,1025,3166,5,526430,1093,136]

theorem envBound9495 : H12AffineFastState.Bounded env9495 := by
  intro p hp
  have h : env9495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9494_9495 : H12AffineEnvironment.transform 31 3166 env9494 = env9495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3166 env9494 == env9495) = true)

theorem identity9495 : scanCanonicalize (H12AffineFastState.compose env9495 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1159) := by decide +kernel

theorem selectedBound9495 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9496 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1159,1045,1167,1093,1158,1036,1093,1159,524288,1158,1045,1,65,138,1030,17,1158,1092,1045,1159,1025,217,5,525529,1093,136]

theorem envBound9496 : H12AffineFastState.Bounded env9496 := by
  intro p hp
  have h : env9496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9495_9496 : H12AffineEnvironment.transform 10 1159 env9495 = env9496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1159 env9495 == env9496) = true)

theorem identity9496 : scanCanonicalize (H12AffineFastState.compose env9496 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9496 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9497 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1039,1045,1031,1093,1038,1036,1093,1039,524288,1038,1045,1,65,2,1030,17,1038,1092,1045,1039,1025,81,5,525393,1093,0]

theorem envBound9497 : H12AffineFastState.Bounded env9497 := by
  intro p hp
  have h : env9497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9496_9497 : H12AffineEnvironment.transform 6 8 env9496 = env9497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9496 == env9497) = true)

def leafEnv9497 : List Nat := [2,4,8,16,1,64,8,5,1,1024,1039,1045,1031,1093,1038,1036,1093,1039,524288,1038,1045,1,65,2,524288,1030,1,17,1038,1092,1045,1039,1025,81,5,525393,5,1037,1093,0,0,1044,1]

def active9497 : List Nat := [0,1,2,3,5,9,18]

def tree9497 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9497 : H12WitnessSearch.Good tree9497 := H12GlobalWitnessIndex.good

theorem leafIdentity9497 : H12AffineFastState.composeSystem env9497 rootObs = leafEnv9497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9497 rootObs == leafEnv9497) = true)

theorem terminalChecked9497 : H12PackedTerminal.terminalCheckFast leafEnv9497 active9497 tree9497 = true := by decide +kernel

def env9498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1992,8864,65536,1344,2049,524288,8864,1297,10249,713,74661,8329,16,9092,1993,1296,9092,1284,4294967296,256,4295560591,1344,513]

theorem envBound9498 : H12AffineFastState.Bounded env9498 := by
  intro p hp
  have h : env9498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9483_9498 : H12AffineEnvironment.transform 11 1297 env9483 = env9498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9483 == env9498) = true)

theorem identity9498 : scanCanonicalize (H12AffineFastState.compose env9498 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound9498 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2316,1992,2988,65536,1344,2049,524288,2988,1297,261,713,68265,2437,16,2696,1993,1296,2696,1284,4294967296,256,4295560591,1344,513]

theorem envBound9499 : H12AffineFastState.Bounded env9499 := by
  intro p hp
  have h : env9499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9498_9499 : H12AffineEnvironment.transform 12 2316 env9498 = env9499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env9498 == env9499) = true)

theorem identity9499 : scanCanonicalize (H12AffineFastState.compose env9499 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 1673) := by decide +kernel

theorem selectedBound9499 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2316,1992,2988,65536,1344,2049,1673,2988,1297,261,713,68265,2437,16,2696,1993,1296,2696,1284,4294967296,256,4295035654,1344,513]

theorem envBound9500 : H12AffineFastState.Bounded env9500 := by
  intro p hp
  have h : env9500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9499_9500 : H12AffineEnvironment.transform 18 1673 env9499 = env9500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1673 env9499 == env9500) = true)

theorem identity9500 : scanCanonicalize (H12AffineFastState.compose env9500 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound9500 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2316,1992,2988,2595,1344,2049,1673,2988,1297,261,713,138,2437,16,2696,1993,1296,2696,1284,4294967296,256,4294967589,1344,513]

theorem envBound9501 : H12AffineFastState.Bounded env9501 := by
  intro p hp
  have h : env9501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9500_9501 : H12AffineEnvironment.transform 15 2595 env9500 = env9501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env9500 == env9501) = true)

theorem identity9501 : scanCanonicalize (H12AffineFastState.compose env9501 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound9501 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9502 : List Nat := [2,4,8,16,32,64,128,256,396,1024,2048,1297,2316,1092,2080,2479,1344,2049,1285,2080,1297,261,325,138,2437,16,2308,1093,1296,2308,1284,4294967296,256,4294967589,1344,397]

theorem envBound9502 : H12AffineFastState.Bounded env9502 := by
  intro p hp
  have h : env9502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9501_9502 : H12AffineEnvironment.transform 8 396 env9501 = env9502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env9501 == env9502) = true)

theorem identity9502 : scanCanonicalize (H12AffineFastState.compose env9502 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9502 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9503 : List Nat := [2,4,8,16,32,64,128,37,169,1024,2048,1076,2089,1092,2080,2186,1125,2049,1056,2080,1076,32,96,138,2208,16,2081,1093,1077,2081,1057,4294967296,37,4294967296,1125,168]

theorem envBound9503 : H12AffineFastState.Bounded env9503 := by
  intro p hp
  have h : env9503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9502_9503 : H12AffineEnvironment.transform 7 37 env9502 = env9503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9502 == env9503) = true)

theorem identity9503 : scanCanonicalize (H12AffineFastState.compose env9503 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 112) := by decide +kernel

theorem selectedBound9503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9504 : List Nat := [2,4,8,16,32,64,128,37,169,1024,2048,1076,2089,1092,2080,2186,1125,2049,1056,2080,1076,32,96,138,2208,16,2081,1093,1077,2081,1057,112,37,112,1125,168]

theorem envBound9504 : H12AffineFastState.Bounded env9504 := by
  intro p hp
  have h : env9504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9503_9504 : H12AffineEnvironment.transform 31 112 env9503 = env9504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 112 env9503 == env9504) = true)

theorem identity9504 : scanCanonicalize (H12AffineFastState.compose env9504 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9504 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env9505 : List Nat := [2,4,8,16,0,64,128,5,137,1024,2048,1044,2057,1092,2048,2186,1093,2049,1024,2048,1044,0,64,138,2176,16,2049,1093,1045,2049,1025,80,5,80,1093,136]

theorem envBound9505 : H12AffineFastState.Bounded env9505 := by
  intro p hp
  have h : env9505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9504_9505 : H12AffineEnvironment.transform 4 0 env9504 = env9505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9504 == env9505) = true)

theorem identity9505 : scanCanonicalize (H12AffineFastState.compose env9505 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound9505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9506 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1038,1044,1031,1092,1038,1156,1093,1039,1024,1038,1044,0,64,138,1166,16,1039,1093,1045,1039,1025,80,5,80,1093,136]

theorem envBound9506 : H12AffineFastState.Bounded env9506 := by
  intro p hp
  have h : env9506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9505_9506 : H12AffineEnvironment.transform 10 1038 env9505 = env9506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env9505 == env9506) = true)

theorem identity9506 : scanCanonicalize (H12AffineFastState.compose env9506 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound9506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9507 : List Nat := [2,4,8,16,0,64,9,5,0,1024,1038,1044,1031,1092,1038,1037,1093,1039,1024,1038,1044,0,64,3,1031,16,1039,1093,1045,1039,1025,80,5,80,1093,1]

end H12CloudChart2