import H12CloudChart2Data219

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env55474 : List Nat := [2,4,8,7,32,64,15,100,39,66,76,38,15,33,97,67,96,77,3,96,38,32,1,98,73,6,106,38,33,75,3,38,100,1,102,103]

theorem envBound55474 : H12AffineFastState.Bounded env55474 := by
  intro p hp
  have h : env55474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55473_55474 : H12AffineEnvironment.transform 6 15 env55473 = env55474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55473 == env55474) = true)

theorem identity55474 : scanCanonicalize (H12AffineFastState.compose env55474 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound55474 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55475 : List Nat := [2,4,8,7,32,45,15,9,39,47,33,38,15,33,12,46,13,32,3,13,38,32,1,15,36,6,7,38,33,38,3,38,9,1,11,10]

theorem envBound55475 : H12AffineFastState.Bounded env55475 := by
  intro p hp
  have h : env55475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55474_55475 : H12AffineEnvironment.transform 5 45 env55474 = env55475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env55474 == env55475) = true)

theorem identity55475 : scanCanonicalize (H12AffineFastState.compose env55475 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55475 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55476 : List Nat := [2,2,8,1,32,43,9,9,33,41,33,32,9,33,10,40,11,32,3,11,32,32,1,9,34,0,1,32,33,32,3,32,9,1,11,10]

theorem envBound55476 : H12AffineFastState.Bounded env55476 := by
  intro p hp
  have h : env55476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55475_55476 : H12AffineEnvironment.transform 1 2 env55475 = env55476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55475 == env55476) = true)

def env55477 : List Nat := [2,4,8,16,32,64,128,256,340,1024,297,1280,24,1296,261,204,1210,77,1089,260,1280,476,490,1500,209,506,1087,1259,1296,438,20,1280,256,490,1344,276]

theorem envBound55477 : H12AffineFastState.Bounded env55477 := by
  intro p hp
  have h : env55477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55469_55477 : H12AffineEnvironment.transform 10 297 env55469 = env55477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 297 env55469 == env55477) = true)

theorem identity55477 : scanCanonicalize (H12AffineFastState.compose env55477 (packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound55477 : packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS < 2^1333 := by decide +kernel

def env55478 : List Nat := [2,4,8,16,32,64,128,98,54,1024,75,1122,24,1138,103,204,1210,77,1089,102,1122,190,136,1214,209,152,1087,1259,1138,212,20,1122,98,136,1058,118]

theorem envBound55478 : H12AffineFastState.Bounded env55478 := by
  intro p hp
  have h : env55478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55477_55478 : H12AffineEnvironment.transform 7 98 env55477 = env55478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env55477 == env55478) = true)

theorem identity55478 : scanCanonicalize (H12AffineFastState.compose env55478 (packedSelected [7,8,9,11,12,15,16,17,19] rootPS)) = affineNative (2^(9+1) ^^^ 161) := by decide +kernel

theorem selectedBound55478 : packedSelected [7,8,9,11,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env55479 : List Nat := [2,4,8,16,32,64,128,98,54,161,75,195,24,211,103,204,27,77,224,102,195,190,136,31,209,152,158,74,211,212,20,195,98,136,131,118]

theorem envBound55479 : H12AffineFastState.Bounded env55479 := by
  intro p hp
  have h : env55479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55478_55479 : H12AffineEnvironment.transform 9 161 env55478 = env55479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 161 env55478 == env55479) = true)

theorem identity55479 : scanCanonicalize (H12AffineFastState.compose env55479 (packedSelected [3,8,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound55479 : packedSelected [3,8,13,15,17] rootPS < 2^1333 := by decide +kernel

def env55480 : List Nat := [2,4,8,16,32,60,128,30,54,161,55,191,24,175,27,176,27,49,156,26,191,190,136,31,173,152,158,54,175,168,20,191,30,136,131,10]

theorem envBound55480 : H12AffineFastState.Bounded env55480 := by
  intro p hp
  have h : env55480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55479_55480 : H12AffineEnvironment.transform 5 60 env55479 = env55480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env55479 == env55480) = true)

theorem identity55480 : scanCanonicalize (H12AffineFastState.compose env55480 (packedSelected [3,8,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55480 : packedSelected [3,8,11,12] rootPS < 2^1333 := by decide +kernel

def env55481 : List Nat := [2,3,8,16,32,59,128,25,49,161,48,184,24,168,27,176,27,49,155,26,184,185,136,24,170,152,153,49,168,168,19,184,25,136,131,10]

theorem envBound55481 : H12AffineFastState.Bounded env55481 := by
  intro p hp
  have h : env55481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55480_55481 : H12AffineEnvironment.transform 1 3 env55480 = env55481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55480 == env55481) = true)

theorem identity55481 : scanCanonicalize (H12AffineFastState.compose env55481 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55481 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55482 : List Nat := [2,3,8,16,0,27,128,25,17,129,16,152,24,136,27,144,27,17,155,26,152,153,136,24,138,152,153,17,136,136,19,152,25,136,131,10]

theorem envBound55482 : H12AffineFastState.Bounded env55482 := by
  intro p hp
  have h : env55482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55481_55482 : H12AffineEnvironment.transform 4 0 env55481 = env55482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55481 == env55482) = true)

theorem identity55482 : scanCanonicalize (H12AffineFastState.compose env55482 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55482 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55483 : List Nat := [2,3,8,10,0,1,128,3,11,129,10,130,2,136,1,138,1,11,129,0,130,131,136,2,138,130,131,11,136,136,9,130,3,136,131,10]

theorem envBound55483 : H12AffineFastState.Bounded env55483 := by
  intro p hp
  have h : env55483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55482_55483 : H12AffineEnvironment.transform 3 10 env55482 = env55483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55482 == env55483) = true)

def env55484 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,260,65536,66678,65665,1088,261,1281,476,65830,66833,208,65847,1086,66599,1296,67666,20,1280,256,65830,1344,277]

theorem envBound55484 : H12AffineFastState.Bounded env55484 := by
  intro p hp
  have h : env55484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55467_55484 : H12AffineEnvironment.transform 11 1281 env55467 = env55484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env55467 == env55484) = true)

theorem identity55484 : scanCanonicalize (H12AffineFastState.compose env55484 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1500) := by decide +kernel

theorem selectedBound55484 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55485 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,260,1500,426,1373,1088,261,1281,476,1274,205,208,1259,1086,507,1296,3470,20,1280,256,1274,1344,277]

theorem envBound55485 : H12AffineFastState.Bounded env55485 := by
  intro p hp
  have h : env55485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55484_55485 : H12AffineEnvironment.transform 15 1500 env55484 = env55485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1500 env55484 == env55485) = true)

def env55486 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1476,1281,24,1296,260,1500,426,1373,1088,261,1281,476,1274,205,208,1259,1086,507,1296,74,20,1280,256,1274,1344,277]

theorem envBound55486 : H12AffineFastState.Bounded env55486 := by
  intro p hp
  have h : env55486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55485_55486 : H12AffineEnvironment.transform 10 1476 env55485 = env55486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1476 env55485 == env55486) = true)

theorem identity55486 : scanCanonicalize (H12AffineFastState.compose env55486 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound55486 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55487 : List Nat := [2,4,8,16,32,7,128,256,275,1024,1411,1281,24,1296,260,1435,426,1306,1031,261,1281,411,1213,138,151,1196,1086,444,1296,13,20,1280,256,1213,1287,277]

theorem envBound55487 : H12AffineFastState.Bounded env55487 := by
  intro p hp
  have h : env55487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55486_55487 : H12AffineEnvironment.transform 5 7 env55486 = env55487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env55486 == env55487) = true)

theorem identity55487 : scanCanonicalize (H12AffineFastState.compose env55487 (packedSelected [0,4,8,11,13,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55487 : packedSelected [0,4,8,11,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55488 : List Nat := [2,4,8,16,32,7,15,256,275,1024,1292,1281,24,1296,260,1300,293,1306,1031,261,1281,276,1074,5,24,1059,1086,307,1296,13,20,1280,256,1074,1287,277]

theorem envBound55488 : H12AffineFastState.Bounded env55488 := by
  intro p hp
  have h : env55488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55487_55488 : H12AffineEnvironment.transform 6 15 env55487 = env55488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55487 == env55488) = true)

theorem identity55488 : scanCanonicalize (H12AffineFastState.compose env55488 (packedSelected [2,3,7,9,10,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 300) := by decide +kernel

theorem selectedBound55488 : packedSelected [2,3,7,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env55489 : List Nat := [2,4,8,16,32,7,15,256,275,300,32,45,24,60,260,56,293,54,299,261,45,276,286,5,24,271,274,307,60,13,20,44,256,286,43,277]

theorem envBound55489 : H12AffineFastState.Bounded env55489 := by
  intro p hp
  have h : env55489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55488_55489 : H12AffineEnvironment.transform 9 300 env55488 = env55489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 300 env55488 == env55489) = true)

theorem identity55489 : scanCanonicalize (H12AffineFastState.compose env55489 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55489 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55490 : List Nat := [2,4,5,16,32,7,2,256,275,289,32,32,21,49,260,53,293,54,294,261,32,276,275,5,21,258,274,307,49,0,20,33,256,275,38,277]

theorem envBound55490 : H12AffineFastState.Bounded env55490 := by
  intro p hp
  have h : env55490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55489_55490 : H12AffineEnvironment.transform 2 5 env55489 = env55490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55489 == env55490) = true)

theorem identity55490 : scanCanonicalize (H12AffineFastState.compose env55490 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55490 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55491 : List Nat := [2,4,5,16,32,7,2,4,23,37,32,32,21,49,0,53,33,54,34,1,32,16,23,5,21,6,22,55,49,0,20,33,4,23,38,17]

theorem envBound55491 : H12AffineFastState.Bounded env55491 := by
  intro p hp
  have h : env55491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55490_55491 : H12AffineEnvironment.transform 7 4 env55490 = env55491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55490 == env55491) = true)

theorem identity55491 : scanCanonicalize (H12AffineFastState.compose env55491 (packedSelected [1,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55491 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env55492 : List Nat := [2,4,5,6,32,7,2,4,1,37,32,32,3,39,0,35,33,32,34,1,32,6,1,5,3,6,0,33,39,0,2,33,4,1,38,7]

theorem envBound55492 : H12AffineFastState.Bounded env55492 := by
  intro p hp
  have h : env55492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55491_55492 : H12AffineEnvironment.transform 3 6 env55491 = env55492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55491 == env55492) = true)

theorem identity55492 : scanCanonicalize (H12AffineFastState.compose env55492 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55493 : List Nat := [2,4,5,6,7,7,2,4,1,2,7,7,3,0,0,4,6,7,5,1,7,6,1,5,3,6,0,6,0,0,2,6,4,1,1,7]

theorem envBound55493 : H12AffineFastState.Bounded env55493 := by
  intro p hp
  have h : env55493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55492_55493 : H12AffineEnvironment.transform 4 7 env55492 = env55493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55492 == env55493) = true)

theorem identity55493 : scanCanonicalize (H12AffineFastState.compose env55493 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55494 : List Nat := [2,3,2,1,0,0,2,3,1,2,0,0,3,0,0,3,1,0,2,1,0,1,1,2,3,1,0,1,0,0,2,1,3,1,1,0]

theorem envBound55494 : H12AffineFastState.Bounded env55494 := by
  intro p hp
  have h : env55494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55493_55494 : H12AffineEnvironment.transform 1 3 env55493 = env55494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55493 == env55494) = true)

theorem identity55494 : scanCanonicalize (H12AffineFastState.compose env55494 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55495 : List Nat := [0,1,0,1,0,0,0,1,1,0,0,0,1,0,0,1,1,0,0,1,0,1,1,0,1,1,0,1,0,0,0,1,1,1,1,0]

theorem envBound55495 : H12AffineFastState.Bounded env55495 := by
  intro p hp
  have h : env55495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55494_55495 : H12AffineEnvironment.transform 0 0 env55494 = env55495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55494 == env55495) = true)

def env55496 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1477,1281,24,1296,260,1500,426,1373,1088,261,1281,476,1274,205,208,1259,1086,507,1296,75,20,1280,256,1274,1344,277]

theorem envBound55496 : H12AffineFastState.Bounded env55496 := by
  intro p hp
  have h : env55496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55485_55496 : H12AffineEnvironment.transform 10 1477 env55485 = env55496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1477 env55485 == env55496) = true)

theorem identity55496 : scanCanonicalize (H12AffineFastState.compose env55496 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound55496 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55497 : List Nat := [2,4,8,16,32,1,128,256,277,1024,1412,1281,24,1296,260,1437,426,1308,1025,261,1281,413,1211,140,145,1194,1086,442,1296,10,20,1280,256,1211,1281,277]

theorem envBound55497 : H12AffineFastState.Bounded env55497 := by
  intro p hp
  have h : env55497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55496_55497 : H12AffineEnvironment.transform 5 1 env55496 = env55497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55496 == env55497) = true)

theorem identity55497 : scanCanonicalize (H12AffineFastState.compose env55497 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55497 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55498 : List Nat := [2,4,8,16,32,1,128,4,17,1024,1152,1029,24,1044,0,1177,174,1048,1025,1,1029,153,1211,140,145,1194,1086,190,1044,10,20,1028,4,1211,1029,17]

theorem envBound55498 : H12AffineFastState.Bounded env55498 := by
  intro p hp
  have h : env55498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55497_55498 : H12AffineEnvironment.transform 7 4 env55497 = env55498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55497 == env55498) = true)

theorem identity55498 : scanCanonicalize (H12AffineFastState.compose env55498 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55498 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55499 : List Nat := [2,4,8,0,32,1,128,4,1,1024,1152,1029,8,1028,0,1161,174,1032,1025,1,1029,137,1195,140,129,1194,1070,174,1028,10,4,1028,4,1195,1029,1]

theorem envBound55499 : H12AffineFastState.Bounded env55499 := by
  intro p hp
  have h : env55499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55498_55499 : H12AffineEnvironment.transform 3 0 env55498 = env55499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55498 == env55499) = true)

theorem identity55499 : scanCanonicalize (H12AffineFastState.compose env55499 (packedSelected [0,1,3,4,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 139) := by decide +kernel

theorem selectedBound55499 : packedSelected [0,1,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env55500 : List Nat := [2,4,8,0,32,1,128,4,1,139,11,142,8,143,0,2,174,131,138,1,142,137,32,140,129,33,165,174,143,10,4,143,4,32,142,1]

theorem envBound55500 : H12AffineFastState.Bounded env55500 := by
  intro p hp
  have h : env55500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55499_55500 : H12AffineEnvironment.transform 9 139 env55499 = env55500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 139 env55499 == env55500) = true)

theorem identity55500 : scanCanonicalize (H12AffineFastState.compose env55500 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound55500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55501 : List Nat := [2,4,8,0,13,1,128,4,1,139,11,142,8,143,0,2,131,131,138,1,142,137,13,140,129,12,136,131,143,10,4,143,4,13,142,1]

theorem envBound55501 : H12AffineFastState.Bounded env55501 := by
  intro p hp
  have h : env55501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55500_55501 : H12AffineEnvironment.transform 4 13 env55500 = env55501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env55500 == env55501) = true)

theorem identity55501 : scanCanonicalize (H12AffineFastState.compose env55501 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound55501 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55502 : List Nat := [2,4,8,0,13,1,14,4,1,5,11,0,8,1,0,2,13,13,4,1,0,7,13,2,15,12,6,13,1,10,4,1,4,13,0,1]

theorem envBound55502 : H12AffineFastState.Bounded env55502 := by
  intro p hp
  have h : env55502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55501_55502 : H12AffineEnvironment.transform 6 14 env55501 = env55502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env55501 == env55502) = true)

theorem identity55502 : scanCanonicalize (H12AffineFastState.compose env55502 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55502 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55503 : List Nat := [2,4,5,0,0,1,3,4,1,5,6,0,5,1,0,2,0,0,4,1,0,7,0,2,2,1,6,0,1,7,4,1,4,0,0,1]

theorem envBound55503 : H12AffineFastState.Bounded env55503 := by
  intro p hp
  have h : env55503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55502_55503 : H12AffineEnvironment.transform 2 5 env55502 = env55503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55502 == env55503) = true)

def env55504 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4096,476,65830,69648,5585,70710,4415,66599,1296,73043,20,1280,256,65830,1344,5141]

theorem envBound55504 : H12AffineFastState.Bounded env55504 := by
  intro p hp
  have h : env55504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55466_55504 : H12AffineEnvironment.transform 8 341 env55466 = env55504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env55466 == env55504) = true)

def env55505 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,261,65536,66678,65665,1089,260,1280,476,65830,66832,209,65846,1087,66599,1296,67667,20,1280,256,65830,1344,277]

theorem envBound55505 : H12AffineFastState.Bounded env55505 := by
  intro p hp
  have h : env55505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55504_55505 : H12AffineEnvironment.transform 11 1280 env55504 = env55505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env55504 == env55505) = true)

theorem identity55505 : scanCanonicalize (H12AffineFastState.compose env55505 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 250) := by decide +kernel

theorem selectedBound55505 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55506 : List Nat := [2,4,8,16,32,64,128,250,175,1024,2048,1274,24,1258,255,65536,66678,65665,1089,254,1274,38,65756,66794,209,65740,1087,66599,1258,67667,20,1274,250,65756,1210,239]

theorem envBound55506 : H12AffineFastState.Bounded env55506 := by
  intro p hp
  have h : env55506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55505_55506 : H12AffineEnvironment.transform 7 250 env55505 = env55506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 250 env55505 == env55506) = true)

def env55507 : List Nat := [2,4,8,16,32,64,128,250,175,224,2048,26,24,10,255,65536,65686,65665,161,254,26,38,65756,65546,209,65740,223,65735,10,67667,20,26,250,65756,90,239]

theorem envBound55507 : H12AffineFastState.Bounded env55507 := by
  intro p hp
  have h : env55507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55506_55507 : H12AffineEnvironment.transform 9 224 env55506 = env55507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 224 env55506 == env55507) = true)

theorem identity55507 : scanCanonicalize (H12AffineFastState.compose env55507 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2085) := by decide +kernel

theorem selectedBound55507 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env55508 : List Nat := [2,4,8,16,32,64,128,250,175,224,2048,26,24,10,255,2085,2227,2212,161,254,26,38,2297,2095,209,2281,223,2274,10,118,20,26,250,2297,90,239]

theorem envBound55508 : H12AffineFastState.Bounded env55508 := by
  intro p hp
  have h : env55508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55507_55508 : H12AffineEnvironment.transform 15 2085 env55507 = env55508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2085 env55507 == env55508) = true)

theorem identity55508 : scanCanonicalize (H12AffineFastState.compose env55508 (packedSelected [0,1,2,3,4,10,11,13,16,17,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound55508 : packedSelected [0,1,2,3,4,10,11,13,16,17,21,23] rootPS < 2^1333 := by decide +kernel

def env55509 : List Nat := [2,4,8,16,32,64,21,111,58,117,2048,26,24,10,106,2085,2086,2097,52,107,26,38,2156,2095,68,2172,74,2167,10,118,20,26,111,2156,90,122]

theorem envBound55509 : H12AffineFastState.Bounded env55509 := by
  intro p hp
  have h : env55509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55508_55509 : H12AffineEnvironment.transform 6 21 env55508 = env55509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env55508 == env55509) = true)

theorem identity55509 : scanCanonicalize (H12AffineFastState.compose env55509 (packedSelected [0,4,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55509 : packedSelected [0,4,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55510 : List Nat := [2,4,8,16,6,64,21,73,28,83,2048,26,24,10,76,2051,2048,2071,18,77,26,0,2122,2057,68,2138,74,2129,10,80,20,26,73,2122,90,92]

theorem envBound55510 : H12AffineFastState.Bounded env55510 := by
  intro p hp
  have h : env55510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55509_55510 : H12AffineEnvironment.transform 4 6 env55509 = env55510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55509 == env55510) = true)

theorem identity55510 : scanCanonicalize (H12AffineFastState.compose env55510 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound55510 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env55511 : List Nat := [2,4,8,16,6,64,21,73,28,83,74,26,24,10,76,73,74,93,18,77,26,0,0,67,68,16,74,27,10,80,20,26,73,0,90,92]

theorem envBound55511 : H12AffineFastState.Bounded env55511 := by
  intro p hp
  have h : env55511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55510_55511 : H12AffineEnvironment.transform 10 74 env55510 = env55511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env55510 == env55511) = true)

theorem identity55511 : scanCanonicalize (H12AffineFastState.compose env55511 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound55511 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55512 : List Nat := [2,4,8,16,6,11,21,2,28,24,1,26,24,10,7,2,1,22,18,6,26,0,0,8,15,16,1,27,10,27,20,26,2,0,17,23]

theorem envBound55512 : H12AffineFastState.Bounded env55512 := by
  intro p hp
  have h : env55512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55511_55512 : H12AffineEnvironment.transform 5 11 env55511 = env55512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env55511 == env55512) = true)

theorem identity55512 : scanCanonicalize (H12AffineFastState.compose env55512 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55512 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55513 : List Nat := [2,4,3,16,6,0,21,2,23,19,1,17,19,1,7,2,1,22,18,6,17,0,0,3,4,16,1,16,1,16,20,17,2,0,17,23]

theorem envBound55513 : H12AffineFastState.Bounded env55513 := by
  intro p hp
  have h : env55513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55512_55513 : H12AffineEnvironment.transform 2 3 env55512 = env55513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55512 == env55513) = true)

theorem identity55513 : scanCanonicalize (H12AffineFastState.compose env55513 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55514 : List Nat := [2,4,3,6,6,0,3,2,1,5,1,7,5,1,7,2,1,0,4,6,7,0,0,3,4,6,1,6,1,6,2,7,2,0,7,1]

theorem envBound55514 : H12AffineFastState.Bounded env55514 := by
  intro p hp
  have h : env55514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55513_55514 : H12AffineEnvironment.transform 3 6 env55513 = env55514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55513 == env55514) = true)

theorem identity55514 : scanCanonicalize (H12AffineFastState.compose env55514 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55515 : List Nat := [2,3,3,1,1,0,3,2,1,2,1,0,2,1,0,2,1,0,3,1,0,0,0,3,3,1,1,1,1,1,2,0,2,0,0,1]

theorem envBound55515 : H12AffineFastState.Bounded env55515 := by
  intro p hp
  have h : env55515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55514_55515 : H12AffineEnvironment.transform 1 3 env55514 = env55515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55514 == env55515) = true)

def env55516 : List Nat := [2,4,8,16,32,64,128,250,175,225,2048,27,24,11,255,65536,65687,65665,160,254,27,38,65756,65547,209,65740,222,65734,11,67667,20,27,250,65756,91,239]

theorem envBound55516 : H12AffineFastState.Bounded env55516 := by
  intro p hp
  have h : env55516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55506_55516 : H12AffineEnvironment.transform 9 225 env55506 = env55516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 225 env55506 == env55516) = true)

theorem identity55516 : scanCanonicalize (H12AffineFastState.compose env55516 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2094) := by decide +kernel

theorem selectedBound55516 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env55517 : List Nat := [2,4,8,16,32,64,128,250,175,225,2048,27,24,11,255,2094,2233,2223,160,254,27,38,2290,2085,209,2274,222,2280,11,125,20,27,250,2290,91,239]

theorem envBound55517 : H12AffineFastState.Bounded env55517 := by
  intro p hp
  have h : env55517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55516_55517 : H12AffineEnvironment.transform 15 2094 env55516 = env55517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2094 env55516 == env55517) = true)

theorem identity55517 : scanCanonicalize (H12AffineFastState.compose env55517 (packedSelected [3,4,5,9,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 223) := by decide +kernel

theorem selectedBound55517 : packedSelected [3,4,5,9,13,16,18] rootPS < 2^1333 := by decide +kernel

def env55518 : List Nat := [2,4,8,16,32,64,128,250,175,225,223,27,24,11,255,241,102,112,160,254,27,38,45,250,209,61,222,55,11,125,20,27,250,45,91,239]

theorem envBound55518 : H12AffineFastState.Bounded env55518 := by
  intro p hp
  have h : env55518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55517_55518 : H12AffineEnvironment.transform 10 223 env55517 = env55518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 223 env55517 == env55518) = true)

theorem identity55518 : scanCanonicalize (H12AffineFastState.compose env55518 (packedSelected [1,3,5,7,8,9,11,12,13,19] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound55518 : packedSelected [1,3,5,7,8,9,11,12,13,19] rootPS < 2^1333 := by decide +kernel

def env55519 : List Nat := [2,4,8,16,32,64,73,51,102,40,22,27,24,11,54,56,102,112,105,55,27,38,45,51,24,61,23,55,11,125,20,27,51,45,91,38]

theorem envBound55519 : H12AffineFastState.Bounded env55519 := by
  intro p hp
  have h : env55519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55518_55519 : H12AffineEnvironment.transform 6 73 env55518 = env55519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env55518 == env55519) = true)

theorem identity55519 : scanCanonicalize (H12AffineFastState.compose env55519 (packedSelected [0,1,2,7,8,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55519 : packedSelected [0,1,2,7,8,13] rootPS < 2^1333 := by decide +kernel

def env55520 : List Nat := [2,4,8,16,32,0,9,51,38,40,22,27,24,11,54,56,38,48,41,55,27,38,45,51,24,61,23,55,11,61,20,27,51,45,27,38]

theorem envBound55520 : H12AffineFastState.Bounded env55520 := by
  intro p hp
  have h : env55520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55519_55520 : H12AffineEnvironment.transform 5 0 env55519 = env55520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55519 == env55520) = true)

theorem identity55520 : scanCanonicalize (H12AffineFastState.compose env55520 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55520 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55521 : List Nat := [2,4,8,16,7,0,9,20,1,15,22,27,24,11,17,31,1,23,14,16,27,1,10,20,24,26,23,16,11,26,20,27,20,10,27,1]

theorem envBound55521 : H12AffineFastState.Bounded env55521 := by
  intro p hp
  have h : env55521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55520_55521 : H12AffineEnvironment.transform 4 7 env55520 = env55521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55520 == env55521) = true)

theorem identity55521 : scanCanonicalize (H12AffineFastState.compose env55521 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55522 : List Nat := [2,4,2,16,7,0,3,20,1,5,22,17,18,1,17,21,1,23,4,16,17,1,0,20,18,16,23,16,1,16,20,17,20,0,17,1]

theorem envBound55522 : H12AffineFastState.Bounded env55522 := by
  intro p hp
  have h : env55522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55521_55522 : H12AffineEnvironment.transform 2 2 env55521 = env55522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55521 == env55522) = true)

theorem identity55522 : scanCanonicalize (H12AffineFastState.compose env55522 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55522 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55523 : List Nat := [2,4,2,7,7,0,3,3,1,5,1,6,5,1,6,2,1,0,4,7,6,1,0,3,5,7,0,7,1,7,3,6,3,0,6,1]

theorem envBound55523 : H12AffineFastState.Bounded env55523 := by
  intro p hp
  have h : env55523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55522_55523 : H12AffineEnvironment.transform 3 7 env55522 = env55523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55522 == env55523) = true)

theorem identity55523 : scanCanonicalize (H12AffineFastState.compose env55523 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55524 : List Nat := [2,2,2,1,1,0,3,3,1,3,1,0,3,1,0,2,1,0,2,1,0,1,0,3,3,1,0,1,1,1,3,0,3,0,0,1]

theorem envBound55524 : H12AffineFastState.Bounded env55524 := by
  intro p hp
  have h : env55524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55523_55524 : H12AffineEnvironment.transform 1 2 env55523 = env55524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55523 == env55524) = true)

def env55525 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,260,65536,66678,65665,1088,261,1281,476,65830,66833,208,65847,1086,66599,1296,67666,20,1280,256,65830,1344,276]

theorem envBound55525 : H12AffineFastState.Bounded env55525 := by
  intro p hp
  have h : env55525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55504_55525 : H12AffineEnvironment.transform 11 1281 env55504 = env55525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env55504 == env55525) = true)

theorem identity55525 : scanCanonicalize (H12AffineFastState.compose env55525 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound55525 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55526 : List Nat := [2,4,8,16,32,64,128,256,341,234,2048,491,24,506,260,65536,65692,65665,170,261,491,476,65830,66043,208,65847,212,65741,506,67666,20,490,256,65830,426,276]

theorem envBound55526 : H12AffineFastState.Bounded env55526 := by
  intro p hp
  have h : env55526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55525_55526 : H12AffineEnvironment.transform 9 234 env55525 = env55526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env55525 == env55526) = true)

def env55527 : List Nat := [2,4,8,16,32,64,128,256,341,234,2048,491,24,506,260,304,428,433,170,261,491,476,22,203,208,7,212,509,506,2402,20,490,256,22,426,276]

theorem envBound55527 : H12AffineFastState.Bounded env55527 := by
  intro p hp
  have h : env55527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55526_55527 : H12AffineEnvironment.transform 15 304 env55526 = env55527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env55526 == env55527) = true)

theorem identity55527 : scanCanonicalize (H12AffineFastState.compose env55527 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound55527 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55528 : List Nat := [2,4,8,16,32,1,128,256,276,171,2048,426,24,443,260,304,428,433,170,261,426,413,22,138,145,7,149,444,443,2339,20,427,256,22,426,276]

theorem envBound55528 : H12AffineFastState.Bounded env55528 := by
  intro p hp
  have h : env55528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55527_55528 : H12AffineEnvironment.transform 5 1 env55527 = env55528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55527 == env55528) = true)

theorem identity55528 : scanCanonicalize (H12AffineFastState.compose env55528 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55528 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55529 : List Nat := [2,4,8,16,32,1,128,4,16,171,2048,174,24,191,0,52,168,181,170,1,174,153,22,138,145,7,149,184,191,2087,20,175,4,22,174,16]

theorem envBound55529 : H12AffineFastState.Bounded env55529 := by
  intro p hp
  have h : env55529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55528_55529 : H12AffineEnvironment.transform 7 4 env55528 = env55529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55528 == env55529) = true)

theorem identity55529 : scanCanonicalize (H12AffineFastState.compose env55529 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound55529 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env55530 : List Nat := [2,4,8,16,32,1,14,4,16,37,2048,32,24,49,0,52,38,59,36,1,32,23,22,4,31,7,27,54,49,2087,20,33,4,22,32,16]

theorem envBound55530 : H12AffineFastState.Bounded env55530 := by
  intro p hp
  have h : env55530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55529_55530 : H12AffineEnvironment.transform 6 14 env55529 = env55530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env55529 == env55530) = true)

theorem identity55530 : scanCanonicalize (H12AffineFastState.compose env55530 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55530 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env55531 : List Nat := [2,4,8,7,32,1,14,4,7,37,2048,32,15,38,0,35,38,44,36,1,32,0,1,4,8,7,12,33,38,2087,3,33,4,1,32,7]

theorem envBound55531 : H12AffineFastState.Bounded env55531 := by
  intro p hp
  have h : env55531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55530_55531 : H12AffineEnvironment.transform 3 7 env55530 = env55531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55530 == env55531) = true)

theorem identity55531 : scanCanonicalize (H12AffineFastState.compose env55531 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound55531 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env55532 : List Nat := [2,4,8,7,32,1,14,4,7,37,13,32,15,38,0,35,38,44,36,1,32,0,1,4,8,7,12,33,38,42,3,33,4,1,32,7]

theorem envBound55532 : H12AffineFastState.Bounded env55532 := by
  intro p hp
  have h : env55532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55531_55532 : H12AffineEnvironment.transform 10 13 env55531 = env55532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env55531 == env55532) = true)

def env55533 : List Nat := [2,4,8,16,32,64,128,256,341,234,2048,491,24,506,260,305,429,432,170,261,491,476,23,202,208,6,212,508,506,2403,20,490,256,23,426,276]

theorem envBound55533 : H12AffineFastState.Bounded env55533 := by
  intro p hp
  have h : env55533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55526_55533 : H12AffineEnvironment.transform 15 305 env55526 = env55533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env55526 == env55533) = true)

theorem identity55533 : scanCanonicalize (H12AffineFastState.compose env55533 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 361) := by decide +kernel

theorem selectedBound55533 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55534 : List Nat := [2,4,8,16,32,64,128,256,341,234,361,491,24,506,260,305,429,432,170,261,491,476,23,202,208,6,212,508,506,10,20,490,256,23,426,276]

theorem envBound55534 : H12AffineFastState.Bounded env55534 := by
  intro p hp
  have h : env55534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55533_55534 : H12AffineEnvironment.transform 10 361 env55533 = env55534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 361 env55533 == env55534) = true)

theorem identity55534 : scanCanonicalize (H12AffineFastState.compose env55534 (packedSelected [1,2,4,5,7,10,12,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound55534 : packedSelected [1,2,4,5,7,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env55535 : List Nat := [2,4,8,16,32,64,105,256,341,3,361,258,24,275,260,305,324,345,67,261,258,309,23,35,57,6,61,277,275,10,20,259,256,23,323,276]

theorem envBound55535 : H12AffineFastState.Bounded env55535 := by
  intro p hp
  have h : env55535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55534_55535 : H12AffineEnvironment.transform 6 105 env55534 = env55535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env55534 == env55535) = true)

theorem identity55535 : scanCanonicalize (H12AffineFastState.compose env55535 (packedSelected [1,3,4,5,7,8,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55535 : packedSelected [1,3,4,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env55536 : List Nat := [2,4,8,16,6,64,79,256,341,3,335,258,24,275,260,279,324,345,67,261,258,275,23,5,31,6,27,277,275,10,20,259,256,23,323,276]

theorem envBound55536 : H12AffineFastState.Bounded env55536 := by
  intro p hp
  have h : env55536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55535_55536 : H12AffineEnvironment.transform 4 6 env55535 = env55536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55535 == env55536) = true)

theorem identity55536 : scanCanonicalize (H12AffineFastState.compose env55536 (packedSelected [0,2,3,4,5,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound55536 : packedSelected [0,2,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env55537 : List Nat := [2,4,8,16,6,64,79,3,86,3,76,1,24,16,7,20,71,90,67,6,1,16,23,5,31,6,27,22,16,10,20,0,3,23,64,23]

theorem envBound55537 : H12AffineFastState.Bounded env55537 := by
  intro p hp
  have h : env55537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55536_55537 : H12AffineEnvironment.transform 7 3 env55536 = env55537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env55536 == env55537) = true)

theorem identity55537 : scanCanonicalize (H12AffineFastState.compose env55537 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound55537 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55538 : List Nat := [2,4,8,16,6,12,3,3,26,3,0,1,24,16,7,20,11,22,15,6,1,16,23,5,31,6,27,22,16,10,20,0,3,23,12,23]

theorem envBound55538 : H12AffineFastState.Bounded env55538 := by
  intro p hp
  have h : env55538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55537_55538 : H12AffineEnvironment.transform 5 12 env55537 = env55538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env55537 == env55538) = true)

theorem identity55538 : scanCanonicalize (H12AffineFastState.compose env55538 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55539 : List Nat := [2,4,8,0,6,12,3,3,10,3,0,1,8,0,7,4,11,6,15,6,1,0,7,5,15,6,11,6,0,10,4,0,3,7,12,7]

theorem envBound55539 : H12AffineFastState.Bounded env55539 := by
  intro p hp
  have h : env55539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55538_55539 : H12AffineEnvironment.transform 3 0 env55538 = env55539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55538 == env55539) = true)

theorem identity55539 : scanCanonicalize (H12AffineFastState.compose env55539 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55539 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55540 : List Nat := [2,3,8,0,1,11,3,3,10,3,0,1,8,0,0,3,11,1,8,1,1,0,0,2,8,1,11,1,0,10,3,0,3,0,11,0]

theorem envBound55540 : H12AffineFastState.Bounded env55540 := by
  intro p hp
  have h : env55540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55539_55540 : H12AffineEnvironment.transform 1 3 env55539 = env55540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55539 == env55540) = true)

theorem identity55540 : scanCanonicalize (H12AffineFastState.compose env55540 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55541 : List Nat := [2,3,3,0,1,0,3,3,1,3,0,1,3,0,0,3,0,1,3,1,1,0,0,2,3,1,0,1,0,1,3,0,3,0,0,0]

theorem envBound55541 : H12AffineFastState.Bounded env55541 := by
  intro p hp
  have h : env55541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55540_55541 : H12AffineEnvironment.transform 2 3 env55540 = env55541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55540 == env55541) = true)

theorem identity55541 : scanCanonicalize (H12AffineFastState.compose env55541 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55542 : List Nat := [0,1,1,0,1,0,1,1,1,1,0,1,1,0,0,1,0,1,1,1,1,0,0,0,1,1,0,1,0,1,1,0,1,0,0,0]

theorem envBound55542 : H12AffineFastState.Bounded env55542 := by
  intro p hp
  have h : env55542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55541_55542 : H12AffineEnvironment.transform 0 0 env55541 = env55542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55541 == env55542) = true)

def env55543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4096,477,74047,69649,13768,78894,332223,74814,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound55543 : H12AffineFastState.Bounded env55543 := by
  intro p hp
  have h : env55543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55380_55543 : H12AffineEnvironment.transform 13 1297 env55380 = env55543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55380 == env55543) = true)

def env55544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4096,477,74047,69649,13768,78894,4415,74814,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound55544 : H12AffineFastState.Bounded env55544 := by
  intro p hp
  have h : env55544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55543_55544 : H12AffineEnvironment.transform 17 65664 env55543 = env55544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55543 == env55544) = true)

theorem identity55544 : scanCanonicalize (H12AffineFastState.compose env55544 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55544 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55545 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,1,79963,8205,17,256,65831,81,4688]

theorem envBound55545 : H12AffineFastState.Bounded env55545 := by
  intro p hp
  have h : env55545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55544_55545 : H12AffineEnvironment.transform 9 273 env55544 = env55545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55544 == env55545) = true)

def env55546 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,1,79963,8205,17,256,65831,81,4356]

theorem envBound55546 : H12AffineFastState.Bounded env55546 := by
  intro p hp
  have h : env55546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55545_55546 : H12AffineEnvironment.transform 8 340 env55545 = env55546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env55545 == env55546) = true)

def env55547 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,65536,74111,65664,336,8477,16,477,74047,65537,8393,74031,303,74031,1,75851,8205,17,256,65831,81,276]

theorem envBound55547 : H12AffineFastState.Bounded env55547 := by
  intro p hp
  have h : env55547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55546_55547 : H12AffineEnvironment.transform 11 16 env55546 = env55547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env55546 == env55547) = true)

theorem identity55547 : scanCanonicalize (H12AffineFastState.compose env55547 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 272) := by decide +kernel

theorem selectedBound55547 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55548 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,272,8303,400,336,8477,16,477,8239,273,8393,8255,303,8255,1,10587,8205,17,256,55,81,276]

theorem envBound55548 : H12AffineFastState.Bounded env55548 := by
  intro p hp
  have h : env55548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55547_55548 : H12AffineEnvironment.transform 15 272 env55547 = env55548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 272 env55547 == env55548) = true)

def env55549 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,56,0,292,272,87,400,336,293,16,477,23,273,241,7,303,7,1,2403,53,17,256,55,81,276]

theorem envBound55549 : H12AffineFastState.Bounded env55549 := by
  intro p hp
  have h : env55549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55548_55549 : H12AffineEnvironment.transform 12 56 env55548 = env55549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env55548 == env55549) = true)

theorem identity55549 : scanCanonicalize (H12AffineFastState.compose env55549 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55549 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env55550 : List Nat := [2,4,8,16,0,64,128,256,340,273,2048,16,24,0,260,272,87,400,336,261,16,477,23,273,209,7,271,7,1,2371,21,17,256,23,81,276]

theorem envBound55550 : H12AffineFastState.Bounded env55550 := by
  intro p hp
  have h : env55550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55549_55550 : H12AffineEnvironment.transform 4 0 env55549 = env55550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55549 == env55550) = true)

theorem identity55550 : scanCanonicalize (H12AffineFastState.compose env55550 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55550 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55551 : List Nat := [2,4,8,16,0,64,128,4,80,21,2048,16,24,0,0,20,87,148,84,1,16,217,23,21,209,7,11,7,1,2119,21,17,4,23,81,16]

theorem envBound55551 : H12AffineFastState.Bounded env55551 := by
  intro p hp
  have h : env55551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55550_55551 : H12AffineEnvironment.transform 7 4 env55550 = env55551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55550 == env55551) = true)

theorem identity55551 : scanCanonicalize (H12AffineFastState.compose env55551 (packedSelected [0,1,3,4,7,8,9,11,12,16] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55551 : packedSelected [0,1,3,4,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env55552 : List Nat := [2,3,8,16,0,64,128,3,80,18,2048,16,24,0,0,19,80,147,83,1,16,217,16,18,209,0,11,0,1,2112,18,17,3,16,81,16]

theorem envBound55552 : H12AffineFastState.Bounded env55552 := by
  intro p hp
  have h : env55552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55551_55552 : H12AffineEnvironment.transform 1 3 env55551 = env55552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55551 == env55552) = true)

theorem identity55552 : scanCanonicalize (H12AffineFastState.compose env55552 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound55552 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env55553 : List Nat := [2,3,8,16,0,64,88,3,80,18,2048,16,24,0,0,19,80,75,83,1,16,1,16,18,9,0,11,0,1,2112,18,17,3,16,81,16]

theorem envBound55553 : H12AffineFastState.Bounded env55553 := by
  intro p hp
  have h : env55553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55552_55553 : H12AffineEnvironment.transform 6 88 env55552 = env55553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env55552 == env55553) = true)

theorem identity55553 : scanCanonicalize (H12AffineFastState.compose env55553 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55553 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env55554 : List Nat := [2,3,2,16,0,64,82,3,80,18,2048,16,18,0,0,19,80,65,83,1,16,1,16,18,3,0,1,0,1,2112,18,17,3,16,81,16]

theorem envBound55554 : H12AffineFastState.Bounded env55554 := by
  intro p hp
  have h : env55554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55553_55554 : H12AffineEnvironment.transform 2 2 env55553 = env55554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55553 == env55554) = true)

theorem identity55554 : scanCanonicalize (H12AffineFastState.compose env55554 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55554 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55555 : List Nat := [2,3,2,16,0,64,82,3,80,18,17,16,18,0,0,19,80,65,83,1,16,1,16,18,3,0,1,0,1,81,18,17,3,16,81,16]

theorem envBound55555 : H12AffineFastState.Bounded env55555 := by
  intro p hp
  have h : env55555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55554_55555 : H12AffineEnvironment.transform 10 17 env55554 = env55555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55554 == env55555) = true)

theorem identity55555 : scanCanonicalize (H12AffineFastState.compose env55555 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55556 : List Nat := [2,3,2,16,0,17,3,3,1,18,17,16,18,0,0,19,1,16,2,1,16,1,16,18,3,0,1,0,1,0,18,17,3,16,0,16]

theorem envBound55556 : H12AffineFastState.Bounded env55556 := by
  intro p hp
  have h : env55556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55555_55556 : H12AffineEnvironment.transform 5 17 env55555 = env55556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55555 == env55556) = true)

theorem identity55556 : scanCanonicalize (H12AffineFastState.compose env55556 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55556 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55557 : List Nat := [2,3,2,0,0,1,3,3,1,2,1,0,2,0,0,3,1,0,2,1,0,1,0,2,3,0,1,0,1,0,2,1,3,0,0,0]

theorem envBound55557 : H12AffineFastState.Bounded env55557 := by
  intro p hp
  have h : env55557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55556_55557 : H12AffineEnvironment.transform 3 0 env55556 = env55557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55556 == env55557) = true)

theorem identity55557 : scanCanonicalize (H12AffineFastState.compose env55557 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55557 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55558 : List Nat := [1,0,1,0,0,1,0,0,1,1,1,0,1,0,0,0,1,0,1,1,0,1,0,1,0,0,1,0,1,0,1,1,0,0,0,0]

theorem envBound55558 : H12AffineFastState.Bounded env55558 := by
  intro p hp
  have h : env55558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55557_55558 : H12AffineEnvironment.transform 0 1 env55557 = env55558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55557 == env55558) = true)

def env55559 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,57,0,293,272,86,400,336,292,16,477,22,273,240,6,303,6,1,2402,52,17,256,55,81,276]

theorem envBound55559 : H12AffineFastState.Bounded env55559 := by
  intro p hp
  have h : env55559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55548_55559 : H12AffineEnvironment.transform 12 57 env55548 = env55559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env55548 == env55559) = true)

theorem identity55559 : scanCanonicalize (H12AffineFastState.compose env55559 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55559 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env55560 : List Nat := [2,4,8,16,7,64,128,256,340,273,2048,16,30,0,258,272,86,400,336,259,16,477,22,273,215,6,264,6,1,2373,19,17,256,16,81,276]

theorem envBound55560 : H12AffineFastState.Bounded env55560 := by
  intro p hp
  have h : env55560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55559_55560 : H12AffineEnvironment.transform 4 7 env55559 = env55560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55559 == env55560) = true)

theorem identity55560 : scanCanonicalize (H12AffineFastState.compose env55560 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound55560 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55561 : List Nat := [2,4,8,16,7,64,128,19,71,2,2048,16,30,0,17,3,86,131,67,16,16,206,22,2,215,6,27,6,1,2134,19,17,19,16,81,7]

theorem envBound55561 : H12AffineFastState.Bounded env55561 := by
  intro p hp
  have h : env55561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55560_55561 : H12AffineEnvironment.transform 7 19 env55560 = env55561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env55560 == env55561) = true)

theorem identity55561 : scanCanonicalize (H12AffineFastState.compose env55561 (packedSelected [3,10,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55561 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env55562 : List Nat := [2,2,8,16,1,64,128,19,65,2,2048,16,24,0,17,3,80,131,67,16,16,200,16,2,209,0,27,0,1,2128,19,17,19,16,81,1]

theorem envBound55562 : H12AffineFastState.Bounded env55562 := by
  intro p hp
  have h : env55562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55561_55562 : H12AffineEnvironment.transform 1 2 env55561 = env55562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55561 == env55562) = true)

theorem identity55562 : scanCanonicalize (H12AffineFastState.compose env55562 (packedSelected [0,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound55562 : packedSelected [0,7,11,12] rootPS < 2^1333 := by decide +kernel

def env55563 : List Nat := [2,2,8,16,1,64,128,19,65,2,64,16,24,0,17,3,80,131,67,16,16,200,16,2,209,0,27,0,1,16,19,17,19,16,81,1]

theorem envBound55563 : H12AffineFastState.Bounded env55563 := by
  intro p hp
  have h : env55563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55562_55563 : H12AffineEnvironment.transform 10 64 env55562 = env55563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env55562 == env55563) = true)

theorem identity55563 : scanCanonicalize (H12AffineFastState.compose env55563 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound55563 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55564 : List Nat := [2,2,8,16,1,64,24,19,65,2,64,16,24,0,17,3,80,27,67,16,16,80,16,2,73,0,27,0,1,16,19,17,19,16,81,1]

theorem envBound55564 : H12AffineFastState.Bounded env55564 := by
  intro p hp
  have h : env55564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55563_55564 : H12AffineEnvironment.transform 6 24 env55563 = env55564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env55563 == env55564) = true)

theorem identity55564 : scanCanonicalize (H12AffineFastState.compose env55564 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound55564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55565 : List Nat := [2,2,8,16,1,1,24,19,0,2,1,16,24,0,17,3,17,27,2,16,16,17,16,2,8,0,27,0,1,16,19,17,19,16,16,1]

theorem envBound55565 : H12AffineFastState.Bounded env55565 := by
  intro p hp
  have h : env55565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55564_55565 : H12AffineEnvironment.transform 5 1 env55564 = env55565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55564 == env55565) = true)

theorem identity55565 : scanCanonicalize (H12AffineFastState.compose env55565 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55566 : List Nat := [1,1,8,16,1,1,24,16,0,1,1,16,24,0,17,0,17,24,1,16,16,17,16,1,8,0,24,0,1,16,16,17,16,16,16,1]

theorem envBound55566 : H12AffineFastState.Bounded env55566 := by
  intro p hp
  have h : env55566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55565_55566 : H12AffineEnvironment.transform 0 1 env55565 = env55566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55565 == env55566) = true)

theorem identity55566 : scanCanonicalize (H12AffineFastState.compose env55566 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound55566 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55567 : List Nat := [1,1,8,9,1,1,1,9,0,1,1,9,1,0,8,0,8,1,1,9,9,8,9,1,8,0,1,0,1,9,9,8,9,9,9,1]

theorem envBound55567 : H12AffineFastState.Bounded env55567 := by
  intro p hp
  have h : env55567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55566_55567 : H12AffineEnvironment.transform 3 9 env55566 = env55567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env55566 == env55567) = true)

theorem identity55567 : scanCanonicalize (H12AffineFastState.compose env55567 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound55567 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55568 : List Nat := [1,1,1,0,1,1,1,0,0,1,1,0,1,0,1,0,1,1,1,0,0,1,0,1,1,0,1,0,1,0,0,1,0,0,0,1]

theorem envBound55568 : H12AffineFastState.Bounded env55568 := by
  intro p hp
  have h : env55568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55567_55568 : H12AffineEnvironment.transform 2 1 env55567 = env55568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env55567 == env55568) = true)

def env55569 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,65536,74111,65664,337,8476,17,477,74047,65536,8392,74030,302,74031,1,75850,8205,17,256,65831,81,277]

theorem envBound55569 : H12AffineFastState.Bounded env55569 := by
  intro p hp
  have h : env55569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55546_55569 : H12AffineEnvironment.transform 11 17 env55546 = env55569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env55546 == env55569) = true)

theorem identity55569 : scanCanonicalize (H12AffineFastState.compose env55569 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8456) := by decide +kernel

theorem selectedBound55569 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55570 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,8456,119,8584,337,8476,17,477,55,8456,8392,38,302,39,1,2370,8205,17,256,8239,81,277]

theorem envBound55570 : H12AffineFastState.Bounded env55570 := by
  intro p hp
  have h : env55570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55569_55570 : H12AffineEnvironment.transform 15 8456 env55569 = env55570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env55569 == env55570) = true)

def env55571 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,8192,0,8477,8456,55,8584,273,8476,17,413,55,8456,8328,38,302,39,1,2306,8205,17,256,8239,17,277]

theorem envBound55571 : H12AffineFastState.Bounded env55571 := by
  intro p hp
  have h : env55571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55570_55571 : H12AffineEnvironment.transform 5 0 env55570 = env55571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55570 == env55571) = true)

theorem identity55571 : scanCanonicalize (H12AffineFastState.compose env55571 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 299) := by decide +kernel

theorem selectedBound55571 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55572 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,299,0,54,35,55,163,273,55,17,413,55,35,419,38,302,39,1,2306,294,17,256,260,17,277]

theorem envBound55572 : H12AffineFastState.Bounded env55572 := by
  intro p hp
  have h : env55572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55571_55572 : H12AffineEnvironment.transform 12 299 env55571 = env55572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 299 env55571 == env55572) = true)

theorem identity55572 : scanCanonicalize (H12AffineFastState.compose env55572 (packedSelected [0,5,7,8,10,12,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55572 : packedSelected [0,5,7,8,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env55573 : List Nat := [2,4,8,16,32,0,15,256,276,273,2048,17,299,0,54,35,55,44,273,55,17,274,55,35,300,38,302,39,1,2306,294,17,256,260,17,277]

theorem envBound55573 : H12AffineFastState.Bounded env55573 := by
  intro p hp
  have h : env55573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55572_55573 : H12AffineEnvironment.transform 6 15 env55572 = env55573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55572 == env55573) = true)

theorem identity55573 : scanCanonicalize (H12AffineFastState.compose env55573 (packedSelected [0,2,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound55573 : packedSelected [0,2,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env55574 : List Nat := [2,4,8,16,32,0,15,256,276,273,44,17,299,0,54,35,55,44,273,55,17,274,55,35,300,38,302,39,1,302,294,17,256,260,17,277]

theorem envBound55574 : H12AffineFastState.Bounded env55574 := by
  intro p hp
  have h : env55574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55573_55574 : H12AffineEnvironment.transform 10 44 env55573 = env55574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env55573 == env55574) = true)

theorem identity55574 : scanCanonicalize (H12AffineFastState.compose env55574 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55574 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55575 : List Nat := [2,4,8,16,6,0,15,256,276,273,10,17,269,0,16,5,17,10,273,17,17,274,17,5,266,0,264,1,1,264,256,17,256,260,17,277]

theorem envBound55575 : H12AffineFastState.Bounded env55575 := by
  intro p hp
  have h : env55575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55574_55575 : H12AffineEnvironment.transform 4 6 env55574 = env55575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55574 == env55575) = true)

theorem identity55575 : scanCanonicalize (H12AffineFastState.compose env55575 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound55575 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55576 : List Nat := [2,4,8,8,6,0,15,256,268,265,10,9,269,0,8,5,9,10,265,9,9,266,9,5,266,0,264,1,1,264,256,9,256,260,9,269]

theorem envBound55576 : H12AffineFastState.Bounded env55576 := by
  intro p hp
  have h : env55576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55575_55576 : H12AffineEnvironment.transform 3 8 env55575 = env55576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env55575 == env55576) = true)

theorem identity55576 : scanCanonicalize (H12AffineFastState.compose env55576 (packedSelected [2,8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55576 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env55577 : List Nat := [0,4,8,8,4,0,13,256,268,265,8,9,269,0,8,5,9,8,265,9,9,264,9,5,264,0,264,1,1,264,256,9,256,260,9,269]

theorem envBound55577 : H12AffineFastState.Bounded env55577 := by
  intro p hp
  have h : env55577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55576_55577 : H12AffineEnvironment.transform 0 0 env55576 = env55577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55576 == env55577) = true)

theorem identity55577 : scanCanonicalize (H12AffineFastState.compose env55577 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55578 : List Nat := [0,4,5,5,4,0,0,256,257,260,5,4,256,0,5,5,4,5,260,4,4,261,4,5,261,0,261,1,1,261,256,4,256,260,4,256]

theorem envBound55578 : H12AffineFastState.Bounded env55578 := by
  intro p hp
  have h : env55578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55577_55578 : H12AffineEnvironment.transform 2 5 env55577 = env55578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55577 == env55578) = true)

theorem identity55578 : scanCanonicalize (H12AffineFastState.compose env55578 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound55578 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55579 : List Nat := [0,4,5,5,4,0,0,0,1,4,5,4,0,0,5,5,4,5,4,4,4,5,4,5,5,0,5,1,1,5,0,4,0,4,4,0]

theorem envBound55579 : H12AffineFastState.Bounded env55579 := by
  intro p hp
  have h : env55579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55578_55579 : H12AffineEnvironment.transform 7 0 env55578 = env55579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env55578 == env55579) = true)

theorem identity55579 : scanCanonicalize (H12AffineFastState.compose env55579 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55580 : List Nat := [0,0,1,1,0,0,0,0,1,0,1,0,0,0,1,1,0,1,0,0,0,1,0,1,1,0,1,1,1,1,0,0,0,0,0,0]

theorem envBound55580 : H12AffineFastState.Bounded env55580 := by
  intro p hp
  have h : env55580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55579_55580 : H12AffineEnvironment.transform 1 0 env55579 = env55580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55579 == env55580) = true)

def env55581 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,17,8192,0,8477,8456,54,8584,272,8476,17,412,55,8456,8329,38,302,39,1,2307,8205,17,256,8239,16,277]

theorem envBound55581 : H12AffineFastState.Bounded env55581 := by
  intro p hp
  have h : env55581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55570_55581 : H12AffineEnvironment.transform 5 1 env55570 = env55581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55570 == env55581) = true)

theorem identity55581 : scanCanonicalize (H12AffineFastState.compose env55581 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 285) := by decide +kernel

theorem selectedBound55581 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55582 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,17,285,0,0,21,54,149,272,1,17,412,55,21,404,38,302,39,1,2307,272,17,256,306,16,277]

theorem envBound55582 : H12AffineFastState.Bounded env55582 := by
  intro p hp
  have h : env55582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55581_55582 : H12AffineEnvironment.transform 12 285 env55581 = env55582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 285 env55581 == env55582) = true)

theorem identity55582 : scanCanonicalize (H12AffineFastState.compose env55582 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55582 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55583 : List Nat := [2,4,8,0,32,1,128,256,261,257,2048,1,269,0,0,5,38,133,256,1,1,396,39,5,388,38,302,39,1,2307,256,1,256,290,0,261]

theorem envBound55583 : H12AffineFastState.Bounded env55583 := by
  intro p hp
  have h : env55583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55582_55583 : H12AffineEnvironment.transform 3 0 env55582 = env55583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55582 == env55583) = true)

theorem identity55583 : scanCanonicalize (H12AffineFastState.compose env55583 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound55583 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env55584 : List Nat := [2,4,8,0,32,1,128,256,261,257,258,1,269,0,0,5,38,133,256,1,1,396,39,5,388,38,302,39,1,1,256,1,256,290,0,261]

theorem envBound55584 : H12AffineFastState.Bounded env55584 := by
  intro p hp
  have h : env55584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55583_55584 : H12AffineEnvironment.transform 10 258 env55583 = env55584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env55583 == env55584) = true)

theorem identity55584 : scanCanonicalize (H12AffineFastState.compose env55584 (packedSelected [0,1,2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55584 : packedSelected [0,1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env55585 : List Nat := [2,4,8,0,32,1,3,256,261,257,258,1,269,0,0,5,38,6,256,1,1,271,39,5,263,38,302,39,1,1,256,1,256,290,0,261]

theorem envBound55585 : H12AffineFastState.Bounded env55585 := by
  intro p hp
  have h : env55585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55584_55585 : H12AffineEnvironment.transform 6 3 env55584 = env55585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55584 == env55585) = true)

theorem identity55585 : scanCanonicalize (H12AffineFastState.compose env55585 (packedSelected [3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55585 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env55586 : List Nat := [2,4,8,0,10,1,3,256,261,257,258,1,269,0,0,5,12,6,256,1,1,271,13,5,263,12,260,13,1,1,256,1,256,264,0,261]

theorem envBound55586 : H12AffineFastState.Bounded env55586 := by
  intro p hp
  have h : env55586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55585_55586 : H12AffineEnvironment.transform 4 10 env55585 = env55586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55585 == env55586) = true)

theorem identity55586 : scanCanonicalize (H12AffineFastState.compose env55586 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound55586 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env55587 : List Nat := [2,4,8,0,10,1,3,3,6,2,1,1,14,0,0,5,12,6,3,1,1,12,13,5,4,12,7,13,1,1,3,1,3,11,0,6]

theorem envBound55587 : H12AffineFastState.Bounded env55587 := by
  intro p hp
  have h : env55587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55586_55587 : H12AffineEnvironment.transform 7 3 env55586 = env55587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env55586 == env55587) = true)

theorem identity55587 : scanCanonicalize (H12AffineFastState.compose env55587 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55587 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55588 : List Nat := [2,4,3,0,1,1,3,3,6,2,1,1,5,0,0,5,7,6,3,1,1,7,6,5,4,7,7,6,1,1,3,1,3,0,0,6]

theorem envBound55588 : H12AffineFastState.Bounded env55588 := by
  intro p hp
  have h : env55588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55587_55588 : H12AffineEnvironment.transform 2 3 env55587 = env55588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55587 == env55588) = true)

theorem identity55588 : scanCanonicalize (H12AffineFastState.compose env55588 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55589 : List Nat := [2,3,3,0,1,1,3,3,1,2,1,1,2,0,0,2,0,1,3,1,1,0,1,2,3,0,0,1,1,1,3,1,3,0,0,1]

theorem envBound55589 : H12AffineFastState.Bounded env55589 := by
  intro p hp
  have h : env55589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55588_55589 : H12AffineEnvironment.transform 1 3 env55588 = env55589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55588 == env55589) = true)

def env55590 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,1,79963,8205,17,256,65831,81,4357]

theorem envBound55590 : H12AffineFastState.Bounded env55590 := by
  intro p hp
  have h : env55590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55545_55590 : H12AffineEnvironment.transform 8 341 env55545 = env55590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env55545 == env55590) = true)

def env55591 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,65536,74111,65664,336,8477,16,477,74047,65537,8393,74031,303,74031,1,75851,8205,17,256,65831,81,277]

theorem envBound55591 : H12AffineFastState.Bounded env55591 := by
  intro p hp
  have h : env55591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55590_55591 : H12AffineEnvironment.transform 11 16 env55590 = env55591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env55590 == env55591) = true)

theorem identity55591 : scanCanonicalize (H12AffineFastState.compose env55591 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 63) := by decide +kernel

theorem selectedBound55591 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55592 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,63,0,291,65536,65856,65664,336,290,16,477,65792,65537,246,65808,303,65808,1,67700,50,17,256,65831,81,277]

theorem envBound55592 : H12AffineFastState.Bounded env55592 := by
  intro p hp
  have h : env55592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55591_55592 : H12AffineEnvironment.transform 12 63 env55591 = env55592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 63 env55591 == env55592) = true)

def env55593 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,63,0,291,272,80,400,336,290,16,477,16,273,246,0,303,0,1,2404,50,17,256,55,81,277]

theorem envBound55593 : H12AffineFastState.Bounded env55593 := by
  intro p hp
  have h : env55593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55592_55593 : H12AffineEnvironment.transform 15 272 env55592 = env55593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 272 env55592 == env55593) = true)

theorem identity55593 : scanCanonicalize (H12AffineFastState.compose env55593 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound55593 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55594 : List Nat := [2,4,8,16,32,64,128,50,103,35,2048,16,63,0,17,34,80,162,98,16,16,239,16,35,246,0,29,0,1,2134,50,17,50,55,81,39]

theorem envBound55594 : H12AffineFastState.Bounded env55594 := by
  intro p hp
  have h : env55594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55593_55594 : H12AffineEnvironment.transform 7 50 env55593 = env55594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env55593 == env55594) = true)

theorem identity55594 : scanCanonicalize (H12AffineFastState.compose env55594 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55594 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env55595 : List Nat := [2,4,8,16,22,64,128,4,81,21,2048,16,9,0,17,20,80,148,84,16,16,217,16,21,192,0,29,0,1,2134,4,17,4,1,81,17]

theorem envBound55595 : H12AffineFastState.Bounded env55595 := by
  intro p hp
  have h : env55595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55594_55595 : H12AffineEnvironment.transform 4 22 env55594 = env55595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55594 == env55595) = true)

theorem identity55595 : scanCanonicalize (H12AffineFastState.compose env55595 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound55595 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55596 : List Nat := [2,4,8,16,22,64,72,4,81,21,2048,16,9,0,17,20,80,92,84,16,16,17,16,21,8,0,29,0,1,2134,4,17,4,1,81,17]

theorem envBound55596 : H12AffineFastState.Bounded env55596 := by
  intro p hp
  have h : env55596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55595_55596 : H12AffineEnvironment.transform 6 72 env55595 = env55596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env55595 == env55596) = true)

def env55597 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,63,0,291,273,81,401,336,290,16,477,17,272,246,1,303,1,1,2405,50,17,256,54,81,277]

theorem envBound55597 : H12AffineFastState.Bounded env55597 := by
  intro p hp
  have h : env55597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55592_55597 : H12AffineEnvironment.transform 15 273 env55592 = env55597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 273 env55592 == env55597) = true)

theorem identity55597 : scanCanonicalize (H12AffineFastState.compose env55597 (packedSelected [13,21] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55597 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55598 : List Nat := [2,4,8,16,22,64,128,256,341,273,2048,16,9,0,277,273,81,401,336,276,16,477,17,272,192,1,281,1,1,2387,4,17,256,0,81,277]

theorem envBound55598 : H12AffineFastState.Bounded env55598 := by
  intro p hp
  have h : env55598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55597_55598 : H12AffineEnvironment.transform 4 22 env55597 = env55598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55597 == env55598) = true)

theorem identity55598 : scanCanonicalize (H12AffineFastState.compose env55598 (packedSelected [0,2,5,7,8,11,15,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55598 : packedSelected [0,2,5,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env55599 : List Nat := [2,4,8,16,22,64,128,256,341,273,1,16,9,0,277,273,81,401,336,276,16,477,17,272,192,1,281,1,1,338,4,17,256,0,81,277]

theorem envBound55599 : H12AffineFastState.Bounded env55599 := by
  intro p hp
  have h : env55599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55598_55599 : H12AffineEnvironment.transform 10 1 env55598 = env55599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55598 == env55599) = true)

theorem identity55599 : scanCanonicalize (H12AffineFastState.compose env55599 (packedSelected [3,4,8,9,10,12,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55599 : packedSelected [3,4,8,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env55600 : List Nat := [2,4,8,16,22,16,128,256,261,273,1,16,9,0,277,273,1,401,256,276,16,397,17,272,144,1,281,1,1,258,4,17,256,0,1,277]

theorem envBound55600 : H12AffineFastState.Bounded env55600 := by
  intro p hp
  have h : env55600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55599_55600 : H12AffineEnvironment.transform 5 16 env55599 = env55600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55599 == env55600) = true)

theorem identity55600 : scanCanonicalize (H12AffineFastState.compose env55600 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound55600 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env55601 : List Nat := [2,4,8,16,22,16,14,256,261,273,1,16,9,0,277,273,1,287,256,276,16,259,17,272,30,1,281,1,1,258,4,17,256,0,1,277]

theorem envBound55601 : H12AffineFastState.Bounded env55601 := by
  intro p hp
  have h : env55601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55600_55601 : H12AffineEnvironment.transform 6 14 env55600 = env55601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env55600 == env55601) = true)

theorem identity55601 : scanCanonicalize (H12AffineFastState.compose env55601 (packedSelected [1,2,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55601 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env55602 : List Nat := [2,4,8,7,1,7,14,256,261,262,1,7,9,0,258,262,1,264,256,259,7,259,6,263,9,1,270,1,1,258,4,6,256,0,1,258]

theorem envBound55602 : H12AffineFastState.Bounded env55602 := by
  intro p hp
  have h : env55602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55601_55602 : H12AffineEnvironment.transform 3 7 env55601 = env55602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55601 == env55602) = true)

theorem identity55602 : scanCanonicalize (H12AffineFastState.compose env55602 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55602 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55603 : List Nat := [2,4,8,7,1,7,14,5,0,3,1,7,9,0,7,3,1,13,5,6,7,6,6,2,9,1,11,1,1,7,4,6,5,0,1,7]

theorem envBound55603 : H12AffineFastState.Bounded env55603 := by
  intro p hp
  have h : env55603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55602_55603 : H12AffineEnvironment.transform 7 5 env55602 = env55603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55602 == env55603) = true)

theorem identity55603 : scanCanonicalize (H12AffineFastState.compose env55603 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55603 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55604 : List Nat := [2,4,5,7,1,7,3,5,0,3,1,7,4,0,7,3,1,0,5,6,7,6,6,2,4,1,6,1,1,7,4,6,5,0,1,7]

theorem envBound55604 : H12AffineFastState.Bounded env55604 := by
  intro p hp
  have h : env55604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55603_55604 : H12AffineEnvironment.transform 2 5 env55603 = env55604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55603 == env55604) = true)

theorem identity55604 : scanCanonicalize (H12AffineFastState.compose env55604 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55604 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55605 : List Nat := [2,3,2,0,1,0,3,2,0,3,1,0,3,0,0,3,1,0,2,1,0,1,1,2,3,1,1,1,1,0,3,1,2,0,1,0]

theorem envBound55605 : H12AffineFastState.Bounded env55605 := by
  intro p hp
  have h : env55605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55604_55605 : H12AffineEnvironment.transform 1 3 env55604 = env55605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55604 == env55605) = true)

def env55606 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,65536,74111,65664,337,8476,17,477,74047,65536,8392,74030,302,74031,1,75850,8205,17,256,65831,81,276]

theorem envBound55606 : H12AffineFastState.Bounded env55606 := by
  intro p hp
  have h : env55606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55590_55606 : H12AffineEnvironment.transform 11 17 env55590 = env55606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env55590 == env55606) = true)

theorem identity55606 : scanCanonicalize (H12AffineFastState.compose env55606 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55606 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55607 : List Nat := [2,4,8,16,7,64,128,256,341,273,2048,17,8192,0,8477,65536,74072,65664,337,8476,17,477,74008,65536,8392,73993,265,73992,1,75850,8205,17,256,65792,81,276]

theorem envBound55607 : H12AffineFastState.Bounded env55607 := by
  intro p hp
  have h : env55607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55606_55607 : H12AffineEnvironment.transform 4 7 env55606 = env55607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55606 == env55607) = true)

def env55608 : List Nat := [2,4,8,16,7,64,128,256,341,273,2048,17,8192,0,8477,8456,80,8584,337,8476,17,477,16,8456,8392,1,265,0,1,2370,8205,17,256,8200,81,276]

theorem envBound55608 : H12AffineFastState.Bounded env55608 := by
  intro p hp
  have h : env55608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55607_55608 : H12AffineEnvironment.transform 15 8456 env55607 = env55608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env55607 == env55608) = true)

theorem identity55608 : scanCanonicalize (H12AffineFastState.compose env55608 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55608 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55609 : List Nat := [2,4,8,16,7,64,128,256,341,273,2048,17,269,0,16,5,80,133,337,17,17,477,16,5,453,1,265,0,1,2370,256,17,256,261,81,276]

theorem envBound55609 : H12AffineFastState.Bounded env55609 := by
  intro p hp
  have h : env55609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55608_55609 : H12AffineEnvironment.transform 12 269 env55608 = env55609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55608 == env55609) = true)

theorem identity55609 : scanCanonicalize (H12AffineFastState.compose env55609 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound55609 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env55610 : List Nat := [2,4,8,16,7,64,128,68,17,85,2048,17,73,0,16,5,80,133,21,17,17,153,16,5,129,1,77,0,1,2054,68,17,68,65,81,80]

theorem envBound55610 : H12AffineFastState.Bounded env55610 := by
  intro p hp
  have h : env55610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55609_55610 : H12AffineEnvironment.transform 7 68 env55609 = env55610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env55609 == env55610) = true)

theorem identity55610 : scanCanonicalize (H12AffineFastState.compose env55610 (packedSelected [2,3,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55610 : packedSelected [2,3,10,12] rootPS < 2^1333 := by decide +kernel

def env55611 : List Nat := [2,4,8,16,7,64,128,68,17,85,1,17,73,0,16,5,80,133,21,17,17,153,16,5,129,1,77,0,1,7,68,17,68,65,81,80]

theorem envBound55611 : H12AffineFastState.Bounded env55611 := by
  intro p hp
  have h : env55611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55610_55611 : H12AffineEnvironment.transform 10 1 env55610 = env55611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55610 == env55611) = true)

theorem identity55611 : scanCanonicalize (H12AffineFastState.compose env55611 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55611 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env55612 : List Nat := [2,2,8,16,1,64,128,66,17,83,1,17,73,0,16,3,80,131,19,17,17,153,16,3,129,1,75,0,1,1,66,17,66,65,81,80]

theorem envBound55612 : H12AffineFastState.Bounded env55612 := by
  intro p hp
  have h : env55612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55611_55612 : H12AffineEnvironment.transform 1 2 env55611 = env55612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55611 == env55612) = true)

theorem identity55612 : scanCanonicalize (H12AffineFastState.compose env55612 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55612 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55613 : List Nat := [2,2,8,1,1,64,128,66,0,66,1,0,73,0,1,3,65,131,2,0,0,136,1,3,129,1,75,0,1,1,66,0,66,65,64,65]

theorem envBound55613 : H12AffineFastState.Bounded env55613 := by
  intro p hp
  have h : env55613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55612_55613 : H12AffineEnvironment.transform 3 1 env55612 = env55613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55612 == env55613) = true)

theorem identity55613 : scanCanonicalize (H12AffineFastState.compose env55613 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound55613 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55614 : List Nat := [2,2,8,1,1,64,73,66,0,66,1,0,73,0,1,3,65,74,2,0,0,65,1,3,72,1,75,0,1,1,66,0,66,65,64,65]

theorem envBound55614 : H12AffineFastState.Bounded env55614 := by
  intro p hp
  have h : env55614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55613_55614 : H12AffineEnvironment.transform 6 73 env55613 = env55614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env55613 == env55614) = true)

theorem identity55614 : scanCanonicalize (H12AffineFastState.compose env55614 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound55614 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55615 : List Nat := [2,2,8,1,1,10,3,8,0,8,1,0,3,0,1,3,11,0,2,0,0,11,1,3,2,1,1,0,1,1,8,0,8,11,10,11]

theorem envBound55615 : H12AffineFastState.Bounded env55615 := by
  intro p hp
  have h : env55615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55614_55615 : H12AffineEnvironment.transform 5 10 env55614 = env55615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env55614 == env55615) = true)

theorem identity55615 : scanCanonicalize (H12AffineFastState.compose env55615 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55615 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env55616 : List Nat := [2,2,3,1,1,1,3,3,0,3,1,0,3,0,1,3,0,0,2,0,0,0,1,3,2,1,1,0,1,1,3,0,3,0,1,0]

theorem envBound55616 : H12AffineFastState.Bounded env55616 := by
  intro p hp
  have h : env55616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55615_55616 : H12AffineEnvironment.transform 2 3 env55615 = env55616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55615 == env55616) = true)

def env55617 : List Nat := [2,4,8,16,7,64,128,256,341,273,2048,17,8192,0,8477,8457,81,8585,337,8476,17,477,17,8457,8392,0,265,1,1,2371,8205,17,256,8201,81,276]

theorem envBound55617 : H12AffineFastState.Bounded env55617 := by
  intro p hp
  have h : env55617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55607_55617 : H12AffineEnvironment.transform 15 8457 env55607 = env55617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8457 env55607 == env55617) = true)

theorem identity55617 : scanCanonicalize (H12AffineFastState.compose env55617 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound55617 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55618 : List Nat := [2,4,8,16,7,64,128,256,341,273,2048,17,8,0,277,257,81,385,337,276,17,477,17,257,192,0,265,1,1,2371,5,17,256,1,81,276]

theorem envBound55618 : H12AffineFastState.Bounded env55618 := by
  intro p hp
  have h : env55618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55617_55618 : H12AffineEnvironment.transform 12 8 env55617 = env55618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env55617 == env55618) = true)

theorem identity55618 : scanCanonicalize (H12AffineFastState.compose env55618 (packedSelected [0,2,5,7,8,11,15,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound55618 : packedSelected [0,2,5,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env55619 : List Nat := [2,4,8,16,7,64,128,256,341,273,65,17,8,0,277,257,81,385,337,276,17,477,17,257,192,0,265,1,1,258,5,17,256,1,81,276]

theorem envBound55619 : H12AffineFastState.Bounded env55619 := by
  intro p hp
  have h : env55619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55618_55619 : H12AffineEnvironment.transform 10 65 env55618 = env55619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env55618 == env55619) = true)

theorem identity55619 : scanCanonicalize (H12AffineFastState.compose env55619 (packedSelected [3,4,8,9,10,12,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55619 : packedSelected [3,4,8,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env55620 : List Nat := [2,4,8,16,7,17,128,256,260,273,16,17,8,0,277,257,0,385,256,276,17,396,17,257,145,0,265,1,1,258,5,17,256,1,0,276]

theorem envBound55620 : H12AffineFastState.Bounded env55620 := by
  intro p hp
  have h : env55620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55619_55620 : H12AffineEnvironment.transform 5 17 env55619 = env55620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55619 == env55620) = true)

theorem identity55620 : scanCanonicalize (H12AffineFastState.compose env55620 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound55620 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env55621 : List Nat := [2,4,8,16,7,17,128,24,28,9,16,17,8,0,13,25,0,153,24,12,17,148,17,25,145,0,17,1,1,26,5,17,24,1,0,12]

theorem envBound55621 : H12AffineFastState.Bounded env55621 := by
  intro p hp
  have h : env55621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55620_55621 : H12AffineEnvironment.transform 7 24 env55620 = env55621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env55620 == env55621) = true)

theorem identity55621 : scanCanonicalize (H12AffineFastState.compose env55621 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55621 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env55622 : List Nat := [2,4,8,16,7,17,9,24,28,9,16,17,8,0,13,25,0,16,24,12,17,29,17,25,24,0,17,1,1,26,5,17,24,1,0,12]

theorem envBound55622 : H12AffineFastState.Bounded env55622 := by
  intro p hp
  have h : env55622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55621_55622 : H12AffineEnvironment.transform 6 9 env55621 = env55622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55621 == env55622) = true)

theorem identity55622 : scanCanonicalize (H12AffineFastState.compose env55622 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55622 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55623 : List Nat := [2,4,8,7,7,6,9,15,11,9,7,6,8,0,13,14,0,7,15,12,6,10,6,14,15,0,6,1,1,13,5,6,15,1,0,12]

theorem envBound55623 : H12AffineFastState.Bounded env55623 := by
  intro p hp
  have h : env55623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55622_55623 : H12AffineEnvironment.transform 3 7 env55622 = env55623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55622 == env55623) = true)

theorem identity55623 : scanCanonicalize (H12AffineFastState.compose env55623 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55624 : List Nat := [2,4,5,7,7,6,4,2,6,4,7,6,5,0,0,3,0,7,2,1,6,7,6,3,2,0,6,1,1,0,5,6,2,1,0,1]

theorem envBound55624 : H12AffineFastState.Bounded env55624 := by
  intro p hp
  have h : env55624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55623_55624 : H12AffineEnvironment.transform 2 5 env55623 = env55624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55623 == env55624) = true)

theorem identity55624 : scanCanonicalize (H12AffineFastState.compose env55624 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55625 : List Nat := [2,2,3,1,1,0,2,2,0,2,1,0,3,0,0,3,0,1,2,1,0,1,0,3,2,0,0,1,1,0,3,0,2,1,0,1]

theorem envBound55625 : H12AffineFastState.Bounded env55625 := by
  intro p hp
  have h : env55625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55624_55625 : H12AffineEnvironment.transform 1 2 env55624 = env55625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55624 == env55625) = true)

theorem identity55625 : scanCanonicalize (H12AffineFastState.compose env55625 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55626 : List Nat := [1,1,0,1,1,0,1,1,0,1,1,0,0,0,0,0,0,1,1,1,0,1,0,0,1,0,0,1,1,0,0,0,1,1,0,1]

theorem envBound55626 : H12AffineFastState.Bounded env55626 := by
  intro p hp
  have h : env55626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55625_55626 : H12AffineEnvironment.transform 0 1 env55625 = env55626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55625 == env55626) = true)

def env55627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4096,477,74047,69649,13768,78894,4414,74814,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound55627 : H12AffineFastState.Bounded env55627 := by
  intro p hp
  have h : env55627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55543_55627 : H12AffineEnvironment.transform 17 65665 env55543 = env55627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55543 == env55627) = true)

theorem identity55627 : scanCanonicalize (H12AffineFastState.compose env55627 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound55627 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,81,477,74047,65600,9625,74879,367,74814,1296,77083,8205,1280,256,65831,1344,1808]

theorem envBound55628 : H12AffineFastState.Bounded env55628 := by
  intro p hp
  have h : env55628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55627_55628 : H12AffineEnvironment.transform 11 81 env55627 = env55628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env55627 == env55628) = true)

def env55629 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,81,477,74047,65600,9625,74879,367,74814,1296,77083,8205,1280,256,65831,1344,1092]

theorem envBound55629 : H12AffineFastState.Bounded env55629 := by
  intro p hp
  have h : env55629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55628_55629 : H12AffineEnvironment.transform 8 340 env55628 = env55629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env55628 == env55629) = true)

def env55630 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9228,65536,74798,65665,273,9229,17,413,74047,65536,9625,74815,303,74814,1296,77083,8205,1280,256,65831,1280,1028]

theorem envBound55630 : H12AffineFastState.Bounded env55630 := by
  intro p hp
  have h : env55630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55629_55630 : H12AffineEnvironment.transform 5 0 env55629 = env55630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55629 == env55630) = true)

theorem identity55630 : scanCanonicalize (H12AffineFastState.compose env55630 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9240) := by decide +kernel

theorem selectedBound55630 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55631 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9228,9240,54,9369,273,9229,17,413,1319,9240,9625,39,303,38,1296,2307,8205,1280,256,9535,1280,1028]

theorem envBound55631 : H12AffineFastState.Bounded env55631 := by
  intro p hp
  have h : env55631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55630_55631 : H12AffineEnvironment.transform 15 9240 env55630 = env55631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9240 env55630 == env55631) = true)

def env55632 : List Nat := [2,4,8,16,32,0,128,256,276,304,2048,17,8192,33,8508,8488,54,8617,273,8509,17,413,23,8488,8361,39,303,38,32,2307,8205,48,256,8207,48,308]

theorem envBound55632 : H12AffineFastState.Bounded env55632 := by
  intro p hp
  have h : env55632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55631_55632 : H12AffineEnvironment.transform 9 304 env55631 = env55632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env55631 == env55632) = true)

theorem identity55632 : scanCanonicalize (H12AffineFastState.compose env55632 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55632 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env55633 : List Nat := [2,4,8,16,32,0,128,36,48,20,2048,17,8192,33,8216,8204,54,8333,53,8217,17,185,23,8204,8361,39,11,38,32,2087,8205,48,36,8207,48,16]

theorem envBound55633 : H12AffineFastState.Bounded env55633 := by
  intro p hp
  have h : env55633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55632_55633 : H12AffineEnvironment.transform 7 36 env55632 = env55633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55632 == env55633) = true)

theorem identity55633 : scanCanonicalize (H12AffineFastState.compose env55633 (packedSelected [0,1,3,4,7,9,11,13,16,18,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound55633 : packedSelected [0,1,3,4,7,9,11,13,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55634 : List Nat := [2,4,8,16,32,0,128,36,48,20,2048,17,2105,33,2081,2101,54,2228,53,2080,17,185,23,2101,2192,39,11,38,32,2087,2100,48,36,2102,48,16]

theorem envBound55634 : H12AffineFastState.Bounded env55634 := by
  intro p hp
  have h : env55634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55633_55634 : H12AffineEnvironment.transform 12 2105 env55633 = env55634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env55633 == env55634) = true)

theorem identity55634 : scanCanonicalize (H12AffineFastState.compose env55634 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound55634 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55635 : List Nat := [2,4,8,16,32,0,31,36,48,20,2048,17,2105,33,2081,2101,54,2091,53,2080,17,38,23,2101,2063,39,11,38,32,2087,2100,48,36,2102,48,16]

theorem envBound55635 : H12AffineFastState.Bounded env55635 := by
  intro p hp
  have h : env55635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55634_55635 : H12AffineEnvironment.transform 6 31 env55634 = env55635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env55634 == env55635) = true)

theorem identity55635 : scanCanonicalize (H12AffineFastState.compose env55635 (packedSelected [1,2,3,4,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound55635 : packedSelected [1,2,3,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env55636 : List Nat := [2,4,8,16,28,0,31,24,12,20,2048,17,2053,29,2077,2057,10,2071,9,2076,17,26,23,2057,2063,27,11,26,28,2075,2056,12,24,2058,12,16]

theorem envBound55636 : H12AffineFastState.Bounded env55636 := by
  intro p hp
  have h : env55636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55635_55636 : H12AffineEnvironment.transform 4 28 env55635 = env55636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env55635 == env55636) = true)

theorem identity55636 : scanCanonicalize (H12AffineFastState.compose env55636 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound55636 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env55637 : List Nat := [2,4,8,16,28,0,31,24,12,20,16,17,21,29,13,25,10,7,9,12,17,26,23,25,31,27,11,26,28,11,24,12,24,26,12,16]

theorem envBound55637 : H12AffineFastState.Bounded env55637 := by
  intro p hp
  have h : env55637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55636_55637 : H12AffineEnvironment.transform 10 16 env55636 = env55637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env55636 == env55637) = true)

theorem identity55637 : scanCanonicalize (H12AffineFastState.compose env55637 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55638 : List Nat := [2,4,8,6,10,0,9,14,12,2,6,7,3,11,13,15,10,7,9,12,7,12,1,15,9,13,11,12,10,11,14,12,14,12,12,6]

theorem envBound55638 : H12AffineFastState.Bounded env55638 := by
  intro p hp
  have h : env55638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55637_55638 : H12AffineEnvironment.transform 3 6 env55637 = env55638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55637 == env55638) = true)

theorem identity55638 : scanCanonicalize (H12AffineFastState.compose env55638 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55638 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55639 : List Nat := [2,4,4,6,6,0,5,2,0,2,6,7,3,7,1,3,6,7,5,0,7,0,1,3,5,1,7,0,6,7,2,0,2,0,0,6]

theorem envBound55639 : H12AffineFastState.Bounded env55639 := by
  intro p hp
  have h : env55639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55638_55639 : H12AffineEnvironment.transform 2 4 env55638 = env55639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55638 == env55639) = true)

def env55640 : List Nat := [2,4,8,16,32,0,128,256,276,305,2048,17,8192,32,8509,8489,54,8616,273,8508,17,413,22,8489,8360,39,303,38,33,2307,8205,49,256,8206,49,309]

theorem envBound55640 : H12AffineFastState.Bounded env55640 := by
  intro p hp
  have h : env55640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55631_55640 : H12AffineEnvironment.transform 9 305 env55631 = env55640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env55631 == env55640) = true)

theorem identity55640 : scanCanonicalize (H12AffineFastState.compose env55640 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound55640 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env55641 : List Nat := [2,4,8,16,32,0,128,35,55,18,2048,17,8192,32,8222,8202,54,8331,50,8223,17,190,22,8202,8360,39,12,38,33,2080,8205,49,35,8206,49,22]

theorem envBound55641 : H12AffineFastState.Bounded env55641 := by
  intro p hp
  have h : env55641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55640_55641 : H12AffineEnvironment.transform 7 35 env55640 = env55641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env55640 == env55641) = true)

theorem identity55641 : scanCanonicalize (H12AffineFastState.compose env55641 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 30) := by decide +kernel

theorem selectedBound55641 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env55642 : List Nat := [2,4,8,16,32,0,128,35,55,18,2048,17,30,32,0,20,54,149,50,1,17,190,22,20,182,39,12,38,33,2080,19,49,35,16,49,22]

theorem envBound55642 : H12AffineFastState.Bounded env55642 := by
  intro p hp
  have h : env55642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55641_55642 : H12AffineEnvironment.transform 12 30 env55641 = env55642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 30 env55641 == env55642) = true)

theorem identity55642 : scanCanonicalize (H12AffineFastState.compose env55642 (packedSelected [0,1,7,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound55642 : packedSelected [0,1,7,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env55643 : List Nat := [2,4,8,16,32,0,46,35,55,18,2048,17,30,32,0,20,54,59,50,1,17,16,22,20,24,39,12,38,33,2080,19,49,35,16,49,22]

theorem envBound55643 : H12AffineFastState.Bounded env55643 := by
  intro p hp
  have h : env55643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55642_55643 : H12AffineEnvironment.transform 6 46 env55642 = env55643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env55642 == env55643) = true)

theorem identity55643 : scanCanonicalize (H12AffineFastState.compose env55643 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55643 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55644 : List Nat := [2,4,8,16,22,0,24,21,1,18,2048,17,30,22,0,20,0,13,4,1,17,16,22,20,24,17,12,16,23,2070,19,7,21,16,7,22]

theorem envBound55644 : H12AffineFastState.Bounded env55644 := by
  intro p hp
  have h : env55644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55643_55644 : H12AffineEnvironment.transform 4 22 env55643 = env55644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55643 == env55644) = true)

theorem identity55644 : scanCanonicalize (H12AffineFastState.compose env55644 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound55644 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env55645 : List Nat := [2,4,8,16,22,0,24,21,1,18,12,17,30,22,0,20,0,13,4,1,17,16,22,20,24,17,12,16,23,26,19,7,21,16,7,22]

theorem envBound55645 : H12AffineFastState.Bounded env55645 := by
  intro p hp
  have h : env55645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55644_55645 : H12AffineEnvironment.transform 10 12 env55644 = env55645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env55644 == env55645) = true)

theorem identity55645 : scanCanonicalize (H12AffineFastState.compose env55645 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55645 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55646 : List Nat := [2,4,8,13,11,0,5,8,1,15,12,12,3,11,0,9,0,13,4,1,12,13,11,9,5,12,12,13,10,7,14,7,8,13,7,11]

theorem envBound55646 : H12AffineFastState.Bounded env55646 := by
  intro p hp
  have h : env55646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55645_55646 : H12AffineEnvironment.transform 3 13 env55645 = env55646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55645 == env55646) = true)

def env55647 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9229,65536,74799,65665,273,9228,16,412,74047,65537,9625,74814,302,74814,1296,77083,8205,1280,256,65831,1281,1029]

theorem envBound55647 : H12AffineFastState.Bounded env55647 := by
  intro p hp
  have h : env55647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55629_55647 : H12AffineEnvironment.transform 5 1 env55629 = env55647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55629 == env55647) = true)

theorem identity55647 : scanCanonicalize (H12AffineFastState.compose env55647 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 273) := by decide +kernel

theorem selectedBound55647 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55648 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9229,273,9534,400,273,9228,16,412,8238,272,9625,9519,302,9519,1296,11274,8205,1280,256,54,1281,1029]

theorem envBound55648 : H12AffineFastState.Bounded env55648 := by
  intro p hp
  have h : env55648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55647_55648 : H12AffineEnvironment.transform 15 273 env55647 = env55648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 273 env55647 == env55648) = true)

def env55649 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,56,1297,1077,273,1286,400,273,1076,16,412,22,272,1441,1303,302,1303,1296,3122,53,1280,256,54,1281,1029]

theorem envBound55649 : H12AffineFastState.Bounded env55649 := by
  intro p hp
  have h : env55649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55648_55649 : H12AffineEnvironment.transform 12 56 env55648 = env55649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env55648 == env55649) = true)

theorem identity55649 : scanCanonicalize (H12AffineFastState.compose env55649 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(9+1) ^^^ 311) := by decide +kernel

theorem selectedBound55649 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env55650 : List Nat := [2,4,8,16,32,1,128,256,277,311,2048,16,56,38,258,273,49,400,273,259,16,412,22,272,150,32,302,32,39,2309,53,55,256,54,54,306]

theorem envBound55650 : H12AffineFastState.Bounded env55650 := by
  intro p hp
  have h : env55650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55649_55650 : H12AffineEnvironment.transform 9 311 env55649 = env55650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 311 env55649 == env55650) = true)

theorem identity55650 : scanCanonicalize (H12AffineFastState.compose env55650 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound55650 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55651 : List Nat := [2,4,8,16,32,1,128,53,32,2,2048,16,56,38,55,36,49,165,36,54,16,169,22,37,150,32,27,32,39,2096,53,55,53,54,54,7]

theorem envBound55651 : H12AffineFastState.Bounded env55651 := by
  intro p hp
  have h : env55651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55650_55651 : H12AffineEnvironment.transform 7 53 env55650 = env55651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env55650 == env55651) = true)

theorem identity55651 : scanCanonicalize (H12AffineFastState.compose env55651 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound55651 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env55652 : List Nat := [2,4,8,16,32,1,128,53,32,2,12,16,56,38,55,36,49,165,36,54,16,169,22,37,150,32,27,32,39,60,53,55,53,54,54,7]

theorem envBound55652 : H12AffineFastState.Bounded env55652 := by
  intro p hp
  have h : env55652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55651_55652 : H12AffineEnvironment.transform 10 12 env55651 = env55652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env55651 == env55652) = true)

theorem identity55652 : scanCanonicalize (H12AffineFastState.compose env55652 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55652 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55653 : List Nat := [2,2,8,16,32,1,128,51,32,2,10,16,56,32,49,34,49,163,34,48,16,169,16,35,144,32,27,32,33,58,51,49,51,48,48,1]

theorem envBound55653 : H12AffineFastState.Bounded env55653 := by
  intro p hp
  have h : env55653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55652_55653 : H12AffineEnvironment.transform 1 2 env55652 = env55653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55652 == env55653) = true)

theorem identity55653 : scanCanonicalize (H12AffineFastState.compose env55653 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55653 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55654 : List Nat := [2,2,8,16,32,1,9,51,32,2,10,16,56,32,49,34,49,42,34,48,16,32,16,35,25,32,27,32,33,58,51,49,51,48,48,1]

theorem envBound55654 : H12AffineFastState.Bounded env55654 := by
  intro p hp
  have h : env55654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55653_55654 : H12AffineEnvironment.transform 6 9 env55653 = env55654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55653 == env55654) = true)

theorem identity55654 : scanCanonicalize (H12AffineFastState.compose env55654 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55654 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env55655 : List Nat := [2,2,8,16,16,1,9,3,16,2,10,16,8,16,1,18,1,26,18,0,16,16,16,19,25,16,27,16,17,10,3,1,3,0,0,1]

theorem envBound55655 : H12AffineFastState.Bounded env55655 := by
  intro p hp
  have h : env55655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55654_55655 : H12AffineEnvironment.transform 4 16 env55654 = env55655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55654 == env55655) = true)

theorem identity55655 : scanCanonicalize (H12AffineFastState.compose env55655 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55656 : List Nat := [2,2,8,1,1,1,9,3,1,2,10,1,8,1,1,3,1,11,3,0,1,1,1,2,8,1,10,1,0,10,3,1,3,0,0,1]

theorem envBound55656 : H12AffineFastState.Bounded env55656 := by
  intro p hp
  have h : env55656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55655_55656 : H12AffineEnvironment.transform 3 1 env55655 = env55656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55655 == env55656) = true)

theorem identity55656 : scanCanonicalize (H12AffineFastState.compose env55656 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55657 : List Nat := [2,2,2,1,1,1,3,3,1,2,0,1,2,1,1,3,1,1,3,0,1,1,1,2,2,1,0,1,0,0,3,1,3,0,0,1]

theorem envBound55657 : H12AffineFastState.Bounded env55657 := by
  intro p hp
  have h : env55657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55656_55657 : H12AffineEnvironment.transform 2 2 env55656 = env55657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55656 == env55657) = true)

def env55658 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,57,1297,1076,273,1287,400,273,1077,16,412,23,272,1440,1302,302,1302,1296,3123,52,1280,256,54,1281,1029]

theorem envBound55658 : H12AffineFastState.Bounded env55658 := by
  intro p hp
  have h : env55658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55648_55658 : H12AffineEnvironment.transform 12 57 env55648 = env55658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env55648 == env55658) = true)

theorem identity55658 : scanCanonicalize (H12AffineFastState.compose env55658 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound55658 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env55659 : List Nat := [2,4,8,16,32,1,128,256,277,304,2048,16,57,33,260,273,55,400,273,261,16,412,23,272,144,38,302,38,32,2307,52,48,256,54,49,309]

theorem envBound55659 : H12AffineFastState.Bounded env55659 := by
  intro p hp
  have h : env55659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55658_55659 : H12AffineEnvironment.transform 9 304 env55658 = env55659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env55658 == env55659) = true)

theorem identity55659 : scanCanonicalize (H12AffineFastState.compose env55659 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55659 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55660 : List Nat := [2,4,8,16,32,1,128,4,17,52,2048,16,57,33,0,21,55,148,21,1,16,152,23,20,144,38,42,38,32,2055,52,48,4,54,49,49]

theorem envBound55660 : H12AffineFastState.Bounded env55660 := by
  intro p hp
  have h : env55660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55659_55660 : H12AffineEnvironment.transform 7 4 env55659 = env55660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55659 == env55660) = true)

theorem identity55660 : scanCanonicalize (H12AffineFastState.compose env55660 (packedSelected [2,4,9,10,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound55660 : packedSelected [2,4,9,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env55661 : List Nat := [2,4,8,16,32,1,128,4,17,52,164,16,57,33,0,21,55,148,21,1,16,152,23,20,144,38,42,38,32,163,52,48,4,54,49,49]

theorem envBound55661 : H12AffineFastState.Bounded env55661 := by
  intro p hp
  have h : env55661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55660_55661 : H12AffineEnvironment.transform 10 164 env55660 = env55661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env55660 == env55661) = true)

theorem identity55661 : scanCanonicalize (H12AffineFastState.compose env55661 (packedSelected [1,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55661 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env55662 : List Nat := [2,3,8,16,32,1,128,3,17,51,163,16,57,33,0,18,48,147,18,1,16,152,16,19,144,33,42,33,32,163,51,48,3,49,49,49]

theorem envBound55662 : H12AffineFastState.Bounded env55662 := by
  intro p hp
  have h : env55662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55661_55662 : H12AffineEnvironment.transform 1 3 env55661 = env55662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55661 == env55662) = true)

theorem identity55662 : scanCanonicalize (H12AffineFastState.compose env55662 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55662 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55663 : List Nat := [2,3,8,16,32,1,9,3,17,51,42,16,57,33,0,18,48,26,18,1,16,17,16,19,25,33,42,33,32,42,51,48,3,49,49,49]

theorem envBound55663 : H12AffineFastState.Bounded env55663 := by
  intro p hp
  have h : env55663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55662_55663 : H12AffineEnvironment.transform 6 9 env55662 = env55663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55662 == env55663) = true)

theorem identity55663 : scanCanonicalize (H12AffineFastState.compose env55663 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55663 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55664 : List Nat := [2,3,8,0,32,1,9,3,1,35,42,0,41,33,0,2,32,10,2,1,0,1,0,3,9,33,42,33,32,42,35,32,3,33,33,33]

theorem envBound55664 : H12AffineFastState.Bounded env55664 := by
  intro p hp
  have h : env55664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55663_55664 : H12AffineEnvironment.transform 3 0 env55663 = env55664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55663 == env55664) = true)

def env55665 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,81,477,74047,65600,9625,74879,367,74814,1296,77083,8205,1280,256,65831,1344,1093]

theorem envBound55665 : H12AffineFastState.Bounded env55665 := by
  intro p hp
  have h : env55665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55628_55665 : H12AffineEnvironment.transform 8 341 env55628 = env55665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env55628 == env55665) = true)

def env55666 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9228,65536,74798,65665,273,9229,17,413,74047,65536,9625,74815,303,74814,1296,77083,8205,1280,256,65831,1280,1029]

theorem envBound55666 : H12AffineFastState.Bounded env55666 := by
  intro p hp
  have h : env55666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55665_55666 : H12AffineEnvironment.transform 5 0 env55665 = env55666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55665 == env55666) = true)

theorem identity55666 : scanCanonicalize (H12AffineFastState.compose env55666 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 311) := by decide +kernel

theorem selectedBound55666 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55667 : List Nat := [2,4,8,16,32,0,128,256,277,311,2048,17,8192,38,8507,65536,74009,65665,273,8506,17,413,74047,65536,8366,73992,303,73993,39,75820,8205,55,256,65831,55,306]

theorem envBound55667 : H12AffineFastState.Bounded env55667 := by
  intro p hp
  have h : env55667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55666_55667 : H12AffineEnvironment.transform 9 311 env55666 = env55667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 311 env55666 == env55667) = true)

def env55668 : List Nat := [2,4,8,16,32,0,128,256,277,311,2048,17,24,38,291,65536,65793,65665,273,290,17,413,65831,65536,182,65808,303,65809,39,67636,21,55,256,65831,55,306]

theorem envBound55668 : H12AffineFastState.Bounded env55668 := by
  intro p hp
  have h : env55668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55667_55668 : H12AffineEnvironment.transform 12 24 env55667 = env55668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env55667 == env55668) = true)

theorem identity55668 : scanCanonicalize (H12AffineFastState.compose env55668 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound55668 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55669 : List Nat := [2,4,8,16,32,0,128,35,54,20,2048,17,24,38,0,65536,65570,65665,50,1,17,190,65540,65536,182,65587,12,65586,39,67636,21,55,35,65540,55,17]

theorem envBound55669 : H12AffineFastState.Bounded env55669 := by
  intro p hp
  have h : env55669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55668_55669 : H12AffineEnvironment.transform 7 35 env55668 = env55669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env55668 == env55669) = true)

theorem identity55669 : scanCanonicalize (H12AffineFastState.compose env55669 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55669 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55670 : List Nat := [2,4,8,16,22,0,128,21,0,20,2048,17,24,16,0,65536,65556,65665,4,1,17,136,65540,65536,128,65541,12,65540,17,67586,21,1,21,65540,1,17]

theorem envBound55670 : H12AffineFastState.Bounded env55670 := by
  intro p hp
  have h : env55670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55669_55670 : H12AffineEnvironment.transform 4 22 env55669 = env55670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55669 == env55670) = true)

theorem identity55670 : scanCanonicalize (H12AffineFastState.compose env55670 (packedSelected [0,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound55670 : packedSelected [0,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env55671 : List Nat := [2,4,8,16,22,0,128,21,0,20,2048,17,24,16,0,2202,2190,2075,4,1,17,136,2206,2202,128,2207,12,2206,17,152,21,1,21,2206,1,17]

theorem envBound55671 : H12AffineFastState.Bounded env55671 := by
  intro p hp
  have h : env55671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55670_55671 : H12AffineEnvironment.transform 15 2202 env55670 = env55671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env55670 == env55671) = true)

theorem identity55671 : scanCanonicalize (H12AffineFastState.compose env55671 (packedSelected [2,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound55671 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env55672 : List Nat := [2,4,8,16,22,0,20,21,0,20,2048,17,24,16,0,2062,2074,2075,4,1,17,28,2058,2062,20,2059,12,2058,17,12,21,1,21,2058,1,17]

theorem envBound55672 : H12AffineFastState.Bounded env55672 := by
  intro p hp
  have h : env55672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55671_55672 : H12AffineEnvironment.transform 6 20 env55671 = env55672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env55671 == env55672) = true)

theorem identity55672 : scanCanonicalize (H12AffineFastState.compose env55672 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55672 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55673 : List Nat := [2,4,3,16,22,0,20,21,0,20,2048,17,19,16,0,2053,2065,2064,4,1,17,23,2049,2053,20,2048,7,2049,17,7,21,1,21,2049,1,17]

theorem envBound55673 : H12AffineFastState.Bounded env55673 := by
  intro p hp
  have h : env55673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55672_55673 : H12AffineEnvironment.transform 2 3 env55672 = env55673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55672 == env55673) = true)

theorem identity55673 : scanCanonicalize (H12AffineFastState.compose env55673 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound55673 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55674 : List Nat := [2,4,3,16,22,0,20,21,0,20,6,17,19,16,0,3,23,22,4,1,17,23,7,3,20,6,7,7,17,7,21,1,21,7,1,17]

theorem envBound55674 : H12AffineFastState.Bounded env55674 := by
  intro p hp
  have h : env55674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55673_55674 : H12AffineEnvironment.transform 10 6 env55673 = env55674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env55673 == env55674) = true)

def env55675 : List Nat := [2,4,8,16,32,0,128,256,277,311,2048,17,25,38,290,65536,65792,65665,273,291,17,413,65830,65536,183,65809,303,65808,39,67637,20,55,256,65831,55,306]

theorem envBound55675 : H12AffineFastState.Bounded env55675 := by
  intro p hp
  have h : env55675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55667_55675 : H12AffineEnvironment.transform 12 25 env55667 = env55675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env55667 == env55675) = true)

theorem identity55675 : scanCanonicalize (H12AffineFastState.compose env55675 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55675 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55676 : List Nat := [2,4,8,16,32,0,128,5,16,50,2048,17,25,38,39,65536,65541,65665,20,38,17,152,65571,65536,183,65556,42,65557,39,67637,20,55,5,65570,55,55]

theorem envBound55676 : H12AffineFastState.Bounded env55676 := by
  intro p hp
  have h : env55676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55675_55676 : H12AffineEnvironment.transform 7 5 env55675 = env55676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55675 == env55676) = true)

theorem identity55676 : scanCanonicalize (H12AffineFastState.compose env55676 (packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 36) := by decide +kernel

theorem selectedBound55676 : packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env55677 : List Nat := [2,4,8,16,32,0,128,5,16,50,2048,17,25,38,39,36,33,165,20,38,17,152,7,36,183,48,42,49,39,2065,20,55,5,6,55,55]

theorem envBound55677 : H12AffineFastState.Bounded env55677 := by
  intro p hp
  have h : env55677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55676_55677 : H12AffineEnvironment.transform 15 36 env55676 = env55677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36 env55676 == env55677) = true)

theorem identity55677 : scanCanonicalize (H12AffineFastState.compose env55677 (packedSelected [1,12] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound55677 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env55678 : List Nat := [2,4,8,16,32,0,128,5,16,50,158,17,25,38,39,36,33,165,20,38,17,152,7,36,183,48,42,49,39,143,20,55,5,6,55,55]

theorem envBound55678 : H12AffineFastState.Bounded env55678 := by
  intro p hp
  have h : env55678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55677_55678 : H12AffineEnvironment.transform 10 158 env55677 = env55678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env55677 == env55678) = true)

theorem identity55678 : scanCanonicalize (H12AffineFastState.compose env55678 (packedSelected [2,3,4,5,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55678 : packedSelected [2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55679 : List Nat := [2,4,3,16,32,0,128,5,16,50,149,17,18,38,39,36,33,165,20,38,17,147,7,36,183,48,33,49,39,132,20,55,5,6,55,55]

theorem envBound55679 : H12AffineFastState.Bounded env55679 := by
  intro p hp
  have h : env55679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55678_55679 : H12AffineEnvironment.transform 2 3 env55678 = env55679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55678 == env55679) = true)

theorem identity55679 : scanCanonicalize (H12AffineFastState.compose env55679 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55679 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env55680 : List Nat := [2,4,3,16,32,0,3,5,16,50,22,17,18,38,39,36,33,38,20,38,17,16,7,36,52,48,33,49,39,7,20,55,5,6,55,55]

theorem envBound55680 : H12AffineFastState.Bounded env55680 := by
  intro p hp
  have h : env55680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55679_55680 : H12AffineEnvironment.transform 6 3 env55679 = env55680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55679 == env55680) = true)

theorem identity55680 : scanCanonicalize (H12AffineFastState.compose env55680 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55680 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55681 : List Nat := [2,4,3,16,1,0,3,5,16,19,22,17,18,7,6,5,0,7,20,7,17,16,7,5,21,17,0,16,6,7,20,22,5,6,22,22]

theorem envBound55681 : H12AffineFastState.Bounded env55681 := by
  intro p hp
  have h : env55681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55680_55681 : H12AffineEnvironment.transform 4 1 env55680 = env55681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55680 == env55681) = true)

theorem identity55681 : scanCanonicalize (H12AffineFastState.compose env55681 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55681 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55682 : List Nat := [2,3,3,16,1,0,3,2,16,19,17,17,18,0,1,2,0,0,19,0,17,16,0,2,18,17,0,16,1,0,19,17,2,1,17,17]

theorem envBound55682 : H12AffineFastState.Bounded env55682 := by
  intro p hp
  have h : env55682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55681_55682 : H12AffineEnvironment.transform 1 3 env55681 = env55682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55681 == env55682) = true)

theorem identity55682 : scanCanonicalize (H12AffineFastState.compose env55682 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55683 : List Nat := [0,1,1,16,1,0,1,0,16,17,17,17,16,0,1,0,0,0,17,0,17,16,0,0,16,17,0,16,1,0,17,17,0,1,17,17]

theorem envBound55683 : H12AffineFastState.Bounded env55683 := by
  intro p hp
  have h : env55683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55682_55683 : H12AffineEnvironment.transform 0 0 env55682 = env55683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55682 == env55683) = true)

def env55684 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9229,65536,74799,65665,273,9228,16,412,74047,65537,9625,74814,302,74814,1296,77083,8205,1280,256,65831,1281,1028]

theorem envBound55684 : H12AffineFastState.Bounded env55684 := by
  intro p hp
  have h : env55684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55665_55684 : H12AffineEnvironment.transform 5 1 env55665 = env55684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55665 == env55684) = true)

theorem identity55684 : scanCanonicalize (H12AffineFastState.compose env55684 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 62) := by decide +kernel

theorem selectedBound55684 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55685 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,62,1297,1075,65536,66577,65665,273,1074,16,412,65793,65537,1447,66560,302,66560,1296,68901,51,1280,256,65831,1281,1028]

theorem envBound55685 : H12AffineFastState.Bounded env55685 := by
  intro p hp
  have h : env55685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55684_55685 : H12AffineEnvironment.transform 12 62 env55684 = env55685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 62 env55684 == env55685) = true)

def env55686 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,62,1297,1075,272,1281,401,273,1074,16,412,17,273,1447,1296,302,1296,1296,3125,51,1280,256,55,1281,1028]

theorem envBound55686 : H12AffineFastState.Bounded env55686 := by
  intro p hp
  have h : env55686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55685_55686 : H12AffineEnvironment.transform 15 272 env55685 = env55686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 272 env55685 == env55686) = true)

theorem identity55686 : scanCanonicalize (H12AffineFastState.compose env55686 (packedSelected [13,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound55686 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55687 : List Nat := [2,4,8,16,23,1,128,256,276,1024,2048,16,9,1297,1028,272,1281,401,273,1029,16,412,17,273,1424,1296,281,1296,1296,3074,4,1280,256,0,1281,1028]

theorem envBound55687 : H12AffineFastState.Bounded env55687 := by
  intro p hp
  have h : env55687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55686_55687 : H12AffineEnvironment.transform 4 23 env55686 = env55687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env55686 == env55687) = true)

theorem identity55687 : scanCanonicalize (H12AffineFastState.compose env55687 (packedSelected [0,2,5,7,8,11,13,15,17,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound55687 : packedSelected [0,2,5,7,8,11,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55688 : List Nat := [2,4,8,16,23,1,18,256,276,1024,2048,16,9,1297,1028,272,1281,259,273,1029,16,270,17,273,1282,1296,281,1296,1296,3074,4,1280,256,0,1281,1028]

theorem envBound55688 : H12AffineFastState.Bounded env55688 := by
  intro p hp
  have h : env55688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55687_55688 : H12AffineEnvironment.transform 6 18 env55687 = env55688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env55687 == env55688) = true)

theorem identity55688 : scanCanonicalize (H12AffineFastState.compose env55688 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound55688 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env55689 : List Nat := [2,4,8,16,23,1,18,256,276,1024,13,16,9,1297,1028,272,1281,259,273,1029,16,270,17,273,1282,1296,281,1296,1296,1039,4,1280,256,0,1281,1028]

theorem envBound55689 : H12AffineFastState.Bounded env55689 := by
  intro p hp
  have h : env55689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55688_55689 : H12AffineEnvironment.transform 10 13 env55688 = env55689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env55688 == env55689) = true)

theorem identity55689 : scanCanonicalize (H12AffineFastState.compose env55689 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55689 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env55690 : List Nat := [2,4,8,16,23,1,18,256,276,5,13,16,9,276,1,272,260,259,273,0,16,270,17,273,263,277,281,277,277,10,4,261,256,0,260,1]

theorem envBound55690 : H12AffineFastState.Bounded env55690 := by
  intro p hp
  have h : env55690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55689_55690 : H12AffineEnvironment.transform 9 5 env55689 = env55690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55689 == env55690) = true)

theorem identity55690 : scanCanonicalize (H12AffineFastState.compose env55690 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound55690 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env55691 : List Nat := [2,4,8,16,23,1,18,8,28,5,13,16,9,28,1,24,12,11,25,0,16,6,17,25,15,29,17,29,29,10,4,13,8,0,12,1]

theorem envBound55691 : H12AffineFastState.Bounded env55691 := by
  intro p hp
  have h : env55691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55690_55691 : H12AffineEnvironment.transform 7 8 env55690 = env55691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env55690 == env55691) = true)

theorem identity55691 : scanCanonicalize (H12AffineFastState.compose env55691 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55692 : List Nat := [2,4,4,16,23,1,18,4,16,5,1,16,5,16,1,20,0,7,21,0,16,6,17,21,3,17,17,17,17,6,4,1,4,0,0,1]

theorem envBound55692 : H12AffineFastState.Bounded env55692 := by
  intro p hp
  have h : env55692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55691_55692 : H12AffineEnvironment.transform 2 4 env55691 = env55692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55691 == env55692) = true)

theorem identity55692 : scanCanonicalize (H12AffineFastState.compose env55692 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55692 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55693 : List Nat := [2,3,3,16,16,1,18,3,16,2,1,16,2,16,1,19,0,0,18,0,16,1,17,18,3,17,17,17,17,1,3,1,3,0,0,1]

theorem envBound55693 : H12AffineFastState.Bounded env55693 := by
  intro p hp
  have h : env55693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55692_55693 : H12AffineEnvironment.transform 1 3 env55692 = env55693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55692 == env55693) = true)

def env55694 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,62,1297,1075,273,1280,400,273,1074,16,412,16,272,1447,1297,302,1297,1296,3124,51,1280,256,54,1281,1028]

theorem envBound55694 : H12AffineFastState.Bounded env55694 := by
  intro p hp
  have h : env55694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55685_55694 : H12AffineEnvironment.transform 15 273 env55685 = env55694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 273 env55685 == env55694) = true)

theorem identity55694 : scanCanonicalize (H12AffineFastState.compose env55694 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound55694 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55695 : List Nat := [2,4,8,16,32,1,128,51,39,1024,2048,16,62,1058,1075,34,1075,163,34,1074,16,175,16,35,1172,1058,29,1058,1059,3124,51,1075,51,54,1074,1028]

theorem envBound55695 : H12AffineFastState.Bounded env55695 := by
  intro p hp
  have h : env55695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55694_55695 : H12AffineEnvironment.transform 7 51 env55694 = env55695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env55694 == env55695) = true)

theorem identity55695 : scanCanonicalize (H12AffineFastState.compose env55695 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound55695 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env55696 : List Nat := [2,4,8,16,32,1,128,51,39,20,2048,16,62,54,39,34,39,163,34,38,16,175,16,35,128,54,29,54,55,2080,51,39,51,54,38,16]

theorem envBound55696 : H12AffineFastState.Bounded env55696 := by
  intro p hp
  have h : env55696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55695_55696 : H12AffineEnvironment.transform 9 20 env55695 = env55696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env55695 == env55696) = true)

theorem identity55696 : scanCanonicalize (H12AffineFastState.compose env55696 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound55696 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env55697 : List Nat := [2,4,8,16,32,1,128,51,39,20,58,16,62,54,39,34,39,163,34,38,16,175,16,35,128,54,29,54,55,26,51,39,51,54,38,16]

theorem envBound55697 : H12AffineFastState.Bounded env55697 := by
  intro p hp
  have h : env55697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55696_55697 : H12AffineEnvironment.transform 10 58 env55696 = env55697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env55696 == env55697) = true)

theorem identity55697 : scanCanonicalize (H12AffineFastState.compose env55697 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound55697 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env55698 : List Nat := [2,4,8,16,27,1,128,8,28,20,1,16,5,13,28,25,28,152,25,29,16,148,16,24,128,13,29,13,12,26,8,28,8,13,29,16]

theorem envBound55698 : H12AffineFastState.Bounded env55698 := by
  intro p hp
  have h : env55698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55697_55698 : H12AffineEnvironment.transform 4 27 env55697 = env55698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env55697 == env55698) = true)

theorem identity55698 : scanCanonicalize (H12AffineFastState.compose env55698 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55699 : List Nat := [2,4,8,16,27,1,15,8,28,20,1,16,5,13,28,25,28,23,25,29,16,27,16,24,15,13,29,13,12,26,8,28,8,13,29,16]

theorem envBound55699 : H12AffineFastState.Bounded env55699 := by
  intro p hp
  have h : env55699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55698_55699 : H12AffineEnvironment.transform 6 15 env55698 = env55699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55698 == env55699) = true)

def env55700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245633,148801,545089,96347,16876545,750911,256,17006917,1345,525825]

theorem envBound55700 : H12AffineFastState.Bounded env55700 := by
  intro p hp
  have h : env55700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54915_55700 : H12AffineEnvironment.transform 26 17245633 env54915 = env55700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env54915 == env55700) = true)

theorem identity55700 : scanCanonicalize (H12AffineFastState.compose env55700 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound55700 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86519,209262,17245633,148801,74814,96347,16876545,131136,256,17006917,1345,95102]

theorem envBound55701 : H12AffineFastState.Bounded env55701 := by
  intro p hp
  have h : env55701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55700_55701 : H12AffineEnvironment.transform 18 95615 env55700 = env55701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env55700 == env55701) = true)

def env55702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86519,209262,225345,148801,74814,96347,381313,131136,256,513221,1345,95102]

theorem envBound55702 : H12AffineFastState.Bounded env55702 := by
  intro p hp
  have h : env55702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55701_55702 : H12AffineEnvironment.transform 23 284032 env55701 = env55702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env55701 == env55702) = true)

def env55703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95615,32769,4096,61649,91504,284032,86519,5214,21873,90225,74814,96347,381313,75120,256,324085,1345,95102]

theorem envBound55703 : H12AffineFastState.Bounded env55703 := by
  intro p hp
  have h : env55703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55702_55703 : H12AffineEnvironment.transform 16 75056 env55702 = env55703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env55702 == env55703) = true)

def env55704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1375,32769,4096,61649,5456,284032,8663,5214,21873,4177,21534,2171,303521,21840,256,324085,1345,862]

theorem envBound55704 : H12AffineFastState.Bounded env55704 := by
  intro p hp
  have h : env55704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55703_55704 : H12AffineEnvironment.transform 15 28704 env55703 = env55704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env55703 == env55704) = true)

def env55705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1374,32769,4096,61649,5457,284032,8662,5214,21873,4176,21535,2170,303520,21841,256,324085,1345,863]

theorem envBound55705 : H12AffineFastState.Bounded env55705 := by
  intro p hp
  have h : env55705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55703_55705 : H12AffineEnvironment.transform 15 28705 env55703 = env55705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env55703 == env55705) = true)

theorem identity55705 : scanCanonicalize (H12AffineFastState.compose env55705 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound55705 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55706 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21582,262144,1025,32769,4096,61649,5134,283871,8329,5214,21550,4176,21535,2170,303359,21518,95,323754,1054,512]

theorem envBound55706 : H12AffineFastState.Bounded env55706 := by
  intro p hp
  have h : env55706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55705_55706 : H12AffineEnvironment.transform 7 95 env55705 = env55706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env55705 == env55706) = true)

theorem identity55706 : scanCanonicalize (H12AffineFastState.compose env55706 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound55706 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55707 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21582,5357,1025,32769,4096,61649,5134,16434,8329,5214,21550,4176,21535,2170,46098,21518,95,58439,1054,512]

theorem envBound55707 : H12AffineFastState.Bounded env55707 := by
  intro p hp
  have h : env55707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55706_55707 : H12AffineEnvironment.transform 17 5357 env55706 = env55707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env55706 == env55707) = true)

theorem identity55707 : scanCanonicalize (H12AffineFastState.compose env55707 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound55707 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55708 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25677,28705,21582,5357,1025,25676,4096,5276,5134,16434,8329,5214,21550,4176,21535,2170,20575,21518,95,10,1054,512]

theorem envBound55708 : H12AffineFastState.Bounded env55708 := by
  intro p hp
  have h : env55708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55707_55708 : H12AffineEnvironment.transform 14 25677 env55707 = env55708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env55707 == env55708) = true)

theorem identity55708 : scanCanonicalize (H12AffineFastState.compose env55708 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55708 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55709 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25628,28705,21535,5308,1025,25629,4096,5276,5134,16434,8329,5135,21550,4097,21535,2091,20494,21518,14,10,1054,512]

theorem envBound55709 : H12AffineFastState.Bounded env55709 := by
  intro p hp
  have h : env55709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55708_55709 : H12AffineEnvironment.transform 5 17 env55708 = env55709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55708 == env55709) = true)

theorem identity55709 : scanCanonicalize (H12AffineFastState.compose env55709 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55709 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55710 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,16384,24601,28705,20506,4281,4,24600,4096,4249,4107,16434,8329,4106,20523,4097,20506,2091,20494,20491,14,10,27,512]

theorem envBound55710 : H12AffineFastState.Bounded env55710 := by
  intro p hp
  have h : env55710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55709_55710 : H12AffineEnvironment.transform 9 5 env55709 = env55710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55709 == env55710) = true)

theorem identity55710 : scanCanonicalize (H12AffineFastState.compose env55710 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound55710 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55711 : List Nat := [2,4,8,16,32,17,128,14,512,5,2048,4096,8192,0,8217,12321,4122,4281,4,8216,4096,4249,4107,50,8329,4106,4139,4097,4122,2091,4110,4107,14,10,27,512]

theorem envBound55711 : H12AffineFastState.Bounded env55711 := by
  intro p hp
  have h : env55711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55710_55711 : H12AffineEnvironment.transform 13 0 env55710 = env55711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env55710 == env55711) = true)

theorem identity55711 : scanCanonicalize (H12AffineFastState.compose env55711 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound55711 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55712 : List Nat := [2,4,8,16,32,17,128,14,512,5,649,4096,8192,0,8217,12321,4122,4281,4,8216,4096,4249,4107,50,8329,4106,4139,4097,4122,674,4110,4107,14,10,27,512]

theorem envBound55712 : H12AffineFastState.Bounded env55712 := by
  intro p hp
  have h : env55712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55711_55712 : H12AffineEnvironment.transform 10 649 env55711 = env55712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env55711 == env55712) = true)

theorem identity55712 : scanCanonicalize (H12AffineFastState.compose env55712 (packedSelected [10,15] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound55712 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env55713 : List Nat := [2,4,8,16,32,17,128,14,512,5,649,555,8192,0,8217,8714,561,658,4,8216,555,690,544,50,8329,545,512,554,561,674,549,544,14,10,27,512]

theorem envBound55713 : H12AffineFastState.Bounded env55713 := by
  intro p hp
  have h : env55713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55712_55713 : H12AffineEnvironment.transform 11 555 env55712 = env55713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env55712 == env55713) = true)

theorem identity55713 : scanCanonicalize (H12AffineFastState.compose env55713 (packedSelected [4,5,7,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound55713 : packedSelected [4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55714 : List Nat := [2,4,8,16,32,17,128,14,61,5,180,22,8192,0,8217,8247,12,175,4,8216,22,143,29,50,8329,28,61,23,12,159,24,29,14,10,27,61]

theorem envBound55714 : H12AffineFastState.Bounded env55714 := by
  intro p hp
  have h : env55714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55713_55714 : H12AffineEnvironment.transform 8 61 env55713 = env55714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env55713 == env55714) = true)

theorem identity55714 : scanCanonicalize (H12AffineFastState.compose env55714 (packedSelected [1,2,3,4,5,7,8,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55714 : packedSelected [1,2,3,4,5,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env55715 : List Nat := [2,4,8,7,32,6,128,14,42,5,163,1,8192,0,8206,8224,12,175,4,8207,1,143,10,37,8329,11,42,0,12,136,15,10,14,10,12,42]

theorem envBound55715 : H12AffineFastState.Bounded env55715 := by
  intro p hp
  have h : env55715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55714_55715 : H12AffineEnvironment.transform 3 7 env55714 = env55715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55714 == env55715) = true)

theorem identity55715 : scanCanonicalize (H12AffineFastState.compose env55715 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55715 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55716 : List Nat := [2,4,8,7,32,6,128,14,42,5,163,1,40,0,38,8,12,175,4,39,1,143,10,37,161,11,42,0,12,136,15,10,14,10,12,42]

theorem envBound55716 : H12AffineFastState.Bounded env55716 := by
  intro p hp
  have h : env55716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55715_55716 : H12AffineEnvironment.transform 12 40 env55715 = env55716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55715 == env55716) = true)

theorem identity55716 : scanCanonicalize (H12AffineFastState.compose env55716 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55716 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env55717 : List Nat := [2,4,8,7,32,6,9,14,42,5,42,1,40,0,38,8,12,38,4,39,1,6,10,37,40,11,42,0,12,1,15,10,14,10,12,42]

theorem envBound55717 : H12AffineFastState.Bounded env55717 := by
  intro p hp
  have h : env55717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55716_55717 : H12AffineEnvironment.transform 6 9 env55716 = env55717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55716 == env55717) = true)

theorem identity55717 : scanCanonicalize (H12AffineFastState.compose env55717 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55718 : List Nat := [2,4,5,7,32,6,4,3,39,5,39,1,37,0,38,5,1,38,4,39,1,6,7,37,37,6,39,0,1,1,2,7,3,7,1,39]

theorem envBound55718 : H12AffineFastState.Bounded env55718 := by
  intro p hp
  have h : env55718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55717_55718 : H12AffineEnvironment.transform 2 5 env55717 = env55718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55717 == env55718) = true)

theorem identity55718 : scanCanonicalize (H12AffineFastState.compose env55718 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55719 : List Nat := [2,4,5,7,7,6,4,3,0,5,0,1,2,0,1,5,1,1,4,0,1,6,7,2,2,6,0,0,1,1,2,7,3,7,1,0]

theorem envBound55719 : H12AffineFastState.Bounded env55719 := by
  intro p hp
  have h : env55719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55718_55719 : H12AffineEnvironment.transform 4 7 env55718 = env55719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55718 == env55719) = true)

def env55720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95615,32769,4096,61649,91505,284032,86519,5215,21872,90224,74814,96347,381313,75121,256,324084,1345,95102]

theorem envBound55720 : H12AffineFastState.Bounded env55720 := by
  intro p hp
  have h : env55720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55702_55720 : H12AffineEnvironment.transform 16 75057 env55702 = env55720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env55702 == env55720) = true)

def env55721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1375,32769,4096,61649,5457,284032,8663,5215,21872,4176,21534,2171,303521,21841,256,324084,1345,862]

theorem envBound55721 : H12AffineFastState.Bounded env55721 := by
  intro p hp
  have h : env55721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55720_55721 : H12AffineEnvironment.transform 15 28704 env55720 = env55721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env55720 == env55721) = true)

theorem identity55721 : scanCanonicalize (H12AffineFastState.compose env55721 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound55721 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55722 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21583,262144,1025,32769,4096,61649,5135,283870,8329,5215,21550,4176,21534,2171,303359,21519,94,323754,1055,512]

theorem envBound55722 : H12AffineFastState.Bounded env55722 := by
  intro p hp
  have h : env55722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55721_55722 : H12AffineEnvironment.transform 7 94 env55721 = env55722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env55721 == env55722) = true)

theorem identity55722 : scanCanonicalize (H12AffineFastState.compose env55722 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound55722 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env55723 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21583,5356,1025,32769,4096,61649,5135,16434,8329,5215,21550,4176,21534,2171,46099,21519,94,58438,1055,512]

theorem envBound55723 : H12AffineFastState.Bounded env55723 := by
  intro p hp
  have h : env55723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55722_55723 : H12AffineEnvironment.transform 17 5356 env55722 = env55723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env55722 == env55723) = true)

theorem identity55723 : scanCanonicalize (H12AffineFastState.compose env55723 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound55723 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55724 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25677,28704,21583,5356,1025,25676,4096,5276,5135,16434,8329,5215,21550,4176,21534,2171,20574,21519,94,11,1055,512]

theorem envBound55724 : H12AffineFastState.Bounded env55724 := by
  intro p hp
  have h : env55724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55723_55724 : H12AffineEnvironment.transform 14 25677 env55723 = env55724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env55723 == env55724) = true)

theorem identity55724 : scanCanonicalize (H12AffineFastState.compose env55724 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55724 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55725 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25628,28704,21534,5309,1025,25629,4096,5276,5135,16434,8329,5134,21550,4097,21534,2090,20495,21519,15,11,1055,512]

theorem envBound55725 : H12AffineFastState.Bounded env55725 := by
  intro p hp
  have h : env55725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55724_55725 : H12AffineEnvironment.transform 5 17 env55724 = env55725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55724 == env55725) = true)

theorem identity55725 : scanCanonicalize (H12AffineFastState.compose env55725 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55725 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55726 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,16384,24601,28704,20507,4280,4,24600,4096,4249,4106,16434,8329,4107,20523,4097,20507,2090,20495,20490,15,11,26,512]

theorem envBound55726 : H12AffineFastState.Bounded env55726 := by
  intro p hp
  have h : env55726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55725_55726 : H12AffineEnvironment.transform 9 5 env55725 = env55726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55725 == env55726) = true)

theorem identity55726 : scanCanonicalize (H12AffineFastState.compose env55726 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound55726 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55727 : List Nat := [2,4,8,16,32,17,128,15,512,5,2048,4096,8192,0,8217,12320,4123,4280,4,8216,4096,4249,4106,50,8329,4107,4139,4097,4123,2090,4111,4106,15,11,26,512]

theorem envBound55727 : H12AffineFastState.Bounded env55727 := by
  intro p hp
  have h : env55727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55726_55727 : H12AffineEnvironment.transform 13 0 env55726 = env55727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env55726 == env55727) = true)

theorem identity55727 : scanCanonicalize (H12AffineFastState.compose env55727 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound55727 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55728 : List Nat := [2,4,8,16,32,17,128,15,512,5,649,4096,8192,0,8217,12320,4123,4280,4,8216,4096,4249,4106,50,8329,4107,4139,4097,4123,675,4111,4106,15,11,26,512]

theorem envBound55728 : H12AffineFastState.Bounded env55728 := by
  intro p hp
  have h : env55728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55727_55728 : H12AffineEnvironment.transform 10 649 env55727 = env55728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env55727 == env55728) = true)

theorem identity55728 : scanCanonicalize (H12AffineFastState.compose env55728 (packedSelected [10,15] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound55728 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env55729 : List Nat := [2,4,8,16,32,17,128,15,512,5,649,555,8192,0,8217,8715,560,659,4,8216,555,690,545,50,8329,544,512,554,560,675,548,545,15,11,26,512]

theorem envBound55729 : H12AffineFastState.Bounded env55729 := by
  intro p hp
  have h : env55729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55728_55729 : H12AffineEnvironment.transform 11 555 env55728 = env55729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env55728 == env55729) = true)

theorem identity55729 : scanCanonicalize (H12AffineFastState.compose env55729 (packedSelected [4,5,7,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 181) := by decide +kernel

theorem selectedBound55729 : packedSelected [4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55730 : List Nat := [2,4,8,16,32,17,128,15,181,5,60,158,8192,0,8217,8382,133,38,4,8216,158,7,148,50,8329,149,181,159,133,22,145,148,15,11,26,181]

theorem envBound55730 : H12AffineFastState.Bounded env55730 := by
  intro p hp
  have h : env55730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55729_55730 : H12AffineEnvironment.transform 8 181 env55729 = env55730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 181 env55729 == env55730) = true)

theorem identity55730 : scanCanonicalize (H12AffineFastState.compose env55730 (packedSelected [1,2,3,4,5,7,8,10,13] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55730 : packedSelected [1,2,3,4,5,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env55731 : List Nat := [2,4,5,16,32,17,128,2,181,5,49,147,8192,0,8212,8371,133,38,4,8213,147,7,148,50,8324,149,181,146,133,22,145,148,2,6,23,181]

theorem envBound55731 : H12AffineFastState.Bounded env55731 := by
  intro p hp
  have h : env55731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55730_55731 : H12AffineEnvironment.transform 2 5 env55730 = env55731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55730 == env55731) = true)

theorem identity55731 : scanCanonicalize (H12AffineFastState.compose env55731 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound55731 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55732 : List Nat := [2,4,5,16,32,17,52,2,1,5,49,39,8192,0,8212,8199,49,38,4,8213,39,7,32,50,8240,33,1,38,49,22,37,32,2,6,23,1]

theorem envBound55732 : H12AffineFastState.Bounded env55732 := by
  intro p hp
  have h : env55732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55731_55732 : H12AffineEnvironment.transform 6 52 env55731 = env55732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env55731 == env55732) = true)

theorem identity55732 : scanCanonicalize (H12AffineFastState.compose env55732 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55733 : List Nat := [2,4,5,6,32,7,34,2,1,5,39,39,8192,0,8194,8199,39,38,4,8195,39,7,32,36,8230,33,1,38,39,0,37,32,2,6,1,1]

theorem envBound55733 : H12AffineFastState.Bounded env55733 := by
  intro p hp
  have h : env55733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55732_55733 : H12AffineEnvironment.transform 3 6 env55732 = env55733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55732 == env55733) = true)

end H12CloudChart2