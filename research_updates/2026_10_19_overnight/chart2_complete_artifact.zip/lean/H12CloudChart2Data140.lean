import H12CloudChart2Data139

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans34793_34794 : H12AffineEnvironment.transform 13 5124 env34793 = env34794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env34793 == env34794) = true)

theorem identity34794 : scanCanonicalize (H12AffineFastState.compose env34794 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound34794 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env34795 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,13374,45216,2184,42144,32769,4097,42117,42164,45202,32808,1045,6329,40984,40984,6193,172,5140,172,40968,1212,41633]

theorem envBound34795 : H12AffineFastState.Bounded env34795 := by
  intro p hp
  have h : env34795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34794_34795 : H12AffineEnvironment.transform 15 13374 env34794 = env34795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env34794 == env34795) = true)

theorem identity34795 : scanCanonicalize (H12AffineFastState.compose env34795 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 7356) := by decide +kernel

theorem selectedBound34795 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env34796 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,7356,13374,11292,2184,14364,7357,4097,14393,14344,11310,7316,1045,6329,15524,15524,6193,172,5140,172,15540,1212,15901]

theorem envBound34796 : H12AffineFastState.Bounded env34796 := by
  intro p hp
  have h : env34796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34795_34796 : H12AffineEnvironment.transform 14 7356 env34795 = env34796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7356 env34795 == env34796) = true)

theorem identity34796 : scanCanonicalize (H12AffineFastState.compose env34796 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound34796 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env34797 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,512,8192,1540,3772,9790,11292,2184,10780,3773,513,10809,10760,11310,3732,1045,2745,11940,11940,2609,172,1556,172,11956,1212,11293]

theorem envBound34797 : H12AffineFastState.Bounded env34797 := by
  intro p hp
  have h : env34797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34796_34797 : H12AffineEnvironment.transform 11 512 env34796 = env34797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env34796 == env34797) = true)

theorem identity34797 : scanCanonicalize (H12AffineFastState.compose env34797 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1676) := by decide +kernel

theorem selectedBound34797 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34798 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1676,512,8192,1540,48,9790,8848,1540,9360,49,513,9397,9348,8866,24,1045,1077,8232,8232,1213,172,1556,172,8248,1212,8849]

theorem envBound34798 : H12AffineFastState.Bounded env34798 := by
  intro p hp
  have h : env34798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34797_34798 : H12AffineEnvironment.transform 10 1676 env34797 = env34798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1676 env34797 == env34798) = true)

theorem identity34798 : scanCanonicalize (H12AffineFastState.compose env34798 (packedSelected [1,3,4,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound34798 : packedSelected [1,3,4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env34799 : List Nat := [2,4,8,16,32,17,128,172,512,543,147,512,8192,27,48,8225,8848,27,8847,49,513,8874,8859,8866,24,522,554,8232,8232,674,172,11,172,8248,675,8849]

theorem envBound34799 : H12AffineFastState.Bounded env34799 := by
  intro p hp
  have h : env34799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34798_34799 : H12AffineEnvironment.transform 9 543 env34798 = env34799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env34798 == env34799) = true)

theorem identity34799 : scanCanonicalize (H12AffineFastState.compose env34799 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound34799 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env34800 : List Nat := [2,4,8,16,32,17,128,172,512,543,147,512,3,27,48,34,659,27,652,49,513,681,664,673,24,522,554,43,43,674,172,11,172,59,675,658]

theorem envBound34800 : H12AffineFastState.Bounded env34800 := by
  intro p hp
  have h : env34800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34799_34800 : H12AffineEnvironment.transform 12 3 env34799 = env34800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env34799 == env34800) = true)

theorem identity34800 : scanCanonicalize (H12AffineFastState.compose env34800 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34800 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34801 : List Nat := [2,4,8,11,32,10,128,172,512,516,136,512,3,0,43,34,648,0,652,42,513,681,643,673,3,522,554,43,43,674,172,11,172,32,675,649]

theorem envBound34801 : H12AffineFastState.Bounded env34801 := by
  intro p hp
  have h : env34801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34800_34801 : H12AffineEnvironment.transform 3 11 env34800 = env34801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34800 == env34801) = true)

theorem identity34801 : scanCanonicalize (H12AffineFastState.compose env34801 (packedSelected [1,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound34801 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env34802 : List Nat := [2,4,8,11,32,10,128,172,137,141,136,137,3,0,43,34,1,0,5,42,136,32,10,40,3,131,163,43,43,43,172,11,172,32,42,0]

theorem envBound34802 : H12AffineFastState.Bounded env34802 := by
  intro p hp
  have h : env34802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34801_34802 : H12AffineEnvironment.transform 8 137 env34801 = env34802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env34801 == env34802) = true)

theorem identity34802 : scanCanonicalize (H12AffineFastState.compose env34802 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34803 : List Nat := [2,4,8,11,32,10,9,37,0,4,1,0,3,0,43,34,1,0,5,42,1,32,10,40,3,10,42,43,43,43,37,11,37,32,42,0]

theorem envBound34803 : H12AffineFastState.Bounded env34803 := by
  intro p hp
  have h : env34803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34802_34803 : H12AffineEnvironment.transform 6 9 env34802 = env34803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34802 == env34803) = true)

theorem identity34803 : scanCanonicalize (H12AffineFastState.compose env34803 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34803 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34804 : List Nat := [2,4,8,11,10,10,9,15,0,4,1,0,3,0,1,8,1,0,5,0,1,10,10,2,3,10,0,1,1,1,15,11,15,10,0,0]

theorem envBound34804 : H12AffineFastState.Bounded env34804 := by
  intro p hp
  have h : env34804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34803_34804 : H12AffineEnvironment.transform 4 10 env34803 = env34804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34803 == env34804) = true)

theorem identity34804 : scanCanonicalize (H12AffineFastState.compose env34804 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34805 : List Nat := [2,3,8,11,10,10,9,8,0,3,1,0,3,0,1,8,1,0,2,0,1,10,10,2,3,10,0,1,1,1,8,11,8,10,0,0]

theorem envBound34805 : H12AffineFastState.Bounded env34805 := by
  intro p hp
  have h : env34805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34804_34805 : H12AffineEnvironment.transform 1 3 env34804 = env34805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34804 == env34805) = true)

def env34806 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143496,20497,508154,148716,148716,96346,90263,16400,173,148732,1260,135681]

theorem envBound34806 : H12AffineFastState.Bounded env34806 := by
  intro p hp
  have h : env34806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34775_34806 : H12AffineEnvironment.transform 7 173 env34775 = env34806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34775 == env34806) = true)

def env34807 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143496,20497,508074,148668,148668,96266,90263,16400,173,148652,1212,135681]

theorem envBound34807 : H12AffineFastState.Bounded env34807 := by
  intro p hp
  have h : env34807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34806_34807 : H12AffineEnvironment.transform 5 16 env34806 = env34807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34806 == env34807) = true)

theorem identity34807 : scanCanonicalize (H12AffineFastState.compose env34807 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound34807 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34808 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61568,147473,58519,143496,20497,60445,148668,148668,96266,90263,16400,173,148652,1212,135681]

theorem envBound34808 : H12AffineFastState.Bounded env34808 := by
  intro p hp
  have h : env34808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34807_34808 : H12AffineEnvironment.transform 17 208055 env34807 = env34808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env34807 == env34808) = true)

theorem identity34808 : scanCanonicalize (H12AffineFastState.compose env34808 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound34808 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env34809 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4097,61568,147473,58519,143496,20497,60445,148668,148668,43048,45237,16400,173,148652,1212,135681]

theorem envBound34809 : H12AffineFastState.Bounded env34809 := by
  intro p hp
  have h : env34809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34808_34809 : H12AffineEnvironment.transform 15 53282 env34808 = env34809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env34808 == env34809) = true)

theorem identity34809 : scanCanonicalize (H12AffineFastState.compose env34809 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound34809 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34810 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4097,61568,5292,58519,25653,20497,60445,4097,4097,43048,45237,16400,173,4113,1212,18108]

theorem envBound34810 : H12AffineFastState.Bounded env34810 := by
  intro p hp
  have h : env34810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34809_34810 : H12AffineEnvironment.transform 16 21693 env34809 = env34810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env34809 == env34810) = true)

theorem identity34810 : scanCanonicalize (H12AffineFastState.compose env34810 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound34810 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env34811 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,16384,32768,49306,17413,43048,16573,32769,185,57400,1044,58519,25653,16553,60445,185,185,43048,40973,16400,173,169,1212,18108]

theorem envBound34811 : H12AffineFastState.Bounded env34811 := by
  intro p hp
  have h : env34811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34810_34811 : H12AffineEnvironment.transform 11 184 env34810 = env34811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env34810 == env34811) = true)

theorem identity34811 : scanCanonicalize (H12AffineFastState.compose env34811 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound34811 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env34812 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,16384,512,17050,17413,10792,16573,513,185,25144,1044,26263,25653,16553,28189,185,185,10792,8717,16400,173,169,1212,18108]

theorem envBound34812 : H12AffineFastState.Bounded env34812 := by
  intro p hp
  have h : env34812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34811_34812 : H12AffineEnvironment.transform 14 512 env34811 = env34812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env34811 == env34812) = true)

theorem identity34812 : scanCanonicalize (H12AffineFastState.compose env34812 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound34812 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env34813 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,2090,512,2736,3119,10792,2199,513,185,10770,1044,11965,11295,2179,9783,185,185,10792,8717,2106,173,169,1212,3734]

theorem envBound34813 : H12AffineFastState.Bounded env34813 := by
  intro p hp
  have h : env34813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34812_34813 : H12AffineEnvironment.transform 13 2090 env34812 = env34813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env34812 == env34813) = true)

theorem identity34813 : scanCanonicalize (H12AffineFastState.compose env34813 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound34813 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env34814 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,1684,2090,512,2736,3119,3260,2199,513,185,3206,1044,2089,2699,2179,163,185,185,3260,1177,2106,173,169,1212,3734]

theorem envBound34814 : H12AffineFastState.Bounded env34814 := by
  intro p hp
  have h : env34814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34813_34814 : H12AffineEnvironment.transform 12 1684 env34813 = env34814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env34813 == env34814) = true)

theorem identity34814 : scanCanonicalize (H12AffineFastState.compose env34814 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound34814 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env34815 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1677,184,1684,1703,512,1085,674,561,1562,513,185,523,1044,1700,1030,1550,163,185,185,561,1177,1719,173,169,1212,27]

theorem envBound34815 : H12AffineFastState.Bounded env34815 := by
  intro p hp
  have h : env34815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34814_34815 : H12AffineEnvironment.transform 10 1677 env34814 = env34815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env34814 == env34815) = true)

theorem identity34815 : scanCanonicalize (H12AffineFastState.compose env34815 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound34815 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env34816 : List Nat := [2,4,8,16,32,16,128,173,512,516,137,184,144,163,512,569,674,561,30,513,185,523,528,160,514,10,163,185,185,561,669,179,173,169,696,27]

theorem envBound34816 : H12AffineFastState.Bounded env34816 := by
  intro p hp
  have h : env34816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34815_34816 : H12AffineEnvironment.transform 9 516 env34815 = env34816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env34815 == env34816) = true)

theorem identity34816 : scanCanonicalize (H12AffineFastState.compose env34816 (packedSelected [1,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34816 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env34817 : List Nat := [2,4,8,16,32,16,128,173,1,5,137,184,144,163,1,56,163,48,30,0,185,10,17,160,3,10,163,185,185,48,156,179,173,169,185,27]

theorem envBound34817 : H12AffineFastState.Bounded env34817 := by
  intro p hp
  have h : env34817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34816_34817 : H12AffineEnvironment.transform 8 1 env34816 = env34817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34816 == env34817) = true)

theorem identity34817 : scanCanonicalize (H12AffineFastState.compose env34817 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34817 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env34818 : List Nat := [2,4,8,16,16,16,128,157,1,5,137,136,144,147,1,8,147,0,30,0,137,10,17,144,3,10,147,137,137,0,156,131,157,153,137,27]

theorem envBound34818 : H12AffineFastState.Bounded env34818 := by
  intro p hp
  have h : env34818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34817_34818 : H12AffineEnvironment.transform 4 16 env34817 = env34818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34817 == env34818) = true)

theorem identity34818 : scanCanonicalize (H12AffineFastState.compose env34818 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound34818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34819 : List Nat := [2,4,8,16,16,16,18,15,1,5,27,26,2,1,1,8,1,0,30,0,27,10,17,2,3,10,1,27,27,0,14,17,15,11,27,27]

theorem envBound34819 : H12AffineFastState.Bounded env34819 := by
  intro p hp
  have h : env34819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34818_34819 : H12AffineEnvironment.transform 6 18 env34818 = env34819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env34818 == env34819) = true)

theorem identity34819 : scanCanonicalize (H12AffineFastState.compose env34819 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34819 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34820 : List Nat := [2,4,8,11,11,11,9,15,1,5,0,1,2,1,1,8,1,0,5,0,0,10,10,2,3,10,1,0,0,0,14,10,15,11,0,0]

theorem envBound34820 : H12AffineFastState.Bounded env34820 := by
  intro p hp
  have h : env34820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34819_34820 : H12AffineEnvironment.transform 3 11 env34819 = env34820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34819 == env34820) = true)

theorem identity34820 : scanCanonicalize (H12AffineFastState.compose env34820 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound34820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34821 : List Nat := [2,4,7,4,4,4,6,0,1,5,0,1,2,1,1,7,1,0,5,0,0,5,5,2,3,5,1,0,0,0,1,5,0,4,0,0]

theorem envBound34821 : H12AffineFastState.Bounded env34821 := by
  intro p hp
  have h : env34821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34820_34821 : H12AffineEnvironment.transform 2 7 env34820 = env34821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env34820 == env34821) = true)

theorem identity34821 : scanCanonicalize (H12AffineFastState.compose env34821 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34821 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34822 : List Nat := [2,3,0,3,3,3,1,0,1,2,0,1,2,1,1,0,1,0,2,0,0,2,2,2,3,2,1,0,0,0,1,2,0,3,0,0]

theorem envBound34822 : H12AffineFastState.Bounded env34822 := by
  intro p hp
  have h : env34822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34821_34822 : H12AffineEnvironment.transform 1 3 env34821 = env34822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34821 == env34822) = true)

theorem identity34822 : scanCanonicalize (H12AffineFastState.compose env34822 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34822 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34823 : List Nat := [0,1,0,1,1,1,1,0,1,0,0,1,0,1,1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,1,0,0]

theorem envBound34823 : H12AffineFastState.Bounded env34823 := by
  intro p hp
  have h : env34823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34822_34823 : H12AffineEnvironment.transform 0 0 env34822 = env34823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34822 == env34823) = true)

def env34824 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143496,20497,508075,148669,148669,96267,90263,16400,173,148653,1213,135681]

theorem envBound34824 : H12AffineFastState.Bounded env34824 := by
  intro p hp
  have h : env34824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34806_34824 : H12AffineEnvironment.transform 5 17 env34806 = env34824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34806 == env34824) = true)

theorem identity34824 : scanCanonicalize (H12AffineFastState.compose env34824 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound34824 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34825 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61569,115854,58519,111638,20497,279605,114723,114723,96267,90263,16400,173,114739,1213,104095]

theorem envBound34825 : H12AffineFastState.Bounded env34825 := by
  intro p hp
  have h : env34825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34824_34825 : H12AffineEnvironment.transform 16 99486 env34824 = env34825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env34824 == env34825) = true)

theorem identity34825 : scanCanonicalize (H12AffineFastState.compose env34825 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound34825 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env34826 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,33830,184,262144,5304,32769,4097,61569,16552,58519,12336,20497,279605,17413,17413,64557,58545,16400,173,17429,1213,4793]

theorem envBound34826 : H12AffineFastState.Bounded env34826 := by
  intro p hp
  have h : env34826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34825_34826 : H12AffineEnvironment.transform 15 33830 env34825 = env34826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env34825 == env34826) = true)

theorem identity34826 : scanCanonicalize (H12AffineFastState.compose env34826 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound34826 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34827 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,32768,33830,184,262144,1025,32769,184,57400,16552,58519,8329,16552,279605,17413,17413,60564,58545,16400,173,17429,1213,512]

theorem envBound34827 : H12AffineFastState.Bounded env34827 := by
  intro p hp
  have h : env34827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34826_34827 : H12AffineEnvironment.transform 11 185 env34826 = env34827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env34826 == env34827) = true)

theorem identity34827 : scanCanonicalize (H12AffineFastState.compose env34827 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound34827 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34828 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,32768,33830,184,262144,1025,32769,184,42116,1044,41003,8329,1044,262281,185,185,43048,40973,1196,173,169,1213,512]

theorem envBound34828 : H12AffineFastState.Bounded env34828 := by
  intro p hp
  have h : env34828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34827_34828 : H12AffineEnvironment.transform 13 1212 env34827 = env34828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env34827 == env34828) = true)

theorem identity34828 : scanCanonicalize (H12AffineFastState.compose env34828 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound34828 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34829 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,560,1558,184,262144,1025,561,184,9908,1044,8731,8329,1044,262281,185,185,10776,8765,1196,173,169,1213,512]

theorem envBound34829 : H12AffineFastState.Bounded env34829 := by
  intro p hp
  have h : env34829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34828_34829 : H12AffineEnvironment.transform 14 560 env34828 = env34829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env34828 == env34829) = true)

theorem identity34829 : scanCanonicalize (H12AffineFastState.compose env34829 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 11804) := by decide +kernel

theorem selectedBound34829 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env34830 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1212,560,1558,184,11804,1025,561,184,9908,1044,8731,8329,1044,11925,185,185,10776,8765,1196,173,169,1213,512]

theorem envBound34830 : H12AffineFastState.Bounded env34830 := by
  intro p hp
  have h : env34830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34829_34830 : H12AffineEnvironment.transform 17 11804 env34829 = env34830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11804 env34829 == env34830) = true)

theorem identity34830 : scanCanonicalize (H12AffineFastState.compose env34830 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound34830 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34831 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2099,1212,560,1558,184,1583,1025,561,184,3719,1044,2600,2234,1044,1702,185,185,555,2574,1196,173,169,1213,512]

theorem envBound34831 : H12AffineFastState.Bounded env34831 := by
  intro p hp
  have h : env34831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34830_34831 : H12AffineEnvironment.transform 12 2099 env34830 = env34831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env34830 == env34831) = true)

def env34832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58683,143497,20496,508155,148801,148800,96346,90427,16401,256,148816,1345,135680]

theorem envBound34832 : H12AffineFastState.Bounded env34832 := by
  intro p hp
  have h : env34832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34774_34832 : H12AffineEnvironment.transform 18 136193 env34774 = env34832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env34774 == env34832) = true)

def env34833 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143497,20496,508155,148717,148716,96346,90263,16401,172,148732,1261,135680]

theorem envBound34833 : H12AffineFastState.Bounded env34833 := by
  intro p hp
  have h : env34833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34832_34833 : H12AffineEnvironment.transform 7 172 env34832 = env34833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env34832 == env34833) = true)

def env34834 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143497,20496,508075,148669,148668,96266,90263,16401,172,148652,1213,135680]

theorem envBound34834 : H12AffineFastState.Bounded env34834 := by
  intro p hp
  have h : env34834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34833_34834 : H12AffineEnvironment.transform 5 16 env34833 = env34834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34833 == env34834) = true)

theorem identity34834 : scanCanonicalize (H12AffineFastState.compose env34834 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound34834 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34835 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,58519,32808,20496,356362,62492,62493,96266,90263,16401,172,62477,1213,41633]

theorem envBound34835 : H12AffineFastState.Bounded env34835 := by
  intro p hp
  have h : env34835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34834_34835 : H12AffineEnvironment.transform 16 45217 env34834 = env34835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env34834 == env34835) = true)

theorem identity34835 : scanCanonicalize (H12AffineFastState.compose env34835 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound34835 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34836 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4097,61568,61616,58519,32808,20496,96386,62492,62493,96266,90263,16401,172,62477,1213,41633]

theorem envBound34836 : H12AffineFastState.Bounded env34836 := by
  intro p hp
  have h : env34836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34835_34836 : H12AffineEnvironment.transform 17 2184 env34835 = env34836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env34835 == env34836) = true)

theorem identity34836 : scanCanonicalize (H12AffineFastState.compose env34836 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound34836 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34837 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,65536,45217,2184,42144,32769,4097,42116,42164,45203,32808,1044,76934,40984,40985,76814,78995,5141,172,40969,1213,41633]

theorem envBound34837 : H12AffineFastState.Bounded env34837 := by
  intro p hp
  have h : env34837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34836_34837 : H12AffineEnvironment.transform 13 5124 env34836 = env34837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env34836 == env34837) = true)

theorem identity34837 : scanCanonicalize (H12AffineFastState.compose env34837 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound34837 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env34838 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,13374,45217,2184,42144,32769,4097,42116,42164,45203,32808,1044,6328,40984,40985,6192,173,5141,172,40969,1213,41633]

theorem envBound34838 : H12AffineFastState.Bounded env34838 := by
  intro p hp
  have h : env34838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34837_34838 : H12AffineEnvironment.transform 15 13374 env34837 = env34838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env34837 == env34838) = true)

theorem identity34838 : scanCanonicalize (H12AffineFastState.compose env34838 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 3076) := by decide +kernel

theorem selectedBound34838 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env34839 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,3076,13374,15525,2184,10404,3077,4097,10368,10416,15511,3116,1044,6328,11292,11293,6192,173,5141,172,11277,1213,11941]

theorem envBound34839 : H12AffineFastState.Bounded env34839 := by
  intro p hp
  have h : env34839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34838_34839 : H12AffineEnvironment.transform 14 3076 env34838 = env34839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3076 env34838 == env34839) = true)

theorem identity34839 : scanCanonicalize (H12AffineFastState.compose env34839 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7844) := by decide +kernel

theorem selectedBound34839 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env34840 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7844,5124,3076,2714,513,2184,5632,3077,4097,5668,5652,563,3116,1044,6328,4792,4793,6192,173,5141,172,4777,1213,4097]

theorem envBound34840 : H12AffineFastState.Bounded env34840 := by
  intro p hp
  have h : env34840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34839_34840 : H12AffineEnvironment.transform 12 7844 env34839 = env34840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7844 env34839 == env34840) = true)

theorem identity34840 : scanCanonicalize (H12AffineFastState.compose env34840 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound34840 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34841 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1077,4096,4753,5124,49,1711,513,1213,5632,48,4097,5668,5652,563,25,1044,5261,4792,4793,5125,173,5141,172,4777,1213,4097]

theorem envBound34841 : H12AffineFastState.Bounded env34841 := by
  intro p hp
  have h : env34841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34840_34841 : H12AffineEnvironment.transform 10 1077 env34840 = env34841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env34840 == env34841) = true)

theorem identity34841 : scanCanonicalize (H12AffineFastState.compose env34841 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound34841 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env34842 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1077,146,515,1174,49,1711,513,1213,1682,48,147,1718,1670,563,25,1044,1055,554,555,1175,173,1159,172,571,1213,147]

theorem envBound34842 : H12AffineFastState.Bounded env34842 := by
  intro p hp
  have h : env34842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34841_34842 : H12AffineEnvironment.transform 11 146 env34841 = env34842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env34841 == env34842) = true)

theorem identity34842 : scanCanonicalize (H12AffineFastState.compose env34842 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound34842 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env34843 : List Nat := [2,4,8,16,32,16,128,172,184,1024,1077,146,187,1174,49,1047,185,1213,1066,48,147,1038,1086,139,25,1044,1055,146,147,1175,173,1159,172,131,1213,147]

theorem envBound34843 : H12AffineFastState.Bounded env34843 := by
  intro p hp
  have h : env34843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34842_34843 : H12AffineEnvironment.transform 8 184 env34842 = env34843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env34842 == env34843) = true)

theorem identity34843 : scanCanonicalize (H12AffineFastState.compose env34843 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34843 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34844 : List Nat := [2,4,8,11,32,11,128,172,163,1024,1070,137,160,1165,42,1036,162,1190,1066,43,136,1038,1061,139,2,1039,1028,137,136,1164,173,1159,172,131,1190,136]

theorem envBound34844 : H12AffineFastState.Bounded env34844 := by
  intro p hp
  have h : env34844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34843_34844 : H12AffineEnvironment.transform 3 11 env34843 = env34844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34843 == env34844) = true)

theorem identity34844 : scanCanonicalize (H12AffineFastState.compose env34844 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 161) := by decide +kernel

theorem selectedBound34844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34845 : List Nat := [2,4,8,11,32,11,128,172,163,161,143,137,160,44,42,173,162,7,139,43,136,175,132,139,2,174,165,137,136,45,173,38,172,131,7,136]

theorem envBound34845 : H12AffineFastState.Bounded env34845 := by
  intro p hp
  have h : env34845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34844_34845 : H12AffineEnvironment.transform 9 161 env34844 = env34845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 161 env34844 == env34845) = true)

theorem identity34845 : scanCanonicalize (H12AffineFastState.compose env34845 (packedSelected [3,6] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34845 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env34846 : List Nat := [2,4,8,11,32,11,35,15,0,2,44,42,3,44,42,14,1,7,40,43,43,12,39,40,2,13,6,42,43,45,14,38,15,32,7,43]

theorem envBound34846 : H12AffineFastState.Bounded env34846 := by
  intro p hp
  have h : env34846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34845_34846 : H12AffineEnvironment.transform 6 35 env34845 = env34846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34845 == env34846) = true)

theorem identity34846 : scanCanonicalize (H12AffineFastState.compose env34846 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound34846 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34847 : List Nat := [2,4,8,11,12,11,15,15,0,2,0,6,3,0,6,14,1,7,4,7,7,12,11,4,2,13,6,6,7,1,14,10,15,12,7,7]

theorem envBound34847 : H12AffineFastState.Bounded env34847 := by
  intro p hp
  have h : env34847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34846_34847 : H12AffineEnvironment.transform 4 12 env34846 = env34847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env34846 == env34847) = true)

theorem identity34847 : scanCanonicalize (H12AffineFastState.compose env34847 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34847 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34848 : List Nat := [2,2,8,11,10,11,9,9,0,2,0,0,3,0,0,8,1,1,2,1,1,10,11,2,2,11,0,0,1,1,8,10,9,10,1,1]

theorem envBound34848 : H12AffineFastState.Bounded env34848 := by
  intro p hp
  have h : env34848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34847_34848 : H12AffineEnvironment.transform 1 2 env34847 = env34848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34847 == env34848) = true)

theorem identity34848 : scanCanonicalize (H12AffineFastState.compose env34848 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34849 : List Nat := [2,2,0,3,2,3,1,1,0,2,0,0,3,0,0,0,1,1,2,1,1,2,3,2,2,3,0,0,1,1,0,2,1,2,1,1]

theorem envBound34849 : H12AffineFastState.Bounded env34849 := by
  intro p hp
  have h : env34849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34848_34849 : H12AffineEnvironment.transform 2 0 env34848 = env34849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34848 == env34849) = true)

theorem identity34849 : scanCanonicalize (H12AffineFastState.compose env34849 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34849 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34850 : List Nat := [1,1,0,0,1,0,1,1,0,1,0,0,0,0,0,0,1,1,1,1,1,1,0,1,1,0,0,0,1,1,0,1,1,1,1,1]

theorem envBound34850 : H12AffineFastState.Bounded env34850 := by
  intro p hp
  have h : env34850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34849_34850 : H12AffineEnvironment.transform 0 1 env34849 = env34850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34849 == env34850) = true)

def env34851 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143497,20496,508074,148668,148669,96267,90263,16401,172,148653,1212,135680]

theorem envBound34851 : H12AffineFastState.Bounded env34851 := by
  intro p hp
  have h : env34851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34833_34851 : H12AffineEnvironment.transform 5 17 env34833 = env34851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34833 == env34851) = true)

theorem identity34851 : scanCanonicalize (H12AffineFastState.compose env34851 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound34851 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34852 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,58519,143497,20496,120867,148668,148669,96267,90263,16401,172,148653,1212,135680]

theorem envBound34852 : H12AffineFastState.Bounded env34852 := by
  intro p hp
  have h : env34852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34851_34852 : H12AffineEnvironment.transform 17 137353 env34851 = env34852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env34851 == env34852) = true)

theorem identity34852 : scanCanonicalize (H12AffineFastState.compose env34852 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound34852 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env34853 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4097,61569,46092,58519,50325,20496,120867,45216,45217,96267,90263,16401,172,45233,1212,58908]

theorem envBound34853 : H12AffineFastState.Bounded env34853 := by
  intro p hp
  have h : env34853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34852_34853 : H12AffineEnvironment.transform 16 62492 env34852 = env34853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env34852 == env34853) = true)

theorem identity34853 : scanCanonicalize (H12AffineFastState.compose env34853 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound34853 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34854 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,49307,62492,60565,57373,32769,4097,61569,46092,58519,50325,20496,6328,45216,45217,47248,40972,16401,172,45233,1212,58908]

theorem envBound34854 : H12AffineFastState.Bounded env34854 := by
  intro p hp
  have h : env34854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34853_34854 : H12AffineEnvironment.transform 15 49307 env34853 = env34854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env34853 == env34854) = true)

theorem identity34854 : scanCanonicalize (H12AffineFastState.compose env34854 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 18993) := by decide +kernel

theorem selectedBound34854 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34855 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,18993,2730,15917,9892,10796,18992,4097,15024,32317,11942,3748,20496,6328,31377,31376,29345,27197,16401,172,31360,1212,11309]

theorem envBound34855 : H12AffineFastState.Bounded env34855 := by
  intro p hp
  have h : env34855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34854_34855 : H12AffineEnvironment.transform 14 18993 env34854 = env34855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18993 env34854 == env34855) = true)

theorem identity34855 : scanCanonicalize (H12AffineFastState.compose env34855 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound34855 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env34856 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,18993,2730,11924,9892,10796,18992,184,10761,28292,11942,3748,16553,2049,27176,27177,25112,27197,16401,172,27193,1212,11309]

theorem envBound34856 : H12AffineFastState.Bounded env34856 := by
  intro p hp
  have h : env34856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34855_34856 : H12AffineEnvironment.transform 11 185 env34855 = env34856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env34855 == env34856) = true)

theorem identity34856 : scanCanonicalize (H12AffineFastState.compose env34856 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound34856 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env34857 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,3629,16384,18993,2730,185,2185,1025,18992,184,1060,16553,139,3748,16553,2049,17413,17412,19509,17424,16401,172,17428,1212,512]

theorem envBound34857 : H12AffineFastState.Bounded env34857 := by
  intro p hp
  have h : env34857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34856_34857 : H12AffineEnvironment.transform 12 3629 env34856 = env34857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env34856 == env34857) = true)

theorem identity34857 : scanCanonicalize (H12AffineFastState.compose env34857 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound34857 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34858 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,185,2720,16384,18993,2730,185,2185,140,18992,184,169,16553,139,2601,16553,2049,16520,16521,18616,16541,16401,172,16537,49,512]

theorem envBound34858 : H12AffineFastState.Bounded env34858 := by
  intro p hp
  have h : env34858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34857_34858 : H12AffineEnvironment.transform 9 141 env34857 = env34858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env34857 == env34858) = true)

theorem identity34858 : scanCanonicalize (H12AffineFastState.compose env34858 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 554) := by decide +kernel

theorem selectedBound34858 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34859 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,185,2720,554,2075,2730,185,2185,140,2074,184,169,643,139,2601,643,2049,674,675,2706,695,571,172,691,49,512]

theorem envBound34859 : H12AffineFastState.Bounded env34859 := by
  intro p hp
  have h : env34859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34858_34859 : H12AffineEnvironment.transform 13 554 env34858 = env34859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 554 env34858 == env34859) = true)

theorem identity34859 : scanCanonicalize (H12AffineFastState.compose env34859 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34859 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env34860 : List Nat := [2,4,8,11,32,10,128,172,512,141,2048,162,2720,554,2048,2730,162,2185,140,2049,163,169,643,139,2601,643,2049,674,675,2697,684,544,172,680,42,512]

theorem envBound34860 : H12AffineFastState.Bounded env34860 := by
  intro p hp
  have h : env34860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34859_34860 : H12AffineEnvironment.transform 3 11 env34859 = env34860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34859 == env34860) = true)

theorem identity34860 : scanCanonicalize (H12AffineFastState.compose env34860 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound34860 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34861 : List Nat := [2,4,8,11,32,10,128,172,137,141,2048,162,2089,163,2048,2083,162,2185,140,2049,163,169,10,139,2208,10,2049,43,42,2048,37,169,172,33,42,137]

theorem envBound34861 : H12AffineFastState.Bounded env34861 := by
  intro p hp
  have h : env34861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34860_34861 : H12AffineEnvironment.transform 8 137 env34860 = env34861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env34860 == env34861) = true)

theorem identity34861 : scanCanonicalize (H12AffineFastState.compose env34861 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound34861 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34862 : List Nat := [2,4,8,11,32,10,128,172,137,141,162,162,139,163,162,129,162,43,140,163,163,169,10,139,2,10,163,43,42,162,37,169,172,33,42,137]

theorem envBound34862 : H12AffineFastState.Bounded env34862 := by
  intro p hp
  have h : env34862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34861_34862 : H12AffineEnvironment.transform 10 162 env34861 = env34862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env34861 == env34862) = true)

theorem identity34862 : scanCanonicalize (H12AffineFastState.compose env34862 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34862 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env34863 : List Nat := [2,4,8,11,32,10,9,37,0,4,43,43,2,42,43,8,43,43,5,42,42,32,10,2,2,10,42,43,42,43,37,32,37,33,42,0]

theorem envBound34863 : H12AffineFastState.Bounded env34863 := by
  intro p hp
  have h : env34863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34862_34863 : H12AffineEnvironment.transform 6 9 env34862 = env34863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34862 == env34863) = true)

theorem identity34863 : scanCanonicalize (H12AffineFastState.compose env34863 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34864 : List Nat := [2,2,8,11,32,10,9,35,0,2,43,43,2,42,43,8,43,43,3,42,42,32,10,2,2,10,42,43,42,43,35,32,35,33,42,0]

theorem envBound34864 : H12AffineFastState.Bounded env34864 := by
  intro p hp
  have h : env34864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34863_34864 : H12AffineEnvironment.transform 1 2 env34863 = env34864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34863 == env34864) = true)

def env34865 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143497,20496,508155,148716,148717,96346,90262,16401,173,148733,1260,135680]

theorem envBound34865 : H12AffineFastState.Bounded env34865 := by
  intro p hp
  have h : env34865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34832_34865 : H12AffineEnvironment.transform 7 173 env34832 = env34865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34832 == env34865) = true)

def env34866 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143497,20496,508075,148668,148669,96266,90262,16401,173,148653,1212,135680]

theorem envBound34866 : H12AffineFastState.Bounded env34866 := by
  intro p hp
  have h : env34866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34865_34866 : H12AffineEnvironment.transform 5 16 env34865 = env34866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34865 == env34866) = true)

theorem identity34866 : scanCanonicalize (H12AffineFastState.compose env34866 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound34866 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34867 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61568,115854,58518,111638,20496,279604,114723,114722,96266,90262,16401,173,114738,1212,104095]

theorem envBound34867 : H12AffineFastState.Bounded env34867 := by
  intro p hp
  have h : env34867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34866_34867 : H12AffineEnvironment.transform 16 99487 env34866 = env34867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env34866 == env34867) = true)

theorem identity34867 : scanCanonicalize (H12AffineFastState.compose env34867 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound34867 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env34868 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,33831,184,262144,5305,32769,4097,61568,16553,58518,12337,20496,279604,17412,17413,64557,58545,16401,173,17429,1212,4792]

theorem envBound34868 : H12AffineFastState.Bounded env34868 := by
  intro p hp
  have h : env34868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34867_34868 : H12AffineEnvironment.transform 15 33831 env34867 = env34868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env34867 == env34868) = true)

theorem identity34868 : scanCanonicalize (H12AffineFastState.compose env34868 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound34868 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34869 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,16384,32768,33831,184,262144,1025,32769,185,57400,16553,58518,8329,16552,279604,17412,17413,60565,58545,16401,173,17429,1212,512]

theorem envBound34869 : H12AffineFastState.Bounded env34869 := by
  intro p hp
  have h : env34869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34868_34869 : H12AffineEnvironment.transform 11 184 env34868 = env34869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env34868 == env34869) = true)

theorem identity34869 : scanCanonicalize (H12AffineFastState.compose env34869 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34869 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34870 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1213,32768,33831,184,262144,1025,32769,185,42117,1044,41003,8329,1045,262281,185,184,43048,40972,1196,173,168,1212,512]

theorem envBound34870 : H12AffineFastState.Bounded env34870 := by
  intro p hp
  have h : env34870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34869_34870 : H12AffineEnvironment.transform 13 1213 env34869 = env34870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env34869 == env34870) = true)

theorem identity34870 : scanCanonicalize (H12AffineFastState.compose env34870 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound34870 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34871 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,657,1213,32768,33831,184,262144,1025,32769,185,34324,1044,33466,536,1045,262281,185,184,35513,33437,1196,173,168,1212,512]

theorem envBound34871 : H12AffineFastState.Bounded env34871 := by
  intro p hp
  have h : env34871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34870_34871 : H12AffineEnvironment.transform 12 657 env34870 = env34871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env34870 == env34871) = true)

theorem identity34871 : scanCanonicalize (H12AffineFastState.compose env34871 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound34871 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env34872 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,657,1213,32768,33831,184,3212,1025,32769,185,34324,1044,33466,536,1045,3077,185,184,35513,33437,1196,173,168,1212,512]

theorem envBound34872 : H12AffineFastState.Bounded env34872 := by
  intro p hp
  have h : env34872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34871_34872 : H12AffineEnvironment.transform 17 3212 env34871 = env34872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env34871 == env34872) = true)

theorem identity34872 : scanCanonicalize (H12AffineFastState.compose env34872 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound34872 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34873 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,184,657,1213,32768,33831,184,1582,1025,32769,185,34324,1044,33466,536,1045,1703,185,184,32795,33437,1196,173,168,1212,512]

theorem envBound34873 : H12AffineFastState.Bounded env34873 := by
  intro p hp
  have h : env34873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34872_34873 : H12AffineEnvironment.transform 10 674 env34872 = env34873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env34872 == env34873) = true)

theorem identity34873 : scanCanonicalize (H12AffineFastState.compose env34873 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound34873 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env34874 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,184,657,1213,560,1559,184,1582,1025,561,185,1060,1044,138,536,1045,1703,185,184,555,173,1196,173,168,1212,512]

theorem envBound34874 : H12AffineFastState.Bounded env34874 := by
  intro p hp
  have h : env34874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34873_34874 : H12AffineEnvironment.transform 14 560 env34873 = env34874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env34873 == env34874) = true)

theorem identity34874 : scanCanonicalize (H12AffineFastState.compose env34874 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34875 : List Nat := [2,4,8,16,32,16,35,14,512,1024,513,27,562,1054,560,1559,27,1582,1025,561,26,1060,1044,41,536,1045,1540,26,27,555,14,1039,14,11,1055,512]

theorem envBound34875 : H12AffineFastState.Bounded env34875 := by
  intro p hp
  have h : env34875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34874_34875 : H12AffineEnvironment.transform 6 35 env34874 = env34875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34874 == env34875) = true)

theorem identity34875 : scanCanonicalize (H12AffineFastState.compose env34875 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound34875 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34876 : List Nat := [2,4,8,16,32,16,35,14,512,31,513,27,562,1,560,520,27,561,30,561,26,59,11,41,536,10,539,26,27,555,14,16,14,11,0,512]

theorem envBound34876 : H12AffineFastState.Bounded env34876 := by
  intro p hp
  have h : env34876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34875_34876 : H12AffineEnvironment.transform 9 31 env34875 = env34876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env34875 == env34876) = true)

theorem identity34876 : scanCanonicalize (H12AffineFastState.compose env34876 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound34876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34877 : List Nat := [2,4,8,16,32,16,35,14,13,31,12,27,63,1,61,5,27,60,30,60,26,59,11,41,21,10,22,26,27,38,14,16,14,11,0,13]

theorem envBound34877 : H12AffineFastState.Bounded env34877 := by
  intro p hp
  have h : env34877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34876_34877 : H12AffineEnvironment.transform 8 13 env34876 = env34877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env34876 == env34877) = true)

theorem identity34877 : scanCanonicalize (H12AffineFastState.compose env34877 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34878 : List Nat := [2,4,8,6,32,6,35,14,13,9,12,13,41,1,43,5,13,42,8,42,12,45,11,41,3,10,0,12,13,38,14,6,14,11,0,13]

theorem envBound34878 : H12AffineFastState.Bounded env34878 := by
  intro p hp
  have h : env34878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34877_34878 : H12AffineEnvironment.transform 3 6 env34877 = env34878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34877 == env34878) = true)

def env34879 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143497,20496,508074,148669,148668,96267,90262,16401,173,148652,1213,135680]

theorem envBound34879 : H12AffineFastState.Bounded env34879 := by
  intro p hp
  have h : env34879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34865_34879 : H12AffineEnvironment.transform 5 17 env34865 = env34879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34865 == env34879) = true)

theorem identity34879 : scanCanonicalize (H12AffineFastState.compose env34879 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound34879 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34880 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61569,147472,58518,143497,20496,60444,148669,148668,96267,90262,16401,173,148652,1213,135680]

theorem envBound34880 : H12AffineFastState.Bounded env34880 := by
  intro p hp
  have h : env34880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34879_34880 : H12AffineEnvironment.transform 17 208054 env34879 = env34880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env34879 == env34880) = true)

theorem identity34880 : scanCanonicalize (H12AffineFastState.compose env34880 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound34880 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env34881 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4097,61569,147472,58518,143497,20496,60444,148669,148668,43048,45237,16401,173,148652,1213,135680]

theorem envBound34881 : H12AffineFastState.Bounded env34881 := by
  intro p hp
  have h : env34881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34880_34881 : H12AffineEnvironment.transform 15 53283 env34880 = env34881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env34880 == env34881) = true)

theorem identity34881 : scanCanonicalize (H12AffineFastState.compose env34881 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound34881 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34882 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4097,61569,5293,58518,25652,20496,60444,4096,4097,43048,45237,16401,173,4113,1213,18109]

theorem envBound34882 : H12AffineFastState.Bounded env34882 := by
  intro p hp
  have h : env34882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34881_34882 : H12AffineEnvironment.transform 16 21693 env34881 = env34882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env34881 == env34882) = true)

theorem identity34882 : scanCanonicalize (H12AffineFastState.compose env34882 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound34882 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env34883 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,32768,49306,17412,43048,16572,32769,184,57400,1044,58518,25652,16553,60444,185,184,43048,40972,16401,173,168,1213,18109]

theorem envBound34883 : H12AffineFastState.Bounded env34883 := by
  intro p hp
  have h : env34883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34882_34883 : H12AffineEnvironment.transform 11 185 env34882 = env34883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env34882 == env34883) = true)

theorem identity34883 : scanCanonicalize (H12AffineFastState.compose env34883 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound34883 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env34884 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,673,16384,32768,49306,17412,35465,16572,32769,184,49817,1044,50743,18069,16553,52925,185,184,35465,33453,16401,173,168,1213,18109]

theorem envBound34884 : H12AffineFastState.Bounded env34884 := by
  intro p hp
  have h : env34884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34883_34884 : H12AffineEnvironment.transform 12 673 env34883 = env34884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env34883 == env34884) = true)

theorem identity34884 : scanCanonicalize (H12AffineFastState.compose env34884 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 3735) := by decide +kernel

theorem selectedBound34884 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env34885 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,673,16384,3735,19981,17412,1054,16572,3734,184,19470,1044,18592,18069,16553,16426,185,184,1054,3130,16401,173,168,1213,18109]

theorem envBound34885 : H12AffineFastState.Bounded env34885 := by
  intro p hp
  have h : env34885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34884_34885 : H12AffineEnvironment.transform 14 3735 env34884 = env34885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3735 env34884 == env34885) = true)

theorem identity34885 : scanCanonicalize (H12AffineFastState.compose env34885 (packedSelected [1,3,13] rootPS)) = affineNative (2^(13+1) ^^^ 137) := by decide +kernel

theorem selectedBound34885 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env34886 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,673,137,3735,3716,1165,1054,53,3734,184,3207,1044,2089,1564,32,163,185,184,1054,3130,152,173,168,1213,1588]

theorem envBound34886 : H12AffineFastState.Bounded env34886 := by
  intro p hp
  have h : env34886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34885_34886 : H12AffineEnvironment.transform 13 137 env34885 = env34886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 137 env34885 == env34886) = true)

theorem identity34886 : scanCanonicalize (H12AffineFastState.compose env34886 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound34886 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env34887 : List Nat := [2,4,8,16,32,17,128,173,512,1024,697,185,673,137,1070,1085,1165,1054,53,1071,184,1598,1044,656,1564,32,163,185,184,1054,1667,152,173,168,1213,1588]

theorem envBound34887 : H12AffineFastState.Bounded env34887 := by
  intro p hp
  have h : env34887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34886_34887 : H12AffineEnvironment.transform 10 697 env34886 = env34887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env34886 == env34887) = true)

theorem identity34887 : scanCanonicalize (H12AffineFastState.compose env34887 (packedSelected [4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34887 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env34888 : List Nat := [2,4,8,16,10,17,128,135,512,1024,659,147,651,137,1028,1047,1165,1054,31,1029,146,1556,1044,656,1564,10,137,147,146,1054,1667,152,135,130,1175,1566]

theorem envBound34888 : H12AffineFastState.Bounded env34888 := by
  intro p hp
  have h : env34888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34887_34888 : H12AffineEnvironment.transform 4 10 env34887 = env34888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34887 == env34888) = true)

theorem identity34888 : scanCanonicalize (H12AffineFastState.compose env34888 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34888 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env34889 : List Nat := [2,4,8,16,10,17,128,135,512,4,659,147,651,137,0,19,137,26,31,1,146,528,16,656,536,10,137,147,146,26,647,152,135,130,147,538]

theorem envBound34889 : H12AffineFastState.Bounded env34889 := by
  intro p hp
  have h : env34889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34888_34889 : H12AffineEnvironment.transform 9 4 env34888 = env34889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34888 == env34889) = true)

theorem identity34889 : scanCanonicalize (H12AffineFastState.compose env34889 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound34889 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env34890 : List Nat := [2,4,8,16,10,17,128,135,26,4,137,147,145,137,0,19,137,26,31,1,146,10,16,138,2,10,137,147,146,26,157,152,135,130,147,0]

theorem envBound34890 : H12AffineFastState.Bounded env34890 := by
  intro p hp
  have h : env34890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34889_34890 : H12AffineEnvironment.transform 8 26 env34889 = env34890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env34889 == env34890) = true)

theorem identity34890 : scanCanonicalize (H12AffineFastState.compose env34890 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34891 : List Nat := [2,4,8,7,10,6,128,135,13,4,137,132,134,137,0,4,137,13,8,1,133,10,7,138,2,10,137,132,133,13,138,143,135,130,132,0]

theorem envBound34891 : H12AffineFastState.Bounded env34891 := by
  intro p hp
  have h : env34891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34890_34891 : H12AffineEnvironment.transform 3 7 env34890 = env34891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34890 == env34891) = true)

theorem identity34891 : scanCanonicalize (H12AffineFastState.compose env34891 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34892 : List Nat := [2,4,8,7,10,6,8,15,13,4,1,12,14,1,0,4,1,13,8,1,13,10,7,2,2,10,1,12,13,13,2,7,15,10,12,0]

theorem envBound34892 : H12AffineFastState.Bounded env34892 := by
  intro p hp
  have h : env34892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34891_34892 : H12AffineEnvironment.transform 6 8 env34891 = env34892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34891 == env34892) = true)

def env34893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245633,148801,545089,96346,16876544,16819499,256,545104,1344,525825]

theorem envBound34893 : H12AffineFastState.Bounded env34893 := by
  intro p hp
  have h : env34893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34772_34893 : H12AffineEnvironment.transform 26 17245633 env34772 = env34893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env34772 == env34893) = true)

theorem identity34893 : scanCanonicalize (H12AffineFastState.compose env34893 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound34893 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env34894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41002,533640,672785,493035,148801,545089,96346,74794,1281,256,545104,1344,525825]

theorem envBound34894 : H12AffineFastState.Bounded env34894 := by
  intro p hp
  have h : env34894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34893_34894 : H12AffineEnvironment.transform 23 41002 env34893 = env34894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env34893 == env34894) = true)

def env34895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,493035,148801,148801,96346,74794,1281,256,148816,1344,135681]

theorem envBound34895 : H12AffineFastState.Bounded env34895 := by
  intro p hp
  have h : env34895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34894_34895 : H12AffineEnvironment.transform 18 136192 env34894 = env34895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env34894 == env34895) = true)

def env34896 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,492615,148717,148717,96346,74794,1197,172,148732,1260,135681]

theorem envBound34896 : H12AffineFastState.Bounded env34896 := by
  intro p hp
  have h : env34896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34895_34896 : H12AffineEnvironment.transform 7 172 env34895 = env34896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env34895 == env34896) = true)

def env34897 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143496,20497,492567,148669,148669,96266,74794,1197,172,148652,1212,135681]

theorem envBound34897 : H12AffineFastState.Bounded env34897 := by
  intro p hp
  have h : env34897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34896_34897 : H12AffineEnvironment.transform 5 16 env34896 = env34897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34896 == env34897) = true)

theorem identity34897 : scanCanonicalize (H12AffineFastState.compose env34897 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound34897 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34898 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,41002,143496,20497,105631,148669,148669,96266,74794,1197,172,148652,1212,135681]

theorem envBound34898 : H12AffineFastState.Bounded env34898 := by
  intro p hp
  have h : env34898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34897_34898 : H12AffineEnvironment.transform 17 137352 env34897 = env34898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env34897 == env34898) = true)

theorem identity34898 : scanCanonicalize (H12AffineFastState.compose env34898 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound34898 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34899 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4097,61568,147473,41002,143496,20497,43168,148669,148669,19509,4117,1197,172,148652,1212,135681]

theorem envBound34899 : H12AffineFastState.Bounded env34899 := by
  intro p hp
  have h : env34899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34898_34899 : H12AffineEnvironment.transform 15 13375 env34898 = env34899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env34898 == env34899) = true)

theorem identity34899 : scanCanonicalize (H12AffineFastState.compose env34899 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound34899 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34900 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136192,32769,4097,46140,132269,41002,143496,5293,43168,131073,131073,2185,4117,1197,172,131088,1212,135681]

theorem envBound34900 : H12AffineFastState.Bounded env34900 := by
  intro p hp
  have h : env34900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34899_34900 : H12AffineEnvironment.transform 13 1212 env34899 = env34900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env34899 == env34900) = true)

theorem identity34900 : scanCanonicalize (H12AffineFastState.compose env34900 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound34900 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env34901 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13375,131072,137352,136192,9381,4097,4248,132269,1166,143496,5293,3076,131073,131073,2185,4117,1197,172,131088,1212,135681]

theorem envBound34901 : H12AffineFastState.Bounded env34901 := by
  intro p hp
  have h : env34901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34900_34901 : H12AffineEnvironment.transform 14 9380 env34900 = env34901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env34900 == env34901) = true)

theorem identity34901 : scanCanonicalize (H12AffineFastState.compose env34901 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 5124) := by decide +kernel

theorem selectedBound34901 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env34902 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13375,5124,3212,4,9381,4097,4248,4265,1166,9356,5293,3076,5125,5125,2185,4117,1197,172,5140,1212,1541]

theorem envBound34902 : H12AffineFastState.Bounded env34902 := by
  intro p hp
  have h : env34902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34901_34902 : H12AffineEnvironment.transform 16 5124 env34901 = env34902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5124 env34901 == env34902) = true)

theorem identity34902 : scanCanonicalize (H12AffineFastState.compose env34902 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound34902 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env34903 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7310,1212,6186,2225,5124,3212,4,6187,4097,4248,4265,1166,6146,5293,3076,5125,5125,2185,4117,1197,172,5140,1212,1541]

theorem envBound34903 : H12AffineFastState.Bounded env34903 := by
  intro p hp
  have h : env34903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34902_34903 : H12AffineEnvironment.transform 12 7310 env34902 = env34903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env34902 == env34903) = true)

theorem identity34903 : scanCanonicalize (H12AffineFastState.compose env34903 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound34903 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env34904 : List Nat := [2,4,8,16,32,16,128,172,512,150,2048,4096,6168,42,6186,2225,4242,2074,4,6187,4097,4248,4265,24,6146,4155,2194,4243,4243,2185,4117,59,172,4226,42,659]

theorem envBound34904 : H12AffineFastState.Bounded env34904 := by
  intro p hp
  have h : env34904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34903_34904 : H12AffineEnvironment.transform 9 150 env34903 = env34904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env34903 == env34904) = true)

theorem identity34904 : scanCanonicalize (H12AffineFastState.compose env34904 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound34904 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env34905 : List Nat := [2,4,8,16,32,16,128,172,512,150,2048,696,2720,42,2706,2225,554,2074,4,2707,697,544,529,24,2746,643,2194,555,555,2185,685,59,172,570,42,659]

theorem envBound34905 : H12AffineFastState.Bounded env34905 := by
  intro p hp
  have h : env34905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34904_34905 : H12AffineEnvironment.transform 11 696 env34904 = env34905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env34904 == env34905) = true)

theorem identity34905 : scanCanonicalize (H12AffineFastState.compose env34905 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound34905 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34906 : List Nat := [2,4,8,16,32,16,128,172,512,150,43,696,651,42,697,154,554,49,4,696,697,544,529,24,657,643,185,555,555,162,685,59,172,570,42,659]

theorem envBound34906 : H12AffineFastState.Bounded env34906 := by
  intro p hp
  have h : env34906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34905_34906 : H12AffineEnvironment.transform 10 43 env34905 = env34906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env34905 == env34906) = true)

def env34907 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143496,20497,492566,148668,148668,96267,74794,1197,172,148653,1213,135681]

theorem envBound34907 : H12AffineFastState.Bounded env34907 := by
  intro p hp
  have h : env34907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34896_34907 : H12AffineEnvironment.transform 5 17 env34896 = env34907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34896 == env34907) = true)

theorem identity34907 : scanCanonicalize (H12AffineFastState.compose env34907 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound34907 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34908 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,41002,32808,20497,341174,62492,62492,96267,74794,1197,172,62477,1213,41633]

theorem envBound34908 : H12AffineFastState.Bounded env34908 := by
  intro p hp
  have h : env34908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34907_34908 : H12AffineEnvironment.transform 16 45216 env34907 = env34908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env34907 == env34908) = true)

theorem identity34908 : scanCanonicalize (H12AffineFastState.compose env34908 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound34908 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env34909 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4097,46141,46092,41002,32808,5293,341174,45216,45216,81079,74794,1197,172,45233,1213,41633]

theorem envBound34909 : H12AffineFastState.Bounded env34909 := by
  intro p hp
  have h : env34909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34908_34909 : H12AffineEnvironment.transform 13 1212 env34908 = env34909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env34908 == env34909) = true)

theorem identity34909 : scanCanonicalize (H12AffineFastState.compose env34909 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound34909 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34910 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,33830,45216,262144,42144,32769,4097,46141,46092,41002,32808,5293,307344,45216,45216,47249,40972,1197,172,45233,1213,41633]

theorem envBound34910 : H12AffineFastState.Bounded env34910 := by
  intro p hp
  have h : env34910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34909_34910 : H12AffineEnvironment.transform 15 33830 env34909 = env34910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env34909 == env34910) = true)

theorem identity34910 : scanCanonicalize (H12AffineFastState.compose env34910 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound34910 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env34911 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33830,40984,262144,42144,32769,185,42117,42164,41002,32808,1045,303144,40984,40984,43049,40972,1197,172,40969,1213,41633]

theorem envBound34911 : H12AffineFastState.Bounded env34911 := by
  intro p hp
  have h : env34911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34910_34911 : H12AffineEnvironment.transform 11 184 env34910 = env34911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env34910 == env34911) = true)

theorem identity34911 : scanCanonicalize (H12AffineFastState.compose env34911 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound34911 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env34912 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33830,40984,43049,42144,32769,185,42117,42164,41002,32808,1045,2049,40984,40984,43049,40972,1197,172,40969,1213,41633]

theorem envBound34912 : H12AffineFastState.Bounded env34912 := by
  intro p hp
  have h : env34912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34911_34912 : H12AffineEnvironment.transform 17 43049 env34911 = env34912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env34911 == env34912) = true)

theorem identity34912 : scanCanonicalize (H12AffineFastState.compose env34912 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 8755) := by decide +kernel

theorem selectedBound34912 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env34913 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,8755,9749,555,2586,1683,8754,185,1718,1671,537,8731,1045,2049,555,555,2586,575,1197,172,570,1213,146]

theorem envBound34913 : H12AffineFastState.Bounded env34913 := by
  intro p hp
  have h : env34913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34912_34913 : H12AffineEnvironment.transform 14 8755 env34912 = env34913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8755 env34912 == env34913) = true)

theorem identity34913 : scanCanonicalize (H12AffineFastState.compose env34913 (packedSelected [1,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound34913 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env34914 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1166,1212,1725,667,555,2586,1683,1724,185,1718,1671,537,1685,1045,2049,555,555,2586,575,1197,172,570,1213,146]

theorem envBound34914 : H12AffineFastState.Bounded env34914 := by
  intro p hp
  have h : env34914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34913_34914 : H12AffineEnvironment.transform 12 1166 env34913 = env34914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env34913 == env34914) = true)

theorem identity34914 : scanCanonicalize (H12AffineFastState.compose env34914 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound34914 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env34915 : List Nat := [2,4,8,16,32,17,128,172,512,1024,554,184,1166,1212,1725,667,555,48,1683,1724,185,1718,1671,537,1685,1045,555,555,555,48,575,1197,172,570,1213,146]

theorem envBound34915 : H12AffineFastState.Bounded env34915 := by
  intro p hp
  have h : env34915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34914_34915 : H12AffineEnvironment.transform 10 554 env34914 = env34915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env34914 == env34915) = true)

theorem identity34915 : scanCanonicalize (H12AffineFastState.compose env34915 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound34915 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34916 : List Nat := [2,4,8,16,32,17,128,172,512,662,554,184,536,554,43,667,555,48,5,42,185,32,17,537,3,643,555,555,555,48,575,571,172,570,555,146]

theorem envBound34916 : H12AffineFastState.Bounded env34916 := by
  intro p hp
  have h : env34916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34915_34916 : H12AffineEnvironment.transform 9 662 env34915 = env34916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env34915 == env34916) = true)

theorem identity34916 : scanCanonicalize (H12AffineFastState.compose env34916 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound34916 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34917 : List Nat := [2,4,8,16,32,17,128,172,180,34,158,184,172,158,43,47,159,48,5,42,185,32,17,173,3,55,159,159,159,48,139,143,172,142,159,146]

theorem envBound34917 : H12AffineFastState.Bounded env34917 := by
  intro p hp
  have h : env34917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34916_34917 : H12AffineEnvironment.transform 8 180 env34916 = env34917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env34916 == env34917) = true)

theorem identity34917 : scanCanonicalize (H12AffineFastState.compose env34917 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound34917 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env34918 : List Nat := [2,4,8,16,28,17,128,144,136,30,158,132,144,158,23,19,159,12,5,22,133,28,17,145,3,11,159,159,159,12,139,143,144,142,159,146]

theorem envBound34918 : H12AffineFastState.Bounded env34918 := by
  intro p hp
  have h : env34918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34917_34918 : H12AffineEnvironment.transform 4 28 env34917 = env34918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env34917 == env34918) = true)

theorem identity34918 : scanCanonicalize (H12AffineFastState.compose env34918 (packedSelected [1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34918 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env34919 : List Nat := [2,4,8,16,28,17,9,25,1,30,23,13,25,23,23,19,22,12,5,22,12,28,17,24,3,11,22,22,22,12,2,6,25,7,22,27]

theorem envBound34919 : H12AffineFastState.Bounded env34919 := by
  intro p hp
  have h : env34919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34918_34919 : H12AffineEnvironment.transform 6 9 env34918 = env34919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34918 == env34919) = true)

theorem identity34919 : scanCanonicalize (H12AffineFastState.compose env34919 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34920 : List Nat := [2,4,8,11,7,10,9,2,1,5,12,13,2,12,12,8,13,12,5,13,12,7,10,3,3,11,13,13,13,12,2,6,2,7,13,0]

theorem envBound34920 : H12AffineFastState.Bounded env34920 := by
  intro p hp
  have h : env34920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34919_34920 : H12AffineEnvironment.transform 3 11 env34919 = env34920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34919 == env34920) = true)

theorem identity34920 : scanCanonicalize (H12AffineFastState.compose env34920 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34920 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34921 : List Nat := [2,4,0,3,7,2,1,2,1,5,4,5,2,4,4,0,5,4,5,5,4,7,2,3,3,3,5,5,5,4,2,6,2,7,5,0]

theorem envBound34921 : H12AffineFastState.Bounded env34921 := by
  intro p hp
  have h : env34921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34920_34921 : H12AffineEnvironment.transform 2 0 env34920 = env34921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34920 == env34921) = true)

theorem identity34921 : scanCanonicalize (H12AffineFastState.compose env34921 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34921 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34922 : List Nat := [2,0,0,3,3,2,1,2,1,1,0,1,2,0,0,0,1,0,1,1,0,3,2,3,3,3,1,1,1,0,2,2,2,3,1,0]

theorem envBound34922 : H12AffineFastState.Bounded env34922 := by
  intro p hp
  have h : env34922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34921_34922 : H12AffineEnvironment.transform 1 0 env34921 = env34922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34921 == env34922) = true)

theorem identity34922 : scanCanonicalize (H12AffineFastState.compose env34922 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34922 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34923 : List Nat := [1,0,0,0,0,1,1,1,1,1,0,1,1,0,0,0,1,0,1,1,0,0,1,0,0,0,1,1,1,0,1,1,1,0,1,0]

theorem envBound34923 : H12AffineFastState.Bounded env34923 := by
  intro p hp
  have h : env34923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34922_34923 : H12AffineEnvironment.transform 0 1 env34922 = env34923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34922 == env34923) = true)

def env34924 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,492614,148716,148716,96346,74794,1196,173,148733,1261,135681]

theorem envBound34924 : H12AffineFastState.Bounded env34924 := by
  intro p hp
  have h : env34924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34895_34924 : H12AffineEnvironment.transform 7 173 env34895 = env34924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34895 == env34924) = true)

def env34925 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143496,20497,492566,148668,148668,96266,74794,1196,173,148653,1213,135681]

theorem envBound34925 : H12AffineFastState.Bounded env34925 := by
  intro p hp
  have h : env34925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34924_34925 : H12AffineEnvironment.transform 5 16 env34924 = env34925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34924 == env34925) = true)

theorem identity34925 : scanCanonicalize (H12AffineFastState.compose env34925 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound34925 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34926 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61568,147473,41002,143496,20497,60444,148668,148668,96266,74794,1196,173,148653,1213,135681]

theorem envBound34926 : H12AffineFastState.Bounded env34926 := by
  intro p hp
  have h : env34926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34925_34926 : H12AffineEnvironment.transform 17 223242 env34925 = env34926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env34925 == env34926) = true)

theorem identity34926 : scanCanonicalize (H12AffineFastState.compose env34926 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound34926 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34927 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4097,61568,147473,41002,143496,20497,60444,148668,148668,2185,21673,1196,173,148653,1213,135681]

theorem envBound34927 : H12AffineFastState.Bounded env34927 := by
  intro p hp
  have h : env34927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34926_34927 : H12AffineEnvironment.transform 15 28803 env34926 = env34927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env34926 == env34927) = true)

theorem identity34927 : scanCanonicalize (H12AffineFastState.compose env34927 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound34927 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env34928 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,28803,131072,137353,136192,29860,4097,1061,147473,21647,143496,20497,6329,148668,148668,2185,21673,1196,173,148653,1213,135681]

theorem envBound34928 : H12AffineFastState.Bounded env34928 := by
  intro p hp
  have h : env34928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34927_34928 : H12AffineEnvironment.transform 14 29861 env34927 = env34928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env34927 == env34928) = true)

theorem identity34928 : scanCanonicalize (H12AffineFastState.compose env34928 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34928 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env34929 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13374,131072,137353,136192,12313,4097,1061,132268,4146,143496,5292,6329,131073,131073,2185,4116,1196,173,131088,1213,135681]

theorem envBound34929 : H12AffineFastState.Bounded env34929 := by
  intro p hp
  have h : env34929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34928_34929 : H12AffineEnvironment.transform 13 1213 env34928 = env34929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env34928 == env34929) = true)

theorem identity34929 : scanCanonicalize (H12AffineFastState.compose env34929 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound34929 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env34930 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2099,1213,6187,7181,131072,137353,136192,6186,4097,1061,132268,4146,137403,5292,6329,131073,131073,2185,4116,1196,173,131088,1213,135681]

theorem envBound34930 : H12AffineFastState.Bounded env34930 := by
  intro p hp
  have h : env34930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34929_34930 : H12AffineEnvironment.transform 12 2099 env34929 = env34930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env34929 == env34930) = true)

theorem identity34930 : scanCanonicalize (H12AffineFastState.compose env34930 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5124) := by decide +kernel

theorem selectedBound34930 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34931 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2099,1213,6187,7181,5124,3213,4,6186,4097,1061,4264,4146,3263,5292,6329,5125,5125,2185,4116,1196,173,5140,1213,1541]

theorem envBound34931 : H12AffineFastState.Bounded env34931 := by
  intro p hp
  have h : env34931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34930_34931 : H12AffineEnvironment.transform 16 5124 env34930 = env34931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5124 env34930 == env34931) = true)

theorem identity34931 : scanCanonicalize (H12AffineFastState.compose env34931 (packedSelected [1,2,3,4,6,9,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound34931 : packedSelected [1,2,3,4,6,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env34932 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1724,2099,1213,3735,2737,696,3213,4,3734,1725,1061,1556,1678,3263,528,3589,697,697,2185,1704,1196,173,680,1213,1541]

theorem envBound34932 : H12AffineFastState.Bounded env34932 := by
  intro p hp
  have h : env34932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34931_34932 : H12AffineEnvironment.transform 11 1724 env34931 = env34932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env34931 == env34932) = true)

theorem identity34932 : scanCanonicalize (H12AffineFastState.compose env34932 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound34932 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34933 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,1724,657,1213,1077,19,696,1583,4,1076,1725,1061,1556,1678,1565,528,1191,697,697,555,1704,1196,173,680,1213,1541]

theorem envBound34933 : H12AffineFastState.Bounded env34933 := by
  intro p hp
  have h : env34933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34932_34933 : H12AffineEnvironment.transform 10 674 env34932 = env34933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env34932 == env34933) = true)

theorem identity34933 : scanCanonicalize (H12AffineFastState.compose env34933 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound34933 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env34934 : List Nat := [2,4,8,16,32,16,128,173,512,151,674,555,657,42,162,19,696,696,4,163,554,178,643,537,650,528,48,697,697,555,575,59,173,680,42,658]

theorem envBound34934 : H12AffineFastState.Bounded env34934 := by
  intro p hp
  have h : env34934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34933_34934 : H12AffineEnvironment.transform 9 151 env34933 = env34934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env34933 == env34934) = true)

theorem identity34934 : scanCanonicalize (H12AffineFastState.compose env34934 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound34934 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env34935 : List Nat := [2,4,8,16,32,16,128,173,27,151,185,48,138,42,162,19,163,163,4,163,49,178,152,2,145,11,48,162,162,48,36,59,173,179,42,137]

theorem envBound34935 : H12AffineFastState.Bounded env34935 := by
  intro p hp
  have h : env34935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34934_34935 : H12AffineEnvironment.transform 8 27 env34934 = env34935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env34934 == env34935) = true)

theorem identity34935 : scanCanonicalize (H12AffineFastState.compose env34935 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound34935 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env34936 : List Nat := [2,4,8,16,32,16,46,3,27,57,23,48,36,42,12,19,13,13,4,13,49,28,54,2,63,11,48,12,12,48,36,59,3,29,42,39]

theorem envBound34936 : H12AffineFastState.Bounded env34936 := by
  intro p hp
  have h : env34936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34935_34936 : H12AffineEnvironment.transform 6 46 env34935 = env34936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env34935 == env34936) = true)

def env34937 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143496,20497,492567,148669,148669,96267,74794,1196,173,148652,1212,135681]

theorem envBound34937 : H12AffineFastState.Bounded env34937 := by
  intro p hp
  have h : env34937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34924_34937 : H12AffineEnvironment.transform 5 17 env34924 = env34937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34924 == env34937) = true)

theorem identity34937 : scanCanonicalize (H12AffineFastState.compose env34937 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound34937 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34938 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61569,98355,41002,127147,20497,279604,99486,99486,96267,74794,1196,173,99471,1212,119330]

theorem envBound34938 : H12AffineFastState.Bounded env34938 := by
  intro p hp
  have h : env34938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34937_34938 : H12AffineEnvironment.transform 16 114723 env34937 = env34938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env34937 == env34938) = true)

theorem identity34938 : scanCanonicalize (H12AffineFastState.compose env34938 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 76814) := by decide +kernel

theorem selectedBound34938 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34939 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,76814,119843,32769,4097,61569,98355,41002,127147,20497,92218,99486,99486,96267,74794,1196,173,99471,1212,119330]

theorem envBound34939 : H12AffineFastState.Bounded env34939 := by
  intro p hp
  have h : env34939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34938_34939 : H12AffineEnvironment.transform 17 76814 env34938 = env34939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76814 env34938 == env34939) = true)

theorem identity34939 : scanCanonicalize (H12AffineFastState.compose env34939 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound34939 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env34940 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,64556,1025,32769,4097,61569,20497,41002,8329,20497,47128,21692,21692,43049,62472,1196,173,21677,1212,512]

theorem envBound34940 : H12AffineFastState.Bounded env34940 := by
  intro p hp
  have h : env34940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34939_34940 : H12AffineEnvironment.transform 15 53282 env34939 = env34940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env34939 == env34940) = true)

theorem identity34940 : scanCanonicalize (H12AffineFastState.compose env34940 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound34940 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34941 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,32768,49307,184,60565,1025,32769,184,57400,16552,41002,8329,16552,43169,17413,17413,43049,58545,1196,173,17428,1212,512]

theorem envBound34941 : H12AffineFastState.Bounded env34941 := by
  intro p hp
  have h : env34941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34940_34941 : H12AffineEnvironment.transform 11 185 env34940 = env34941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env34940 == env34941) = true)

theorem identity34941 : scanCanonicalize (H12AffineFastState.compose env34941 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17033) := by decide +kernel

theorem selectedBound34941 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34942 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,16384,17033,530,184,11804,1025,17032,184,8881,16552,25251,8329,16552,27176,17413,17413,27296,9784,1196,173,17428,1212,512]

theorem envBound34942 : H12AffineFastState.Bounded env34942 := by
  intro p hp
  have h : env34942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34941_34942 : H12AffineEnvironment.transform 14 17033 env34941 = env34942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17033 env34941 == env34942) = true)

theorem identity34942 : scanCanonicalize (H12AffineFastState.compose env34942 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound34942 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env34943 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,185,8192,16384,16530,9,184,11271,1025,16531,184,8362,16552,24760,8329,16552,26675,17413,17413,26811,9251,1196,173,17428,1212,27]

theorem envBound34943 : H12AffineFastState.Bounded env34943 := by
  intro p hp
  have h : env34943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34942_34943 : H12AffineEnvironment.transform 8 27 env34942 = env34943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env34942 == env34943) = true)

theorem identity34943 : scanCanonicalize (H12AffineFastState.compose env34943 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 11406) := by decide +kernel

theorem selectedBound34943 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34944 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,185,8192,11406,11292,9,184,11271,1025,11293,184,8362,11302,3126,8329,11302,1213,10379,10379,1077,9251,1196,173,10394,1212,27]

theorem envBound34944 : H12AffineFastState.Bounded env34944 := by
  intro p hp
  have h : env34944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34943_34944 : H12AffineEnvironment.transform 13 11406 env34943 = env34944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11406 env34943 == env34944) = true)

theorem identity34944 : scanCanonicalize (H12AffineFastState.compose env34944 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 3236) := by decide +kernel

theorem selectedBound34944 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env34945 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,185,3236,42,184,9,184,163,1025,185,184,3086,130,3126,3117,130,1213,1071,1071,1077,2183,1196,173,1086,1212,27]

theorem envBound34945 : H12AffineFastState.Bounded env34945 := by
  intro p hp
  have h : env34945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34944_34945 : H12AffineEnvironment.transform 12 3236 env34944 = env34945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3236 env34944 == env34945) = true)

theorem identity34945 : scanCanonicalize (H12AffineFastState.compose env34945 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound34945 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34946 : List Nat := [2,4,8,16,32,17,128,173,27,1024,1191,185,3,42,184,9,184,163,1025,185,184,169,130,145,138,130,1213,1071,1071,1077,1056,1196,173,1086,1212,27]

theorem envBound34946 : H12AffineFastState.Bounded env34946 := by
  intro p hp
  have h : env34946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34945_34946 : H12AffineEnvironment.transform 10 1191 env34945 = env34946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env34945 == env34946) = true)

theorem identity34946 : scanCanonicalize (H12AffineFastState.compose env34946 (packedSelected [4,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34946 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env34947 : List Nat := [2,4,8,16,32,17,19,62,27,1024,1076,42,3,42,43,9,43,48,1025,42,43,58,17,2,25,17,1070,1071,1071,1077,1056,1087,62,1086,1071,27]

theorem envBound34947 : H12AffineFastState.Bounded env34947 := by
  intro p hp
  have h : env34947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34946_34947 : H12AffineEnvironment.transform 6 19 env34946 = env34947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34946 == env34947) = true)

theorem identity34947 : scanCanonicalize (H12AffineFastState.compose env34947 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34947 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env34948 : List Nat := [2,4,8,11,32,10,8,37,0,1024,1071,42,3,42,43,9,43,43,1025,42,43,33,10,2,2,10,1070,1071,1071,1070,1056,1060,37,1061,1071,0]

theorem envBound34948 : H12AffineFastState.Bounded env34948 := by
  intro p hp
  have h : env34948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34947_34948 : H12AffineEnvironment.transform 3 11 env34947 = env34948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34947 == env34948) = true)

def env34949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,493035,148801,148800,96346,74794,1281,256,148817,1344,135680]

theorem envBound34949 : H12AffineFastState.Bounded env34949 := by
  intro p hp
  have h : env34949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34894_34949 : H12AffineEnvironment.transform 18 136193 env34894 = env34949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env34894 == env34949) = true)

def env34950 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,492615,148717,148716,96346,74794,1197,172,148733,1260,135680]

theorem envBound34950 : H12AffineFastState.Bounded env34950 := by
  intro p hp
  have h : env34950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34949_34950 : H12AffineEnvironment.transform 7 172 env34949 = env34950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env34949 == env34950) = true)

def env34951 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143497,20496,492567,148669,148668,96266,74794,1197,172,148653,1212,135680]

theorem envBound34951 : H12AffineFastState.Bounded env34951 := by
  intro p hp
  have h : env34951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34950_34951 : H12AffineEnvironment.transform 5 16 env34950 = env34951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34950 == env34951) = true)

theorem identity34951 : scanCanonicalize (H12AffineFastState.compose env34951 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound34951 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34952 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,41002,32808,20496,341174,62492,62493,96266,74794,1197,172,62476,1212,41633]

theorem envBound34952 : H12AffineFastState.Bounded env34952 := by
  intro p hp
  have h : env34952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34951_34952 : H12AffineEnvironment.transform 16 45217 env34951 = env34952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env34951 == env34952) = true)

theorem identity34952 : scanCanonicalize (H12AffineFastState.compose env34952 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34952 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env34953 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4097,46141,46093,41002,32808,5293,341174,45217,45216,81079,74794,1197,172,45233,1212,41633]

theorem envBound34953 : H12AffineFastState.Bounded env34953 := by
  intro p hp
  have h : env34953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34952_34953 : H12AffineEnvironment.transform 13 1213 env34952 = env34953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env34952 == env34953) = true)

theorem identity34953 : scanCanonicalize (H12AffineFastState.compose env34953 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound34953 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34954 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,33831,45217,262144,42144,32769,4097,46141,46093,41002,32808,5293,307345,45217,45216,47248,40973,1197,172,45233,1212,41633]

theorem envBound34954 : H12AffineFastState.Bounded env34954 := by
  intro p hp
  have h : env34954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34953_34954 : H12AffineEnvironment.transform 15 33831 env34953 = env34954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env34953 == env34954) = true)

theorem identity34954 : scanCanonicalize (H12AffineFastState.compose env34954 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound34954 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env34955 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33831,40984,262144,42144,32769,184,42116,42164,41002,32808,1044,303144,40984,40985,43049,40973,1197,172,40968,1212,41633]

theorem envBound34955 : H12AffineFastState.Bounded env34955 := by
  intro p hp
  have h : env34955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34954_34955 : H12AffineEnvironment.transform 11 185 env34954 = env34955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env34954 == env34955) = true)

theorem identity34955 : scanCanonicalize (H12AffineFastState.compose env34955 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound34955 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env34956 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33831,40984,2184,42144,32769,184,42116,42164,41002,32808,1044,43168,40984,40985,43049,40973,1197,172,40968,1212,41633]

theorem envBound34956 : H12AffineFastState.Bounded env34956 := by
  intro p hp
  have h : env34956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34955_34956 : H12AffineEnvironment.transform 17 2184 env34955 = env34956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env34955 == env34956) = true)

theorem identity34956 : scanCanonicalize (H12AffineFastState.compose env34956 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound34956 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env34957 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,3237,1213,32768,33831,36029,2184,34821,32769,184,34849,34833,35983,32808,1044,33797,36029,36028,33932,36008,1197,172,36013,1212,36356]

theorem envBound34957 : H12AffineFastState.Bounded env34957 := by
  intro p hp
  have h : env34957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34956_34957 : H12AffineEnvironment.transform 12 3237 env34956 = env34957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env34956 == env34957) = true)

theorem identity34957 : scanCanonicalize (H12AffineFastState.compose env34957 (packedSelected [1,2,4,5,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound34957 : packedSelected [1,2,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env34958 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,185,3237,1213,32768,33831,36029,2184,34821,32769,184,34849,34833,35983,32808,1044,33797,36029,36028,33932,36008,1197,172,36013,1212,35870]

theorem envBound34958 : H12AffineFastState.Bounded env34958 := by
  intro p hp
  have h : env34958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34957_34958 : H12AffineEnvironment.transform 8 26 env34957 = env34958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env34957 == env34958) = true)

theorem identity34958 : scanCanonicalize (H12AffineFastState.compose env34958 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(14+1) ^^^ 42) := by decide +kernel

theorem selectedBound34958 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34959 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,185,3237,1213,42,1037,3223,2184,2095,43,184,2059,2107,3237,2,1044,1071,3223,3222,1190,3202,1197,172,3207,1212,3124]

theorem envBound34959 : H12AffineFastState.Bounded env34959 := by
  intro p hp
  have h : env34959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34958_34959 : H12AffineEnvironment.transform 14 42 env34958 = env34959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 42 env34958 == env34959) = true)

theorem identity34959 : scanCanonicalize (H12AffineFastState.compose env34959 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound34959 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env34960 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1191,185,2,1213,42,1037,48,1071,1160,43,184,1196,1180,2,2,1044,1071,48,49,1190,37,1197,172,32,1212,147]

theorem envBound34960 : H12AffineFastState.Bounded env34960 := by
  intro p hp
  have h : env34960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34959_34960 : H12AffineEnvironment.transform 10 1191 env34959 = env34960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env34959 == env34960) = true)

theorem identity34960 : scanCanonicalize (H12AffineFastState.compose env34960 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound34960 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env34961 : List Nat := [2,4,8,16,32,16,128,172,26,31,184,185,2,162,42,18,48,48,151,43,184,179,131,2,2,11,48,48,49,185,37,178,172,32,163,147]

theorem envBound34961 : H12AffineFastState.Bounded env34961 := by
  intro p hp
  have h : env34961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34960_34961 : H12AffineEnvironment.transform 9 31 env34960 = env34961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env34960 == env34961) = true)

theorem identity34961 : scanCanonicalize (H12AffineFastState.compose env34961 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34961 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34962 : List Nat := [2,4,8,10,32,10,128,172,0,5,162,163,2,162,42,8,42,42,141,43,162,169,131,2,2,11,42,42,43,163,37,168,172,32,163,137]

theorem envBound34962 : H12AffineFastState.Bounded env34962 := by
  intro p hp
  have h : env34962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34961_34962 : H12AffineEnvironment.transform 3 10 env34961 = env34962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34961 == env34962) = true)

theorem identity34962 : scanCanonicalize (H12AffineFastState.compose env34962 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound34962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34963 : List Nat := [2,4,8,10,32,10,46,2,0,5,12,13,2,12,42,8,42,42,35,43,12,7,45,2,2,11,42,42,43,13,37,6,2,32,13,39]

theorem envBound34963 : H12AffineFastState.Bounded env34963 := by
  intro p hp
  have h : env34963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34962_34963 : H12AffineEnvironment.transform 6 46 env34962 = env34963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env34962 == env34963) = true)

theorem identity34963 : scanCanonicalize (H12AffineFastState.compose env34963 (packedSelected [0,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34963 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env34964 : List Nat := [2,4,8,10,6,10,8,2,0,5,12,13,2,12,12,8,12,12,5,13,12,7,11,2,2,11,12,12,13,13,3,6,2,6,13,1]

theorem envBound34964 : H12AffineFastState.Bounded env34964 := by
  intro p hp
  have h : env34964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34963_34964 : H12AffineEnvironment.transform 4 6 env34963 = env34964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34963 == env34964) = true)

theorem identity34964 : scanCanonicalize (H12AffineFastState.compose env34964 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34965 : List Nat := [2,1,8,10,3,10,8,2,0,0,9,8,2,9,9,8,9,9,0,8,9,2,11,2,2,11,9,9,8,8,3,3,2,3,8,1]

theorem envBound34965 : H12AffineFastState.Bounded env34965 := by
  intro p hp
  have h : env34965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34964_34965 : H12AffineEnvironment.transform 1 1 env34964 = env34965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34964 == env34965) = true)

theorem identity34965 : scanCanonicalize (H12AffineFastState.compose env34965 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound34965 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34966 : List Nat := [2,1,1,3,3,3,1,2,0,0,0,1,2,0,0,1,0,0,0,1,0,2,2,2,2,2,0,0,1,1,3,3,2,3,1,1]

theorem envBound34966 : H12AffineFastState.Bounded env34966 := by
  intro p hp
  have h : env34966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34965_34966 : H12AffineEnvironment.transform 2 1 env34965 = env34966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env34965 == env34966) = true)

theorem identity34966 : scanCanonicalize (H12AffineFastState.compose env34966 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34966 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34967 : List Nat := [0,1,1,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,0,1,1,1]

theorem envBound34967 : H12AffineFastState.Bounded env34967 := by
  intro p hp
  have h : env34967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34966_34967 : H12AffineEnvironment.transform 0 0 env34966 = env34967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34966 == env34967) = true)

def env34968 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143497,20496,492566,148668,148669,96267,74794,1197,172,148652,1213,135680]

theorem envBound34968 : H12AffineFastState.Bounded env34968 := by
  intro p hp
  have h : env34968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34950_34968 : H12AffineEnvironment.transform 5 17 env34950 = env34968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34950 == env34968) = true)

theorem identity34968 : scanCanonicalize (H12AffineFastState.compose env34968 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound34968 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34969 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,41002,143497,20496,105631,148668,148669,96267,74794,1197,172,148652,1213,135680]

theorem envBound34969 : H12AffineFastState.Bounded env34969 := by
  intro p hp
  have h : env34969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34968_34969 : H12AffineEnvironment.transform 17 137353 env34968 = env34969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env34968 == env34969) = true)

theorem identity34969 : scanCanonicalize (H12AffineFastState.compose env34969 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound34969 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34970 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4097,61569,147472,41002,143497,20496,43168,148668,148669,19508,4117,1197,172,148652,1213,135680]

theorem envBound34970 : H12AffineFastState.Bounded env34970 := by
  intro p hp
  have h : env34970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34969_34970 : H12AffineEnvironment.transform 15 13375 env34969 = env34970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env34969 == env34970) = true)

theorem identity34970 : scanCanonicalize (H12AffineFastState.compose env34970 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34970 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34971 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136193,32769,4097,46140,132269,41002,143497,5293,43168,131073,131072,2185,4117,1197,172,131089,1213,135680]

theorem envBound34971 : H12AffineFastState.Bounded env34971 := by
  intro p hp
  have h : env34971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34970_34971 : H12AffineEnvironment.transform 13 1213 env34970 = env34971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env34970 == env34971) = true)

theorem identity34971 : scanCanonicalize (H12AffineFastState.compose env34971 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound34971 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env34972 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,46244,44077,41125,32769,4097,46140,45065,41002,33837,5293,43168,46245,46244,2185,4117,1197,172,46261,1213,42660]

theorem envBound34972 : H12AffineFastState.Bounded env34972 := by
  intro p hp
  have h : env34972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34971_34972 : H12AffineEnvironment.transform 16 46244 env34971 = env34972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env34971 == env34972) = true)

theorem identity34972 : scanCanonicalize (H12AffineFastState.compose env34972 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound34972 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34973 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3103,8192,1213,32768,10272,43195,44077,41125,32769,3102,43043,44054,41002,33837,2226,43168,43194,43195,2185,3082,1197,172,43178,1213,42660]

theorem envBound34973 : H12AffineFastState.Bounded env34973 := by
  intro p hp
  have h : env34973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34972_34973 : H12AffineEnvironment.transform 11 3103 env34972 = env34973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env34972 == env34973) = true)

theorem identity34973 : scanCanonicalize (H12AffineFastState.compose env34973 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound34973 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env34974 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3103,25,1213,32768,2105,34978,35892,32956,32769,3102,34874,35855,32819,33837,2226,35001,34979,34978,2185,3082,1197,172,34995,1213,34493]

theorem envBound34974 : H12AffineFastState.Bounded env34974 := by
  intro p hp
  have h : env34974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34973_34974 : H12AffineEnvironment.transform 12 25 env34973 = env34974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34973 == env34974) = true)

theorem identity34974 : scanCanonicalize (H12AffineFastState.compose env34974 (packedSelected [0,2,3,4,5,6,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34974 : packedSelected [0,2,3,4,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env34975 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3103,25,1076,32768,2105,34859,35892,32821,32769,3102,34874,35855,32819,33837,2107,34864,34858,34859,2048,3082,1060,37,34874,1076,34356]

theorem envBound34975 : H12AffineFastState.Bounded env34975 := by
  intro p hp
  have h : env34975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34974_34975 : H12AffineEnvironment.transform 6 9 env34974 = env34975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34974 == env34975) = true)

theorem identity34975 : scanCanonicalize (H12AffineFastState.compose env34975 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 3588) := by decide +kernel

theorem selectedBound34975 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env34976 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3103,25,1076,3588,2105,1583,560,3633,3589,3102,1598,523,3639,2601,2107,1588,1582,1583,2048,3082,1060,37,1598,1076,2096]

theorem envBound34976 : H12AffineFastState.Bounded env34976 := by
  intro p hp
  have h : env34976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34975_34976 : H12AffineEnvironment.transform 14 3588 env34975 = env34976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3588 env34975 == env34976) = true)

theorem identity34976 : scanCanonicalize (H12AffineFastState.compose env34976 (packedSelected [0,3,4,5,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound34976 : packedSelected [0,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34977 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1588,555,25,1076,48,1549,1583,560,5,49,554,1598,523,3,1053,1551,1588,1582,1583,1588,574,1060,37,1598,1076,1540]

theorem envBound34977 : H12AffineFastState.Bounded env34977 := by
  intro p hp
  have h : env34977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34976_34977 : H12AffineEnvironment.transform 10 1588 env34976 = env34977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env34976 == env34977) = true)

theorem identity34977 : scanCanonicalize (H12AffineFastState.compose env34977 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound34977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34978 : List Nat := [2,4,8,16,32,17,9,37,512,564,0,555,25,512,48,57,27,560,5,49,554,10,523,3,553,59,0,26,27,0,574,528,37,10,512,48]

theorem envBound34978 : H12AffineFastState.Bounded env34978 := by
  intro p hp
  have h : env34978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34977_34978 : H12AffineEnvironment.transform 9 564 env34977 = env34978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env34977 == env34978) = true)

theorem identity34978 : scanCanonicalize (H12AffineFastState.compose env34978 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34979 : List Nat := [2,4,8,16,16,17,9,21,512,516,0,539,25,512,0,9,27,512,5,1,538,10,523,3,537,11,0,26,27,0,526,528,21,10,512,0]

theorem envBound34979 : H12AffineFastState.Bounded env34979 := by
  intro p hp
  have h : env34979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34978_34979 : H12AffineEnvironment.transform 4 16 env34978 = env34979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34978 == env34979) = true)

theorem identity34979 : scanCanonicalize (H12AffineFastState.compose env34979 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound34979 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34980 : List Nat := [2,4,8,16,16,17,9,21,26,30,0,1,25,26,0,9,27,26,5,1,0,10,17,3,3,11,0,26,27,0,20,10,21,10,26,0]

theorem envBound34980 : H12AffineFastState.Bounded env34980 := by
  intro p hp
  have h : env34980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34979_34980 : H12AffineEnvironment.transform 8 26 env34979 = env34980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env34979 == env34980) = true)

theorem identity34980 : scanCanonicalize (H12AffineFastState.compose env34980 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34980 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34981 : List Nat := [2,3,8,16,16,17,9,18,26,25,0,1,25,26,0,9,27,26,2,1,0,10,17,3,3,11,0,26,27,0,19,10,18,10,26,0]

theorem envBound34981 : H12AffineFastState.Bounded env34981 := by
  intro p hp
  have h : env34981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34980_34981 : H12AffineEnvironment.transform 1 3 env34980 = env34981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34980 == env34981) = true)

def env34982 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,492614,148716,148717,96346,74794,1196,173,148732,1261,135680]

theorem envBound34982 : H12AffineFastState.Bounded env34982 := by
  intro p hp
  have h : env34982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34949_34982 : H12AffineEnvironment.transform 7 173 env34949 = env34982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34949 == env34982) = true)

def env34983 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143497,20496,492566,148668,148669,96266,74794,1196,173,148652,1213,135680]

theorem envBound34983 : H12AffineFastState.Bounded env34983 := by
  intro p hp
  have h : env34983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34982_34983 : H12AffineEnvironment.transform 5 16 env34982 = env34983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34982 == env34983) = true)

theorem identity34983 : scanCanonicalize (H12AffineFastState.compose env34983 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound34983 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34984 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61568,98354,41002,127146,20496,279605,99487,99486,96266,74794,1196,173,99471,1213,119331]

theorem envBound34984 : H12AffineFastState.Bounded env34984 := by
  intro p hp
  have h : env34984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34983_34984 : H12AffineEnvironment.transform 16 114723 env34983 = env34984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env34983 == env34984) = true)

theorem identity34984 : scanCanonicalize (H12AffineFastState.compose env34984 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 76815) := by decide +kernel

theorem selectedBound34984 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34985 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,76815,119842,32769,4097,61568,98354,41002,127146,20496,92218,99487,99486,96266,74794,1196,173,99471,1213,119331]

theorem envBound34985 : H12AffineFastState.Bounded env34985 := by
  intro p hp
  have h : env34985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34984_34985 : H12AffineEnvironment.transform 17 76815 env34984 = env34985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76815 env34984 == env34985) = true)

theorem identity34985 : scanCanonicalize (H12AffineFastState.compose env34985 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound34985 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env34986 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,64556,1025,32769,4097,61568,20497,41002,8329,20496,47129,21692,21693,43049,62473,1196,173,21676,1213,512]

theorem envBound34986 : H12AffineFastState.Bounded env34986 := by
  intro p hp
  have h : env34986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34985_34986 : H12AffineEnvironment.transform 15 53283 env34985 = env34986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env34985 == env34986) = true)

theorem identity34986 : scanCanonicalize (H12AffineFastState.compose env34986 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound34986 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34987 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,16384,32768,49307,184,60564,1025,32769,185,57400,16553,41002,8329,16552,43169,17412,17413,43049,58545,1196,173,17428,1213,512]

theorem envBound34987 : H12AffineFastState.Bounded env34987 := by
  intro p hp
  have h : env34987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34986_34987 : H12AffineEnvironment.transform 11 184 env34986 = env34987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env34986 == env34987) = true)

theorem identity34987 : scanCanonicalize (H12AffineFastState.compose env34987 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound34987 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34988 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,8745,32768,41650,184,36541,1025,32769,185,33297,8832,41002,8329,8833,43169,9773,9772,43049,34456,1196,173,9789,1213,512]

theorem envBound34988 : H12AffineFastState.Bounded env34988 := by
  intro p hp
  have h : env34988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34987_34988 : H12AffineEnvironment.transform 13 8745 env34987 = env34988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env34987 == env34988) = true)

theorem identity34988 : scanCanonicalize (H12AffineFastState.compose env34988 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound34988 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env34989 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,8745,1071,9885,184,2706,1025,1070,185,1598,8832,9221,8329,8833,11406,9773,9772,11270,695,1196,173,9789,1213,512]

theorem envBound34989 : H12AffineFastState.Bounded env34989 := by
  intro p hp
  have h : env34989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34988_34989 : H12AffineEnvironment.transform 14 1071 env34988 = env34989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env34988 == env34989) = true)

theorem identity34989 : scanCanonicalize (H12AffineFastState.compose env34989 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound34989 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env34990 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,184,8192,8242,1071,9350,184,2185,1025,1070,185,1061,8347,9221,8329,8346,11406,9270,9271,11270,172,1196,173,9254,1213,27]

theorem envBound34990 : H12AffineFastState.Bounded env34990 := by
  intro p hp
  have h : env34990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34989_34990 : H12AffineEnvironment.transform 8 27 env34989 = env34990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env34989 == env34990) = true)

theorem identity34990 : scanCanonicalize (H12AffineFastState.compose env34990 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound34990 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env34991 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,184,2099,2049,1071,3253,184,2185,1025,1070,185,1061,2216,3126,2234,2217,1213,3077,3076,1077,172,1196,173,3093,1213,27]

theorem envBound34991 : H12AffineFastState.Bounded env34991 := by
  intro p hp
  have h : env34991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34990_34991 : H12AffineEnvironment.transform 12 2099 env34990 = env34991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env34990 == env34991) = true)

theorem identity34991 : scanCanonicalize (H12AffineFastState.compose env34991 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound34991 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env34992 : List Nat := [2,4,8,16,32,16,128,173,27,1024,1191,184,1172,1190,1071,18,184,1070,1025,1070,185,1061,1039,145,1053,1038,1213,162,163,1077,172,1196,173,178,1213,27]

theorem envBound34992 : H12AffineFastState.Bounded env34992 := by
  intro p hp
  have h : env34992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34991_34992 : H12AffineEnvironment.transform 10 1191 env34991 = env34992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env34991 == env34992) = true)

theorem identity34992 : scanCanonicalize (H12AffineFastState.compose env34992 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34992 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34993 : List Nat := [2,4,8,16,32,16,9,36,27,1024,1070,49,1053,1071,1071,18,49,1070,1025,1070,48,1061,1039,24,1053,1038,1076,43,42,1077,37,1061,36,59,1076,27]

theorem envBound34993 : H12AffineFastState.Bounded env34993 := by
  intro p hp
  have h : env34993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34992_34993 : H12AffineEnvironment.transform 6 9 env34992 = env34993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34992 == env34993) = true)

def env34994 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143497,20496,492567,148669,148668,96267,74794,1196,173,148653,1212,135680]

theorem envBound34994 : H12AffineFastState.Bounded env34994 := by
  intro p hp
  have h : env34994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34982_34994 : H12AffineEnvironment.transform 5 17 env34982 = env34994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34982 == env34994) = true)

theorem identity34994 : scanCanonicalize (H12AffineFastState.compose env34994 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound34994 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env34995 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61569,147472,41002,143497,20496,60445,148669,148668,96267,74794,1196,173,148653,1212,135680]

theorem envBound34995 : H12AffineFastState.Bounded env34995 := by
  intro p hp
  have h : env34995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34994_34995 : H12AffineEnvironment.transform 17 223242 env34994 = env34995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env34994 == env34995) = true)

theorem identity34995 : scanCanonicalize (H12AffineFastState.compose env34995 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound34995 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34996 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4097,61569,147472,41002,143497,20496,60445,148669,148668,2185,21672,1196,173,148653,1212,135680]

theorem envBound34996 : H12AffineFastState.Bounded env34996 := by
  intro p hp
  have h : env34996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34995_34996 : H12AffineEnvironment.transform 15 28802 env34995 = env34996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env34995 == env34996) = true)

theorem identity34996 : scanCanonicalize (H12AffineFastState.compose env34996 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound34996 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env34997 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,28802,131072,137352,136193,29860,4097,1060,147472,21647,143497,20496,6328,148669,148668,2185,21672,1196,173,148653,1212,135680]

theorem envBound34997 : H12AffineFastState.Bounded env34997 := by
  intro p hp
  have h : env34997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34996_34997 : H12AffineEnvironment.transform 14 29861 env34996 = env34997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env34996 == env34997) = true)

theorem identity34997 : scanCanonicalize (H12AffineFastState.compose env34997 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound34997 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env34998 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12313,13374,131072,137352,136193,12312,4097,1060,132268,4147,143497,5292,6328,131073,131072,2185,4116,1196,173,131089,1212,135680]

theorem envBound34998 : H12AffineFastState.Bounded env34998 := by
  intro p hp
  have h : env34998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34997_34998 : H12AffineEnvironment.transform 13 1212 env34997 = env34998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env34997 == env34998) = true)

theorem identity34998 : scanCanonicalize (H12AffineFastState.compose env34998 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound34998 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env34999 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6282,1212,2195,3252,131072,137352,136193,2194,4097,1060,132268,4147,133123,5292,6328,131073,131072,2185,4116,1196,173,131089,1212,135680]

theorem envBound34999 : H12AffineFastState.Bounded env34999 := by
  intro p hp
  have h : env34999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34998_34999 : H12AffineEnvironment.transform 12 6282 env34998 = env34999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env34998 == env34999) = true)

theorem identity34999 : scanCanonicalize (H12AffineFastState.compose env34999 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound34999 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35000 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,3127,1212,2195,3252,131072,134197,131260,2194,1212,1060,132268,1166,133123,17,3077,131073,131072,2185,1193,1196,173,131089,1212,132797]

theorem envBound35000 : H12AffineFastState.Bounded env35000 := by
  intro p hp
  have h : env35000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34999_35000 : H12AffineEnvironment.transform 11 1213 env34999 = env35000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env34999 == env35000) = true)

theorem identity35000 : scanCanonicalize (H12AffineFastState.compose env35000 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 1725) := by decide +kernel

theorem selectedBound35000 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env35001 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,3127,1212,2195,3252,1725,2696,1537,2194,1212,1060,529,1166,3774,17,3077,1724,1725,2185,1193,1196,173,1708,1212,0]

theorem envBound35001 : H12AffineFastState.Bounded env35001 := by
  intro p hp
  have h : env35001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35000_35001 : H12AffineEnvironment.transform 16 1725 env35000 = env35001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1725 env35000 == env35001) = true)

theorem identity35001 : scanCanonicalize (H12AffineFastState.compose env35001 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound35001 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35002 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1213,1684,1212,560,1559,1725,43,1537,561,1212,1060,529,1166,1053,17,1702,1724,1725,554,1193,1196,173,1708,1212,0]

theorem envBound35002 : H12AffineFastState.Bounded env35002 := by
  intro p hp
  have h : env35002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35001_35002 : H12AffineEnvironment.transform 10 675 env35001 = env35002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env35001 == env35002) = true)

theorem identity35002 : scanCanonicalize (H12AffineFastState.compose env35002 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound35002 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env35003 : List Nat := [2,4,8,16,32,17,128,173,146,1024,49,1213,1030,1212,162,1157,1071,43,1171,163,1212,1060,131,1166,1053,17,1076,1070,1071,184,1193,1196,173,1086,1212,0]

theorem envBound35003 : H12AffineFastState.Bounded env35003 := by
  intro p hp
  have h : env35003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35002_35003 : H12AffineEnvironment.transform 8 146 env35002 = env35003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env35002 == env35003) = true)

theorem identity35003 : scanCanonicalize (H12AffineFastState.compose env35003 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 155) := by decide +kernel

theorem selectedBound35003 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35004 : List Nat := [2,4,8,16,32,17,128,173,146,155,49,38,157,39,162,30,180,43,8,163,39,191,131,21,134,17,175,181,180,184,50,55,173,165,39,0]

theorem envBound35004 : H12AffineFastState.Bounded env35004 := by
  intro p hp
  have h : env35004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35003_35004 : H12AffineEnvironment.transform 9 155 env35003 = env35004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 155 env35003 == env35004) = true)

theorem identity35004 : scanCanonicalize (H12AffineFastState.compose env35004 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35004 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env35005 : List Nat := [2,4,8,16,32,17,9,36,27,18,49,38,20,39,43,30,61,43,8,42,39,54,10,21,15,17,38,60,61,49,50,55,36,44,39,0]

theorem envBound35005 : H12AffineFastState.Bounded env35005 := by
  intro p hp
  have h : env35005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35004_35005 : H12AffineEnvironment.transform 6 9 env35004 = env35005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35004 == env35005) = true)

theorem identity35005 : scanCanonicalize (H12AffineFastState.compose env35005 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35005 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env35006 : List Nat := [2,4,5,16,32,17,4,36,22,18,49,38,20,39,38,19,48,38,5,39,39,54,7,21,2,17,38,49,48,49,50,55,36,33,39,0]

theorem envBound35006 : H12AffineFastState.Bounded env35006 := by
  intro p hp
  have h : env35006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35005_35006 : H12AffineEnvironment.transform 2 5 env35005 = env35006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35005 == env35006) = true)

theorem identity35006 : scanCanonicalize (H12AffineFastState.compose env35006 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound35006 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35007 : List Nat := [2,4,5,16,7,17,4,3,22,18,22,1,20,0,1,19,23,1,5,0,0,17,7,21,2,17,1,22,23,22,21,16,3,6,0,0]

theorem envBound35007 : H12AffineFastState.Bounded env35007 := by
  intro p hp
  have h : env35007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35006_35007 : H12AffineEnvironment.transform 4 7 env35006 = env35007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env35006 == env35007) = true)

theorem identity35007 : scanCanonicalize (H12AffineFastState.compose env35007 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound35007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35008 : List Nat := [2,4,5,6,7,7,4,3,0,4,0,1,2,0,1,5,1,1,5,0,0,7,7,3,2,7,1,0,1,0,3,6,3,6,0,0]

theorem envBound35008 : H12AffineFastState.Bounded env35008 := by
  intro p hp
  have h : env35008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35007_35008 : H12AffineEnvironment.transform 3 6 env35007 = env35008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env35007 == env35008) = true)

def env35009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,134217728,148801,545088,96346,16876545,134709482,257,152007824,151462017,525824]

theorem envBound35009 : H12AffineFastState.Bounded env35009 := by
  intro p hp
  have h : env35009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_35009 : H12AffineEnvironment.transform 24 533641 env34771 = env35009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env34771 == env35009) = true)

def env35010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245632,148801,545088,96346,16876545,16819498,257,545104,1345,525824]

theorem envBound35010 : H12AffineFastState.Bounded env35010 := by
  intro p hp
  have h : env35010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35009_35010 : H12AffineEnvironment.transform 26 17245632 env35009 = env35010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env35009 == env35010) = true)

theorem identity35010 : scanCanonicalize (H12AffineFastState.compose env35010 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound35010 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86519,209263,17245632,148801,74814,96346,16876545,16819498,257,74798,1345,95102]

theorem envBound35011 : H12AffineFastState.Bounded env35011 := by
  intro p hp
  have h : env35011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35010_35011 : H12AffineEnvironment.transform 18 95614 env35010 = env35011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env35010 == env35011) = true)

def env35012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86519,209263,225344,148801,74814,96346,381313,323754,257,74798,1345,95102]

theorem envBound35012 : H12AffineFastState.Bounded env35012 := by
  intro p hp
  have h : env35012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35011_35012 : H12AffineEnvironment.transform 23 284032 env35011 = env35012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env35011 == env35012) = true)

def env35013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86519,94527,77840,1297,74814,96346,381313,323754,257,74798,1345,95102]

theorem envBound35013 : H12AffineFastState.Bounded env35013 := by
  intro p hp
  have h : env35013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35012_35013 : H12AffineEnvironment.transform 16 16464 env35012 = env35013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env35012 == env35013) = true)

def env35014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70887,78895,77840,1297,74814,81226,365713,308666,257,74798,1345,79470]

theorem envBound35014 : H12AffineFastState.Bounded env35014 := by
  intro p hp
  have h : env35014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35013_35014 : H12AffineEnvironment.transform 13 1296 env35013 = env35014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35013 == env35014) = true)

theorem identity35014 : scanCanonicalize (H12AffineFastState.compose env35014 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35014 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,17,266384,70887,78895,77840,1297,74814,81226,336012,262567,257,74798,1345,79470]

theorem envBound35015 : H12AffineFastState.Bounded env35015 := by
  intro p hp
  have h : env35015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35014_35015 : H12AffineEnvironment.transform 14 13341 env35014 = env35015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35014 == env35015) = true)

def env35016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,17,69648,70887,78895,77840,1297,74814,81226,8204,65831,257,74798,1345,79470]

theorem envBound35016 : H12AffineFastState.Bounded env35016 := by
  intro p hp
  have h : env35016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35015_35016 : H12AffineEnvironment.transform 17 65664 env35015 = env35016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35015 == env35016) = true)

theorem identity35016 : scanCanonicalize (H12AffineFastState.compose env35016 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound35016 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,65536,1344,65664,69671,5205,4097,477,17,69648,70887,70758,69721,1297,66679,72963,69,65831,257,66663,1345,71207]

theorem envBound35017 : H12AffineFastState.Bounded env35017 := by
  intro p hp
  have h : env35017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35016_35017 : H12AffineEnvironment.transform 12 73 env35016 = env35017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env35016 == env35017) = true)

def env35018 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,65536,1296,65664,69671,5125,4097,397,17,69648,70839,70710,69641,1297,66599,72963,21,65831,257,66615,1297,71207]

theorem envBound35018 : H12AffineFastState.Bounded env35018 := by
  intro p hp
  have h : env35018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35017_35018 : H12AffineEnvironment.transform 5 16 env35017 = env35018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35017 == env35018) = true)

theorem identity35018 : scanCanonicalize (H12AffineFastState.compose env35018 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound35018 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,4130,1296,4258,5,5125,4097,397,17,50,1173,1044,43,1297,5125,3361,21,4357,257,5141,1297,1541]

theorem envBound35019 : H12AffineFastState.Bounded env35019 := by
  intro p hp
  have h : env35019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35018_35019 : H12AffineEnvironment.transform 15 4130 env35018 = env35019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env35018 == env35019) = true)

theorem identity35019 : scanCanonicalize (H12AffineFastState.compose env35019 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound35019 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,25,1296,276,1330,1296,1458,5,277,1297,397,17,50,1173,1044,43,1297,277,3361,21,1045,257,261,1297,1541]

theorem envBound35020 : H12AffineFastState.Bounded env35020 := by
  intro p hp
  have h : env35020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35019_35020 : H12AffineEnvironment.transform 11 1296 env35019 = env35020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env35019 == env35020) = true)

theorem identity35020 : scanCanonicalize (H12AffineFastState.compose env35020 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35020 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35021 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,25,276,276,310,276,438,5,277,277,397,17,50,145,16,43,277,277,2341,21,17,257,261,277,513]

theorem envBound35021 : H12AffineFastState.Bounded env35021 := by
  intro p hp
  have h : env35021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35020_35021 : H12AffineEnvironment.transform 9 4 env35020 = env35021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35020 == env35021) = true)

theorem identity35021 : scanCanonicalize (H12AffineFastState.compose env35021 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound35021 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35022 : List Nat := [2,4,8,16,32,16,128,256,185,4,2048,276,25,276,276,310,276,438,5,277,277,397,17,50,145,16,43,277,277,2341,21,17,257,261,277,184]

theorem envBound35022 : H12AffineFastState.Bounded env35022 := by
  intro p hp
  have h : env35022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35021_35022 : H12AffineEnvironment.transform 8 185 env35021 = env35022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env35021 == env35022) = true)

theorem identity35022 : scanCanonicalize (H12AffineFastState.compose env35022 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35022 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35023 : List Nat := [2,4,8,16,10,16,128,256,147,4,2048,276,25,276,276,284,276,412,5,277,277,397,17,24,145,16,1,277,277,2319,21,17,257,261,277,146]

theorem envBound35023 : H12AffineFastState.Bounded env35023 := by
  intro p hp
  have h : env35023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35022_35023 : H12AffineEnvironment.transform 4 10 env35022 = env35023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35022 == env35023) = true)

theorem identity35023 : scanCanonicalize (H12AffineFastState.compose env35023 (packedSelected [5,7] rootPS)) = affineNative (2^(10+1) ^^^ 145) := by decide +kernel

theorem selectedBound35023 : packedSelected [5,7] rootPS < 2^1333 := by decide +kernel

def env35024 : List Nat := [2,4,8,16,10,16,128,256,147,4,145,276,25,276,276,284,276,412,5,277,277,397,17,24,145,16,1,277,277,414,21,17,257,261,277,146]

theorem envBound35024 : H12AffineFastState.Bounded env35024 := by
  intro p hp
  have h : env35024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35023_35024 : H12AffineEnvironment.transform 10 145 env35023 = env35024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 145 env35023 == env35024) = true)

theorem identity35024 : scanCanonicalize (H12AffineFastState.compose env35024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35025 : List Nat := [2,4,8,0,10,0,128,256,131,4,129,260,9,260,260,268,260,396,5,261,261,397,1,8,129,0,1,261,261,398,5,1,257,261,261,130]

theorem envBound35025 : H12AffineFastState.Bounded env35025 := by
  intro p hp
  have h : env35025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35024_35025 : H12AffineEnvironment.transform 3 0 env35024 = env35025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35024 == env35025) = true)

theorem identity35025 : scanCanonicalize (H12AffineFastState.compose env35025 (packedSelected [5,12] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound35025 : packedSelected [5,12] rootPS < 2^1333 := by decide +kernel

def env35026 : List Nat := [2,4,8,0,10,0,128,138,131,4,129,142,9,142,142,134,142,6,5,143,143,7,1,8,129,0,1,143,143,4,5,1,139,143,143,130]

theorem envBound35026 : H12AffineFastState.Bounded env35026 := by
  intro p hp
  have h : env35026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35025_35026 : H12AffineEnvironment.transform 7 138 env35025 = env35026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env35025 == env35026) = true)

theorem identity35026 : scanCanonicalize (H12AffineFastState.compose env35026 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35026 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env35027 : List Nat := [2,4,8,0,10,0,8,2,11,4,9,6,9,6,6,14,6,6,5,7,7,7,1,8,9,0,1,7,7,4,5,1,3,7,7,10]

theorem envBound35027 : H12AffineFastState.Bounded env35027 := by
  intro p hp
  have h : env35027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35026_35027 : H12AffineEnvironment.transform 6 8 env35026 = env35027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35026 == env35027) = true)

theorem identity35027 : scanCanonicalize (H12AffineFastState.compose env35027 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35027 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35028 : List Nat := [2,1,8,0,10,0,8,2,11,1,9,3,9,3,3,11,3,3,0,2,2,2,1,8,9,0,1,2,2,1,0,1,3,2,2,10]

theorem envBound35028 : H12AffineFastState.Bounded env35028 := by
  intro p hp
  have h : env35028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35027_35028 : H12AffineEnvironment.transform 1 1 env35027 = env35028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35027 == env35028) = true)

theorem identity35028 : scanCanonicalize (H12AffineFastState.compose env35028 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35028 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35029 : List Nat := [2,1,2,0,0,0,2,2,1,1,3,3,3,3,3,1,3,3,0,2,2,2,1,2,3,0,1,2,2,1,0,1,3,2,2,0]

theorem envBound35029 : H12AffineFastState.Bounded env35029 := by
  intro p hp
  have h : env35029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35028_35029 : H12AffineEnvironment.transform 2 2 env35028 = env35029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35028 == env35029) = true)

theorem identity35029 : scanCanonicalize (H12AffineFastState.compose env35029 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35030 : List Nat := [1,1,1,0,0,0,1,1,1,1,0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,0,1,1,1,1,0,1,0,1,1,0]

theorem envBound35030 : H12AffineFastState.Bounded env35030 := by
  intro p hp
  have h : env35030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35029_35030 : H12AffineEnvironment.transform 0 1 env35029 = env35030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35029 == env35030) = true)

def env35031 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5125,65536,1297,65664,69671,5124,4097,396,17,69648,70838,70711,69640,1297,66598,72963,20,65831,257,66614,1296,71207]

theorem envBound35031 : H12AffineFastState.Bounded env35031 := by
  intro p hp
  have h : env35031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35017_35031 : H12AffineEnvironment.transform 5 17 env35017 = env35031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35017 == env35031) = true)

theorem identity35031 : scanCanonicalize (H12AffineFastState.compose env35031 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35031 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35032 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,24,276,4097,65536,277,65664,69671,4096,4097,396,17,69648,69810,69683,69640,277,65570,71943,20,65831,257,65586,276,70179]

theorem envBound35032 : H12AffineFastState.Bounded env35032 := by
  intro p hp
  have h : env35032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35031_35032 : H12AffineEnvironment.transform 9 4 env35031 = env35032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35031 == env35032) = true)

theorem identity35032 : scanCanonicalize (H12AffineFastState.compose env35032 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound35032 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35033 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,24,276,4097,311,277,439,4368,4096,4097,396,17,4391,4485,4356,4415,277,277,6192,20,16,257,261,276,4884]

theorem envBound35033 : H12AffineFastState.Bounded env35033 := by
  intro p hp
  have h : env35033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35032_35033 : H12AffineEnvironment.transform 15 311 env35032 = env35033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env35032 == env35033) = true)

theorem identity35033 : scanCanonicalize (H12AffineFastState.compose env35033 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound35033 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35034 : List Nat := [2,4,8,16,32,17,128,256,512,4,788,4096,24,276,4097,311,277,439,4368,4096,4097,396,17,4391,4485,4356,4415,277,277,4900,20,16,257,261,276,4884]

theorem envBound35034 : H12AffineFastState.Bounded env35034 := by
  intro p hp
  have h : env35034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35033_35034 : H12AffineEnvironment.transform 10 788 env35033 = env35034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env35033 == env35034) = true)

theorem identity35034 : scanCanonicalize (H12AffineFastState.compose env35034 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35034 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env35035 : List Nat := [2,4,8,16,32,17,128,256,1,4,277,4096,24,276,4097,311,277,439,4368,4096,4097,396,17,4391,4485,4356,4415,277,277,4389,20,16,257,261,276,4373]

theorem envBound35035 : H12AffineFastState.Bounded env35035 := by
  intro p hp
  have h : env35035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35034_35035 : H12AffineEnvironment.transform 8 1 env35034 = env35035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35034 == env35035) = true)

theorem identity35035 : scanCanonicalize (H12AffineFastState.compose env35035 (packedSelected [0,7,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35035 : packedSelected [0,7,10,12,18] rootPS < 2^1333 := by decide +kernel

def env35036 : List Nat := [2,4,8,16,32,17,128,36,1,4,49,4096,24,48,4097,19,49,147,4148,4096,4097,168,17,4099,4257,4128,4123,49,49,4097,20,16,37,33,48,4145]

theorem envBound35036 : H12AffineFastState.Bounded env35036 := by
  intro p hp
  have h : env35036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35035_35036 : H12AffineEnvironment.transform 7 36 env35035 = env35036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35035 == env35036) = true)

theorem identity35036 : scanCanonicalize (H12AffineFastState.compose env35036 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 147) := by decide +kernel

theorem selectedBound35036 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env35037 : List Nat := [2,4,8,16,32,17,128,36,1,4,49,147,24,48,146,19,49,147,167,147,146,168,17,144,50,179,136,49,49,146,20,16,37,33,48,162]

theorem envBound35037 : H12AffineFastState.Bounded env35037 := by
  intro p hp
  have h : env35037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35036_35037 : H12AffineEnvironment.transform 11 147 env35036 = env35037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 147 env35036 == env35037) = true)

theorem identity35037 : scanCanonicalize (H12AffineFastState.compose env35037 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35037 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35038 : List Nat := [2,4,8,16,17,17,128,21,1,4,0,147,24,1,146,19,0,147,150,147,146,153,17,144,3,130,136,0,0,146,20,16,20,16,1,147]

theorem envBound35038 : H12AffineFastState.Bounded env35038 := by
  intro p hp
  have h : env35038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35037_35038 : H12AffineEnvironment.transform 4 17 env35037 = env35038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35037 == env35038) = true)

def env35039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,17,69649,70887,78895,77840,1297,74814,81226,8205,65830,257,74798,1345,79470]

theorem envBound35039 : H12AffineFastState.Bounded env35039 := by
  intro p hp
  have h : env35039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35015_35039 : H12AffineEnvironment.transform 17 65665 env35015 = env35039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35015 == env35039) = true)

theorem identity35039 : scanCanonicalize (H12AffineFastState.compose env35039 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound35039 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,65536,1344,65665,66919,277,4097,477,17,69649,70887,65830,66841,1297,69943,67651,5380,65830,257,69927,1345,66407]

theorem envBound35040 : H12AffineFastState.Bounded env35040 := by
  intro p hp
  have h : env35040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35039_35040 : H12AffineEnvironment.transform 12 5385 env35039 = env35040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env35039 == env35040) = true)

def env35041 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,65536,1296,65665,66871,277,4097,397,17,69649,70839,65830,66841,1297,69943,67603,5380,65830,257,69927,1297,66359]

theorem envBound35041 : H12AffineFastState.Bounded env35041 := by
  intro p hp
  have h : env35041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35040_35041 : H12AffineEnvironment.transform 5 16 env35040 = env35041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35040 == env35041) = true)

theorem identity35041 : scanCanonicalize (H12AffineFastState.compose env35041 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound35041 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35042 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,1330,1296,1459,5,277,4097,397,17,5411,4485,1044,43,1297,5125,3361,5380,1044,257,5141,1297,1541]

theorem envBound35042 : H12AffineFastState.Bounded env35042 := by
  intro p hp
  have h : env35042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35041_35042 : H12AffineEnvironment.transform 15 1330 env35041 = env35042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env35041 == env35042) = true)

theorem identity35042 : scanCanonicalize (H12AffineFastState.compose env35042 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound35042 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35043 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1052,1296,276,1330,1296,1459,5,277,276,397,17,1078,144,1044,43,1297,1296,3361,1041,1044,257,1280,1297,1541]

theorem envBound35043 : H12AffineFastState.Bounded env35043 := by
  intro p hp
  have h : env35043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35042_35043 : H12AffineEnvironment.transform 11 277 env35042 = env35043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env35042 == env35043) = true)

theorem identity35043 : scanCanonicalize (H12AffineFastState.compose env35043 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound35043 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env35044 : List Nat := [2,4,8,16,32,16,128,256,147,1024,2048,277,1052,1296,276,1330,1296,1459,5,277,276,397,17,1078,144,1044,43,1297,1296,3361,1041,1044,257,1280,1297,1174]

theorem envBound35044 : H12AffineFastState.Bounded env35044 := by
  intro p hp
  have h : env35044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35043_35044 : H12AffineEnvironment.transform 8 147 env35043 = env35044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env35043 == env35044) = true)

theorem identity35044 : scanCanonicalize (H12AffineFastState.compose env35044 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 1338) := by decide +kernel

theorem selectedBound35044 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env35045 : List Nat := [2,4,8,16,32,16,128,256,147,1024,1338,277,1052,1296,276,1330,1296,1459,5,277,276,397,17,1078,144,1044,43,1297,1296,27,1041,1044,257,1280,1297,1174]

theorem envBound35045 : H12AffineFastState.Bounded env35045 := by
  intro p hp
  have h : env35045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35044_35045 : H12AffineEnvironment.transform 10 1338 env35044 = env35045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1338 env35044 == env35045) = true)

theorem identity35045 : scanCanonicalize (H12AffineFastState.compose env35045 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound35045 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35046 : List Nat := [2,4,8,16,32,16,128,172,147,1024,1174,185,1052,1212,184,1182,1212,1055,5,185,184,33,17,1078,144,1044,43,1213,1212,27,1041,1044,173,1196,1213,1174]

theorem envBound35046 : H12AffineFastState.Bounded env35046 := by
  intro p hp
  have h : env35046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35045_35046 : H12AffineEnvironment.transform 7 172 env35045 = env35046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env35045 == env35046) = true)

theorem identity35046 : scanCanonicalize (H12AffineFastState.compose env35046 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound35046 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env35047 : List Nat := [2,4,8,16,32,16,19,63,0,1024,1029,42,1052,1071,43,1037,1071,1055,5,42,43,33,17,1078,3,1044,43,1070,1071,27,1041,1044,62,1087,1070,1029]

theorem envBound35047 : H12AffineFastState.Bounded env35047 := by
  intro p hp
  have h : env35047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35046_35047 : H12AffineEnvironment.transform 6 19 env35046 = env35047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env35046 == env35047) = true)

theorem identity35047 : scanCanonicalize (H12AffineFastState.compose env35047 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35047 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env35048 : List Nat := [2,4,8,16,32,16,19,63,0,53,48,42,41,26,43,56,26,42,5,42,43,33,17,3,3,33,43,27,26,27,36,33,62,10,27,48]

theorem envBound35048 : H12AffineFastState.Bounded env35048 := by
  intro p hp
  have h : env35048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2