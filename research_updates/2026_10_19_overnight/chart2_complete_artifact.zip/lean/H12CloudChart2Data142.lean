import H12CloudChart2Data141

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans35305_35306 : H12AffineEnvironment.transform 12 656 env35305 = env35306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env35305 == env35306) = true)

theorem identity35306 : scanCanonicalize (H12AffineFastState.compose env35306 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound35306 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env35307 : List Nat := [2,4,8,16,32,1,128,5,512,5,539,0,656,16,648,51,649,179,4,649,1,153,665,34,536,649,59,665,16,179,669,17,4,1,1,513]

theorem envBound35307 : H12AffineFastState.Bounded env35307 := by
  intro p hp
  have h : env35307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35306_35307 : H12AffineEnvironment.transform 10 539 env35306 = env35307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env35306 == env35307) = true)

theorem identity35307 : scanCanonicalize (H12AffineFastState.compose env35307 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound35307 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35308 : List Nat := [2,4,8,16,32,1,57,5,512,5,539,0,553,16,561,51,560,10,4,560,1,32,544,34,536,560,59,544,16,10,548,17,4,1,1,513]

theorem envBound35308 : H12AffineFastState.Bounded env35308 := by
  intro p hp
  have h : env35308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35307_35308 : H12AffineEnvironment.transform 6 57 env35307 = env35308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env35307 == env35308) = true)

theorem identity35308 : scanCanonicalize (H12AffineFastState.compose env35308 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound35308 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35309 : List Nat := [2,4,8,16,32,1,57,5,26,5,1,0,51,16,43,51,42,10,4,42,1,32,58,34,2,42,59,58,16,10,62,17,4,1,1,27]

theorem envBound35309 : H12AffineFastState.Bounded env35309 := by
  intro p hp
  have h : env35309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35308_35309 : H12AffineEnvironment.transform 8 26 env35308 = env35309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env35308 == env35309) = true)

theorem identity35309 : scanCanonicalize (H12AffineFastState.compose env35309 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound35309 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35310 : List Nat := [2,4,8,16,22,1,15,5,26,5,1,0,5,16,29,5,28,10,4,28,1,22,12,20,2,28,13,12,16,10,8,17,4,1,1,27]

theorem envBound35310 : H12AffineFastState.Bounded env35310 := by
  intro p hp
  have h : env35310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35309_35310 : H12AffineEnvironment.transform 4 22 env35309 = env35310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env35309 == env35310) = true)

theorem identity35310 : scanCanonicalize (H12AffineFastState.compose env35310 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound35310 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35311 : List Nat := [2,4,8,7,1,1,15,5,13,5,1,0,5,7,10,5,11,10,4,11,1,1,12,3,2,11,13,12,7,10,8,6,4,1,1,12]

theorem envBound35311 : H12AffineFastState.Bounded env35311 := by
  intro p hp
  have h : env35311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35310_35311 : H12AffineEnvironment.transform 3 7 env35310 = env35311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env35310 == env35311) = true)

theorem identity35311 : scanCanonicalize (H12AffineFastState.compose env35311 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35311 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35312 : List Nat := [2,2,8,1,1,1,9,3,11,3,1,0,3,1,10,3,11,10,2,11,1,1,10,3,2,11,11,10,1,10,8,0,2,1,1,10]

theorem envBound35312 : H12AffineFastState.Bounded env35312 := by
  intro p hp
  have h : env35312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35311_35312 : H12AffineEnvironment.transform 1 2 env35311 = env35312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35311 == env35312) = true)

theorem identity35312 : scanCanonicalize (H12AffineFastState.compose env35312 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35313 : List Nat := [1,1,8,1,1,1,9,0,8,0,1,0,0,1,9,0,8,9,1,8,1,1,9,0,1,8,8,9,1,9,8,0,1,1,1,9]

theorem envBound35313 : H12AffineFastState.Bounded env35313 := by
  intro p hp
  have h : env35313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35312_35313 : H12AffineEnvironment.transform 0 1 env35312 = env35313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35312 == env35313) = true)

theorem identity35313 : scanCanonicalize (H12AffineFastState.compose env35313 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35314 : List Nat := [1,1,1,1,1,1,0,0,1,0,1,0,0,1,0,0,1,0,1,1,1,1,0,0,1,1,1,0,1,0,1,0,1,1,1,0]

theorem envBound35314 : H12AffineFastState.Bounded env35314 := by
  intro p hp
  have h : env35314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35313_35314 : H12AffineEnvironment.transform 2 1 env35313 = env35314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35313 == env35314) = true)

def env35315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4097,5276,74047,66896,13769,78895,1150,74815,1296,81226,8205,65831,257,1281,1344,5952]

theorem envBound35315 : H12AffineFastState.Bounded env35315 := by
  intro p hp
  have h : env35315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35288_35315 : H12AffineEnvironment.transform 17 65665 env35288 = env35315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35288 == env35315) = true)

theorem identity35315 : scanCanonicalize (H12AffineFastState.compose env35315 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35315 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35316 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,65536,74031,65665,4416,8541,4097,4573,74047,65553,12424,78190,319,74110,81,79883,8205,65831,257,64,1,4609]

theorem envBound35316 : H12AffineFastState.Bounded env35316 := by
  intro p hp
  have h : env35316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35315_35316 : H12AffineEnvironment.transform 9 321 env35315 = env35316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35315 == env35316) = true)

def env35317 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,81,8540,65536,74031,65665,532,8541,853,649,74047,65553,9180,74298,319,74110,81,76639,8205,65831,257,64,1,341]

theorem envBound35317 : H12AffineFastState.Bounded env35317 := by
  intro p hp
  have h : env35317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35316_35317 : H12AffineEnvironment.transform 11 852 env35316 = env35317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env35316 == env35317) = true)

def env35318 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,65,8524,65536,74031,65665,516,8525,837,649,74031,65537,9164,74282,303,74094,65,76623,8205,65831,257,64,1,325]

theorem envBound35318 : H12AffineFastState.Bounded env35318 := by
  intro p hp
  have h : env35318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35317_35318 : H12AffineEnvironment.transform 3 0 env35317 = env35318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35317 == env35318) = true)

theorem identity35318 : scanCanonicalize (H12AffineFastState.compose env35318 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 717) := by decide +kernel

theorem selectedBound35318 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35319 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,717,65,897,65536,66530,65665,516,896,837,649,66530,65537,257,65767,303,66467,65,67970,704,65831,257,64,1,325]

theorem envBound35319 : H12AffineFastState.Bounded env35319 := by
  intro p hp
  have h : env35319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35318_35319 : H12AffineEnvironment.transform 12 717 env35318 = env35319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 717 env35318 == env35319) = true)

def env35320 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,717,65,897,932,70,805,516,896,837,649,70,933,257,835,303,7,65,2598,704,643,257,64,1,325]

theorem envBound35320 : H12AffineFastState.Bounded env35320 := by
  intro p hp
  have h : env35320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35319_35320 : H12AffineEnvironment.transform 15 932 env35319 = env35320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 932 env35319 == env35320) = true)

theorem identity35320 : scanCanonicalize (H12AffineFastState.compose env35320 (packedSelected [0,1,2,4,5,7,9,10,15,16,17,19,20,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 619) := by decide +kernel

theorem selectedBound35320 : packedSelected [0,1,2,4,5,7,9,10,15,16,17,19,20,21,23,32] rootPS < 2^1333 := by decide +kernel

def env35321 : List Nat := [2,4,8,0,32,64,128,256,512,321,619,836,717,65,897,932,70,805,516,896,837,649,70,933,257,835,303,7,65,77,704,643,257,64,1,325]

theorem envBound35321 : H12AffineFastState.Bounded env35321 := by
  intro p hp
  have h : env35321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35320_35321 : H12AffineEnvironment.transform 10 619 env35320 = env35321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 619 env35320 == env35321) = true)

theorem identity35321 : scanCanonicalize (H12AffineFastState.compose env35321 (packedSelected [1,3,4,5,8,9,10,11,12,13,15,16,18,19,20,24] rootPS)) = affineNative (2^(8+1) ^^^ 355) := by decide +kernel

theorem selectedBound35321 : packedSelected [1,3,4,5,8,9,10,11,12,13,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env35322 : List Nat := [2,4,8,0,32,64,128,256,355,321,264,39,430,65,226,199,70,70,359,227,38,490,70,198,257,32,303,7,65,77,419,480,257,64,1,325]

theorem envBound35322 : H12AffineFastState.Bounded env35322 := by
  intro p hp
  have h : env35322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35321_35322 : H12AffineEnvironment.transform 8 355 env35321 = env35322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 355 env35321 == env35322) = true)

theorem identity35322 : scanCanonicalize (H12AffineFastState.compose env35322 (packedSelected [2,5,10,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35322 : packedSelected [2,5,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env35323 : List Nat := [2,4,8,0,32,64,8,256,355,321,264,39,294,65,106,79,70,70,359,107,38,354,70,78,257,32,303,7,65,77,299,360,257,64,1,325]

theorem envBound35323 : H12AffineFastState.Bounded env35323 := by
  intro p hp
  have h : env35323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35322_35323 : H12AffineEnvironment.transform 6 8 env35322 = env35323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35322 == env35323) = true)

theorem identity35323 : scanCanonicalize (H12AffineFastState.compose env35323 (packedSelected [0,1,2,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound35323 : packedSelected [0,1,2,4,10] rootPS < 2^1333 := by decide +kernel

def env35324 : List Nat := [2,4,8,0,32,64,8,98,1,35,106,39,68,65,106,79,70,70,5,107,38,0,70,78,99,32,77,7,65,77,73,10,99,64,1,39]

theorem envBound35324 : H12AffineFastState.Bounded env35324 := by
  intro p hp
  have h : env35324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35323_35324 : H12AffineEnvironment.transform 7 98 env35323 = env35324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env35323 == env35324) = true)

theorem identity35324 : scanCanonicalize (H12AffineFastState.compose env35324 (packedSelected [4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound35324 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env35325 : List Nat := [2,4,8,0,32,10,8,40,1,35,32,39,14,11,32,5,12,12,5,33,38,0,12,4,41,32,7,7,11,7,3,10,41,10,1,39]

theorem envBound35325 : H12AffineFastState.Bounded env35325 := by
  intro p hp
  have h : env35325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35324_35325 : H12AffineEnvironment.transform 5 10 env35324 = env35325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env35324 == env35325) = true)

theorem identity35325 : scanCanonicalize (H12AffineFastState.compose env35325 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35326 : List Nat := [2,4,5,0,32,7,5,37,1,35,32,39,3,6,32,5,1,1,5,33,38,0,1,4,36,32,7,7,6,7,3,7,36,7,1,39]

theorem envBound35326 : H12AffineFastState.Bounded env35326 := by
  intro p hp
  have h : env35326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35325_35326 : H12AffineEnvironment.transform 2 5 env35325 = env35326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35325 == env35326) = true)

theorem identity35326 : scanCanonicalize (H12AffineFastState.compose env35326 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35326 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35327 : List Nat := [2,4,5,0,1,7,5,4,1,2,1,6,3,6,1,5,1,1,5,0,7,0,1,4,5,1,7,7,6,7,3,7,5,7,1,6]

theorem envBound35327 : H12AffineFastState.Bounded env35327 := by
  intro p hp
  have h : env35327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35326_35327 : H12AffineEnvironment.transform 4 1 env35326 = env35327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35326 == env35327) = true)

theorem identity35327 : scanCanonicalize (H12AffineFastState.compose env35327 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35327 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35328 : List Nat := [2,3,2,0,1,0,2,3,1,2,1,1,3,1,1,2,1,1,2,0,0,0,1,3,2,1,0,0,1,0,3,0,2,0,1,1]

theorem envBound35328 : H12AffineFastState.Bounded env35328 := by
  intro p hp
  have h : env35328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35327_35328 : H12AffineEnvironment.transform 1 3 env35327 = env35328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35327 == env35328) = true)

def env35329 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,717,65,897,933,71,804,516,896,837,649,71,932,257,834,303,6,65,2599,704,642,257,64,1,325]

theorem envBound35329 : H12AffineFastState.Bounded env35329 := by
  intro p hp
  have h : env35329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35319_35329 : H12AffineEnvironment.transform 15 933 env35319 = env35329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 933 env35319 == env35329) = true)

theorem identity35329 : scanCanonicalize (H12AffineFastState.compose env35329 (packedSelected [0,1,2,4,5,7,9,10,15,16,17,19,20,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound35329 : packedSelected [0,1,2,4,5,7,9,10,15,16,17,19,20,21,23,32] rootPS < 2^1333 := by decide +kernel

def env35330 : List Nat := [2,4,8,0,32,64,128,256,512,321,169,836,717,65,897,933,71,804,516,896,837,649,71,932,257,834,303,6,65,654,704,642,257,64,1,325]

theorem envBound35330 : H12AffineFastState.Bounded env35330 := by
  intro p hp
  have h : env35330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35329_35330 : H12AffineEnvironment.transform 10 169 env35329 = env35330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env35329 == env35330) = true)

theorem identity35330 : scanCanonicalize (H12AffineFastState.compose env35330 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 108) := by decide +kernel

theorem selectedBound35330 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env35331 : List Nat := [2,4,8,0,32,64,128,256,108,321,169,296,161,65,493,457,71,328,104,492,297,229,71,456,257,302,303,6,65,226,172,238,257,64,1,325]

theorem envBound35331 : H12AffineFastState.Bounded env35331 := by
  intro p hp
  have h : env35331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35330_35331 : H12AffineEnvironment.transform 8 108 env35330 = env35331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 108 env35330 == env35331) = true)

theorem identity35331 : scanCanonicalize (H12AffineFastState.compose env35331 (packedSelected [3,4,5,8,9,10,12,15,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35331 : packedSelected [3,4,5,8,9,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35332 : List Nat := [2,4,5,0,32,64,128,256,97,321,164,293,161,65,480,452,71,325,101,481,292,229,71,453,257,291,290,6,65,226,161,227,257,64,1,325]

theorem envBound35332 : H12AffineFastState.Bounded env35332 := by
  intro p hp
  have h : env35332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35331_35332 : H12AffineEnvironment.transform 2 5 env35331 = env35332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35331 == env35332) = true)

theorem identity35332 : scanCanonicalize (H12AffineFastState.compose env35332 (packedSelected [2,3,5,7,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound35332 : packedSelected [2,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env35333 : List Nat := [2,4,5,0,32,64,128,192,97,129,164,229,161,65,32,4,71,133,101,33,228,229,71,5,193,227,226,6,65,226,161,227,193,64,1,133]

theorem envBound35333 : H12AffineFastState.Bounded env35333 := by
  intro p hp
  have h : env35333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35332_35333 : H12AffineEnvironment.transform 7 192 env35332 = env35333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env35332 == env35333) = true)

theorem identity35333 : scanCanonicalize (H12AffineFastState.compose env35333 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound35333 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35334 : List Nat := [2,4,5,0,32,64,36,100,97,37,0,65,5,65,32,4,71,33,101,33,64,65,71,5,101,71,70,6,65,70,5,71,101,64,1,33]

theorem envBound35334 : H12AffineFastState.Bounded env35334 := by
  intro p hp
  have h : env35334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35333_35334 : H12AffineEnvironment.transform 6 36 env35333 = env35334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env35333 == env35334) = true)

theorem identity35334 : scanCanonicalize (H12AffineFastState.compose env35334 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound35334 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env35335 : List Nat := [2,4,5,0,32,1,36,37,32,37,0,0,5,0,32,4,6,33,36,33,1,0,6,5,36,6,7,6,0,7,5,6,36,1,1,33]

theorem envBound35335 : H12AffineFastState.Bounded env35335 := by
  intro p hp
  have h : env35335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35334_35335 : H12AffineEnvironment.transform 5 1 env35334 = env35335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35334 == env35335) = true)

theorem identity35335 : scanCanonicalize (H12AffineFastState.compose env35335 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35335 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35336 : List Nat := [1,4,5,0,32,1,36,37,32,37,0,0,5,0,32,4,5,33,36,33,1,0,5,5,36,5,4,5,0,4,5,5,36,1,1,33]

theorem envBound35336 : H12AffineFastState.Bounded env35336 := by
  intro p hp
  have h : env35336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35335_35336 : H12AffineEnvironment.transform 0 1 env35335 = env35336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35335 == env35336) = true)

theorem identity35336 : scanCanonicalize (H12AffineFastState.compose env35336 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35336 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35337 : List Nat := [1,4,5,0,0,1,4,5,0,5,0,0,5,0,0,4,5,1,4,1,1,0,5,5,4,5,4,5,0,4,5,5,4,1,1,1]

theorem envBound35337 : H12AffineFastState.Bounded env35337 := by
  intro p hp
  have h : env35337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35336_35337 : H12AffineEnvironment.transform 4 0 env35336 = env35337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35336 == env35337) = true)

def env35338 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,64,8525,65536,74031,65665,517,8524,836,649,74030,65536,9165,74283,302,74095,64,76622,8205,65831,257,64,1,324]

theorem envBound35338 : H12AffineFastState.Bounded env35338 := by
  intro p hp
  have h : env35338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35317_35338 : H12AffineEnvironment.transform 3 1 env35317 = env35338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35317 == env35338) = true)

theorem identity35338 : scanCanonicalize (H12AffineFastState.compose env35338 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound35338 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35339 : List Nat := [2,4,8,1,32,64,128,256,133,321,2048,448,8192,64,8525,65536,74031,65665,128,8524,449,12,74030,65536,8520,73902,302,74095,64,76235,8205,65831,257,64,1,324]

theorem envBound35339 : H12AffineFastState.Bounded env35339 := by
  intro p hp
  have h : env35339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35338_35339 : H12AffineEnvironment.transform 8 133 env35338 = env35339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env35338 == env35339) = true)

def env35340 : List Nat := [2,4,8,1,32,64,128,256,133,321,2048,448,8192,64,8525,8552,71,8681,128,8524,449,12,70,8552,8520,454,302,7,64,2211,8205,8271,257,64,1,324]

theorem envBound35340 : H12AffineFastState.Bounded env35340 := by
  intro p hp
  have h : env35340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35339_35340 : H12AffineEnvironment.transform 15 8552 env35339 = env35340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8552 env35339 == env35340) = true)

theorem identity35340 : scanCanonicalize (H12AffineFastState.compose env35340 (packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound35340 : packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS < 2^1333 := by decide +kernel

def env35341 : List Nat := [2,4,8,1,32,64,128,256,133,321,260,448,8192,64,8525,8552,71,8681,128,8524,449,12,70,8552,8520,454,302,7,64,423,8205,8271,257,64,1,324]

theorem envBound35341 : H12AffineFastState.Bounded env35341 := by
  intro p hp
  have h : env35341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35340_35341 : H12AffineEnvironment.transform 10 260 env35340 = env35341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env35340 == env35341) = true)

theorem identity35341 : scanCanonicalize (H12AffineFastState.compose env35341 (packedSelected [0,1,2,3,4,8,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 352) := by decide +kernel

theorem selectedBound35341 : packedSelected [0,1,2,3,4,8,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env35342 : List Nat := [2,4,8,1,32,64,128,256,133,321,260,448,352,64,45,8,71,137,128,44,449,12,70,8,40,454,302,7,64,423,365,303,257,64,1,324]

theorem envBound35342 : H12AffineFastState.Bounded env35342 := by
  intro p hp
  have h : env35342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35341_35342 : H12AffineEnvironment.transform 12 352 env35341 = env35342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 352 env35341 == env35342) = true)

theorem identity35342 : scanCanonicalize (H12AffineFastState.compose env35342 (packedSelected [2,3,7,9,12,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound35342 : packedSelected [2,3,7,9,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env35343 : List Nat := [2,4,8,1,32,64,128,66,133,3,70,130,34,64,45,8,71,137,128,44,131,12,70,8,40,132,108,7,64,229,47,109,67,64,1,6]

theorem envBound35343 : H12AffineFastState.Bounded env35343 := by
  intro p hp
  have h : env35343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35342_35343 : H12AffineEnvironment.transform 7 66 env35342 = env35343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env35342 == env35343) = true)

theorem identity35343 : scanCanonicalize (H12AffineFastState.compose env35343 (packedSelected [5,10] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound35343 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35344 : List Nat := [2,4,8,1,32,7,128,5,133,3,1,130,34,7,45,8,0,137,128,44,131,12,1,8,40,132,43,7,7,162,47,42,4,7,1,6]

theorem envBound35344 : H12AffineFastState.Bounded env35344 := by
  intro p hp
  have h : env35344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35343_35344 : H12AffineEnvironment.transform 5 7 env35343 = env35344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env35343 == env35344) = true)

theorem identity35344 : scanCanonicalize (H12AffineFastState.compose env35344 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound35344 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env35345 : List Nat := [2,4,8,1,32,7,40,5,45,3,1,42,34,7,45,8,0,33,40,44,43,12,1,8,40,44,43,7,7,10,47,42,4,7,1,6]

theorem envBound35345 : H12AffineFastState.Bounded env35345 := by
  intro p hp
  have h : env35345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35344_35345 : H12AffineEnvironment.transform 6 40 env35344 = env35345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env35344 == env35345) = true)

theorem identity35345 : scanCanonicalize (H12AffineFastState.compose env35345 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35345 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35346 : List Nat := [2,4,2,1,32,7,34,5,39,3,1,32,34,7,39,2,0,33,34,38,33,6,1,2,34,38,33,7,7,0,37,32,4,7,1,6]

theorem envBound35346 : H12AffineFastState.Bounded env35346 := by
  intro p hp
  have h : env35346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35345_35346 : H12AffineEnvironment.transform 2 2 env35345 = env35346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35345 == env35346) = true)

theorem identity35346 : scanCanonicalize (H12AffineFastState.compose env35346 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35346 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35347 : List Nat := [2,4,2,1,0,7,2,5,7,3,1,0,2,7,7,2,0,1,2,6,1,6,1,2,2,6,1,7,7,0,5,0,4,7,1,6]

theorem envBound35347 : H12AffineFastState.Bounded env35347 := by
  intro p hp
  have h : env35347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35346_35347 : H12AffineEnvironment.transform 4 0 env35346 = env35347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35346 == env35347) = true)

theorem identity35347 : scanCanonicalize (H12AffineFastState.compose env35347 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35348 : List Nat := [0,4,0,1,0,5,0,5,5,1,1,0,0,5,5,0,0,1,0,4,1,4,1,0,0,4,1,5,5,0,5,0,4,5,1,4]

theorem envBound35348 : H12AffineFastState.Bounded env35348 := by
  intro p hp
  have h : env35348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35347_35348 : H12AffineEnvironment.transform 0 0 env35347 = env35348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35347 == env35348) = true)

theorem identity35348 : scanCanonicalize (H12AffineFastState.compose env35348 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35348 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35349 : List Nat := [0,1,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,1,1,1,1,0,0,1,1,0,0,0,0,0,1,0,1,1]

theorem envBound35349 : H12AffineFastState.Bounded env35349 := by
  intro p hp
  have h : env35349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35348_35349 : H12AffineEnvironment.transform 1 1 env35348 = env35349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35348 == env35349) = true)

def env35350 : List Nat := [2,4,8,1,32,64,128,256,133,321,2048,448,8192,64,8525,8553,70,8680,128,8524,449,12,71,8553,8520,455,302,6,64,2210,8205,8270,257,64,1,324]

theorem envBound35350 : H12AffineFastState.Bounded env35350 := by
  intro p hp
  have h : env35350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35339_35350 : H12AffineEnvironment.transform 15 8553 env35339 = env35350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8553 env35339 == env35350) = true)

theorem identity35350 : scanCanonicalize (H12AffineFastState.compose env35350 (packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound35350 : packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS < 2^1333 := by decide +kernel

def env35351 : List Nat := [2,4,8,1,32,64,128,256,133,321,2048,448,2317,64,2112,2148,70,2277,128,2113,449,12,71,2148,2117,455,302,6,64,2210,2304,2371,257,64,1,324]

theorem envBound35351 : H12AffineFastState.Bounded env35351 := by
  intro p hp
  have h : env35351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35350_35351 : H12AffineEnvironment.transform 12 2317 env35350 = env35351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env35350 == env35351) = true)

theorem identity35351 : scanCanonicalize (H12AffineFastState.compose env35351 (packedSelected [2,3,5,11,12,13,15,16,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound35351 : packedSelected [2,3,5,11,12,13,15,16,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35352 : List Nat := [2,4,8,1,32,64,128,72,133,9,2048,136,2117,64,2112,2148,70,2277,128,2113,137,12,71,2148,2117,143,102,6,64,2210,2120,2059,73,64,1,12]

theorem envBound35352 : H12AffineFastState.Bounded env35352 := by
  intro p hp
  have h : env35352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35351_35352 : H12AffineEnvironment.transform 7 72 env35351 = env35352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env35351 == env35352) = true)

theorem identity35352 : scanCanonicalize (H12AffineFastState.compose env35352 (packedSelected [0,1,2,3,4,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound35352 : packedSelected [0,1,2,3,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env35353 : List Nat := [2,4,8,1,32,13,128,5,133,9,2048,136,2056,13,2061,2089,11,2216,128,2060,137,12,10,2089,2056,143,43,6,13,2210,2053,2059,4,13,1,12]

theorem envBound35353 : H12AffineFastState.Bounded env35353 := by
  intro p hp
  have h : env35353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35352_35353 : H12AffineEnvironment.transform 5 13 env35352 = env35353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env35352 == env35353) = true)

theorem identity35353 : scanCanonicalize (H12AffineFastState.compose env35353 (packedSelected [0,2,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35353 : packedSelected [0,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35354 : List Nat := [2,4,8,1,32,13,8,5,13,9,2048,0,2056,13,2061,2089,11,2080,8,2060,1,12,10,2089,2056,7,43,6,13,2090,2053,2059,4,13,1,12]

theorem envBound35354 : H12AffineFastState.Bounded env35354 := by
  intro p hp
  have h : env35354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35353_35354 : H12AffineEnvironment.transform 6 8 env35353 = env35354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35353 == env35354) = true)

theorem identity35354 : scanCanonicalize (H12AffineFastState.compose env35354 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35354 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env35355 : List Nat := [2,4,8,1,1,13,8,5,13,9,2048,0,2056,13,2061,2056,11,2049,8,2060,1,12,10,2056,2056,7,10,6,13,2059,2053,2059,4,13,1,12]

theorem envBound35355 : H12AffineFastState.Bounded env35355 := by
  intro p hp
  have h : env35355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35354_35355 : H12AffineEnvironment.transform 4 1 env35354 = env35355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35354 == env35355) = true)

theorem identity35355 : scanCanonicalize (H12AffineFastState.compose env35355 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35355 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35356 : List Nat := [2,4,2,1,1,7,2,5,7,3,2048,0,2050,7,2055,2050,1,2049,2,2054,1,6,0,2050,2050,7,0,6,7,2049,2053,2049,4,7,1,6]

theorem envBound35356 : H12AffineFastState.Bounded env35356 := by
  intro p hp
  have h : env35356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35355_35356 : H12AffineEnvironment.transform 2 2 env35355 = env35356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35355 == env35356) = true)

theorem identity35356 : scanCanonicalize (H12AffineFastState.compose env35356 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound35356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35357 : List Nat := [2,4,2,1,1,7,2,5,7,3,5,0,7,7,2,7,1,4,2,3,1,6,0,7,7,7,0,6,7,4,0,4,4,7,1,6]

theorem envBound35357 : H12AffineFastState.Bounded env35357 := by
  intro p hp
  have h : env35357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35356_35357 : H12AffineEnvironment.transform 10 5 env35356 = env35357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env35356 == env35357) = true)

theorem identity35357 : scanCanonicalize (H12AffineFastState.compose env35357 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35357 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35358 : List Nat := [2,0,2,1,1,3,2,1,3,3,1,0,3,3,2,3,1,0,2,3,1,2,0,3,3,3,0,2,3,0,0,0,0,3,1,2]

theorem envBound35358 : H12AffineFastState.Bounded env35358 := by
  intro p hp
  have h : env35358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35357_35358 : H12AffineEnvironment.transform 1 0 env35357 = env35358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35357 == env35358) = true)

theorem identity35358 : scanCanonicalize (H12AffineFastState.compose env35358 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35358 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35359 : List Nat := [1,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,1,0,1,0,1,1,0,0,0,0,0,1,0,0,0,0,0,0,1,1]

theorem envBound35359 : H12AffineFastState.Bounded env35359 := by
  intro p hp
  have h : env35359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35358_35359 : H12AffineEnvironment.transform 0 1 env35358 = env35359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35358 == env35359) = true)

def env35360 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,81,8540,65536,74031,65665,533,8541,852,648,74047,65553,9181,74299,319,74110,81,76638,8205,65831,257,64,1,340]

theorem envBound35360 : H12AffineFastState.Bounded env35360 := by
  intro p hp
  have h : env35360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35316_35360 : H12AffineEnvironment.transform 11 853 env35316 = env35360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env35316 == env35360) = true)

def env35361 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,65,8524,65536,74031,65665,517,8525,836,648,74031,65537,9165,74283,303,74094,65,76622,8205,65831,257,64,1,324]

theorem envBound35361 : H12AffineFastState.Bounded env35361 := by
  intro p hp
  have h : env35361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35360_35361 : H12AffineEnvironment.transform 3 0 env35360 = env35361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35360 == env35361) = true)

theorem identity35361 : scanCanonicalize (H12AffineFastState.compose env35361 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 994) := by decide +kernel

theorem selectedBound35361 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35362 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,65,8524,994,8909,867,517,8525,836,648,8909,995,9165,8649,303,8844,65,10412,8205,709,257,64,1,324]

theorem envBound35362 : H12AffineFastState.Bounded env35362 := by
  intro p hp
  have h : env35362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35361_35362 : H12AffineEnvironment.transform 15 994 env35361 = env35362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 994 env35361 == env35362) = true)

def env35363 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8,65,324,994,709,867,517,325,836,648,709,995,965,449,303,644,65,2212,5,709,257,64,1,324]

theorem envBound35363 : H12AffineFastState.Bounded env35363 := by
  intro p hp
  have h : env35363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35362_35363 : H12AffineEnvironment.transform 12 8 env35362 = env35363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env35362 == env35363) = true)

theorem identity35363 : scanCanonicalize (H12AffineFastState.compose env35363 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound35363 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env35364 : List Nat := [2,4,8,0,32,64,128,256,512,321,577,837,8,65,324,994,709,867,517,325,836,648,709,995,965,449,303,644,65,741,5,709,257,64,1,324]

theorem envBound35364 : H12AffineFastState.Bounded env35364 := by
  intro p hp
  have h : env35364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35363_35364 : H12AffineEnvironment.transform 10 577 env35363 = env35364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env35363 == env35364) = true)

def env35365 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,9,65,325,994,708,867,517,324,836,648,708,995,964,448,303,645,65,2213,4,709,257,64,1,324]

theorem envBound35365 : H12AffineFastState.Bounded env35365 := by
  intro p hp
  have h : env35365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35362_35365 : H12AffineEnvironment.transform 12 9 env35362 = env35365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env35362 == env35365) = true)

theorem identity35365 : scanCanonicalize (H12AffineFastState.compose env35365 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound35365 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env35366 : List Nat := [2,4,8,0,32,64,128,256,512,321,259,837,9,65,325,994,708,867,517,324,836,648,708,995,964,448,303,645,65,422,4,709,257,64,1,324]

theorem envBound35366 : H12AffineFastState.Bounded env35366 := by
  intro p hp
  have h : env35366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35365_35366 : H12AffineEnvironment.transform 10 259 env35365 = env35366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env35365 == env35366) = true)

theorem identity35366 : scanCanonicalize (H12AffineFastState.compose env35366 (packedSelected [0,2,3,4,7,8,9,11,12,15,16,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 481) := by decide +kernel

theorem selectedBound35366 : packedSelected [0,2,3,4,7,8,9,11,12,15,16,17,21] rootPS < 2^1333 := by decide +kernel

def env35367 : List Nat := [2,4,8,0,32,64,128,256,481,321,259,164,9,65,325,3,293,130,484,324,165,361,293,2,37,448,303,356,65,422,4,292,257,64,1,324]

theorem envBound35367 : H12AffineFastState.Bounded env35367 := by
  intro p hp
  have h : env35367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35366_35367 : H12AffineEnvironment.transform 8 481 env35366 = env35367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 481 env35366 == env35367) = true)

theorem identity35367 : scanCanonicalize (H12AffineFastState.compose env35367 (packedSelected [3,8,10,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound35367 : packedSelected [3,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env35368 : List Nat := [2,4,8,0,32,64,128,205,44,140,206,164,9,65,136,3,232,130,41,137,165,164,232,2,37,13,226,169,65,107,4,233,204,64,1,137]

theorem envBound35368 : H12AffineFastState.Bounded env35368 := by
  intro p hp
  have h : env35368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35367_35368 : H12AffineEnvironment.transform 7 205 env35367 = env35368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env35367 == env35368) = true)

theorem identity35368 : scanCanonicalize (H12AffineFastState.compose env35368 (packedSelected [1,3,4,5,9,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35368 : packedSelected [1,3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35369 : List Nat := [2,4,3,0,32,64,128,198,39,135,197,164,2,65,131,3,227,130,34,130,165,164,227,2,37,6,226,162,65,96,4,226,199,64,1,130]

theorem envBound35369 : H12AffineFastState.Bounded env35369 := by
  intro p hp
  have h : env35369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35368_35369 : H12AffineEnvironment.transform 2 3 env35368 = env35369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35368 == env35369) = true)

theorem identity35369 : scanCanonicalize (H12AffineFastState.compose env35369 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35369 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env35370 : List Nat := [2,4,3,0,32,0,128,134,39,135,133,164,2,1,131,3,163,130,34,130,165,164,163,2,37,6,162,162,1,32,4,162,135,0,1,130]

theorem envBound35370 : H12AffineFastState.Bounded env35370 := by
  intro p hp
  have h : env35370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35369_35370 : H12AffineEnvironment.transform 5 0 env35369 = env35370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35369 == env35370) = true)

theorem identity35370 : scanCanonicalize (H12AffineFastState.compose env35370 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound35370 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35371 : List Nat := [2,4,3,0,32,0,34,36,39,37,39,6,2,1,33,3,1,32,34,32,7,6,1,2,37,6,0,0,1,32,4,0,37,0,1,32]

theorem envBound35371 : H12AffineFastState.Bounded env35371 := by
  intro p hp
  have h : env35371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35370_35371 : H12AffineEnvironment.transform 6 34 env35370 = env35371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env35370 == env35371) = true)

theorem identity35371 : scanCanonicalize (H12AffineFastState.compose env35371 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35372 : List Nat := [2,4,3,0,1,0,3,5,6,4,6,6,2,1,0,3,1,1,3,1,7,6,1,2,4,6,0,0,1,1,4,0,4,0,1,1]

theorem envBound35372 : H12AffineFastState.Bounded env35372 := by
  intro p hp
  have h : env35372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35371_35372 : H12AffineEnvironment.transform 4 1 env35371 = env35372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35371 == env35372) = true)

theorem identity35372 : scanCanonicalize (H12AffineFastState.compose env35372 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35372 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35373 : List Nat := [2,2,3,0,1,0,3,3,0,2,0,0,2,1,0,3,1,1,3,1,1,0,1,2,2,0,0,0,1,1,2,0,2,0,1,1]

theorem envBound35373 : H12AffineFastState.Bounded env35373 := by
  intro p hp
  have h : env35373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35372_35373 : H12AffineEnvironment.transform 1 2 env35372 = env35373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35372 == env35373) = true)

theorem identity35373 : scanCanonicalize (H12AffineFastState.compose env35373 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35373 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35374 : List Nat := [1,1,0,0,1,0,0,0,0,1,0,0,1,1,0,0,1,1,0,1,1,0,1,1,1,0,0,0,1,1,1,0,1,0,1,1]

theorem envBound35374 : H12AffineFastState.Bounded env35374 := by
  intro p hp
  have h : env35374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35373_35374 : H12AffineEnvironment.transform 0 1 env35373 = env35374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35373 == env35374) = true)

def env35375 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,64,8525,65536,74031,65665,516,8524,837,648,74030,65536,9164,74282,302,74095,64,76623,8205,65831,257,64,1,325]

theorem envBound35375 : H12AffineFastState.Bounded env35375 := by
  intro p hp
  have h : env35375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35360_35375 : H12AffineEnvironment.transform 3 1 env35360 = env35375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35360 == env35375) = true)

theorem identity35375 : scanCanonicalize (H12AffineFastState.compose env35375 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9130) := by decide +kernel

theorem selectedBound35375 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35376 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,64,8525,9130,645,9003,516,8524,837,648,644,9130,9164,384,302,709,64,2277,8205,8845,257,64,1,325]

theorem envBound35376 : H12AffineFastState.Bounded env35376 := by
  intro p hp
  have h : env35376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35375_35376 : H12AffineEnvironment.transform 15 9130 env35375 = env35376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9130 env35375 == env35376) = true)

def env35377 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8,64,325,930,645,803,516,324,837,648,644,930,964,384,302,709,64,2277,5,645,257,64,1,325]

theorem envBound35377 : H12AffineFastState.Bounded env35377 := by
  intro p hp
  have h : env35377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35376_35377 : H12AffineEnvironment.transform 12 8 env35376 = env35377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env35376 == env35377) = true)

theorem identity35377 : scanCanonicalize (H12AffineFastState.compose env35377 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 322) := by decide +kernel

theorem selectedBound35377 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env35378 : List Nat := [2,4,8,1,32,64,128,256,512,321,322,836,8,64,325,930,645,803,516,324,837,648,644,930,964,384,302,709,64,423,5,645,257,64,1,325]

theorem envBound35378 : H12AffineFastState.Bounded env35378 := by
  intro p hp
  have h : env35378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35377_35378 : H12AffineEnvironment.transform 10 322 env35377 = env35378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 322 env35377 == env35378) = true)

theorem identity35378 : scanCanonicalize (H12AffineFastState.compose env35378 (packedSelected [0,2,3,4,7,8,9,11,12,15,16,17,21] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35378 : packedSelected [0,2,3,4,7,8,9,11,12,15,16,17,21] rootPS < 2^1333 := by decide +kernel

def env35379 : List Nat := [2,4,8,1,32,64,128,36,512,101,102,608,8,64,97,646,645,519,516,96,609,648,644,646,736,164,10,709,64,131,5,645,37,64,1,97]

theorem envBound35379 : H12AffineFastState.Bounded env35379 := by
  intro p hp
  have h : env35379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35378_35379 : H12AffineEnvironment.transform 7 36 env35378 = env35379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35378 == env35379) = true)

theorem identity35379 : scanCanonicalize (H12AffineFastState.compose env35379 (packedSelected [3,8,10,13,15] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35379 : packedSelected [3,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env35380 : List Nat := [2,4,4,1,32,64,128,36,512,101,102,608,4,64,97,646,645,519,516,96,609,644,644,646,736,164,6,709,64,131,5,645,37,64,1,97]

theorem envBound35380 : H12AffineFastState.Bounded env35380 := by
  intro p hp
  have h : env35380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35379_35380 : H12AffineEnvironment.transform 2 4 env35379 = env35380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35379 == env35380) = true)

theorem identity35380 : scanCanonicalize (H12AffineFastState.compose env35380 (packedSelected [0,2,3,5,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound35380 : packedSelected [0,2,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env35381 : List Nat := [2,4,4,1,32,64,98,36,512,101,102,608,4,64,97,612,615,519,516,96,609,614,614,612,514,70,6,551,64,97,5,615,37,64,1,97]

theorem envBound35381 : H12AffineFastState.Bounded env35381 := by
  intro p hp
  have h : env35381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35380_35381 : H12AffineEnvironment.transform 6 98 env35380 = env35381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env35380 == env35381) = true)

theorem identity35381 : scanCanonicalize (H12AffineFastState.compose env35381 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound35381 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35382 : List Nat := [2,4,4,1,32,64,98,36,7,101,102,103,4,64,97,99,96,0,3,96,102,97,97,99,5,70,6,32,64,97,5,96,37,64,1,97]

theorem envBound35382 : H12AffineFastState.Bounded env35382 := by
  intro p hp
  have h : env35382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35381_35382 : H12AffineEnvironment.transform 8 7 env35381 = env35382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env35381 == env35382) = true)

theorem identity35382 : scanCanonicalize (H12AffineFastState.compose env35382 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound35382 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35383 : List Nat := [2,4,4,1,6,64,68,2,7,67,64,65,4,64,71,69,70,0,3,70,64,71,71,69,5,70,6,6,64,71,5,70,3,64,1,71]

theorem envBound35383 : H12AffineFastState.Bounded env35383 := by
  intro p hp
  have h : env35383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35382_35383 : H12AffineEnvironment.transform 4 6 env35382 = env35383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env35382 == env35383) = true)

theorem identity35383 : scanCanonicalize (H12AffineFastState.compose env35383 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound35383 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35384 : List Nat := [2,4,4,1,6,6,2,2,7,5,6,7,4,6,1,3,0,0,3,0,6,1,1,3,5,0,6,6,6,1,5,0,3,6,1,1]

theorem envBound35384 : H12AffineFastState.Bounded env35384 := by
  intro p hp
  have h : env35384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35383_35384 : H12AffineEnvironment.transform 5 6 env35383 = env35384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env35383 == env35384) = true)

def env35385 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,9,64,324,931,645,802,516,325,837,648,644,931,965,384,302,709,64,2277,4,644,257,64,1,325]

theorem envBound35385 : H12AffineFastState.Bounded env35385 := by
  intro p hp
  have h : env35385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35376_35385 : H12AffineEnvironment.transform 12 9 env35376 = env35385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env35376 == env35385) = true)

theorem identity35385 : scanCanonicalize (H12AffineFastState.compose env35385 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound35385 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env35386 : List Nat := [2,4,8,1,32,64,128,256,512,321,577,836,9,64,324,931,645,802,516,325,837,648,644,931,965,384,302,709,64,676,4,644,257,64,1,325]

theorem envBound35386 : H12AffineFastState.Bounded env35386 := by
  intro p hp
  have h : env35386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35385_35386 : H12AffineEnvironment.transform 10 577 env35385 = env35386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env35385 == env35386) = true)

theorem identity35386 : scanCanonicalize (H12AffineFastState.compose env35386 (packedSelected [0,3,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound35386 : packedSelected [0,3,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env35387 : List Nat := [2,4,8,1,32,64,128,256,133,321,196,449,9,64,324,294,0,423,129,325,448,13,1,294,320,384,302,64,64,33,4,1,257,64,1,325]

theorem envBound35387 : H12AffineFastState.Bounded env35387 := by
  intro p hp
  have h : env35387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35386_35387 : H12AffineEnvironment.transform 8 133 env35386 = env35387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env35386 == env35387) = true)

theorem identity35387 : scanCanonicalize (H12AffineFastState.compose env35387 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound35387 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env35388 : List Nat := [2,4,8,1,32,64,73,256,76,321,13,264,9,64,324,294,0,366,72,325,265,13,1,294,320,329,302,64,64,33,4,1,257,64,1,325]

theorem envBound35388 : H12AffineFastState.Bounded env35388 := by
  intro p hp
  have h : env35388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35387_35388 : H12AffineEnvironment.transform 6 73 env35387 = env35388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env35387 == env35388) = true)

theorem identity35388 : scanCanonicalize (H12AffineFastState.compose env35388 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound35388 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env35389 : List Nat := [2,4,8,1,32,64,73,104,76,41,13,96,9,64,44,78,0,6,72,45,97,13,1,78,40,33,70,64,64,33,4,1,105,64,1,45]

theorem envBound35389 : H12AffineFastState.Bounded env35389 := by
  intro p hp
  have h : env35389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35388_35389 : H12AffineEnvironment.transform 7 104 env35388 = env35389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env35388 == env35389) = true)

theorem identity35389 : scanCanonicalize (H12AffineFastState.compose env35389 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35389 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env35390 : List Nat := [2,4,8,1,1,64,73,73,76,8,13,65,9,64,13,78,0,6,72,12,64,13,1,78,9,0,70,64,64,0,4,1,72,64,1,12]

theorem envBound35390 : H12AffineFastState.Bounded env35390 := by
  intro p hp
  have h : env35390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35389_35390 : H12AffineEnvironment.transform 4 1 env35389 = env35390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35389 == env35390) = true)

theorem identity35390 : scanCanonicalize (H12AffineFastState.compose env35390 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound35390 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35391 : List Nat := [2,4,8,1,1,10,3,3,6,8,13,11,9,10,13,4,0,6,2,12,10,13,1,4,9,0,12,10,10,0,4,1,2,10,1,12]

theorem envBound35391 : H12AffineFastState.Bounded env35391 := by
  intro p hp
  have h : env35391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35390_35391 : H12AffineEnvironment.transform 5 10 env35390 = env35391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env35390 == env35391) = true)

theorem identity35391 : scanCanonicalize (H12AffineFastState.compose env35391 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35391 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35392 : List Nat := [2,4,4,1,1,6,3,3,6,4,1,7,5,6,1,4,0,6,2,0,6,1,1,4,5,0,0,6,6,0,4,1,2,6,1,0]

theorem envBound35392 : H12AffineFastState.Bounded env35392 := by
  intro p hp
  have h : env35392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35391_35392 : H12AffineEnvironment.transform 2 4 env35391 = env35392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35391 == env35392) = true)

theorem identity35392 : scanCanonicalize (H12AffineFastState.compose env35392 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35392 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35393 : List Nat := [2,3,3,1,1,1,3,3,1,3,1,0,2,1,1,3,0,1,2,0,1,1,1,3,2,0,0,1,1,0,3,1,2,1,1,0]

theorem envBound35393 : H12AffineFastState.Bounded env35393 := by
  intro p hp
  have h : env35393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35392_35393 : H12AffineEnvironment.transform 1 3 env35392 = env35393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35392 == env35393) = true)

theorem identity35393 : scanCanonicalize (H12AffineFastState.compose env35393 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35394 : List Nat := [0,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,0,1,0,0,1,1,1,1,0,0,0,1,1,0,1,1,0,1,1,0]

theorem envBound35394 : H12AffineFastState.Bounded env35394 := by
  intro p hp
  have h : env35394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35393_35394 : H12AffineEnvironment.transform 0 0 env35393 = env35394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35393 == env35394) = true)

def env35395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4097,5276,74046,66896,13768,78895,328959,74814,1296,81227,8204,65830,257,1281,1344,5953]

theorem envBound35395 : H12AffineFastState.Bounded env35395 := by
  intro p hp
  have h : env35395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35287_35395 : H12AffineEnvironment.transform 13 1297 env35287 = env35395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35287 == env35395) = true)

def env35396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4097,5276,74046,66896,13768,78895,1151,74814,1296,81227,8204,65830,257,1281,1344,5953]

theorem envBound35396 : H12AffineFastState.Bounded env35396 := by
  intro p hp
  have h : env35396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35395_35396 : H12AffineEnvironment.transform 17 65664 env35395 = env35396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35395 == env35396) = true)

theorem identity35396 : scanCanonicalize (H12AffineFastState.compose env35396 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound35396 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,65536,66599,65664,4417,277,4097,5276,65911,66896,5505,70758,1151,66679,1296,72962,69,65830,257,1281,1344,5953]

theorem envBound35397 : H12AffineFastState.Bounded env35397 := by
  intro p hp
  have h : env35397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35396_35397 : H12AffineEnvironment.transform 12 73 env35396 = env35397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env35396 == env35397) = true)

def env35398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1297,276,65536,66599,65664,1877,277,1557,648,65911,66896,917,66162,1151,66679,1296,68374,69,65830,257,1281,1344,341]

theorem envBound35398 : H12AffineFastState.Bounded env35398 := by
  intro p hp
  have h : env35398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35397_35398 : H12AffineEnvironment.transform 11 1556 env35397 = env35398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env35397 == env35398) = true)

def env35399 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,65536,65895,65664,533,277,853,648,65911,65552,917,66162,319,65847,80,68374,69,65830,257,65,0,341]

theorem envBound35399 : H12AffineFastState.Bounded env35399 := by
  intro p hp
  have h : env35399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35398_35399 : H12AffineEnvironment.transform 9 320 env35398 = env35399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35398 == env35399) = true)

theorem identity35399 : scanCanonicalize (H12AffineFastState.compose env35399 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound35399 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35400 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,807,576,935,533,277,853,648,592,823,917,341,319,528,80,2097,69,513,257,65,0,341]

theorem envBound35400 : H12AffineFastState.Bounded env35400 := by
  intro p hp
  have h : env35400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35399_35400 : H12AffineEnvironment.transform 15 807 env35399 = env35400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env35399 == env35400) = true)

theorem identity35400 : scanCanonicalize (H12AffineFastState.compose env35400 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35400 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env35401 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,576,73,81,0,563,576,691,533,1,577,648,592,547,641,65,43,528,80,2097,69,513,21,65,0,65]

theorem envBound35401 : H12AffineFastState.Bounded env35401 := by
  intro p hp
  have h : env35401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35400_35401 : H12AffineEnvironment.transform 7 20 env35400 = env35401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35400 == env35401) = true)

theorem identity35401 : scanCanonicalize (H12AffineFastState.compose env35401 (packedSelected [2,3,4,9,10,16] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound35401 : packedSelected [2,3,4,9,10,16] rootPS < 2^1333 := by decide +kernel

def env35402 : List Nat := [2,4,8,16,32,64,128,20,86,84,2048,22,73,81,0,101,22,229,67,1,23,222,6,117,215,65,43,70,80,2097,69,87,21,65,0,65]

theorem envBound35402 : H12AffineFastState.Bounded env35402 := by
  intro p hp
  have h : env35402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35401_35402 : H12AffineEnvironment.transform 8 86 env35401 = env35402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env35401 == env35402) = true)

theorem identity35402 : scanCanonicalize (H12AffineFastState.compose env35402 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound35402 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env35403 : List Nat := [2,4,8,16,32,64,128,20,86,84,11,22,73,81,0,101,22,229,67,1,23,222,6,117,215,65,43,70,80,58,69,87,21,65,0,65]

theorem envBound35403 : H12AffineFastState.Bounded env35403 := by
  intro p hp
  have h : env35403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35402_35403 : H12AffineEnvironment.transform 10 11 env35402 = env35403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env35402 == env35403) = true)

theorem identity35403 : scanCanonicalize (H12AffineFastState.compose env35403 (packedSelected [2,5,10,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound35403 : packedSelected [2,5,10,15] rootPS < 2^1333 := by decide +kernel

def env35404 : List Nat := [2,4,8,16,6,64,128,20,86,84,11,22,73,81,0,67,22,195,67,1,23,222,6,83,215,65,13,70,80,28,69,87,21,65,0,65]

theorem envBound35404 : H12AffineFastState.Bounded env35404 := by
  intro p hp
  have h : env35404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35403_35404 : H12AffineEnvironment.transform 4 6 env35403 = env35404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env35403 == env35404) = true)

theorem identity35404 : scanCanonicalize (H12AffineFastState.compose env35404 (packedSelected [1,2,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound35404 : packedSelected [1,2,8,12] rootPS < 2^1333 := by decide +kernel

def env35405 : List Nat := [2,4,8,16,6,6,128,20,16,18,11,22,15,23,0,5,22,133,5,1,23,152,6,21,145,7,13,0,22,28,3,17,21,7,0,7]

theorem envBound35405 : H12AffineFastState.Bounded env35405 := by
  intro p hp
  have h : env35405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35404_35405 : H12AffineEnvironment.transform 5 6 env35404 = env35405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env35404 == env35405) = true)

theorem identity35405 : scanCanonicalize (H12AffineFastState.compose env35405 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound35405 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35406 : List Nat := [2,4,8,16,6,6,5,20,16,18,11,22,15,23,0,5,22,0,5,1,23,29,6,21,20,7,13,0,22,28,3,17,21,7,0,7]

theorem envBound35406 : H12AffineFastState.Bounded env35406 := by
  intro p hp
  have h : env35406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35405_35406 : H12AffineEnvironment.transform 6 5 env35405 = env35406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env35405 == env35406) = true)

theorem identity35406 : scanCanonicalize (H12AffineFastState.compose env35406 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound35406 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35407 : List Nat := [2,4,8,6,6,6,5,2,6,4,11,0,15,1,0,5,0,0,5,1,1,11,6,3,2,7,13,0,0,10,3,7,3,7,0,7]

theorem envBound35407 : H12AffineFastState.Bounded env35407 := by
  intro p hp
  have h : env35407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35406_35407 : H12AffineEnvironment.transform 3 6 env35406 = env35407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env35406 == env35407) = true)

theorem identity35407 : scanCanonicalize (H12AffineFastState.compose env35407 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35407 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35408 : List Nat := [2,4,0,6,6,6,5,2,6,4,3,0,7,1,0,5,0,0,5,1,1,3,6,3,2,7,5,0,0,2,3,7,3,7,0,7]

theorem envBound35408 : H12AffineFastState.Bounded env35408 := by
  intro p hp
  have h : env35408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35407_35408 : H12AffineEnvironment.transform 2 0 env35407 = env35408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35407 == env35408) = true)

theorem identity35408 : scanCanonicalize (H12AffineFastState.compose env35408 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35409 : List Nat := [1,4,0,5,5,5,5,1,5,4,0,0,4,1,0,5,0,0,5,1,1,0,5,0,1,4,5,0,0,1,0,4,0,4,0,4]

theorem envBound35409 : H12AffineFastState.Bounded env35409 := by
  intro p hp
  have h : env35409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35408_35409 : H12AffineEnvironment.transform 0 1 env35408 = env35409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35408 == env35409) = true)

theorem identity35409 : scanCanonicalize (H12AffineFastState.compose env35409 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35409 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35410 : List Nat := [1,0,0,1,1,1,1,1,1,0,0,0,0,1,0,1,0,0,1,1,1,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0]

theorem envBound35410 : H12AffineFastState.Bounded env35410 := by
  intro p hp
  have h : env35410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35409_35410 : H12AffineEnvironment.transform 1 0 env35409 = env35410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35409 == env35410) = true)

def env35411 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,65536,65894,65664,532,277,852,648,65911,65553,917,66162,318,65846,81,68374,69,65830,257,64,1,341]

theorem envBound35411 : H12AffineFastState.Bounded env35411 := by
  intro p hp
  have h : env35411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35398_35411 : H12AffineEnvironment.transform 9 321 env35398 = env35411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35398 == env35411) = true)

theorem identity35411 : scanCanonicalize (H12AffineFastState.compose env35411 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35411 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35412 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,115,277,243,532,277,852,648,260,98,917,513,318,325,81,2917,69,341,257,64,1,341]

theorem envBound35412 : H12AffineFastState.Bounded env35412 := by
  intro p hp
  have h : env35412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35411_35412 : H12AffineEnvironment.transform 15 115 env35411 = env35412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35411 == env35412) = true)

theorem identity35412 : scanCanonicalize (H12AffineFastState.compose env35412 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35412 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35413 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,772,24,1,276,34,277,162,532,277,773,648,260,51,917,513,318,276,0,2868,20,260,257,17,1,260]

theorem envBound35413 : H12AffineFastState.Bounded env35413 := by
  intro p hp
  have h : env35413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35412_35413 : H12AffineEnvironment.transform 5 17 env35412 = env35413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35412 == env35413) = true)

theorem identity35413 : scanCanonicalize (H12AffineFastState.compose env35413 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound35413 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env35414 : List Nat := [2,4,8,16,32,17,128,256,512,272,61,772,24,1,276,34,277,162,532,277,773,648,260,51,917,513,318,276,0,777,20,260,257,17,1,260]

theorem envBound35414 : H12AffineFastState.Bounded env35414 := by
  intro p hp
  have h : env35414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35413_35414 : H12AffineEnvironment.transform 10 61 env35413 = env35414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env35413 == env35414) = true)

theorem identity35414 : scanCanonicalize (H12AffineFastState.compose env35414 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound35414 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35415 : List Nat := [2,4,8,16,13,17,128,256,512,272,16,772,24,1,276,15,277,143,532,277,773,648,260,30,917,513,275,276,0,777,20,260,257,17,1,260]

theorem envBound35415 : H12AffineFastState.Bounded env35415 := by
  intro p hp
  have h : env35415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35414_35415 : H12AffineEnvironment.transform 4 13 env35414 = env35415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env35414 == env35415) = true)

theorem identity35415 : scanCanonicalize (H12AffineFastState.compose env35415 (packedSelected [5,10] rootPS)) = affineNative (2^(8+1) ^^^ 158) := by decide +kernel

theorem selectedBound35415 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35416 : List Nat := [2,4,8,16,13,17,128,256,158,272,16,410,24,1,276,15,277,143,138,277,411,22,260,30,267,159,275,276,0,407,20,260,257,17,1,260]

theorem envBound35416 : H12AffineFastState.Bounded env35416 := by
  intro p hp
  have h : env35416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35415_35416 : H12AffineEnvironment.transform 8 158 env35415 = env35416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 158 env35415 == env35416) = true)

theorem identity35416 : scanCanonicalize (H12AffineFastState.compose env35416 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound35416 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env35417 : List Nat := [2,4,8,16,13,17,24,256,6,272,16,258,24,1,276,15,277,23,18,277,259,22,260,30,267,7,275,276,0,271,20,260,257,17,1,260]

theorem envBound35417 : H12AffineFastState.Bounded env35417 := by
  intro p hp
  have h : env35417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35416_35417 : H12AffineEnvironment.transform 6 24 env35416 = env35417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env35416 == env35417) = true)

theorem identity35417 : scanCanonicalize (H12AffineFastState.compose env35417 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound35417 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35418 : List Nat := [2,4,8,16,13,17,24,18,6,2,16,16,24,1,6,15,7,23,18,7,17,22,22,30,25,7,1,6,0,29,20,22,19,17,1,22]

theorem envBound35418 : H12AffineFastState.Bounded env35418 := by
  intro p hp
  have h : env35418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35417_35418 : H12AffineEnvironment.transform 7 18 env35417 = env35418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env35417 == env35418) = true)

theorem identity35418 : scanCanonicalize (H12AffineFastState.compose env35418 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35418 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35419 : List Nat := [2,3,8,16,10,17,24,18,1,2,16,16,24,1,1,8,0,16,18,0,17,17,17,25,25,0,1,1,0,26,19,17,19,17,1,17]

theorem envBound35419 : H12AffineFastState.Bounded env35419 := by
  intro p hp
  have h : env35419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35418_35419 : H12AffineEnvironment.transform 1 3 env35418 = env35419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35418 == env35419) = true)

theorem identity35419 : scanCanonicalize (H12AffineFastState.compose env35419 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35419 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35420 : List Nat := [2,3,8,11,10,10,3,9,1,2,11,11,3,1,1,8,0,11,9,0,10,10,10,2,2,0,1,1,0,1,8,10,8,10,1,10]

theorem envBound35420 : H12AffineFastState.Bounded env35420 := by
  intro p hp
  have h : env35420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35419_35420 : H12AffineEnvironment.transform 3 11 env35419 = env35420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35419 == env35420) = true)

theorem identity35420 : scanCanonicalize (H12AffineFastState.compose env35420 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35421 : List Nat := [2,3,3,0,1,1,3,2,1,2,0,0,3,1,1,3,0,0,2,0,1,1,1,2,2,0,1,1,0,1,3,1,3,1,1,1]

theorem envBound35421 : H12AffineFastState.Bounded env35421 := by
  intro p hp
  have h : env35421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35420_35421 : H12AffineEnvironment.transform 2 3 env35420 = env35421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35420 == env35421) = true)

def env35422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1297,276,65536,66599,65664,1876,277,1556,649,65911,66896,916,66163,1151,66679,1296,68375,69,65830,257,1281,1344,340]

theorem envBound35422 : H12AffineFastState.Bounded env35422 := by
  intro p hp
  have h : env35422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35397_35422 : H12AffineEnvironment.transform 11 1557 env35397 = env35422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env35397 == env35422) = true)

def env35423 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,65536,65895,65664,532,277,852,649,65911,65552,916,66163,319,65847,80,68375,69,65830,257,65,0,340]

theorem envBound35423 : H12AffineFastState.Bounded env35423 := by
  intro p hp
  have h : env35423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35422_35423 : H12AffineEnvironment.transform 9 320 env35422 = env35423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35422 == env35423) = true)

theorem identity35423 : scanCanonicalize (H12AffineFastState.compose env35423 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound35423 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35424 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,806,577,934,532,277,852,649,593,822,916,341,319,529,80,2097,69,512,257,65,0,340]

theorem envBound35424 : H12AffineFastState.Bounded env35424 := by
  intro p hp
  have h : env35424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35423_35424 : H12AffineEnvironment.transform 15 806 env35423 = env35424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env35423 == env35424) = true)

theorem identity35424 : scanCanonicalize (H12AffineFastState.compose env35424 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35424 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env35425 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,577,73,81,0,562,577,690,532,1,576,649,593,546,640,65,43,529,80,2097,69,512,21,65,0,64]

theorem envBound35425 : H12AffineFastState.Bounded env35425 := by
  intro p hp
  have h : env35425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35424_35425 : H12AffineEnvironment.transform 7 20 env35424 = env35425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35424 == env35425) = true)

theorem identity35425 : scanCanonicalize (H12AffineFastState.compose env35425 (packedSelected [2,3,4,9,10,16] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound35425 : packedSelected [2,3,4,9,10,16] rootPS < 2^1333 := by decide +kernel

def env35426 : List Nat := [2,4,8,16,32,64,128,20,86,84,2048,23,73,81,0,100,23,228,66,1,22,223,7,116,214,65,43,71,80,2097,69,86,21,65,0,64]

theorem envBound35426 : H12AffineFastState.Bounded env35426 := by
  intro p hp
  have h : env35426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35425_35426 : H12AffineEnvironment.transform 8 86 env35425 = env35426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env35425 == env35426) = true)

theorem identity35426 : scanCanonicalize (H12AffineFastState.compose env35426 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound35426 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env35427 : List Nat := [2,4,8,16,32,64,128,20,86,84,10,23,73,81,0,100,23,228,66,1,22,223,7,116,214,65,43,71,80,59,69,86,21,65,0,64]

theorem envBound35427 : H12AffineFastState.Bounded env35427 := by
  intro p hp
  have h : env35427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35426_35427 : H12AffineEnvironment.transform 10 10 env35426 = env35427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env35426 == env35427) = true)

theorem identity35427 : scanCanonicalize (H12AffineFastState.compose env35427 (packedSelected [2,5,10,15] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35427 : packedSelected [2,5,10,15] rootPS < 2^1333 := by decide +kernel

def env35428 : List Nat := [2,4,8,16,17,64,128,20,86,84,10,23,73,81,0,85,23,213,66,1,22,223,7,69,214,65,26,71,80,10,69,86,21,65,0,64]

theorem envBound35428 : H12AffineFastState.Bounded env35428 := by
  intro p hp
  have h : env35428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35427_35428 : H12AffineEnvironment.transform 4 17 env35427 = env35428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35427 == env35428) = true)

theorem identity35428 : scanCanonicalize (H12AffineFastState.compose env35428 (packedSelected [1,3,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35428 : packedSelected [1,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env35429 : List Nat := [2,4,8,16,17,17,128,20,7,5,10,23,24,0,0,4,23,132,19,1,22,142,7,20,135,16,26,22,1,10,20,7,21,16,0,17]

theorem envBound35429 : H12AffineFastState.Bounded env35429 := by
  intro p hp
  have h : env35429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35428_35429 : H12AffineEnvironment.transform 5 17 env35428 = env35429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35428 == env35429) = true)

def env35430 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,65536,65894,65664,533,277,853,649,65911,65553,916,66163,318,65846,81,68375,69,65830,257,64,1,340]

theorem envBound35430 : H12AffineFastState.Bounded env35430 := by
  intro p hp
  have h : env35430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35422_35430 : H12AffineEnvironment.transform 9 321 env35422 = env35430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35422 == env35430) = true)

theorem identity35430 : scanCanonicalize (H12AffineFastState.compose env35430 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35430 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35431 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,115,277,243,533,277,853,649,260,98,916,512,318,325,81,2916,69,341,257,64,1,340]

theorem envBound35431 : H12AffineFastState.Bounded env35431 := by
  intro p hp
  have h : env35431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35430_35431 : H12AffineEnvironment.transform 15 115 env35430 = env35431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35430 == env35431) = true)

theorem identity35431 : scanCanonicalize (H12AffineFastState.compose env35431 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35431 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35432 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,773,24,1,276,34,277,162,533,277,772,649,260,51,916,512,318,276,0,2869,20,260,257,17,1,261]

theorem envBound35432 : H12AffineFastState.Bounded env35432 := by
  intro p hp
  have h : env35432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35431_35432 : H12AffineEnvironment.transform 5 17 env35431 = env35432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35431 == env35432) = true)

theorem identity35432 : scanCanonicalize (H12AffineFastState.compose env35432 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 557) := by decide +kernel

theorem selectedBound35432 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env35433 : List Nat := [2,4,8,16,32,17,128,256,512,272,557,773,24,1,276,34,277,162,533,277,772,649,260,51,916,512,318,276,0,280,20,260,257,17,1,261]

theorem envBound35433 : H12AffineFastState.Bounded env35433 := by
  intro p hp
  have h : env35433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35432_35433 : H12AffineEnvironment.transform 10 557 env35432 = env35433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env35432 == env35433) = true)

theorem identity35433 : scanCanonicalize (H12AffineFastState.compose env35433 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound35433 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35434 : List Nat := [2,4,8,16,32,17,128,256,60,272,17,313,24,1,276,34,277,162,41,277,312,181,260,51,424,60,318,276,0,280,20,260,257,17,1,261]

theorem envBound35434 : H12AffineFastState.Bounded env35434 := by
  intro p hp
  have h : env35434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35433_35434 : H12AffineEnvironment.transform 8 60 env35433 = env35434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env35433 == env35434) = true)

theorem identity35434 : scanCanonicalize (H12AffineFastState.compose env35434 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound35434 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env35435 : List Nat := [2,4,8,16,32,17,14,256,60,272,17,313,24,1,276,34,277,44,41,277,312,59,260,51,294,60,318,276,0,280,20,260,257,17,1,261]

theorem envBound35435 : H12AffineFastState.Bounded env35435 := by
  intro p hp
  have h : env35435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35434_35435 : H12AffineEnvironment.transform 6 14 env35434 = env35435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env35434 == env35435) = true)

theorem identity35435 : scanCanonicalize (H12AffineFastState.compose env35435 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound35435 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env35436 : List Nat := [2,4,8,7,32,6,14,256,43,263,6,302,15,1,259,34,258,44,41,258,303,44,260,36,294,43,297,259,0,271,3,260,257,6,1,261]

theorem envBound35436 : H12AffineFastState.Bounded env35436 := by
  intro p hp
  have h : env35436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35435_35436 : H12AffineEnvironment.transform 3 7 env35435 = env35436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env35435 == env35436) = true)

theorem identity35436 : scanCanonicalize (H12AffineFastState.compose env35436 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound35436 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35437 : List Nat := [2,4,8,7,32,6,14,40,43,47,6,6,15,1,43,34,42,44,41,42,7,44,44,36,14,43,1,43,0,39,3,44,41,6,1,45]

theorem envBound35437 : H12AffineFastState.Bounded env35437 := by
  intro p hp
  have h : env35437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35436_35437 : H12AffineEnvironment.transform 7 40 env35436 = env35437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env35436 == env35437) = true)

theorem identity35437 : scanCanonicalize (H12AffineFastState.compose env35437 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound35437 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35438 : List Nat := [2,4,8,7,12,6,14,4,7,3,6,6,15,1,7,14,6,0,5,6,7,0,0,8,14,7,1,7,0,11,3,0,5,6,1,1]

theorem envBound35438 : H12AffineFastState.Bounded env35438 := by
  intro p hp
  have h : env35438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35437_35438 : H12AffineEnvironment.transform 4 12 env35437 = env35438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env35437 == env35438) = true)

theorem identity35438 : scanCanonicalize (H12AffineFastState.compose env35438 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35439 : List Nat := [2,4,2,7,6,6,4,4,7,3,6,6,5,1,7,4,6,0,5,6,7,0,0,2,4,7,1,7,0,1,3,0,5,6,1,1]

theorem envBound35439 : H12AffineFastState.Bounded env35439 := by
  intro p hp
  have h : env35439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35438_35439 : H12AffineEnvironment.transform 2 2 env35438 = env35439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35438 == env35439) = true)

theorem identity35439 : scanCanonicalize (H12AffineFastState.compose env35439 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35439 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35440 : List Nat := [2,2,2,1,0,0,2,2,1,3,0,0,3,1,1,2,0,0,3,0,1,0,0,2,2,1,1,1,0,1,3,0,3,0,1,1]

theorem envBound35440 : H12AffineFastState.Bounded env35440 := by
  intro p hp
  have h : env35440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35439_35440 : H12AffineEnvironment.transform 1 2 env35439 = env35440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35439 == env35440) = true)

def env35441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4097,5276,74046,66896,13768,78895,1150,74814,1296,81227,8204,65830,257,1281,1344,5953]

theorem envBound35441 : H12AffineFastState.Bounded env35441 := by
  intro p hp
  have h : env35441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35395_35441 : H12AffineEnvironment.transform 17 65665 env35395 = env35441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35395 == env35441) = true)

theorem identity35441 : scanCanonicalize (H12AffineFastState.compose env35441 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound35441 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,65536,69991,65665,4417,5205,4097,5276,70711,66896,193,65830,1150,69943,1296,67650,5381,65830,257,1281,1344,5953]

theorem envBound35442 : H12AffineFastState.Bounded env35442 := by
  intro p hp
  have h : env35442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35441_35442 : H12AffineEnvironment.transform 12 5385 env35441 = env35442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env35441 == env35442) = true)

def env35443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1297,576,65536,67443,65665,1877,577,1557,648,66083,66896,193,65830,1150,67363,1296,67650,785,65830,257,1281,1344,341]

theorem envBound35443 : H12AffineFastState.Bounded env35443 := by
  intro p hp
  have h : env35443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35442_35443 : H12AffineEnvironment.transform 11 1556 env35442 = env35443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env35442 == env35443) = true)

def env35444 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,65,576,65536,66083,65665,517,577,837,648,66083,65536,193,65830,302,66163,64,67650,785,65830,257,81,16,341]

theorem envBound35444 : H12AffineFastState.Bounded env35444 := by
  intro p hp
  have h : env35444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35443_35444 : H12AffineEnvironment.transform 9 336 env35443 = env35444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env35443 == env35444) = true)

theorem identity35444 : scanCanonicalize (H12AffineFastState.compose env35444 (packedSelected [1,8,28] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound35444 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35445 : List Nat := [2,4,8,13,32,64,128,256,512,333,2048,836,768,65,576,65536,66083,65665,517,577,837,648,66083,65536,193,65830,302,66158,64,67650,780,65830,257,76,13,328]

theorem envBound35445 : H12AffineFastState.Bounded env35445 := by
  intro p hp
  have h : env35445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35444_35445 : H12AffineEnvironment.transform 3 13 env35444 = env35445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env35444 == env35445) = true)

def env35446 : List Nat := [2,4,8,13,32,64,128,256,328,333,2048,12,72,65,264,65536,65899,65665,333,265,13,448,65899,65536,193,65830,302,65830,64,67650,68,65830,257,76,13,328]

theorem envBound35446 : H12AffineFastState.Bounded env35446 := by
  intro p hp
  have h : env35446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35445_35446 : H12AffineEnvironment.transform 8 328 env35445 = env35446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env35445 == env35446) = true)

theorem identity35446 : scanCanonicalize (H12AffineFastState.compose env35446 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound35446 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35447 : List Nat := [2,4,8,13,32,64,128,256,328,333,2048,12,72,65,264,99,264,226,333,265,13,448,264,99,193,325,302,325,64,2081,68,325,257,76,13,328]

theorem envBound35447 : H12AffineFastState.Bounded env35447 := by
  intro p hp
  have h : env35447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35446_35447 : H12AffineEnvironment.transform 15 99 env35446 = env35447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env35446 == env35447) = true)

theorem identity35447 : scanCanonicalize (H12AffineFastState.compose env35447 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound35447 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35448 : List Nat := [2,4,8,13,32,12,128,256,260,257,2048,12,4,13,264,47,264,174,257,265,13,396,264,47,141,265,302,265,12,2081,8,265,257,0,13,260]

theorem envBound35448 : H12AffineFastState.Bounded env35448 := by
  intro p hp
  have h : env35448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35447_35448 : H12AffineEnvironment.transform 5 12 env35447 = env35448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env35447 == env35448) = true)

theorem identity35448 : scanCanonicalize (H12AffineFastState.compose env35448 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound35448 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env35449 : List Nat := [2,4,8,13,32,12,128,256,260,257,13,12,4,13,264,47,264,174,257,265,13,396,264,47,141,265,302,265,12,44,8,265,257,0,13,260]

theorem envBound35449 : H12AffineFastState.Bounded env35449 := by
  intro p hp
  have h : env35449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35448_35449 : H12AffineEnvironment.transform 10 13 env35448 = env35449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env35448 == env35449) = true)

theorem identity35449 : scanCanonicalize (H12AffineFastState.compose env35449 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound35449 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env35450 : List Nat := [2,4,8,13,32,12,4,256,260,257,13,12,4,13,264,47,264,42,257,265,13,264,264,47,9,265,302,265,12,44,8,265,257,0,13,260]

theorem envBound35450 : H12AffineFastState.Bounded env35450 := by
  intro p hp
  have h : env35450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35449_35450 : H12AffineEnvironment.transform 6 4 env35449 = env35450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env35449 == env35450) = true)

theorem identity35450 : scanCanonicalize (H12AffineFastState.compose env35450 (packedSelected [1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound35450 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env35451 : List Nat := [2,4,8,13,32,12,4,41,45,40,13,12,4,13,33,47,33,42,40,32,13,33,33,47,9,32,7,32,12,44,8,32,40,0,13,45]

theorem envBound35451 : H12AffineFastState.Bounded env35451 := by
  intro p hp
  have h : env35451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35450_35451 : H12AffineEnvironment.transform 7 41 env35450 = env35451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env35450 == env35451) = true)

theorem identity35451 : scanCanonicalize (H12AffineFastState.compose env35451 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35451 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35452 : List Nat := [2,4,4,1,32,0,4,37,33,36,1,0,4,1,33,35,33,38,36,32,1,33,33,35,5,32,7,32,0,32,4,32,36,0,1,33]

theorem envBound35452 : H12AffineFastState.Bounded env35452 := by
  intro p hp
  have h : env35452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35451_35452 : H12AffineEnvironment.transform 2 4 env35451 = env35452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35451 == env35452) = true)

theorem identity35452 : scanCanonicalize (H12AffineFastState.compose env35452 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35453 : List Nat := [2,4,4,1,0,0,4,5,1,4,1,0,4,1,1,3,1,6,4,0,1,1,1,3,5,0,7,0,0,0,4,0,4,0,1,1]

theorem envBound35453 : H12AffineFastState.Bounded env35453 := by
  intro p hp
  have h : env35453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35452_35453 : H12AffineEnvironment.transform 4 0 env35452 = env35453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35452 == env35453) = true)

theorem identity35453 : scanCanonicalize (H12AffineFastState.compose env35453 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35453 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35454 : List Nat := [2,2,2,1,0,0,2,3,1,2,1,0,2,1,1,3,1,0,2,0,1,1,1,3,3,0,1,0,0,0,2,0,2,0,1,1]

theorem envBound35454 : H12AffineFastState.Bounded env35454 := by
  intro p hp
  have h : env35454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35453_35454 : H12AffineEnvironment.transform 1 2 env35453 = env35454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35453 == env35454) = true)

def env35455 : List Nat := [2,4,8,13,32,64,128,256,329,333,2048,13,73,65,265,65536,65898,65665,332,264,12,449,65898,65536,193,65830,302,65831,64,67650,69,65830,257,76,13,328]

theorem envBound35455 : H12AffineFastState.Bounded env35455 := by
  intro p hp
  have h : env35455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35445_35455 : H12AffineEnvironment.transform 8 329 env35445 = env35455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env35445 == env35455) = true)

theorem identity35455 : scanCanonicalize (H12AffineFastState.compose env35455 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound35455 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35456 : List Nat := [2,4,8,13,32,64,128,73,0,4,2048,13,73,65,64,65536,65571,65665,5,65,12,136,65571,65536,193,65647,103,65646,64,67650,69,65647,72,76,13,1]

theorem envBound35456 : H12AffineFastState.Bounded env35456 := by
  intro p hp
  have h : env35456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35455_35456 : H12AffineEnvironment.transform 7 73 env35455 = env35456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env35455 == env35456) = true)

theorem identity35456 : scanCanonicalize (H12AffineFastState.compose env35456 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 110) := by decide +kernel

theorem selectedBound35456 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35457 : List Nat := [2,4,8,13,32,64,128,73,0,4,2048,13,73,65,64,110,77,239,5,65,12,136,77,110,193,1,103,0,64,2092,69,1,72,76,13,1]

theorem envBound35457 : H12AffineFastState.Bounded env35457 := by
  intro p hp
  have h : env35457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35456_35457 : H12AffineEnvironment.transform 15 110 env35456 = env35457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 110 env35456 == env35457) = true)

theorem identity35457 : scanCanonicalize (H12AffineFastState.compose env35457 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound35457 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35458 : List Nat := [2,4,8,13,32,13,128,4,0,4,2048,13,4,12,13,35,0,162,5,12,12,136,0,35,140,1,42,0,13,2092,8,1,5,1,13,1]

theorem envBound35458 : H12AffineFastState.Bounded env35458 := by
  intro p hp
  have h : env35458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35457_35458 : H12AffineEnvironment.transform 5 13 env35457 = env35458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env35457 == env35458) = true)

theorem identity35458 : scanCanonicalize (H12AffineFastState.compose env35458 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound35458 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35459 : List Nat := [2,4,8,13,32,13,46,4,0,4,2048,13,4,12,13,35,0,12,5,12,12,38,0,35,34,1,42,0,13,2092,8,1,5,1,13,1]

theorem envBound35459 : H12AffineFastState.Bounded env35459 := by
  intro p hp
  have h : env35459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35458_35459 : H12AffineEnvironment.transform 6 46 env35458 = env35459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env35458 == env35459) = true)

theorem identity35459 : scanCanonicalize (H12AffineFastState.compose env35459 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35459 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env35460 : List Nat := [2,4,0,5,32,5,38,4,0,4,2048,5,4,4,5,35,0,4,5,4,4,38,0,35,34,1,34,0,5,2084,0,1,5,1,5,1]

theorem envBound35460 : H12AffineFastState.Bounded env35460 := by
  intro p hp
  have h : env35460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35459_35460 : H12AffineEnvironment.transform 2 0 env35459 = env35460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35459 == env35460) = true)

def env35461 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,64,576,65536,66082,65665,516,577,836,648,66083,65537,193,65830,303,66162,65,67650,785,65830,257,80,17,341]

theorem envBound35461 : H12AffineFastState.Bounded env35461 := by
  intro p hp
  have h : env35461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35443_35461 : H12AffineEnvironment.transform 9 337 env35443 = env35461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env35443 == env35461) = true)

theorem identity35461 : scanCanonicalize (H12AffineFastState.compose env35461 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 344) := by decide +kernel

theorem selectedBound35461 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35462 : List Nat := [2,4,8,16,32,64,128,256,344,337,2048,29,69,64,280,65536,65914,65665,348,281,28,464,65915,65537,193,65830,303,65834,65,67650,73,65830,257,80,17,341]

theorem envBound35462 : H12AffineFastState.Bounded env35462 := by
  intro p hp
  have h : env35462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35461_35462 : H12AffineEnvironment.transform 8 344 env35461 = env35462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 344 env35461 == env35462) = true)

def env35463 : List Nat := [2,4,4,16,32,64,128,256,340,337,2048,17,69,64,276,65536,65910,65665,336,277,16,464,65911,65537,193,65830,291,65830,65,67650,69,65830,257,80,17,341]

theorem envBound35463 : H12AffineFastState.Bounded env35463 := by
  intro p hp
  have h : env35463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35462_35463 : H12AffineEnvironment.transform 2 4 env35462 = env35463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35462 == env35463) = true)

theorem identity35463 : scanCanonicalize (H12AffineFastState.compose env35463 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound35463 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35464 : List Nat := [2,4,4,16,32,64,128,85,1,4,2048,17,69,64,65,65536,65571,65665,5,64,16,133,65570,65537,193,65651,118,65651,65,67650,69,65651,84,80,17,0]

theorem envBound35464 : H12AffineFastState.Bounded env35464 := by
  intro p hp
  have h : env35464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35463_35464 : H12AffineEnvironment.transform 7 85 env35463 = env35464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env35463 == env35464) = true)

theorem identity35464 : scanCanonicalize (H12AffineFastState.compose env35464 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35464 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35465 : List Nat := [2,4,4,16,32,64,128,85,1,4,2048,17,69,64,65,115,80,242,5,64,16,133,81,114,193,0,118,0,65,2097,69,0,84,80,17,0]

theorem envBound35465 : H12AffineFastState.Bounded env35465 := by
  intro p hp
  have h : env35465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35464_35465 : H12AffineEnvironment.transform 15 115 env35464 = env35465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35464 == env35465) = true)

theorem identity35465 : scanCanonicalize (H12AffineFastState.compose env35465 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35465 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35466 : List Nat := [2,4,4,16,32,17,128,4,1,4,2048,17,20,17,16,34,1,163,5,17,16,133,0,35,144,0,39,0,16,2097,20,0,5,1,17,0]

theorem envBound35466 : H12AffineFastState.Bounded env35466 := by
  intro p hp
  have h : env35466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35465_35466 : H12AffineEnvironment.transform 5 17 env35465 = env35466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35465 == env35466) = true)

theorem identity35466 : scanCanonicalize (H12AffineFastState.compose env35466 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound35466 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35467 : List Nat := [2,4,4,16,32,17,128,4,1,4,16,17,20,17,16,34,1,163,5,17,16,133,0,35,144,0,39,0,16,33,20,0,5,1,17,0]

theorem envBound35467 : H12AffineFastState.Bounded env35467 := by
  intro p hp
  have h : env35467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35466_35467 : H12AffineEnvironment.transform 10 16 env35466 = env35467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env35466 == env35467) = true)

theorem identity35467 : scanCanonicalize (H12AffineFastState.compose env35467 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 49) := by decide +kernel

theorem selectedBound35467 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35468 : List Nat := [2,4,4,16,32,17,49,4,1,4,16,17,20,17,16,34,1,18,5,17,16,52,0,35,33,0,39,0,16,33,20,0,5,1,17,0]

theorem envBound35468 : H12AffineFastState.Bounded env35468 := by
  intro p hp
  have h : env35468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35467_35468 : H12AffineEnvironment.transform 6 49 env35467 = env35468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 49 env35467 == env35468) = true)

theorem identity35468 : scanCanonicalize (H12AffineFastState.compose env35468 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound35468 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env35469 : List Nat := [2,4,4,16,3,17,18,4,1,4,16,17,20,17,16,1,1,18,5,17,16,23,0,0,2,0,4,0,16,2,20,0,5,1,17,0]

theorem envBound35469 : H12AffineFastState.Bounded env35469 := by
  intro p hp
  have h : env35469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35468_35469 : H12AffineEnvironment.transform 4 3 env35468 = env35469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env35468 == env35469) = true)

theorem identity35469 : scanCanonicalize (H12AffineFastState.compose env35469 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35470 : List Nat := [0,4,4,16,1,17,16,4,1,4,16,17,20,17,16,1,1,16,5,17,16,21,0,0,0,0,4,0,16,0,20,0,5,1,17,0]

theorem envBound35470 : H12AffineFastState.Bounded env35470 := by
  intro p hp
  have h : env35470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35469_35470 : H12AffineEnvironment.transform 0 0 env35469 = env35470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35469 == env35470) = true)

theorem identity35470 : scanCanonicalize (H12AffineFastState.compose env35470 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35470 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35471 : List Nat := [0,0,0,16,1,17,16,0,1,0,16,17,16,17,16,1,1,16,1,17,16,17,0,0,0,0,0,0,16,0,16,0,1,1,17,0]

theorem envBound35471 : H12AffineFastState.Bounded env35471 := by
  intro p hp
  have h : env35471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35470_35471 : H12AffineEnvironment.transform 1 0 env35470 = env35471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35470 == env35471) = true)

theorem identity35471 : scanCanonicalize (H12AffineFastState.compose env35471 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35472 : List Nat := [0,0,0,1,1,0,1,0,1,0,1,0,1,0,1,1,1,1,1,0,1,0,0,0,0,0,0,0,1,0,1,0,1,1,0,0]

theorem envBound35472 : H12AffineFastState.Bounded env35472 := by
  intro p hp
  have h : env35472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35471_35472 : H12AffineEnvironment.transform 3 1 env35471 = env35472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35471 == env35472) = true)

def env35473 : List Nat := [2,4,5,16,32,64,128,256,341,337,2048,16,69,64,277,65536,65911,65665,337,276,17,464,65910,65537,193,65830,290,65831,65,67650,68,65830,257,80,17,341]

theorem envBound35473 : H12AffineFastState.Bounded env35473 := by
  intro p hp
  have h : env35473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35462_35473 : H12AffineEnvironment.transform 2 5 env35462 = env35473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35462 == env35473) = true)

theorem identity35473 : scanCanonicalize (H12AffineFastState.compose env35473 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound35473 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35474 : List Nat := [2,4,5,16,32,64,128,256,341,337,2048,16,69,64,277,98,277,227,337,276,17,464,276,99,193,324,290,325,65,2080,68,324,257,80,17,341]

theorem envBound35474 : H12AffineFastState.Bounded env35474 := by
  intro p hp
  have h : env35474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35473_35474 : H12AffineEnvironment.transform 15 98 env35473 = env35474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env35473 == env35474) = true)

theorem identity35474 : scanCanonicalize (H12AffineFastState.compose env35474 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35474 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35475 : List Nat := [2,4,5,16,32,17,128,256,260,256,2048,16,20,17,277,51,277,178,256,276,17,385,276,50,144,277,290,276,16,2080,21,277,257,1,17,260]

theorem envBound35475 : H12AffineFastState.Bounded env35475 := by
  intro p hp
  have h : env35475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35474_35475 : H12AffineEnvironment.transform 5 17 env35474 = env35475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35474 == env35475) = true)

theorem identity35475 : scanCanonicalize (H12AffineFastState.compose env35475 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound35475 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env35476 : List Nat := [2,4,5,16,32,17,128,256,260,256,17,16,20,17,277,51,277,178,256,276,17,385,276,50,144,277,290,276,16,49,21,277,257,1,17,260]

theorem envBound35476 : H12AffineFastState.Bounded env35476 := by
  intro p hp
  have h : env35476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35475_35476 : H12AffineEnvironment.transform 10 17 env35475 = env35476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env35475 == env35476) = true)

theorem identity35476 : scanCanonicalize (H12AffineFastState.compose env35476 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound35476 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env35477 : List Nat := [2,4,5,16,32,17,21,256,260,256,17,16,20,17,277,51,277,39,256,276,17,276,276,50,5,277,290,276,16,49,21,277,257,1,17,260]

theorem envBound35477 : H12AffineFastState.Bounded env35477 := by
  intro p hp
  have h : env35477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35476_35477 : H12AffineEnvironment.transform 6 21 env35476 = env35477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env35476 == env35477) = true)

theorem identity35477 : scanCanonicalize (H12AffineFastState.compose env35477 (packedSelected [1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35477 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env35478 : List Nat := [2,4,5,16,0,17,21,256,260,256,17,16,20,17,277,19,277,7,256,276,17,276,276,18,5,277,258,276,16,17,21,277,257,1,17,260]

theorem envBound35478 : H12AffineFastState.Bounded env35478 := by
  intro p hp
  have h : env35478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35477_35478 : H12AffineEnvironment.transform 4 0 env35477 = env35478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35477 == env35478) = true)

theorem identity35478 : scanCanonicalize (H12AffineFastState.compose env35478 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35479 : List Nat := [2,4,5,16,0,17,21,21,17,21,17,16,20,17,0,19,0,7,21,1,17,1,1,18,5,0,23,1,16,17,21,0,20,1,17,17]

theorem envBound35479 : H12AffineFastState.Bounded env35479 := by
  intro p hp
  have h : env35479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35478_35479 : H12AffineEnvironment.transform 7 21 env35478 = env35479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35478 == env35479) = true)

def env35480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1297,577,65536,67442,65665,1876,576,1556,649,66082,66896,193,65830,1150,67362,1296,67650,784,65830,257,1281,1344,340]

theorem envBound35480 : H12AffineFastState.Bounded env35480 := by
  intro p hp
  have h : env35480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35442_35480 : H12AffineEnvironment.transform 11 1557 env35442 = env35480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env35442 == env35480) = true)

def env35481 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,65,577,65536,66082,65665,516,576,836,649,66082,65536,193,65830,302,66162,64,67650,784,65830,257,81,16,340]

theorem envBound35481 : H12AffineFastState.Bounded env35481 := by
  intro p hp
  have h : env35481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35480_35481 : H12AffineEnvironment.transform 9 336 env35480 = env35481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env35480 == env35481) = true)

theorem identity35481 : scanCanonicalize (H12AffineFastState.compose env35481 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 558) := by decide +kernel

theorem selectedBound35481 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35482 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,65,577,558,12,687,516,576,836,649,12,558,193,776,302,92,64,2668,784,776,257,81,16,340]

theorem envBound35482 : H12AffineFastState.Bounded env35482 := by
  intro p hp
  have h : env35482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35481_35482 : H12AffineEnvironment.transform 15 558 env35481 = env35482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 558 env35481 == env35482) = true)

def env35483 : List Nat := [2,4,8,16,32,64,128,256,324,336,2048,1,88,65,261,362,12,491,320,260,0,461,12,362,193,76,302,92,64,2344,84,76,257,81,16,340]

theorem envBound35483 : H12AffineFastState.Bounded env35483 := by
  intro p hp
  have h : env35483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35482_35483 : H12AffineEnvironment.transform 8 324 env35482 = env35483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env35482 == env35483) = true)

theorem identity35483 : scanCanonicalize (H12AffineFastState.compose env35483 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound35483 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35484 : List Nat := [2,4,8,16,32,64,128,25,93,73,2048,1,88,65,28,115,12,242,89,29,0,212,12,115,193,76,55,92,64,2097,84,76,24,81,16,77]

theorem envBound35484 : H12AffineFastState.Bounded env35484 := by
  intro p hp
  have h : env35484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35483_35484 : H12AffineEnvironment.transform 7 25 env35483 = env35484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env35483 == env35484) = true)

theorem identity35484 : scanCanonicalize (H12AffineFastState.compose env35484 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35484 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35485 : List Nat := [2,4,8,16,32,17,128,25,12,24,2048,1,9,16,28,34,12,163,8,29,0,133,12,34,144,29,55,13,17,2097,5,29,24,0,16,28]

theorem envBound35485 : H12AffineFastState.Bounded env35485 := by
  intro p hp
  have h : env35485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35484_35485 : H12AffineEnvironment.transform 5 17 env35484 = env35485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35484 == env35485) = true)

theorem identity35485 : scanCanonicalize (H12AffineFastState.compose env35485 (packedSelected [0,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound35485 : packedSelected [0,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env35486 : List Nat := [2,4,8,16,32,17,128,25,12,24,132,1,9,16,28,34,12,163,8,29,0,133,12,34,144,29,55,13,17,181,5,29,24,0,16,28]

theorem envBound35486 : H12AffineFastState.Bounded env35486 := by
  intro p hp
  have h : env35486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35485_35486 : H12AffineEnvironment.transform 10 132 env35485 = env35486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env35485 == env35486) = true)

theorem identity35486 : scanCanonicalize (H12AffineFastState.compose env35486 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound35486 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35487 : List Nat := [2,4,8,16,32,17,53,25,12,24,49,1,9,16,28,34,12,22,8,29,0,48,12,34,37,29,55,13,17,0,5,29,24,0,16,28]

theorem envBound35487 : H12AffineFastState.Bounded env35487 := by
  intro p hp
  have h : env35487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35486_35487 : H12AffineEnvironment.transform 6 53 env35486 = env35487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env35486 == env35487) = true)

theorem identity35487 : scanCanonicalize (H12AffineFastState.compose env35487 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound35487 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35488 : List Nat := [2,4,8,16,23,17,2,25,12,24,6,1,9,16,28,21,12,22,8,29,0,7,12,21,18,29,0,13,17,0,5,29,24,0,16,28]

theorem envBound35488 : H12AffineFastState.Bounded env35488 := by
  intro p hp
  have h : env35488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35487_35488 : H12AffineEnvironment.transform 4 23 env35487 = env35488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env35487 == env35488) = true)

theorem identity35488 : scanCanonicalize (H12AffineFastState.compose env35488 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35488 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env35489 : List Nat := [2,4,3,16,23,17,2,18,7,19,6,1,2,16,23,21,7,22,3,22,0,7,7,21,18,22,0,6,17,0,5,22,19,0,16,23]

theorem envBound35489 : H12AffineFastState.Bounded env35489 := by
  intro p hp
  have h : env35489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35488_35489 : H12AffineEnvironment.transform 2 3 env35488 = env35489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35488 == env35489) = true)

theorem identity35489 : scanCanonicalize (H12AffineFastState.compose env35489 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35490 : List Nat := [2,4,3,0,7,1,2,2,7,3,6,1,2,0,7,5,7,6,3,6,0,7,7,5,2,6,0,6,1,0,5,6,3,0,0,7]

theorem envBound35490 : H12AffineFastState.Bounded env35490 := by
  intro p hp
  have h : env35490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35489_35490 : H12AffineEnvironment.transform 3 0 env35489 = env35490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35489 == env35490) = true)

theorem identity35490 : scanCanonicalize (H12AffineFastState.compose env35490 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35491 : List Nat := [2,3,3,0,0,1,2,2,0,3,1,1,2,0,0,2,0,1,3,1,0,0,0,2,2,1,0,1,1,0,2,1,3,0,0,0]

theorem envBound35491 : H12AffineFastState.Bounded env35491 := by
  intro p hp
  have h : env35491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35490_35491 : H12AffineEnvironment.transform 1 3 env35490 = env35491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35490 == env35491) = true)

def env35492 : List Nat := [2,4,8,16,32,64,128,256,325,336,2048,0,89,65,260,363,12,490,321,261,1,460,12,363,193,77,302,92,64,2345,85,77,257,81,16,340]

theorem envBound35492 : H12AffineFastState.Bounded env35492 := by
  intro p hp
  have h : env35492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35482_35492 : H12AffineEnvironment.transform 8 325 env35482 = env35492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env35482 == env35492) = true)

theorem identity35492 : scanCanonicalize (H12AffineFastState.compose env35492 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound35492 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35493 : List Nat := [2,4,8,16,32,64,128,8,77,88,2048,0,89,65,12,99,12,226,73,13,1,196,12,99,193,77,38,92,64,2081,85,77,9,81,16,92]

theorem envBound35493 : H12AffineFastState.Bounded env35493 := by
  intro p hp
  have h : env35493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35492_35493 : H12AffineEnvironment.transform 7 8 env35492 = env35493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env35492 == env35493) = true)

theorem identity35493 : scanCanonicalize (H12AffineFastState.compose env35493 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35493 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env35494 : List Nat := [2,4,4,16,32,64,128,4,65,84,2048,0,85,65,0,99,0,226,69,1,1,196,0,99,193,65,38,80,64,2081,85,65,5,81,16,80]

theorem envBound35494 : H12AffineFastState.Bounded env35494 := by
  intro p hp
  have h : env35494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35493_35494 : H12AffineEnvironment.transform 2 4 env35493 = env35494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35493 == env35494) = true)

theorem identity35494 : scanCanonicalize (H12AffineFastState.compose env35494 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound35494 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env35495 : List Nat := [2,4,4,16,32,54,128,4,55,34,2048,0,35,55,0,21,0,148,51,1,1,178,0,21,183,55,38,38,54,2081,35,55,5,39,16,38]

theorem envBound35495 : H12AffineFastState.Bounded env35495 := by
  intro p hp
  have h : env35495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35494_35495 : H12AffineEnvironment.transform 5 54 env35494 = env35495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env35494 == env35495) = true)

theorem identity35495 : scanCanonicalize (H12AffineFastState.compose env35495 (packedSelected [0,2,5,7,8,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound35495 : packedSelected [0,2,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env35496 : List Nat := [2,4,4,16,32,54,128,4,55,34,132,0,35,55,0,21,0,148,51,1,1,178,0,21,183,55,38,38,54,165,35,55,5,39,16,38]

theorem envBound35496 : H12AffineFastState.Bounded env35496 := by
  intro p hp
  have h : env35496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35495_35496 : H12AffineEnvironment.transform 10 132 env35495 = env35496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env35495 == env35496) = true)

def env35497 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,64,577,65536,66083,65665,517,576,837,649,66082,65537,193,65830,303,66163,65,67650,784,65830,257,80,17,340]

theorem envBound35497 : H12AffineFastState.Bounded env35497 := by
  intro p hp
  have h : env35497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35480_35497 : H12AffineEnvironment.transform 9 337 env35480 = env35497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env35480 == env35497) = true)

theorem identity35497 : scanCanonicalize (H12AffineFastState.compose env35497 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 362) := by decide +kernel

theorem selectedBound35497 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35498 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,64,577,362,841,491,517,576,837,649,840,363,193,76,303,793,65,2344,784,76,257,80,17,340]

theorem envBound35498 : H12AffineFastState.Bounded env35498 := by
  intro p hp
  have h : env35498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35497_35498 : H12AffineEnvironment.transform 15 362 env35497 = env35498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 362 env35497 == env35498) = true)

def env35499 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,780,64,577,362,841,491,517,576,837,649,840,363,193,76,303,777,65,2344,768,76,257,64,1,324]

theorem envBound35499 : H12AffineFastState.Bounded env35499 := by
  intro p hp
  have h : env35499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35498_35499 : H12AffineEnvironment.transform 3 0 env35498 = env35499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35498 == env35499) = true)

theorem identity35499 : scanCanonicalize (H12AffineFastState.compose env35499 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 76) := by decide +kernel

theorem selectedBound35499 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35500 : List Nat := [2,4,8,0,32,64,128,256,76,321,2048,264,320,64,13,362,261,491,73,12,265,197,260,363,193,76,303,325,65,2344,332,76,257,64,1,324]

theorem envBound35500 : H12AffineFastState.Bounded env35500 := by
  intro p hp
  have h : env35500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35499_35500 : H12AffineEnvironment.transform 8 76 env35499 = env35500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 76 env35499 == env35500) = true)

theorem identity35500 : scanCanonicalize (H12AffineFastState.compose env35500 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound35500 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35501 : List Nat := [2,4,8,0,32,1,128,256,13,256,2048,264,257,1,13,299,261,426,8,12,265,132,260,298,128,13,303,260,0,2344,269,13,257,1,1,261]

theorem envBound35501 : H12AffineFastState.Bounded env35501 := by
  intro p hp
  have h : env35501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35500_35501 : H12AffineEnvironment.transform 5 1 env35500 = env35501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35500 == env35501) = true)

theorem identity35501 : scanCanonicalize (H12AffineFastState.compose env35501 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound35501 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env35502 : List Nat := [2,4,8,0,32,1,128,256,13,256,292,264,257,1,13,299,261,426,8,12,265,132,260,298,128,13,303,260,0,12,269,13,257,1,1,261]

theorem envBound35502 : H12AffineFastState.Bounded env35502 := by
  intro p hp
  have h : env35502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35501_35502 : H12AffineEnvironment.transform 10 292 env35501 = env35502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env35501 == env35502) = true)

theorem identity35502 : scanCanonicalize (H12AffineFastState.compose env35502 (packedSelected [0,1,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound35502 : packedSelected [0,1,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env35503 : List Nat := [2,4,8,0,32,1,128,161,13,161,133,169,160,1,13,138,164,11,8,12,168,132,165,139,128,13,142,165,0,12,172,13,160,1,1,164]

theorem envBound35503 : H12AffineFastState.Bounded env35503 := by
  intro p hp
  have h : env35503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35502_35503 : H12AffineEnvironment.transform 7 161 env35502 = env35503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env35502 == env35503) = true)

theorem identity35503 : scanCanonicalize (H12AffineFastState.compose env35503 (packedSelected [1,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound35503 : packedSelected [1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35504 : List Nat := [2,4,8,0,32,1,5,36,13,36,0,44,37,1,13,15,33,11,8,12,45,1,32,14,5,13,11,32,0,12,41,13,37,1,1,33]

theorem envBound35504 : H12AffineFastState.Bounded env35504 := by
  intro p hp
  have h : env35504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35503_35504 : H12AffineEnvironment.transform 6 5 env35503 = env35504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env35503 == env35504) = true)

theorem identity35504 : scanCanonicalize (H12AffineFastState.compose env35504 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35504 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35505 : List Nat := [2,4,2,0,32,1,5,36,7,36,0,38,37,1,7,5,33,1,2,6,39,1,32,4,5,7,1,32,0,6,35,7,37,1,1,33]

theorem envBound35505 : H12AffineFastState.Bounded env35505 := by
  intro p hp
  have h : env35505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35504_35505 : H12AffineEnvironment.transform 2 2 env35504 = env35505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35504 == env35505) = true)

def env35506 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,781,64,577,362,841,491,517,576,837,649,840,363,193,76,303,776,65,2344,769,76,257,65,0,325]

theorem envBound35506 : H12AffineFastState.Bounded env35506 := by
  intro p hp
  have h : env35506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35498_35506 : H12AffineEnvironment.transform 3 1 env35498 = env35506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35498 == env35506) = true)

theorem identity35506 : scanCanonicalize (H12AffineFastState.compose env35506 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound35506 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35507 : List Nat := [2,4,8,1,32,64,128,8,512,72,2048,588,517,64,577,98,577,227,517,576,589,649,576,99,193,76,39,512,65,2080,521,76,9,65,0,77]

theorem envBound35507 : H12AffineFastState.Bounded env35507 := by
  intro p hp
  have h : env35507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35506_35507 : H12AffineEnvironment.transform 7 8 env35506 = env35507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env35506 == env35507) = true)

theorem identity35507 : scanCanonicalize (H12AffineFastState.compose env35507 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 751) := by decide +kernel

theorem selectedBound35507 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env35508 : List Nat := [2,4,8,1,32,64,128,8,512,72,751,588,517,64,577,98,577,227,517,576,589,649,576,99,193,76,39,512,65,719,521,76,9,65,0,77]

theorem envBound35508 : H12AffineFastState.Bounded env35508 := by
  intro p hp
  have h : env35508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35507_35508 : H12AffineEnvironment.transform 10 751 env35507 = env35508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 751 env35507 == env35508) = true)

theorem identity35508 : scanCanonicalize (H12AffineFastState.compose env35508 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound35508 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35509 : List Nat := [2,4,8,1,32,64,37,8,512,72,586,588,517,64,577,98,577,70,517,576,589,556,576,99,100,76,39,512,65,618,521,76,9,65,0,77]

theorem envBound35509 : H12AffineFastState.Bounded env35509 := by
  intro p hp
  have h : env35509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35508_35509 : H12AffineEnvironment.transform 6 37 env35508 = env35509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env35508 == env35509) = true)

theorem identity35509 : scanCanonicalize (H12AffineFastState.compose env35509 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35509 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env35510 : List Nat := [2,4,8,1,1,64,4,8,512,72,586,588,517,64,577,67,577,70,517,576,589,525,576,66,69,76,6,512,65,587,521,76,9,65,0,77]

theorem envBound35510 : H12AffineFastState.Bounded env35510 := by
  intro p hp
  have h : env35510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35509_35510 : H12AffineEnvironment.transform 4 1 env35509 = env35510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35509 == env35510) = true)

theorem identity35510 : scanCanonicalize (H12AffineFastState.compose env35510 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35510 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env35511 : List Nat := [2,4,8,1,1,0,4,8,512,8,522,524,517,0,513,3,513,6,517,512,525,525,512,2,5,12,6,512,1,523,521,12,9,1,0,13]

theorem envBound35511 : H12AffineFastState.Bounded env35511 := by
  intro p hp
  have h : env35511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35510_35511 : H12AffineEnvironment.transform 5 0 env35510 = env35511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35510 == env35511) = true)

theorem identity35511 : scanCanonicalize (H12AffineFastState.compose env35511 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35511 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35512 : List Nat := [2,4,8,1,1,0,4,8,10,8,0,6,15,0,11,3,11,6,15,10,7,7,10,2,5,12,6,10,1,1,3,12,9,1,0,13]

theorem envBound35512 : H12AffineFastState.Bounded env35512 := by
  intro p hp
  have h : env35512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35511_35512 : H12AffineEnvironment.transform 8 10 env35511 = env35512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35511 == env35512) = true)

theorem identity35512 : scanCanonicalize (H12AffineFastState.compose env35512 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35513 : List Nat := [2,2,8,1,1,0,2,8,10,8,0,0,9,0,11,3,11,0,9,10,1,1,10,2,3,10,0,10,1,1,3,10,9,1,0,11]

theorem envBound35513 : H12AffineFastState.Bounded env35513 := by
  intro p hp
  have h : env35513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35512_35513 : H12AffineEnvironment.transform 1 2 env35512 = env35513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35512 == env35513) = true)

theorem identity35513 : scanCanonicalize (H12AffineFastState.compose env35513 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35514 : List Nat := [0,0,8,1,1,0,0,8,8,8,0,0,9,0,9,1,9,0,9,8,1,1,8,0,1,8,0,8,1,1,1,8,9,1,0,9]

theorem envBound35514 : H12AffineFastState.Bounded env35514 := by
  intro p hp
  have h : env35514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35513_35514 : H12AffineEnvironment.transform 0 0 env35513 = env35514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35513 == env35514) = true)

theorem identity35514 : scanCanonicalize (H12AffineFastState.compose env35514 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35514 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35515 : List Nat := [0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,1,0,0,0,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,0,0]

theorem envBound35515 : H12AffineFastState.Bounded env35515 := by
  intro p hp
  have h : env35515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35514_35515 : H12AffineEnvironment.transform 2 1 env35514 = env35515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35514 == env35515) = true)

def env35516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123164,28888,78894,385203,90415,1297,96346,25885,82999,257,1280,1344,21073]

theorem envBound35516 : H12AffineFastState.Bounded env35516 := by
  intro p hp
  have h : env35516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35285_35516 : H12AffineEnvironment.transform 18 21585 env35285 = env35516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env35285 == env35516) = true)

theorem identity35516 : scanCanonicalize (H12AffineFastState.compose env35516 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35516 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4097,17613,91183,87297,28888,78894,349358,90415,1297,96346,25885,82999,257,1280,1344,21073]

theorem envBound35517 : H12AffineFastState.Bounded env35517 := by
  intro p hp
  have h : env35517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35516_35517 : H12AffineEnvironment.transform 14 13341 env35516 = env35517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35516 == env35517) = true)

def env35518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4097,477,74047,69649,13768,78894,332222,74815,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound35518 : H12AffineFastState.Bounded env35518 := by
  intro p hp
  have h : env35518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35517_35518 : H12AffineEnvironment.transform 13 1296 env35517 = env35518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35517 == env35518) = true)

def env35519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4097,477,74047,69649,13768,78894,4414,74815,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound35519 : H12AffineFastState.Bounded env35519 := by
  intro p hp
  have h : env35519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35518_35519 : H12AffineEnvironment.transform 17 65664 env35518 = env35519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35518 == env35519) = true)

theorem identity35519 : scanCanonicalize (H12AffineFastState.compose env35519 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound35519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,1,477,74047,65553,9672,74798,318,74815,1297,77130,8205,65831,257,1280,1344,1857]

theorem envBound35520 : H12AffineFastState.Bounded env35520 := by
  intro p hp
  have h : env35520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35519_35520 : H12AffineEnvironment.transform 11 0 env35519 = env35520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35519 == env35520) = true)

def env35521 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,1,477,74047,65553,9672,74798,318,74815,1297,77130,8205,65831,257,1280,1344,1045]

theorem envBound35521 : H12AffineFastState.Bounded env35521 := by
  intro p hp
  have h : env35521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35520_35521 : H12AffineEnvironment.transform 8 340 env35520 = env35521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env35520 == env35521) = true)

def env35522 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9229,65536,74862,65664,321,9228,1,461,74031,65537,9672,74798,302,74799,1281,77130,8205,65831,257,1280,1344,1029]

theorem envBound35522 : H12AffineFastState.Bounded env35522 := by
  intro p hp
  have h : env35522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35521_35522 : H12AffineEnvironment.transform 3 0 env35521 = env35522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35521 == env35522) = true)

theorem identity35522 : scanCanonicalize (H12AffineFastState.compose env35522 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound35522 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35523 : List Nat := [2,4,8,0,32,12,128,256,264,1024,2048,0,8192,1280,9229,65536,74786,65664,269,9228,1,385,74031,65537,9604,74798,302,74799,1281,77062,8205,65831,257,1280,1292,1029]

theorem envBound35523 : H12AffineFastState.Bounded env35523 := by
  intro p hp
  have h : env35523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35522_35523 : H12AffineEnvironment.transform 5 12 env35522 = env35523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env35522 == env35523) = true)

def env35524 : List Nat := [2,4,8,0,32,12,128,256,264,256,2048,0,8192,0,8461,65536,74018,65664,269,8460,1,385,74031,65537,8324,74030,302,74031,1,75782,8205,65831,257,0,12,261]

theorem envBound35524 : H12AffineFastState.Bounded env35524 := by
  intro p hp
  have h : env35524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35523_35524 : H12AffineEnvironment.transform 9 256 env35523 = env35524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env35523 == env35524) = true)

theorem identity35524 : scanCanonicalize (H12AffineFastState.compose env35524 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8231) := by decide +kernel

theorem selectedBound35524 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env35525 : List Nat := [2,4,8,0,32,12,128,256,264,256,2048,0,8192,0,8461,8231,261,8359,269,8460,1,385,264,8230,8324,265,302,264,1,2081,8205,8448,257,0,12,261]

theorem envBound35525 : H12AffineFastState.Bounded env35525 := by
  intro p hp
  have h : env35525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35524_35525 : H12AffineEnvironment.transform 15 8231 env35524 = env35525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8231 env35524 == env35525) = true)

theorem identity35525 : scanCanonicalize (H12AffineFastState.compose env35525 (packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound35525 : packedSelected [0,2,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env35526 : List Nat := [2,4,8,0,32,12,128,256,264,256,12,0,8192,0,8461,8231,261,8359,269,8460,1,385,264,8230,8324,265,302,264,1,45,8205,8448,257,0,12,261]

theorem envBound35526 : H12AffineFastState.Bounded env35526 := by
  intro p hp
  have h : env35526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35525_35526 : H12AffineEnvironment.transform 10 12 env35525 = env35526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env35525 == env35526) = true)

theorem identity35526 : scanCanonicalize (H12AffineFastState.compose env35526 (packedSelected [8,10,11,12,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound35526 : packedSelected [8,10,11,12,17,18,19] rootPS < 2^1333 := by decide +kernel

def env35527 : List Nat := [2,4,8,0,32,12,128,40,32,40,12,0,8192,0,8229,8231,45,8359,37,8228,1,169,32,8230,8324,33,6,32,1,45,8205,8232,41,0,12,45]

theorem envBound35527 : H12AffineFastState.Bounded env35527 := by
  intro p hp
  have h : env35527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35526_35527 : H12AffineEnvironment.transform 7 40 env35526 = env35527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env35526 == env35527) = true)

theorem identity35527 : scanCanonicalize (H12AffineFastState.compose env35527 (packedSelected [1,3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound35527 : packedSelected [1,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env35528 : List Nat := [2,4,8,0,32,12,15,40,32,40,12,0,8192,0,8229,8231,45,8232,37,8228,1,38,32,8230,8203,33,6,32,1,45,8205,8232,41,0,12,45]

theorem envBound35528 : H12AffineFastState.Bounded env35528 := by
  intro p hp
  have h : env35528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35527_35528 : H12AffineEnvironment.transform 6 15 env35527 = env35528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env35527 == env35528) = true)

theorem identity35528 : scanCanonicalize (H12AffineFastState.compose env35528 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound35528 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35529 : List Nat := [2,4,8,0,32,12,15,40,32,40,12,0,40,0,13,15,45,0,37,12,1,38,32,14,35,33,6,32,1,45,37,0,41,0,12,45]

theorem envBound35529 : H12AffineFastState.Bounded env35529 := by
  intro p hp
  have h : env35529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35528_35529 : H12AffineEnvironment.transform 12 40 env35528 = env35529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env35528 == env35529) = true)

theorem identity35529 : scanCanonicalize (H12AffineFastState.compose env35529 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35529 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35530 : List Nat := [2,4,8,0,0,12,15,8,0,8,12,0,8,0,13,15,13,0,5,12,1,6,0,14,3,1,6,0,1,13,5,0,9,0,12,13]

theorem envBound35530 : H12AffineFastState.Bounded env35530 := by
  intro p hp
  have h : env35530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35529_35530 : H12AffineEnvironment.transform 4 0 env35529 = env35530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35529 == env35530) = true)

theorem identity35530 : scanCanonicalize (H12AffineFastState.compose env35530 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35530 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35531 : List Nat := [2,4,3,0,0,7,4,3,0,3,7,0,3,0,6,4,6,0,5,7,1,6,0,5,3,1,6,0,1,6,5,0,2,0,7,6]

theorem envBound35531 : H12AffineFastState.Bounded env35531 := by
  intro p hp
  have h : env35531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35530_35531 : H12AffineEnvironment.transform 2 3 env35530 = env35531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35530 == env35531) = true)

theorem identity35531 : scanCanonicalize (H12AffineFastState.compose env35531 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35532 : List Nat := [2,3,3,0,0,0,3,3,0,3,0,0,3,0,1,3,1,0,2,0,1,1,0,2,3,1,1,0,1,1,2,0,2,0,0,1]

theorem envBound35532 : H12AffineFastState.Bounded env35532 := by
  intro p hp
  have h : env35532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35531_35532 : H12AffineEnvironment.transform 1 3 env35531 = env35532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35531 == env35532) = true)

theorem identity35532 : scanCanonicalize (H12AffineFastState.compose env35532 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35533 : List Nat := [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,1,0,1,0,1,1,0,1,1,1,0,1,0,0,1]

theorem envBound35533 : H12AffineFastState.Bounded env35533 := by
  intro p hp
  have h : env35533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35532_35533 : H12AffineEnvironment.transform 0 1 env35532 = env35533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35532 == env35533) = true)

def env35534 : List Nat := [2,4,8,0,32,12,128,256,264,257,2048,0,8192,1,8460,65536,74019,65664,269,8461,1,385,74031,65537,8325,74031,302,74030,0,75783,8205,65831,257,1,13,260]

theorem envBound35534 : H12AffineFastState.Bounded env35534 := by
  intro p hp
  have h : env35534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35523_35534 : H12AffineEnvironment.transform 9 257 env35523 = env35534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env35523 == env35534) = true)

theorem identity35534 : scanCanonicalize (H12AffineFastState.compose env35534 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound35534 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env35535 : List Nat := [2,4,8,0,32,12,128,256,264,257,2048,0,8192,1,8460,8234,265,8362,269,8461,1,385,261,8235,8325,261,302,260,0,2093,8205,8461,257,1,13,260]

theorem envBound35535 : H12AffineFastState.Bounded env35535 := by
  intro p hp
  have h : env35535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35534_35535 : H12AffineEnvironment.transform 15 8234 env35534 = env35535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env35534 == env35535) = true)

theorem identity35535 : scanCanonicalize (H12AffineFastState.compose env35535 (packedSelected [0,1,4,7,8,9,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound35535 : packedSelected [0,1,4,7,8,9,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35536 : List Nat := [2,4,8,0,32,12,128,256,264,257,2048,0,4,1,264,46,265,174,269,265,1,385,261,47,129,261,302,260,0,2093,9,265,257,1,13,260]

theorem envBound35536 : H12AffineFastState.Bounded env35536 := by
  intro p hp
  have h : env35536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35535_35536 : H12AffineEnvironment.transform 12 4 env35535 = env35536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env35535 == env35536) = true)

theorem identity35536 : scanCanonicalize (H12AffineFastState.compose env35536 (packedSelected [0,2,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound35536 : packedSelected [0,2,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env35537 : List Nat := [2,4,8,0,32,12,128,41,33,40,2048,0,4,1,33,46,32,174,36,32,1,168,44,47,129,44,7,45,0,2093,9,32,40,1,13,45]

theorem envBound35537 : H12AffineFastState.Bounded env35537 := by
  intro p hp
  have h : env35537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35536_35537 : H12AffineEnvironment.transform 7 41 env35536 = env35537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env35536 == env35537) = true)

theorem identity35537 : scanCanonicalize (H12AffineFastState.compose env35537 (packedSelected [2,5,10,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35537 : packedSelected [2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env35538 : List Nat := [2,3,8,0,32,11,128,41,33,40,2048,0,3,1,33,41,32,169,35,32,1,168,43,40,129,43,0,42,0,2090,9,32,40,1,10,42]

theorem envBound35538 : H12AffineFastState.Bounded env35538 := by
  intro p hp
  have h : env35538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35537_35538 : H12AffineEnvironment.transform 1 3 env35537 = env35538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35537 == env35538) = true)

theorem identity35538 : scanCanonicalize (H12AffineFastState.compose env35538 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound35538 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env35539 : List Nat := [2,3,8,0,32,11,128,41,33,40,11,0,3,1,33,41,32,169,35,32,1,168,43,40,129,43,0,42,0,33,9,32,40,1,10,42]

theorem envBound35539 : H12AffineFastState.Bounded env35539 := by
  intro p hp
  have h : env35539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35538_35539 : H12AffineEnvironment.transform 10 11 env35538 = env35539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env35538 == env35539) = true)

theorem identity35539 : scanCanonicalize (H12AffineFastState.compose env35539 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35539 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env35540 : List Nat := [2,3,8,0,0,11,128,9,1,8,11,0,3,1,1,9,0,137,3,0,1,136,11,8,129,11,0,10,0,1,9,0,8,1,10,10]

theorem envBound35540 : H12AffineFastState.Bounded env35540 := by
  intro p hp
  have h : env35540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35539_35540 : H12AffineEnvironment.transform 4 0 env35539 = env35540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35539 == env35540) = true)

theorem identity35540 : scanCanonicalize (H12AffineFastState.compose env35540 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound35540 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env35541 : List Nat := [2,3,8,0,0,11,3,9,1,8,11,0,3,1,1,9,0,10,3,0,1,11,11,8,2,11,0,10,0,1,9,0,8,1,10,10]

theorem envBound35541 : H12AffineFastState.Bounded env35541 := by
  intro p hp
  have h : env35541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35540_35541 : H12AffineEnvironment.transform 6 3 env35540 = env35541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env35540 == env35541) = true)

def env35542 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9228,65536,74862,65664,321,9229,1,460,74030,65536,9672,74798,303,74798,1280,77130,8205,65831,257,1280,1344,1028]

theorem envBound35542 : H12AffineFastState.Bounded env35542 := by
  intro p hp
  have h : env35542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35521_35542 : H12AffineEnvironment.transform 3 1 env35521 = env35542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35521 == env35542) = true)

theorem identity35542 : scanCanonicalize (H12AffineFastState.compose env35542 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1349) := by decide +kernel

theorem selectedBound35542 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35543 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,1349,1281,329,65536,65835,65664,321,328,1,460,66667,65536,141,65899,303,65899,1280,67599,1352,65831,257,1280,1344,1028]

theorem envBound35543 : H12AffineFastState.Bounded env35543 := by
  intro p hp
  have h : env35543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35542_35543 : H12AffineEnvironment.transform 12 1349 env35542 = env35543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1349 env35542 == env35543) = true)

def env35544 : List Nat := [2,4,8,1,32,0,128,256,261,1024,2048,0,1285,1281,265,65536,65835,65664,257,264,1,396,66603,65536,141,65835,303,65835,1280,67599,1288,65831,257,1280,1280,1028]

theorem envBound35544 : H12AffineFastState.Bounded env35544 := by
  intro p hp
  have h : env35544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35543_35544 : H12AffineEnvironment.transform 5 0 env35543 = env35544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35543 == env35544) = true)

theorem identity35544 : scanCanonicalize (H12AffineFastState.compose env35544 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 1326) := by decide +kernel

theorem selectedBound35544 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env35545 : List Nat := [2,4,8,1,32,0,128,256,261,1024,2048,0,1285,1281,265,1326,1029,1454,257,264,1,396,261,1326,141,1029,303,1029,1280,3361,1288,1033,257,1280,1280,1028]

theorem envBound35545 : H12AffineFastState.Bounded env35545 := by
  intro p hp
  have h : env35545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35544_35545 : H12AffineEnvironment.transform 15 1326 env35544 = env35545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1326 env35544 == env35545) = true)

theorem identity35545 : scanCanonicalize (H12AffineFastState.compose env35545 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35545 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35546 : List Nat := [2,4,8,1,32,0,128,256,261,5,2048,0,256,260,265,299,0,427,257,264,1,396,261,299,141,0,303,0,261,2340,269,12,257,261,261,1]

theorem envBound35546 : H12AffineFastState.Bounded env35546 := by
  intro p hp
  have h : env35546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35545_35546 : H12AffineEnvironment.transform 9 5 env35545 = env35546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35545 == env35546) = true)

theorem identity35546 : scanCanonicalize (H12AffineFastState.compose env35546 (packedSelected [1,2,3,5,8,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound35546 : packedSelected [1,2,3,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env35547 : List Nat := [2,4,8,1,32,0,128,256,261,5,162,0,256,260,265,299,0,427,257,264,1,396,261,299,141,0,303,0,261,390,269,12,257,261,261,1]

theorem envBound35547 : H12AffineFastState.Bounded env35547 := by
  intro p hp
  have h : env35547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35546_35547 : H12AffineEnvironment.transform 10 162 env35546 = env35547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env35546 == env35547) = true)

theorem identity35547 : scanCanonicalize (H12AffineFastState.compose env35547 (packedSelected [0,2,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound35547 : packedSelected [0,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env35548 : List Nat := [2,4,8,1,32,0,41,256,261,5,11,0,256,260,265,299,0,258,257,264,1,293,261,299,36,0,303,0,261,303,269,12,257,261,261,1]

theorem envBound35548 : H12AffineFastState.Bounded env35548 := by
  intro p hp
  have h : env35548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35547_35548 : H12AffineEnvironment.transform 6 41 env35547 = env35548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env35547 == env35548) = true)

theorem identity35548 : scanCanonicalize (H12AffineFastState.compose env35548 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound35548 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35549 : List Nat := [2,4,8,1,12,0,5,256,261,5,11,0,256,260,265,263,0,258,257,264,1,265,261,263,8,0,259,0,261,259,269,12,257,261,261,1]

theorem envBound35549 : H12AffineFastState.Bounded env35549 := by
  intro p hp
  have h : env35549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35548_35549 : H12AffineEnvironment.transform 4 12 env35548 = env35549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env35548 == env35549) = true)

theorem identity35549 : scanCanonicalize (H12AffineFastState.compose env35549 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound35549 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35550 : List Nat := [2,4,8,1,12,0,5,2,7,5,11,0,2,6,11,5,0,0,3,10,1,11,7,5,8,0,1,0,7,1,15,12,3,7,7,1]

theorem envBound35550 : H12AffineFastState.Bounded env35550 := by
  intro p hp
  have h : env35550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35549_35550 : H12AffineEnvironment.transform 7 2 env35549 = env35550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env35549 == env35550) = true)

theorem identity35550 : scanCanonicalize (H12AffineFastState.compose env35550 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35551 : List Nat := [2,4,5,1,1,0,5,2,7,5,6,0,2,6,6,5,0,0,3,7,1,6,7,5,5,0,1,0,7,1,2,1,3,7,7,1]

theorem envBound35551 : H12AffineFastState.Bounded env35551 := by
  intro p hp
  have h : env35551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35550_35551 : H12AffineEnvironment.transform 2 5 env35550 = env35551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35550 == env35551) = true)

theorem identity35551 : scanCanonicalize (H12AffineFastState.compose env35551 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35551 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35552 : List Nat := [2,2,3,1,1,0,3,2,1,3,0,0,2,0,0,3,0,0,3,1,1,0,1,3,3,0,1,0,1,1,2,1,3,1,1,1]

theorem envBound35552 : H12AffineFastState.Bounded env35552 := by
  intro p hp
  have h : env35552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35551_35552 : H12AffineEnvironment.transform 1 2 env35551 = env35552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35551 == env35552) = true)

def env35553 : List Nat := [2,4,8,1,32,1,128,256,260,1024,2048,0,1284,1281,264,65536,65835,65664,256,265,1,397,66602,65536,141,65834,303,65834,1280,67599,1289,65831,257,1280,1281,1028]

theorem envBound35553 : H12AffineFastState.Bounded env35553 := by
  intro p hp
  have h : env35553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35543_35553 : H12AffineEnvironment.transform 5 1 env35543 = env35553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35543 == env35553) = true)

theorem identity35553 : scanCanonicalize (H12AffineFastState.compose env35553 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound35553 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env35554 : List Nat := [2,4,8,1,32,1,128,256,260,1024,2048,0,1284,1281,264,47,260,175,256,265,1,397,1029,47,141,261,303,261,1280,2080,1289,264,257,1280,1281,1028]

theorem envBound35554 : H12AffineFastState.Bounded env35554 := by
  intro p hp
  have h : env35554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35553_35554 : H12AffineEnvironment.transform 15 47 env35553 = env35554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env35553 == env35554) = true)

theorem identity35554 : scanCanonicalize (H12AffineFastState.compose env35554 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35554 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35555 : List Nat := [2,4,8,1,32,1,128,256,260,5,2048,0,257,260,264,47,260,175,256,265,1,397,0,47,141,261,303,261,261,2080,268,264,257,261,260,1]

theorem envBound35555 : H12AffineFastState.Bounded env35555 := by
  intro p hp
  have h : env35555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35554_35555 : H12AffineEnvironment.transform 9 5 env35554 = env35555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35554 == env35555) = true)

theorem identity35555 : scanCanonicalize (H12AffineFastState.compose env35555 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound35555 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35556 : List Nat := [2,4,8,1,32,1,128,140,136,5,2048,0,141,136,132,47,136,175,140,133,1,1,0,47,141,137,163,137,137,2080,128,132,141,137,136,1]

theorem envBound35556 : H12AffineFastState.Bounded env35556 := by
  intro p hp
  have h : env35556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35555_35556 : H12AffineEnvironment.transform 7 140 env35555 = env35556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env35555 == env35556) = true)

theorem identity35556 : scanCanonicalize (H12AffineFastState.compose env35556 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound35556 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env35557 : List Nat := [2,4,8,1,32,1,128,140,136,5,131,0,141,136,132,47,136,175,140,133,1,1,0,47,141,137,163,137,137,163,128,132,141,137,136,1]

theorem envBound35557 : H12AffineFastState.Bounded env35557 := by
  intro p hp
  have h : env35557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35556_35557 : H12AffineEnvironment.transform 10 131 env35556 = env35557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env35556 == env35557) = true)

theorem identity35557 : scanCanonicalize (H12AffineFastState.compose env35557 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound35557 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35558 : List Nat := [2,4,8,1,32,1,47,35,39,5,44,0,34,39,43,47,39,0,35,42,1,1,0,47,34,38,12,38,38,12,47,43,34,38,39,1]

theorem envBound35558 : H12AffineFastState.Bounded env35558 := by
  intro p hp
  have h : env35558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35557_35558 : H12AffineEnvironment.transform 6 47 env35557 = env35558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env35557 == env35558) = true)

theorem identity35558 : scanCanonicalize (H12AffineFastState.compose env35558 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35559 : List Nat := [2,4,4,1,32,1,35,35,39,5,32,0,34,39,39,35,39,0,35,38,1,1,0,35,34,38,0,38,38,0,35,39,34,38,39,1]

theorem envBound35559 : H12AffineFastState.Bounded env35559 := by
  intro p hp
  have h : env35559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35558_35559 : H12AffineEnvironment.transform 2 4 env35558 = env35559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35558 == env35559) = true)

theorem identity35559 : scanCanonicalize (H12AffineFastState.compose env35559 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35560 : List Nat := [2,2,2,1,32,1,35,35,33,3,32,0,34,33,33,35,33,0,35,32,1,1,0,35,34,32,0,32,32,0,35,33,34,32,33,1]

theorem envBound35560 : H12AffineFastState.Bounded env35560 := by
  intro p hp
  have h : env35560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35559_35560 : H12AffineEnvironment.transform 1 2 env35559 = env35560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35559 == env35560) = true)

theorem identity35560 : scanCanonicalize (H12AffineFastState.compose env35560 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35560 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35561 : List Nat := [2,2,2,1,1,1,2,2,0,3,1,0,3,0,0,2,0,0,2,1,1,1,0,2,3,1,0,1,1,0,2,0,3,1,0,1]

theorem envBound35561 : H12AffineFastState.Bounded env35561 := by
  intro p hp
  have h : env35561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35560_35561 : H12AffineEnvironment.transform 4 1 env35560 = env35561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35560 == env35561) = true)

theorem identity35561 : scanCanonicalize (H12AffineFastState.compose env35561 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35562 : List Nat := [1,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,0,1,1,1,1,0,1,0,1,0,1,1,0,1,0,0,1,0,1]

theorem envBound35562 : H12AffineFastState.Bounded env35562 := by
  intro p hp
  have h : env35562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35561_35562 : H12AffineEnvironment.transform 0 1 env35561 = env35562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35561 == env35562) = true)

def env35563 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,1,477,74047,65553,9672,74798,318,74815,1297,77130,8205,65831,257,1280,1344,1044]

theorem envBound35563 : H12AffineFastState.Bounded env35563 := by
  intro p hp
  have h : env35563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35520_35563 : H12AffineEnvironment.transform 8 341 env35520 = env35563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env35520 == env35563) = true)

def env35564 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9229,65536,74862,65664,321,9228,1,461,74031,65537,9672,74798,302,74799,1281,77130,8205,65831,257,1280,1344,1028]

theorem envBound35564 : H12AffineFastState.Bounded env35564 := by
  intro p hp
  have h : env35564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35563_35564 : H12AffineEnvironment.transform 3 0 env35563 = env35564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35563 == env35564) = true)

theorem identity35564 : scanCanonicalize (H12AffineFastState.compose env35564 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8546) := by decide +kernel

theorem selectedBound35564 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env35565 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9229,8546,1292,8674,321,9228,1,461,77,8547,9672,1356,302,1357,1281,3112,8205,8261,257,1280,1344,1028]

theorem envBound35565 : H12AffineFastState.Bounded env35565 := by
  intro p hp
  have h : env35565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35564_35565 : H12AffineEnvironment.transform 15 8546 env35564 = env35565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8546 env35564 == env35565) = true)

def env35566 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,8192,64,8525,8546,76,8674,321,8524,1,461,77,8547,8328,12,302,13,65,2408,8205,8261,257,64,0,324]

theorem envBound35566 : H12AffineFastState.Bounded env35566 := by
  intro p hp
  have h : env35566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35565_35566 : H12AffineEnvironment.transform 9 320 env35565 = env35566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35565 == env35566) = true)

theorem identity35566 : scanCanonicalize (H12AffineFastState.compose env35566 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

end H12CloudChart2