import H12CloudChart2Data178

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound44871 : H12AffineFastState.Bounded env44871 := by
  intro p hp
  have h : env44871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44870_44871 : H12AffineEnvironment.transform 15 362 env44870 = env44871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 362 env44870 == env44871) = true)

theorem identity44871 : scanCanonicalize (H12AffineFastState.compose env44871 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44871 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44872 : List Nat := [2,4,5,1,32,64,128,256,64,320,2048,261,69,64,261,359,0,487,68,260,260,196,1,358,453,324,291,64,64,2081,69,65,257,64,1,324]

theorem envBound44872 : H12AffineFastState.Bounded env44872 := by
  intro p hp
  have h : env44872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44871_44872 : H12AffineEnvironment.transform 2 5 env44871 = env44872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44871 == env44872) = true)

theorem identity44872 : scanCanonicalize (H12AffineFastState.compose env44872 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound44872 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env44873 : List Nat := [2,4,5,1,32,64,128,134,64,198,2048,131,69,64,131,225,0,97,68,130,130,196,1,224,67,194,165,64,64,2081,69,65,135,64,1,194]

theorem envBound44873 : H12AffineFastState.Bounded env44873 := by
  intro p hp
  have h : env44873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44872_44873 : H12AffineEnvironment.transform 7 134 env44872 = env44873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env44872 == env44873) = true)

theorem identity44873 : scanCanonicalize (H12AffineFastState.compose env44873 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound44873 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44874 : List Nat := [2,4,5,1,32,39,128,134,39,161,2048,131,34,39,131,134,0,6,35,130,130,163,1,135,36,165,165,39,39,2081,34,38,135,39,1,165]

theorem envBound44874 : H12AffineFastState.Bounded env44874 := by
  intro p hp
  have h : env44874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44873_44874 : H12AffineEnvironment.transform 5 39 env44873 = env44874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env44873 == env44874) = true)

theorem identity44874 : scanCanonicalize (H12AffineFastState.compose env44874 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound44874 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env44875 : List Nat := [2,4,5,1,32,39,128,134,39,161,131,131,34,39,131,134,0,6,35,130,130,163,1,135,36,165,165,39,39,162,34,38,135,39,1,165]

theorem envBound44875 : H12AffineFastState.Bounded env44875 := by
  intro p hp
  have h : env44875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44874_44875 : H12AffineEnvironment.transform 10 131 env44874 = env44875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env44874 == env44875) = true)

def env44876 : List Nat := [2,4,8,1,32,64,128,256,77,320,2048,264,73,64,260,65536,65894,65664,73,261,265,196,65895,65537,457,65583,302,65830,64,67914,68,65830,257,64,1,324]

theorem envBound44876 : H12AffineFastState.Bounded env44876 := by
  intro p hp
  have h : env44876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44869_44876 : H12AffineEnvironment.transform 12 73 env44869 = env44876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env44869 == env44876) = true)

theorem identity44876 : scanCanonicalize (H12AffineFastState.compose env44876 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound44876 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44877 : List Nat := [2,4,8,1,32,64,128,256,77,320,2048,264,73,64,260,98,260,226,73,261,265,196,261,99,457,77,302,324,64,2344,68,324,257,64,1,324]

theorem envBound44877 : H12AffineFastState.Bounded env44877 := by
  intro p hp
  have h : env44877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44876_44877 : H12AffineEnvironment.transform 15 98 env44876 = env44877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env44876 == env44877) = true)

theorem identity44877 : scanCanonicalize (H12AffineFastState.compose env44877 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44877 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44878 : List Nat := [2,4,8,1,32,0,128,256,13,256,2048,264,9,0,260,34,260,162,9,261,265,132,261,35,393,13,302,260,0,2344,4,260,257,0,1,260]

theorem envBound44878 : H12AffineFastState.Bounded env44878 := by
  intro p hp
  have h : env44878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44877_44878 : H12AffineEnvironment.transform 5 0 env44877 = env44878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44877 == env44878) = true)

theorem identity44878 : scanCanonicalize (H12AffineFastState.compose env44878 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound44878 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44879 : List Nat := [2,4,8,1,32,0,128,256,13,256,39,264,9,0,260,34,260,162,9,261,265,132,261,35,393,13,302,260,0,271,4,260,257,0,1,260]

theorem envBound44879 : H12AffineFastState.Bounded env44879 := by
  intro p hp
  have h : env44879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44878_44879 : H12AffineEnvironment.transform 10 39 env44878 = env44879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env44878 == env44879) = true)

theorem identity44879 : scanCanonicalize (H12AffineFastState.compose env44879 (packedSelected [0,2,4,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound44879 : packedSelected [0,2,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44880 : List Nat := [2,4,8,1,32,0,128,161,13,161,39,169,9,0,165,34,165,162,9,164,168,132,164,35,40,13,143,165,0,174,4,165,160,0,1,165]

theorem envBound44880 : H12AffineFastState.Bounded env44880 := by
  intro p hp
  have h : env44880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44879_44880 : H12AffineEnvironment.transform 7 161 env44879 = env44880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env44879 == env44880) = true)

theorem identity44880 : scanCanonicalize (H12AffineFastState.compose env44880 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound44880 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env44881 : List Nat := [2,4,8,1,32,0,40,9,13,9,39,1,9,0,13,34,13,10,9,12,0,44,12,35,40,13,39,13,0,6,4,13,8,0,1,13]

theorem envBound44881 : H12AffineFastState.Bounded env44881 := by
  intro p hp
  have h : env44881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44880_44881 : H12AffineEnvironment.transform 6 40 env44880 = env44881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env44880 == env44881) = true)

theorem identity44881 : scanCanonicalize (H12AffineFastState.compose env44881 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44882 : List Nat := [2,4,8,1,10,0,2,9,13,9,13,1,9,0,13,8,13,10,9,12,0,6,12,9,2,13,13,13,0,6,4,13,8,0,1,13]

theorem envBound44882 : H12AffineFastState.Bounded env44882 := by
  intro p hp
  have h : env44882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44881_44882 : H12AffineEnvironment.transform 4 10 env44881 = env44882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44881 == env44882) = true)

theorem identity44882 : scanCanonicalize (H12AffineFastState.compose env44882 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44883 : List Nat := [2,4,3,1,1,0,2,2,6,2,6,1,2,0,6,3,6,1,2,7,0,6,7,2,2,6,6,6,0,6,4,6,3,0,1,6]

theorem envBound44883 : H12AffineFastState.Bounded env44883 := by
  intro p hp
  have h : env44883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44882_44883 : H12AffineEnvironment.transform 2 3 env44882 = env44883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44882 == env44883) = true)

theorem identity44883 : scanCanonicalize (H12AffineFastState.compose env44883 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44884 : List Nat := [2,3,3,1,1,0,2,2,1,2,1,1,2,0,1,3,1,1,2,0,0,1,0,2,2,1,1,1,0,1,3,1,3,0,1,1]

theorem envBound44884 : H12AffineFastState.Bounded env44884 := by
  intro p hp
  have h : env44884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44883_44884 : H12AffineEnvironment.transform 1 3 env44883 = env44884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44883 == env44884) = true)

def env44885 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,81,8540,65536,74031,65664,532,8541,852,648,74047,65552,9181,74299,319,74110,81,76638,8205,65830,257,64,1,340]

theorem envBound44885 : H12AffineFastState.Bounded env44885 := by
  intro p hp
  have h : env44885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44848_44885 : H12AffineEnvironment.transform 11 853 env44848 = env44885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env44848 == env44885) = true)

def env44886 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,65536,74031,65664,516,8525,836,648,74031,65536,9165,74283,303,74094,65,76622,8205,65830,257,64,1,324]

theorem envBound44886 : H12AffineFastState.Bounded env44886 := by
  intro p hp
  have h : env44886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44885_44886 : H12AffineEnvironment.transform 3 0 env44885 = env44886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44885 == env44886) = true)

theorem identity44886 : scanCanonicalize (H12AffineFastState.compose env44886 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 810) := by decide +kernel

theorem selectedBound44886 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44887 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,65,8524,810,8709,938,516,8525,836,648,8709,810,9165,8449,303,8772,65,10340,8205,524,257,64,1,324]

theorem envBound44887 : H12AffineFastState.Bounded env44887 := by
  intro p hp
  have h : env44887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44886_44887 : H12AffineEnvironment.transform 15 810 env44886 = env44887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 810 env44886 == env44887) = true)

def env44888 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,72,65,260,810,589,938,516,261,836,648,589,810,901,329,303,524,65,2092,69,524,257,64,1,324]

theorem envBound44888 : H12AffineFastState.Bounded env44888 := by
  intro p hp
  have h : env44888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44887_44888 : H12AffineEnvironment.transform 12 72 env44887 = env44888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44887 == env44888) = true)

theorem identity44888 : scanCanonicalize (H12AffineFastState.compose env44888 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44888 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44889 : List Nat := [2,4,4,0,32,64,128,256,512,320,2048,837,68,65,260,806,577,934,516,261,836,644,577,806,901,325,291,512,65,2080,69,512,257,64,1,324]

theorem envBound44889 : H12AffineFastState.Bounded env44889 := by
  intro p hp
  have h : env44889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44888_44889 : H12AffineEnvironment.transform 2 4 env44888 = env44889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44888 == env44889) = true)

theorem identity44889 : scanCanonicalize (H12AffineFastState.compose env44889 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound44889 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44890 : List Nat := [2,4,4,0,32,64,128,256,65,320,2048,260,68,65,260,359,0,487,69,261,261,197,0,359,452,325,291,65,65,2080,69,65,257,64,1,324]

theorem envBound44890 : H12AffineFastState.Bounded env44890 := by
  intro p hp
  have h : env44890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44889_44890 : H12AffineEnvironment.transform 8 65 env44889 = env44890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env44889 == env44890) = true)

theorem identity44890 : scanCanonicalize (H12AffineFastState.compose env44890 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound44890 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env44891 : List Nat := [2,4,4,0,32,64,128,134,65,198,2048,130,68,65,130,225,0,97,69,131,131,197,0,225,66,195,165,65,65,2080,69,65,135,64,1,194]

theorem envBound44891 : H12AffineFastState.Bounded env44891 := by
  intro p hp
  have h : env44891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44890_44891 : H12AffineEnvironment.transform 7 134 env44890 = env44891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env44890 == env44891) = true)

theorem identity44891 : scanCanonicalize (H12AffineFastState.compose env44891 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound44891 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44892 : List Nat := [2,4,4,0,32,64,100,98,65,34,2048,102,68,65,102,5,0,97,69,103,103,33,0,5,66,39,65,65,65,2080,69,65,99,64,1,38]

theorem envBound44892 : H12AffineFastState.Bounded env44892 := by
  intro p hp
  have h : env44892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44891_44892 : H12AffineEnvironment.transform 6 100 env44891 = env44892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env44891 == env44892) = true)

theorem identity44892 : scanCanonicalize (H12AffineFastState.compose env44892 (packedSelected [0,1,3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound44892 : packedSelected [0,1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env44893 : List Nat := [2,4,4,0,32,64,100,98,65,34,97,102,68,65,102,5,0,97,69,103,103,33,0,5,66,39,65,65,65,65,69,65,99,64,1,38]

theorem envBound44893 : H12AffineFastState.Bounded env44893 := by
  intro p hp
  have h : env44893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44892_44893 : H12AffineEnvironment.transform 10 97 env44892 = env44893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env44892 == env44893) = true)

theorem identity44893 : scanCanonicalize (H12AffineFastState.compose env44893 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound44893 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44894 : List Nat := [2,4,4,0,32,38,2,4,39,34,7,0,34,39,0,5,0,7,35,1,1,33,0,5,36,39,39,39,39,39,35,39,5,38,1,38]

theorem envBound44894 : H12AffineFastState.Bounded env44894 := by
  intro p hp
  have h : env44894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44893_44894 : H12AffineEnvironment.transform 5 38 env44893 = env44894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env44893 == env44894) = true)

theorem identity44894 : scanCanonicalize (H12AffineFastState.compose env44894 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound44894 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44895 : List Nat := [2,4,4,0,3,5,2,4,4,1,7,0,1,4,0,5,0,7,0,1,1,2,0,5,7,4,4,4,4,4,0,4,5,5,1,5]

theorem envBound44895 : H12AffineFastState.Bounded env44895 := by
  intro p hp
  have h : env44895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44894_44895 : H12AffineEnvironment.transform 4 3 env44894 = env44895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env44894 == env44895) = true)

theorem identity44895 : scanCanonicalize (H12AffineFastState.compose env44895 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44895 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env44896 : List Nat := [2,2,2,0,3,3,2,2,2,1,1,0,1,2,0,3,0,1,0,1,1,2,0,3,1,2,2,2,2,2,0,2,3,3,1,3]

theorem envBound44896 : H12AffineFastState.Bounded env44896 := by
  intro p hp
  have h : env44896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44895_44896 : H12AffineEnvironment.transform 1 2 env44895 = env44896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44895 == env44896) = true)

def env44897 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,73,65,261,810,588,938,516,260,836,648,588,810,900,328,303,525,65,2093,68,524,257,64,1,324]

theorem envBound44897 : H12AffineFastState.Bounded env44897 := by
  intro p hp
  have h : env44897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44887_44897 : H12AffineEnvironment.transform 12 73 env44887 = env44897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env44887 == env44897) = true)

theorem identity44897 : scanCanonicalize (H12AffineFastState.compose env44897 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 329) := by decide +kernel

theorem selectedBound44897 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44898 : List Nat := [2,4,8,0,32,64,128,256,329,320,2048,12,73,65,261,99,261,227,333,260,13,449,261,99,205,328,303,324,65,2093,68,325,257,64,1,324]

theorem envBound44898 : H12AffineFastState.Bounded env44898 := by
  intro p hp
  have h : env44898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44897_44898 : H12AffineEnvironment.transform 8 329 env44897 = env44898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env44897 == env44898) = true)

theorem identity44898 : scanCanonicalize (H12AffineFastState.compose env44898 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44898 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44899 : List Nat := [2,4,8,0,32,1,128,256,264,257,2048,12,8,0,261,34,261,162,268,260,13,384,261,34,140,265,303,261,0,2093,5,260,257,1,1,261]

theorem envBound44899 : H12AffineFastState.Bounded env44899 := by
  intro p hp
  have h : env44899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44898_44899 : H12AffineEnvironment.transform 5 1 env44898 = env44899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44898 == env44899) = true)

theorem identity44899 : scanCanonicalize (H12AffineFastState.compose env44899 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound44899 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44900 : List Nat := [2,4,8,0,32,1,128,256,264,257,303,12,8,0,261,34,261,162,268,260,13,384,261,34,140,265,303,261,0,258,5,260,257,1,1,261]

theorem envBound44900 : H12AffineFastState.Bounded env44900 := by
  intro p hp
  have h : env44900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44899_44900 : H12AffineEnvironment.transform 10 303 env44899 = env44900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env44899 == env44900) = true)

theorem identity44900 : scanCanonicalize (H12AffineFastState.compose env44900 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44900 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44901 : List Nat := [2,4,8,0,7,1,128,256,264,257,264,12,8,0,261,5,261,133,268,260,13,384,261,5,140,265,264,261,0,258,5,260,257,1,1,261]

theorem envBound44901 : H12AffineFastState.Bounded env44901 := by
  intro p hp
  have h : env44901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44900_44901 : H12AffineEnvironment.transform 4 7 env44900 = env44901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44900 == env44901) = true)

theorem identity44901 : scanCanonicalize (H12AffineFastState.compose env44901 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound44901 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env44902 : List Nat := [2,4,8,0,7,1,128,9,1,8,1,12,8,0,12,5,12,133,5,13,13,137,12,5,140,0,1,12,0,11,5,13,8,1,1,12]

theorem envBound44902 : H12AffineFastState.Bounded env44902 := by
  intro p hp
  have h : env44902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44901_44902 : H12AffineEnvironment.transform 7 9 env44901 = env44902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env44901 == env44902) = true)

theorem identity44902 : scanCanonicalize (H12AffineFastState.compose env44902 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44903 : List Nat := [2,3,8,0,0,1,128,9,1,8,1,11,8,0,11,2,11,130,2,10,10,137,11,2,139,0,1,11,0,11,2,10,8,1,1,11]

theorem envBound44903 : H12AffineFastState.Bounded env44903 := by
  intro p hp
  have h : env44903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44902_44903 : H12AffineEnvironment.transform 1 3 env44902 = env44903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44902 == env44903) = true)

theorem identity44903 : scanCanonicalize (H12AffineFastState.compose env44903 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound44903 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44904 : List Nat := [2,3,8,0,0,1,3,9,1,8,1,11,8,0,11,2,11,1,2,10,10,10,11,2,8,0,1,11,0,11,2,10,8,1,1,11]

theorem envBound44904 : H12AffineFastState.Bounded env44904 := by
  intro p hp
  have h : env44904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44903_44904 : H12AffineEnvironment.transform 6 3 env44903 = env44904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env44903 == env44904) = true)

theorem identity44904 : scanCanonicalize (H12AffineFastState.compose env44904 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44904 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44905 : List Nat := [2,3,3,0,0,1,3,2,1,3,1,0,3,0,0,2,0,1,2,1,1,1,0,2,3,0,1,0,0,0,2,1,3,1,1,0]

theorem envBound44905 : H12AffineFastState.Bounded env44905 := by
  intro p hp
  have h : env44905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44904_44905 : H12AffineEnvironment.transform 2 3 env44904 = env44905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44904 == env44905) = true)

theorem identity44905 : scanCanonicalize (H12AffineFastState.compose env44905 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44906 : List Nat := [1,0,0,0,0,1,0,1,1,0,1,0,0,0,0,1,0,1,1,1,1,1,0,1,0,0,1,0,0,0,1,1,0,1,1,0]

theorem envBound44906 : H12AffineFastState.Bounded env44906 := by
  intro p hp
  have h : env44906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44905_44906 : H12AffineEnvironment.transform 0 1 env44905 = env44906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44905 == env44906) = true)

def env44907 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,65536,74031,65664,517,8524,837,648,74030,65537,9164,74282,302,74095,64,76623,8205,65830,257,64,1,325]

theorem envBound44907 : H12AffineFastState.Bounded env44907 := by
  intro p hp
  have h : env44907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44885_44907 : H12AffineEnvironment.transform 3 1 env44885 = env44907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44885 == env44907) = true)

theorem identity44907 : scanCanonicalize (H12AffineFastState.compose env44907 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9058) := by decide +kernel

theorem selectedBound44907 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env44908 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,64,8525,9058,589,9186,517,8524,837,648,588,9059,9164,328,302,525,64,2093,8205,8772,257,64,1,325]

theorem envBound44908 : H12AffineFastState.Bounded env44908 := by
  intro p hp
  have h : env44908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44907_44908 : H12AffineEnvironment.transform 15 9058 env44907 = env44908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9058 env44907 == env44908) = true)

def env44909 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,72,64,261,810,589,938,517,260,837,648,588,811,900,328,302,525,64,2093,69,524,257,64,1,325]

theorem envBound44909 : H12AffineFastState.Bounded env44909 := by
  intro p hp
  have h : env44909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44908_44909 : H12AffineEnvironment.transform 12 72 env44908 = env44909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44908 == env44909) = true)

theorem identity44909 : scanCanonicalize (H12AffineFastState.compose env44909 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44909 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44910 : List Nat := [2,4,4,1,32,64,128,256,512,320,2048,836,68,64,261,806,577,934,517,260,837,644,576,807,900,324,290,513,64,2081,69,512,257,64,1,325]

theorem envBound44910 : H12AffineFastState.Bounded env44910 := by
  intro p hp
  have h : env44910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44909_44910 : H12AffineEnvironment.transform 2 4 env44909 = env44910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44909 == env44910) = true)

theorem identity44910 : scanCanonicalize (H12AffineFastState.compose env44910 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound44910 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44911 : List Nat := [2,4,4,1,32,64,128,256,65,320,2048,261,68,64,261,359,0,487,68,260,260,197,1,358,453,324,290,64,64,2081,69,65,257,64,1,325]

theorem envBound44911 : H12AffineFastState.Bounded env44911 := by
  intro p hp
  have h : env44911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44910_44911 : H12AffineEnvironment.transform 8 65 env44910 = env44911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env44910 == env44911) = true)

theorem identity44911 : scanCanonicalize (H12AffineFastState.compose env44911 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound44911 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env44912 : List Nat := [2,4,4,1,32,64,128,134,65,198,2048,131,68,64,131,225,0,97,68,130,130,197,1,224,67,194,164,64,64,2081,69,65,135,64,1,195]

theorem envBound44912 : H12AffineFastState.Bounded env44912 := by
  intro p hp
  have h : env44912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44911_44912 : H12AffineEnvironment.transform 7 134 env44911 = env44912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env44911 == env44912) = true)

theorem identity44912 : scanCanonicalize (H12AffineFastState.compose env44912 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound44912 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44913 : List Nat := [2,4,4,1,32,38,128,134,39,160,2048,131,34,38,131,135,0,7,34,130,130,163,1,134,37,164,164,38,38,2081,35,39,135,38,1,165]

theorem envBound44913 : H12AffineFastState.Bounded env44913 := by
  intro p hp
  have h : env44913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44912_44913 : H12AffineEnvironment.transform 5 38 env44912 = env44913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env44912 == env44913) = true)

theorem identity44913 : scanCanonicalize (H12AffineFastState.compose env44913 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound44913 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env44914 : List Nat := [2,4,4,1,32,38,128,134,39,160,130,131,34,38,131,135,0,7,34,130,130,163,1,134,37,164,164,38,38,163,35,39,135,38,1,165]

theorem envBound44914 : H12AffineFastState.Bounded env44914 := by
  intro p hp
  have h : env44914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44913_44914 : H12AffineEnvironment.transform 10 130 env44913 = env44914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env44913 == env44914) = true)

theorem identity44914 : scanCanonicalize (H12AffineFastState.compose env44914 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound44914 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44915 : List Nat := [2,4,4,1,6,0,128,134,1,134,130,131,4,0,131,135,0,7,4,130,130,133,1,134,3,130,130,0,0,133,5,1,135,0,1,131]

theorem envBound44915 : H12AffineFastState.Bounded env44915 := by
  intro p hp
  have h : env44915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44914_44915 : H12AffineEnvironment.transform 4 6 env44914 = env44915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env44914 == env44915) = true)

theorem identity44915 : scanCanonicalize (H12AffineFastState.compose env44915 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound44915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44916 : List Nat := [2,4,4,1,6,0,3,5,1,5,1,0,4,0,0,4,0,7,4,1,1,6,1,5,3,1,1,0,0,6,5,1,4,0,1,0]

theorem envBound44916 : H12AffineFastState.Bounded env44916 := by
  intro p hp
  have h : env44916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44915_44916 : H12AffineEnvironment.transform 6 3 env44915 = env44916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env44915 == env44916) = true)

theorem identity44916 : scanCanonicalize (H12AffineFastState.compose env44916 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44917 : List Nat := [2,0,0,1,2,0,3,1,1,1,1,0,0,0,0,0,0,3,0,1,1,2,1,1,3,1,1,0,0,2,1,1,0,0,1,0]

theorem envBound44917 : H12AffineFastState.Bounded env44917 := by
  intro p hp
  have h : env44917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44916_44917 : H12AffineEnvironment.transform 1 0 env44916 = env44917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44916 == env44917) = true)

def env44918 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,73,64,260,811,589,939,517,261,837,648,588,810,901,328,302,525,64,2093,68,525,257,64,1,325]

theorem envBound44918 : H12AffineFastState.Bounded env44918 := by
  intro p hp
  have h : env44918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44908_44918 : H12AffineEnvironment.transform 12 73 env44908 = env44918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env44908 == env44918) = true)

theorem identity44918 : scanCanonicalize (H12AffineFastState.compose env44918 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 329) := by decide +kernel

theorem selectedBound44918 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44919 : List Nat := [2,4,8,1,32,64,128,256,329,320,2048,13,73,64,260,98,260,226,332,261,12,449,261,99,204,328,302,324,64,2093,68,324,257,64,1,325]

theorem envBound44919 : H12AffineFastState.Bounded env44919 := by
  intro p hp
  have h : env44919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44918_44919 : H12AffineEnvironment.transform 8 329 env44918 = env44919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env44918 == env44919) = true)

theorem identity44919 : scanCanonicalize (H12AffineFastState.compose env44919 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44919 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44920 : List Nat := [2,4,8,1,32,0,128,256,265,256,2048,13,9,0,260,34,260,162,268,261,12,385,261,35,140,264,302,260,0,2093,4,260,257,0,1,261]

theorem envBound44920 : H12AffineFastState.Bounded env44920 := by
  intro p hp
  have h : env44920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44919_44920 : H12AffineEnvironment.transform 5 0 env44919 = env44920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44919 == env44920) = true)

theorem identity44920 : scanCanonicalize (H12AffineFastState.compose env44920 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound44920 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44921 : List Nat := [2,4,8,1,32,0,128,256,265,256,42,13,9,0,260,34,260,162,268,261,12,385,261,35,140,264,302,260,0,7,4,260,257,0,1,261]

theorem envBound44921 : H12AffineFastState.Bounded env44921 := by
  intro p hp
  have h : env44921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44920_44921 : H12AffineEnvironment.transform 10 42 env44920 = env44921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env44920 == env44921) = true)

theorem identity44921 : scanCanonicalize (H12AffineFastState.compose env44921 (packedSelected [0,1,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound44921 : packedSelected [0,1,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44922 : List Nat := [2,4,8,1,32,0,40,256,265,256,42,13,9,0,260,34,260,10,268,261,12,297,261,35,36,264,302,260,0,7,4,260,257,0,1,261]

theorem envBound44922 : H12AffineFastState.Bounded env44922 := by
  intro p hp
  have h : env44922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44921_44922 : H12AffineEnvironment.transform 6 40 env44921 = env44922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env44921 == env44922) = true)

theorem identity44922 : scanCanonicalize (H12AffineFastState.compose env44922 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound44922 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44923 : List Nat := [2,4,8,1,12,0,4,256,265,256,6,13,9,0,260,14,260,10,268,261,12,261,261,15,8,264,258,260,0,7,4,260,257,0,1,261]

theorem envBound44923 : H12AffineFastState.Bounded env44923 := by
  intro p hp
  have h : env44923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44922_44923 : H12AffineEnvironment.transform 4 12 env44922 = env44923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env44922 == env44923) = true)

theorem identity44923 : scanCanonicalize (H12AffineFastState.compose env44923 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44923 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44924 : List Nat := [2,3,8,1,11,0,3,256,265,256,1,10,9,0,259,9,259,10,267,258,11,258,258,8,8,264,258,259,0,0,3,259,257,0,1,258]

theorem envBound44924 : H12AffineFastState.Bounded env44924 := by
  intro p hp
  have h : env44924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44923_44924 : H12AffineEnvironment.transform 1 3 env44923 = env44924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44923 == env44924) = true)

theorem identity44924 : scanCanonicalize (H12AffineFastState.compose env44924 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound44924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44925 : List Nat := [2,3,8,1,11,0,3,3,10,3,1,10,9,0,0,9,0,10,8,1,11,1,1,8,8,11,1,0,0,0,3,0,2,0,1,1]

theorem envBound44925 : H12AffineFastState.Bounded env44925 := by
  intro p hp
  have h : env44925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44924_44925 : H12AffineEnvironment.transform 7 3 env44924 = env44925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env44924 == env44925) = true)

def env44926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4097,5277,74047,66896,13768,78894,1150,74814,1297,81227,8205,65830,257,1280,1345,5953]

theorem envBound44926 : H12AffineFastState.Bounded env44926 := by
  intro p hp
  have h : env44926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44846_44926 : H12AffineEnvironment.transform 17 65665 env44846 = env44926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44846 == env44926) = true)

theorem identity44926 : scanCanonicalize (H12AffineFastState.compose env44926 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound44926 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,65536,74863,65665,321,8541,1,1181,74047,66896,9672,74798,1150,74814,1297,77131,8205,65830,257,1280,1345,1857]

theorem envBound44927 : H12AffineFastState.Bounded env44927 := by
  intro p hp
  have h : env44927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44926_44927 : H12AffineEnvironment.transform 11 0 env44926 = env44927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44926 == env44927) = true)

def env44928 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8540,65536,74031,65665,321,8541,1,477,74047,65552,8328,74094,318,74110,81,75787,8205,65830,257,64,1,513]

theorem envBound44928 : H12AffineFastState.Bounded env44928 := by
  intro p hp
  have h : env44928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44927_44928 : H12AffineEnvironment.transform 9 320 env44927 = env44928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44927 == env44928) = true)

theorem identity44928 : scanCanonicalize (H12AffineFastState.compose env44928 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44928 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44929 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8192,81,8216,65536,73835,65665,5,8217,1,153,73851,65552,8328,73770,122,73786,81,75787,8205,65634,69,64,1,513]

theorem envBound44929 : H12AffineFastState.Bounded env44929 := by
  intro p hp
  have h : env44929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44928_44929 : H12AffineEnvironment.transform 7 68 env44928 = env44929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44928 == env44929) = true)

theorem identity44929 : scanCanonicalize (H12AffineFastState.compose env44929 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound44929 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44930 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8192,81,8216,115,8216,242,5,8217,1,153,8200,99,8328,8281,122,8265,81,10360,8205,17,69,64,1,513]

theorem envBound44930 : H12AffineFastState.Bounded env44930 := by
  intro p hp
  have h : env44930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44929_44930 : H12AffineEnvironment.transform 15 115 env44929 = env44930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env44929 == env44930) = true)

theorem identity44930 : scanCanonicalize (H12AffineFastState.compose env44930 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound44930 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44931 : List Nat := [2,4,8,16,32,0,128,4,512,4,2048,0,8192,17,8216,51,8216,178,5,8217,1,153,8200,35,8328,8217,58,8201,17,10296,8205,17,5,0,1,513]

theorem envBound44931 : H12AffineFastState.Bounded env44931 := by
  intro p hp
  have h : env44931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44930_44931 : H12AffineEnvironment.transform 5 0 env44930 = env44931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env44930 == env44931) = true)

theorem identity44931 : scanCanonicalize (H12AffineFastState.compose env44931 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound44931 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env44932 : List Nat := [2,4,8,16,32,0,128,4,512,4,2048,0,656,17,648,51,648,178,5,649,1,153,664,35,536,649,58,665,17,2728,669,17,5,0,1,513]

theorem envBound44932 : H12AffineFastState.Bounded env44932 := by
  intro p hp
  have h : env44932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44931_44932 : H12AffineEnvironment.transform 12 656 env44931 = env44932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env44931 == env44932) = true)

theorem identity44932 : scanCanonicalize (H12AffineFastState.compose env44932 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44932 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env44933 : List Nat := [2,4,8,16,32,0,128,4,48,4,2048,0,160,17,184,51,184,178,5,185,1,153,168,35,40,185,58,169,17,2200,173,17,5,0,1,49]

theorem envBound44933 : H12AffineFastState.Bounded env44933 := by
  intro p hp
  have h : env44933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44932_44933 : H12AffineEnvironment.transform 8 48 env44932 = env44933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44932 == env44933) = true)

theorem identity44933 : scanCanonicalize (H12AffineFastState.compose env44933 (packedSelected [0,2,3,5,7,8,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44933 : packedSelected [0,2,3,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env44934 : List Nat := [2,4,8,16,7,0,128,4,23,4,2048,0,135,17,159,20,159,149,5,158,1,153,143,4,15,158,29,142,17,2200,138,17,5,0,1,22]

theorem envBound44934 : H12AffineFastState.Bounded env44934 := by
  intro p hp
  have h : env44934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44933_44934 : H12AffineEnvironment.transform 4 7 env44933 = env44934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44933 == env44934) = true)

theorem identity44934 : scanCanonicalize (H12AffineFastState.compose env44934 (packedSelected [0,1,5,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44934 : packedSelected [0,1,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env44935 : List Nat := [2,4,8,1,7,0,128,4,6,4,2048,0,135,0,142,5,142,132,5,143,1,136,143,4,15,143,12,142,0,2185,138,0,5,0,1,7]

theorem envBound44935 : H12AffineFastState.Bounded env44935 := by
  intro p hp
  have h : env44935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44934_44935 : H12AffineEnvironment.transform 3 1 env44934 = env44935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44934 == env44935) = true)

theorem identity44935 : scanCanonicalize (H12AffineFastState.compose env44935 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44936 : List Nat := [2,3,8,1,0,0,128,3,1,3,2048,0,128,0,137,2,137,131,2,136,1,136,136,3,8,136,11,137,0,2185,138,0,2,0,1,0]

theorem envBound44936 : H12AffineFastState.Bounded env44936 := by
  intro p hp
  have h : env44936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44935_44936 : H12AffineEnvironment.transform 1 3 env44935 = env44936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44935 == env44936) = true)

theorem identity44936 : scanCanonicalize (H12AffineFastState.compose env44936 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound44936 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44937 : List Nat := [2,3,8,1,0,0,0,3,1,3,2048,0,0,0,9,2,9,3,2,8,1,8,8,3,8,8,11,9,0,2057,10,0,2,0,1,0]

theorem envBound44937 : H12AffineFastState.Bounded env44937 := by
  intro p hp
  have h : env44937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44936_44937 : H12AffineEnvironment.transform 6 0 env44936 = env44937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env44936 == env44937) = true)

theorem identity44937 : scanCanonicalize (H12AffineFastState.compose env44937 (packedSelected [0,3] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound44937 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44938 : List Nat := [2,3,8,1,0,0,0,3,1,3,8,0,0,0,9,2,9,3,2,8,1,8,8,3,8,8,11,9,0,1,10,0,2,0,1,0]

theorem envBound44938 : H12AffineFastState.Bounded env44938 := by
  intro p hp
  have h : env44938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44937_44938 : H12AffineEnvironment.transform 10 8 env44937 = env44938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env44937 == env44938) = true)

theorem identity44938 : scanCanonicalize (H12AffineFastState.compose env44938 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44939 : List Nat := [2,3,2,1,0,0,0,3,1,3,2,0,0,0,3,2,3,3,2,2,1,2,2,3,2,2,1,3,0,1,0,0,2,0,1,0]

theorem envBound44939 : H12AffineFastState.Bounded env44939 := by
  intro p hp
  have h : env44939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44938_44939 : H12AffineEnvironment.transform 2 2 env44938 = env44939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44938 == env44939) = true)

def env44940 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,65536,74030,65665,321,8541,1,476,74047,65553,8329,74095,319,74111,80,75786,8205,65830,257,65,0,512]

theorem envBound44940 : H12AffineFastState.Bounded env44940 := by
  intro p hp
  have h : env44940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44927_44940 : H12AffineEnvironment.transform 9 321 env44927 = env44940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44927 == env44940) = true)

theorem identity44940 : scanCanonicalize (H12AffineFastState.compose env44940 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound44940 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44941 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,8251,277,8378,321,8541,1,476,260,8234,8329,340,319,324,80,2097,8205,8477,257,65,0,512]

theorem envBound44941 : H12AffineFastState.Bounded env44941 := by
  intro p hp
  have h : env44941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44940_44941 : H12AffineEnvironment.transform 15 8251 env44940 = env44941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env44940 == env44941) = true)

theorem identity44941 : scanCanonicalize (H12AffineFastState.compose env44941 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44941 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44942 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,8461,8251,277,8378,272,8460,1,397,260,8234,8329,261,319,277,1,2097,8205,8477,257,16,0,512]

theorem envBound44942 : H12AffineFastState.Bounded env44942 := by
  intro p hp
  have h : env44942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44941_44942 : H12AffineEnvironment.transform 5 17 env44941 = env44942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44941 == env44942) = true)

theorem identity44942 : scanCanonicalize (H12AffineFastState.compose env44942 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound44942 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env44943 : List Nat := [2,4,8,16,32,17,128,256,512,272,136,0,8192,1,8461,8251,277,8378,272,8460,1,397,260,8234,8329,261,319,277,1,185,8205,8477,257,16,0,512]

theorem envBound44943 : H12AffineFastState.Bounded env44943 := by
  intro p hp
  have h : env44943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44942_44943 : H12AffineEnvironment.transform 10 136 env44942 = env44943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env44942 == env44943) = true)

theorem identity44943 : scanCanonicalize (H12AffineFastState.compose env44943 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound44943 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env44944 : List Nat := [2,4,8,16,32,17,128,256,512,272,136,0,145,1,412,170,277,43,272,413,1,397,260,187,24,261,319,277,1,185,156,396,257,16,0,512]

theorem envBound44944 : H12AffineFastState.Bounded env44944 := by
  intro p hp
  have h : env44944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44943_44944 : H12AffineEnvironment.transform 12 145 env44943 = env44944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env44943 == env44944) = true)

theorem identity44944 : scanCanonicalize (H12AffineFastState.compose env44944 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound44944 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env44945 : List Nat := [2,4,8,16,32,17,128,256,412,272,136,0,145,1,412,170,277,43,272,413,1,397,260,187,24,261,319,277,1,185,156,396,257,16,0,412]

theorem envBound44945 : H12AffineFastState.Bounded env44945 := by
  intro p hp
  have h : env44945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44944_44945 : H12AffineEnvironment.transform 8 412 env44944 = env44945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env44944 == env44945) = true)

theorem identity44945 : scanCanonicalize (H12AffineFastState.compose env44945 (packedSelected [5,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound44945 : packedSelected [5,7] rootPS < 2^1333 := by decide +kernel

def env44946 : List Nat := [2,4,8,16,32,17,34,256,318,272,42,0,51,1,318,8,277,43,272,319,1,303,260,25,24,261,319,277,1,27,62,302,257,16,0,318]

theorem envBound44946 : H12AffineFastState.Bounded env44946 := by
  intro p hp
  have h : env44946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44945_44946 : H12AffineEnvironment.transform 6 34 env44945 = env44946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env44945 == env44946) = true)

theorem identity44946 : scanCanonicalize (H12AffineFastState.compose env44946 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44946 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44947 : List Nat := [2,4,8,16,11,17,9,256,277,272,1,0,24,1,277,8,277,0,272,276,1,260,260,25,24,261,276,277,1,27,21,261,257,16,0,277]

theorem envBound44947 : H12AffineFastState.Bounded env44947 := by
  intro p hp
  have h : env44947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44946_44947 : H12AffineEnvironment.transform 4 11 env44946 = env44947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44946 == env44947) = true)

def env44948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123165,28888,78895,385202,90415,1296,96346,25884,82999,257,1281,1345,21073]

theorem envBound44948 : H12AffineFastState.Bounded env44948 := by
  intro p hp
  have h : env44948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44713_44948 : H12AffineEnvironment.transform 18 21585 env44713 = env44948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env44713 == env44948) = true)

theorem identity44948 : scanCanonicalize (H12AffineFastState.compose env44948 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound44948 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4097,17612,91182,87297,28888,78895,349358,90415,1296,96346,25884,82999,257,1281,1345,21073]

theorem envBound44949 : H12AffineFastState.Bounded env44949 := by
  intro p hp
  have h : env44949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44948_44949 : H12AffineEnvironment.transform 14 13340 env44948 = env44949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env44948 == env44949) = true)

def env44950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4097,476,74046,69649,13768,78895,332222,74815,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound44950 : H12AffineFastState.Bounded env44950 := by
  intro p hp
  have h : env44950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44949_44950 : H12AffineEnvironment.transform 13 1296 env44949 = env44950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44949 == env44950) = true)

def env44951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4097,476,74046,69649,13768,78895,4414,74815,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound44951 : H12AffineFastState.Bounded env44951 := by
  intro p hp
  have h : env44951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44950_44951 : H12AffineEnvironment.transform 17 65664 env44950 = env44951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44950 == env44951) = true)

theorem identity44951 : scanCanonicalize (H12AffineFastState.compose env44951 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound44951 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4097,476,70710,69649,192,65831,4414,69943,1296,67650,5380,65831,257,1281,1345,5953]

theorem envBound44952 : H12AffineFastState.Bounded env44952 := by
  intro p hp
  have h : env44952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44951_44952 : H12AffineEnvironment.transform 12 5384 env44951 = env44952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env44951 == env44952) = true)

def env44953 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4097,476,70710,69649,192,65831,4414,69943,1296,67650,5380,65831,257,1281,1345,5141]

theorem envBound44953 : H12AffineFastState.Bounded env44953 := by
  intro p hp
  have h : env44953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44952_44953 : H12AffineEnvironment.transform 8 340 env44952 = env44953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env44952 == env44953) = true)

def env44954 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,276,65536,65895,65664,321,277,1,476,66614,65553,192,65831,318,65847,1296,67650,1284,65831,257,1281,1345,1045]

theorem envBound44954 : H12AffineFastState.Bounded env44954 := by
  intro p hp
  have h : env44954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44953_44954 : H12AffineEnvironment.transform 11 0 env44953 = env44954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44953 == env44954) = true)

theorem identity44954 : scanCanonicalize (H12AffineFastState.compose env44954 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44954 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44955 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1296,276,114,277,242,321,277,1,476,1092,99,192,341,318,325,1296,2096,1284,341,257,1281,1345,1045]

theorem envBound44955 : H12AffineFastState.Bounded env44955 := by
  intro p hp
  have h : env44955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44954_44955 : H12AffineEnvironment.transform 15 114 env44954 = env44955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44954 == env44955) = true)

theorem identity44955 : scanCanonicalize (H12AffineFastState.compose env44955 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1255) := by decide +kernel

theorem selectedBound44955 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44956 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1255,0,1288,1296,276,114,277,242,321,277,1,476,1092,99,192,341,318,325,1296,1239,1284,341,257,1281,1345,1045]

theorem envBound44956 : H12AffineFastState.Bounded env44956 := by
  intro p hp
  have h : env44956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44955_44956 : H12AffineEnvironment.transform 10 1255 env44955 = env44956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1255 env44955 == env44956) = true)

theorem identity44956 : scanCanonicalize (H12AffineFastState.compose env44956 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44956 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env44957 : List Nat := [2,4,8,16,32,64,128,21,65,1024,1255,0,1053,1029,1,114,0,242,84,0,1,201,1092,99,192,64,43,80,1029,1239,1041,64,20,1044,1108,1045]

theorem envBound44957 : H12AffineFastState.Bounded env44957 := by
  intro p hp
  have h : env44957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44956_44957 : H12AffineEnvironment.transform 7 21 env44956 = env44957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44956 == env44957) = true)

theorem identity44957 : scanCanonicalize (H12AffineFastState.compose env44957 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 187) := by decide +kernel

theorem selectedBound44957 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44958 : List Nat := [2,4,8,16,32,64,128,21,65,187,92,0,166,190,1,114,0,242,84,0,1,201,255,99,192,64,43,80,190,108,170,64,20,175,239,174]

theorem envBound44958 : H12AffineFastState.Bounded env44958 := by
  intro p hp
  have h : env44958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44957_44958 : H12AffineEnvironment.transform 9 187 env44957 = env44958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 187 env44957 == env44958) = true)

theorem identity44958 : scanCanonicalize (H12AffineFastState.compose env44958 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 117) := by decide +kernel

theorem selectedBound44958 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env44959 : List Nat := [2,4,8,16,32,64,117,21,65,78,92,0,83,75,1,114,0,7,84,0,1,60,10,99,53,64,43,80,75,108,95,64,20,90,26,91]

theorem envBound44959 : H12AffineFastState.Bounded env44959 := by
  intro p hp
  have h : env44959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44958_44959 : H12AffineEnvironment.transform 6 117 env44958 = env44959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 117 env44958 == env44959) = true)

theorem identity44959 : scanCanonicalize (H12AffineFastState.compose env44959 (packedSelected [3,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44959 : packedSelected [3,10,12] rootPS < 2^1333 := by decide +kernel

def env44960 : List Nat := [2,4,8,16,7,64,82,21,65,78,92,0,83,75,1,85,0,7,84,0,1,27,10,68,18,64,12,80,75,75,95,64,20,90,26,91]

theorem envBound44960 : H12AffineFastState.Bounded env44960 := by
  intro p hp
  have h : env44960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44959_44960 : H12AffineEnvironment.transform 4 7 env44959 = env44960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44959 == env44960) = true)

theorem identity44960 : scanCanonicalize (H12AffineFastState.compose env44960 (packedSelected [1,2,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44960 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44961 : List Nat := [2,2,8,16,1,64,82,19,65,72,90,0,83,75,1,83,0,1,82,0,1,27,10,66,18,64,10,80,75,75,89,64,18,90,26,91]

theorem envBound44961 : H12AffineFastState.Bounded env44961 := by
  intro p hp
  have h : env44961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44960_44961 : H12AffineEnvironment.transform 1 2 env44960 = env44961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44960 == env44961) = true)

theorem identity44961 : scanCanonicalize (H12AffineFastState.compose env44961 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound44961 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44962 : List Nat := [2,2,8,16,1,27,9,19,26,19,1,0,8,16,1,8,0,1,9,0,1,27,10,25,18,27,10,11,16,16,2,27,18,1,26,0]

theorem envBound44962 : H12AffineFastState.Bounded env44962 := by
  intro p hp
  have h : env44962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44961_44962 : H12AffineEnvironment.transform 5 27 env44961 = env44962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env44961 == env44962) = true)

theorem identity44962 : scanCanonicalize (H12AffineFastState.compose env44962 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44962 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44963 : List Nat := [2,2,8,10,1,1,9,9,0,9,1,0,8,10,1,8,0,1,9,0,1,1,10,3,8,1,10,11,10,10,2,1,8,1,0,0]

theorem envBound44963 : H12AffineFastState.Bounded env44963 := by
  intro p hp
  have h : env44963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44962_44963 : H12AffineEnvironment.transform 3 10 env44962 = env44963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44962 == env44963) = true)

theorem identity44963 : scanCanonicalize (H12AffineFastState.compose env44963 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44964 : List Nat := [2,2,2,0,1,1,3,3,0,3,1,0,2,0,1,2,0,1,3,0,1,1,0,3,2,1,0,1,0,0,2,1,2,1,0,0]

theorem envBound44964 : H12AffineFastState.Bounded env44964 := by
  intro p hp
  have h : env44964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44963_44964 : H12AffineEnvironment.transform 2 2 env44963 = env44964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44963 == env44964) = true)

def env44965 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,276,65536,65894,65664,320,277,0,476,66615,65552,192,65831,319,65846,1296,67650,1285,65831,257,1281,1345,1044]

theorem envBound44965 : H12AffineFastState.Bounded env44965 := by
  intro p hp
  have h : env44965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44953_44965 : H12AffineEnvironment.transform 11 1 env44953 = env44965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env44953 == env44965) = true)

theorem identity44965 : scanCanonicalize (H12AffineFastState.compose env44965 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound44965 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44966 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1296,276,1331,1109,1459,320,277,0,476,260,1315,192,1044,319,1029,1296,3441,1285,1044,257,1281,1345,1044]

theorem envBound44966 : H12AffineFastState.Bounded env44966 := by
  intro p hp
  have h : env44966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44965_44966 : H12AffineEnvironment.transform 15 1331 env44965 = env44966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env44965 == env44966) = true)

theorem identity44966 : scanCanonicalize (H12AffineFastState.compose env44966 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound44966 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env44967 : List Nat := [2,4,8,16,32,64,128,256,340,1024,91,1,1289,1296,276,1331,1109,1459,320,277,0,476,260,1315,192,1044,319,1029,1296,1322,1285,1044,257,1281,1345,1044]

theorem envBound44967 : H12AffineFastState.Bounded env44967 := by
  intro p hp
  have h : env44967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44966_44967 : H12AffineEnvironment.transform 10 91 env44966 = env44967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env44966 == env44967) = true)

theorem identity44967 : scanCanonicalize (H12AffineFastState.compose env44967 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44967 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44968 : List Nat := [2,4,8,16,32,64,128,256,340,4,91,1,269,276,276,311,81,439,320,277,0,476,260,295,192,16,319,1,276,302,257,16,257,261,325,16]

theorem envBound44968 : H12AffineFastState.Bounded env44968 := by
  intro p hp
  have h : env44968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44967_44968 : H12AffineEnvironment.transform 9 4 env44967 = env44968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44967 == env44968) = true)

theorem identity44968 : scanCanonicalize (H12AffineFastState.compose env44968 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44968 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env44969 : List Nat := [2,4,8,11,32,64,128,256,335,4,64,1,269,271,271,300,74,428,320,270,0,455,260,295,192,11,292,1,271,302,257,11,257,261,325,11]

theorem envBound44969 : H12AffineFastState.Bounded env44969 := by
  intro p hp
  have h : env44969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44968_44969 : H12AffineEnvironment.transform 3 11 env44968 = env44969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44968 == env44969) = true)

theorem identity44969 : scanCanonicalize (H12AffineFastState.compose env44969 (packedSelected [0,5,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound44969 : packedSelected [0,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44970 : List Nat := [2,4,8,11,32,64,5,256,335,4,64,1,269,271,271,300,74,297,320,270,0,322,260,295,69,11,292,1,271,302,257,11,257,261,325,11]

theorem envBound44970 : H12AffineFastState.Bounded env44970 := by
  intro p hp
  have h : env44970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44969_44970 : H12AffineEnvironment.transform 6 5 env44969 = env44970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env44969 == env44970) = true)

theorem identity44970 : scanCanonicalize (H12AffineFastState.compose env44970 (packedSelected [0,2,3,7,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound44970 : packedSelected [0,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env44971 : List Nat := [2,4,8,11,32,64,5,41,102,4,64,1,36,38,38,5,74,0,105,39,0,107,45,14,69,11,13,1,38,7,40,11,40,44,108,11]

theorem envBound44971 : H12AffineFastState.Bounded env44971 := by
  intro p hp
  have h : env44971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44970_44971 : H12AffineEnvironment.transform 7 41 env44970 = env44971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env44970 == env44971) = true)

theorem identity44971 : scanCanonicalize (H12AffineFastState.compose env44971 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44971 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44972 : List Nat := [2,3,8,11,32,64,2,41,97,3,64,1,35,33,33,2,74,0,105,32,0,107,42,9,66,11,10,1,33,0,40,11,40,43,107,11]

theorem envBound44972 : H12AffineFastState.Bounded env44972 := by
  intro p hp
  have h : env44972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44971_44972 : H12AffineEnvironment.transform 1 3 env44971 = env44972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44971 == env44972) = true)

theorem identity44972 : scanCanonicalize (H12AffineFastState.compose env44972 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44972 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44973 : List Nat := [2,3,8,11,0,64,2,9,65,3,64,1,3,1,1,2,74,0,73,0,0,75,10,9,66,11,10,1,1,0,8,11,8,11,75,11]

theorem envBound44973 : H12AffineFastState.Bounded env44973 := by
  intro p hp
  have h : env44973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44972_44973 : H12AffineEnvironment.transform 4 0 env44972 = env44973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44972 == env44973) = true)

def env44974 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1296,276,65536,69991,65664,4417,277,4097,476,70710,69649,192,65831,4414,69943,1296,67650,5380,65831,257,1281,1345,5140]

theorem envBound44974 : H12AffineFastState.Bounded env44974 := by
  intro p hp
  have h : env44974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44952_44974 : H12AffineEnvironment.transform 8 341 env44952 = env44974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env44952 == env44974) = true)

def env44975 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,276,65536,65895,65664,321,277,1,476,66614,65553,192,65831,318,65847,1296,67650,1284,65831,257,1281,1345,1044]

theorem envBound44975 : H12AffineFastState.Bounded env44975 := by
  intro p hp
  have h : env44975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44974_44975 : H12AffineEnvironment.transform 11 0 env44974 = env44975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44974 == env44975) = true)

theorem identity44975 : scanCanonicalize (H12AffineFastState.compose env44975 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44975 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44976 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1296,276,114,277,242,321,277,1,476,1092,99,192,341,318,325,1296,2096,1284,341,257,1281,1345,1044]

theorem envBound44976 : H12AffineFastState.Bounded env44976 := by
  intro p hp
  have h : env44976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44975_44976 : H12AffineEnvironment.transform 15 114 env44975 = env44976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44975 == env44976) = true)

theorem identity44976 : scanCanonicalize (H12AffineFastState.compose env44976 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1254) := by decide +kernel

theorem selectedBound44976 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44977 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1254,0,1288,1296,276,114,277,242,321,277,1,476,1092,99,192,341,318,325,1296,1238,1284,341,257,1281,1345,1044]

theorem envBound44977 : H12AffineFastState.Bounded env44977 := by
  intro p hp
  have h : env44977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44976_44977 : H12AffineEnvironment.transform 10 1254 env44976 = env44977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1254 env44976 == env44977) = true)

theorem identity44977 : scanCanonicalize (H12AffineFastState.compose env44977 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44977 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env44978 : List Nat := [2,4,8,16,32,64,128,21,64,1024,1254,0,1053,1029,1,114,0,242,84,0,1,201,1092,99,192,64,43,80,1029,1238,1041,64,20,1044,1108,1044]

theorem envBound44978 : H12AffineFastState.Bounded env44978 := by
  intro p hp
  have h : env44978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44977_44978 : H12AffineEnvironment.transform 7 21 env44977 = env44978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44977 == env44978) = true)

theorem identity44978 : scanCanonicalize (H12AffineFastState.compose env44978 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound44978 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44979 : List Nat := [2,4,8,16,32,64,111,21,64,1024,1033,0,1053,1029,1,114,0,29,84,0,1,38,1092,99,47,64,43,80,1029,1081,1041,64,20,1044,1108,1044]

theorem envBound44979 : H12AffineFastState.Bounded env44979 := by
  intro p hp
  have h : env44979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44978_44979 : H12AffineEnvironment.transform 6 111 env44978 = env44979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env44978 == env44979) = true)

theorem identity44979 : scanCanonicalize (H12AffineFastState.compose env44979 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44979 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env44980 : List Nat := [2,4,8,10,32,64,111,15,64,1024,1033,0,1031,1029,1,104,0,7,78,0,1,38,1092,99,47,64,43,74,1029,1059,1035,64,14,1038,1102,1038]

theorem envBound44980 : H12AffineFastState.Bounded env44980 := by
  intro p hp
  have h : env44980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44979_44980 : H12AffineEnvironment.transform 3 10 env44979 = env44980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44979 == env44980) = true)

theorem identity44980 : scanCanonicalize (H12AffineFastState.compose env44980 (packedSelected [0,3,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound44980 : packedSelected [0,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44981 : List Nat := [2,4,8,10,32,38,9,15,38,1024,1033,0,1031,1029,1,14,0,7,40,0,1,38,1058,5,47,38,43,44,1029,1059,1035,38,14,1038,1064,1038]

theorem envBound44981 : H12AffineFastState.Bounded env44981 := by
  intro p hp
  have h : env44981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44980_44981 : H12AffineEnvironment.transform 5 38 env44980 = env44981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env44980 == env44981) = true)

theorem identity44981 : scanCanonicalize (H12AffineFastState.compose env44981 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44981 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env44982 : List Nat := [2,4,8,10,7,1,9,15,1,1024,1033,0,1031,1029,1,14,0,7,15,0,1,1,1029,5,8,1,12,11,1029,1028,1035,1,14,1038,1039,1038]

theorem envBound44982 : H12AffineFastState.Bounded env44982 := by
  intro p hp
  have h : env44982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44981_44982 : H12AffineEnvironment.transform 4 7 env44981 = env44982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44981 == env44982) = true)

def env44983 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,276,65536,65894,65664,320,277,0,476,66615,65552,192,65831,319,65846,1296,67650,1285,65831,257,1281,1345,1045]

theorem envBound44983 : H12AffineFastState.Bounded env44983 := by
  intro p hp
  have h : env44983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44974_44983 : H12AffineEnvironment.transform 11 1 env44974 = env44983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env44974 == env44983) = true)

theorem identity44983 : scanCanonicalize (H12AffineFastState.compose env44983 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound44983 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44984 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1296,276,1331,1109,1459,320,277,0,476,260,1315,192,1044,319,1029,1296,3441,1285,1044,257,1281,1345,1045]

theorem envBound44984 : H12AffineFastState.Bounded env44984 := by
  intro p hp
  have h : env44984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44983_44984 : H12AffineEnvironment.transform 15 1331 env44983 = env44984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env44983 == env44984) = true)

theorem identity44984 : scanCanonicalize (H12AffineFastState.compose env44984 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound44984 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env44985 : List Nat := [2,4,8,16,32,64,128,256,341,1024,90,1,1289,1296,276,1331,1109,1459,320,277,0,476,260,1315,192,1044,319,1029,1296,1323,1285,1044,257,1281,1345,1045]

theorem envBound44985 : H12AffineFastState.Bounded env44985 := by
  intro p hp
  have h : env44985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44984_44985 : H12AffineEnvironment.transform 10 90 env44984 = env44985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env44984 == env44985) = true)

theorem identity44985 : scanCanonicalize (H12AffineFastState.compose env44985 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44985 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44986 : List Nat := [2,4,8,16,32,64,128,256,341,4,90,1,269,276,276,311,81,439,320,277,0,476,260,295,192,16,319,1,276,303,257,16,257,261,325,17]

theorem envBound44986 : H12AffineFastState.Bounded env44986 := by
  intro p hp
  have h : env44986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44985_44986 : H12AffineEnvironment.transform 9 4 env44985 = env44986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44985 == env44986) = true)

theorem identity44986 : scanCanonicalize (H12AffineFastState.compose env44986 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44986 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env44987 : List Nat := [2,4,8,11,32,64,128,256,334,4,65,1,269,271,271,300,74,428,320,270,0,455,260,295,192,11,292,1,271,303,257,11,257,261,325,10]

theorem envBound44987 : H12AffineFastState.Bounded env44987 := by
  intro p hp
  have h : env44987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44986_44987 : H12AffineEnvironment.transform 3 11 env44986 = env44987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44986 == env44987) = true)

theorem identity44987 : scanCanonicalize (H12AffineFastState.compose env44987 (packedSelected [0,5,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound44987 : packedSelected [0,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44988 : List Nat := [2,4,8,11,32,64,128,138,196,4,65,1,135,133,133,166,74,38,202,132,0,77,142,173,192,11,174,1,133,165,139,11,139,143,207,10]

theorem envBound44988 : H12AffineFastState.Bounded env44988 := by
  intro p hp
  have h : env44988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44987_44988 : H12AffineEnvironment.transform 7 138 env44987 = env44988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env44987 == env44988) = true)

theorem identity44988 : scanCanonicalize (H12AffineFastState.compose env44988 (packedSelected [0,2,3,7,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound44988 : packedSelected [0,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env44989 : List Nat := [2,4,8,11,6,64,128,138,196,4,65,1,135,133,133,128,74,0,202,132,0,77,142,139,192,11,136,1,133,131,139,11,139,143,207,10]

theorem envBound44989 : H12AffineFastState.Bounded env44989 := by
  intro p hp
  have h : env44989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44988_44989 : H12AffineEnvironment.transform 4 6 env44988 = env44989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env44988 == env44989) = true)

theorem identity44989 : scanCanonicalize (H12AffineFastState.compose env44989 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound44989 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44990 : List Nat := [2,4,8,11,6,64,3,9,71,4,65,1,4,6,6,3,74,0,73,7,0,77,13,8,67,11,11,1,6,0,8,11,8,12,76,10]

theorem envBound44990 : H12AffineFastState.Bounded env44990 := by
  intro p hp
  have h : env44990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44989_44990 : H12AffineEnvironment.transform 6 3 env44989 = env44990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env44989 == env44990) = true)

theorem identity44990 : scanCanonicalize (H12AffineFastState.compose env44990 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44990 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44991 : List Nat := [2,3,8,11,1,64,3,9,64,3,65,1,3,1,1,3,74,0,73,0,0,74,10,8,67,11,11,1,1,0,8,11,8,11,75,10]

theorem envBound44991 : H12AffineFastState.Bounded env44991 := by
  intro p hp
  have h : env44991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44990_44991 : H12AffineEnvironment.transform 1 3 env44990 = env44991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44990 == env44991) = true)

def env44992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4097,476,74046,69649,13768,78895,4415,74815,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound44992 : H12AffineFastState.Bounded env44992 := by
  intro p hp
  have h : env44992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44950_44992 : H12AffineEnvironment.transform 17 65665 env44950 = env44992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44950 == env44992) = true)

theorem identity44992 : scanCanonicalize (H12AffineFastState.compose env44992 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound44992 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4097,476,65910,69649,5504,70759,4415,66679,1296,72962,68,65831,257,1281,1345,5953]

theorem envBound44993 : H12AffineFastState.Bounded env44993 := by
  intro p hp
  have h : env44993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44992_44993 : H12AffineEnvironment.transform 12 72 env44992 = env44993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44992 == env44993) = true)

def env44994 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4097,476,65910,69649,5504,70759,4415,66679,1296,72962,68,65831,257,1281,1345,5141]

theorem envBound44994 : H12AffineFastState.Bounded env44994 := by
  intro p hp
  have h : env44994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44993_44994 : H12AffineEnvironment.transform 8 340 env44993 = env44994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env44993 == env44994) = true)

def env44995 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4372,65536,65895,65665,4417,4373,4097,476,65910,69649,4288,69927,4415,65847,80,71746,68,65831,257,65,1,4437]

theorem envBound44995 : H12AffineFastState.Bounded env44995 := by
  intro p hp
  have h : env44995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44994_44995 : H12AffineEnvironment.transform 9 320 env44994 = env44995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44994 == env44995) = true)

theorem identity44995 : scanCanonicalize (H12AffineFastState.compose env44995 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44995 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44996 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4372,114,277,243,4417,4373,4097,476,260,4195,4288,4437,4415,325,80,6192,68,341,257,65,1,4437]

theorem envBound44996 : H12AffineFastState.Bounded env44996 := by
  intro p hp
  have h : env44996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44995_44996 : H12AffineEnvironment.transform 15 114 env44995 = env44996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44995 == env44996) = true)

theorem identity44996 : scanCanonicalize (H12AffineFastState.compose env44996 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 503) := by decide +kernel

theorem selectedBound44996 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env44997 : List Nat := [2,4,8,16,32,64,128,256,340,320,503,4096,72,80,4372,114,277,243,4417,4373,4097,476,260,4195,4288,4437,4415,325,80,4551,68,341,257,65,1,4437]

theorem envBound44997 : H12AffineFastState.Bounded env44997 := by
  intro p hp
  have h : env44997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44996_44997 : H12AffineEnvironment.transform 10 503 env44996 = env44997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 503 env44996 == env44997) = true)

theorem identity44997 : scanCanonicalize (H12AffineFastState.compose env44997 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 60) := by decide +kernel

theorem selectedBound44997 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44998 : List Nat := [2,4,8,16,32,64,128,256,340,320,503,60,72,80,296,114,277,243,381,297,61,476,260,95,252,361,259,325,80,507,68,341,257,65,1,361]

theorem envBound44998 : H12AffineFastState.Bounded env44998 := by
  intro p hp
  have h : env44998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44997_44998 : H12AffineEnvironment.transform 11 60 env44997 = env44998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 60 env44997 == env44998) = true)

theorem identity44998 : scanCanonicalize (H12AffineFastState.compose env44998 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound44998 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env44999 : List Nat := [2,4,8,16,32,64,128,41,125,105,222,60,72,80,1,114,60,243,84,0,61,245,45,95,252,64,42,108,80,210,68,124,40,65,1,64]

theorem envBound44999 : H12AffineFastState.Bounded env44999 := by
  intro p hp
  have h : env44999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44998_44999 : H12AffineEnvironment.transform 7 41 env44998 = env44999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env44998 == env44999) = true)

theorem identity44999 : scanCanonicalize (H12AffineFastState.compose env44999 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound44999 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env45000 : List Nat := [2,4,8,16,32,59,128,41,6,18,165,60,51,43,1,9,60,136,47,0,61,142,45,36,135,59,42,23,43,169,63,7,40,58,1,59]

theorem envBound45000 : H12AffineFastState.Bounded env45000 := by
  intro p hp
  have h : env45000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44999_45000 : H12AffineEnvironment.transform 5 59 env44999 = env45000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env44999 == env45000) = true)

theorem identity45000 : scanCanonicalize (H12AffineFastState.compose env45000 (packedSelected [1,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound45000 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env45001 : List Nat := [2,4,8,16,32,59,37,41,6,18,0,60,51,43,1,9,60,45,47,0,61,43,45,36,34,59,42,23,43,12,63,7,40,58,1,59]

theorem envBound45001 : H12AffineFastState.Bounded env45001 := by
  intro p hp
  have h : env45001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45000_45001 : H12AffineEnvironment.transform 6 37 env45000 = env45001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env45000 == env45001) = true)

theorem identity45001 : scanCanonicalize (H12AffineFastState.compose env45001 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45001 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env45002 : List Nat := [2,4,8,0,32,43,37,41,6,2,0,44,35,43,1,9,44,45,47,0,45,43,45,36,34,43,42,7,43,12,47,7,40,42,1,43]

theorem envBound45002 : H12AffineFastState.Bounded env45002 := by
  intro p hp
  have h : env45002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45001_45002 : H12AffineEnvironment.transform 3 0 env45001 = env45002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45001 == env45002) = true)

theorem identity45002 : scanCanonicalize (H12AffineFastState.compose env45002 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45003 : List Nat := [2,4,8,0,7,12,2,14,6,2,0,11,4,12,1,9,11,10,8,0,10,12,10,3,5,12,13,7,12,12,8,7,15,13,1,12]

theorem envBound45003 : H12AffineFastState.Bounded env45003 := by
  intro p hp
  have h : env45003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45002_45003 : H12AffineEnvironment.transform 4 7 env45002 = env45003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45002 == env45003) = true)

def env45004 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4373,65536,65894,65665,4417,4372,4097,476,65910,69649,4289,69926,4415,65846,81,71747,68,65831,257,64,0,4436]

theorem envBound45004 : H12AffineFastState.Bounded env45004 := by
  intro p hp
  have h : env45004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44994_45004 : H12AffineEnvironment.transform 9 321 env44994 = env45004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44994 == env45004) = true)

theorem identity45004 : scanCanonicalize (H12AffineFastState.compose env45004 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound45004 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45005 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4373,4211,4373,4338,4417,4372,4097,476,4357,98,4289,341,4415,4421,81,2096,68,4436,257,64,0,4436]

theorem envBound45005 : H12AffineFastState.Bounded env45005 := by
  intro p hp
  have h : env45005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45004_45005 : H12AffineEnvironment.transform 15 4211 env45004 = env45005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env45004 == env45005) = true)

theorem identity45005 : scanCanonicalize (H12AffineFastState.compose env45005 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45005 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45006 : List Nat := [2,4,8,16,32,64,128,69,17,4,2048,4096,72,81,4176,4211,4176,4338,4100,4177,4097,153,4160,98,4289,16,4218,4096,81,2096,68,4113,68,64,0,4113]

theorem envBound45006 : H12AffineFastState.Bounded env45006 := by
  intro p hp
  have h : env45006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45005_45006 : H12AffineEnvironment.transform 7 69 env45005 = env45006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45005 == env45006) = true)

theorem identity45006 : scanCanonicalize (H12AffineFastState.compose env45006 (packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 229) := by decide +kernel

theorem selectedBound45006 : packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env45007 : List Nat := [2,4,8,16,32,64,128,69,17,4,2048,229,72,81,181,150,181,23,225,180,228,153,165,98,36,16,159,229,81,2096,68,244,68,64,0,244]

theorem envBound45007 : H12AffineFastState.Bounded env45007 := by
  intro p hp
  have h : env45007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45006_45007 : H12AffineEnvironment.transform 11 229 env45006 = env45007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 229 env45006 == env45007) = true)

theorem identity45007 : scanCanonicalize (H12AffineFastState.compose env45007 (packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound45007 : packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env45008 : List Nat := [2,4,8,16,32,64,128,69,17,4,133,229,72,81,181,150,181,23,225,180,228,153,165,98,36,16,159,229,81,181,68,244,68,64,0,244]

theorem envBound45008 : H12AffineFastState.Bounded env45008 := by
  intro p hp
  have h : env45008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45007_45008 : H12AffineEnvironment.transform 10 133 env45007 = env45008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env45007 == env45008) = true)

theorem identity45008 : scanCanonicalize (H12AffineFastState.compose env45008 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45008 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env45009 : List Nat := [2,4,8,10,32,64,128,69,11,4,133,229,72,75,175,140,175,13,225,174,228,131,165,98,36,10,133,229,75,175,68,238,68,64,0,238]

theorem envBound45009 : H12AffineFastState.Bounded env45009 := by
  intro p hp
  have h : env45009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45008_45009 : H12AffineEnvironment.transform 3 10 env45008 = env45009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45008 == env45009) = true)

theorem identity45009 : scanCanonicalize (H12AffineFastState.compose env45009 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound45009 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env45010 : List Nat := [2,4,8,10,32,64,98,69,11,4,103,7,72,75,77,110,77,13,3,76,6,97,71,98,36,10,103,7,75,77,68,12,68,64,0,12]

theorem envBound45010 : H12AffineFastState.Bounded env45010 := by
  intro p hp
  have h : env45010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45009_45010 : H12AffineEnvironment.transform 6 98 env45009 = env45010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env45009 == env45010) = true)

theorem identity45010 : scanCanonicalize (H12AffineFastState.compose env45010 (packedSelected [0,3,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound45010 : packedSelected [0,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env45011 : List Nat := [2,4,8,10,32,1,35,4,11,4,38,7,9,10,12,47,12,13,3,13,6,32,6,35,36,10,38,7,10,12,5,12,5,1,0,12]

theorem envBound45011 : H12AffineFastState.Bounded env45011 := by
  intro p hp
  have h : env45011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45010_45011 : H12AffineEnvironment.transform 5 1 env45010 = env45011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45010 == env45011) = true)

theorem identity45011 : scanCanonicalize (H12AffineFastState.compose env45011 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45011 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45012 : List Nat := [2,4,8,10,11,1,8,4,11,4,13,7,9,10,12,4,12,13,3,13,6,11,6,8,15,10,13,7,10,12,5,12,5,1,0,12]

theorem envBound45012 : H12AffineFastState.Bounded env45012 := by
  intro p hp
  have h : env45012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45011_45012 : H12AffineEnvironment.transform 4 11 env45011 = env45012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45011 == env45012) = true)

theorem identity45012 : scanCanonicalize (H12AffineFastState.compose env45012 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45013 : List Nat := [2,4,3,1,0,1,3,4,0,4,6,7,2,1,7,4,7,6,3,6,6,0,6,3,4,1,6,7,1,7,5,7,5,1,0,7]

theorem envBound45013 : H12AffineFastState.Bounded env45013 := by
  intro p hp
  have h : env45013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45012_45013 : H12AffineEnvironment.transform 2 3 env45012 = env45013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45012 == env45013) = true)

theorem identity45013 : scanCanonicalize (H12AffineFastState.compose env45013 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45013 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45014 : List Nat := [2,3,3,1,0,1,3,3,0,3,1,0,2,1,0,3,0,1,3,1,1,0,1,3,3,1,1,0,1,0,2,0,2,1,0,0]

theorem envBound45014 : H12AffineFastState.Bounded env45014 := by
  intro p hp
  have h : env45014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45013_45014 : H12AffineEnvironment.transform 1 3 env45013 = env45014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45013 == env45014) = true)

def env45015 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1296,5204,65536,66599,65665,4417,5205,4097,476,65910,69649,5504,70759,4415,66679,1296,72962,68,65831,257,1281,1345,5140]

theorem envBound45015 : H12AffineFastState.Bounded env45015 := by
  intro p hp
  have h : env45015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44993_45015 : H12AffineEnvironment.transform 8 341 env44993 = env45015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env44993 == env45015) = true)

def env45016 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4372,65536,65895,65665,4417,4373,4097,476,65910,69649,4288,69927,4415,65847,80,71746,68,65831,257,65,1,4436]

theorem envBound45016 : H12AffineFastState.Bounded env45016 := by
  intro p hp
  have h : env45016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45016 : H12AffineEnvironment.transform 9 320 env45015 = env45016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env45015 == env45016) = true)

theorem identity45016 : scanCanonicalize (H12AffineFastState.compose env45016 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound45016 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45017 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4372,114,277,243,4417,4373,4097,476,260,4195,4288,4437,4415,325,80,6192,68,341,257,65,1,4436]

theorem envBound45017 : H12AffineFastState.Bounded env45017 := by
  intro p hp
  have h : env45017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45016_45017 : H12AffineEnvironment.transform 15 114 env45016 = env45017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env45016 == env45017) = true)

theorem identity45017 : scanCanonicalize (H12AffineFastState.compose env45017 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound45017 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env45018 : List Nat := [2,4,8,16,32,64,128,256,341,320,502,4096,72,80,4372,114,277,243,4417,4373,4097,476,260,4195,4288,4437,4415,325,80,4550,68,341,257,65,1,4436]

theorem envBound45018 : H12AffineFastState.Bounded env45018 := by
  intro p hp
  have h : env45018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45017_45018 : H12AffineEnvironment.transform 10 502 env45017 = env45018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env45017 == env45018) = true)

theorem identity45018 : scanCanonicalize (H12AffineFastState.compose env45018 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 297) := by decide +kernel

theorem selectedBound45018 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45019 : List Nat := [2,4,8,16,32,64,128,256,341,320,502,297,72,80,61,114,277,243,104,60,296,476,260,330,489,124,22,325,80,239,68,341,257,65,1,125]

theorem envBound45019 : H12AffineFastState.Bounded env45019 := by
  intro p hp
  have h : env45019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45018_45019 : H12AffineEnvironment.transform 11 297 env45018 = env45019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 297 env45018 == env45019) = true)

theorem identity45019 : scanCanonicalize (H12AffineFastState.compose env45019 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound45019 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env45020 : List Nat := [2,4,8,16,28,64,128,256,341,320,458,277,72,80,1,78,277,207,84,0,276,476,260,330,469,64,22,325,80,211,68,341,257,65,1,65]

theorem envBound45020 : H12AffineFastState.Bounded env45020 := by
  intro p hp
  have h : env45020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45019_45020 : H12AffineEnvironment.transform 4 28 env45019 = env45020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env45019 == env45020) = true)

theorem identity45020 : scanCanonicalize (H12AffineFastState.compose env45020 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 83) := by decide +kernel

theorem selectedBound45020 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env45021 : List Nat := [2,4,8,16,28,64,128,83,6,19,153,70,72,80,1,78,70,207,84,0,71,143,87,25,134,64,22,22,80,211,68,6,82,65,1,65]

theorem envBound45021 : H12AffineFastState.Bounded env45021 := by
  intro p hp
  have h : env45021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45020_45021 : H12AffineEnvironment.transform 7 83 env45020 = env45021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 83 env45020 == env45021) = true)

theorem identity45021 : scanCanonicalize (H12AffineFastState.compose env45021 (packedSelected [2,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45021 : packedSelected [2,5,12] rootPS < 2^1333 := by decide +kernel

def env45022 : List Nat := [2,4,8,16,28,64,8,83,6,19,17,70,72,80,1,78,70,71,84,0,71,7,87,25,14,64,22,22,80,91,68,6,82,65,1,65]

theorem envBound45022 : H12AffineFastState.Bounded env45022 := by
  intro p hp
  have h : env45022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45021_45022 : H12AffineEnvironment.transform 6 8 env45021 = env45022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45021 == env45022) = true)

theorem identity45022 : scanCanonicalize (H12AffineFastState.compose env45022 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound45022 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45023 : List Nat := [2,4,8,16,28,12,8,31,6,19,17,10,4,28,1,2,10,11,24,0,11,7,27,25,14,12,22,22,28,23,8,6,30,13,1,13]

theorem envBound45023 : H12AffineFastState.Bounded env45023 := by
  intro p hp
  have h : env45023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45022_45023 : H12AffineEnvironment.transform 5 12 env45022 = env45023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env45022 == env45023) = true)

theorem identity45023 : scanCanonicalize (H12AffineFastState.compose env45023 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound45023 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45024 : List Nat := [2,4,8,13,1,12,8,2,6,14,12,10,4,1,1,2,10,11,5,0,11,7,6,4,14,12,11,11,1,10,8,6,3,13,1,13]

theorem envBound45024 : H12AffineFastState.Bounded env45024 := by
  intro p hp
  have h : env45024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45023_45024 : H12AffineEnvironment.transform 3 13 env45023 = env45024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env45023 == env45024) = true)

theorem identity45024 : scanCanonicalize (H12AffineFastState.compose env45024 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45025 : List Nat := [2,4,2,7,1,6,2,2,6,4,6,0,4,1,1,2,0,1,5,0,1,7,6,4,4,6,1,1,1,0,2,6,3,7,1,7]

theorem envBound45025 : H12AffineFastState.Bounded env45025 := by
  intro p hp
  have h : env45025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45024_45025 : H12AffineEnvironment.transform 2 2 env45024 = env45025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45024 == env45025) = true)

theorem identity45025 : scanCanonicalize (H12AffineFastState.compose env45025 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45026 : List Nat := [2,0,2,3,1,2,2,2,2,0,2,0,0,1,1,2,0,1,1,0,1,3,2,0,0,2,1,1,1,0,2,2,3,3,1,3]

theorem envBound45026 : H12AffineFastState.Bounded env45026 := by
  intro p hp
  have h : env45026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45025_45026 : H12AffineEnvironment.transform 1 0 env45025 = env45026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45025 == env45026) = true)

def env45027 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4373,65536,65894,65665,4417,4372,4097,476,65910,69649,4289,69926,4415,65846,81,71747,68,65831,257,64,0,4437]

theorem envBound45027 : H12AffineFastState.Bounded env45027 := by
  intro p hp
  have h : env45027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45027 : H12AffineEnvironment.transform 9 321 env45015 = env45027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45015 == env45027) = true)

theorem identity45027 : scanCanonicalize (H12AffineFastState.compose env45027 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound45027 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45028 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4373,4211,4373,4338,4417,4372,4097,476,4357,98,4289,341,4415,4421,81,2096,68,4436,257,64,0,4437]

theorem envBound45028 : H12AffineFastState.Bounded env45028 := by
  intro p hp
  have h : env45028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45027_45028 : H12AffineEnvironment.transform 15 4211 env45027 = env45028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env45027 == env45028) = true)

theorem identity45028 : scanCanonicalize (H12AffineFastState.compose env45028 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45028 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45029 : List Nat := [2,4,8,16,32,64,128,69,16,4,2048,4096,72,81,4176,4211,4176,4338,4100,4177,4097,153,4160,98,4289,16,4218,4096,81,2096,68,4113,68,64,0,4112]

theorem envBound45029 : H12AffineFastState.Bounded env45029 := by
  intro p hp
  have h : env45029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45028_45029 : H12AffineEnvironment.transform 7 69 env45028 = env45029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45028 == env45029) = true)

theorem identity45029 : scanCanonicalize (H12AffineFastState.compose env45029 (packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound45029 : packedSelected [0,2,3,5,7,8,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env45030 : List Nat := [2,4,8,16,32,64,53,69,16,4,2048,4096,72,81,4176,4211,4176,4167,4100,4177,4097,44,4160,98,4212,16,4218,4096,81,2096,68,4113,68,64,0,4112]

theorem envBound45030 : H12AffineFastState.Bounded env45030 := by
  intro p hp
  have h : env45030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45029_45030 : H12AffineEnvironment.transform 6 53 env45029 = env45030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env45029 == env45030) = true)

theorem identity45030 : scanCanonicalize (H12AffineFastState.compose env45030 (packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound45030 : packedSelected [0,3,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env45031 : List Nat := [2,4,8,16,32,64,53,69,16,4,2048,2144,72,81,2096,2067,2096,2087,2148,2097,2145,44,2080,98,2068,16,2074,2144,81,2096,68,2161,68,64,0,2160]

theorem envBound45031 : H12AffineFastState.Bounded env45031 := by
  intro p hp
  have h : env45031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45030_45031 : H12AffineEnvironment.transform 11 2144 env45030 = env45031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env45030 == env45031) = true)

theorem identity45031 : scanCanonicalize (H12AffineFastState.compose env45031 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound45031 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env45032 : List Nat := [2,4,8,16,32,64,53,69,16,4,122,26,72,81,74,105,74,93,30,75,27,44,90,98,110,16,96,26,81,74,68,11,68,64,0,10]

theorem envBound45032 : H12AffineFastState.Bounded env45032 := by
  intro p hp
  have h : env45032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45031_45032 : H12AffineEnvironment.transform 10 122 env45031 = env45032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env45031 == env45032) = true)

theorem identity45032 : scanCanonicalize (H12AffineFastState.compose env45032 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound45032 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env45033 : List Nat := [2,4,8,16,32,12,53,9,16,4,54,26,4,29,6,37,6,17,30,7,27,44,22,46,34,16,44,26,29,6,8,11,8,12,0,10]

theorem envBound45033 : H12AffineFastState.Bounded env45033 := by
  intro p hp
  have h : env45033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45032_45033 : H12AffineEnvironment.transform 5 12 env45032 = env45033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env45032 == env45033) = true)

theorem identity45033 : scanCanonicalize (H12AffineFastState.compose env45033 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45033 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45034 : List Nat := [2,4,8,16,7,12,18,9,16,4,17,26,4,29,6,2,6,17,30,7,27,11,22,9,5,16,11,26,29,6,8,11,8,12,0,10]

theorem envBound45034 : H12AffineFastState.Bounded env45034 := by
  intro p hp
  have h : env45034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45033_45034 : H12AffineEnvironment.transform 4 7 env45033 = env45034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45033 == env45034) = true)

theorem identity45034 : scanCanonicalize (H12AffineFastState.compose env45034 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45034 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env45035 : List Nat := [2,4,4,16,7,0,18,5,16,4,17,22,4,17,6,2,6,17,18,7,23,7,22,5,5,16,7,22,17,6,4,7,4,0,0,6]

theorem envBound45035 : H12AffineFastState.Bounded env45035 := by
  intro p hp
  have h : env45035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45034_45035 : H12AffineEnvironment.transform 2 4 env45034 = env45035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45034 == env45035) = true)

theorem identity45035 : scanCanonicalize (H12AffineFastState.compose env45035 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45035 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45036 : List Nat := [2,4,4,6,7,0,4,5,6,4,7,0,4,7,6,2,6,7,4,7,1,7,0,5,5,6,7,0,7,6,4,7,4,0,0,6]

theorem envBound45036 : H12AffineFastState.Bounded env45036 := by
  intro p hp
  have h : env45036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45035_45036 : H12AffineEnvironment.transform 3 6 env45035 = env45036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45035 == env45036) = true)

def env45037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4097,477,74047,69648,13769,78895,332223,74814,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound45037 : H12AffineFastState.Bounded env45037 := by
  intro p hp
  have h : env45037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44949_45037 : H12AffineEnvironment.transform 13 1297 env44949 = env45037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44949 == env45037) = true)

def env45038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4097,477,74047,69648,13769,78895,4415,74814,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound45038 : H12AffineFastState.Bounded env45038 := by
  intro p hp
  have h : env45038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45037_45038 : H12AffineEnvironment.transform 17 65664 env45037 = env45038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45037 == env45038) = true)

theorem identity45038 : scanCanonicalize (H12AffineFastState.compose env45038 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound45038 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45039 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4097,477,74047,69648,12424,78190,4415,74111,81,79882,8205,65830,257,64,0,4609]

theorem envBound45039 : H12AffineFastState.Bounded env45039 := by
  intro p hp
  have h : env45039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45038_45039 : H12AffineEnvironment.transform 9 321 env45038 = env45039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45038 == env45039) = true)

def env45040 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4097,477,74047,69648,12424,78190,4415,74111,81,79882,8205,65830,257,64,0,4437]

theorem envBound45040 : H12AffineFastState.Bounded env45040 := by
  intro p hp
  have h : env45040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45039_45040 : H12AffineEnvironment.transform 8 340 env45039 = env45040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env45039 == env45040) = true)

def env45041 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,80,8525,65536,74030,65664,336,8524,17,477,74047,65536,8344,74110,303,74111,81,75802,8205,65830,257,64,0,325]

theorem envBound45041 : H12AffineFastState.Bounded env45041 := by
  intro p hp
  have h : env45041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45040_45041 : H12AffineEnvironment.transform 11 16 env45040 = env45041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45040 == env45041) = true)

theorem identity45041 : scanCanonicalize (H12AffineFastState.compose env45041 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound45041 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45042 : List Nat := [2,4,8,16,32,64,5,256,340,321,2048,16,8192,80,8525,65536,74030,65541,336,8524,17,344,74047,65536,8221,74110,303,74111,81,75802,8205,65830,257,64,0,325]

theorem envBound45042 : H12AffineFastState.Bounded env45042 := by
  intro p hp
  have h : env45042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45041_45042 : H12AffineEnvironment.transform 6 5 env45041 = env45042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env45041 == env45042) = true)

def env45043 : List Nat := [2,4,8,16,32,64,5,256,340,321,2048,16,8192,80,8525,352,8270,357,336,8524,17,344,8287,352,8221,8222,303,8223,81,10618,8205,70,257,64,0,325]

theorem envBound45043 : H12AffineFastState.Bounded env45043 := by
  intro p hp
  have h : env45043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45042_45043 : H12AffineEnvironment.transform 15 352 env45042 = env45043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 352 env45042 == env45043) = true)

theorem identity45043 : scanCanonicalize (H12AffineFastState.compose env45043 (packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 36) := by decide +kernel

theorem selectedBound45043 : packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45044 : List Nat := [2,4,8,16,32,64,5,256,340,321,2048,16,36,80,361,352,106,357,336,360,17,344,123,352,57,58,303,59,81,2398,41,70,257,64,0,325]

theorem envBound45044 : H12AffineFastState.Bounded env45044 := by
  intro p hp
  have h : env45044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45043_45044 : H12AffineEnvironment.transform 12 36 env45043 = env45044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 36 env45043 == env45044) = true)

theorem identity45044 : scanCanonicalize (H12AffineFastState.compose env45044 (packedSelected [0,2,4,7,9,17,18,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound45044 : packedSelected [0,2,4,7,9,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env45045 : List Nat := [2,4,8,16,32,64,5,256,340,321,113,16,36,80,361,352,106,357,336,360,17,344,123,352,57,58,303,59,81,303,41,70,257,64,0,325]

theorem envBound45045 : H12AffineFastState.Bounded env45045 := by
  intro p hp
  have h : env45045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45044_45045 : H12AffineEnvironment.transform 10 113 env45044 = env45045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env45044 == env45045) = true)

theorem identity45045 : scanCanonicalize (H12AffineFastState.compose env45045 (packedSelected [8,10,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45045 : packedSelected [8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env45046 : List Nat := [2,4,8,16,26,64,5,256,340,321,75,16,30,80,339,346,80,351,336,338,17,344,65,346,3,0,277,1,81,277,19,70,257,64,0,325]

theorem envBound45046 : H12AffineFastState.Bounded env45046 := by
  intro p hp
  have h : env45046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45045_45046 : H12AffineEnvironment.transform 4 26 env45045 = env45046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45045 == env45046) = true)

theorem identity45046 : scanCanonicalize (H12AffineFastState.compose env45046 (packedSelected [1,3,4,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound45046 : packedSelected [1,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env45047 : List Nat := [2,4,8,16,26,64,5,15,91,78,75,16,30,80,92,85,80,80,95,93,17,87,65,85,3,0,26,1,81,26,19,70,14,64,0,74]

theorem envBound45047 : H12AffineFastState.Bounded env45047 := by
  intro p hp
  have h : env45047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45046_45047 : H12AffineEnvironment.transform 7 15 env45046 = env45047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env45046 == env45047) = true)

theorem identity45047 : scanCanonicalize (H12AffineFastState.compose env45047 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound45047 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env45048 : List Nat := [2,4,8,16,26,7,5,15,28,9,12,16,30,23,27,18,23,23,24,26,17,16,6,18,3,0,26,1,22,26,19,1,14,7,0,13]

theorem envBound45048 : H12AffineFastState.Bounded env45048 := by
  intro p hp
  have h : env45048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45047_45048 : H12AffineEnvironment.transform 5 7 env45047 = env45048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env45047 == env45048) = true)

theorem identity45048 : scanCanonicalize (H12AffineFastState.compose env45048 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45048 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45049 : List Nat := [2,4,8,11,1,7,5,15,7,9,12,11,5,12,0,9,12,12,3,1,10,11,6,9,3,0,1,1,13,1,8,1,14,7,0,13]

theorem envBound45049 : H12AffineFastState.Bounded env45049 := by
  intro p hp
  have h : env45049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45048_45049 : H12AffineEnvironment.transform 3 11 env45048 = env45049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45048 == env45049) = true)

theorem identity45049 : scanCanonicalize (H12AffineFastState.compose env45049 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45049 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45050 : List Nat := [2,4,5,6,1,7,5,2,7,4,1,6,5,1,0,4,1,1,3,1,7,6,6,4,3,0,1,1,0,1,5,1,3,7,0,0]

theorem envBound45050 : H12AffineFastState.Bounded env45050 := by
  intro p hp
  have h : env45050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45049_45050 : H12AffineEnvironment.transform 2 5 env45049 = env45050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45049 == env45050) = true)

def env45051 : List Nat := [2,4,8,16,32,64,5,256,340,321,2048,16,8192,80,8525,353,8271,356,336,8524,17,344,8286,353,8221,8223,303,8222,81,10619,8205,71,257,64,0,325]

theorem envBound45051 : H12AffineFastState.Bounded env45051 := by
  intro p hp
  have h : env45051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45042_45051 : H12AffineEnvironment.transform 15 353 env45042 = env45051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 353 env45042 == env45051) = true)

theorem identity45051 : scanCanonicalize (H12AffineFastState.compose env45051 (packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 34) := by decide +kernel

theorem selectedBound45051 : packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45052 : List Nat := [2,4,8,16,32,64,5,256,340,321,2048,16,34,80,367,353,109,356,336,366,17,344,124,353,63,61,303,60,81,2393,47,71,257,64,0,325]

theorem envBound45052 : H12AffineFastState.Bounded env45052 := by
  intro p hp
  have h : env45052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45051_45052 : H12AffineEnvironment.transform 12 34 env45051 = env45052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 34 env45051 == env45052) = true)

theorem identity45052 : scanCanonicalize (H12AffineFastState.compose env45052 (packedSelected [0,2,3,4,7,9,10,12,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound45052 : packedSelected [0,2,3,4,7,9,10,12,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env45053 : List Nat := [2,4,8,16,32,64,5,256,340,321,107,16,34,80,367,353,109,356,336,366,17,344,124,353,63,61,303,60,81,306,47,71,257,64,0,325]

theorem envBound45053 : H12AffineFastState.Bounded env45053 := by
  intro p hp
  have h : env45053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45052_45053 : H12AffineEnvironment.transform 10 107 env45052 = env45053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env45052 == env45053) = true)

theorem identity45053 : scanCanonicalize (H12AffineFastState.compose env45053 (packedSelected [2,5,7,9,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound45053 : packedSelected [2,5,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env45054 : List Nat := [2,4,8,16,32,64,5,50,102,115,107,16,34,80,93,83,109,86,98,92,17,106,124,83,63,61,29,60,81,0,47,71,51,64,0,119]

theorem envBound45054 : H12AffineFastState.Bounded env45054 := by
  intro p hp
  have h : env45054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45053_45054 : H12AffineEnvironment.transform 7 50 env45053 = env45054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env45053 == env45054) = true)

theorem identity45054 : scanCanonicalize (H12AffineFastState.compose env45054 (packedSelected [0,1,2,3,5,9,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45054 : packedSelected [0,1,2,3,5,9,12] rootPS < 2^1333 := by decide +kernel

def env45055 : List Nat := [2,3,8,16,32,64,2,50,97,115,107,16,34,80,90,83,106,81,98,91,17,106,123,83,56,58,26,59,81,0,40,64,51,64,0,112]

theorem envBound45055 : H12AffineFastState.Bounded env45055 := by
  intro p hp
  have h : env45055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45054_45055 : H12AffineEnvironment.transform 1 3 env45054 = env45055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45054 == env45055) = true)

theorem identity45055 : scanCanonicalize (H12AffineFastState.compose env45055 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45055 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env45056 : List Nat := [2,3,8,16,32,17,2,50,48,34,58,16,34,1,11,2,59,0,51,10,17,59,42,2,56,58,26,59,0,0,40,17,51,17,0,33]

theorem envBound45056 : H12AffineFastState.Bounded env45056 := by
  intro p hp
  have h : env45056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45055_45056 : H12AffineEnvironment.transform 5 17 env45055 = env45056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45055 == env45056) = true)

theorem identity45056 : scanCanonicalize (H12AffineFastState.compose env45056 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45056 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env45057 : List Nat := [2,3,8,16,17,17,2,3,1,19,11,16,19,1,11,2,10,0,2,10,17,10,27,2,9,11,26,10,0,0,25,17,2,17,0,16]

theorem envBound45057 : H12AffineFastState.Bounded env45057 := by
  intro p hp
  have h : env45057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45056_45057 : H12AffineEnvironment.transform 4 17 env45056 = env45057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45056 == env45057) = true)

theorem identity45057 : scanCanonicalize (H12AffineFastState.compose env45057 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45057 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45058 : List Nat := [2,3,3,16,17,17,2,3,1,19,0,16,19,1,0,2,1,0,2,1,17,1,16,2,2,0,17,1,0,0,18,17,2,17,0,16]

theorem envBound45058 : H12AffineFastState.Bounded env45058 := by
  intro p hp
  have h : env45058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45057_45058 : H12AffineEnvironment.transform 2 3 env45057 = env45058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45057 == env45058) = true)

def env45059 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,80,8524,65536,74030,65664,337,8525,16,477,74047,65537,8345,74111,302,74111,81,75803,8205,65830,257,64,0,324]

theorem envBound45059 : H12AffineFastState.Bounded env45059 := by
  intro p hp
  have h : env45059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45040_45059 : H12AffineEnvironment.transform 11 17 env45040 = env45059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45040 == env45059) = true)

theorem identity45059 : scanCanonicalize (H12AffineFastState.compose env45059 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 204) := by decide +kernel

theorem selectedBound45059 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45060 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,204,80,384,65536,66018,65664,337,385,16,477,66035,65537,85,65971,302,65971,81,67799,193,65830,257,64,0,324]

theorem envBound45060 : H12AffineFastState.Bounded env45060 := by
  intro p hp
  have h : env45060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45059_45060 : H12AffineEnvironment.transform 12 204 env45059 = env45060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 204 env45059 == env45060) = true)

def env45061 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,204,64,384,65536,66018,65664,321,385,0,461,66019,65537,69,65955,302,65955,65,67783,193,65830,257,64,0,324]

theorem envBound45061 : H12AffineFastState.Bounded env45061 := by
  intro p hp
  have h : env45061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45060_45061 : H12AffineEnvironment.transform 3 0 env45060 = env45061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45060 == env45061) = true)

theorem identity45061 : scanCanonicalize (H12AffineFastState.compose env45061 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 231) := by decide +kernel

theorem selectedBound45061 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45062 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,204,64,384,231,261,103,321,385,0,461,260,230,69,324,302,324,65,2080,193,449,257,64,0,324]

theorem envBound45062 : H12AffineFastState.Bounded env45062 := by
  intro p hp
  have h : env45062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45061_45062 : H12AffineEnvironment.transform 15 231 env45061 = env45062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 231 env45061 == env45062) = true)

theorem identity45062 : scanCanonicalize (H12AffineFastState.compose env45062 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45062 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45063 : List Nat := [2,4,8,0,32,64,128,69,1,4,2048,1,204,64,197,231,64,103,4,196,0,136,65,230,69,1,107,1,65,2080,193,132,68,64,0,1]

theorem envBound45063 : H12AffineFastState.Bounded env45063 := by
  intro p hp
  have h : env45063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45062_45063 : H12AffineEnvironment.transform 7 69 env45062 = env45063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45062 == env45063) = true)

theorem identity45063 : scanCanonicalize (H12AffineFastState.compose env45063 (packedSelected [5,10] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound45063 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env45064 : List Nat := [2,4,8,0,32,42,128,47,1,4,2048,1,166,42,175,141,42,13,4,174,0,136,43,140,47,1,1,1,43,2080,171,132,46,42,0,1]

theorem envBound45064 : H12AffineFastState.Bounded env45064 := by
  intro p hp
  have h : env45064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45063_45064 : H12AffineEnvironment.transform 5 42 env45063 = env45064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env45063 == env45064) = true)

theorem identity45064 : scanCanonicalize (H12AffineFastState.compose env45064 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound45064 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env45065 : List Nat := [2,4,8,0,32,42,128,47,1,4,133,1,166,42,175,141,42,13,4,174,0,136,43,140,47,1,1,1,43,165,171,132,46,42,0,1]

theorem envBound45065 : H12AffineFastState.Bounded env45065 := by
  intro p hp
  have h : env45065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45064_45065 : H12AffineEnvironment.transform 10 133 env45064 = env45065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env45064 == env45065) = true)

theorem identity45065 : scanCanonicalize (H12AffineFastState.compose env45065 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45065 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env45066 : List Nat := [2,4,8,0,32,42,9,47,1,4,12,1,47,42,38,4,42,13,4,39,0,1,43,5,47,1,1,1,43,44,34,13,46,42,0,1]

theorem envBound45066 : H12AffineFastState.Bounded env45066 := by
  intro p hp
  have h : env45066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45065_45066 : H12AffineEnvironment.transform 6 9 env45065 = env45066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45065 == env45066) = true)

theorem identity45066 : scanCanonicalize (H12AffineFastState.compose env45066 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45066 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env45067 : List Nat := [2,4,8,0,0,10,9,15,1,4,12,1,15,10,6,4,10,13,4,7,0,1,11,5,15,1,1,1,11,12,2,13,14,10,0,1]

theorem envBound45067 : H12AffineFastState.Bounded env45067 := by
  intro p hp
  have h : env45067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45066_45067 : H12AffineEnvironment.transform 4 0 env45066 = env45067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45066 == env45067) = true)

theorem identity45067 : scanCanonicalize (H12AffineFastState.compose env45067 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45068 : List Nat := [2,4,4,0,0,6,5,3,1,4,0,1,3,6,6,4,6,1,4,7,0,1,7,5,3,1,1,1,7,0,2,1,2,6,0,1]

theorem envBound45068 : H12AffineFastState.Bounded env45068 := by
  intro p hp
  have h : env45068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45067_45068 : H12AffineEnvironment.transform 2 4 env45067 = env45068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45067 == env45068) = true)

theorem identity45068 : scanCanonicalize (H12AffineFastState.compose env45068 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45069 : List Nat := [2,2,2,0,0,0,3,3,1,2,0,1,3,0,0,2,0,1,2,1,0,1,1,3,3,1,1,1,1,0,2,1,2,0,0,1]

theorem envBound45069 : H12AffineFastState.Bounded env45069 := by
  intro p hp
  have h : env45069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45068_45069 : H12AffineEnvironment.transform 1 2 env45068 = env45069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45068 == env45069) = true)

def env45070 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,204,65,384,65536,66018,65664,320,385,1,460,66018,65537,68,65954,302,65954,64,67782,193,65830,257,64,0,324]

theorem envBound45070 : H12AffineFastState.Bounded env45070 := by
  intro p hp
  have h : env45070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45060_45070 : H12AffineEnvironment.transform 3 1 env45060 = env45070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45060 == env45070) = true)

theorem identity45070 : scanCanonicalize (H12AffineFastState.compose env45070 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45070 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45071 : List Nat := [2,4,8,1,32,64,128,68,1,5,2048,0,204,65,196,65536,65702,65664,4,197,1,136,65702,65537,68,65766,106,65766,64,67782,193,65634,69,64,0,0]

theorem envBound45071 : H12AffineFastState.Bounded env45071 := by
  intro p hp
  have h : env45071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45070_45071 : H12AffineEnvironment.transform 7 68 env45070 = env45071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45070 == env45071) = true)

theorem identity45071 : scanCanonicalize (H12AffineFastState.compose env45071 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound45071 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45072 : List Nat := [2,4,8,1,32,64,128,68,1,5,2048,0,204,65,196,98,196,226,4,197,1,136,196,99,68,132,106,132,64,2212,193,0,69,64,0,0]

theorem envBound45072 : H12AffineFastState.Bounded env45072 := by
  intro p hp
  have h : env45072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45071_45072 : H12AffineEnvironment.transform 15 98 env45071 = env45072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env45071 == env45072) = true)

theorem identity45072 : scanCanonicalize (H12AffineFastState.compose env45072 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound45072 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45073 : List Nat := [2,4,8,1,32,64,69,68,1,5,2048,0,9,65,1,98,1,39,4,0,1,77,1,99,68,65,106,65,64,2145,4,0,69,64,0,0]

theorem envBound45073 : H12AffineFastState.Bounded env45073 := by
  intro p hp
  have h : env45073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45072_45073 : H12AffineEnvironment.transform 6 69 env45072 = env45073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env45072 == env45073) = true)

theorem identity45073 : scanCanonicalize (H12AffineFastState.compose env45073 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound45073 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45074 : List Nat := [2,4,8,1,32,64,69,68,1,5,12,0,9,65,1,98,1,39,4,0,1,77,1,99,68,65,106,65,64,109,4,0,69,64,0,0]

theorem envBound45074 : H12AffineFastState.Bounded env45074 := by
  intro p hp
  have h : env45074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45073_45074 : H12AffineEnvironment.transform 10 12 env45073 = env45074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env45073 == env45074) = true)

theorem identity45074 : scanCanonicalize (H12AffineFastState.compose env45074 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound45074 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45075 : List Nat := [2,4,8,1,32,10,15,14,1,5,12,0,9,11,1,40,1,39,4,0,1,7,1,41,14,11,32,11,10,39,4,0,15,10,0,0]

theorem envBound45075 : H12AffineFastState.Bounded env45075 := by
  intro p hp
  have h : env45075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45074_45075 : H12AffineEnvironment.transform 5 10 env45074 = env45075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env45074 == env45075) = true)

theorem identity45075 : scanCanonicalize (H12AffineFastState.compose env45075 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45075 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45076 : List Nat := [2,4,5,1,32,7,2,3,1,5,1,0,4,6,1,37,1,39,4,0,1,7,1,36,3,6,32,6,7,39,4,0,2,7,0,0]

theorem envBound45076 : H12AffineFastState.Bounded env45076 := by
  intro p hp
  have h : env45076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45075_45076 : H12AffineEnvironment.transform 2 5 env45075 = env45076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45075 == env45076) = true)

theorem identity45076 : scanCanonicalize (H12AffineFastState.compose env45076 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound45076 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45077 : List Nat := [2,4,5,1,3,7,2,3,1,5,1,0,4,6,1,6,1,4,4,0,1,7,1,7,3,6,3,6,7,4,4,0,2,7,0,0]

theorem envBound45077 : H12AffineFastState.Bounded env45077 := by
  intro p hp
  have h : env45077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45076_45077 : H12AffineEnvironment.transform 4 3 env45076 = env45077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env45076 == env45077) = true)

theorem identity45077 : scanCanonicalize (H12AffineFastState.compose env45077 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45078 : List Nat := [2,0,1,1,3,3,2,3,1,1,1,0,0,2,1,2,1,0,0,0,1,3,1,3,3,2,3,2,3,0,0,0,2,3,0,0]

theorem envBound45078 : H12AffineFastState.Bounded env45078 := by
  intro p hp
  have h : env45078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45077_45078 : H12AffineEnvironment.transform 1 0 env45077 = env45078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45077 == env45078) = true)

def env45079 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,80,12637,65536,74030,65664,4416,12636,4097,477,74047,69648,12424,78190,4415,74111,81,79882,8205,65830,257,64,0,4436]

theorem envBound45079 : H12AffineFastState.Bounded env45079 := by
  intro p hp
  have h : env45079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45039_45079 : H12AffineEnvironment.transform 8 341 env45039 = env45079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env45039 == env45079) = true)

def env45080 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8525,65536,74030,65664,336,8524,17,477,74047,65536,8344,74110,303,74111,81,75802,8205,65830,257,64,0,324]

theorem envBound45080 : H12AffineFastState.Bounded env45080 := by
  intro p hp
  have h : env45080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45079_45080 : H12AffineEnvironment.transform 11 16 env45079 = env45080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45079 == env45080) = true)

theorem identity45080 : scanCanonicalize (H12AffineFastState.compose env45080 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8619) := by decide +kernel

theorem selectedBound45080 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45081 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8525,8619,133,8491,336,8524,17,477,148,8619,8344,213,303,212,81,2481,8205,8333,257,64,0,324]

theorem envBound45081 : H12AffineFastState.Bounded env45081 := by
  intro p hp
  have h : env45081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45080_45081 : H12AffineEnvironment.transform 15 8619 env45080 = env45081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8619 env45080 == env45081) = true)

def env45082 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,8192,64,8525,8619,133,8491,320,8524,1,461,132,8619,8328,197,303,196,65,2465,8205,8333,257,64,0,324]

theorem envBound45082 : H12AffineFastState.Bounded env45082 := by
  intro p hp
  have h : env45082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45081_45082 : H12AffineEnvironment.transform 3 0 env45081 = env45082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45081 == env45082) = true)

theorem identity45082 : scanCanonicalize (H12AffineFastState.compose env45082 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45082 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45083 : List Nat := [2,4,8,0,32,64,128,68,1,5,2048,0,8192,64,8201,8431,133,8303,4,8200,1,137,132,8431,8328,197,107,196,65,2277,8205,8333,69,64,0,0]

theorem envBound45083 : H12AffineFastState.Bounded env45083 := by
  intro p hp
  have h : env45083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45082_45083 : H12AffineEnvironment.transform 7 68 env45082 = env45083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45082 == env45083) = true)

theorem identity45083 : scanCanonicalize (H12AffineFastState.compose env45083 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound45083 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45084 : List Nat := [2,4,8,0,32,64,128,68,1,5,2048,0,140,64,133,99,133,227,4,132,1,137,132,99,4,197,107,196,65,2277,129,1,69,64,0,0]

theorem envBound45084 : H12AffineFastState.Bounded env45084 := by
  intro p hp
  have h : env45084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45083_45084 : H12AffineEnvironment.transform 12 140 env45083 = env45084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env45083 == env45084) = true)

theorem identity45084 : scanCanonicalize (H12AffineFastState.compose env45084 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound45084 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45085 : List Nat := [2,4,8,0,32,64,5,68,1,5,2048,0,9,64,0,99,0,102,4,1,1,12,1,99,4,64,107,65,65,2144,4,1,69,64,0,0]

theorem envBound45085 : H12AffineFastState.Bounded env45085 := by
  intro p hp
  have h : env45085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45084_45085 : H12AffineEnvironment.transform 6 5 env45084 = env45085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env45084 == env45085) = true)

theorem identity45085 : scanCanonicalize (H12AffineFastState.compose env45085 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound45085 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45086 : List Nat := [2,4,8,0,32,64,5,68,1,5,10,0,9,64,0,99,0,102,4,1,1,12,1,99,4,64,107,65,65,106,4,1,69,64,0,0]

theorem envBound45086 : H12AffineFastState.Bounded env45086 := by
  intro p hp
  have h : env45086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45085_45086 : H12AffineEnvironment.transform 10 10 env45085 = env45086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env45085 == env45086) = true)

theorem identity45086 : scanCanonicalize (H12AffineFastState.compose env45086 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound45086 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45087 : List Nat := [2,4,8,0,32,10,5,14,1,5,10,0,9,10,0,41,0,44,4,1,1,12,1,41,4,10,33,11,11,32,4,1,15,10,0,0]

theorem envBound45087 : H12AffineFastState.Bounded env45087 := by
  intro p hp
  have h : env45087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45086_45087 : H12AffineEnvironment.transform 5 10 env45086 = env45087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env45086 == env45087) = true)

theorem identity45087 : scanCanonicalize (H12AffineFastState.compose env45087 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45087 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45088 : List Nat := [2,4,8,0,10,10,5,14,1,5,10,0,9,10,0,3,0,6,4,1,1,12,1,3,4,10,11,11,11,10,4,1,15,10,0,0]

theorem envBound45088 : H12AffineFastState.Bounded env45088 := by
  intro p hp
  have h : env45088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45087_45088 : H12AffineEnvironment.transform 4 10 env45087 = env45088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45087 == env45088) = true)

theorem identity45088 : scanCanonicalize (H12AffineFastState.compose env45088 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound45088 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45089 : List Nat := [2,4,7,0,5,5,5,1,1,5,5,0,6,5,0,3,0,6,4,1,1,3,1,3,4,5,4,4,4,5,4,1,0,5,0,0]

theorem envBound45089 : H12AffineFastState.Bounded env45089 := by
  intro p hp
  have h : env45089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45088_45089 : H12AffineEnvironment.transform 2 7 env45088 = env45089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env45088 == env45089) = true)

theorem identity45089 : scanCanonicalize (H12AffineFastState.compose env45089 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45089 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env45090 : List Nat := [2,1,2,0,0,0,0,1,1,0,0,0,3,0,0,3,0,3,1,1,1,3,1,3,1,0,1,1,1,0,1,1,0,0,0,0]

theorem envBound45090 : H12AffineFastState.Bounded env45090 := by
  intro p hp
  have h : env45090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45089_45090 : H12AffineEnvironment.transform 1 1 env45089 = env45090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45089 == env45090) = true)

def env45091 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,8192,65,8525,8619,133,8491,321,8524,0,460,133,8619,8329,196,303,197,64,2464,8205,8333,257,64,0,324]

theorem envBound45091 : H12AffineFastState.Bounded env45091 := by
  intro p hp
  have h : env45091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45081_45091 : H12AffineEnvironment.transform 3 1 env45081 = env45091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45081 == env45091) = true)

theorem identity45091 : scanCanonicalize (H12AffineFastState.compose env45091 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound45091 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45092 : List Nat := [2,4,8,1,32,64,128,129,197,192,2048,1,8192,65,8396,8234,133,8362,192,8397,0,77,133,8234,8329,196,174,197,64,2081,8205,8333,128,64,0,197]

theorem envBound45092 : H12AffineFastState.Bounded env45092 := by
  intro p hp
  have h : env45092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45091_45092 : H12AffineEnvironment.transform 7 129 env45091 = env45092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env45091 == env45092) = true)

theorem identity45092 : scanCanonicalize (H12AffineFastState.compose env45092 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound45092 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45093 : List Nat := [2,4,8,1,32,64,68,69,1,4,2048,1,8192,65,8200,8234,65,8302,4,8201,0,77,65,8234,8269,0,106,1,64,2081,8205,8265,68,64,0,1]

theorem envBound45093 : H12AffineFastState.Bounded env45093 := by
  intro p hp
  have h : env45093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45092_45093 : H12AffineEnvironment.transform 6 68 env45092 = env45093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env45092 == env45093) = true)

theorem identity45093 : scanCanonicalize (H12AffineFastState.compose env45093 (packedSelected [5,10] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound45093 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env45094 : List Nat := [2,4,8,1,32,43,47,46,1,4,2048,1,8192,42,8200,8234,42,8197,4,8201,0,38,42,8234,8230,0,1,1,43,2081,8205,8226,47,43,0,1]

theorem envBound45094 : H12AffineFastState.Bounded env45094 := by
  intro p hp
  have h : env45094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45093_45094 : H12AffineEnvironment.transform 5 43 env45093 = env45094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env45093 == env45094) = true)

theorem identity45094 : scanCanonicalize (H12AffineFastState.compose env45094 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound45094 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env45095 : List Nat := [2,4,8,1,32,43,47,46,1,4,2048,1,2082,42,2090,2056,42,2087,4,2091,0,38,42,2056,2052,0,1,1,43,2081,2095,2048,47,43,0,1]

theorem envBound45095 : H12AffineFastState.Bounded env45095 := by
  intro p hp
  have h : env45095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45094_45095 : H12AffineEnvironment.transform 12 2082 env45094 = env45095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env45094 == env45095) = true)

theorem identity45095 : scanCanonicalize (H12AffineFastState.compose env45095 (packedSelected [2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45095 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env45096 : List Nat := [2,4,8,1,6,13,9,8,1,4,2048,1,2052,12,2060,2056,12,2049,4,2061,0,0,12,2056,2052,0,1,1,13,2055,2057,2048,9,13,0,1]

theorem envBound45096 : H12AffineFastState.Bounded env45096 := by
  intro p hp
  have h : env45096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45095_45096 : H12AffineEnvironment.transform 4 6 env45095 = env45096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45095 == env45096) = true)

theorem identity45096 : scanCanonicalize (H12AffineFastState.compose env45096 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45096 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env45097 : List Nat := [2,3,8,1,1,10,9,8,1,3,2048,1,2051,11,2059,2056,11,2049,3,2058,0,0,11,2056,2051,0,1,1,10,2048,2057,2048,9,10,0,1]

theorem envBound45097 : H12AffineFastState.Bounded env45097 := by
  intro p hp
  have h : env45097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45096_45097 : H12AffineEnvironment.transform 1 3 env45096 = env45097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45096 == env45097) = true)

theorem identity45097 : scanCanonicalize (H12AffineFastState.compose env45097 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45098 : List Nat := [2,3,8,1,1,10,9,8,1,3,0,1,3,11,11,8,11,1,3,10,0,0,11,8,3,0,1,1,10,0,9,0,9,10,0,1]

theorem envBound45098 : H12AffineFastState.Bounded env45098 := by
  intro p hp
  have h : env45098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45097_45098 : H12AffineEnvironment.transform 10 0 env45097 = env45098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45097 == env45098) = true)

theorem identity45098 : scanCanonicalize (H12AffineFastState.compose env45098 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45099 : List Nat := [2,3,3,1,1,1,2,3,1,3,0,1,3,0,0,3,0,1,3,1,0,0,0,3,3,0,1,1,1,0,2,0,2,1,0,1]

theorem envBound45099 : H12AffineFastState.Bounded env45099 := by
  intro p hp
  have h : env45099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45098_45099 : H12AffineEnvironment.transform 2 3 env45098 = env45099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45098 == env45099) = true)

def env45100 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8524,65536,74030,65664,337,8525,16,477,74047,65537,8345,74111,302,74111,81,75803,8205,65830,257,64,0,325]

theorem envBound45100 : H12AffineFastState.Bounded env45100 := by
  intro p hp
  have h : env45100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45079_45100 : H12AffineEnvironment.transform 11 17 env45079 = env45100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45079 == env45100) = true)

theorem identity45100 : scanCanonicalize (H12AffineFastState.compose env45100 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 482) := by decide +kernel

theorem selectedBound45100 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45101 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8524,482,8396,354,337,8525,16,477,8413,483,8345,8349,302,8349,81,10745,8205,196,257,64,0,325]

theorem envBound45101 : H12AffineFastState.Bounded env45101 := by
  intro p hp
  have h : env45101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45100_45101 : H12AffineEnvironment.transform 15 482 env45100 = env45101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 482 env45100 == env45101) = true)

def env45102 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,8192,64,8524,482,8396,354,321,8525,0,461,8397,483,8329,8333,302,8333,65,10729,8205,196,257,64,0,325]

theorem envBound45102 : H12AffineFastState.Bounded env45102 := by
  intro p hp
  have h : env45102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45101_45102 : H12AffineEnvironment.transform 3 0 env45101 = env45102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45101 == env45102) = true)

theorem identity45102 : scanCanonicalize (H12AffineFastState.compose env45102 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 457) := by decide +kernel

theorem selectedBound45102 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45103 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,457,64,133,482,261,354,321,132,0,461,260,483,320,324,302,324,65,2080,452,196,257,64,0,325]

theorem envBound45103 : H12AffineFastState.Bounded env45103 := by
  intro p hp
  have h : env45103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45102_45103 : H12AffineEnvironment.transform 12 457 env45102 = env45103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 457 env45102 == env45103) = true)

theorem identity45103 : scanCanonicalize (H12AffineFastState.compose env45103 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45103 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45104 : List Nat := [2,4,8,0,32,64,128,69,0,4,2048,1,140,64,133,167,64,39,4,132,0,136,65,166,5,1,107,1,65,2080,129,196,68,64,0,0]

theorem envBound45104 : H12AffineFastState.Bounded env45104 := by
  intro p hp
  have h : env45104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45103_45104 : H12AffineEnvironment.transform 7 69 env45103 = env45104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45103 == env45104) = true)

theorem identity45104 : scanCanonicalize (H12AffineFastState.compose env45104 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45104 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env45105 : List Nat := [2,4,8,0,11,64,128,69,0,4,2048,1,140,64,133,140,64,12,4,132,0,136,65,141,5,1,64,1,65,2059,129,196,68,64,0,0]

theorem envBound45105 : H12AffineFastState.Bounded env45105 := by
  intro p hp
  have h : env45105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45104_45105 : H12AffineEnvironment.transform 4 11 env45104 = env45105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45104 == env45105) = true)

theorem identity45105 : scanCanonicalize (H12AffineFastState.compose env45105 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 196) := by decide +kernel

theorem selectedBound45105 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env45106 : List Nat := [2,4,8,0,11,64,128,69,0,4,196,1,140,64,133,140,64,12,4,132,0,136,65,141,5,1,64,1,65,207,129,196,68,64,0,0]

theorem envBound45106 : H12AffineFastState.Bounded env45106 := by
  intro p hp
  have h : env45106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45105_45106 : H12AffineEnvironment.transform 10 196 env45105 = env45106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 196 env45105 == env45106) = true)

theorem identity45106 : scanCanonicalize (H12AffineFastState.compose env45106 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound45106 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env45107 : List Nat := [2,4,8,0,11,64,69,69,0,4,1,1,73,64,64,73,64,12,4,65,0,77,65,72,5,1,64,1,65,10,68,1,68,64,0,0]

theorem envBound45107 : H12AffineFastState.Bounded env45107 := by
  intro p hp
  have h : env45107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45106_45107 : H12AffineEnvironment.transform 6 69 env45106 = env45107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env45106 == env45107) = true)

theorem identity45107 : scanCanonicalize (H12AffineFastState.compose env45107 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45107 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45108 : List Nat := [2,4,5,0,6,64,69,69,0,4,1,1,68,64,64,68,64,1,4,65,0,64,65,69,5,1,64,1,65,7,68,1,68,64,0,0]

theorem envBound45108 : H12AffineFastState.Bounded env45108 := by
  intro p hp
  have h : env45108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45107_45108 : H12AffineEnvironment.transform 2 5 env45107 = env45108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45107 == env45108) = true)

theorem identity45108 : scanCanonicalize (H12AffineFastState.compose env45108 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45109 : List Nat := [2,3,2,0,1,64,66,66,0,3,1,1,67,64,64,67,64,1,3,65,0,64,65,66,2,1,64,1,65,0,67,1,67,64,0,0]

theorem envBound45109 : H12AffineFastState.Bounded env45109 := by
  intro p hp
  have h : env45109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45108_45109 : H12AffineEnvironment.transform 1 3 env45108 = env45109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45108 == env45109) = true)

theorem identity45109 : scanCanonicalize (H12AffineFastState.compose env45109 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound45109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45110 : List Nat := [2,3,2,0,1,1,3,3,0,3,1,1,2,1,1,2,1,1,3,0,0,1,0,3,2,1,1,1,0,0,2,1,2,1,0,0]

theorem envBound45110 : H12AffineFastState.Bounded env45110 := by
  intro p hp
  have h : env45110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45109_45110 : H12AffineEnvironment.transform 5 1 env45109 = env45110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45109 == env45110) = true)

def env45111 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,8192,65,8524,482,8396,354,320,8525,1,460,8396,483,8328,8332,302,8332,64,10728,8205,196,257,64,0,325]

theorem envBound45111 : H12AffineFastState.Bounded env45111 := by
  intro p hp
  have h : env45111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45101_45111 : H12AffineEnvironment.transform 3 1 env45101 = env45111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45101 == env45111) = true)

theorem identity45111 : scanCanonicalize (H12AffineFastState.compose env45111 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45111 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45112 : List Nat := [2,4,8,1,32,64,128,68,0,5,2048,0,8192,65,8200,166,8396,38,4,8201,1,136,8396,167,8328,8332,106,8332,64,10412,8205,196,69,64,0,1]

theorem envBound45112 : H12AffineFastState.Bounded env45112 := by
  intro p hp
  have h : env45112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45111_45112 : H12AffineEnvironment.transform 7 68 env45111 = env45112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45111 == env45112) = true)

theorem identity45112 : scanCanonicalize (H12AffineFastState.compose env45112 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound45112 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45113 : List Nat := [2,4,8,1,32,64,68,68,0,5,2048,0,8192,65,8200,98,8200,38,4,8201,1,76,8200,99,8268,8264,106,8264,64,10344,8205,0,69,64,0,1]

theorem envBound45113 : H12AffineFastState.Bounded env45113 := by
  intro p hp
  have h : env45113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45112_45113 : H12AffineEnvironment.transform 6 68 env45112 = env45113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env45112 == env45113) = true)

theorem identity45113 : scanCanonicalize (H12AffineFastState.compose env45113 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound45113 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45114 : List Nat := [2,4,8,1,32,64,68,68,0,5,2048,0,9,65,1,98,1,38,4,0,1,76,1,99,69,65,106,65,64,2145,4,0,69,64,0,1]

theorem envBound45114 : H12AffineFastState.Bounded env45114 := by
  intro p hp
  have h : env45114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45113_45114 : H12AffineEnvironment.transform 12 9 env45113 = env45114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env45113 == env45114) = true)

theorem identity45114 : scanCanonicalize (H12AffineFastState.compose env45114 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound45114 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45115 : List Nat := [2,4,8,1,32,64,68,68,0,5,12,0,9,65,1,98,1,38,4,0,1,76,1,99,69,65,106,65,64,109,4,0,69,64,0,1]

theorem envBound45115 : H12AffineFastState.Bounded env45115 := by
  intro p hp
  have h : env45115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45114_45115 : H12AffineEnvironment.transform 10 12 env45114 = env45115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env45114 == env45115) = true)

theorem identity45115 : scanCanonicalize (H12AffineFastState.compose env45115 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45115 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45116 : List Nat := [2,4,2,1,32,64,68,68,0,5,6,0,3,65,1,98,1,38,4,0,1,70,1,99,69,65,96,65,64,103,4,0,69,64,0,1]

theorem envBound45116 : H12AffineFastState.Bounded env45116 := by
  intro p hp
  have h : env45116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45115_45116 : H12AffineEnvironment.transform 2 2 env45115 = env45116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45115 == env45116) = true)

theorem identity45116 : scanCanonicalize (H12AffineFastState.compose env45116 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound45116 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45117 : List Nat := [2,4,2,1,32,7,3,3,0,5,6,0,3,6,1,37,1,38,4,0,1,1,1,36,2,6,39,6,7,32,4,0,2,7,0,1]

theorem envBound45117 : H12AffineFastState.Bounded env45117 := by
  intro p hp
  have h : env45117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45116_45117 : H12AffineEnvironment.transform 5 7 env45116 = env45117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env45116 == env45117) = true)

theorem identity45117 : scanCanonicalize (H12AffineFastState.compose env45117 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45117 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45118 : List Nat := [2,4,2,1,6,7,3,3,0,5,6,0,3,6,1,3,1,0,4,0,1,1,1,2,2,6,1,6,7,6,4,0,2,7,0,1]

theorem envBound45118 : H12AffineFastState.Bounded env45118 := by
  intro p hp
  have h : env45118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45117_45118 : H12AffineEnvironment.transform 4 6 env45117 = env45118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45117 == env45118) = true)

theorem identity45118 : scanCanonicalize (H12AffineFastState.compose env45118 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45119 : List Nat := [2,0,2,1,2,3,3,3,0,1,2,0,3,2,1,3,1,0,0,0,1,1,1,2,2,2,1,2,3,2,0,0,2,3,0,1]

theorem envBound45119 : H12AffineFastState.Bounded env45119 := by
  intro p hp
  have h : env45119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45118_45119 : H12AffineEnvironment.transform 1 0 env45118 = env45119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45118 == env45119) = true)

theorem identity45119 : scanCanonicalize (H12AffineFastState.compose env45119 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45119 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env45120 : List Nat := [0,0,0,1,0,1,1,1,0,1,0,0,1,0,1,1,1,0,0,0,1,1,1,0,0,0,1,0,1,0,0,0,0,1,0,1]

theorem envBound45120 : H12AffineFastState.Bounded env45120 := by
  intro p hp
  have h : env45120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45119_45120 : H12AffineEnvironment.transform 0 0 env45119 = env45120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45119 == env45120) = true)

def env45121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4097,477,74047,69648,13769,78895,4414,74814,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound45121 : H12AffineFastState.Bounded env45121 := by
  intro p hp
  have h : env45121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45037_45121 : H12AffineEnvironment.transform 17 65665 env45037 = env45121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45037 == env45121) = true)

theorem identity45121 : scanCanonicalize (H12AffineFastState.compose env45121 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound45121 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,1,477,74047,65552,9673,74799,318,74814,1296,77131,8205,65830,257,1281,1345,1856]

theorem envBound45122 : H12AffineFastState.Bounded env45122 := by
  intro p hp
  have h : env45122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45121_45122 : H12AffineEnvironment.transform 11 0 env45121 = env45122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env45121 == env45122) = true)

def env45123 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,1,477,74047,65552,9673,74799,318,74814,1296,77131,8205,65830,257,1281,1345,1044]

theorem envBound45123 : H12AffineFastState.Bounded env45123 := by
  intro p hp
  have h : env45123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45122_45123 : H12AffineEnvironment.transform 8 340 env45122 = env45123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env45122 == env45123) = true)

def env45124 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9228,65536,74863,65665,320,9229,1,461,74031,65536,9673,74799,302,74798,1280,77131,8205,65830,257,1281,1345,1028]

theorem envBound45124 : H12AffineFastState.Bounded env45124 := by
  intro p hp
  have h : env45124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45123_45124 : H12AffineEnvironment.transform 3 0 env45123 = env45124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45123 == env45124) = true)

theorem identity45124 : scanCanonicalize (H12AffineFastState.compose env45124 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 453) := by decide +kernel

theorem selectedBound45124 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45125 : List Nat := [2,4,8,0,32,64,128,256,324,453,2048,0,8192,196,8649,65536,74154,65665,320,8648,1,461,74031,65536,8204,74218,302,74219,197,75918,8205,65830,257,196,132,449]

theorem envBound45125 : H12AffineFastState.Bounded env45125 := by
  intro p hp
  have h : env45125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45124_45125 : H12AffineEnvironment.transform 9 453 env45124 = env45125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 453 env45124 == env45125) = true)

def env45126 : List Nat := [2,4,8,0,32,64,128,256,324,453,2048,0,8192,196,8649,484,8270,357,320,8648,1,461,8395,484,8204,8206,302,8207,197,10602,8205,194,257,196,132,449]

theorem envBound45126 : H12AffineFastState.Bounded env45126 := by
  intro p hp
  have h : env45126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45125_45126 : H12AffineEnvironment.transform 15 484 env45125 = env45126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 484 env45125 == env45126) = true)

theorem identity45126 : scanCanonicalize (H12AffineFastState.compose env45126 (packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound45126 : packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45127 : List Nat := [2,4,8,0,32,64,128,104,44,173,2048,0,8192,196,8353,140,8270,13,40,8352,1,165,8395,140,8204,8206,70,8207,197,10242,8205,194,105,196,132,169]

theorem envBound45127 : H12AffineFastState.Bounded env45127 := by
  intro p hp
  have h : env45127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45126_45127 : H12AffineEnvironment.transform 7 104 env45126 = env45127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env45126 == env45127) = true)

theorem identity45127 : scanCanonicalize (H12AffineFastState.compose env45127 (packedSelected [1,2,3,5,8,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 236) := by decide +kernel

theorem selectedBound45127 : packedSelected [1,2,3,5,8,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env45128 : List Nat := [2,4,8,0,32,64,128,104,44,173,2048,0,236,196,77,140,162,13,40,76,1,165,39,140,224,226,70,227,197,2286,225,194,105,196,132,169]

theorem envBound45128 : H12AffineFastState.Bounded env45128 := by
  intro p hp
  have h : env45128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45127_45128 : H12AffineEnvironment.transform 12 236 env45127 = env45128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 236 env45127 == env45128) = true)

theorem identity45128 : scanCanonicalize (H12AffineFastState.compose env45128 (packedSelected [2,3,7,9,10,11,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound45128 : packedSelected [2,3,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env45129 : List Nat := [2,4,8,0,32,10,128,34,44,173,2048,0,166,142,7,140,162,13,40,6,1,165,39,140,170,168,12,169,143,2212,171,136,35,142,132,169]

theorem envBound45129 : H12AffineFastState.Bounded env45129 := by
  intro p hp
  have h : env45129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45128_45129 : H12AffineEnvironment.transform 5 10 env45128 = env45129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env45128 == env45129) = true)

theorem identity45129 : scanCanonicalize (H12AffineFastState.compose env45129 (packedSelected [2,3,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45129 : packedSelected [2,3,10,11,12] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2