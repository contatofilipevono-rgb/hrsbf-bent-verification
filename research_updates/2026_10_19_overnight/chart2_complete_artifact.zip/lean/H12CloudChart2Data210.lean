import H12CloudChart2Data209

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52885 : scanCanonicalize (H12AffineFastState.compose env52885 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52885 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52886 : List Nat := [2,4,8,16,16,16,128,256,137,272,1,0,268,1,0,18,1,147,273,1,0,396,17,3,389,17,270,1,1,277,256,16,256,261,0,137]

theorem envBound52886 : H12AffineFastState.Bounded env52886 := by
  intro p hp
  have h : env52886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52885_52886 : H12AffineEnvironment.transform 4 16 env52885 = env52886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52885 == env52886) = true)

theorem identity52886 : scanCanonicalize (H12AffineFastState.compose env52886 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52886 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52887 : List Nat := [2,4,8,16,16,16,128,20,137,4,1,0,24,1,0,18,1,147,5,1,0,152,17,3,145,17,26,1,1,1,20,16,20,17,0,137]

theorem envBound52887 : H12AffineFastState.Bounded env52887 := by
  intro p hp
  have h : env52887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52886_52887 : H12AffineEnvironment.transform 7 20 env52886 = env52887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52886 == env52887) = true)

theorem identity52887 : scanCanonicalize (H12AffineFastState.compose env52887 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound52887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52888 : List Nat := [2,4,8,13,13,13,128,9,137,4,1,0,5,1,0,15,1,142,5,1,0,133,12,3,140,12,7,1,1,1,9,13,9,12,0,137]

theorem envBound52888 : H12AffineFastState.Bounded env52888 := by
  intro p hp
  have h : env52888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52887_52888 : H12AffineEnvironment.transform 3 13 env52887 = env52888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env52887 == env52888) = true)

theorem identity52888 : scanCanonicalize (H12AffineFastState.compose env52888 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52888 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52889 : List Nat := [2,4,8,13,13,13,9,9,0,4,1,0,5,1,0,15,1,7,5,1,0,12,12,3,5,12,7,1,1,1,9,13,9,12,0,0]

theorem envBound52889 : H12AffineFastState.Bounded env52889 := by
  intro p hp
  have h : env52889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52888_52889 : H12AffineEnvironment.transform 6 9 env52888 = env52889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52888 == env52889) = true)

theorem identity52889 : scanCanonicalize (H12AffineFastState.compose env52889 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52889 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52890 : List Nat := [2,2,8,11,11,11,9,9,0,2,1,0,3,1,0,9,1,1,3,1,0,10,10,3,3,10,1,1,1,1,9,11,9,10,0,0]

theorem envBound52890 : H12AffineFastState.Bounded env52890 := by
  intro p hp
  have h : env52890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52889_52890 : H12AffineEnvironment.transform 1 2 env52889 = env52890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52889 == env52890) = true)

def env52891 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8495,1,8622,4417,8541,4096,4573,16,8511,12424,4161,319,81,80,6436,8204,65,256,8200,1,4609]

theorem envBound52891 : H12AffineFastState.Bounded env52891 := by
  intro p hp
  have h : env52891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52879_52891 : H12AffineEnvironment.transform 9 321 env52879 = env52891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52879 == env52891) = true)

theorem identity52891 : scanCanonicalize (H12AffineFastState.compose env52891 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound52891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52892 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,80,4421,4406,1,4535,4417,4420,4096,4573,16,4390,145,4161,319,81,80,6436,4117,65,256,4113,1,4609]

theorem envBound52892 : H12AffineFastState.Bounded env52892 := by
  intro p hp
  have h : env52892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52891_52892 : H12AffineEnvironment.transform 12 4121 env52891 = env52892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env52891 == env52892) = true)

theorem identity52892 : scanCanonicalize (H12AffineFastState.compose env52892 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound52892 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env52893 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,648,657,80,973,958,1,831,969,972,648,853,16,942,145,713,319,81,80,2988,669,65,256,665,1,137]

theorem envBound52893 : H12AffineFastState.Bounded env52893 := by
  intro p hp
  have h : env52893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52892_52893 : H12AffineEnvironment.transform 11 648 env52892 = env52893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env52892 == env52893) = true)

theorem identity52893 : scanCanonicalize (H12AffineFastState.compose env52893 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52893 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env52894 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,648,657,80,649,762,1,635,653,648,648,529,16,746,145,713,123,81,80,2792,669,65,68,665,1,137]

theorem envBound52894 : H12AffineFastState.Bounded env52894 := by
  intro p hp
  have h : env52894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52893_52894 : H12AffineEnvironment.transform 7 68 env52893 = env52894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52893 == env52894) = true)

theorem identity52894 : scanCanonicalize (H12AffineFastState.compose env52894 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 707) := by decide +kernel

theorem selectedBound52894 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env52895 : List Nat := [2,4,8,16,32,64,128,68,512,5,707,648,657,80,649,762,1,635,653,648,648,529,16,746,145,713,123,81,80,43,669,65,68,665,1,137]

theorem envBound52895 : H12AffineFastState.Bounded env52895 := by
  intro p hp
  have h : env52895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52894_52895 : H12AffineEnvironment.transform 10 707 env52894 = env52895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 707 env52894 == env52895) = true)

theorem identity52895 : scanCanonicalize (H12AffineFastState.compose env52895 (packedSelected [3,4,5,9,10,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52895 : packedSelected [3,4,5,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env52896 : List Nat := [2,4,8,16,32,64,128,68,137,5,74,1,24,80,0,115,1,242,4,1,1,152,16,99,145,64,123,81,80,43,20,65,68,16,1,137]

theorem envBound52896 : H12AffineFastState.Bounded env52896 := by
  intro p hp
  have h : env52896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52895_52896 : H12AffineEnvironment.transform 8 137 env52895 = env52896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52895 == env52896) = true)

theorem identity52896 : scanCanonicalize (H12AffineFastState.compose env52896 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52896 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52897 : List Nat := [2,4,8,16,11,64,128,68,137,5,74,1,24,80,0,88,1,217,4,1,1,152,16,72,145,64,80,81,80,0,20,65,68,16,1,137]

theorem envBound52897 : H12AffineFastState.Bounded env52897 := by
  intro p hp
  have h : env52897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52896_52897 : H12AffineEnvironment.transform 4 11 env52896 = env52897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52896 == env52897) = true)

theorem identity52897 : scanCanonicalize (H12AffineFastState.compose env52897 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52897 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env52898 : List Nat := [2,4,8,16,11,16,128,20,137,5,26,1,24,0,0,8,1,137,4,1,1,152,16,24,145,16,0,1,0,0,20,17,20,16,1,137]

theorem envBound52898 : H12AffineFastState.Bounded env52898 := by
  intro p hp
  have h : env52898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52897_52898 : H12AffineEnvironment.transform 5 16 env52897 = env52898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52897 == env52898) = true)

theorem identity52898 : scanCanonicalize (H12AffineFastState.compose env52898 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound52898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52899 : List Nat := [2,4,8,13,11,13,128,9,137,5,7,1,5,0,0,8,1,137,4,1,1,133,13,5,140,13,0,1,0,0,9,12,9,13,1,137]

theorem envBound52899 : H12AffineFastState.Bounded env52899 := by
  intro p hp
  have h : env52899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52898_52899 : H12AffineEnvironment.transform 3 13 env52898 = env52899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env52898 == env52899) = true)

theorem identity52899 : scanCanonicalize (H12AffineFastState.compose env52899 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52900 : List Nat := [2,3,8,10,11,10,128,9,137,2,0,1,2,0,0,8,1,137,3,1,1,130,10,2,139,10,0,1,0,0,9,11,9,10,1,137]

theorem envBound52900 : H12AffineFastState.Bounded env52900 := by
  intro p hp
  have h : env52900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52899_52900 : H12AffineEnvironment.transform 1 3 env52899 = env52900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52899 == env52900) = true)

def env52901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123164,28889,78894,385202,90414,1296,96347,25885,1280,256,82999,1344,21072]

theorem envBound52901 : H12AffineFastState.Bounded env52901 := by
  intro p hp
  have h : env52901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52807_52901 : H12AffineEnvironment.transform 18 21585 env52807 = env52901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env52807 == env52901) = true)

theorem identity52901 : scanCanonicalize (H12AffineFastState.compose env52901 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52901 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4096,17612,91182,87297,28889,78894,349359,90414,1296,96347,25885,1280,256,82999,1344,21072]

theorem envBound52902 : H12AffineFastState.Bounded env52902 := by
  intro p hp
  have h : env52902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52901_52902 : H12AffineEnvironment.transform 14 13341 env52901 = env52902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52901 == env52902) = true)

def env52903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4096,476,74046,69649,13769,78894,332223,74814,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound52903 : H12AffineFastState.Bounded env52903 := by
  intro p hp
  have h : env52903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52902_52903 : H12AffineEnvironment.transform 13 1296 env52902 = env52903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52902 == env52903) = true)

def env52904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4096,476,74046,69649,13769,78894,4415,74814,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound52904 : H12AffineFastState.Bounded env52904 := by
  intro p hp
  have h : env52904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52903_52904 : H12AffineEnvironment.transform 17 65664 env52903 = env52904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52903 == env52904) = true)

theorem identity52904 : scanCanonicalize (H12AffineFastState.compose env52904 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound52904 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,359,9480,487,4417,13340,4096,476,8281,4470,13769,13641,4415,9561,1296,15404,8205,1280,256,64,1344,5952]

theorem envBound52905 : H12AffineFastState.Bounded env52905 := by
  intro p hp
  have h : env52905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52904_52905 : H12AffineEnvironment.transform 15 359 env52904 = env52905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env52904 == env52905) = true)

def env52906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,359,1344,487,4417,5204,4096,476,17,4470,5505,5377,4415,1297,1296,7268,69,1280,256,64,1344,5952]

theorem envBound52906 : H12AffineFastState.Bounded env52906 := by
  intro p hp
  have h : env52906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52905_52906 : H12AffineEnvironment.transform 12 72 env52905 = env52906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env52905 == env52906) = true)

theorem identity52906 : scanCanonicalize (H12AffineFastState.compose env52906 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52906 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52907 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,72,1108,5205,35,1028,163,4101,5204,4096,152,17,4146,5317,5189,4219,1109,1108,7268,69,1092,68,64,1028,5636]

theorem envBound52907 : H12AffineFastState.Bounded env52907 := by
  intro p hp
  have h : env52907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52906_52907 : H12AffineEnvironment.transform 7 68 env52906 = env52907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52906 == env52907) = true)

theorem identity52907 : scanCanonicalize (H12AffineFastState.compose env52907 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound52907 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52908 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,72,1108,81,35,1028,163,1025,80,1028,152,17,1078,193,65,1151,1109,1108,2144,69,1092,68,64,1028,512]

theorem envBound52908 : H12AffineFastState.Bounded env52908 := by
  intro p hp
  have h : env52908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52907_52908 : H12AffineEnvironment.transform 11 1028 env52907 = env52908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env52907 == env52908) = true)

theorem identity52908 : scanCanonicalize (H12AffineFastState.compose env52908 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound52908 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52909 : List Nat := [2,4,8,16,32,64,128,68,512,1024,147,1028,72,1108,81,35,1028,163,1025,80,1028,152,17,1078,193,65,1151,1109,1108,243,69,1092,68,64,1028,512]

theorem envBound52909 : H12AffineFastState.Bounded env52909 := by
  intro p hp
  have h : env52909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52908_52909 : H12AffineEnvironment.transform 10 147 env52908 = env52909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env52908 == env52909) = true)

theorem identity52909 : scanCanonicalize (H12AffineFastState.compose env52909 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound52909 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52910 : List Nat := [2,4,8,16,32,64,128,68,49,1024,147,1028,72,1108,81,35,1028,163,1025,80,1028,152,17,1078,193,65,1151,1109,1108,243,69,1092,68,64,1028,49]

theorem envBound52910 : H12AffineFastState.Bounded env52910 := by
  intro p hp
  have h : env52910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52909_52910 : H12AffineEnvironment.transform 8 49 env52909 = env52910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env52909 == env52910) = true)

theorem identity52910 : scanCanonicalize (H12AffineFastState.compose env52910 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52910 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52911 : List Nat := [2,4,8,16,32,17,128,21,49,1024,147,1028,25,1029,0,35,1028,163,1025,1,1028,152,17,1078,144,16,1070,1028,1029,162,20,1045,21,17,1028,49]

theorem envBound52911 : H12AffineFastState.Bounded env52911 := by
  intro p hp
  have h : env52911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52910_52911 : H12AffineEnvironment.transform 5 17 env52910 = env52911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52910 == env52911) = true)

theorem identity52911 : scanCanonicalize (H12AffineFastState.compose env52911 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52911 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52912 : List Nat := [2,4,8,16,32,17,8,21,49,1024,27,1028,25,1029,0,35,1028,43,1025,1,1028,16,17,1078,24,16,1070,1028,1029,42,20,1045,21,17,1028,49]

theorem envBound52912 : H12AffineFastState.Bounded env52912 := by
  intro p hp
  have h : env52912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52911_52912 : H12AffineEnvironment.transform 6 8 env52911 = env52912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52911 == env52912) = true)

theorem identity52912 : scanCanonicalize (H12AffineFastState.compose env52912 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound52912 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52913 : List Nat := [2,4,8,16,32,17,8,21,49,52,27,48,25,49,0,35,48,43,53,1,48,16,17,2,24,16,26,48,49,42,20,33,21,17,48,49]

theorem envBound52913 : H12AffineFastState.Bounded env52913 := by
  intro p hp
  have h : env52913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52912_52913 : H12AffineEnvironment.transform 9 52 env52912 = env52913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52912 == env52913) = true)

theorem identity52913 : scanCanonicalize (H12AffineFastState.compose env52913 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52913 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52914 : List Nat := [2,4,8,11,32,10,8,14,42,47,0,43,2,42,0,35,43,43,46,1,43,11,10,2,3,11,1,43,42,42,15,33,14,10,43,42]

theorem envBound52914 : H12AffineFastState.Bounded env52914 := by
  intro p hp
  have h : env52914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52913_52914 : H12AffineEnvironment.transform 3 11 env52913 = env52914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52913 == env52914) = true)

def env52915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,359,1345,487,4417,5205,4096,476,16,4470,5504,5376,4415,1296,1296,7269,68,1280,256,64,1344,5952]

theorem envBound52915 : H12AffineFastState.Bounded env52915 := by
  intro p hp
  have h : env52915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52905_52915 : H12AffineEnvironment.transform 12 73 env52905 = env52915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env52905 == env52915) = true)

theorem identity52915 : scanCanonicalize (H12AffineFastState.compose env52915 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound52915 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1296,1028,359,1345,487,273,1029,80,476,16,294,1488,1360,367,1296,1296,3125,68,1280,256,64,1344,1808]

theorem envBound52916 : H12AffineFastState.Bounded env52916 := by
  intro p hp
  have h : env52916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52915_52916 : H12AffineEnvironment.transform 11 80 env52915 = env52916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env52915 == env52916) = true)

theorem identity52916 : scanCanonicalize (H12AffineFastState.compose env52916 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52916 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52917 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,73,1212,1028,203,1261,75,189,1029,80,112,16,138,1148,1276,195,1212,1212,3125,68,1196,172,64,1260,1724]

theorem envBound52917 : H12AffineFastState.Bounded env52917 := by
  intro p hp
  have h : env52917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52916_52917 : H12AffineEnvironment.transform 7 172 env52916 = env52917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52916 == env52917) = true)

theorem identity52917 : scanCanonicalize (H12AffineFastState.compose env52917 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound52917 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env52918 : List Nat := [2,4,8,16,32,64,128,172,512,1024,538,80,73,1212,1028,203,1261,75,189,1029,80,112,16,138,1148,1276,195,1212,1212,1583,68,1196,172,64,1260,1724]

theorem envBound52918 : H12AffineFastState.Bounded env52918 := by
  intro p hp
  have h : env52918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52917_52918 : H12AffineEnvironment.transform 10 538 env52917 = env52918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env52917 == env52918) = true)

theorem identity52918 : scanCanonicalize (H12AffineFastState.compose env52918 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound52918 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env52919 : List Nat := [2,4,8,16,32,64,67,111,512,1024,538,80,73,1151,1028,8,1070,75,126,1029,80,112,16,73,1148,1087,0,1151,1151,1583,68,1135,111,64,1071,1663]

theorem envBound52919 : H12AffineFastState.Bounded env52919 := by
  intro p hp
  have h : env52919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52918_52919 : H12AffineEnvironment.transform 6 67 env52918 = env52919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env52918 == env52919) = true)

theorem identity52919 : scanCanonicalize (H12AffineFastState.compose env52919 (packedSelected [2,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound52919 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env52920 : List Nat := [2,4,8,16,32,64,67,111,74,1024,80,80,73,1151,1028,8,1070,75,126,1029,80,112,16,73,1148,1087,0,1151,1151,1125,68,1135,111,64,1071,1077]

theorem envBound52920 : H12AffineFastState.Bounded env52920 := by
  intro p hp
  have h : env52920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52919_52920 : H12AffineEnvironment.transform 8 74 env52919 = env52920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env52919 == env52920) = true)

theorem identity52920 : scanCanonicalize (H12AffineFastState.compose env52920 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound52920 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52921 : List Nat := [2,4,8,16,32,10,9,37,0,1024,26,26,3,1077,1028,8,1070,1,52,1029,26,58,16,3,1078,1087,0,1077,1077,1071,14,1061,37,10,1071,1077]

theorem envBound52921 : H12AffineFastState.Bounded env52921 := by
  intro p hp
  have h : env52921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52920_52921 : H12AffineEnvironment.transform 5 10 env52920 = env52921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env52920 == env52921) = true)

theorem identity52921 : scanCanonicalize (H12AffineFastState.compose env52921 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52921 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52922 : List Nat := [2,4,8,16,10,10,9,15,0,1024,26,26,3,1055,1028,8,1028,1,30,1029,26,16,16,3,1052,1045,0,1055,1055,1029,14,1039,15,10,1029,1055]

theorem envBound52922 : H12AffineFastState.Bounded env52922 := by
  intro p hp
  have h : env52922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52921_52922 : H12AffineEnvironment.transform 4 10 env52921 = env52922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52921 == env52922) = true)

theorem identity52922 : scanCanonicalize (H12AffineFastState.compose env52922 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52922 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52923 : List Nat := [2,4,8,11,10,10,9,15,0,1024,1,1,3,1028,1028,8,1028,1,5,1029,1,11,11,3,1031,1038,0,1028,1028,1029,14,1039,15,10,1029,1028]

theorem envBound52923 : H12AffineFastState.Bounded env52923 := by
  intro p hp
  have h : env52923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52922_52923 : H12AffineEnvironment.transform 3 11 env52922 = env52923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52922 == env52923) = true)

theorem identity52923 : scanCanonicalize (H12AffineFastState.compose env52923 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52924 : List Nat := [2,4,8,11,10,10,9,15,0,5,1,1,3,1,1,8,1,1,5,0,1,11,11,3,2,11,0,1,1,0,14,10,15,10,0,1]

theorem envBound52924 : H12AffineFastState.Bounded env52924 := by
  intro p hp
  have h : env52924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52923_52924 : H12AffineEnvironment.transform 9 5 env52923 = env52924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52923 == env52924) = true)

theorem identity52924 : scanCanonicalize (H12AffineFastState.compose env52924 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound52924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52925 : List Nat := [2,4,7,4,5,5,6,0,0,5,1,1,3,1,1,7,1,1,5,0,1,4,4,3,2,4,0,1,1,0,1,5,0,5,0,1]

theorem envBound52925 : H12AffineFastState.Bounded env52925 := by
  intro p hp
  have h : env52925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52924_52925 : H12AffineEnvironment.transform 2 7 env52924 = env52925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env52924 == env52925) = true)

theorem identity52925 : scanCanonicalize (H12AffineFastState.compose env52925 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52926 : List Nat := [2,3,0,3,2,2,1,0,0,2,1,1,3,1,1,0,1,1,2,0,1,3,3,3,2,3,0,1,1,0,1,2,0,2,0,1]

theorem envBound52926 : H12AffineFastState.Bounded env52926 := by
  intro p hp
  have h : env52926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52925_52926 : H12AffineEnvironment.transform 1 3 env52925 = env52926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52925 == env52926) = true)

theorem identity52926 : scanCanonicalize (H12AffineFastState.compose env52926 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52926 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52927 : List Nat := [0,1,0,1,0,0,1,0,0,0,1,1,1,1,1,0,1,1,0,0,1,1,1,1,0,1,0,1,1,0,1,0,0,0,0,1]

theorem envBound52927 : H12AffineFastState.Bounded env52927 := by
  intro p hp
  have h : env52927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52926_52927 : H12AffineEnvironment.transform 0 0 env52926 = env52927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52926 == env52927) = true)

def env52928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4096,476,74046,69649,13769,78894,4414,74814,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound52928 : H12AffineFastState.Bounded env52928 := by
  intro p hp
  have h : env52928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52903_52928 : H12AffineEnvironment.transform 17 65665 env52903 = env52928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52903 == env52928) = true)

theorem identity52928 : scanCanonicalize (H12AffineFastState.compose env52928 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound52928 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,12361,5287,4417,13340,4096,476,13592,1079,13769,8200,4414,12312,1296,10605,8205,1280,256,5377,1344,5952]

theorem envBound52929 : H12AffineFastState.Bounded env52929 := by
  intro p hp
  have h : env52929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52928_52929 : H12AffineEnvironment.transform 15 5158 env52928 = env52929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env52928 == env52929) = true)

def env52930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,5158,1345,5287,4417,276,4096,476,16,1079,193,5376,4414,1296,1296,7269,5381,1280,256,5377,1344,5952]

theorem envBound52930 : H12AffineFastState.Bounded env52930 := by
  intro p hp
  have h : env52930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52929_52930 : H12AffineEnvironment.transform 12 5384 env52929 = env52930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env52929 == env52930) = true)

theorem identity52930 : scanCanonicalize (H12AffineFastState.compose env52930 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52930 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52931 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,1,277,4407,80,4534,4417,276,4096,476,16,294,193,4113,4414,1,1,6516,4116,17,256,4112,81,4689]

theorem envBound52931 : H12AffineFastState.Bounded env52931 := by
  intro p hp
  have h : env52931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52930_52931 : H12AffineEnvironment.transform 9 273 env52930 = env52931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52930 == env52931) = true)

theorem identity52931 : scanCanonicalize (H12AffineFastState.compose env52931 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52931 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52932 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,4121,1,185,4251,80,4122,4333,184,4096,112,16,138,193,4113,4242,1,1,6360,4116,17,172,4112,81,4689]

theorem envBound52932 : H12AffineFastState.Bounded env52932 := by
  intro p hp
  have h : env52932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52931_52932 : H12AffineEnvironment.transform 7 172 env52931 = env52932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52931 == env52932) = true)

theorem identity52932 : scanCanonicalize (H12AffineFastState.compose env52932 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound52932 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env52933 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2635,2642,1,185,2768,80,2641,2726,184,2635,112,16,138,193,2650,2777,1,1,659,2655,17,172,2651,81,2074]

theorem envBound52933 : H12AffineFastState.Bounded env52933 := by
  intro p hp
  have h : env52933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52932_52933 : H12AffineEnvironment.transform 11 2635 env52932 = env52933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env52932 == env52933) = true)

theorem identity52933 : scanCanonicalize (H12AffineFastState.compose env52933 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 728) := by decide +kernel

theorem selectedBound52933 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env52934 : List Nat := [2,4,8,16,32,64,128,172,512,189,728,147,138,1,185,8,80,137,126,184,147,112,16,138,193,130,1,1,1,659,135,17,172,131,81,706]

theorem envBound52934 : H12AffineFastState.Bounded env52934 := by
  intro p hp
  have h : env52934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52933_52934 : H12AffineEnvironment.transform 10 728 env52933 = env52934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 728 env52933 == env52934) = true)

theorem identity52934 : scanCanonicalize (H12AffineFastState.compose env52934 (packedSelected [2,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound52934 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env52935 : List Nat := [2,4,8,16,32,64,128,172,216,189,0,147,138,1,185,8,80,137,126,184,147,112,16,138,193,130,1,1,1,75,135,17,172,131,81,26]

theorem envBound52935 : H12AffineFastState.Bounded env52935 := by
  intro p hp
  have h : env52935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52934_52935 : H12AffineEnvironment.transform 8 216 env52934 = env52935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env52934 == env52935) = true)

theorem identity52935 : scanCanonicalize (H12AffineFastState.compose env52935 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52935 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52936 : List Nat := [2,4,8,16,10,64,128,134,216,151,0,147,138,1,147,8,80,137,84,146,147,90,16,138,193,130,1,1,1,75,135,17,134,131,81,26]

theorem envBound52936 : H12AffineFastState.Bounded env52936 := by
  intro p hp
  have h : env52936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52935_52936 : H12AffineEnvironment.transform 4 10 env52935 = env52936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52935 == env52936) = true)

theorem identity52936 : scanCanonicalize (H12AffineFastState.compose env52936 (packedSelected [2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52936 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env52937 : List Nat := [2,4,8,10,10,64,128,134,194,141,0,137,138,1,137,8,74,137,78,136,137,64,10,138,193,130,1,1,1,75,135,11,134,131,75,0]

theorem envBound52937 : H12AffineFastState.Bounded env52937 := by
  intro p hp
  have h : env52937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52936_52937 : H12AffineEnvironment.transform 3 10 env52936 = env52937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52936 == env52937) = true)

theorem identity52937 : scanCanonicalize (H12AffineFastState.compose env52937 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52938 : List Nat := [2,4,8,10,10,64,8,14,74,5,0,1,2,1,1,8,74,1,78,0,1,64,10,2,73,10,1,1,1,75,15,11,14,11,75,0]

theorem envBound52938 : H12AffineFastState.Bounded env52938 := by
  intro p hp
  have h : env52938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52937_52938 : H12AffineEnvironment.transform 6 8 env52937 = env52938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52937 == env52938) = true)

theorem identity52938 : scanCanonicalize (H12AffineFastState.compose env52938 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound52938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52939 : List Nat := [2,4,8,10,10,13,8,14,7,5,0,1,2,1,1,8,7,1,3,0,1,13,10,2,4,10,1,1,1,6,15,11,14,11,6,0]

theorem envBound52939 : H12AffineFastState.Bounded env52939 := by
  intro p hp
  have h : env52939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52938_52939 : H12AffineEnvironment.transform 5 13 env52938 = env52939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env52938 == env52939) = true)

theorem identity52939 : scanCanonicalize (H12AffineFastState.compose env52939 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52939 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52940 : List Nat := [2,3,8,10,10,10,8,9,0,2,0,1,2,1,1,8,0,1,3,0,1,10,10,2,3,10,1,1,1,1,8,11,9,11,1,0]

theorem envBound52940 : H12AffineFastState.Bounded env52940 := by
  intro p hp
  have h : env52940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52939_52940 : H12AffineEnvironment.transform 1 3 env52939 = env52940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52939 == env52940) = true)

def env52941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,5158,1344,5287,4417,277,4096,476,17,1079,192,5377,4414,1297,1296,7268,5380,1280,256,5377,1344,5952]

theorem envBound52941 : H12AffineFastState.Bounded env52941 := by
  intro p hp
  have h : env52941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52929_52941 : H12AffineEnvironment.transform 12 5385 env52929 = env52941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env52929 == env52941) = true)

theorem identity52941 : scanCanonicalize (H12AffineFastState.compose env52941 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52941 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,268,1296,276,35,1344,162,1348,277,1029,476,17,1079,192,260,1339,1297,1296,2145,257,1280,256,260,1344,837]

theorem envBound52942 : H12AffineFastState.Bounded env52942 := by
  intro p hp
  have h : env52942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52941_52942 : H12AffineEnvironment.transform 11 1029 env52941 = env52942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52941 == env52942) = true)

theorem identity52942 : scanCanonicalize (H12AffineFastState.compose env52942 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52942 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env52943 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1029,268,1296,276,35,1344,162,1348,277,1029,476,17,1079,192,260,1339,1297,1296,2145,257,1280,256,260,1344,460]

theorem envBound52943 : H12AffineFastState.Bounded env52943 := by
  intro p hp
  have h : env52943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52942_52943 : H12AffineEnvironment.transform 8 137 env52942 = env52943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52942 == env52943) = true)

theorem identity52943 : scanCanonicalize (H12AffineFastState.compose env52943 (packedSelected [2,4,5,8,9,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1223) := by decide +kernel

theorem selectedBound52943 : packedSelected [2,4,5,8,9,16,17] rootPS < 2^1333 := by decide +kernel

def env52944 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1223,1029,268,1296,276,35,1344,162,1348,277,1029,476,17,1079,192,260,1339,1297,1296,1190,257,1280,256,260,1344,460]

theorem envBound52944 : H12AffineFastState.Bounded env52944 := by
  intro p hp
  have h : env52944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52943_52944 : H12AffineEnvironment.transform 10 1223 env52943 = env52944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1223 env52943 == env52944) = true)

theorem identity52944 : scanCanonicalize (H12AffineFastState.compose env52944 (packedSelected [2,4,9,10,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound52944 : packedSelected [2,4,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env52945 : List Nat := [2,4,8,16,32,64,128,256,137,320,391,325,268,80,276,35,0,162,4,277,325,476,17,375,192,260,123,81,80,486,257,64,256,260,0,460]

theorem envBound52945 : H12AffineFastState.Bounded env52945 := by
  intro p hp
  have h : env52945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52944_52945 : H12AffineEnvironment.transform 9 320 env52944 = env52945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52944 == env52945) = true)

theorem identity52945 : scanCanonicalize (H12AffineFastState.compose env52945 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52945 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52946 : List Nat := [2,4,8,16,32,64,128,68,137,4,195,1,72,80,80,35,0,162,4,81,1,152,17,51,192,64,123,81,80,162,69,64,68,64,0,136]

theorem envBound52946 : H12AffineFastState.Bounded env52946 := by
  intro p hp
  have h : env52946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52945_52946 : H12AffineEnvironment.transform 7 68 env52945 = env52946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52945 == env52946) = true)

theorem identity52946 : scanCanonicalize (H12AffineFastState.compose env52946 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound52946 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env52947 : List Nat := [2,4,8,16,32,22,128,18,137,4,149,1,30,6,6,35,0,162,4,7,1,152,17,51,150,22,45,7,6,162,19,22,18,22,0,136]

theorem envBound52947 : H12AffineFastState.Bounded env52947 := by
  intro p hp
  have h : env52947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52946_52947 : H12AffineEnvironment.transform 5 22 env52946 = env52947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env52946 == env52947) = true)

theorem identity52947 : scanCanonicalize (H12AffineFastState.compose env52947 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound52947 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52948 : List Nat := [2,4,8,16,32,22,46,18,39,4,59,1,30,6,6,35,0,12,4,7,1,54,17,51,56,22,45,7,6,12,19,22,18,22,0,38]

theorem envBound52948 : H12AffineFastState.Bounded env52948 := by
  intro p hp
  have h : env52948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52947_52948 : H12AffineEnvironment.transform 6 46 env52947 = env52948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env52947 == env52948) = true)

theorem identity52948 : scanCanonicalize (H12AffineFastState.compose env52948 (packedSelected [1,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52948 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env52949 : List Nat := [2,4,8,0,32,6,46,2,39,4,43,1,14,6,6,35,0,12,4,7,1,38,1,35,40,6,45,7,6,12,3,6,2,6,0,38]

theorem envBound52949 : H12AffineFastState.Bounded env52949 := by
  intro p hp
  have h : env52949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52948_52949 : H12AffineEnvironment.transform 3 0 env52948 = env52949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52948 == env52949) = true)

theorem identity52949 : scanCanonicalize (H12AffineFastState.compose env52949 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52949 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52950 : List Nat := [2,4,8,0,11,6,5,2,12,4,0,1,14,6,6,8,0,12,4,7,1,13,1,8,3,6,6,7,6,12,3,6,2,6,0,13]

theorem envBound52950 : H12AffineFastState.Bounded env52950 := by
  intro p hp
  have h : env52950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52949_52950 : H12AffineEnvironment.transform 4 11 env52949 = env52950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52949 == env52950) = true)

theorem identity52950 : scanCanonicalize (H12AffineFastState.compose env52950 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52951 : List Nat := [2,4,0,0,3,6,5,2,4,4,0,1,6,6,6,0,0,4,4,7,1,5,1,0,3,6,6,7,6,4,3,6,2,6,0,5]

theorem envBound52951 : H12AffineFastState.Bounded env52951 := by
  intro p hp
  have h : env52951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52950_52951 : H12AffineEnvironment.transform 2 0 env52950 = env52951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52950 == env52951) = true)

theorem identity52951 : scanCanonicalize (H12AffineFastState.compose env52951 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52951 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52952 : List Nat := [2,3,0,0,3,1,2,2,3,3,0,1,1,1,1,0,0,3,3,0,1,2,1,0,3,1,1,0,1,3,3,1,2,1,0,2]

theorem envBound52952 : H12AffineFastState.Bounded env52952 := by
  intro p hp
  have h : env52952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52951_52952 : H12AffineEnvironment.transform 1 3 env52951 = env52952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52951 == env52952) = true)

def env52953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4096,477,74047,69648,13768,78894,332222,74815,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound52953 : H12AffineFastState.Bounded env52953 := by
  intro p hp
  have h : env52953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52902_52953 : H12AffineEnvironment.transform 13 1297 env52902 = env52953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52902 == env52953) = true)

def env52954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4096,477,74047,69648,13768,78894,4414,74815,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound52954 : H12AffineFastState.Bounded env52954 := by
  intro p hp
  have h : env52954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52953_52954 : H12AffineEnvironment.transform 17 65664 env52953 = env52954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52953 == env52954) = true)

theorem identity52954 : scanCanonicalize (H12AffineFastState.compose env52954 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound52954 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,5441,12718,4416,13340,4096,477,4113,8510,13768,1280,4414,5393,1296,3172,8204,1280,256,12296,1344,5953]

theorem envBound52955 : H12AffineFastState.Bounded env52955 := by
  intro p hp
  have h : env52955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52954_52955 : H12AffineEnvironment.transform 15 12590 env52954 = env52955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env52954 == env52955) = true)

def env52956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,8494,1345,8622,320,9244,0,477,17,8510,9672,1280,318,1297,1296,3172,8204,1280,256,8200,1344,1857]

theorem envBound52956 : H12AffineFastState.Bounded env52956 := by
  intro p hp
  have h : env52956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52955_52956 : H12AffineEnvironment.transform 11 0 env52955 = env52956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52955 == env52956) = true)

theorem identity52956 : scanCanonicalize (H12AffineFastState.compose env52956 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound52956 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1297,325,1142,1345,1270,320,324,0,477,17,1126,144,1280,318,1297,1296,3172,1364,1280,256,1360,1344,1857]

theorem envBound52957 : H12AffineFastState.Bounded env52957 := by
  intro p hp
  have h : env52957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52956_52957 : H12AffineEnvironment.transform 12 1368 env52956 = env52957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env52956 == env52957) = true)

theorem identity52957 : scanCanonicalize (H12AffineFastState.compose env52957 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound52957 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52958 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,0,436,509,325,154,429,26,320,324,0,477,17,138,144,492,318,509,508,2184,440,492,256,444,428,941]

theorem envBound52958 : H12AffineFastState.Bounded env52958 := by
  intro p hp
  have h : env52958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52957_52958 : H12AffineEnvironment.transform 9 236 env52957 = env52958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env52957 == env52958) = true)

theorem identity52958 : scanCanonicalize (H12AffineFastState.compose env52958 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound52958 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env52959 : List Nat := [2,4,8,16,32,64,128,256,49,236,2048,0,436,509,325,154,429,26,320,324,0,477,17,138,144,492,318,509,508,2184,440,492,256,444,428,412]

theorem envBound52959 : H12AffineFastState.Bounded env52959 := by
  intro p hp
  have h : env52959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52958_52959 : H12AffineEnvironment.transform 8 49 env52958 = env52959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env52958 == env52959) = true)

theorem identity52959 : scanCanonicalize (H12AffineFastState.compose env52959 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound52959 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52960 : List Nat := [2,4,8,16,32,64,128,256,49,236,276,0,436,509,325,154,429,26,320,324,0,477,17,138,144,492,318,509,508,412,440,492,256,444,428,412]

theorem envBound52960 : H12AffineFastState.Bounded env52960 := by
  intro p hp
  have h : env52960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52959_52960 : H12AffineEnvironment.transform 10 276 env52959 = env52960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env52959 == env52960) = true)

theorem identity52960 : scanCanonicalize (H12AffineFastState.compose env52960 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52960 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52961 : List Nat := [2,4,8,16,32,64,18,256,49,126,276,0,294,367,325,8,319,26,320,324,0,335,17,24,2,382,318,367,366,270,298,382,256,302,318,270]

theorem envBound52961 : H12AffineFastState.Bounded env52961 := by
  intro p hp
  have h : env52961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52960_52961 : H12AffineEnvironment.transform 6 18 env52960 = env52961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52960 == env52961) = true)

theorem identity52961 : scanCanonicalize (H12AffineFastState.compose env52961 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52961 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env52962 : List Nat := [2,4,8,16,32,64,18,116,49,126,96,0,82,27,49,8,75,26,52,48,0,59,17,24,2,10,74,27,26,122,94,10,116,90,74,122]

theorem envBound52962 : H12AffineFastState.Bounded env52962 := by
  intro p hp
  have h : env52962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52961_52962 : H12AffineEnvironment.transform 7 116 env52961 = env52962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52961 == env52962) = true)

theorem identity52962 : scanCanonicalize (H12AffineFastState.compose env52962 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52962 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52963 : List Nat := [2,4,8,16,16,64,18,68,1,78,80,0,82,27,1,8,75,26,4,0,0,11,17,24,2,10,74,27,26,74,94,10,68,90,74,74]

theorem envBound52963 : H12AffineFastState.Bounded env52963 := by
  intro p hp
  have h : env52963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52962_52963 : H12AffineEnvironment.transform 4 16 env52962 = env52963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52962 == env52963) = true)

theorem identity52963 : scanCanonicalize (H12AffineFastState.compose env52963 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52963 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52964 : List Nat := [2,4,8,16,16,17,18,21,1,31,1,0,3,27,1,8,26,26,4,0,0,11,17,24,2,10,27,27,26,27,15,10,21,11,27,27]

theorem envBound52964 : H12AffineFastState.Bounded env52964 := by
  intro p hp
  have h : env52964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52963_52964 : H12AffineEnvironment.transform 5 17 env52963 = env52964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52963 == env52964) = true)

theorem identity52964 : scanCanonicalize (H12AffineFastState.compose env52964 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52964 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52965 : List Nat := [2,4,5,16,16,17,18,21,1,18,1,0,3,22,1,5,23,23,4,0,0,6,17,21,2,7,22,22,23,22,2,7,21,6,22,22]

theorem envBound52965 : H12AffineFastState.Bounded env52965 := by
  intro p hp
  have h : env52965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52964_52965 : H12AffineEnvironment.transform 2 5 env52964 = env52965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52964 == env52965) = true)

def env52966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,8495,1344,8623,321,9245,1,477,16,8510,9673,1280,319,1296,1296,3172,8204,1280,256,8201,1344,1856]

theorem envBound52966 : H12AffineFastState.Bounded env52966 := by
  intro p hp
  have h : env52966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52955_52966 : H12AffineEnvironment.transform 11 1 env52955 = env52966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52955 == env52966) = true)

theorem identity52966 : scanCanonicalize (H12AffineFastState.compose env52966 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound52966 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1101,1297,81,1378,1344,1506,321,80,1,477,16,1395,388,1280,319,1296,1296,3172,1089,1280,256,1092,1344,1856]

theorem envBound52967 : H12AffineFastState.Bounded env52967 := by
  intro p hp
  have h : env52967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52966_52967 : H12AffineEnvironment.transform 12 1101 env52966 = env52967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env52966 == env52967) = true)

theorem identity52967 : scanCanonicalize (H12AffineFastState.compose env52967 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound52967 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52968 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,269,81,81,34,0,162,321,80,1,477,16,51,388,64,319,80,80,2340,257,64,256,260,0,512]

theorem envBound52968 : H12AffineFastState.Bounded env52968 := by
  intro p hp
  have h : env52968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52967_52968 : H12AffineEnvironment.transform 9 320 env52967 = env52968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52967 == env52968) = true)

theorem identity52968 : scanCanonicalize (H12AffineFastState.compose env52968 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52968 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52969 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,0,0,34,0,162,272,1,1,396,16,51,388,17,319,1,1,2340,257,17,256,260,0,512]

theorem envBound52969 : H12AffineFastState.Bounded env52969 := by
  intro p hp
  have h : env52969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52968_52969 : H12AffineEnvironment.transform 5 17 env52968 = env52969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52968 == env52969) = true)

theorem identity52969 : scanCanonicalize (H12AffineFastState.compose env52969 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound52969 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52970 : List Nat := [2,4,8,16,32,17,128,256,512,273,554,1,269,0,0,34,0,162,272,1,1,396,16,51,388,17,319,1,1,782,257,17,256,260,0,512]

theorem envBound52970 : H12AffineFastState.Bounded env52970 := by
  intro p hp
  have h : env52970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52969_52970 : H12AffineEnvironment.transform 10 554 env52969 = env52970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env52969 == env52970) = true)

theorem identity52970 : scanCanonicalize (H12AffineFastState.compose env52970 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound52970 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52971 : List Nat := [2,4,8,16,32,17,128,256,412,273,438,1,269,0,0,34,0,162,272,1,1,396,16,51,388,17,319,1,1,146,257,17,256,260,0,412]

theorem envBound52971 : H12AffineFastState.Bounded env52971 := by
  intro p hp
  have h : env52971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52970_52971 : H12AffineEnvironment.transform 8 412 env52970 = env52971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env52970 == env52971) = true)

theorem identity52971 : scanCanonicalize (H12AffineFastState.compose env52971 (packedSelected [0,1,2,3,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52971 : packedSelected [0,1,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env52972 : List Nat := [2,4,8,16,32,17,128,173,49,188,27,1,160,0,0,34,0,162,189,1,1,33,16,51,41,17,146,1,1,146,172,17,173,169,0,49]

theorem envBound52972 : H12AffineFastState.Bounded env52972 := by
  intro p hp
  have h : env52972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52971_52972 : H12AffineEnvironment.transform 7 173 env52971 = env52972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52971 == env52972) = true)

theorem identity52972 : scanCanonicalize (H12AffineFastState.compose env52972 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52972 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52973 : List Nat := [2,4,8,11,32,10,128,173,42,167,0,1,160,0,0,34,0,162,166,1,1,33,11,40,41,10,137,1,1,137,172,10,173,169,0,42]

theorem envBound52973 : H12AffineFastState.Bounded env52973 := by
  intro p hp
  have h : env52973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52972_52973 : H12AffineEnvironment.transform 3 11 env52972 = env52973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52972 == env52973) = true)

theorem identity52973 : scanCanonicalize (H12AffineFastState.compose env52973 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52973 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env52974 : List Nat := [2,4,8,11,32,10,35,14,42,4,0,1,3,0,0,34,0,1,5,1,1,33,11,40,41,10,42,1,1,42,15,10,14,10,0,42]

theorem envBound52974 : H12AffineFastState.Bounded env52974 := by
  intro p hp
  have h : env52974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52973_52974 : H12AffineEnvironment.transform 6 35 env52973 = env52974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52973 == env52974) = true)

theorem identity52974 : scanCanonicalize (H12AffineFastState.compose env52974 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52975 : List Nat := [2,2,8,11,32,10,35,8,42,2,0,1,3,0,0,34,0,1,3,1,1,33,11,40,41,10,42,1,1,42,9,10,8,10,0,42]

theorem envBound52975 : H12AffineFastState.Bounded env52975 := by
  intro p hp
  have h : env52975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52974_52975 : H12AffineEnvironment.transform 1 2 env52974 = env52975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52974 == env52975) = true)

def env52976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4096,477,74047,69648,13768,78894,4415,74815,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound52976 : H12AffineFastState.Bounded env52976 := by
  intro p hp
  have h : env52976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52953_52976 : H12AffineEnvironment.transform 17 65665 env52953 = env52976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52953 == env52976) = true)

theorem identity52976 : scanCanonicalize (H12AffineFastState.compose env52976 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound52976 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,1,9455,4416,13340,4096,477,1361,13438,13768,4160,4415,81,1296,6436,8204,1280,256,9544,1344,5953]

theorem envBound52977 : H12AffineFastState.Bounded env52977 := by
  intro p hp
  have h : env52977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52976_52977 : H12AffineEnvironment.transform 15 9326 env52976 = env52977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env52976 == env52977) = true)

def env52978 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,8494,1,8623,4416,12636,4096,477,17,12606,12424,4160,4415,81,80,6436,8204,64,256,8200,0,4609]

theorem envBound52978 : H12AffineFastState.Bounded env52978 := by
  intro p hp
  have h : env52978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52977_52978 : H12AffineEnvironment.transform 9 320 env52977 = env52978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52977 == env52978) = true)

theorem identity52978 : scanCanonicalize (H12AffineFastState.compose env52978 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound52978 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52979 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,81,4421,310,1,439,4416,4420,4096,477,17,4390,4240,4160,4415,81,80,6436,20,64,256,16,0,4609]

theorem envBound52979 : H12AffineFastState.Bounded env52979 := by
  intro p hp
  have h : env52979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52978_52979 : H12AffineEnvironment.transform 12 24 env52978 = env52979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env52978 == env52979) = true)

theorem identity52979 : scanCanonicalize (H12AffineFastState.compose env52979 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound52979 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52980 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,428,24,81,233,310,1,439,236,232,428,477,17,138,316,492,147,81,80,2184,20,64,256,16,0,941]

theorem envBound52980 : H12AffineFastState.Bounded env52980 := by
  intro p hp
  have h : env52980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52979_52980 : H12AffineEnvironment.transform 11 428 env52979 = env52980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env52979 == env52980) = true)

theorem identity52980 : scanCanonicalize (H12AffineFastState.compose env52980 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound52980 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env52981 : List Nat := [2,4,8,16,32,64,128,256,413,320,2048,428,24,81,233,310,1,439,236,232,428,477,17,138,316,492,147,81,80,2184,20,64,256,16,0,48]

theorem envBound52981 : H12AffineFastState.Bounded env52981 := by
  intro p hp
  have h : env52981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52980_52981 : H12AffineEnvironment.transform 8 413 env52980 = env52981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env52980 == env52981) = true)

theorem identity52981 : scanCanonicalize (H12AffineFastState.compose env52981 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound52981 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52982 : List Nat := [2,4,8,16,32,64,128,256,413,320,277,428,24,81,233,310,1,439,236,232,428,477,17,138,316,492,147,81,80,413,20,64,256,16,0,48]

theorem envBound52982 : H12AffineFastState.Bounded env52982 := by
  intro p hp
  have h : env52982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52981_52982 : H12AffineEnvironment.transform 10 277 env52981 = env52982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env52981 == env52982) = true)

theorem identity52982 : scanCanonicalize (H12AffineFastState.compose env52982 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52982 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env52983 : List Nat := [2,4,8,16,32,64,128,172,49,236,185,0,24,81,233,154,1,27,236,232,0,113,17,138,144,64,147,81,80,49,20,64,172,16,0,48]

theorem envBound52983 : H12AffineFastState.Bounded env52983 := by
  intro p hp
  have h : env52983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52982_52983 : H12AffineEnvironment.transform 7 172 env52982 = env52983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52982 == env52983) = true)

theorem identity52983 : scanCanonicalize (H12AffineFastState.compose env52983 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound52983 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52984 : List Nat := [2,4,8,16,32,64,19,63,49,127,42,0,24,81,122,9,1,27,127,123,0,113,17,25,3,64,0,81,80,49,20,64,63,16,0,48]

theorem envBound52984 : H12AffineFastState.Bounded env52984 := by
  intro p hp
  have h : env52984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52983_52984 : H12AffineEnvironment.transform 6 19 env52983 = env52984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env52983 == env52984) = true)

theorem identity52984 : scanCanonicalize (H12AffineFastState.compose env52984 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound52984 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52985 : List Nat := [2,4,8,16,32,24,19,63,49,39,42,0,24,9,34,9,1,27,39,35,0,41,17,25,3,24,0,9,8,49,20,24,63,16,0,48]

theorem envBound52985 : H12AffineFastState.Bounded env52985 := by
  intro p hp
  have h : env52985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52984_52985 : H12AffineEnvironment.transform 5 24 env52984 = env52985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env52984 == env52985) = true)

theorem identity52985 : scanCanonicalize (H12AffineFastState.compose env52985 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound52985 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52986 : List Nat := [2,4,8,16,27,24,19,4,10,28,17,0,24,9,25,9,1,27,28,24,0,18,17,25,3,24,0,9,8,10,20,24,4,16,0,11]

theorem envBound52986 : H12AffineFastState.Bounded env52986 := by
  intro p hp
  have h : env52986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52985_52986 : H12AffineEnvironment.transform 4 27 env52985 = env52986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env52985 == env52986) = true)

theorem identity52986 : scanCanonicalize (H12AffineFastState.compose env52986 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52987 : List Nat := [2,4,5,16,22,21,19,4,7,17,17,0,21,4,20,4,1,22,17,21,0,18,17,20,3,21,0,4,5,7,20,21,4,16,0,6]

theorem envBound52987 : H12AffineFastState.Bounded env52987 := by
  intro p hp
  have h : env52987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52986_52987 : H12AffineEnvironment.transform 2 5 env52986 = env52987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52986 == env52987) = true)

theorem identity52987 : scanCanonicalize (H12AffineFastState.compose env52987 (packedSelected [0,8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound52987 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env52988 : List Nat := [2,0,1,16,18,17,19,0,3,17,17,0,17,0,16,0,1,18,17,17,0,18,17,16,3,17,0,0,1,3,16,17,0,16,0,2]

theorem envBound52988 : H12AffineFastState.Bounded env52988 := by
  intro p hp
  have h : env52988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52987_52988 : H12AffineEnvironment.transform 1 0 env52987 = env52988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env52987 == env52988) = true)

theorem identity52988 : scanCanonicalize (H12AffineFastState.compose env52988 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound52988 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52989 : List Nat := [2,0,1,3,1,2,0,0,3,2,2,0,2,0,3,0,1,1,2,2,0,1,2,3,3,2,0,0,1,3,3,2,0,3,0,2]

theorem envBound52989 : H12AffineFastState.Bounded env52989 := by
  intro p hp
  have h : env52989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52988_52989 : H12AffineEnvironment.transform 3 3 env52988 = env52989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env52988 == env52989) = true)

theorem identity52989 : scanCanonicalize (H12AffineFastState.compose env52989 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52989 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52990 : List Nat := [0,0,1,1,1,0,0,0,1,0,0,0,0,0,1,0,1,1,0,0,0,1,0,1,1,0,0,0,1,1,1,0,0,1,0,0]

theorem envBound52990 : H12AffineFastState.Bounded env52990 := by
  intro p hp
  have h : env52990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52989_52990 : H12AffineEnvironment.transform 0 0 env52989 = env52990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52989 == env52990) = true)

def env52991 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,8495,1,8622,4416,12637,4096,477,16,12607,12425,4160,4415,81,81,6436,8204,65,256,8201,1,4608]

theorem envBound52991 : H12AffineFastState.Bounded env52991 := by
  intro p hp
  have h : env52991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52977_52991 : H12AffineEnvironment.transform 9 321 env52977 = env52991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52977 == env52991) = true)

theorem identity52991 : scanCanonicalize (H12AffineFastState.compose env52991 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound52991 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52992 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4365,80,81,4130,1,4259,4416,80,4096,477,16,50,388,4160,4415,81,81,6436,4353,65,256,4356,1,4608]

theorem envBound52992 : H12AffineFastState.Bounded env52992 := by
  intro p hp
  have h : env52992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52991_52992 : H12AffineEnvironment.transform 12 4365 env52991 = env52992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env52991 == env52992) = true)

theorem identity52992 : scanCanonicalize (H12AffineFastState.compose env52992 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound52992 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env52993 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,4096,4365,80,81,4130,1,4259,4416,80,4096,477,16,50,388,4160,4415,81,81,6436,4353,65,256,4356,1,4232]

theorem envBound52993 : H12AffineFastState.Bounded env52993 := by
  intro p hp
  have h : env52993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52992_52993 : H12AffineEnvironment.transform 8 136 env52992 = env52993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env52992 == env52993) = true)

theorem identity52993 : scanCanonicalize (H12AffineFastState.compose env52993 (packedSelected [5,8,11,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound52993 : packedSelected [5,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env52994 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,2367,2098,80,81,2333,1,2460,2175,80,2367,477,16,50,388,2431,2048,81,81,27,2110,65,256,2107,1,2487]

theorem envBound52994 : H12AffineFastState.Bounded env52994 := by
  intro p hp
  have h : env52994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52993_52994 : H12AffineEnvironment.transform 11 2367 env52993 = env52994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env52993 == env52994) = true)

theorem identity52994 : scanCanonicalize (H12AffineFastState.compose env52994 (packedSelected [0,1,2,7,8,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound52994 : packedSelected [0,1,2,7,8,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env52995 : List Nat := [2,4,8,16,32,64,128,256,136,321,195,508,241,80,81,478,1,351,188,80,508,477,16,50,388,444,195,81,81,27,253,65,256,248,1,372]

theorem envBound52995 : H12AffineFastState.Bounded env52995 := by
  intro p hp
  have h : env52995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52994_52995 : H12AffineEnvironment.transform 10 195 env52994 = env52995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env52994 == env52995) = true)

theorem identity52995 : scanCanonicalize (H12AffineFastState.compose env52995 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound52995 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52996 : List Nat := [2,4,8,16,32,64,128,21,136,84,195,233,241,80,81,203,1,74,188,80,233,200,16,50,145,169,195,81,81,27,253,65,21,248,1,97]

theorem envBound52996 : H12AffineFastState.Bounded env52996 := by
  intro p hp
  have h : env52996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52995_52996 : H12AffineEnvironment.transform 7 21 env52995 = env52996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env52995 == env52996) = true)

theorem identity52996 : scanCanonicalize (H12AffineFastState.compose env52996 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52996 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52997 : List Nat := [2,4,8,16,17,64,128,21,136,84,195,216,192,80,81,203,1,74,141,80,216,200,16,3,145,152,195,81,81,27,204,65,21,201,1,80]

theorem envBound52997 : H12AffineFastState.Bounded env52997 := by
  intro p hp
  have h : env52997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52996_52997 : H12AffineEnvironment.transform 4 17 env52996 = env52997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52996 == env52997) = true)

theorem identity52997 : scanCanonicalize (H12AffineFastState.compose env52997 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound52997 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52998 : List Nat := [2,4,8,16,17,64,66,21,74,84,1,26,2,80,81,9,1,74,79,80,26,10,16,3,83,90,1,81,81,27,14,65,21,11,1,80]

theorem envBound52998 : H12AffineFastState.Bounded env52998 := by
  intro p hp
  have h : env52998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52997_52998 : H12AffineEnvironment.transform 6 66 env52997 = env52998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env52997 == env52998) = true)

theorem identity52998 : scanCanonicalize (H12AffineFastState.compose env52998 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52999 : List Nat := [2,4,8,16,17,17,19,21,27,5,1,26,2,1,0,9,1,27,30,1,26,10,16,3,2,11,1,0,0,27,14,16,21,11,1,1]

theorem envBound52999 : H12AffineFastState.Bounded env52999 := by
  intro p hp
  have h : env52999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52998_52999 : H12AffineEnvironment.transform 5 17 env52998 = env52999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52998 == env52999) = true)

theorem identity52999 : scanCanonicalize (H12AffineFastState.compose env52999 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52999 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53000 : List Nat := [2,4,8,6,7,7,5,3,13,5,1,12,2,1,0,9,1,13,8,1,12,10,6,3,2,11,1,0,0,13,14,6,3,11,1,1]

theorem envBound53000 : H12AffineFastState.Bounded env53000 := by
  intro p hp
  have h : env53000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52999_53000 : H12AffineEnvironment.transform 3 6 env52999 = env53000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52999 == env53000) = true)

theorem identity53000 : scanCanonicalize (H12AffineFastState.compose env53000 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53000 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53001 : List Nat := [2,4,4,6,7,7,5,3,1,5,1,0,2,1,0,5,1,1,4,1,0,6,6,3,2,7,1,0,0,1,2,6,3,7,1,1]

theorem envBound53001 : H12AffineFastState.Bounded env53001 := by
  intro p hp
  have h : env53001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53000_53001 : H12AffineEnvironment.transform 2 4 env53000 = env53001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53000 == env53001) = true)

def env53002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123165,533640,614527,385203,90414,545089,96347,25884,1280,256,594023,1344,525825]

theorem envBound53002 : H12AffineFastState.Bounded env53002 := by
  intro p hp
  have h : env53002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52806_53002 : H12AffineEnvironment.transform 23 123165 env52806 = env53002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env52806 == env53002) = true)

def env53003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123165,28888,78895,385203,90414,1297,96347,25884,1280,256,82999,1344,21073]

theorem envBound53003 : H12AffineFastState.Bounded env53003 := by
  intro p hp
  have h : env53003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53002_53003 : H12AffineEnvironment.transform 18 21584 env53002 = env53003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env53002 == env53003) = true)

theorem identity53003 : scanCanonicalize (H12AffineFastState.compose env53003 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound53003 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4096,5276,91182,66896,28888,78895,328958,90414,1297,96347,25884,1280,256,82999,1344,21073]

theorem envBound53004 : H12AffineFastState.Bounded env53004 := by
  intro p hp
  have h : env53004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53003_53004 : H12AffineEnvironment.transform 14 25677 env53003 = env53004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env53003 == env53004) = true)

def env53005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4096,5276,74046,66896,13768,78895,328958,74814,1297,81227,8204,1280,256,65831,1344,5953]

theorem envBound53005 : H12AffineFastState.Bounded env53005 := by
  intro p hp
  have h : env53005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53004_53005 : H12AffineEnvironment.transform 13 1296 env53004 = env53005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53004 == env53005) = true)

def env53006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4096,5276,74046,66896,13768,78895,1150,74814,1297,81227,8204,1280,256,65831,1344,5953]

theorem envBound53006 : H12AffineFastState.Bounded env53006 := by
  intro p hp
  have h : env53006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53005_53006 : H12AffineEnvironment.transform 17 65664 env53005 = env53006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53005 == env53006) = true)

theorem identity53006 : scanCanonicalize (H12AffineFastState.compose env53006 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound53006 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,65536,66598,65664,4416,277,4096,5276,65911,66896,5505,70758,1150,66679,1297,72962,69,1280,256,65831,1344,5953]

theorem envBound53007 : H12AffineFastState.Bounded env53007 := by
  intro p hp
  have h : env53007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53006_53007 : H12AffineEnvironment.transform 12 73 env53006 = env53007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env53006 == env53007) = true)

def env53008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1296,276,65536,66598,65664,1876,277,1556,648,65911,66896,917,66162,1150,66679,1297,68374,69,1280,256,65831,1344,341]

theorem envBound53008 : H12AffineFastState.Bounded env53008 := by
  intro p hp
  have h : env53008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53007_53008 : H12AffineEnvironment.transform 11 1556 env53007 = env53008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env53007 == env53008) = true)

def env53009 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,65536,65894,65664,532,277,852,648,65911,65552,917,66162,318,65847,81,68374,69,64,256,65831,0,341]

theorem envBound53009 : H12AffineFastState.Bounded env53009 := by
  intro p hp
  have h : env53009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53008_53009 : H12AffineEnvironment.transform 9 320 env53008 = env53009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53008 == env53009) = true)

theorem identity53009 : scanCanonicalize (H12AffineFastState.compose env53009 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53009 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53010 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,577,73,80,1,65536,65651,65664,532,0,577,648,65634,65552,640,66162,43,65570,81,68099,69,64,21,65586,0,64]

theorem envBound53010 : H12AffineFastState.Bounded env53010 := by
  intro p hp
  have h : env53010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53009_53010 : H12AffineEnvironment.transform 7 21 env53009 = env53010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53009 == env53010) = true)

theorem identity53010 : scanCanonicalize (H12AffineFastState.compose env53010 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53010 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53011 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,529,25,0,1,65536,65571,65664,532,0,529,648,65586,65552,640,66082,43,65570,1,68099,21,16,21,65586,0,16]

theorem envBound53011 : H12AffineFastState.Bounded env53011 := by
  intro p hp
  have h : env53011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53010_53011 : H12AffineEnvironment.transform 5 16 env53010 = env53011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53010 == env53011) = true)

theorem identity53011 : scanCanonicalize (H12AffineFastState.compose env53011 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 553) := by decide +kernel

theorem selectedBound53011 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53012 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,529,25,0,1,553,522,681,532,0,529,648,539,569,640,11,43,523,1,2090,21,16,21,539,0,16]

theorem envBound53012 : H12AffineFastState.Bounded env53012 := by
  intro p hp
  have h : env53012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53011_53012 : H12AffineEnvironment.transform 15 553 env53011 = env53012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 553 env53011 == env53012) = true)

theorem identity53012 : scanCanonicalize (H12AffineFastState.compose env53012 (packedSelected [0,2,3,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53012 : packedSelected [0,2,3,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env53013 : List Nat := [2,4,8,11,32,11,128,14,512,5,2048,522,2,0,1,553,522,681,527,0,522,648,512,546,640,11,43,523,1,2090,14,11,14,512,0,11]

theorem envBound53013 : H12AffineFastState.Bounded env53013 := by
  intro p hp
  have h : env53013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53012_53013 : H12AffineEnvironment.transform 3 11 env53012 = env53013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53012 == env53013) = true)

theorem identity53013 : scanCanonicalize (H12AffineFastState.compose env53013 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound53013 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env53014 : List Nat := [2,4,8,11,32,11,128,14,45,5,2048,39,2,0,1,4,39,132,34,0,39,165,45,15,173,11,43,38,1,2090,14,11,14,45,0,11]

theorem envBound53014 : H12AffineFastState.Bounded env53014 := by
  intro p hp
  have h : env53014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53013_53014 : H12AffineEnvironment.transform 8 45 env53013 = env53014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env53013 == env53014) = true)

theorem identity53014 : scanCanonicalize (H12AffineFastState.compose env53014 (packedSelected [2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound53014 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env53015 : List Nat := [2,4,8,11,32,11,128,14,45,5,33,39,2,0,1,4,39,132,34,0,39,165,45,15,173,11,43,38,1,11,14,11,14,45,0,11]

theorem envBound53015 : H12AffineFastState.Bounded env53015 := by
  intro p hp
  have h : env53015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53014_53015 : H12AffineEnvironment.transform 10 33 env53014 = env53015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env53014 == env53015) = true)

theorem identity53015 : scanCanonicalize (H12AffineFastState.compose env53015 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53016 : List Nat := [2,4,8,11,32,11,9,14,45,5,33,39,2,0,1,4,39,13,34,0,39,44,45,15,36,11,43,38,1,11,14,11,14,45,0,11]

theorem envBound53016 : H12AffineFastState.Bounded env53016 := by
  intro p hp
  have h : env53016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53015_53016 : H12AffineEnvironment.transform 6 9 env53015 = env53016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53015 == env53016) = true)

theorem identity53016 : scanCanonicalize (H12AffineFastState.compose env53016 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53016 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53017 : List Nat := [2,4,8,11,7,11,9,14,10,5,6,0,2,0,1,4,0,13,5,0,0,11,10,15,3,11,12,1,1,11,14,11,14,10,0,11]

theorem envBound53017 : H12AffineFastState.Bounded env53017 := by
  intro p hp
  have h : env53017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53016_53017 : H12AffineEnvironment.transform 4 7 env53016 = env53017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53016 == env53017) = true)

theorem identity53017 : scanCanonicalize (H12AffineFastState.compose env53017 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53018 : List Nat := [2,4,3,0,7,0,2,5,1,5,6,0,2,0,1,4,0,6,5,0,0,0,1,4,3,0,7,1,1,0,5,0,5,1,0,0]

theorem envBound53018 : H12AffineFastState.Bounded env53018 := by
  intro p hp
  have h : env53018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53017_53018 : H12AffineEnvironment.transform 2 3 env53017 = env53018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53017 == env53018) = true)

theorem identity53018 : scanCanonicalize (H12AffineFastState.compose env53018 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53019 : List Nat := [2,1,3,0,2,0,2,0,1,0,3,0,2,0,1,1,0,3,0,0,0,0,1,1,3,0,2,1,1,0,0,0,0,1,0,0]

theorem envBound53019 : H12AffineFastState.Bounded env53019 := by
  intro p hp
  have h : env53019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53018_53019 : H12AffineEnvironment.transform 1 1 env53018 = env53019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53018 == env53019) = true)

theorem identity53019 : scanCanonicalize (H12AffineFastState.compose env53019 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53019 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53020 : List Nat := [1,1,0,0,1,0,1,0,1,0,0,0,1,0,1,1,0,0,0,0,0,0,1,1,0,0,1,1,1,0,0,0,0,1,0,0]

theorem envBound53020 : H12AffineFastState.Bounded env53020 := by
  intro p hp
  have h : env53020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53019_53020 : H12AffineEnvironment.transform 0 1 env53019 = env53020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53019 == env53020) = true)

def env53021 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,65536,65895,65664,533,277,853,648,65911,65553,917,66162,319,65846,80,68374,69,65,256,65831,1,341]

theorem envBound53021 : H12AffineFastState.Bounded env53021 := by
  intro p hp
  have h : env53021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53008_53021 : H12AffineEnvironment.transform 9 321 env53008 = env53021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53008 == env53021) = true)

theorem identity53021 : scanCanonicalize (H12AffineFastState.compose env53021 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound53021 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53022 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,73,81,276,65536,65895,65664,85,277,277,200,65911,65553,469,65586,319,65846,80,67926,69,65,256,65831,1,341]

theorem envBound53022 : H12AffineFastState.Bounded env53022 := by
  intro p hp
  have h : env53022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53021_53022 : H12AffineEnvironment.transform 8 64 env53021 = env53022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env53021 == env53022) = true)

theorem identity53022 : scanCanonicalize (H12AffineFastState.compose env53022 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound53022 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env53023 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,73,81,276,114,277,242,85,277,277,200,261,99,469,64,319,324,80,2340,69,65,256,341,1,341]

theorem envBound53023 : H12AffineFastState.Bounded env53023 := by
  intro p hp
  have h : env53023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53022_53023 : H12AffineEnvironment.transform 15 114 env53022 = env53023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env53022 == env53023) = true)

theorem identity53023 : scanCanonicalize (H12AffineFastState.compose env53023 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound53023 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env53024 : List Nat := [2,4,8,16,32,64,128,193,64,128,2048,212,73,81,213,114,212,242,85,212,212,200,196,99,20,64,254,133,80,2277,69,65,193,148,1,148]

theorem envBound53024 : H12AffineFastState.Bounded env53024 := by
  intro p hp
  have h : env53024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53023_53024 : H12AffineEnvironment.transform 7 193 env53023 = env53024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env53023 == env53024) = true)

theorem identity53024 : scanCanonicalize (H12AffineFastState.compose env53024 (packedSelected [0,1,7,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound53024 : packedSelected [0,1,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53025 : List Nat := [2,4,8,16,32,64,128,193,64,128,28,212,73,81,213,114,212,242,85,212,212,200,196,99,20,64,254,133,80,249,69,65,193,148,1,148]

theorem envBound53025 : H12AffineFastState.Bounded env53025 := by
  intro p hp
  have h : env53025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53024_53025 : H12AffineEnvironment.transform 10 28 env53024 = env53025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env53024 == env53025) = true)

theorem identity53025 : scanCanonicalize (H12AffineFastState.compose env53025 (packedSelected [2,3,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound53025 : packedSelected [2,3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env53026 : List Nat := [2,4,8,16,32,12,128,141,12,128,28,152,5,29,153,62,152,190,25,152,152,132,136,47,20,12,178,133,28,181,9,13,141,148,1,148]

theorem envBound53026 : H12AffineFastState.Bounded env53026 := by
  intro p hp
  have h : env53026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53025_53026 : H12AffineEnvironment.transform 5 12 env53025 = env53026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env53025 == env53026) = true)

theorem identity53026 : scanCanonicalize (H12AffineFastState.compose env53026 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound53026 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53027 : List Nat := [2,4,8,16,32,12,36,41,12,36,28,60,5,29,61,62,60,26,25,60,60,32,44,47,20,12,22,33,28,17,9,13,41,48,1,48]

theorem envBound53027 : H12AffineFastState.Bounded env53027 := by
  intro p hp
  have h : env53027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53026_53027 : H12AffineEnvironment.transform 6 36 env53026 = env53027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env53026 == env53027) = true)

theorem identity53027 : scanCanonicalize (H12AffineFastState.compose env53027 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53027 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env53028 : List Nat := [2,4,8,10,32,12,36,41,12,36,6,38,5,7,39,36,38,0,3,38,38,32,44,47,14,12,12,33,6,11,9,13,41,42,1,42]

theorem envBound53028 : H12AffineFastState.Bounded env53028 := by
  intro p hp
  have h : env53028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53027_53028 : H12AffineEnvironment.transform 3 10 env53027 = env53028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53027 == env53028) = true)

theorem identity53028 : scanCanonicalize (H12AffineFastState.compose env53028 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53029 : List Nat := [2,4,8,10,0,12,4,9,12,4,6,6,5,7,7,4,6,0,3,6,6,0,12,15,14,12,12,1,6,11,9,13,9,10,1,10]

theorem envBound53029 : H12AffineFastState.Bounded env53029 := by
  intro p hp
  have h : env53029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53028_53029 : H12AffineEnvironment.transform 4 0 env53028 = env53029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53028 == env53029) = true)

def env53030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1296,276,65536,66598,65664,1877,277,1557,649,65911,66896,916,66163,1150,66679,1297,68375,69,1280,256,65831,1344,340]

theorem envBound53030 : H12AffineFastState.Bounded env53030 := by
  intro p hp
  have h : env53030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53007_53030 : H12AffineEnvironment.transform 11 1557 env53007 = env53030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env53007 == env53030) = true)

def env53031 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,65536,65894,65664,533,277,853,649,65911,65552,916,66163,318,65847,81,68375,69,64,256,65831,0,340]

theorem envBound53031 : H12AffineFastState.Bounded env53031 := by
  intro p hp
  have h : env53031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53030_53031 : H12AffineEnvironment.transform 9 320 env53030 = env53031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53030 == env53031) = true)

theorem identity53031 : scanCanonicalize (H12AffineFastState.compose env53031 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53031 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53032 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,576,73,80,1,65536,65651,65664,533,0,576,649,65634,65552,641,66163,43,65570,81,68098,69,64,21,65586,0,65]

theorem envBound53032 : H12AffineFastState.Bounded env53032 := by
  intro p hp
  have h : env53032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53031_53032 : H12AffineEnvironment.transform 7 21 env53031 = env53032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53031 == env53032) = true)

theorem identity53032 : scanCanonicalize (H12AffineFastState.compose env53032 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53032 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53033 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,528,25,0,1,65536,65571,65664,533,0,528,649,65586,65552,641,66083,43,65570,1,68098,21,16,21,65586,0,17]

theorem envBound53033 : H12AffineFastState.Bounded env53033 := by
  intro p hp
  have h : env53033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53032_53033 : H12AffineEnvironment.transform 5 16 env53032 = env53033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53032 == env53033) = true)

theorem identity53033 : scanCanonicalize (H12AffineFastState.compose env53033 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 57) := by decide +kernel

theorem selectedBound53033 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53034 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,528,25,0,1,57,26,185,533,0,528,649,11,41,641,538,43,27,1,2619,21,16,21,11,0,17]

theorem envBound53034 : H12AffineFastState.Bounded env53034 := by
  intro p hp
  have h : env53034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53033_53034 : H12AffineEnvironment.transform 15 57 env53033 = env53034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 57 env53033 == env53034) = true)

theorem identity53034 : scanCanonicalize (H12AffineFastState.compose env53034 (packedSelected [0,2,3,4,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound53034 : packedSelected [0,2,3,4,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env53035 : List Nat := [2,4,8,16,32,16,128,21,10,5,2048,26,25,0,1,57,26,185,31,0,26,131,11,41,139,16,43,27,1,2097,21,16,21,11,0,17]

theorem envBound53035 : H12AffineFastState.Bounded env53035 := by
  intro p hp
  have h : env53035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53034_53035 : H12AffineEnvironment.transform 8 10 env53034 = env53035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env53034 == env53035) = true)

theorem identity53035 : scanCanonicalize (H12AffineFastState.compose env53035 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53035 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env53036 : List Nat := [2,4,8,16,6,16,128,21,10,5,2048,26,25,0,1,31,26,159,31,0,26,131,11,15,139,16,13,27,1,2071,21,16,21,11,0,17]

theorem envBound53036 : H12AffineFastState.Bounded env53036 := by
  intro p hp
  have h : env53036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53035_53036 : H12AffineEnvironment.transform 4 6 env53035 = env53036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53035 == env53036) = true)

theorem identity53036 : scanCanonicalize (H12AffineFastState.compose env53036 (packedSelected [2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound53036 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env53037 : List Nat := [2,4,8,16,6,16,128,21,10,5,29,26,25,0,1,31,26,159,31,0,26,131,11,15,139,16,13,27,1,10,21,16,21,11,0,17]

theorem envBound53037 : H12AffineFastState.Bounded env53037 := by
  intro p hp
  have h : env53037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53036_53037 : H12AffineEnvironment.transform 10 29 env53036 = env53037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env53036 == env53037) = true)

theorem identity53037 : scanCanonicalize (H12AffineFastState.compose env53037 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound53037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53038 : List Nat := [2,4,8,16,6,16,18,21,10,5,29,26,25,0,1,31,26,13,31,0,26,17,11,15,25,16,13,27,1,10,21,16,21,11,0,17]

theorem envBound53038 : H12AffineFastState.Bounded env53038 := by
  intro p hp
  have h : env53038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53037_53038 : H12AffineEnvironment.transform 6 18 env53037 = env53038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env53037 == env53038) = true)

theorem identity53038 : scanCanonicalize (H12AffineFastState.compose env53038 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53038 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53039 : List Nat := [2,4,3,16,6,16,18,21,1,5,22,17,18,0,1,20,17,6,20,0,17,17,0,4,18,16,6,16,1,1,21,16,21,0,0,17]

theorem envBound53039 : H12AffineFastState.Bounded env53039 := by
  intro p hp
  have h : env53039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53038_53039 : H12AffineEnvironment.transform 2 3 env53038 = env53039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53038 == env53039) = true)

theorem identity53039 : scanCanonicalize (H12AffineFastState.compose env53039 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound53039 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53040 : List Nat := [2,4,3,6,6,6,4,3,1,5,0,7,4,0,1,2,7,6,2,0,7,7,0,4,4,6,6,6,1,1,3,6,3,0,0,7]

theorem envBound53040 : H12AffineFastState.Bounded env53040 := by
  intro p hp
  have h : env53040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53039_53040 : H12AffineEnvironment.transform 3 6 env53039 = env53040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env53039 == env53040) = true)

def env53041 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,65536,65895,65664,532,277,852,649,65911,65553,916,66163,319,65846,80,68375,69,65,256,65831,1,340]

theorem envBound53041 : H12AffineFastState.Bounded env53041 := by
  intro p hp
  have h : env53041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53030_53041 : H12AffineEnvironment.transform 9 321 env53030 = env53041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53030 == env53041) = true)

theorem identity53041 : scanCanonicalize (H12AffineFastState.compose env53041 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound53041 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53042 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,73,81,276,65536,65895,65664,85,277,277,200,65911,65553,469,65586,319,65846,80,67926,69,65,256,65831,1,340]

theorem envBound53042 : H12AffineFastState.Bounded env53042 := by
  intro p hp
  have h : env53042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53041_53042 : H12AffineEnvironment.transform 8 65 env53041 = env53042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env53041 == env53042) = true)

theorem identity53042 : scanCanonicalize (H12AffineFastState.compose env53042 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound53042 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env53043 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,73,81,276,114,277,242,85,277,277,200,261,99,469,64,319,324,80,2340,69,65,256,341,1,340]

theorem envBound53043 : H12AffineFastState.Bounded env53043 := by
  intro p hp
  have h : env53043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53042_53043 : H12AffineEnvironment.transform 15 114 env53042 = env53043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env53042 == env53043) = true)

theorem identity53043 : scanCanonicalize (H12AffineFastState.compose env53043 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound53043 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env53044 : List Nat := [2,4,8,16,32,64,128,192,65,129,2048,213,73,81,212,114,213,242,85,213,213,200,197,99,21,64,255,132,80,2276,69,65,192,149,1,148]

theorem envBound53044 : H12AffineFastState.Bounded env53044 := by
  intro p hp
  have h : env53044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53043_53044 : H12AffineEnvironment.transform 7 192 env53043 = env53044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env53043 == env53044) = true)

theorem identity53044 : scanCanonicalize (H12AffineFastState.compose env53044 (packedSelected [0,1,7,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 201) := by decide +kernel

theorem selectedBound53044 : packedSelected [0,1,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53045 : List Nat := [2,4,8,16,32,64,128,192,65,129,201,213,73,81,212,114,213,242,85,213,213,200,197,99,21,64,255,132,80,45,69,65,192,149,1,148]

theorem envBound53045 : H12AffineFastState.Bounded env53045 := by
  intro p hp
  have h : env53045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53044_53045 : H12AffineEnvironment.transform 10 201 env53044 = env53045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env53044 == env53045) = true)

theorem identity53045 : scanCanonicalize (H12AffineFastState.compose env53045 (packedSelected [2,3,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound53045 : packedSelected [2,3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env53046 : List Nat := [2,4,8,16,32,12,128,140,13,129,133,153,5,29,152,62,153,190,25,153,153,132,137,47,21,12,179,132,28,45,9,13,140,149,1,148]

theorem envBound53046 : H12AffineFastState.Bounded env53046 := by
  intro p hp
  have h : env53046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53045_53046 : H12AffineEnvironment.transform 5 12 env53045 = env53046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env53045 == env53046) = true)

theorem identity53046 : scanCanonicalize (H12AffineFastState.compose env53046 (packedSelected [2,3,8,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound53046 : packedSelected [2,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env53047 : List Nat := [2,4,8,16,32,12,5,9,13,4,0,28,5,29,29,62,28,59,25,28,28,1,12,47,21,12,54,1,28,45,9,13,9,16,1,17]

theorem envBound53047 : H12AffineFastState.Bounded env53047 := by
  intro p hp
  have h : env53047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53046_53047 : H12AffineEnvironment.transform 6 5 env53046 = env53047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env53046 == env53047) = true)

theorem identity53047 : scanCanonicalize (H12AffineFastState.compose env53047 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53047 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53048 : List Nat := [2,4,8,16,1,12,5,9,13,4,0,28,5,29,29,31,28,26,25,28,28,1,12,14,21,12,23,1,28,12,9,13,9,16,1,17]

theorem envBound53048 : H12AffineFastState.Bounded env53048 := by
  intro p hp
  have h : env53048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53047_53048 : H12AffineEnvironment.transform 4 1 env53047 = env53048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53047 == env53048) = true)

theorem identity53048 : scanCanonicalize (H12AffineFastState.compose env53048 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound53048 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53049 : List Nat := [2,4,8,12,1,12,5,9,13,4,0,0,5,1,1,3,0,6,5,0,0,1,12,14,9,12,11,1,0,12,9,13,9,12,1,13]

theorem envBound53049 : H12AffineFastState.Bounded env53049 := by
  intro p hp
  have h : env53049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53048_53049 : H12AffineEnvironment.transform 3 12 env53048 = env53049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env53048 == env53049) = true)

def env53050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4096,5276,74046,66896,13768,78895,1151,74814,1297,81227,8204,1280,256,65831,1344,5953]

theorem envBound53050 : H12AffineFastState.Bounded env53050 := by
  intro p hp
  have h : env53050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53005_53050 : H12AffineEnvironment.transform 17 65665 env53005 = env53050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53005 == env53050) = true)

theorem identity53050 : scanCanonicalize (H12AffineFastState.compose env53050 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound53050 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,65536,69990,65665,4416,5205,4096,5276,70711,66896,193,65830,1151,69943,1297,67650,5381,1280,256,65831,1344,5953]

theorem envBound53051 : H12AffineFastState.Bounded env53051 := by
  intro p hp
  have h : env53051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53050_53051 : H12AffineEnvironment.transform 12 5385 env53050 = env53051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env53050 == env53051) = true)

def env53052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1296,576,65536,67442,65665,1876,577,1556,648,66083,66896,193,65830,1151,67363,1297,67650,785,1280,256,65831,1344,341]

theorem envBound53052 : H12AffineFastState.Bounded env53052 := by
  intro p hp
  have h : env53052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53051_53052 : H12AffineEnvironment.transform 11 1556 env53051 = env53052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env53051 == env53052) = true)

def env53053 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,65536,66082,65665,516,577,836,648,66083,65536,193,65830,303,66163,65,67650,785,80,256,65831,16,341]

theorem envBound53053 : H12AffineFastState.Bounded env53053 := by
  intro p hp
  have h : env53053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53052_53053 : H12AffineEnvironment.transform 9 336 env53052 = env53053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env53052 == env53053) = true)

theorem identity53053 : scanCanonicalize (H12AffineFastState.compose env53053 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 506) := by decide +kernel

theorem selectedBound53053 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53054 : List Nat := [2,4,8,16,32,64,128,256,506,336,2048,190,231,64,442,65536,66008,65665,510,443,190,370,66009,65536,193,65830,303,65929,65,67650,235,80,256,65831,16,341]

theorem envBound53054 : H12AffineFastState.Bounded env53054 := by
  intro p hp
  have h : env53054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53053_53054 : H12AffineEnvironment.transform 8 506 env53053 = env53054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 506 env53053 == env53054) = true)

def env53055 : List Nat := [2,4,8,0,32,64,128,256,490,320,2048,174,231,64,426,65536,65992,65665,494,427,174,354,65993,65536,193,65830,303,65929,65,67650,235,64,256,65831,0,325]

theorem envBound53055 : H12AffineFastState.Bounded env53055 := by
  intro p hp
  have h : env53055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53054_53055 : H12AffineEnvironment.transform 3 0 env53054 = env53055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53054 == env53055) = true)

theorem identity53055 : scanCanonicalize (H12AffineFastState.compose env53055 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound53055 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53056 : List Nat := [2,4,8,0,32,64,128,171,65,235,2048,174,231,64,1,65536,65635,65665,69,0,174,201,65634,65536,193,65677,132,65570,65,67650,235,64,171,65676,0,238]

theorem envBound53056 : H12AffineFastState.Bounded env53056 := by
  intro p hp
  have h : env53056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53055_53056 : H12AffineEnvironment.transform 7 171 env53055 = env53056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env53055 == env53056) = true)

theorem identity53056 : scanCanonicalize (H12AffineFastState.compose env53056 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53056 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53057 : List Nat := [2,4,8,0,32,0,128,171,1,171,2048,174,167,0,1,65536,65571,65665,5,0,174,137,65570,65536,129,65677,132,65570,1,67586,171,0,171,65676,0,174]

theorem envBound53057 : H12AffineFastState.Bounded env53057 := by
  intro p hp
  have h : env53057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53056_53057 : H12AffineEnvironment.transform 5 0 env53056 = env53057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53056 == env53057) = true)

theorem identity53057 : scanCanonicalize (H12AffineFastState.compose env53057 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound53057 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53058 : List Nat := [2,4,8,0,32,0,128,171,1,171,164,174,167,0,1,65536,65571,65665,5,0,174,137,65570,65536,129,65677,132,65570,1,65702,171,0,171,65676,0,174]

theorem envBound53058 : H12AffineFastState.Bounded env53058 := by
  intro p hp
  have h : env53058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53057_53058 : H12AffineEnvironment.transform 10 164 env53057 = env53058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env53057 == env53058) = true)

theorem identity53058 : scanCanonicalize (H12AffineFastState.compose env53058 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound53058 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53059 : List Nat := [2,4,8,0,32,0,128,171,1,171,164,174,167,0,1,141,174,12,5,0,174,137,175,141,129,0,132,175,1,43,171,0,171,1,0,174]

theorem envBound53059 : H12AffineFastState.Bounded env53059 := by
  intro p hp
  have h : env53059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53058_53059 : H12AffineEnvironment.transform 15 141 env53058 = env53059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env53058 == env53059) = true)

theorem identity53059 : scanCanonicalize (H12AffineFastState.compose env53059 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound53059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53060 : List Nat := [2,4,8,0,32,0,37,14,1,14,1,11,2,0,1,40,11,12,5,0,11,44,10,40,36,0,33,10,1,43,14,0,14,1,0,11]

theorem envBound53060 : H12AffineFastState.Bounded env53060 := by
  intro p hp
  have h : env53060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53059_53060 : H12AffineEnvironment.transform 6 37 env53059 = env53060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env53059 == env53060) = true)

theorem identity53060 : scanCanonicalize (H12AffineFastState.compose env53060 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53060 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53061 : List Nat := [2,4,8,0,0,0,5,14,1,14,1,11,2,0,1,8,11,12,5,0,11,12,10,8,4,0,1,10,1,11,14,0,14,1,0,11]

theorem envBound53061 : H12AffineFastState.Bounded env53061 := by
  intro p hp
  have h : env53061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53060_53061 : H12AffineEnvironment.transform 4 0 env53060 = env53061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53060 == env53061) = true)

def env53062 : List Nat := [2,4,8,1,32,64,128,256,491,321,2048,175,231,64,427,65536,65993,65665,495,426,175,355,65992,65536,193,65830,303,65929,65,67650,235,65,256,65831,1,324]

theorem envBound53062 : H12AffineFastState.Bounded env53062 := by
  intro p hp
  have h : env53062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53054_53062 : H12AffineEnvironment.transform 3 1 env53054 = env53062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53054 == env53062) = true)

theorem identity53062 : scanCanonicalize (H12AffineFastState.compose env53062 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53062 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53063 : List Nat := [2,4,8,1,32,64,128,5,238,68,2048,175,231,64,174,65536,65740,65665,234,175,175,102,65741,65536,193,65571,42,65676,65,67650,235,65,5,65570,1,65]

theorem envBound53063 : H12AffineFastState.Bounded env53063 := by
  intro p hp
  have h : env53063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53062_53063 : H12AffineEnvironment.transform 7 5 env53062 = env53063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53062 == env53063) = true)

theorem identity53063 : scanCanonicalize (H12AffineFastState.compose env53063 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2247) := by decide +kernel

theorem selectedBound53063 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env53064 : List Nat := [2,4,8,1,32,64,128,5,238,68,2048,175,231,64,174,2247,2059,2118,234,175,175,102,2058,2247,193,2276,42,2123,65,133,235,65,5,2277,1,65]

theorem envBound53064 : H12AffineFastState.Bounded env53064 := by
  intro p hp
  have h : env53064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53063_53064 : H12AffineEnvironment.transform 15 2247 env53063 = env53064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2247 env53063 == env53064) = true)

theorem identity53064 : scanCanonicalize (H12AffineFastState.compose env53064 (packedSelected [2,4,5,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound53064 : packedSelected [2,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env53065 : List Nat := [2,4,8,1,12,64,128,5,194,68,2048,131,203,64,130,2247,2059,2118,198,131,131,74,2058,2247,193,2248,6,2123,65,133,199,65,5,2249,1,65]

theorem envBound53065 : H12AffineFastState.Bounded env53065 := by
  intro p hp
  have h : env53065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53064_53065 : H12AffineEnvironment.transform 4 12 env53064 = env53065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env53064 == env53065) = true)

theorem identity53065 : scanCanonicalize (H12AffineFastState.compose env53065 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound53065 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53066 : List Nat := [2,4,8,1,12,64,128,5,194,68,11,131,203,64,130,204,0,77,198,131,131,74,1,204,193,195,6,64,65,133,199,65,5,194,1,65]

theorem envBound53066 : H12AffineFastState.Bounded env53066 := by
  intro p hp
  have h : env53066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53065_53066 : H12AffineEnvironment.transform 10 11 env53065 = env53066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env53065 == env53066) = true)

theorem identity53066 : scanCanonicalize (H12AffineFastState.compose env53066 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53066 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env53067 : List Nat := [2,4,8,1,12,64,9,5,75,68,11,10,66,64,11,69,0,77,79,10,10,74,1,69,72,74,6,64,65,12,78,65,5,75,1,65]

theorem envBound53067 : H12AffineFastState.Bounded env53067 := by
  intro p hp
  have h : env53067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53066_53067 : H12AffineEnvironment.transform 6 9 env53066 = env53067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53066 == env53067) = true)

theorem identity53067 : scanCanonicalize (H12AffineFastState.compose env53067 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53067 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53068 : List Nat := [2,4,5,1,1,64,4,5,70,68,6,7,66,64,6,69,0,64,66,7,7,71,1,69,69,71,6,64,65,1,67,65,5,70,1,65]

theorem envBound53068 : H12AffineFastState.Bounded env53068 := by
  intro p hp
  have h : env53068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53067_53068 : H12AffineEnvironment.transform 2 5 env53067 = env53068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53067 == env53068) = true)

theorem identity53068 : scanCanonicalize (H12AffineFastState.compose env53068 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53069 : List Nat := [2,4,5,1,1,1,4,5,7,5,6,7,3,1,6,4,0,1,3,7,7,6,1,4,4,6,6,1,0,1,2,0,5,7,1,0]

theorem envBound53069 : H12AffineFastState.Bounded env53069 := by
  intro p hp
  have h : env53069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53068_53069 : H12AffineEnvironment.transform 5 1 env53068 = env53069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53068 == env53069) = true)

theorem identity53069 : scanCanonicalize (H12AffineFastState.compose env53069 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53069 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53070 : List Nat := [2,2,3,1,1,1,2,3,1,3,0,1,3,1,0,2,0,1,3,1,1,0,1,2,2,0,0,1,0,1,2,0,3,1,1,0]

theorem envBound53070 : H12AffineFastState.Bounded env53070 := by
  intro p hp
  have h : env53070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53069_53070 : H12AffineEnvironment.transform 1 2 env53069 = env53070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53069 == env53070) = true)

theorem identity53070 : scanCanonicalize (H12AffineFastState.compose env53070 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53070 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53071 : List Nat := [1,1,0,1,1,1,1,0,1,0,0,1,0,1,0,1,0,1,0,1,1,0,1,1,1,0,0,1,0,1,1,0,0,1,1,0]

theorem envBound53071 : H12AffineFastState.Bounded env53071 := by
  intro p hp
  have h : env53071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53070_53071 : H12AffineEnvironment.transform 0 1 env53070 = env53071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53070 == env53071) = true)

def env53072 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,65536,66083,65665,517,577,837,648,66083,65537,193,65830,302,66162,64,67650,785,81,256,65831,17,341]

theorem envBound53072 : H12AffineFastState.Bounded env53072 := by
  intro p hp
  have h : env53072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53052_53072 : H12AffineEnvironment.transform 9 337 env53052 = env53072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env53052 == env53072) = true)

theorem identity53072 : scanCanonicalize (H12AffineFastState.compose env53072 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound53072 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53073 : List Nat := [2,4,8,16,32,64,63,256,512,337,2048,837,797,65,576,65536,66083,65598,517,577,837,567,66083,65537,126,65830,302,66162,64,67650,785,81,256,65831,17,341]

theorem envBound53073 : H12AffineFastState.Bounded env53073 := by
  intro p hp
  have h : env53073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53072_53073 : H12AffineEnvironment.transform 6 63 env53072 = env53073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env53072 == env53073) = true)

def env53074 : List Nat := [2,4,8,0,32,64,47,256,512,321,2048,837,781,65,576,65536,66083,65582,517,577,837,551,66083,65537,110,65830,302,66146,64,67650,769,65,256,65831,1,325]

theorem envBound53074 : H12AffineFastState.Bounded env53074 := by
  intro p hp
  have h : env53074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53073_53074 : H12AffineEnvironment.transform 3 0 env53073 = env53074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53073 == env53074) = true)

theorem identity53074 : scanCanonicalize (H12AffineFastState.compose env53074 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53074 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53075 : List Nat := [2,4,8,0,32,64,47,4,512,69,2048,577,521,65,576,65536,66083,65582,517,577,577,551,66083,65537,110,65570,42,66146,64,67650,517,65,4,65571,1,65]

theorem envBound53075 : H12AffineFastState.Bounded env53075 := by
  intro p hp
  have h : env53075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53074_53075 : H12AffineEnvironment.transform 7 4 env53074 = env53075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53074 == env53075) = true)

theorem identity53075 : scanCanonicalize (H12AffineFastState.compose env53075 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2600) := by decide +kernel

theorem selectedBound53075 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env53076 : List Nat := [2,4,8,0,32,64,47,4,512,69,2048,577,521,65,576,2600,2059,2566,517,577,577,551,2059,2601,110,2570,42,2122,64,618,517,65,4,2571,1,65]

theorem envBound53076 : H12AffineFastState.Bounded env53076 := by
  intro p hp
  have h : env53076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53075_53076 : H12AffineEnvironment.transform 15 2600 env53075 = env53076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2600 env53075 == env53076) = true)

theorem identity53076 : scanCanonicalize (H12AffineFastState.compose env53076 (packedSelected [2,4,5,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 109) := by decide +kernel

theorem selectedBound53076 : packedSelected [2,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env53077 : List Nat := [2,4,8,0,32,64,47,4,109,69,2048,44,100,65,45,2117,2059,2155,104,44,44,74,2059,2116,110,2151,42,2122,64,7,104,65,4,2150,1,65]

theorem envBound53077 : H12AffineFastState.Bounded env53077 := by
  intro p hp
  have h : env53077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53076_53077 : H12AffineEnvironment.transform 8 109 env53076 = env53077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 109 env53076 == env53077) = true)

theorem identity53077 : scanCanonicalize (H12AffineFastState.compose env53077 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound53077 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53078 : List Nat := [2,4,8,0,32,64,47,4,109,69,102,44,100,65,45,35,109,13,104,44,44,74,109,34,110,1,42,44,64,7,104,65,4,0,1,65]

theorem envBound53078 : H12AffineFastState.Bounded env53078 := by
  intro p hp
  have h : env53078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53077_53078 : H12AffineEnvironment.transform 10 102 env53077 = env53078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env53077 == env53078) = true)

theorem identity53078 : scanCanonicalize (H12AffineFastState.compose env53078 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound53078 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53079 : List Nat := [2,4,8,0,12,64,3,4,65,69,74,0,72,65,1,15,65,13,68,0,0,74,65,14,66,1,6,0,64,7,68,65,4,0,1,65]

theorem envBound53079 : H12AffineFastState.Bounded env53079 := by
  intro p hp
  have h : env53079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53078_53079 : H12AffineEnvironment.transform 4 12 env53078 = env53079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env53078 == env53079) = true)

theorem identity53079 : scanCanonicalize (H12AffineFastState.compose env53079 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound53079 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53080 : List Nat := [2,4,8,0,12,13,3,4,12,8,7,0,5,12,1,15,12,13,9,0,0,7,12,14,15,1,6,0,13,7,9,12,4,0,1,12]

theorem envBound53080 : H12AffineFastState.Bounded env53080 := by
  intro p hp
  have h : env53080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53079_53080 : H12AffineEnvironment.transform 5 13 env53079 = env53080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env53079 == env53080) = true)

theorem identity53080 : scanCanonicalize (H12AffineFastState.compose env53080 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53081 : List Nat := [2,3,8,0,11,10,3,3,11,8,0,0,2,11,1,8,11,10,9,0,0,0,11,9,8,1,1,0,10,0,9,11,3,0,1,11]

theorem envBound53081 : H12AffineFastState.Bounded env53081 := by
  intro p hp
  have h : env53081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53080_53081 : H12AffineEnvironment.transform 1 3 env53080 = env53081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53080 == env53081) = true)

def env53082 : List Nat := [2,4,8,1,32,64,46,256,512,320,2048,837,780,65,576,65536,66083,65583,517,577,837,550,66083,65537,111,65830,302,66147,64,67650,768,64,256,65831,0,324]

theorem envBound53082 : H12AffineFastState.Bounded env53082 := by
  intro p hp
  have h : env53082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53073_53082 : H12AffineEnvironment.transform 3 1 env53073 = env53082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53073 == env53082) = true)

theorem identity53082 : scanCanonicalize (H12AffineFastState.compose env53082 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound53082 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53083 : List Nat := [2,4,8,1,32,64,46,256,65,320,2048,260,333,65,1,65536,65634,65583,68,0,260,103,65634,65537,111,65830,302,65570,64,67650,321,64,256,65831,0,324]

theorem envBound53083 : H12AffineFastState.Bounded env53083 := by
  intro p hp
  have h : env53083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53082_53083 : H12AffineEnvironment.transform 8 65 env53082 = env53083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env53082 == env53083) = true)

theorem identity53083 : scanCanonicalize (H12AffineFastState.compose env53083 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53083 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53084 : List Nat := [2,4,8,1,32,1,46,256,0,257,2048,260,268,0,1,65536,65571,65583,5,0,260,38,65571,65537,46,65830,302,65570,1,67587,256,1,256,65831,0,261]

theorem envBound53084 : H12AffineFastState.Bounded env53084 := by
  intro p hp
  have h : env53084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53083_53084 : H12AffineEnvironment.transform 5 1 env53083 = env53084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53083 == env53084) = true)

theorem identity53084 : scanCanonicalize (H12AffineFastState.compose env53084 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound53084 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53085 : List Nat := [2,4,8,1,32,1,46,256,0,257,271,260,268,0,1,65536,65571,65583,5,0,260,38,65571,65537,46,65830,302,65570,1,65804,256,1,256,65831,0,261]

theorem envBound53085 : H12AffineFastState.Bounded env53085 := by
  intro p hp
  have h : env53085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53084_53085 : H12AffineEnvironment.transform 10 271 env53084 = env53085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env53084 == env53085) = true)

theorem identity53085 : scanCanonicalize (H12AffineFastState.compose env53085 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53085 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53086 : List Nat := [2,4,8,1,32,1,46,5,0,4,10,1,9,0,1,65536,65571,65583,5,0,1,38,65571,65537,46,65571,43,65570,1,65545,5,1,5,65570,0,0]

theorem envBound53086 : H12AffineFastState.Bounded env53086 := by
  intro p hp
  have h : env53086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53085_53086 : H12AffineEnvironment.transform 7 5 env53085 = env53086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53085 == env53086) = true)

theorem identity53086 : scanCanonicalize (H12AffineFastState.compose env53086 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53086 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53087 : List Nat := [2,4,3,1,32,1,37,5,0,4,1,1,2,0,1,65536,65571,65572,5,0,1,38,65571,65537,37,65571,32,65570,1,65538,5,1,5,65570,0,0]

theorem envBound53087 : H12AffineFastState.Bounded env53087 := by
  intro p hp
  have h : env53087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53086_53087 : H12AffineEnvironment.transform 2 3 env53086 = env53087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53086 == env53087) = true)

theorem identity53087 : scanCanonicalize (H12AffineFastState.compose env53087 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53087 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53088 : List Nat := [2,4,3,1,6,1,3,5,0,4,1,1,2,0,1,65536,65541,65538,5,0,1,0,65541,65537,3,65541,6,65540,1,65538,5,1,5,65540,0,0]

theorem envBound53088 : H12AffineFastState.Bounded env53088 := by
  intro p hp
  have h : env53088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53087_53088 : H12AffineEnvironment.transform 4 6 env53087 = env53088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53087 == env53088) = true)

theorem identity53088 : scanCanonicalize (H12AffineFastState.compose env53088 (packedSelected [1,2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound53088 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53089 : List Nat := [2,4,3,1,6,1,3,5,0,4,1,1,2,0,1,3,6,1,5,0,1,0,6,2,3,6,6,7,1,1,5,1,5,7,0,0]

theorem envBound53089 : H12AffineFastState.Bounded env53089 := by
  intro p hp
  have h : env53089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53088_53089 : H12AffineEnvironment.transform 15 3 env53088 = env53089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env53088 == env53089) = true)

theorem identity53089 : scanCanonicalize (H12AffineFastState.compose env53089 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53090 : List Nat := [2,2,3,1,0,1,3,3,0,2,1,1,2,0,1,3,0,1,3,0,1,0,0,2,3,0,0,1,1,1,3,1,3,1,0,0]

theorem envBound53090 : H12AffineFastState.Bounded env53090 := by
  intro p hp
  have h : env53090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53089_53090 : H12AffineEnvironment.transform 1 2 env53089 = env53090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53089 == env53090) = true)

def env53091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1296,577,65536,67443,65665,1877,576,1557,649,66082,66896,193,65830,1151,67362,1297,67650,784,1280,256,65831,1344,340]

theorem envBound53091 : H12AffineFastState.Bounded env53091 := by
  intro p hp
  have h : env53091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53051_53091 : H12AffineEnvironment.transform 11 1557 env53051 = env53091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env53051 == env53091) = true)

def env53092 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,65536,66083,65665,517,576,837,649,66082,65536,193,65830,303,66162,65,67650,784,80,256,65831,16,340]

theorem envBound53092 : H12AffineFastState.Bounded env53092 := by
  intro p hp
  have h : env53092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53091_53092 : H12AffineEnvironment.transform 9 336 env53091 = env53092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env53091 == env53092) = true)

theorem identity53092 : scanCanonicalize (H12AffineFastState.compose env53092 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 457) := by decide +kernel

theorem selectedBound53092 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53093 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,457,1002,328,517,576,837,649,1003,457,193,239,303,955,65,2443,784,80,256,238,16,340]

theorem envBound53093 : H12AffineFastState.Bounded env53093 := by
  intro p hp
  have h : env53093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53092_53093 : H12AffineEnvironment.transform 15 457 env53092 = env53093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 457 env53092 == env53093) = true)

def env53094 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,780,64,577,457,1002,328,517,576,837,649,1003,457,193,239,303,939,65,2443,768,64,256,238,0,324]

theorem envBound53094 : H12AffineFastState.Bounded env53094 := by
  intro p hp
  have h : env53094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53093_53094 : H12AffineEnvironment.transform 3 0 env53093 = env53094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53093 == env53094) = true)

theorem identity53094 : scanCanonicalize (H12AffineFastState.compose env53094 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound53094 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53095 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,261,332,64,1,457,426,328,69,0,261,201,427,457,193,239,303,491,65,2443,320,64,256,238,0,324]

theorem envBound53095 : H12AffineFastState.Bounded env53095 := by
  intro p hp
  have h : env53095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53094_53095 : H12AffineEnvironment.transform 8 64 env53094 = env53095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env53094 == env53095) = true)

theorem identity53095 : scanCanonicalize (H12AffineFastState.compose env53095 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53095 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53096 : List Nat := [2,4,8,0,32,0,128,256,0,256,2048,261,268,0,1,393,426,264,5,0,261,137,427,393,129,175,303,427,1,2443,256,0,256,174,0,260]

theorem envBound53096 : H12AffineFastState.Bounded env53096 := by
  intro p hp
  have h : env53096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53095_53096 : H12AffineEnvironment.transform 5 0 env53095 = env53096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53095 == env53096) = true)

theorem identity53096 : scanCanonicalize (H12AffineFastState.compose env53096 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound53096 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53097 : List Nat := [2,4,8,0,32,0,128,256,0,256,11,261,268,0,1,393,426,264,5,0,261,137,427,393,129,175,303,427,1,384,256,0,256,174,0,260]

theorem envBound53097 : H12AffineFastState.Bounded env53097 := by
  intro p hp
  have h : env53097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53096_53097 : H12AffineEnvironment.transform 10 11 env53096 = env53097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env53096 == env53097) = true)

theorem identity53097 : scanCanonicalize (H12AffineFastState.compose env53097 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53097 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53098 : List Nat := [2,4,8,0,32,0,128,4,0,4,11,1,8,0,1,141,174,12,5,0,1,137,175,141,129,175,43,175,1,132,4,0,4,174,0,0]

theorem envBound53098 : H12AffineFastState.Bounded env53098 := by
  intro p hp
  have h : env53098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53097_53098 : H12AffineEnvironment.transform 7 4 env53097 = env53098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53097 == env53098) = true)

theorem identity53098 : scanCanonicalize (H12AffineFastState.compose env53098 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53098 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53099 : List Nat := [2,4,2,0,32,0,128,4,0,4,1,1,2,0,1,135,164,6,5,0,1,131,165,135,129,165,33,165,1,132,4,0,4,164,0,0]

theorem envBound53099 : H12AffineFastState.Bounded env53099 := by
  intro p hp
  have h : env53099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53098_53099 : H12AffineEnvironment.transform 2 2 env53098 = env53099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53098 == env53099) = true)

theorem identity53099 : scanCanonicalize (H12AffineFastState.compose env53099 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound53099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53100 : List Nat := [2,4,2,0,32,0,2,4,0,4,1,1,2,0,1,5,38,6,5,0,1,1,39,5,3,39,33,39,1,6,4,0,4,38,0,0]

theorem envBound53100 : H12AffineFastState.Bounded env53100 := by
  intro p hp
  have h : env53100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53099_53100 : H12AffineEnvironment.transform 6 2 env53099 = env53100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env53099 == env53100) = true)

theorem identity53100 : scanCanonicalize (H12AffineFastState.compose env53100 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53100 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53101 : List Nat := [2,3,2,0,32,0,2,3,0,3,1,1,2,0,1,2,33,1,2,0,1,1,32,2,3,32,33,32,1,1,3,0,3,33,0,0]

theorem envBound53101 : H12AffineFastState.Bounded env53101 := by
  intro p hp
  have h : env53101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53100_53101 : H12AffineEnvironment.transform 1 3 env53100 = env53101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53100 == env53101) = true)

theorem identity53101 : scanCanonicalize (H12AffineFastState.compose env53101 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53101 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53102 : List Nat := [2,3,2,0,1,0,2,3,0,3,1,1,2,0,1,2,0,1,2,0,1,1,1,2,3,1,0,1,1,1,3,0,3,0,0,0]

theorem envBound53102 : H12AffineFastState.Bounded env53102 := by
  intro p hp
  have h : env53102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53101_53102 : H12AffineEnvironment.transform 4 1 env53101 = env53102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53101 == env53102) = true)

def env53103 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,781,64,577,457,1002,328,517,576,837,649,1003,457,193,239,303,938,65,2443,769,65,256,238,1,325]

theorem envBound53103 : H12AffineFastState.Bounded env53103 := by
  intro p hp
  have h : env53103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53093_53103 : H12AffineEnvironment.transform 3 1 env53093 = env53103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53093 == env53103) = true)

theorem identity53103 : scanCanonicalize (H12AffineFastState.compose env53103 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53103 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53104 : List Nat := [2,4,8,1,32,64,128,5,512,68,2048,576,520,64,577,204,751,77,517,576,576,649,750,204,193,239,42,687,65,2190,516,65,5,238,1,64]

theorem envBound53104 : H12AffineFastState.Bounded env53104 := by
  intro p hp
  have h : env53104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53103_53104 : H12AffineEnvironment.transform 7 5 env53103 = env53104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53103 == env53104) = true)

theorem identity53104 : scanCanonicalize (H12AffineFastState.compose env53104 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 741) := by decide +kernel

theorem selectedBound53104 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env53105 : List Nat := [2,4,8,1,32,64,128,5,512,68,741,576,520,64,577,204,751,77,517,576,576,649,750,204,193,239,42,687,65,619,516,65,5,238,1,64]

theorem envBound53105 : H12AffineFastState.Bounded env53105 := by
  intro p hp
  have h : env53105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53104_53105 : H12AffineEnvironment.transform 10 741 env53104 = env53105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 741 env53104 == env53105) = true)

theorem identity53105 : scanCanonicalize (H12AffineFastState.compose env53105 (packedSelected [2,4,5,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 194) := by decide +kernel

theorem selectedBound53105 : packedSelected [2,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env53106 : List Nat := [2,4,8,1,32,64,128,5,194,68,39,130,202,64,131,204,45,77,199,130,130,75,44,204,193,239,42,109,65,169,198,65,5,238,1,64]

theorem envBound53106 : H12AffineFastState.Bounded env53106 := by
  intro p hp
  have h : env53106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53105_53106 : H12AffineEnvironment.transform 8 194 env53105 = env53106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 194 env53105 == env53106) = true)

theorem identity53106 : scanCanonicalize (H12AffineFastState.compose env53106 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound53106 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53107 : List Nat := [2,4,8,1,32,45,128,5,175,41,39,130,167,45,131,161,45,32,170,130,130,38,44,161,172,130,42,0,44,169,171,44,5,131,1,45]

theorem envBound53107 : H12AffineFastState.Bounded env53107 := by
  intro p hp
  have h : env53107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53106_53107 : H12AffineEnvironment.transform 5 45 env53106 = env53107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env53106 == env53107) = true)

theorem identity53107 : scanCanonicalize (H12AffineFastState.compose env53107 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound53107 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53108 : List Nat := [2,4,8,1,32,45,2,5,45,41,39,0,37,45,1,35,45,32,40,0,0,38,44,35,46,0,42,0,44,43,41,44,5,1,1,45]

theorem envBound53108 : H12AffineFastState.Bounded env53108 := by
  intro p hp
  have h : env53108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53107_53108 : H12AffineEnvironment.transform 6 2 env53107 = env53108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env53107 == env53108) = true)

theorem identity53108 : scanCanonicalize (H12AffineFastState.compose env53108 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53108 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53109 : List Nat := [2,4,4,1,32,33,2,5,33,37,39,0,37,33,1,35,33,32,36,0,0,38,32,35,34,0,38,0,32,39,37,32,5,1,1,33]

theorem envBound53109 : H12AffineFastState.Bounded env53109 := by
  intro p hp
  have h : env53109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53108_53109 : H12AffineEnvironment.transform 2 4 env53108 = env53109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53108 == env53109) = true)

theorem identity53109 : scanCanonicalize (H12AffineFastState.compose env53109 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53110 : List Nat := [2,4,4,1,7,6,2,5,6,2,0,0,2,6,1,4,6,7,3,0,0,1,7,4,5,0,1,0,7,0,2,7,5,1,1,6]

theorem envBound53110 : H12AffineFastState.Bounded env53110 := by
  intro p hp
  have h : env53110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53109_53110 : H12AffineEnvironment.transform 4 7 env53109 = env53110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53109 == env53110) = true)

def env53111 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,65536,66082,65665,516,576,836,649,66082,65537,193,65830,302,66163,64,67650,784,81,256,65831,17,340]

theorem envBound53111 : H12AffineFastState.Bounded env53111 := by
  intro p hp
  have h : env53111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53091_53111 : H12AffineEnvironment.transform 9 337 env53091 = env53111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env53091 == env53111) = true)

theorem identity53111 : scanCanonicalize (H12AffineFastState.compose env53111 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 653) := by decide +kernel

theorem selectedBound53111 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53112 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,653,175,524,516,576,836,649,175,652,193,939,302,254,64,2767,784,81,256,938,17,340]

theorem envBound53112 : H12AffineFastState.Bounded env53112 := by
  intro p hp
  have h : env53112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53111_53112 : H12AffineEnvironment.transform 15 653 env53111 = env53112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 653 env53111 == env53112) = true)

def env53113 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,780,65,577,653,175,524,516,576,836,649,175,652,193,939,302,238,64,2767,768,65,256,938,1,324]

theorem envBound53113 : H12AffineFastState.Bounded env53113 := by
  intro p hp
  have h : env53113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53112_53113 : H12AffineEnvironment.transform 3 0 env53112 = env53113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53112 == env53113) = true)

theorem identity53113 : scanCanonicalize (H12AffineFastState.compose env53113 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53113 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53114 : List Nat := [2,4,8,0,32,64,128,4,512,69,2048,576,520,65,577,653,175,524,516,576,576,649,175,652,193,687,42,238,64,2767,516,65,4,686,1,64]

theorem envBound53114 : H12AffineFastState.Bounded env53114 := by
  intro p hp
  have h : env53114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53113_53114 : H12AffineEnvironment.transform 7 4 env53113 = env53114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53113 == env53114) = true)

theorem identity53114 : scanCanonicalize (H12AffineFastState.compose env53114 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound53114 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env53115 : List Nat := [2,4,8,0,32,64,128,4,512,69,165,576,520,65,577,653,175,524,516,576,576,649,175,652,193,687,42,238,64,618,516,65,4,686,1,64]

theorem envBound53115 : H12AffineFastState.Bounded env53115 := by
  intro p hp
  have h : env53115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53114_53115 : H12AffineEnvironment.transform 10 165 env53114 = env53115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env53114 == env53115) = true)

theorem identity53115 : scanCanonicalize (H12AffineFastState.compose env53115 (packedSelected [2,4,5,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 194) := by decide +kernel

theorem selectedBound53115 : packedSelected [2,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env53116 : List Nat := [2,4,8,0,32,64,128,4,194,69,165,130,202,65,131,79,175,206,198,130,130,75,175,78,193,109,42,238,64,168,198,65,4,108,1,64]

theorem envBound53116 : H12AffineFastState.Bounded env53116 := by
  intro p hp
  have h : env53116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53115_53116 : H12AffineEnvironment.transform 8 194 env53115 = env53116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 194 env53115 == env53116) = true)

theorem identity53116 : scanCanonicalize (H12AffineFastState.compose env53116 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound53116 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53117 : List Nat := [2,4,8,0,13,64,128,4,194,69,136,130,202,65,131,79,130,206,198,130,130,75,130,78,193,64,7,195,64,133,198,65,4,65,1,64]

theorem envBound53117 : H12AffineFastState.Bounded env53117 := by
  intro p hp
  have h : env53117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53116_53117 : H12AffineEnvironment.transform 4 13 env53116 = env53117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env53116 == env53117) = true)

theorem identity53117 : scanCanonicalize (H12AffineFastState.compose env53117 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound53117 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env53118 : List Nat := [2,4,8,0,13,64,72,4,10,69,64,74,2,65,75,79,74,6,14,74,74,75,74,78,9,64,7,11,64,77,14,65,4,65,1,64]

theorem envBound53118 : H12AffineFastState.Bounded env53118 := by
  intro p hp
  have h : env53118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53117_53118 : H12AffineEnvironment.transform 6 72 env53117 = env53118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env53117 == env53118) = true)

theorem identity53118 : scanCanonicalize (H12AffineFastState.compose env53118 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound53118 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53119 : List Nat := [2,4,8,0,13,7,15,4,10,2,7,13,2,6,12,8,13,6,14,13,13,12,13,9,9,7,7,11,7,10,14,6,4,6,1,7]

theorem envBound53119 : H12AffineFastState.Bounded env53119 := by
  intro p hp
  have h : env53119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53118_53119 : H12AffineEnvironment.transform 5 7 env53118 = env53119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env53118 == env53119) = true)

theorem identity53119 : scanCanonicalize (H12AffineFastState.compose env53119 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53120 : List Nat := [2,3,8,0,10,0,8,3,10,2,0,10,2,1,11,8,10,1,9,10,10,11,10,9,9,0,0,11,0,10,9,1,3,1,1,0]

theorem envBound53120 : H12AffineFastState.Bounded env53120 := by
  intro p hp
  have h : env53120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53119_53120 : H12AffineEnvironment.transform 1 3 env53119 = env53120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53119 == env53120) = true)

def env53121 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,781,65,577,653,175,524,516,576,836,649,175,652,193,939,302,239,64,2767,769,64,256,938,0,325]

theorem envBound53121 : H12AffineFastState.Bounded env53121 := by
  intro p hp
  have h : env53121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53112_53121 : H12AffineEnvironment.transform 3 1 env53112 = env53121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53112 == env53121) = true)

theorem identity53121 : scanCanonicalize (H12AffineFastState.compose env53121 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound53121 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53122 : List Nat := [2,4,8,1,32,64,128,256,64,320,2048,260,333,65,1,205,175,76,68,0,260,201,175,204,193,491,302,239,64,2191,321,64,256,490,0,325]

theorem envBound53122 : H12AffineFastState.Bounded env53122 := by
  intro p hp
  have h : env53122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53121_53122 : H12AffineEnvironment.transform 8 64 env53121 = env53122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env53121 == env53122) = true)

theorem identity53122 : scanCanonicalize (H12AffineFastState.compose env53122 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53122 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53123 : List Nat := [2,4,8,1,32,1,128,256,1,257,2048,260,268,0,1,140,175,13,5,0,260,136,175,141,128,426,302,174,1,2191,256,1,256,427,0,260]

theorem envBound53123 : H12AffineFastState.Bounded env53123 := by
  intro p hp
  have h : env53123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53122_53123 : H12AffineEnvironment.transform 5 1 env53122 = env53123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53122 == env53123) = true)

theorem identity53123 : scanCanonicalize (H12AffineFastState.compose env53123 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53123 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53124 : List Nat := [2,4,8,1,32,1,128,256,1,257,10,260,268,0,1,140,175,13,5,0,260,136,175,141,128,426,302,174,1,133,256,1,256,427,0,260]

theorem envBound53124 : H12AffineFastState.Bounded env53124 := by
  intro p hp
  have h : env53124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53123_53124 : H12AffineEnvironment.transform 10 10 env53123 = env53124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53123 == env53124) = true)

theorem identity53124 : scanCanonicalize (H12AffineFastState.compose env53124 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound53124 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env53125 : List Nat := [2,4,8,1,32,1,128,171,1,170,10,175,167,0,1,140,175,13,5,0,175,136,175,141,128,1,133,174,1,133,171,1,171,0,0,175]

theorem envBound53125 : H12AffineFastState.Bounded env53125 := by
  intro p hp
  have h : env53125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53124_53125 : H12AffineEnvironment.transform 7 171 env53124 = env53125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env53124 == env53125) = true)

theorem identity53125 : scanCanonicalize (H12AffineFastState.compose env53125 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound53125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53126 : List Nat := [2,4,8,1,32,1,37,14,1,15,10,10,2,0,1,41,10,13,5,0,10,45,10,40,37,1,32,11,1,32,14,1,14,0,0,10]

theorem envBound53126 : H12AffineFastState.Bounded env53126 := by
  intro p hp
  have h : env53126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53125_53126 : H12AffineEnvironment.transform 6 37 env53125 = env53126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env53125 == env53126) = true)

theorem identity53126 : scanCanonicalize (H12AffineFastState.compose env53126 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53126 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53127 : List Nat := [2,4,8,1,10,1,15,14,1,15,10,10,2,0,1,3,10,13,5,0,10,7,10,2,15,1,10,11,1,10,14,1,14,0,0,10]

theorem envBound53127 : H12AffineFastState.Bounded env53127 := by
  intro p hp
  have h : env53127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53126_53127 : H12AffineEnvironment.transform 4 10 env53126 = env53127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53126 == env53127) = true)

theorem identity53127 : scanCanonicalize (H12AffineFastState.compose env53127 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53127 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53128 : List Nat := [2,4,2,1,0,1,5,4,1,5,0,0,2,0,1,3,0,7,5,0,0,7,0,2,5,1,0,1,1,0,4,1,4,0,0,0]

theorem envBound53128 : H12AffineFastState.Bounded env53128 := by
  intro p hp
  have h : env53128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53127_53128 : H12AffineEnvironment.transform 2 2 env53127 = env53128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53127 == env53128) = true)

theorem identity53128 : scanCanonicalize (H12AffineFastState.compose env53128 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53129 : List Nat := [2,0,2,1,0,1,1,0,1,1,0,0,2,0,1,3,0,3,1,0,0,3,0,2,1,1,0,1,1,0,0,1,0,0,0,0]

theorem envBound53129 : H12AffineFastState.Bounded env53129 := by
  intro p hp
  have h : env53129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53128_53129 : H12AffineEnvironment.transform 1 0 env53128 = env53129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53128 == env53129) = true)

theorem identity53129 : scanCanonicalize (H12AffineFastState.compose env53129 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53129 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53130 : List Nat := [0,0,0,1,0,1,1,0,1,1,0,0,0,0,1,1,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,0,0]

theorem envBound53130 : H12AffineFastState.Bounded env53130 := by
  intro p hp
  have h : env53130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53129_53130 : H12AffineEnvironment.transform 0 0 env53129 = env53130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53129 == env53130) = true)

def env53131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4096,5276,74047,66896,13769,78895,328958,74815,1297,81226,8205,1280,256,65830,1344,5952]

theorem envBound53131 : H12AffineFastState.Bounded env53131 := by
  intro p hp
  have h : env53131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53004_53131 : H12AffineEnvironment.transform 13 1297 env53004 = env53131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53004 == env53131) = true)

def env53132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4096,5276,74047,66896,13769,78895,1150,74815,1297,81226,8205,1280,256,65830,1344,5952]

theorem envBound53132 : H12AffineFastState.Bounded env53132 := by
  intro p hp
  have h : env53132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53131_53132 : H12AffineEnvironment.transform 17 65664 env53131 = env53132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53131 == env53132) = true)

theorem identity53132 : scanCanonicalize (H12AffineFastState.compose env53132 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53132 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,65536,74863,65664,320,8541,1,1181,74047,66896,9672,74798,1150,74815,1297,77131,8205,1280,256,65830,1344,1857]

theorem envBound53133 : H12AffineFastState.Bounded env53133 := by
  intro p hp
  have h : env53133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53132_53133 : H12AffineEnvironment.transform 11 1 env53132 = env53133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53132 == env53133) = true)

def env53134 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,65536,74031,65664,320,8541,1,477,74047,65552,8328,74094,318,74111,81,75787,8205,64,256,65830,0,513]

theorem envBound53134 : H12AffineFastState.Bounded env53134 := by
  intro p hp
  have h : env53134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53133_53134 : H12AffineEnvironment.transform 9 320 env53133 = env53134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53133 == env53134) = true)

theorem identity53134 : scanCanonicalize (H12AffineFastState.compose env53134 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound53134 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53135 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,35,8460,163,320,8541,1,477,8476,51,8328,8525,318,8540,81,10280,8205,64,256,261,0,513]

theorem envBound53135 : H12AffineFastState.Bounded env53135 := by
  intro p hp
  have h : env53135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53134_53135 : H12AffineEnvironment.transform 15 35 env53134 = env53135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env53134 == env53135) = true)

theorem identity53135 : scanCanonicalize (H12AffineFastState.compose env53135 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53135 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53136 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,1,8192,81,8265,35,8217,163,85,8264,1,200,8201,51,8328,8280,43,8265,81,10280,8205,64,21,16,0,513]

theorem envBound53136 : H12AffineFastState.Bounded env53136 := by
  intro p hp
  have h : env53136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53135_53136 : H12AffineEnvironment.transform 7 21 env53135 = env53136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53135 == env53136) = true)

theorem identity53136 : scanCanonicalize (H12AffineFastState.compose env53136 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53136 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53137 : List Nat := [2,4,8,1,32,64,128,4,512,68,2048,1,8192,64,8265,35,8200,163,68,8264,1,200,8201,34,8328,8265,43,8265,64,10280,8205,64,4,1,0,513]

theorem envBound53137 : H12AffineFastState.Bounded env53137 := by
  intro p hp
  have h : env53137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53136_53137 : H12AffineEnvironment.transform 3 1 env53136 = env53137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53136 == env53137) = true)

theorem identity53137 : scanCanonicalize (H12AffineFastState.compose env53137 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 640) := by decide +kernel

theorem selectedBound53137 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env53138 : List Nat := [2,4,8,1,32,64,128,4,512,68,2048,1,640,64,713,35,648,163,68,712,1,200,649,34,520,713,43,713,64,2728,653,64,4,1,0,513]

theorem envBound53138 : H12AffineFastState.Bounded env53138 := by
  intro p hp
  have h : env53138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53137_53138 : H12AffineEnvironment.transform 12 640 env53137 = env53138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env53137 == env53138) = true)

theorem identity53138 : scanCanonicalize (H12AffineFastState.compose env53138 (packedSelected [1,2,3,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound53138 : packedSelected [1,2,3,13,15] rootPS < 2^1333 := by decide +kernel

def env53139 : List Nat := [2,4,8,1,32,64,128,4,512,68,675,1,640,64,713,35,648,163,68,712,1,200,649,34,520,713,43,713,64,11,653,64,4,1,0,513]

theorem envBound53139 : H12AffineFastState.Bounded env53139 := by
  intro p hp
  have h : env53139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53138_53139 : H12AffineEnvironment.transform 10 675 env53138 = env53139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env53138 == env53139) = true)

theorem identity53139 : scanCanonicalize (H12AffineFastState.compose env53139 (packedSelected [3,4,5,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 196) := by decide +kernel

theorem selectedBound53139 : packedSelected [3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53140 : List Nat := [2,4,8,1,32,64,128,4,196,68,103,1,68,64,13,35,76,163,68,12,1,200,77,34,204,13,43,13,64,11,73,64,4,1,0,197]

theorem envBound53140 : H12AffineFastState.Bounded env53140 := by
  intro p hp
  have h : env53140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53139_53140 : H12AffineEnvironment.transform 8 196 env53139 = env53140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 196 env53139 == env53140) = true)

theorem identity53140 : scanCanonicalize (H12AffineFastState.compose env53140 (packedSelected [2,3,4,8,9,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound53140 : packedSelected [2,3,4,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env53141 : List Nat := [2,4,8,1,32,13,128,4,137,9,42,1,9,13,13,35,1,163,9,12,1,133,0,34,129,13,43,13,13,11,4,13,4,1,0,136]

theorem envBound53141 : H12AffineFastState.Bounded env53141 := by
  intro p hp
  have h : env53141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53140_53141 : H12AffineEnvironment.transform 5 13 env53140 = env53141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env53140 == env53141) = true)

theorem identity53141 : scanCanonicalize (H12AffineFastState.compose env53141 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53141 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53142 : List Nat := [2,2,8,1,32,11,128,2,137,9,42,1,9,11,11,35,1,163,9,10,1,131,0,34,129,11,43,11,11,11,2,11,2,1,0,136]

theorem envBound53142 : H12AffineFastState.Bounded env53142 := by
  intro p hp
  have h : env53142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53141_53142 : H12AffineEnvironment.transform 1 2 env53141 = env53142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53141 == env53142) = true)

theorem identity53142 : scanCanonicalize (H12AffineFastState.compose env53142 (packedSelected [0,1,2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53142 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env53143 : List Nat := [2,2,1,1,32,2,128,2,128,0,35,1,0,2,2,35,1,163,0,3,1,131,0,34,129,2,34,2,2,2,2,2,2,1,0,129]

end H12CloudChart2